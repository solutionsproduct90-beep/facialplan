<!--
  ============================================================================
  POLÍTICA DE PRIVACIDADE DO FacialPlan — VERSÃO 2026-09-28
  ============================================================================

  COMO ESTE ARQUIVO FUNCIONA
  Mesmo esquema do arquivo de Termos: Markdown versionado no repositório, e a
  data de vigência vive em PRIVACY_VERSION (src/lib/legalDocs.ts). Toda
  alteração de conteúdo exige subir essa data, porque ela é gravada em
  terms_acceptances.privacy_version no momento do aceite.

  ---------------------------------------------------------------------------
  !! PENDÊNCIAS QUE SÓ O DONO DO PRODUTO PODE RESOLVER !!
  ---------------------------------------------------------------------------
  Razão social, CNPJ, endereço, encarregado (DPO) e prazos de retenção
  foram preenchidos em 2026-09-28 com os dados fornecidos pelo dono do
  produto. Os prazos de retenção (30 dias / 12 meses) são os já propostos
  neste documento, coerentes com o que o código faz hoje, mas ainda
  merecem validação jurídica formal — em especial o prazo de guarda de
  prontuário, que para profissional médico segue a Resolução CFM
  nº 1.821/2007 (20 anos), sob responsabilidade do profissional, não da
  plataforma.

  Ainda PENDENTE (só o dono do produto resolve):
    1. Confirmação de que há DPA/contrato de operador assinado com cada
       subprocessador listado na seção 6
    2. Região de hospedagem efetivamente contratada no Supabase (a lista de
       transferência internacional abaixo assume infraestrutura fora do
       Brasil, que é o padrão da conta)

  A LISTA DE SUBPROCESSADORES DA SEÇÃO 6 FOI LEVANTADA DO CÓDIGO, não de
  memória — cada item tem a referência do arquivo que faz a chamada. Se uma
  integração for adicionada ou removida, esta seção precisa ser atualizada
  junto, no mesmo commit.
  ---------------------------------------------------------------------------
-->

# Política de Privacidade do FacialPlan

**Versão 2026-09-17.** Esta Política explica que dados o FacialPlan trata, por
quê, com quem compartilha e como você e seus pacientes exercem seus direitos.
Ela é parte integrante dos [Termos de Uso](/termos).

## 1. Quem é controlador e quem é operador

O FacialPlan trata dois conjuntos de dados muito diferentes, e o papel de cada
parte muda conforme o conjunto. Essa distinção não é formalidade: ela define
quem responde por quê.

**a) Dados dos seus pacientes** (fotografia de rosto, anamnese, histórico
clínico, plano de tratamento, orçamento, evolução):

- **Controlador: você**, profissional de saúde usuário. É você quem tem a
  relação clínica com o titular, quem decide coletar o dado, para qual
  finalidade, e quem deve colher o consentimento.
- **Operador: o FacialPlan**, que trata esses dados exclusivamente conforme suas
  instruções — isto é, conforme o que você faz na plataforma — e para nenhuma
  finalidade própria.

**b) Seus dados como assinante** (nome, e-mail, especialidade, registro
profissional, dados de assinatura, logs de uso e de erro):

- **Controlador: o FacialPlan**, operado por **VENDRE DIGITAL**, CNPJ
  **51.755.399/0001-51**, sede em **Rua Simão da Cunha Gago, 145, Aterrado,
  Volta Redonda - RJ**.

## 2. Que dados são coletados

### 2.1 Do profissional assinante

Nome completo, e-mail, senha (armazenada apenas como hash pelo provedor de
autenticação), especialidade, tipo e número de registro no conselho, telefone,
país, nome e logotipo da clínica, preferências de idioma e de configuração,
dados de estoque e de precificação, identificadores de assinatura, endereço IP
e user agent no momento do aceite dos [Termos de Uso](/termos) e desta
Política, e registros técnicos de uso e de erro.

### 2.2 Dos pacientes — inclui dado sensível

Nome, telefone, data de nascimento, observações clínicas, **fotografias de
rosto** e **dados referentes à saúde** (anamnese: alergias, medicamentos em
uso, doenças autoimunes, gestação/lactação, implantes metálicos e marcapasso,
procedimentos anteriores, eventos adversos, triagem de lesões cutâneas
suspeitas), plano de aplicação (substâncias, quantidades, regiões),
consentimentos registrados, orçamentos e histórico de evolução.

Fotografia de rosto é **dado biométrico** e anamnese é **dado referente à
saúde** — ambos são **dados pessoais sensíveis** na LGPD (art. 5º, II). O
tratamento se apoia no **consentimento específico e destacado do titular**
(art. 11, I) e, no contexto assistencial, na hipótese de tutela da saúde em
procedimento realizado por profissional de saúde (art. 11, II, "f"),
observado que a base legal, no caso, é invocada por você, controlador.

### 2.3 De visitantes do site

Dados mínimos de navegação nas páginas públicas e, quando você preenche um
formulário de contato ou de captação de mini-site, os dados que você mesmo
informa.

## 3. Para que os dados são usados

- Prestar o serviço: analisar as fotografias, gerar sugestões e simulações,
  montar prontuário, orçamento, agenda e documentos.
- Comunicar com o paciente **em seu nome e por sua iniciativa** (link de
  anamnese, apresentação de resultado, lembretes de retorno, cartão de
  emergência pós-procedimento).
- Operar a assinatura: cobrança, liberação e bloqueio de acesso.
- Segurança, prevenção a fraude, registro de auditoria e diagnóstico de erro.
- Melhoria de IA **somente com consentimento opt-in específico por paciente**,
  e apenas sobre dados agregados e anonimizados (ver seção 5 dos
  [Termos de Uso](/termos)).

**Não vendemos dados pessoais. Não usamos fotografia de paciente para treinar
modelos de inteligência artificial.**

## 4. Com base em quê tratamos (bases legais)

| Tratamento | Base legal (LGPD) |
| --- | --- |
| Conta e assinatura do profissional | Execução de contrato (art. 7º, V) |
| Cobrança e obrigações fiscais | Cumprimento de obrigação legal (art. 7º, II) |
| Segurança, auditoria e prevenção a fraude | Legítimo interesse (art. 7º, IX) |
| Fotografia de rosto e anamnese do paciente | Consentimento específico e destacado (art. 11, I) e tutela da saúde (art. 11, II, "f") |
| Uso de imagem em divulgação | Consentimento específico, separado e revogável |
| Dados agregados para melhoria de IA | Consentimento opt-in específico, revogável |

## 5. Como os dados são protegidos

- Isolamento por profissional imposto no banco de dados por **Row Level
  Security** — cada linha de paciente, sessão, foto e consentimento só é
  legível pelo profissional dono; não é um filtro na aplicação que poderia ser
  contornado.
- Fotografias e simulações ficam em **buckets privados**, com política de
  acesso por pasta do próprio profissional; não há URL pública permanente.
- Comunicação em trânsito por TLS; senhas sob hash no provedor de
  autenticação.
- Registro de auditoria das ações sensíveis e log de erros sem conteúdo
  clínico.

## 6. Com quem compartilhamos (subprocessadores)

O FacialPlan se apoia em provedores que atuam como **operadores/subprocessadores**.
Esta lista reflete as integrações efetivamente presentes no produto:

| Provedor | Para quê | Que dado alcança |
| --- | --- | --- |
| **Supabase** | Banco de dados, autenticação, armazenamento de arquivos e execução das funções de servidor | Todos os dados da plataforma, incluindo fotografias e anamnese |
| **OpenAI** | Análise facial, segunda checagem de risco e leitura de rótulo de insumo | Fotografia enviada para análise e o contexto clínico necessário àquela chamada |
| **Google** (Gemini) | Geração da simulação visual e de imagens de marketing | Fotografia enviada para a simulação |
| **Hotmart** | Venda e renovação da assinatura | Nome, e-mail e status da compra |
| **Resend** | Envio de e-mails transacionais (ao profissional e, por sua iniciativa, ao paciente) | Nome, e-mail e o conteúdo da mensagem enviada |
| **Vercel** | Servir o aplicativo e as páginas públicas | Dados técnicos de requisição (IP, user agent) |

Cada provedor trata os dados apenas para a finalidade acima. A contratação
formal (DPA/cláusulas de operador) com cada um é responsabilidade do
controlador — ver a pendência nº 5 no cabeçalho deste arquivo.

## 7. Transferência internacional de dados

Os provedores acima operam, no todo ou em parte, **fora do território
brasileiro** — notadamente nos Estados Unidos e na União Europeia. Isso
significa que fotografias e dados clínicos de pacientes podem ser processados
fora do Brasil.

A transferência se apoia no art. 33 da LGPD, em especial no consentimento
específico e destacado do titular (inciso VIII) e nas cláusulas contratuais
firmadas com cada operador (inciso II), e — quando aplicável a titulares no
Espaço Econômico Europeu — nas Cláusulas Contratuais Padrão da Comissão
Europeia.

Como você é o controlador dos dados dos seus pacientes, **a existência dessa
transferência é informação que o paciente precisa receber de você** no momento
do consentimento. O texto de consentimento oferecido pela plataforma já
menciona o uso de inteligência artificial sobre a imagem.

## 8. Por quanto tempo guardamos

| Dado | Prazo |
| --- | --- |
| Dados de paciente, fotos, anamnese e sessões | Enquanto a conta existir e você não excluir o paciente. A exclusão permanente de um paciente apaga em cascata sessões, fotografias, anamnese e consentimentos vinculados |
| Conta do profissional | Enquanto a assinatura existir; após o encerramento, **30 dias** para exportação dos dados antes da exclusão |
| Registros de aceite dos Termos e da Política | Pelo prazo prescricional aplicável, mesmo após o encerramento da conta — é a prova do contrato |
| Dados fiscais e de pagamento | Pelo prazo exigido pela legislação fiscal |
| Logs de auditoria e de erro | **12 meses** |

**Guarda de prontuário:** o dever legal de guardar o prontuário do paciente,
pelo prazo fixado pelo conselho profissional aplicável, é **seu**, controlador
— não da plataforma. Exportar e arquivar o prontuário antes de excluir um
paciente ou encerrar a conta é sua responsabilidade. Ver pendência nº 4 no
cabeçalho deste arquivo.

## 9. Direitos do titular e como exercê-los

Todo titular tem direito a confirmação de tratamento, acesso, correção,
anonimização, bloqueio, eliminação, portabilidade, informação sobre
compartilhamento, revisão de decisão automatizada e revogação do consentimento
(arts. 18 e 20 da LGPD).

**Se você é paciente:** o seu controlador é o profissional que te atendeu.
Fale com ele — é quem tem a sua ficha e quem pode corrigir, exportar ou
excluir os seus dados dentro da plataforma. Se ele não atender, você pode nos
acionar pelo contato da seção 10, e nós o apoiaremos na resposta, na condição
de operador.

**Se você é o profissional assinante:** dentro do aplicativo você já consegue,
sem pedir nada a ninguém:

- exportar o prontuário completo de um paciente;
- corrigir qualquer dado cadastral ou clínico;
- excluir permanentemente um paciente, com apagamento em cascata de sessões,
  fotografias, anamnese e consentimentos;
- revogar, por paciente, o consentimento de marketing e o de melhoria de IA;
- consultar os aceites de Termos e Política que você registrou, com versão,
  data e origem.

Para os demais pedidos, inclusive exclusão da sua própria conta, use o contato
abaixo. Respondemos em até 15 dias.

## 10. Encarregado pelo tratamento de dados (DPO)

Encarregado: **VENDRE DIGITAL — Encarregado de Proteção de Dados**
E-mail: **privacidade@facialplan.com.br**

A indicação e a divulgação pública do encarregado são exigidas pelo art. 41 da
LGPD. Você também pode reclamar diretamente à Autoridade Nacional de Proteção
de Dados (ANPD).

## 11. Incidentes de segurança

Em caso de incidente que possa acarretar risco ou dano relevante aos
titulares, comunicaremos a ANPD e os controladores afetados — ou seja, você —
em prazo razoável, com as informações do art. 48, § 1º, da LGPD, para que você
possa cumprir seu próprio dever de comunicação aos pacientes.

## 12. Alterações desta Política

Cada revisão recebe uma nova versão datada. Quando a mudança afetar as
finalidades ou o compartilhamento de dados, pediremos um **novo aceite** e
registraremos qual versão você aceitou e quando.

## 13. Contato

**privacidade@facialplan.com.br**
