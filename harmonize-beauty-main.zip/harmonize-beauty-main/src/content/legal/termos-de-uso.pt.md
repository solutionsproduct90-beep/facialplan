<!--
  ============================================================================
  TERMOS DE USO DO FacialPlan — VERSÃO 2026-09-28
  ============================================================================

  COMO ESTE ARQUIVO FUNCIONA
  Conteúdo em Markdown versionado no repositório, mesmo padrão dos posts do
  blog (src/content/blog/<locale>/*.md, ver src/lib/blog.ts): publicar uma
  revisão é editar o arquivo, subir a data em TERMS_VERSION
  (src/lib/legalDocs.ts) e dar merge. A data em TERMS_VERSION é gravada em
  terms_acceptances.terms_version a cada aceite — por isso NUNCA edite o
  texto sem subir a versão: quem aceitou a versão antiga continuaria
  registrado como tendo aceitado um texto que já não existe.

  ---------------------------------------------------------------------------
  !! PENDÊNCIAS QUE SÓ O DONO DO PRODUTO PODE RESOLVER !!
  ---------------------------------------------------------------------------
  Razão social, CNPJ, endereço, e-mail de contato e foro eleito foram
  preenchidos em 2026-09-28 com os dados fornecidos pelo dono do produto.

  Ainda PENDENTE (só o dono do produto resolve):
    1. Confirmação de que os contratos/DPAs com os subprocessadores listados
       na Política de Privacidade foram de fato assinados
  ---------------------------------------------------------------------------
-->

# Termos de Uso do FacialPlan

**Versão 2026-09-17.** Estes Termos regem o uso da plataforma FacialPlan e
constituem o contrato entre você, profissional de saúde usuário, e a empresa
que opera o FacialPlan.

Ao criar uma conta, você declara que leu, entendeu e concorda integralmente
com estes Termos e com a [Política de Privacidade](/privacidade), que é parte
inseparável deles.

## 1. Quem somos

O FacialPlan é operado por **VENDRE DIGITAL**, inscrita no
CNPJ sob o nº **51.755.399/0001-51**, com sede em **Rua Simão da Cunha Gago, 145,
Aterrado, Volta Redonda - RJ** (doravante "FacialPlan", "nós").

## 2. O que o FacialPlan é — e o que ele não é

O FacialPlan é uma ferramenta de **apoio ao planejamento** de procedimentos de
harmonização facial, destinada exclusivamente a profissionais de saúde
legalmente habilitados. A plataforma:

- analisa fotografias faciais e produz sugestões de pontos de aplicação,
  substâncias e quantidades;
- gera simulações visuais de resultado estimado por inteligência artificial;
- organiza prontuário, anamnese, orçamento, agenda, estoque e comunicação com
  o paciente.

O FacialPlan **não é um dispositivo médico, não emite diagnóstico e não prescreve
tratamento**. Toda sugestão gerada pela plataforma — inclusive a sinalização
de lesões cutâneas suspeitas e as checagens automáticas de risco — é
informação de apoio e **jamais substitui o exame presencial, o julgamento
clínico e a decisão do profissional**. A simulação visual é uma estimativa
gerada por IA e **não é promessa de resultado**.

## 3. Habilitação profissional e responsabilidade regulatória

O uso desta plataforma para o planejamento de procedimentos estéticos
injetáveis (incluindo, entre outros, toxina botulínica, ácido hialurônico e
bioestimuladores de colágeno) pressupõe que você está devida e legalmente
habilitado, nos termos da legislação aplicável à sua profissão e jurisdição e
das normas do seu conselho ou órgão de classe, a realizar os procedimentos
que planejar por meio da plataforma.

O FacialPlan não valida, audita, garante ou se responsabiliza, de qualquer forma,
pela conformidade do profissional usuário com o escopo de atuação legal de
sua profissão, tampouco arbitra controvérsias regulatórias entre conselhos de
classe quanto à competência para a realização de determinado procedimento. A
definição de quais procedimentos cada categoria profissional está autorizada a
executar é de competência exclusiva da legislação vigente e dos respectivos
conselhos e órgãos reguladores de cada jurisdição.

A responsabilidade técnica, ética e legal pelos procedimentos planejados e
executados é inteira e exclusivamente sua.

## 4. Sua conta

Você é responsável por manter a confidencialidade das suas credenciais e por
tudo que acontecer na sua conta. A conta é **pessoal e intransferível**:
compartilhá-la com outro profissional significa dar a ele acesso ao prontuário
e às fotografias dos **seus** pacientes, o que é violação destes Termos e,
provavelmente, do seu dever de sigilo profissional.

Você se compromete a nos avisar imediatamente em caso de suspeita de acesso
indevido.

## 5. Dados dos seus pacientes: você é o controlador

Este é o ponto mais importante do contrato.

Em relação aos dados pessoais dos **seus pacientes** — incluindo fotografias
de rosto, anamnese, histórico clínico e plano de tratamento — **você é o
CONTROLADOR** e o **FacialPlan é o OPERADOR**, nos termos do art. 5º, VI e VII, da
Lei nº 13.709/2018 (LGPD). Na prática:

- é você quem decide coletar aquele dado, para qual finalidade e por quanto
  tempo mantê-lo;
- é você quem tem a relação clínica com o titular e o dever de informá-lo;
- **é você quem deve colher o consentimento do paciente** antes de fotografar,
  antes de usar a imagem em divulgação e antes de realizar o procedimento. A
  plataforma oferece as ferramentas para isso (consentimento geral de imagem e
  IA, TCLE por procedimento e consentimento opcional de marketing), mas
  oferecer a ferramenta não transfere a obrigação;
- o FacialPlan trata esses dados **apenas** conforme as instruções que você dá ao
  usar a plataforma, e para nenhuma finalidade própria além de prestar o
  serviço, garantir sua segurança e cumprir obrigação legal.

Em relação aos **seus próprios** dados cadastrais (nome, e-mail, registro
profissional, dados de pagamento), o FacialPlan é o controlador. A
[Política de Privacidade](/privacidade) detalha os dois papéis.

## 6. Uso de dados agregados para melhoria da IA

Além do consentimento clínico geral de uso de imagem e IA e do consentimento
de marketing, o FacialPlan oferece um terceiro consentimento, **específico e
opcional**, registrado por paciente: autorizar que os dados das sessões
daquele paciente — sempre agregados e anonimizados, nunca individualizáveis —
sejam usados para aprimorar as sugestões de inteligência artificial da
plataforma.

Esse consentimento tem valor padrão negativo (**opt-in explícito, nunca
opt-out por omissão**) e pode ser concedido ou revogado a qualquer momento na
ficha do paciente. As estatísticas que dele dependem são calculadas por
agrupamento, com número mínimo de amostras, e nunca expõem nome, foto,
telefone, prontuário ou qualquer outro dado que identifique um paciente ou um
profissional específico.

**Fotografias de pacientes nunca são usadas para treinar modelos de IA**, nem
por nós nem pelos provedores de IA que utilizamos.

## 7. Assinatura, pagamento e inadimplência

O acesso às funcionalidades clínicas depende de assinatura ativa. Os
pagamentos são processados pela **Hotmart**; o FacialPlan não armazena número
de cartão.

Em caso de falha de pagamento, a assinatura entra em situação de atraso e
você é avisado dentro do aplicativo, com um **período de carência de 3 dias**
antes de o acesso às funcionalidades clínicas ser bloqueado. Mesmo bloqueado,
você continua podendo acessar a área de regularização e **exercer seus
direitos sobre os dados**, inclusive exportá-los — bloqueio por inadimplência
nunca é usado como forma de reter dado de paciente.

O cancelamento pode ser feito a qualquer tempo e produz efeito ao fim do ciclo
já pago, sem reembolso proporcional, salvo disposição legal em contrário
(notadamente o direito de arrependimento do art. 49 do Código de Defesa do
Consumidor, quando aplicável).

## 8. Condutas vedadas

É vedado, entre outros:

- usar a plataforma sem habilitação profissional para o procedimento planejado;
- inserir fotografia ou dado de saúde de pessoa que não é seu paciente, ou de
  quem você não tenha obtido consentimento;
- apresentar a simulação gerada por IA ao paciente como promessa de resultado;
- tentar acessar dados de outro profissional, burlar limites de plano,
  automatizar acesso por meios não autorizados, ou submeter a plataforma a
  engenharia reversa;
- revender, sublicenciar ou expor as funcionalidades da plataforma a terceiros
  fora do seu uso profissional.

O descumprimento pode levar à suspensão ou encerramento da conta, sem prejuízo
das responsabilidades legais.

## 9. Propriedade intelectual

O software, a marca, a interface e os conteúdos do FacialPlan são nossos. As
fotografias, os prontuários e os dados que você insere continuam **seus e dos
seus pacientes** — não reivindicamos propriedade sobre eles e não os usamos
fora do que estes Termos e a Política de Privacidade preveem.

As imagens geradas pela IA a partir das fotografias que você envia podem ser
usadas por você no contexto do atendimento e, havendo consentimento específico
do paciente, em divulgação.

## 10. Disponibilidade e limitação de responsabilidade

Fazemos esforço razoável para manter a plataforma disponível, mas ela depende
de serviços de terceiros (infraestrutura, provedores de IA, gateways de
pagamento) e pode ficar indisponível por manutenção ou falha. Não garantimos
disponibilidade ininterrupta.

Na máxima extensão permitida pela lei aplicável, nossa responsabilidade
agregada por qualquer reclamação relacionada ao serviço fica limitada ao valor
pago por você nos 12 meses anteriores ao fato. **Esta limitação não se aplica**
a dolo, a danos decorrentes de violação de dados causada por nós, nem a
qualquer hipótese em que a lei vede a limitação — inclusive nas relações
regidas pelo Código de Defesa do Consumidor.

Não respondemos por decisão clínica tomada por você, por resultado de
procedimento, nem por uso da plataforma fora do seu escopo de habilitação.

## 11. Alterações destes Termos

Podemos revisar estes Termos. Cada revisão recebe uma nova versão datada.
Alterações relevantes são comunicadas com antecedência razoável e, quando a
mudança afetar seus direitos ou o tratamento de dados, **pediremos um novo
aceite** — o registro de qual versão você aceitou, e quando, é mantido por nós
justamente para isso.

## 12. Encerramento

Você pode encerrar sua conta a qualquer momento. Podemos encerrá-la em caso de
violação destes Termos ou de inadimplência prolongada, sempre com aviso prévio
e janela para exportação dos dados, ressalvadas as hipóteses de determinação
legal ou judicial.

## 13. Lei aplicável e foro

Estes Termos são regidos pelas leis da República Federativa do Brasil. Fica
eleito o foro da comarca de **Volta Redonda, Rio de Janeiro** para
dirimir controvérsias, ressalvado o direito do consumidor de demandar no foro
do seu domicílio.

## 14. Contato

Dúvidas sobre estes Termos, sobre a plataforma ou sobre seus dados:
**privacidade@facialplan.com.br**. Para assuntos de proteção de dados, fale
com o encarregado indicado na [Política de Privacidade](/privacidade).
