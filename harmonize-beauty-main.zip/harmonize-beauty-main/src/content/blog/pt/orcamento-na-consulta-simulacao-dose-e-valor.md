---
title: "Orçamento na consulta: por que simular dose e valor na hora muda o atendimento"
description: "Fechar o orçamento só depois da consulta, em outra ferramenta, quebra o momento de decisão do paciente. Entender por que dose, substância e valor deveriam aparecer juntos, ao vivo, durante o atendimento."
date: "2026-09-05"
author: "Equipe FacialPlan"
tags: "orçamento, planejamento, conversão"
---

Um padrão comum em consultórios de harmonização facial. O profissional define o plano de aplicação durante a consulta, mas o orçamento só é montado depois, numa planilha separada, numa calculadora à parte, às vezes até num aplicativo diferente do que foi usado pra simular o resultado. O paciente sai da consulta sem saber o valor, e o profissional perde o momento em que a decisão estava mais próxima de acontecer.

## O custo real de separar plano e orçamento

Toda vez que dose, substância e preço não aparecem juntos no mesmo fluxo, dois problemas acontecem.

1. **O orçamento vira estimativa, não cálculo.** Sem ligação direta entre a quantidade real definida no plano e o preço de cada marca ou substância, o valor apresentado ao paciente tende a ser arredondado ou aproximado. Isso gera divergência quando o valor final muda.
2. **A decisão esfria.** Entre a consulta, onde a expectativa visual está mais forte, com a simulação na tela, e o retorno com o orçamento pronto, o paciente tem tempo de comparar preços em outro lugar, adiar, ou simplesmente esquecer.

## Por que o cálculo em tempo real resolve os dois

Quando o orçamento é calculado automaticamente a partir da mesma quantidade e marca definidas no plano de aplicação, no mesmo momento em que a simulação está sendo mostrada, o paciente vê resultado esperado e investimento necessário lado a lado, sem intervalo entre eles. Isso não é um truque de vendas. É eliminar a fricção de um processo que, hoje, costuma estar fragmentado em ferramentas diferentes.

## O que isso exige tecnicamente

Pra funcionar de verdade, o cálculo precisa vir dos mesmos dados do plano clínico. Cada marca de insumo com seu custo e preço próprio, somada por substância e quantidade real definida ponto a ponto, não uma tabela de preço fixa por "tipo de procedimento" desconectada do que foi efetivamente decidido naquela sessão.

No FacialPlan, o orçamento do Estágio 2/3 é montado a partir da mesma arquitetura de insumos e marca usada no plano de aplicação. Cada ponto de aplicação já carrega sua substância, marca e quantidade, e o orçamento profissional, nunca exposto ao paciente ou no link público, é calculado em cima disso, ao vivo, sem precisar sair da tela de atendimento pra outra ferramenta.
