---
title: "Consentimento informado por procedimento: por que um TCLE genérico não basta"
description: "Um termo de consentimento único para toda a clínica deixa buracos jurídicos e clínicos. Veja por que o consentimento deveria ser específico por procedimento, e como estruturar isso na prática."
date: "2026-09-01"
author: "Equipe FacialPlan"
tags: "consentimento, segurança clínica, TCLE"
---

Grande parte das clínicas de harmonização facial ainda usa um único Termo de Consentimento Livre e Esclarecido (TCLE), genérico, assinado uma vez no cadastro do paciente. Ele cobre "procedimentos estéticos" em geral, sem detalhar riscos específicos de cada substância, técnica ou região tratada.

O problema aparece exatamente no momento em que o consentimento importa. Uma intercorrência.

## Por que o TCLE genérico falha

Um consentimento específico por procedimento precisa registrar, no mínimo, estes três pontos.

- **A substância e a quantidade** planejadas para aquela sessão (não "preenchimento facial", mas "1,5ml de ácido hialurônico, região malar").
- **Os riscos daquela técnica específica**, não uma lista genérica de "possíveis efeitos colaterais".
- **A assinatura vinculada àquela sessão**, com data e, sempre que possível, evidência de identidade (IP, dispositivo) de quem assinou.

Sem isso, o termo genérico serve como formalidade, não como proteção real. Nem para o paciente, que não foi de fato informado sobre o procedimento específico que vai receber, nem para o profissional, que não tem como provar que aquele risco pontual foi comunicado.

## Consentimento como parte do fluxo, não como anexo

A forma mais confiável de garantir que o consentimento específico realmente aconteça é embuti-lo no próprio fluxo de atendimento, no momento em que o plano do procedimento já está definido, depois que substância, quantidade e técnica foram decididas, antes da aplicação.

No FacialPlan, isso acontece automaticamente. Ao avançar da etapa de planejamento (onde os pontos de aplicação, substâncias e quantidades são definidos) para a etapa de execução, o sistema gera um termo específico daquela sessão, com os dados reais do plano, não um texto fixo, e exige a assinatura do paciente, registrando IP e timestamp, antes de liberar a continuidade.

Isso muda o consentimento de "documento que existe" para "documento que corresponde à realidade daquele atendimento".

## O que verificar no seu processo hoje

Se sua clínica ainda usa TCLE genérico, algumas perguntas ajudam a diagnosticar o tamanho do buraco.

1. O termo assinado pelo paciente menciona a substância e quantidade reais daquela sessão?
2. Existe um termo por sessão, ou um único termo vale para todo o histórico do paciente?
3. Em caso de intercorrência, você consegue mostrar exatamente o que foi comunicado ao paciente antes daquele procedimento específico?

Se a resposta for "não" em qualquer uma delas, o consentimento genérico está expondo tanto o paciente quanto a clínica a um risco que é simples de eliminar. Só exige que o consentimento vire parte do fluxo clínico, não um documento à parte.
