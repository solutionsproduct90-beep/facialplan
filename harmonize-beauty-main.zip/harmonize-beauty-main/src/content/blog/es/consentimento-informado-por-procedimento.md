---
title: "Consentimiento informado por procedimiento: por qué un documento genérico no alcanza"
description: "Un único consentimiento para toda la clínica deja huecos legales y clínicos. Por qué el consentimiento debería ser específico por procedimiento, y cómo estructurarlo en la práctica."
date: "2026-09-01"
author: "Equipo FacialPlan"
tags: "consentimiento, seguridad clínica, documentación"
---

Gran parte de las clínicas de armonización facial todavía usa un único documento de consentimiento informado, genérico, firmado una sola vez en el registro del paciente. Cubre "procedimientos estéticos" en general, sin detallar los riesgos específicos de cada sustancia, técnica o región tratada.

El problema aparece justo en el momento en que el consentimiento realmente importa. Una complicación.

## Por qué el consentimiento genérico falla

Un consentimiento específico por procedimiento necesita registrar, como mínimo, estos tres puntos.

- **La sustancia y la cantidad** planificadas para esa sesión (no "relleno facial", sino "1,5ml de ácido hialurónico, región malar").
- **Los riesgos de esa técnica específica**, no una lista genérica de "posibles efectos secundarios".
- **La firma vinculada a esa sesión**, con fecha y, siempre que sea posible, evidencia de identidad (IP, dispositivo) de quien firmó.

Sin esto, el documento genérico funciona como formalidad, no como protección real. Ni para el paciente, que no fue realmente informado sobre el procedimiento específico que va a recibir, ni para el profesional, que no puede demostrar que ese riesgo puntual fue comunicado.

## El consentimiento como parte del flujo, no como un anexo

La forma más confiable de garantizar que el consentimiento específico realmente ocurra es integrarlo al propio flujo de atención, en el momento en que el plan del procedimiento ya está definido, después de decidir sustancia, cantidad y técnica, antes de la aplicación.

En FacialPlan esto ocurre automáticamente. Al avanzar de la etapa de planificación (donde se definen los puntos de aplicación, sustancias y cantidades) a la etapa de ejecución, el sistema genera un documento específico de esa sesión, con los datos reales del plan, no un texto fijo, y exige la firma del paciente, registrando IP y marca de tiempo, antes de permitir continuar.

Esto cambia el consentimiento de "documento que existe" a "documento que corresponde a la realidad de esa consulta".

## Qué revisar en tu proceso hoy

Si tu clínica todavía usa un consentimiento genérico, algunas preguntas ayudan a diagnosticar el tamaño del problema.

1. ¿El documento firmado por el paciente menciona la sustancia y cantidad reales de esa sesión?
2. ¿Existe un documento por sesión, o un único documento vale para todo el historial del paciente?
3. Ante una complicación, ¿puedes mostrar exactamente qué se le comunicó al paciente antes de ese procedimiento específico?

Si la respuesta es "no" en cualquiera de ellas, el consentimiento genérico está exponiendo tanto al paciente como a la clínica a un riesgo que es simple de eliminar. Solo exige que el consentimiento sea parte del flujo clínico, no un documento aparte.
