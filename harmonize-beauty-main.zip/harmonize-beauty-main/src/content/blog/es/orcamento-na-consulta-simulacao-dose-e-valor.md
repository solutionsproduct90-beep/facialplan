---
title: "Presupuesto en la consulta: por qué simular dosis y valor en el momento cambia la atención"
description: "Cerrar el presupuesto recién después de la consulta, en otra herramienta, rompe el momento de decisión del paciente. Entiende por qué dosis, sustancia y valor deberían aparecer juntos, en vivo, durante la consulta."
date: "2026-09-05"
author: "Equipo FacialPlan"
tags: "presupuesto, planificación, conversión"
---

Un patrón común en consultorios de armonización facial. El profesional define el plan de aplicación durante la consulta, pero el presupuesto se arma recién después, en una planilla aparte, en una calculadora distinta, a veces incluso en una aplicación diferente de la que se usó para simular el resultado. El paciente sale de la consulta sin saber el valor, y el profesional pierde el momento en que la decisión estaba más cerca de concretarse.

## El costo real de separar plan y presupuesto

Cada vez que dosis, sustancia y precio no aparecen juntos en el mismo flujo, ocurren dos problemas.

1. **El presupuesto se vuelve estimación, no cálculo.** Sin conexión directa entre la cantidad real definida en el plan y el precio de cada marca o sustancia, el valor presentado al paciente tiende a ser redondeado o aproximado. Eso genera discrepancias cuando el valor final cambia.
2. **La decisión se enfría.** Entre la consulta, donde la expectativa visual está más fuerte, con la simulación en pantalla, y el regreso con el presupuesto listo, el paciente tiene tiempo de comparar precios en otro lugar, postergar, o simplemente olvidarse.

## Por qué el cálculo en tiempo real resuelve ambos problemas

Cuando el presupuesto se calcula automáticamente a partir de la misma cantidad y marca definidas en el plan de aplicación, en el mismo momento en que se muestra la simulación, el paciente ve el resultado esperado y la inversión necesaria lado a lado, sin intervalo entre ambos. Esto no es un truco de ventas. Es eliminar la fricción de un proceso que, hoy, suele estar fragmentado en herramientas distintas.

## Qué exige esto técnicamente

Para que funcione de verdad, el cálculo debe provenir de los mismos datos del plan clínico. Cada marca de insumo con su costo y precio propio, sumada por sustancia y cantidad real definida punto por punto, no una tabla de precio fijo por "tipo de procedimiento" desconectada de lo que realmente se decidió en esa sesión.

En FacialPlan, el presupuesto de la Etapa 2/3 se arma a partir de la misma arquitectura de insumos y marca usada en el plan de aplicación. Cada punto de aplicación ya lleva su sustancia, marca y cantidad, y el presupuesto profesional, nunca expuesto al paciente ni en el enlace público, se calcula sobre eso, en vivo, sin necesidad de salir de la pantalla de atención hacia otra herramienta.
