import { useCallback, useEffect, useRef, useState } from 'react';
import { useOnlineStatus } from './useOnlineStatus';
import { deleteDraft, getDraft, putDraft } from '@/lib/offlineDb';
import { draftStoreKey, type SessionDraftData } from '@/types/offlineDraft';

const DEFAULT_DEBOUNCE_MS = 800;

type DraftPatch = Partial<Pick<SessionDraftData, 'photoDataUrl' | 'stage1Review' | 'stage2Points'>>;

export interface UseOfflineSessionDraftOptions {
  /** Sessão à qual este rascunho pertence. `undefined` (ainda carregando a
   * rota) desativa o hook inteiro — `draft` fica `null` e `saveDraft` vira
   * no-op, sem tentar abrir o IndexedDB com uma chave inválida. */
  sessionId: string | undefined;
  /**
   * Envia o rascunho pendente pro Supabase. Chamado sempre que a conexão
   * está online E existe um rascunho com `pendingSync` — tanto ao VOLTAR de
   * offline quanto ao montar a página já online com um rascunho deixado por
   * uma sessão de navegador anterior (ver comentário no efeito abaixo).
   * Deve devolver `true` só quando a sincronização foi CONFIRMADA sem erro
   * — só então o rascunho é apagado (`clearDraft`); `false`/rejeição
   * mantém o rascunho intacto para a próxima tentativa (nova reconexão ou
   * nova edição local via `saveDraft`), sem retry automático imediato — ver
   * o comentário do efeito de sincronização.
   *
   * Omitir quando não há nada para reenviar ao servidor (rascunho só de
   * recuperação local, ver `stage1Review` em SessaoEstagio1.tsx) — sem
   * `onSync`, o rascunho só é limpo manualmente via `clearDraft`.
   *
   * Precisa ser estável entre renders (`useCallback`) — o efeito de
   * sincronização o inclui nas dependências, e uma função nova a cada
   * render dispararia uma nova tentativa de sync a cada render enquanto
   * houver rascunho pendente e a conexão estiver online.
   */
  onSync?: (draft: SessionDraftData) => Promise<boolean>;
  /** Atraso do debounce de `saveDraft`, em ms. Default 800 — rápido o
   * suficiente para não perder muito progresso num fechamento abrupto da
   * aba, sem gravar no IndexedDB a cada tecla/toque. */
  debounceMs?: number;
}

export interface UseOfflineSessionDraftResult {
  /** O rascunho local, ou `null` enquanto ainda carrega ou se não há nenhum
   * para esta sessão. */
  draft: SessionDraftData | null;
  /** `true` assim que a leitura inicial do IndexedDB terminou (mesmo sem
   * achar nada) — use para não sobrescrever um rascunho ainda não lido. */
  loaded: boolean;
  hasPendingDraft: boolean;
  isSyncing: boolean;
  /** Mescla `patch` no rascunho atual e agenda a escrita no IndexedDB
   * (debounced) — chamadas repetidas antes do atraso reiniciam o timer, só
   * a última "vence". */
  saveDraft: (patch: DraftPatch) => void;
  /** Apaga o rascunho local imediatamente (sem debounce, cancela qualquer
   * escrita pendente). Chame depois de confirmar que os dados já estão a
   * salvo no Supabase por outro caminho (ex. `handleProceed` da Etapa 1). */
  clearDraft: () => void;
}

/**
 * Rascunho offline de UMA sessão em andamento (ver src/types/offlineDraft.ts
 * para o formato completo e as limitações de escopo — local a um único
 * dispositivo/aba por vez, sem resolução de conflito multi-aba).
 */
export function useOfflineSessionDraft({
  sessionId,
  onSync,
  debounceMs = DEFAULT_DEBOUNCE_MS,
}: UseOfflineSessionDraftOptions): UseOfflineSessionDraftResult {
  const isOnline = useOnlineStatus();
  const [draft, setDraft] = useState<SessionDraftData | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Carrega o rascunho existente (se houver) uma vez por sessionId.
  useEffect(() => {
    let cancelled = false;
    setLoaded(false);
    setDraft(null);
    if (!sessionId) {
      setLoaded(true);
      return;
    }
    getDraft<SessionDraftData>(draftStoreKey(sessionId)).then((found) => {
      if (cancelled) return;
      setDraft(found ?? null);
      setLoaded(true);
    });
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  // Cancela qualquer debounce pendente ao desmontar/trocar de sessão, pra
  // não gravar no IndexedDB depois que o componente que chamou saveDraft já
  // não existe mais (ex. navegação pra outra sessão).
  useEffect(() => {
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [sessionId]);

  const saveDraft = useCallback(
    (patch: DraftPatch) => {
      if (!sessionId) return;
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      debounceTimer.current = setTimeout(() => {
        setDraft((prev) => {
          const next: SessionDraftData = {
            sessionId,
            photoDataUrl: patch.photoDataUrl !== undefined ? patch.photoDataUrl : prev?.photoDataUrl ?? null,
            stage1Review: patch.stage1Review !== undefined ? patch.stage1Review : prev?.stage1Review ?? null,
            stage2Points: patch.stage2Points !== undefined ? patch.stage2Points : prev?.stage2Points ?? null,
            pendingSync: true,
            updatedAt: Date.now(),
          };
          void putDraft(draftStoreKey(sessionId), next);
          return next;
        });
      }, debounceMs);
    },
    [sessionId, debounceMs]
  );

  const clearDraft = useCallback(() => {
    if (!sessionId) return;
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    void deleteDraft(draftStoreKey(sessionId));
    setDraft(null);
  }, [sessionId]);

  // Sincronização automática: dispara sempre que há rascunho pendente E a
  // conexão está online — tanto ao VOLTAR de offline quanto ao montar a
  // página já online com um rascunho deixado por uma sessão de navegador
  // anterior (ex.: o profissional fechou a aba ainda offline e só reabriu
  // depois de a conexão já ter voltado — não há uma transição offline→online
  // para "detectar" nesse caso, então a condição não exige uma). Uma
  // tentativa que falha (`onSync` resolve `false`/rejeita) não é reagendada
  // automaticamente aqui — como `draft` não muda nesse caso, o efeito só
  // roda de novo quando `draft` mudar de novo (nova edição local via
  // `saveDraft`) ou `isOnline` alternar (nova reconexão), evitando uma
  // tempestade de tentativas contra um servidor fora do ar.
  useEffect(() => {
    if (!isOnline || !draft?.pendingSync || !onSync) return;
    let cancelled = false;
    setIsSyncing(true);
    onSync(draft)
      .then((success) => {
        if (!cancelled && success) clearDraft();
      })
      .catch((err) => {
        console.error('[useOfflineSessionDraft] Falha ao sincronizar rascunho:', err);
      })
      .finally(() => {
        if (!cancelled) setIsSyncing(false);
      });
    return () => {
      cancelled = true;
    };
  }, [isOnline, draft, onSync, clearDraft]);

  return {
    draft,
    loaded,
    hasPendingDraft: !!draft?.pendingSync,
    isSyncing,
    saveDraft,
    clearDraft,
  };
}
