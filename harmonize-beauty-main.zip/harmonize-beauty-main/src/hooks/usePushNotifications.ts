import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

/**
 * Estado da inscrição de push notifications do profissional logado neste
 * navegador/dispositivo:
 * - 'unsupported': o navegador não tem as APIs necessárias (Notification,
 *   ServiceWorker, PushManager) — ver LIMITAÇÃO CONHECIDA abaixo.
 * - 'denied': a permissão de notificação foi negada (pelo usuário, ou por
 *   uma política do navegador/SO).
 * - 'enabled': permissão concedida e inscrição ativa salva no Supabase.
 * - 'idle': suportado, mas ainda não ativado neste dispositivo.
 */
export type PushNotificationStatus = 'unsupported' | 'denied' | 'enabled' | 'idle';

interface UsePushNotificationsResult {
  status: PushNotificationStatus;
  /** true enquanto uma operação de ativar/desativar/verificar está em andamento. */
  loading: boolean;
  enable: () => Promise<void>;
  disable: () => Promise<void>;
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

function isPushSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    'serviceWorker' in navigator &&
    'PushManager' in window &&
    'Notification' in window
  );
}

/**
 * Ativa/desativa Web Push para o profissional logado neste navegador.
 *
 * LIMITAÇÃO CONHECIDA (não é bug, é uma restrição da própria Apple): no
 * Safari/iOS, Web Push só funciona com o PWA instalado na tela de início
 * (iOS 16.4+) — dentro de uma aba comum do Safari, `'PushManager' in
 * window` é `false` mesmo nas versões mais recentes do iOS, então `status`
 * fica 'unsupported' até o profissional instalar o app (Compartilhar >
 * Adicionar à Tela de Início). Não há nenhum contorno possível a partir do
 * client para isso — só documentar e orientar o profissional a instalar o
 * app primeiro (ver texto correspondente na UI de ativação).
 */
export function usePushNotifications(): UsePushNotificationsResult {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [status, setStatus] = useState<PushNotificationStatus>('idle');
  const [loading, setLoading] = useState(true);

  const vapidPublicKey = import.meta.env.VITE_VAPID_PUBLIC_KEY as string | undefined;

  const refreshStatus = useCallback(async () => {
    if (!isPushSupported()) {
      setStatus('unsupported');
      setLoading(false);
      return;
    }
    if (Notification.permission === 'denied') {
      setStatus('denied');
      setLoading(false);
      return;
    }
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      const subscription = await registration?.pushManager.getSubscription();
      setStatus(subscription ? 'enabled' : 'idle');
    } catch {
      setStatus('idle');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshStatus();
  }, [refreshStatus]);

  const enable = useCallback(async () => {
    if (!user) return;
    if (!isPushSupported()) {
      toast.error(t('profile.pushNotifications.unsupported'));
      return;
    }
    if (!vapidPublicKey) {
      // Configuração ausente (dev sem VITE_VAPID_PUBLIC_KEY, ou deploy sem
      // essa env var) — é um erro de configuração do app, não algo que o
      // profissional causou; não faz sentido pedir permissão de
      // notificação para em seguida falhar ao inscrever.
      toast.error(t('profile.pushNotifications.misconfigured'));
      return;
    }

    setLoading(true);
    try {
      // Nunca chama requestPermission() de novo por conta própria depois de
      // uma negação anterior: o próprio navegador já recusa reexibir o
      // diálogo nativo nesse caso (devolve 'denied' imediatamente, sem
      // prompt) — então esta chamada nunca "insiste" sozinha, e o botão que
      // dispara `enable()` só aparece quando `status !== 'denied'` (ver
      // PushNotificationsToggle.tsx), evitando incomodar o profissional
      // repetidamente.
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        setStatus(permission === 'denied' ? 'denied' : 'idle');
        toast.error(t('profile.pushNotifications.permissionDenied'));
        return;
      }

      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
      });

      const json = subscription.toJSON();
      const p256dh = json.keys?.p256dh;
      const auth = json.keys?.auth;
      if (!p256dh || !auth) throw new Error('Inscrição de push sem as chaves p256dh/auth esperadas');

      const { error } = await supabase.from('push_subscriptions').upsert(
        {
          professional_id: user.id,
          endpoint: subscription.endpoint,
          p256dh,
          auth,
          user_agent: navigator.userAgent,
        },
        { onConflict: 'endpoint' },
      );
      if (error) throw error;

      setStatus('enabled');
      toast.success(t('profile.pushNotifications.enabled'));
    } catch (err) {
      console.error('usePushNotifications.enable error:', err);
      toast.error(t('profile.pushNotifications.genericError'));
      await refreshStatus();
    } finally {
      setLoading(false);
    }
  }, [user, vapidPublicKey, t, refreshStatus]);

  const disable = useCallback(async () => {
    setLoading(true);
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      const subscription = await registration?.pushManager.getSubscription();
      if (subscription) {
        const endpoint = subscription.endpoint;
        await subscription.unsubscribe();
        await supabase.from('push_subscriptions').delete().eq('endpoint', endpoint);
      }
      setStatus('idle');
      toast.success(t('profile.pushNotifications.disabled'));
    } catch (err) {
      console.error('usePushNotifications.disable error:', err);
      toast.error(t('profile.pushNotifications.genericError'));
    } finally {
      setLoading(false);
    }
  }, [t]);

  return { status, loading, enable, disable };
}
