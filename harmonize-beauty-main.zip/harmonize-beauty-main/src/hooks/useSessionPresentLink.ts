import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import { buildPresentLink } from '@/lib/presentLink';

/**
 * Public, no-login link to the session's result-presentation screen
 * (/present/:token — see SessaoPresentPublico.tsx and the
 * public-session-presentation edge function). Same insert-your-own-row
 * pattern as useSendAnamnesisLink, adapted for a link that's revisitable
 * (the patient may reopen it to review the result) and revocable — unlike
 * an anamnesis link, this one has no single-use "used_at": the professional
 * turns it off with `revoked_at` instead, and a session can accumulate
 * revoked rows over time as a link gets regenerated.
 */
export function useSessionPresentLink(sessionId: string | undefined) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  /**
   * A busca do token ativo, guardada como promessa.
   *
   * O estado `token` só existe depois que essa busca resolve, e os botões
   * da tela já estão clicáveis antes disso. Sem a promessa, `ensureLink()`
   * lia `token === null` durante a janela de carregamento e criava uma
   * SEGUNDA linha ativa para a mesma sessão — e, pior, a busca de montagem
   * resolvia depois e sobrescrevia o estado com o token ANTIGO. O link que
   * o paciente recebeu (o novo) passava a não ser o que o hook rastreia,
   * então "Desativar link" revogava o outro e o acesso público continuava
   * de pé sem nada na tela indicando isso.
   *
   * Achado do ciclo 67 do QA Contínuo.
   */
  const pendingLoadRef = useRef<Promise<string | null> | null>(null);
  /** Chamada de `ensureLink` em voo, compartilhada entre cliques simultâneos. */
  const pendingEnsureRef = useRef<Promise<string | null> | null>(null);

  useEffect(() => {
    if (!sessionId) {
      pendingLoadRef.current = null;
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    const load = (async () => {
      const { data } = await supabase
        .from('session_present_links')
        .select('token')
        .eq('session_id', sessionId)
        .is('revoked_at', null)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      return (data?.token as string | undefined) ?? null;
    })();
    pendingLoadRef.current = load;
    void load.then(
      (found) => {
        if (active) {
          setToken(found);
          setLoading(false);
        }
      },
      () => {
        if (active) setLoading(false);
      },
    );
    return () => {
      active = false;
    };
  }, [sessionId]);

  const logFailure = useCallback((error_type: string, message: string) => {
    if (!user) return;
    logClientError({
      professionalId: user.id,
      stage: 'present',
      errorType: error_type,
      message,
    });
  }, [user]);

  const ensureLink = useCallback(async (): Promise<string | null> => {
    if (!sessionId || !user) return null;
    if (token) return buildPresentLink(window.location.origin, token);
    // Espera a busca de montagem antes de concluir que não existe link. Um
    // clique imediato (ou a geração do QR do PDF em SessaoEstagio3) chega
    // aqui antes de `token` estar preenchido, e criar um segundo link ativo
    // deixaria um acesso público fora do alcance de "Desativar link".
    const pendingLoad = pendingLoadRef.current;
    if (pendingLoad) {
      const existing = await pendingLoad.catch(() => null);
      if (existing) return buildPresentLink(window.location.origin, existing);
    }
    // Duas ações disparadas juntas (copiar e mandar no WhatsApp) também
    // criariam duas linhas; a segunda reaproveita a primeira.
    const inFlight = pendingEnsureRef.current;
    if (inFlight) return inFlight;
    setBusy(true);
    const run = (async () => {
      try {
        const { data, error } = await supabase
          .from('session_present_links')
          .insert({ session_id: sessionId, professional_id: user.id })
          .select('token')
          .single();
        if (error || !data) throw error ?? new Error('token ausente');
        setToken(data.token);
        return buildPresentLink(window.location.origin, data.token);
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : t('sessions.present.publicLink.errorGenerating');
        toast.error(message);
        console.error('[useSessionPresentLink] Falha ao gerar link:', err);
        logFailure('present_link_generation_failed', message);
        return null;
      } finally {
        setBusy(false);
        pendingEnsureRef.current = null;
      }
    })();
    pendingEnsureRef.current = run;
    return run;
  }, [sessionId, user, token, t, logFailure]);

  const copyLink = useCallback(async () => {
    const link = await ensureLink();
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      toast.success(t('sessions.present.publicLink.copiedToast'));
    } catch {
      toast.info(link);
    }
  }, [ensureLink, t]);

  const sendWhatsApp = useCallback(async () => {
    const link = await ensureLink();
    const message = link
      ? t('sessions.present.publicLink.whatsAppMessage', { link })
      : t('sessions.present.whatsAppMessage');
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  }, [ensureLink, t]);

  const disableLink = useCallback(async () => {
    if (!sessionId || !token) return;
    setBusy(true);
    try {
      // Revoga por sessão, não pelo token em estado: se uma linha órfã
      // chegar a existir (versão anterior do app, duas abas abertas), ela
      // também é desligada aqui. "Desativar link" tem que significar
      // "ninguém mais vê isso", e não "desliguei o que eu estava
      // rastreando".
      const { error } = await supabase
        .from('session_present_links')
        .update({ revoked_at: new Date().toISOString() })
        .eq('session_id', sessionId)
        .is('revoked_at', null);
      if (error) throw error;
      setToken(null);
      toast.success(t('sessions.present.publicLink.disabledToast'));
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('sessions.present.publicLink.errorDisabling');
      toast.error(message);
      logFailure('present_link_revoke_failed', message);
    } finally {
      setBusy(false);
    }
  }, [sessionId, token, t, logFailure]);

  // `ensureLink` já existia internamente (usado por copyLink/sendWhatsApp)
  // mas nunca era exposto — exportado aqui pra que outro consumidor (ex.: o
  // QR code de verificação do PDF em SessaoEstagio3.tsx) possa obter/criar a
  // mesma URL pública sem herdar o efeito colateral de copiar pro
  // clipboard ou abrir o WhatsApp.
  return { token, loading, busy, ensureLink, copyLink, sendWhatsApp, disableLink };
}
