import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useMinisiteLink } from './useMinisiteLink';

/**
 * Regressão do ciclo 67 do QA Contínuo — a variante destrutiva.
 *
 * `ensureLink()` GRAVA `profiles.minisite_slug` quando não encontra um, e o
 * botão de copiar já está clicável antes de a leitura de montagem resolver.
 * Enquanto ela não chegava, um clique imediato sobrescrevia o slug que o
 * profissional escolheu e já distribuiu (cartão, bio, anúncio) por um
 * aleatório — e o toast de sucesso ainda mostrava a URL nova, sem nada
 * indicando que os links antigos tinham acabado de morrer.
 */

type Deferred<T> = { promise: Promise<T>; resolve: (value: T) => void };
function deferred<T>(): Deferred<T> {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => { resolve = r; });
  return { promise, resolve };
}

type ProfileRow = { minisite_slug: string | null; clinic_name: string | null; full_name: string | null };

const updates: Array<Record<string, unknown>> = [];
let mountSelect: Deferred<{ data: ProfileRow | null }>;

function makeBuilder() {
  let payload: Record<string, unknown> | null = null;
  const builder: Record<string, unknown> = {};
  const chain = () => builder;
  Object.assign(builder, {
    select: chain,
    eq: chain,
    update: (next: Record<string, unknown>) => { payload = next; updates.push(next); return builder; },
    maybeSingle: () => mountSelect.promise,
    single: () => Promise.resolve({ data: { minisite_slug: payload?.minisite_slug ?? null }, error: null }),
    then: (onOk: (v: unknown) => unknown) => Promise.resolve({ error: null }).then(onOk),
  });
  return builder;
}

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: () => makeBuilder() },
}));

// Objeto estável: o efeito do hook depende de `user`, e um objeto novo a
// cada render faria o efeito reexecutar em laço (no app real o contexto
// devolve sempre a mesma referência).
const AUTH = { user: { id: 'prof-1' } };
vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => AUTH,
}));

vi.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() },
}));

describe('useMinisiteLink', () => {
  beforeEach(() => {
    updates.length = 0;
    mountSelect = deferred();
  });

  it('não sobrescreve um slug existente quando a leitura ainda não chegou', async () => {
    const { result } = renderHook(() => useMinisiteLink());

    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: { minisite_slug: 'clinica-sol', clinic_name: 'Clínica Sol', full_name: null } });
      link = await pending;
    });

    expect(link).toContain('clinica-sol');
    expect(updates).toHaveLength(0);
  });

  it('gera um slug quando o profissional realmente não tem nenhum', async () => {
    const { result } = renderHook(() => useMinisiteLink());

    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: { minisite_slug: null, clinic_name: 'Clínica Sol', full_name: null } });
      link = await pending;
    });

    expect(updates).toHaveLength(1);
    expect(link).toBeTruthy();
  });

  it('dois cliques simultâneos geram um único slug', async () => {
    const { result } = renderHook(() => useMinisiteLink());

    await act(async () => {
      const a = result.current.ensureLink();
      const b = result.current.ensureLink();
      mountSelect.resolve({ data: { minisite_slug: null, clinic_name: null, full_name: 'Ana' } });
      await Promise.all([a, b]);
    });

    expect(updates).toHaveLength(1);
  });
});
