import { useEffect } from 'react';

/**
 * Define `document.title` e as meta tags de descrição/Open Graph (`og:title`,
 * `og:description`, `og:image`) via `useEffect`, restaurando o valor
 * anterior ao desmontar. Feito pra páginas públicas com dado por-entidade
 * (hoje: o Mini-site de Captação, `Minisite.tsx`) que precisam de um
 * `<title>`/preview diferente do genérico do `index.html`.
 *
 * --- Limitação real: isto NÃO corrige o preview de link no WhatsApp -----
 *
 * Esta é uma SPA sem SSR. As tags que este hook escreve só existem depois
 * que o JavaScript roda no navegador. WhatsApp, Instagram, Facebook e a
 * maioria dos crawlers de preview de link NÃO executam JavaScript — eles
 * leem só o HTML estático inicial (o `index.html` servido antes do bundle
 * rodar), que sempre traz o `<title>`/meta genéricos do app. Ou seja:
 * quando um profissional compartilha `/m/:slug` no WhatsApp pra captar
 * lead, o preview do link continua vindo genérico mesmo com este hook.
 *
 * O que este hook resolve: o título da aba do navegador pra quem já abriu a
 * página, e qualquer plataforma que eventualmente renderize JS antes de ler
 * as tags (nem todo crawler é tão simples quanto o do WhatsApp).
 *
 * O que resolveria de verdade: pré-renderização no edge — detectar o
 * User-Agent de bots de preview (WhatsApp/Facebook/Instagram/Twitter) numa
 * Vercel Edge Middleware ou Serverless Function com rewrite condicional, e
 * servir ali um HTML estático já com as tags corretas por profissional,
 * antes do JS rodar. Isso NÃO foi implementado agora porque depende de
 * configuração específica do Vercel (Edge Middleware + rewrite por
 * User-Agent) que não dá pra testar de ponta a ponta neste ambiente — sem
 * acesso a um deploy real do projeto no Vercel nem a um simulador de
 * crawler do WhatsApp/Meta pra validar o resultado. Fica registrado aqui
 * como item de arquitetura futura (documentado como entrega futura em vez
 * de forçado numa squad menor do que o item realmente exige). Próximos passos, quando
 * houver acesso a deploy real pra testar: (1) Edge Middleware no Vercel que
 * inspeciona `User-Agent` em `/m/:slug`; (2) pra bots conhecidos, buscar os
 * dados do profissional (mesma edge function `public-minisite` já usada
 * aqui) e responder com HTML estático contendo as tags; (3) pra navegadores
 * normais, deixar passar pro SPA normalmente; (4) validar com o Sharing
 * Debugger do Facebook/Meta e o simulador de link do WhatsApp Business.
 */
export interface DocumentMetaOptions {
  /** `document.title` e, por padrão, também o `og:title`. */
  title?: string | null;
  /** `<meta name="description">` e, por padrão, também o `og:description`. */
  description?: string | null;
  /** `og:title` explícito, quando precisa divergir do `title` acima. */
  ogTitle?: string | null;
  /** `og:description` explícito, quando precisa divergir da `description` acima. */
  ogDescription?: string | null;
  /** `og:image` — só é escrito quando uma URL é informada. */
  ogImage?: string | null;
}

type Restorer = () => void;

function applyMetaTag(attr: 'name' | 'property', key: string, content: string | null | undefined): Restorer | null {
  if (!content) return null;

  const selector = `meta[${attr}="${key}"]`;
  const existing = document.head.querySelector<HTMLMetaElement>(selector);

  if (existing) {
    const previousContent = existing.getAttribute('content');
    existing.setAttribute('content', content);
    return () => {
      if (previousContent === null) existing.removeAttribute('content');
      else existing.setAttribute('content', previousContent);
    };
  }

  const created = document.createElement('meta');
  created.setAttribute(attr, key);
  created.setAttribute('content', content);
  document.head.appendChild(created);
  return () => created.remove();
}

export function useDocumentMeta({ title, description, ogTitle, ogDescription, ogImage }: DocumentMetaOptions): void {
  useEffect(() => {
    const previousTitle = document.title;
    if (title) document.title = title;

    const restorers: Restorer[] = [];
    const track = (restorer: Restorer | null) => {
      if (restorer) restorers.push(restorer);
    };

    track(applyMetaTag('name', 'description', description));
    track(applyMetaTag('property', 'og:title', ogTitle ?? title));
    track(applyMetaTag('property', 'og:description', ogDescription ?? description));
    track(applyMetaTag('property', 'og:image', ogImage));

    return () => {
      document.title = previousTitle;
      restorers.forEach((restore) => restore());
    };
  }, [title, description, ogTitle, ogDescription, ogImage]);
}
