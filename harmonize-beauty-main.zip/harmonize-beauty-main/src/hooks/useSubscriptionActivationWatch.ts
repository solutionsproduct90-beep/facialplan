import { useCallback, useEffect, useRef, useState } from 'react';

import { useAuth } from '@/contexts/AuthContext';
import { hasAppAccess } from '@/lib/subscriptionAccess';

/**
 * Espera pela liberação do acesso depois do checkout.
 *
 * O PROBLEMA: o checkout da Hotmart abre em outra aba. Quem paga volta para a
 * aba do FacialPlan e continua vendo o paywall, porque o perfil no cliente foi
 * lido uma vez, no login, e ninguém releu. O banco já está certo — o webhook
 * virou `subscription_status` para 'active' segundos depois do pagamento —
 * mas a tela não sabe. Do lado de quem pagou, isso é indistinguível de "o
 * pagamento não funcionou", e o próximo passo natural é pedir estorno ou
 * abrir chamado no suporte.
 *
 * A ESPERA É ESCALONADA, NÃO UM POLLING FIXO: o webhook costuma chegar em
 * poucos segundos, mas pode demorar (retentativa da Hotmart, fila). Uma
 * tentativa só perde o caso lento; um polling de 2 em 2 segundos por minutos
 * castiga o banco à toa para todo mundo que passa por aqui. O escalonamento
 * cobre os dois: resposta quase imediata no caso comum, e ainda assim uma
 * janela de ~um minuto para o caso lento, com 5 leituras no total.
 *
 * O gatilho é a volta para a aba (`visibilitychange`/`focus`), e não um
 * intervalo que roda sozinho: antes de voltar, não há o que verificar.
 */
export const ACTIVATION_RETRY_DELAYS_MS: readonly number[] = [0, 3_000, 8_000, 15_000, 30_000];

export type ActivationWatchStatus =
  /** Nada em curso — estado inicial e depois de desistir. */
  | 'idle'
  /** Uma sequência de leituras está rodando. */
  | 'checking'
  /** O perfil voltou com acesso liberado. */
  | 'activated'
  /** A sequência terminou e o acesso continua bloqueado. */
  | 'not_yet';

export interface SubscriptionActivationWatch {
  status: ActivationWatchStatus;
  /** Qual leitura da sequência está em curso (1-based, 0 quando parado). */
  attempt: number;
  /** Total de leituras que a sequência faz — para exibir "2 de 5". */
  totalAttempts: number;
  /** Dispara a sequência agora. Resolve com `true` se o acesso foi liberado. */
  check: () => Promise<boolean>;
  /** Marca que houve ida ao checkout: a próxima volta para a aba dispara `check`. */
  armOnReturn: () => void;
}

export function useSubscriptionActivationWatch(
  delays: readonly number[] = ACTIVATION_RETRY_DELAYS_MS,
): SubscriptionActivationWatch {
  const { refreshProfile } = useAuth();
  const [status, setStatus] = useState<ActivationWatchStatus>('idle');
  const [attempt, setAttempt] = useState(0);

  // Contador de geração: desmontar ou começar uma sequência nova invalida a
  // anterior. Mesmo padrão do carregamento de perfil no AuthContext — uma
  // sequência abandonada não pode escrever estado por cima da atual.
  const runRef = useRef(0);
  const runningRef = useRef(false);
  const armedRef = useRef(false);

  // Encerra a espera em curso RESOLVENDO a Promise, e não só limpando o
  // timer: um `clearTimeout` seco deixaria a sequência abandonada pendurada
  // para sempre num `await` que nunca resolve. Quem acorda confere o
  // contador de geração e sai.
  const wakeSleepRef = useRef<(() => void) | null>(null);

  const sleep = useCallback((ms: number) => {
    return new Promise<void>((resolve) => {
      const timeoutId = setTimeout(() => {
        wakeSleepRef.current = null;
        resolve();
      }, ms);
      wakeSleepRef.current = () => {
        clearTimeout(timeoutId);
        wakeSleepRef.current = null;
        resolve();
      };
    });
  }, []);

  useEffect(() => {
    return () => {
      runRef.current += 1;
      runningRef.current = false;
      wakeSleepRef.current?.();
    };
  }, []);

  const check = useCallback(async (): Promise<boolean> => {
    // Acorda a sequência anterior (se houver) antes de tomar o lugar dela,
    // para que ela saia do `await` na hora em vez de esperar o próprio timer.
    wakeSleepRef.current?.();
    const runId = ++runRef.current;
    runningRef.current = true;
    armedRef.current = false;
    setStatus('checking');
    setAttempt(0);

    try {
      for (let index = 0; index < delays.length; index += 1) {
        const delay = delays[index];
        if (delay > 0) {
          await sleep(delay);
          if (runId !== runRef.current) return false;
        }

        setAttempt(index + 1);
        const profile = await refreshProfile();
        if (runId !== runRef.current) return false;

        if (hasAppAccess(profile)) {
          setStatus('activated');
          return true;
        }
      }

      setStatus('not_yet');
      return false;
    } finally {
      if (runId === runRef.current) runningRef.current = false;
    }
  }, [delays, refreshProfile, sleep]);

  const armOnReturn = useCallback(() => {
    armedRef.current = true;
  }, []);

  useEffect(() => {
    const onReturn = () => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      if (!armedRef.current || runningRef.current) return;
      void check();
    };

    // Voltar de outra aba dispara `visibilitychange`; voltar de outra janela
    // (ou de um app, no celular) pode disparar só `focus`. Os dois chamam o
    // mesmo caminho, e `runningRef` impede que a dupla notificação reinicie
    // uma sequência já em curso.
    document.addEventListener('visibilitychange', onReturn);
    window.addEventListener('focus', onReturn);
    return () => {
      document.removeEventListener('visibilitychange', onReturn);
      window.removeEventListener('focus', onReturn);
    };
  }, [check]);

  return { status, attempt, totalAttempts: delays.length, check, armOnReturn };
}
