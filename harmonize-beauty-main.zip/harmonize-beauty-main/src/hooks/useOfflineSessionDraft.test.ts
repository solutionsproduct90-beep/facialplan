import "fake-indexeddb/auto";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { renderHook, waitFor, act } from "@testing-library/react";
import { useOfflineSessionDraft } from "./useOfflineSessionDraft";
import { getDraft, putDraft, __resetOfflineDbForTests } from "@/lib/offlineDb";
import { draftStoreKey, type SessionDraftData } from "@/types/offlineDraft";

// `useOnlineStatus` mockado (não o `navigator.onLine`/eventos reais) — os
// testes controlam a conectividade diretamente trocando o valor devolvido
// aqui, o que é bem mais direto do que disparar eventos `online`/`offline`
// de verdade na `window` para exercer o efeito de sincronização abaixo.
const onlineStatusMock = vi.fn(() => true);
vi.mock("./useOnlineStatus", () => ({
  useOnlineStatus: () => onlineStatusMock(),
}));

// Debounce bem curto nos testes — evita esperar os 800ms default a cada
// asserção sem perder a cobertura do comportamento "debounced" em si (ver
// teste "agrupa chamadas seguidas...' abaixo).
const DEBOUNCE_MS = 15;

describe("useOfflineSessionDraft", () => {
  beforeEach(() => {
    __resetOfflineDbForTests();
    onlineStatusMock.mockReturnValue(true);
  });

  it("começa sem rascunho e marca `loaded` assim que a leitura inicial termina", async () => {
    const { result } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-initial-empty", debounceMs: DEBOUNCE_MS })
    );
    expect(result.current.draft).toBeNull();
    await waitFor(() => expect(result.current.loaded).toBe(true));
    expect(result.current.draft).toBeNull();
    expect(result.current.hasPendingDraft).toBe(false);
  });

  it("salva um rascunho (debounced) e o persiste no IndexedDB", async () => {
    const { result } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-save-basic", debounceMs: DEBOUNCE_MS })
    );
    await waitFor(() => expect(result.current.loaded).toBe(true));

    act(() => {
      result.current.saveDraft({ stage2Points: [{ id: "p1" } as never] });
    });

    // Antes do debounce disparar, nada deveria ter sido escrito ainda.
    expect(result.current.hasPendingDraft).toBe(false);

    await waitFor(() => expect(result.current.hasPendingDraft).toBe(true));
    expect(result.current.draft?.stage2Points).toEqual([{ id: "p1" }]);
    expect(result.current.draft?.pendingSync).toBe(true);

    const persisted = await getDraft<SessionDraftData>(draftStoreKey("test-save-basic"));
    expect(persisted?.stage2Points).toEqual([{ id: "p1" }]);
  });

  it("agrupa chamadas seguidas de saveDraft antes do debounce — só a última mescla vence", async () => {
    const { result } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-debounce-merge", debounceMs: DEBOUNCE_MS })
    );
    await waitFor(() => expect(result.current.loaded).toBe(true));

    act(() => {
      result.current.saveDraft({ photoDataUrl: "data:v1" });
      result.current.saveDraft({ photoDataUrl: "data:v2" });
    });

    await waitFor(() => expect(result.current.hasPendingDraft).toBe(true));
    expect(result.current.draft?.photoDataUrl).toBe("data:v2");
  });

  it("recupera um rascunho já salvo ao montar (reload da página)", async () => {
    const existing: SessionDraftData = {
      sessionId: "test-recover-mount",
      stage2Points: [{ id: "recovered" } as never],
      photoDataUrl: null,
      stage1Review: null,
      pendingSync: true,
      updatedAt: Date.now(),
    };
    await putDraft(draftStoreKey("test-recover-mount"), existing);

    const { result } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-recover-mount", debounceMs: DEBOUNCE_MS })
    );

    await waitFor(() => expect(result.current.loaded).toBe(true));
    expect(result.current.draft?.stage2Points).toEqual([{ id: "recovered" }]);
    expect(result.current.hasPendingDraft).toBe(true);
  });

  it("não sincroniza enquanto offline, mesmo com rascunho pendente", async () => {
    onlineStatusMock.mockReturnValue(false);
    const onSync = vi.fn(async () => true);
    const { result, rerender } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-offline-no-sync", debounceMs: DEBOUNCE_MS, onSync })
    );
    await waitFor(() => expect(result.current.loaded).toBe(true));

    act(() => {
      result.current.saveDraft({ stage2Points: [{ id: "p1" } as never] });
    });
    await waitFor(() => expect(result.current.hasPendingDraft).toBe(true));

    rerender();
    expect(onSync).not.toHaveBeenCalled();
  });

  it("sincroniza automaticamente quando a conexão volta e limpa o rascunho após sucesso", async () => {
    onlineStatusMock.mockReturnValue(false);
    const onSync = vi.fn(async () => true);
    const { result, rerender } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-sync-on-reconnect", debounceMs: DEBOUNCE_MS, onSync })
    );
    await waitFor(() => expect(result.current.loaded).toBe(true));

    act(() => {
      result.current.saveDraft({ stage2Points: [{ id: "p1" } as never] });
    });
    await waitFor(() => expect(result.current.hasPendingDraft).toBe(true));
    expect(onSync).not.toHaveBeenCalled();

    // Conexão volta — a própria mudança do valor mockado não re-renderiza o
    // hook sozinha (não é estado React), por isso o `rerender()` explícito.
    onlineStatusMock.mockReturnValue(true);
    rerender();

    await waitFor(() => expect(onSync).toHaveBeenCalledTimes(1));
    expect(onSync).toHaveBeenCalledWith(
      expect.objectContaining({ stage2Points: [{ id: "p1" }] })
    );

    // Sync confirmado → o rascunho local inteiro é apagado, não só marcado.
    await waitFor(() => expect(result.current.draft).toBeNull());
    expect(result.current.hasPendingDraft).toBe(false);
    const persisted = await getDraft<SessionDraftData>(draftStoreKey("test-sync-on-reconnect"));
    expect(persisted).toBeUndefined();
  });

  it("mantém o rascunho quando a sincronização falha", async () => {
    const onSync = vi.fn(async () => false);
    const { result } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-sync-fail", debounceMs: DEBOUNCE_MS, onSync })
    );
    await waitFor(() => expect(result.current.loaded).toBe(true));

    act(() => {
      result.current.saveDraft({ stage2Points: [{ id: "p1" } as never] });
    });

    await waitFor(() => expect(onSync).toHaveBeenCalledTimes(1));
    // `onSync` resolveu `false` — o rascunho permanece pendente.
    expect(result.current.hasPendingDraft).toBe(true);
    const persisted = await getDraft<SessionDraftData>(draftStoreKey("test-sync-fail"));
    expect(persisted?.stage2Points).toEqual([{ id: "p1" }]);
  });

  it("clearDraft apaga o rascunho imediatamente, sem esperar o debounce", async () => {
    const { result } = renderHook(() =>
      useOfflineSessionDraft({ sessionId: "test-clear-immediate", debounceMs: 5000 })
    );
    await waitFor(() => expect(result.current.loaded).toBe(true));

    act(() => {
      result.current.saveDraft({ stage2Points: [{ id: "p1" } as never] });
      result.current.clearDraft();
    });

    expect(result.current.draft).toBeNull();
    const persisted = await getDraft<SessionDraftData>(draftStoreKey("test-clear-immediate"));
    expect(persisted).toBeUndefined();
  });
});
