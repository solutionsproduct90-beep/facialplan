import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import { buildFeedbackLink } from '@/lib/feedbackLink';

/**
 * Public, no-login link to the patient-feedback/NPS screen (/feedback/:token
 * — see DepoimentoPublico.tsx and the public-patient-feedback edge
 * function). Same insert-your-own-row pattern as useSessionPresentLink, but
 * for a single-use token (`used_at`, not `revoked_at` — see the comment on
 * `patient_feedback_links` in the migration for why): once the patient has
 * answered, there's nothing left to copy/send, so `token` goes back to
 * `null` and the UI falls back to the "not answered yet" state.
 */
export function useSessionFeedbackLink(sessionId: string | undefined) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [token, setToken] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  /**
   * Mesma trava do useSessionPresentLink (achado do ciclo 67 do QA
   * Contínuo): o botão de copiar já está clicável antes de a busca de
   * montagem resolver, e sem esperar por ela `ensureLink()` criava um
   * segundo link para a mesma sessão. Aqui o link é de uso único, então o
   * efeito é um token extra em aberto — o paciente podia responder por um
   * link enquanto a tela já contava a resposta do outro.
   */
  const pendingLoadRef = useRef<Promise<string | null> | null>(null);
  /** Chamada de `ensureLink` em voo, compartilhada entre cliques simultâneos. */
  const pendingEnsureRef = useRef<Promise<string | null> | null>(null);

  useEffect(() => {
    if (!sessionId) {
      pendingLoadRef.current = null;
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    const load = (async () => {
      const { data } = await supabase
        .from('patient_feedback_links')
        .select('token, used_at')
        .eq('session_id', sessionId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (active) setAnswered(Boolean(data?.used_at));
      return data && !data.used_at ? (data.token as string) : null;
    })();
    pendingLoadRef.current = load;
    void load.then(
      (usable) => {
        if (active) {
          setToken(usable);
          setLoading(false);
        }
      },
      () => {
        if (active) setLoading(false);
      },
    );
    return () => {
      active = false;
    };
  }, [sessionId]);

  const logFailure = useCallback((error_type: string, message: string) => {
    if (!user) return;
    logClientError({
      professionalId: user.id,
      stage: 'feedback',
      errorType: error_type,
      message,
    });
  }, [user]);

  const ensureLink = useCallback(async (): Promise<string | null> => {
    if (!sessionId || !user) return null;
    if (token) return buildFeedbackLink(window.location.origin, token);
    // Espera a busca de montagem antes de concluir que não existe link.
    const pendingLoad = pendingLoadRef.current;
    if (pendingLoad) {
      const existing = await pendingLoad.catch(() => null);
      if (existing) return buildFeedbackLink(window.location.origin, existing);
    }
    const inFlight = pendingEnsureRef.current;
    if (inFlight) return inFlight;
    setBusy(true);
    const run = (async () => {
      try {
        const { data, error } = await supabase
          .from('patient_feedback_links')
          .insert({ session_id: sessionId, professional_id: user.id })
          .select('token')
          .single();
        if (error || !data) throw error ?? new Error('token ausente');
        setToken(data.token);
        return buildFeedbackLink(window.location.origin, data.token);
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : t('sessions.feedback.publicLink.errorGenerating');
        toast.error(message);
        console.error('[useSessionFeedbackLink] Falha ao gerar link:', err);
        logFailure('feedback_link_generation_failed', message);
        return null;
      } finally {
        setBusy(false);
        pendingEnsureRef.current = null;
      }
    })();
    pendingEnsureRef.current = run;
    return run;
  }, [sessionId, user, token, t, logFailure]);

  const copyLink = useCallback(async () => {
    const link = await ensureLink();
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      toast.success(t('sessions.feedback.publicLink.copiedToast'));
    } catch {
      toast.info(link);
    }
  }, [ensureLink, t]);

  const sendWhatsApp = useCallback(async () => {
    const link = await ensureLink();
    if (!link) return;
    window.open(`https://wa.me/?text=${encodeURIComponent(t('sessions.feedback.publicLink.whatsAppMessage', { link }))}`, '_blank');
  }, [ensureLink, t]);

  return { token, answered, loading, busy, ensureLink, copyLink, sendWhatsApp };
}
