import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ALL_QUESTION_KEYS } from '@/types/anamnesis';

/**
 * Perguntas do histórico do paciente que este profissional desabilitou
 * explicitamente (ver /perfil/anamnese — PerfilAnamnese.tsx). Ausência de
 * linha == pergunta habilitada (opt-out, não opt-in): um profissional que
 * nunca abriu as configurações continua vendo as 18 perguntas padrão.
 */
export function useDisabledAnamnesisQuestionKeys(professionalId: string | null | undefined) {
  return useQuery({
    queryKey: ['anamnesis-question-settings', professionalId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('anamnesis_question_settings')
        .select('question_key, enabled')
        .eq('professional_id', professionalId!);
      if (error) throw error;
      return new Set((data ?? []).filter((r) => r.enabled === false).map((r) => r.question_key));
    },
    enabled: !!professionalId,
  });
}

/**
 * Conjunto de chaves habilitadas (todas as 18, menos as desabilitadas) para
 * este profissional — pronto para passar a `AnamnesisRiskFields` /
 * `AnamnesisPatientAnswers` como `enabledKeys`. Enquanto carrega (ou se o
 * profissional ainda não existe), retorna `undefined` — os componentes
 * tratam isso como "mostrar todas", nunca escondendo uma resposta por
 * engano antes das configurações carregarem.
 */
export function useEnabledAnamnesisQuestionKeys(professionalId: string | null | undefined) {
  const { data: disabledKeys, isLoading } = useDisabledAnamnesisQuestionKeys(professionalId);
  if (isLoading || !disabledKeys) return undefined;
  if (disabledKeys.size === 0) return undefined;
  return new Set(ALL_QUESTION_KEYS.filter((key) => !disabledKeys.has(key)));
}
