import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { buildMinisiteLink, buildAutoSlugCandidate, isValidMinisiteSlug } from '@/lib/minisiteLink';

// Postgres unique_violation — see https://www.postgresql.org/docs/current/errcodes-appendix.html
const UNIQUE_VIOLATION = '23505';
const MAX_AUTO_GENERATE_ATTEMPTS = 5;

/**
 * Public, no-login link to the professional's minisite/lead-capture landing
 * page (/m/:slug — see Minisite.tsx and the public-minisite edge function).
 * Unlike useSessionPresentLink (a fresh UUID token per session), this reads
 * and writes a single column on the professional's own profile row
 * (`profiles.minisite_slug`) — the link is a stable identity, not something
 * regenerated per patient.
 */
export function useMinisiteLink() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [slug, setSlug] = useState<string | null>(null);
  const [nameHint, setNameHint] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  /**
   * A leitura do slug atual, guardada como promessa.
   *
   * Aqui isso é mais grave do que nos outros links públicos (mesma classe
   * do achado do ciclo 67 do QA Contínuo). `ensureLink()` GRAVA o slug
   * quando não encontra um, e o botão de copiar já está clicável antes de
   * a leitura de montagem resolver. Sem esperar por ela, um clique imediato
   * fazia um `UPDATE profiles SET minisite_slug = <aleatório>` por cima de
   * um slug que o profissional escolheu e já distribuiu — cartão, bio do
   * Instagram, anúncio — e todo link antigo passava a não achar ninguém,
   * com um toast de sucesso mostrando a URL nova.
   */
  const pendingLoadRef = useRef<Promise<string | null> | null>(null);
  /** Chamada de `ensureLink` em voo, compartilhada entre cliques simultâneos. */
  const pendingEnsureRef = useRef<Promise<string | null> | null>(null);

  useEffect(() => {
    if (!user) {
      pendingLoadRef.current = null;
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    const load = (async () => {
      const { data } = await supabase
        .from('profiles')
        .select('minisite_slug, clinic_name, full_name')
        .eq('id', user.id)
        .maybeSingle();
      if (active) setNameHint(data?.clinic_name || data?.full_name || null);
      return (data?.minisite_slug as string | undefined) ?? null;
    })();
    pendingLoadRef.current = load;
    void load.then(
      (found) => {
        if (active) {
          setSlug(found);
          setLoading(false);
        }
      },
      () => {
        if (active) setLoading(false);
      },
    );
    return () => {
      active = false;
    };
  }, [user]);

  /**
   * Returns the current slug's link, or generates one automatically (from
   * the clinic/professional name + a random suffix) on first use. Retries
   * with a fresh suffix a few times if the candidate collides with another
   * professional's slug (unique_violation) — cheaper than checking
   * availability up front for what should be a rare collision.
   */
  const ensureLink = useCallback(async (): Promise<string | null> => {
    if (!user) return null;
    if (slug) return buildMinisiteLink(window.location.origin, slug);
    // Nunca gerar um slug por cima de um existente só porque a leitura de
    // montagem ainda não chegou: esperar por ela é o que impede a gravação
    // destrutiva descrita em pendingLoadRef.
    const pendingLoad = pendingLoadRef.current;
    if (pendingLoad) {
      const existing = await pendingLoad.catch(() => null);
      if (existing) return buildMinisiteLink(window.location.origin, existing);
    }
    const inFlight = pendingEnsureRef.current;
    if (inFlight) return inFlight;

    setBusy(true);
    const run = (async () => {
      try {
        for (let attempt = 0; attempt < MAX_AUTO_GENERATE_ATTEMPTS; attempt++) {
          const candidate = buildAutoSlugCandidate(nameHint);
          const { data, error } = await supabase
            .from('profiles')
            .update({ minisite_slug: candidate })
            .eq('id', user.id)
            .select('minisite_slug')
            .single();

          if (!error && data?.minisite_slug) {
            setSlug(data.minisite_slug);
            return buildMinisiteLink(window.location.origin, data.minisite_slug);
          }
          if (error && error.code !== UNIQUE_VIOLATION) throw error;
          // unique_violation — loop again with a new random suffix.
        }
        throw new Error('slug_generation_exhausted');
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : t('minisite.link.errorGenerating');
        toast.error(t('minisite.link.errorGenerating'));
        console.error('[useMinisiteLink] Falha ao gerar slug:', message);
        return null;
      } finally {
        setBusy(false);
        pendingEnsureRef.current = null;
      }
    })();
    pendingEnsureRef.current = run;
    return run;
  }, [user, slug, nameHint, t]);

  /**
   * Lets the professional set/change their own slug to a custom, memorable
   * value (e.g. for a business card or Instagram bio). Validates the shape
   * client-side first (see isValidMinisiteSlug) and surfaces a friendly
   * error when the slug is already taken by someone else.
   */
  const updateSlug = useCallback(
    async (nextSlug: string): Promise<boolean> => {
      if (!user) return false;
      const normalized = nextSlug.trim().toLowerCase();
      if (!isValidMinisiteSlug(normalized)) {
        toast.error(t('minisite.link.invalidSlug'));
        return false;
      }
      setBusy(true);
      try {
        const { error } = await supabase.from('profiles').update({ minisite_slug: normalized }).eq('id', user.id);
        if (error) {
          if (error.code === UNIQUE_VIOLATION) {
            toast.error(t('minisite.link.slugTaken'));
          } else {
            toast.error(t('minisite.link.errorSaving'));
          }
          return false;
        }
        setSlug(normalized);
        toast.success(t('minisite.link.savedToast'));
        return true;
      } finally {
        setBusy(false);
      }
    },
    [user, t],
  );

  const copyLink = useCallback(async () => {
    const link = await ensureLink();
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      toast.success(t('minisite.link.copiedToast'));
    } catch {
      toast.info(link);
    }
  }, [ensureLink, t]);

  const sendWhatsApp = useCallback(async () => {
    const link = await ensureLink();
    if (!link) return;
    window.open(`https://wa.me/?text=${encodeURIComponent(t('minisite.link.whatsAppMessage', { link }))}`, '_blank');
  }, [ensureLink, t]);

  return { slug, loading, busy, ensureLink, updateSlug, copyLink, sendWhatsApp };
}
