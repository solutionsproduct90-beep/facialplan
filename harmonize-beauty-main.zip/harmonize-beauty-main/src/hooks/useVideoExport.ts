import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import { generateBeforeAfterVideo } from '@/lib/videoExport';

export type VideoExportStatus = 'idle' | 'generating' | 'ready' | 'error';

export interface UseVideoExportOptions {
  sessionId: string | undefined;
  beforeUrl: string | null | undefined;
  afterUrl: string | null | undefined;
  title?: string;
  caption?: string;
}

/**
 * Orquestra a geração client-side do vídeo antes/depois (ver
 * `src/lib/videoExport.ts`) e o compartilhamento do resultado — via Web
 * Share API (`navigator.share`) quando o navegador suporta compartilhar
 * arquivos, com fallback para download simples do `.mp4`. Segue o mesmo
 * padrão de `useSessionPresentLink`: log de falhas em `error_logs` com
 * `stage: 'present'` para dar visibilidade a problemas de geração.
 */
export function useVideoExport({ sessionId, beforeUrl, afterUrl, title, caption }: UseVideoExportOptions) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [status, setStatus] = useState<VideoExportStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const objectUrlRef = useRef<string | null>(null);

  const revokeObjectUrl = useCallback(() => {
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current);
      objectUrlRef.current = null;
    }
  }, []);

  useEffect(() => revokeObjectUrl, [revokeObjectUrl]);

  const logFailure = useCallback((message: string) => {
    if (!user) return;
    logClientError({
      professionalId: user.id,
      sessionId: sessionId ?? null,
      stage: 'present',
      errorType: 'video_export_failed',
      message,
    });
  }, [user, sessionId]);

  const generate = useCallback(async () => {
    if (!beforeUrl || !afterUrl) {
      toast.error(t('sessions.present.video.missingPhotos'));
      return;
    }
    revokeObjectUrl();
    setVideoFile(null);
    setVideoUrl(null);
    setStatus('generating');
    setProgress(0);
    try {
      const result = await generateBeforeAfterVideo({
        beforeUrl,
        afterUrl,
        title,
        caption,
        onProgress: setProgress,
      });
      const file = new File([result.blob], `harmonize-antes-depois-${Date.now()}.mp4`, { type: 'video/mp4' });
      objectUrlRef.current = URL.createObjectURL(result.blob);
      setVideoFile(file);
      setVideoUrl(objectUrlRef.current);
      setStatus('ready');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('sessions.present.video.errorGenerating');
      toast.error(t('sessions.present.video.errorGenerating'));
      console.error('[useVideoExport] Falha ao gerar vídeo:', err);
      logFailure(message);
      setStatus('error');
    }
  }, [beforeUrl, afterUrl, title, caption, t, logFailure, revokeObjectUrl]);

  const download = useCallback(() => {
    if (!videoUrl || !videoFile) return;
    const link = document.createElement('a');
    link.href = videoUrl;
    link.download = videoFile.name;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }, [videoUrl, videoFile]);

  const canShareFiles = Boolean(
    videoFile &&
      typeof navigator !== 'undefined' &&
      typeof navigator.share === 'function' &&
      typeof navigator.canShare === 'function' &&
      navigator.canShare({ files: [videoFile] })
  );

  const share = useCallback(async () => {
    if (!videoFile) return;
    if (canShareFiles) {
      try {
        await navigator.share({ files: [videoFile], title: title ?? t('sessions.present.video.shareTitle') });
        return;
      } catch (err) {
        // AbortError = o paciente/profissional cancelou a folha de compartilhamento — não é falha.
        if ((err as DOMException)?.name === 'AbortError') return;
      }
    }
    download();
  }, [videoFile, canShareFiles, download, title, t]);

  const reset = useCallback(() => {
    revokeObjectUrl();
    setVideoFile(null);
    setVideoUrl(null);
    setStatus('idle');
    setProgress(0);
  }, [revokeObjectUrl]);

  return { status, progress, canShareFiles, generate, download, share, reset };
}
