import { useEffect, useState } from 'react';

/**
 * Fatia mínima de "offline-first" (ver backlog: "Modo offline-first (PWA)
 * pra sala de procedimento"). Apenas detecta o estado online/offline do
 * navegador — NÃO inclui cache local nem sincronização de dados, que ficam
 * como próximo passo (ver OfflineBanner.tsx e o commit desta mudança).
 *
 * `navigator.onLine` é otimista (true nem sempre significa conectividade
 * real de rede, só que o SO/browser não detectou desconexão), mas os
 * eventos `online`/`offline` da `window` são o sinal padrão da plataforma
 * pra essa mudança de estado, e é o suficiente para o aviso não-bloqueante
 * que esta fatia entrega.
 */
export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}
