import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useSessionFeedbackLink } from './useSessionFeedbackLink';

/**
 * Regressão do ciclo 67 do QA Contínuo, no link de depoimento/NPS.
 *
 * Mesma corrida do useSessionPresentLink: enquanto a busca de montagem não
 * resolvia, `ensureLink()` criava um segundo token para a mesma sessão.
 * Como este link é de uso único, o efeito é um convite extra em aberto — o
 * paciente podia responder por um link enquanto a tela já dava a resposta
 * do outro por encerrada.
 */

type Deferred<T> = { promise: Promise<T>; resolve: (value: T) => void };
function deferred<T>(): Deferred<T> {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => { resolve = r; });
  return { promise, resolve };
}

type LinkRow = { token: string; used_at: string | null };

const inserts: unknown[] = [];
let mountSelect: Deferred<{ data: LinkRow | null }>;

function makeBuilder() {
  const builder: Record<string, unknown> = {};
  const chain = () => builder;
  Object.assign(builder, {
    select: chain,
    order: chain,
    limit: chain,
    eq: chain,
    insert: (payload: unknown) => { inserts.push(payload); return builder; },
    maybeSingle: () => mountSelect.promise,
    single: () => Promise.resolve({ data: { token: 'token-novo' }, error: null }),
    then: (onOk: (v: unknown) => unknown) => Promise.resolve({ error: null }).then(onOk),
  });
  return builder;
}

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: () => makeBuilder() },
}));

const AUTH = { user: { id: 'prof-1' } };
vi.mock('@/contexts/AuthContext', () => ({ useAuth: () => AUTH }));
vi.mock('react-i18next', () => ({ useTranslation: () => ({ t: (key: string) => key }) }));
vi.mock('sonner', () => ({ toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() } }));
vi.mock('@/lib/logClientError', () => ({ logClientError: vi.fn() }));

describe('useSessionFeedbackLink', () => {
  beforeEach(() => {
    inserts.length = 0;
    mountSelect = deferred();
  });

  it('reaproveita o link pendente em vez de criar um segundo', async () => {
    const { result } = renderHook(() => useSessionFeedbackLink('sessao-1'));

    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: { token: 'token-existente', used_at: null } });
      link = await pending;
    });

    expect(link).toContain('token-existente');
    expect(inserts).toHaveLength(0);
  });

  it('cria um link quando o anterior já foi respondido', async () => {
    // Link de uso único: respondido significa que não há mais nada a
    // reaproveitar, e aí criar é o certo.
    const { result } = renderHook(() => useSessionFeedbackLink('sessao-1'));

    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: { token: 'token-usado', used_at: '2026-09-01T10:00:00Z' } });
      link = await pending;
    });

    expect(link).toContain('token-novo');
    expect(inserts).toHaveLength(1);
  });
});
