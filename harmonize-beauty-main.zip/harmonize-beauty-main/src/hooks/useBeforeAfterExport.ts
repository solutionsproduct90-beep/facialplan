import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import { exportBeforeAfterPng } from '@/lib/beforeAfterExport';

export type BeforeAfterExportStatus = 'idle' | 'generating' | 'ready' | 'error';

export interface UseBeforeAfterExportOptions {
  sessionId: string | undefined;
  beforeUrl: string | null | undefined;
  afterUrl: string | null | undefined;
  clinicName?: string | null;
  logoUrl?: string | null;
}

/**
 * Gera, 100% client-side, o PNG antes/depois com marca da clínica para a
 * Biblioteca de Antes/Depois (src/pages/BibliotecaMarketing.tsx), e cuida do
 * compartilhamento/download do resultado — mesmo padrão de useVideoExport.ts
 * (Web Share API quando suportada, fallback pra download simples do
 * arquivo), incluindo o log de falhas em `error_logs`.
 */
export function useBeforeAfterExport({ sessionId, beforeUrl, afterUrl, clinicName, logoUrl }: UseBeforeAfterExportOptions) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [status, setStatus] = useState<BeforeAfterExportStatus>('idle');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const objectUrlRef = useRef<string | null>(null);

  const revokeObjectUrl = useCallback(() => {
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current);
      objectUrlRef.current = null;
    }
  }, []);

  useEffect(() => revokeObjectUrl, [revokeObjectUrl]);

  const logFailure = useCallback((message: string) => {
    if (!user) return;
    logClientError({
      professionalId: user.id,
      sessionId: sessionId ?? null,
      stage: 'marketing_library',
      errorType: 'before_after_export_failed',
      message,
    });
  }, [user, sessionId]);

  const generate = useCallback(async () => {
    if (!beforeUrl || !afterUrl) {
      toast.error(t('marketingLibrary.export.missingPhotos'));
      return;
    }
    revokeObjectUrl();
    setImageFile(null);
    setImageUrl(null);
    setStatus('generating');
    try {
      const blob = await exportBeforeAfterPng({
        beforeUrl,
        afterUrl,
        clinicName,
        logoUrl,
        beforeLabel: t('marketingLibrary.export.beforeLabel'),
        afterLabel: t('marketingLibrary.export.afterLabel'),
      });
      const file = new File([blob], `facialplan-antes-depois-${Date.now()}.png`, { type: 'image/png' });
      objectUrlRef.current = URL.createObjectURL(blob);
      setImageFile(file);
      setImageUrl(objectUrlRef.current);
      setStatus('ready');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('marketingLibrary.export.errorGenerating');
      toast.error(t('marketingLibrary.export.errorGenerating'));
      console.error('[useBeforeAfterExport] Falha ao gerar imagem:', err);
      logFailure(message);
      setStatus('error');
    }
  }, [beforeUrl, afterUrl, clinicName, logoUrl, t, logFailure, revokeObjectUrl]);

  const download = useCallback(() => {
    if (!imageUrl || !imageFile) return;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = imageFile.name;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }, [imageUrl, imageFile]);

  const canShareFiles = Boolean(
    imageFile &&
      typeof navigator !== 'undefined' &&
      typeof navigator.share === 'function' &&
      typeof navigator.canShare === 'function' &&
      navigator.canShare({ files: [imageFile] })
  );

  const share = useCallback(async () => {
    if (!imageFile) return;
    if (canShareFiles) {
      try {
        await navigator.share({ files: [imageFile], title: t('marketingLibrary.export.shareTitle') });
        return;
      } catch (err) {
        // AbortError = o profissional cancelou a folha de compartilhamento — não é falha.
        if ((err as DOMException)?.name === 'AbortError') return;
      }
    }
    download();
  }, [imageFile, canShareFiles, download, t]);

  const reset = useCallback(() => {
    revokeObjectUrl();
    setImageFile(null);
    setImageUrl(null);
    setStatus('idle');
  }, [revokeObjectUrl]);

  return { status, imageUrl, canShareFiles, generate, download, share, reset };
}
