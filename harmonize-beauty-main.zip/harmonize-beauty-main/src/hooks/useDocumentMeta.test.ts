import { describe, it, expect, afterEach } from 'vitest';
import { renderHook, cleanup } from '@testing-library/react';
import { useDocumentMeta } from './useDocumentMeta';

function metaContent(attr: 'name' | 'property', key: string): string | null {
  return document.head.querySelector(`meta[${attr}="${key}"]`)?.getAttribute('content') ?? null;
}

describe('useDocumentMeta', () => {
  afterEach(() => {
    cleanup();
    document.title = '';
    document.head.querySelectorAll('meta[name="description"], meta[property^="og:"]').forEach((el) => el.remove());
  });

  it('sets document.title and the description meta tag', () => {
    renderHook(() => useDocumentMeta({ title: 'Dra. Ana — Antes e Depois', description: 'Confira resultados reais.' }));

    expect(document.title).toBe('Dra. Ana — Antes e Depois');
    expect(metaContent('name', 'description')).toBe('Confira resultados reais.');
  });

  it('defaults og:title and og:description to title/description when not given explicitly', () => {
    renderHook(() => useDocumentMeta({ title: 'Dra. Ana — Antes e Depois', description: 'Confira resultados reais.' }));

    expect(metaContent('property', 'og:title')).toBe('Dra. Ana — Antes e Depois');
    expect(metaContent('property', 'og:description')).toBe('Confira resultados reais.');
  });

  it('uses explicit ogTitle/ogDescription over title/description when both are given', () => {
    renderHook(() =>
      useDocumentMeta({
        title: 'Título da aba',
        description: 'Descrição da aba',
        ogTitle: 'Título do preview',
        ogDescription: 'Descrição do preview',
      })
    );

    expect(document.title).toBe('Título da aba');
    expect(metaContent('property', 'og:title')).toBe('Título do preview');
    expect(metaContent('property', 'og:description')).toBe('Descrição do preview');
  });

  it('only writes og:image when an image URL is provided', () => {
    const { rerender } = renderHook(({ ogImage }: { ogImage?: string | null }) => useDocumentMeta({ title: 't', ogImage }), {
      initialProps: { ogImage: undefined as string | undefined },
    });
    expect(document.head.querySelector('meta[property="og:image"]')).toBeNull();

    rerender({ ogImage: 'https://example.com/foto.jpg' });
    expect(metaContent('property', 'og:image')).toBe('https://example.com/foto.jpg');
  });

  it('restores the previous document.title on unmount', () => {
    document.title = 'FacialPlan';
    const { unmount } = renderHook(() => useDocumentMeta({ title: 'Dra. Ana — Antes e Depois' }));

    expect(document.title).toBe('Dra. Ana — Antes e Depois');
    unmount();
    expect(document.title).toBe('FacialPlan');
  });

  it('restores a pre-existing meta description content on unmount instead of deleting the tag', () => {
    const preexisting = document.createElement('meta');
    preexisting.setAttribute('name', 'description');
    preexisting.setAttribute('content', 'Planejamento estético com inteligência artificial');
    document.head.appendChild(preexisting);

    const { unmount } = renderHook(() => useDocumentMeta({ title: 't', description: 'Descrição específica' }));
    expect(metaContent('name', 'description')).toBe('Descrição específica');

    unmount();
    expect(metaContent('name', 'description')).toBe('Planejamento estético com inteligência artificial');
  });

  it('removes a meta tag it created itself on unmount, when none pre-existed', () => {
    const { unmount } = renderHook(() => useDocumentMeta({ title: 't', description: 'Descrição específica' }));
    expect(document.head.querySelector('meta[name="description"]')).not.toBeNull();

    unmount();
    expect(document.head.querySelector('meta[name="description"]')).toBeNull();
  });
});
