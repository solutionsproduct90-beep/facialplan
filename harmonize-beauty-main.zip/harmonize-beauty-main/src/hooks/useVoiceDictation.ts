import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';

interface UseVoiceDictationOptions {
  /** Valor atual do campo de texto controlado que recebe o ditado. */
  value: string;
  /** Chamado com o texto completo (valor anterior + transcrição) a cada atualização do reconhecimento. */
  onTranscript: (text: string) => void;
  /** BCP-47, ex. "pt-BR". */
  lang?: string;
}

interface UseVoiceDictationResult {
  isSupported: boolean;
  isRecording: boolean;
  start: () => void;
  stop: () => void;
}

function getSpeechRecognitionCtor(): SpeechRecognitionStatic | undefined {
  if (typeof window === 'undefined') return undefined;
  return window.SpeechRecognition ?? window.webkitSpeechRecognition;
}

function joinNonEmpty(...parts: string[]): string {
  return parts
    .map((part) => part.trim())
    .filter(Boolean)
    .join(' ');
}

/**
 * Ditado por voz 100% client-side via Web Speech API nativa do navegador
 * (`SpeechRecognition`/`webkitSpeechRecognition`) — nenhum áudio é enviado a
 * nenhum serviço, de IA ou não (não confundir com a edge function
 * `analyze-face`, que analisa fotos, não voz). Suporte é parcial entre
 * navegadores: Chrome/Edge implementam via `webkitSpeechRecognition`;
 * Firefox e Safari não implementam ou implementam de forma incompleta — por
 * isso `isSupported` existe, para o consumidor (ver VoiceDictationButton)
 * decidir como degradar.
 */
export function useVoiceDictation({ value, onTranscript, lang }: UseVoiceDictationOptions): UseVoiceDictationResult {
  const { t } = useTranslation();
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  // Valor "base" sobre o qual o texto ditado é anexado. Congelado no momento
  // em que start() é chamado e só ressincronizado com o `value` externo
  // enquanto não há gravação em andamento — senão as próprias atualizações
  // disparadas por onTranscript realimentariam este efeito e duplicariam o
  // texto já ditado nesta sessão de gravação.
  const baseValueRef = useRef(value);
  const finalTranscriptRef = useRef('');
  const isSupported = !!getSpeechRecognitionCtor();

  useEffect(() => {
    if (!isRecording) {
      baseValueRef.current = value;
    }
  }, [value, isRecording]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
  }, []);

  const start = useCallback(() => {
    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor || recognitionRef.current) return;

    const recognition = new Ctor();
    recognition.lang = lang || 'pt-BR';
    recognition.continuous = true;
    recognition.interimResults = true;

    baseValueRef.current = value;
    finalTranscriptRef.current = '';

    recognition.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const chunk = result[0]?.transcript ?? '';
        if (result.isFinal) {
          finalTranscriptRef.current = joinNonEmpty(finalTranscriptRef.current, chunk);
        } else {
          interim = joinNonEmpty(interim, chunk);
        }
      }
      onTranscript(joinNonEmpty(baseValueRef.current, finalTranscriptRef.current, interim));
    };

    recognition.onerror = (event) => {
      // "no-speech" (silêncio) e "aborted" (stop() manual) não são falhas
      // reais — não vale incomodar o profissional com um toast por isso.
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        toast.error(t('voiceDictation.permissionDenied'));
      } else if (event.error !== 'no-speech' && event.error !== 'aborted') {
        toast.error(t('voiceDictation.genericError'));
      }
    };

    recognition.onend = () => {
      setIsRecording(false);
      recognitionRef.current = null;
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsRecording(true);
    } catch {
      // start() pode lançar de forma síncrona (ex.: InvalidStateError se já
      // houver um reconhecimento em andamento no navegador).
      recognitionRef.current = null;
      setIsRecording(false);
      toast.error(t('voiceDictation.genericError'));
    }
  }, [lang, onTranscript, value, t]);

  // Encerra o reconhecimento em andamento se o componente desmontar (ex.:
  // profissional navega para outra tela no meio de um ditado).
  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
    };
  }, []);

  return { isSupported, isRecording, start, stop };
}
