import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import type { SiteLocale } from '@/lib/siteLocale';

/**
 * Locale efetivo de uma página pública institucional/blog, derivado da URL
 * (não do idioma detectado no navegador) — a rota é a fonte da verdade, já
 * que estas páginas precisam ter conteúdo/URL correspondentes 1:1 pra
 * crawlers (ver src/lib/siteLocale.ts). Sincroniza o idioma ativo do
 * i18next com esse locale, pra chrome (nav, botões) acompanhar mesmo
 * quando o navegador detectou outro idioma.
 */
export function useSiteLocale(): SiteLocale {
  const { lang } = useParams<{ lang?: string }>();
  const { i18n } = useTranslation();
  const locale = (lang as SiteLocale) ?? 'pt';

  useEffect(() => {
    if (i18n.language !== locale) {
      i18n.changeLanguage(locale);
    }
  }, [locale, i18n]);

  return locale;
}
