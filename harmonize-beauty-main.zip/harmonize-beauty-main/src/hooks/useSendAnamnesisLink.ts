import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import { logDataAccess } from '@/lib/auditLog';

/**
 * Geração/reenvio do link público de anamnese, extraída de PacienteDetalhe
 * para ser reaproveitada também pela tela de bloqueio do Estágio 1
 * (SessaoEstagio1.tsx — ver `anamnesisGate`), que precisa da mesma ação sem
 * duplicar a lógica de expiração/erro/log.
 *
 * Link válido por 7 dias — tempo suficiente para o paciente preencher em
 * casa sem deixar um token utilizável indefinidamente.
 */
export function useSendAnamnesisLink() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [linkGenerating, setLinkGenerating] = useState(false);

  const sendAnamnesisLink = async (patient: { id: string; name: string }) => {
    if (!user) return false;
    setLinkGenerating(true);
    try {
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      const { data, error } = await supabase
        .from('anamnesis_links')
        .insert({ patient_id: patient.id, professional_id: user.id, expires_at: expiresAt })
        .select('token')
        .single();
      if (error || !data) throw error ?? new Error('token ausente');

      // Gap P2 do backlog de auditoria: gerar um link público de anamnese
      // dá a quem tiver a URL acesso aos dados de saúde do paciente, então
      // passa a ser um evento auditável como os demais (ver
      // supabase/migrations/20260910210000_audit_log_admin_view_and_patient_link.sql).
      // Melhor esforço/não bloqueante, mesmo padrão de todo outro chamador
      // de logDataAccess — uma falha aqui não deve impedir o profissional de
      // enviar o link pro paciente.
      logDataAccess('send_anamnesis_link', 'patient', patient.id);

      const link = `${window.location.origin}/anamnese/${data.token}`;
      const message = t('anamnesis.whatsAppMessage', { link, name: patient.name.split(' ')[0] });
      window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
      return true;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('anamnesis.linkErrorGenerating');
      toast.error(message);
      // Bug corrigido (ver histórico de PacienteDetalhe.tsx): sem isso, uma
      // falha ao gerar o link virava um toast genérico sem nenhum registro,
      // impossível de diagnosticar depois (RLS, chave estrangeira, etc.).
      // eslint-disable-next-line no-console
      console.error('[useSendAnamnesisLink] Falha ao gerar link de anamnese:', err);
      if (user) {
        logClientError({
          professionalId: user.id,
          stage: 'anamnesis',
          errorType: 'anamnesis_link_generation_failed',
          message,
        });
      }
      return false;
    } finally {
      setLinkGenerating(false);
    }
  };

  return { sendAnamnesisLink, linkGenerating };
}
