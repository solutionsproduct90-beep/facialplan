import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { useSessionPresentLink } from './useSessionPresentLink';

/**
 * Regressão do ciclo 67 do QA Contínuo.
 *
 * O hook decide se cria um link novo olhando o estado `token`, que só é
 * preenchido quando a busca de montagem resolve. Os botões da tela já estão
 * clicáveis antes disso, e a geração do QR do PDF (SessaoEstagio3) chama
 * `ensureLink()` sem botão nenhum. Enquanto a busca não chegava, o hook
 * criava uma SEGUNDA linha ativa para a mesma sessão — e a busca, ao
 * resolver depois, sobrescrevia o estado com o token ANTIGO. "Desativar
 * link" passava a revogar o token errado, e o link que o paciente recebeu
 * continuava dando acesso às fotos e à simulação.
 *
 * Os testes exercitam o hook de produção de verdade; só o cliente Supabase
 * é dublê.
 */

type Deferred<T> = { promise: Promise<T>; resolve: (value: T) => void };
function deferred<T>(): Deferred<T> {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => { resolve = r; });
  return { promise, resolve };
}

/** Uma chamada registrada no dublê: tabela, operação e filtros aplicados. */
type Call = { table: string; op: 'select' | 'insert' | 'update'; filters: Array<[string, unknown]>; payload?: unknown };

const calls: Call[] = [];
let mountSelect: Deferred<{ data: { token: string } | null }>;
let insertToken: string;

function makeBuilder(table: string) {
  const call: Call = { table, op: 'select', filters: [] };
  calls.push(call);
  const builder: Record<string, unknown> = {};
  const chain = () => builder;
  Object.assign(builder, {
    select: chain,
    order: chain,
    limit: chain,
    eq: (col: string, value: unknown) => { call.filters.push([col, value]); return builder; },
    is: (col: string, value: unknown) => { call.filters.push([col, value]); return builder; },
    insert: (payload: unknown) => { call.op = 'insert'; call.payload = payload; return builder; },
    update: (payload: unknown) => { call.op = 'update'; call.payload = payload; return builder; },
    maybeSingle: () => mountSelect.promise,
    single: () => Promise.resolve({ data: { token: insertToken }, error: null }),
    then: (onOk: (v: unknown) => unknown) => Promise.resolve({ error: null }).then(onOk),
  });
  return builder;
}

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (table: string) => makeBuilder(table) },
}));

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => ({ user: { id: 'prof-1' } }),
}));

vi.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() },
}));

vi.mock('@/lib/logClientError', () => ({ logClientError: vi.fn() }));

describe('useSessionPresentLink', () => {
  beforeEach(() => {
    calls.length = 0;
    mountSelect = deferred();
    insertToken = 'token-novo';
    Object.defineProperty(window.navigator, 'clipboard', {
      value: { writeText: vi.fn().mockResolvedValue(undefined) },
      configurable: true,
    });
  });

  it('não cria um segundo link quando a busca de montagem ainda não chegou', async () => {
    const { result } = renderHook(() => useSessionPresentLink('sessao-1'));

    // Clique instantâneo: a busca de montagem está em voo e já tem um token
    // ativo para entregar.
    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: { token: 'token-existente' } });
      link = await pending;
    });

    expect(link).toContain('token-existente');
    expect(calls.filter((c) => c.op === 'insert')).toHaveLength(0);
  });

  it('o estado final aponta para o mesmo token que foi entregue', async () => {
    // Era aqui que o bug se completava: o insert acontecia, mas a busca de
    // montagem resolvia depois e devolvia o estado ao token antigo — o hook
    // passava a rastrear um link diferente do que foi compartilhado.
    const { result } = renderHook(() => useSessionPresentLink('sessao-1'));

    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: { token: 'token-existente' } });
      link = await pending;
    });

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(link).toContain(result.current.token as string);
  });

  it('cria um link quando a sessão realmente não tem nenhum ativo', async () => {
    const { result } = renderHook(() => useSessionPresentLink('sessao-1'));

    let link: string | null = null;
    await act(async () => {
      const pending = result.current.ensureLink();
      mountSelect.resolve({ data: null });
      link = await pending;
    });

    expect(link).toContain('token-novo');
    expect(calls.filter((c) => c.op === 'insert')).toHaveLength(1);
  });

  it('duas ações disparadas juntas geram um único link', async () => {
    // Copiar e mandar no WhatsApp em sequência rápida não pode deixar uma
    // linha ativa órfã para trás.
    const { result } = renderHook(() => useSessionPresentLink('sessao-1'));

    await act(async () => {
      const a = result.current.ensureLink();
      const b = result.current.ensureLink();
      mountSelect.resolve({ data: null });
      await Promise.all([a, b]);
    });

    expect(calls.filter((c) => c.op === 'insert')).toHaveLength(1);
  });

  it('desativar revoga por sessão, não só o token em estado', async () => {
    // Se uma linha órfã existir (app antigo, duas abas), ela também precisa
    // cair: "Desativar link" tem que significar "ninguém mais vê isso".
    const { result } = renderHook(() => useSessionPresentLink('sessao-1'));
    await act(async () => {
      mountSelect.resolve({ data: { token: 'token-existente' } });
    });
    await waitFor(() => expect(result.current.token).toBe('token-existente'));

    await act(async () => { await result.current.disableLink(); });

    const update = calls.find((c) => c.op === 'update');
    expect(update?.filters).toContainEqual(['session_id', 'sessao-1']);
    expect(update?.filters).toContainEqual(['revoked_at', null]);
    expect(update?.filters.some(([col]) => col === 'token')).toBe(false);
  });
});
