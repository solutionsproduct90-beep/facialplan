import React from 'react';
import { useTranslation } from 'react-i18next';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import SiteLayout from '@/components/site/SiteLayout';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { stripAuthoringNotes } from '@/lib/legalDocs';

// Casca compartilhada das páginas de documento legal (/termos e
// /privacidade). Existe como componente próprio porque as duas páginas são
// idênticas em tudo menos no arquivo de conteúdo e no par título/versão —
// duplicar a casca garantiria que, na primeira revisão, uma das duas
// deixasse de exibir a versão ou o aviso de tradução.
//
// Usa SiteLayout (header + rodapé institucional) em vez da casca solta que
// estas páginas tinham antes: é onde estão os links de volta para o site e
// para os próprios documentos, e é o que faz a página parecer parte do
// produto — um documento legal numa página órfã passa a impressão errada
// justamente onde a confiança importa.

// O corpo usa a mesma folha editorial dos artigos do blog (.site-prose em
// index.css), pra o documento legal ler como parte do site e não como um
// anexo com outra tipografia.

interface LegalDocumentPageProps {
  titleKey: string;
  descriptionKey: string;
  /** Data de vigência (AAAA-MM-DD) — ver src/lib/legalDocs.ts. */
  version: string;
  /** Markdown do documento, sempre em pt-BR. */
  body: string;
}

const LegalDocumentPage: React.FC<LegalDocumentPageProps> = ({ titleKey, descriptionKey, version, body }) => {
  const { t, i18n } = useTranslation();
  const title = t(titleKey);
  const description = t(descriptionKey);

  useDocumentMeta({ title: `${title} — FacialPlan`, description });

  // O corpo legal existe só em português (ver TERMS_BODY_PT em
  // src/lib/legalDocs.ts): é redigido sobre a LGPD, e uma tradução sem valor
  // jurídico criaria dúvida sobre qual versão prevalece. Quem está com a
  // interface em outro idioma merece saber disso antes de começar a ler, em
  // vez de topar com uma parede de português sem explicação.
  const showTranslationNotice = !i18n.language.startsWith('pt');

  return (
    <SiteLayout>
      <article className="mx-auto max-w-[720px] px-5 pb-20 pt-14 sm:px-8 md:pb-28 md:pt-20">
        <h1 className="font-display text-balance text-[38px] font-normal leading-[1.05] tracking-[-0.02em] text-s-ink md:text-[52px]">
          {title}
        </h1>
        <p className="mb-10 mt-4 border-b border-s-line pb-6 text-[13.5px] text-s-ink-3">{t('legal.versionLabel', { version })}</p>

        {showTranslationNotice && (
          <p className="mb-10 border-l-2 border-s-accent bg-s-paper px-5 py-4 text-[14px] leading-snug text-s-ink-2">
            {t('legal.translationPending')}
          </p>
        )}

        <div className="site-prose">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{stripAuthoringNotes(body)}</ReactMarkdown>
        </div>
      </article>
    </SiteLayout>
  );
};

export default LegalDocumentPage;
