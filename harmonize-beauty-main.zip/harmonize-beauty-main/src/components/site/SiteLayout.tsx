import React from 'react';
import SiteHeader from './SiteHeader';
import SiteFooter from './SiteFooter';

// Layout compartilhado das páginas públicas institucionais e do blog —
// mesma casca (header + footer) em toda página fora do ProtectedRoute que
// não é uma tela de autenticação/formulário isolado. O fundo e a cor de
// texto do site (paleta `s`, ver tailwind.config.ts) moram aqui, e não no
// <body>, porque o <body> é compartilhado com o app.
const SiteLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="flex min-h-screen flex-col bg-s-bone text-s-ink selection:bg-s-accent selection:text-white">
    <SiteHeader />
    <main className="flex-1">{children}</main>
    <SiteFooter />
  </div>
);

export default SiteLayout;
