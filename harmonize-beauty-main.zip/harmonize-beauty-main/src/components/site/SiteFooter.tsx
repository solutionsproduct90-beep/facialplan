import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import LogoMark from '@/components/harmonize/LogoMark';
import { useSiteLocale } from '@/hooks/useSiteLocale';
import { localizedPath } from '@/lib/siteLocale';
import { CONTAINER } from './SiteUi';

const linkClass = 'site-link w-fit pb-0.5 text-[14px] text-white/65 transition-colors hover:text-white';
const headingClass = 'mb-5 text-[11.5px] font-semibold uppercase tracking-[0.2em] text-white/40';

const SiteFooter: React.FC = () => {
  const { t } = useTranslation();
  const locale = useSiteLocale();
  const year = 2026;

  return (
    <footer className="overflow-hidden bg-s-night text-white">
      <div className={`${CONTAINER} grid gap-14 pb-10 pt-20 md:pt-24 lg:grid-cols-12`}>
        <div className="lg:col-span-5">
          <div className="mb-5 flex items-center gap-2.5">
            <LogoMark size={26} innerColor="#1A1215" />
            <span className="text-[17px] font-extrabold tracking-[-0.02em]">FacialPlan</span>
          </div>
          <p className="max-w-[340px] text-pretty text-[14.5px] leading-relaxed text-white/60">{t('site.footer.tagline')}</p>
        </div>

        <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:col-span-7">
          <div>
            <p className={headingClass}>{t('site.footer.productHeading')}</p>
            <div className="flex flex-col gap-3">
              <Link to={localizedPath('/recursos', locale)} className={linkClass}>{t('site.nav.features')}</Link>
              <Link to={localizedPath('/precos', locale)} className={linkClass}>{t('site.nav.pricing')}</Link>
              <Link to={localizedPath('/blog', locale)} className={linkClass}>{t('site.nav.blog')}</Link>
            </div>
          </div>
          <div>
            <p className={headingClass}>{t('site.footer.companyHeading')}</p>
            <div className="flex flex-col gap-3">
              <Link to={localizedPath('/sobre', locale)} className={linkClass}>{t('site.nav.about')}</Link>
              <Link to="/auth/login" className={linkClass}>{t('site.nav.login')}</Link>
            </div>
          </div>
          <div>
            <p className={headingClass}>{t('site.footer.legalHeading')}</p>
            {/* Os dois documentos legais saem do mesmo par de chaves usado
                no cabeçalho das próprias páginas e no checkbox do cadastro
                (legal.*) — antes o rodapé lia `termos.title` com
                `defaultValue`, o que mascarava a chave faltando em vez de
                denunciá-la. */}
            <div className="flex flex-col gap-3">
              <Link to="/termos" className={linkClass}>{t('legal.terms.title')}</Link>
              <Link to="/privacidade" className={linkClass}>{t('legal.privacy.title')}</Link>
            </div>
          </div>
        </div>
      </div>

      <div className={CONTAINER}>
        <p className="border-t border-white/10 py-6 text-[12.5px] text-white/40">{t('site.footer.copyright', { year })}</p>
      </div>

      {/* Assinatura da marca em escala de cartaz, tom sobre tom, cortada na
          base — o nome do produto como o maior elemento tipográfico do site,
          sem competir com nada acima dele. Decorativa: o nome já está no
          topo do rodapé para leitores de tela. */}
      <div aria-hidden="true" className="select-none overflow-hidden">
        <p className="-mb-[0.22em] whitespace-nowrap text-center text-[18.5vw] font-extrabold leading-[0.9] tracking-[-0.06em] text-s-night-2">
          FacialPlan
        </p>
      </div>
    </footer>
  );
};

export default SiteFooter;
