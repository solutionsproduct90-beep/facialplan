import React from 'react';

// Substitui a foto de banco de imagens da capa do blog (pessoa segurando
// tablet com malha facial genérica) por um desenho de linha autoral: o
// mesmo conceito de "varredura facial com IA" do produto de verdade — ver
// a animação real em src/pages/NovaSessao.tsx (scanSweep/scanDotIn em
// index.css) —, redesenhado no vocabulário do site institucional (fundo
// s-night, acento único s-accent) em vez do gradiente rosa/roxo do app.
//
// O rosto é um diagrama, não uma foto: óvalo de linha fina + as três
// linhas horizontais do cânone clássico de proporção facial (nascimento
// do cabelo / linha das sobrancelhas / base do nariz / mento) — a mesma
// régua que orienta a técnica de aplicação no produto real. Os 5 pontos
// luminosos usam as chaves de região reais de src/lib/faceRegions.ts
// (glabela, malar esq./dir., lábio superior, mento), não posições
// inventadas.
const LANDMARKS = [
  { cx: 400, cy: 206, delay: '0ms' },   // glabela
  { cx: 322, cy: 264, delay: '260ms' }, // malar esquerda
  { cx: 478, cy: 264, delay: '520ms' }, // malar direita
  { cx: 400, cy: 344, delay: '780ms' }, // lábio superior
  { cx: 400, cy: 412, delay: '1040ms' }, // mento
] as const;

const FACE_OUTLINE =
  'M400,92 C462,92 506,142 513,209 C519,268 501,338 460,392 ' +
  'C440,418 420,430 400,430 C380,430 360,418 340,392 ' +
  'C299,338 281,268 287,209 C294,142 338,92 400,92 Z';

const FaceScanVisual: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`relative bg-s-night ${className}`}>
    <svg viewBox="0 0 800 500" className="h-full w-full" role="presentation" aria-hidden="true">
      {/* Óvalo do rosto */}
      <path d={FACE_OUTLINE} fill="none" stroke="#FBF8F4" strokeOpacity={0.32} strokeWidth={2} />

      {/* Cânone de proporção — terços horizontais + eixo vertical, tracejados */}
      {[203, 316].map((y) => (
        <line key={y} x1={250} y1={y} x2={550} y2={y} stroke="#FBF8F4" strokeOpacity={0.14} strokeWidth={1} strokeDasharray="3 6" />
      ))}
      <line x1={400} y1={70} x2={400} y2={450} stroke="#FBF8F4" strokeOpacity={0.1} strokeWidth={1} strokeDasharray="3 6" />

      {/* Traços de olhos, nariz e lábios — sugestão mínima, não retrato */}
      <path d="M350,203 q20,-14 40,0" fill="none" stroke="#FBF8F4" strokeOpacity={0.4} strokeWidth={2} strokeLinecap="round" />
      <path d="M410,203 q20,-14 40,0" fill="none" stroke="#FBF8F4" strokeOpacity={0.4} strokeWidth={2} strokeLinecap="round" />
      <path d="M400,210 L396,314 M388,320 q12,10 24,0" fill="none" stroke="#FBF8F4" strokeOpacity={0.4} strokeWidth={2} strokeLinecap="round" />
      <path d="M366,344 q34,16 68,0" fill="none" stroke="#FBF8F4" strokeOpacity={0.4} strokeWidth={2} strokeLinecap="round" />

      {/* Pontos de região — mesma taxonomia clínica do produto real */}
      {LANDMARKS.map(({ cx, cy, delay }) => (
        <g key={`${cx}-${cy}`} className="site-scan-dot" style={{ transformOrigin: `${cx}px ${cy}px`, animationDelay: delay }}>
          <circle cx={cx} cy={cy} r={13} fill="#A63A5E" fillOpacity={0.16} />
          <circle cx={cx} cy={cy} r={4.5} fill="#E8A3B9" stroke="#1A1215" strokeWidth={1} />
        </g>
      ))}
    </svg>

    {/* Linha de varredura — fina, como a barra de progresso de leitura do
        artigo (ver .site-progress): é o único lugar, fora do LogoMark, onde
        o gradiente da marca aparece, e só como um fio de 2px, nunca como
        área grande. */}
    <div
      className="site-scan-sweep pointer-events-none absolute inset-x-[10%] h-[2px]"
      style={{
        background: 'linear-gradient(90deg, transparent, #E05C8A, #7C5AC2, transparent)',
        boxShadow: '0 0 12px 1px rgba(166,58,94,0.45)',
        animation: 'site-scan-sweep 3.4s ease-in-out infinite',
      }}
    />
  </div>
);

export default FaceScanVisual;
