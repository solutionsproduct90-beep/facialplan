import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowRight, Menu, X } from 'lucide-react';
import LogoMark from '@/components/harmonize/LogoMark';
import { useAuth } from '@/contexts/AuthContext';
import { useSiteLocale } from '@/hooks/useSiteLocale';
import { PREFIXED_LOCALES, localizedPath, splitLocaleFromPath, type SiteLocale } from '@/lib/siteLocale';
import { CONTAINER } from './SiteUi';

const NAV_ITEMS: Array<{ to: string; key: string }> = [
  { to: '/recursos', key: 'site.nav.features' },
  { to: '/precos', key: 'site.nav.pricing' },
  { to: '/blog', key: 'site.nav.blog' },
  { to: '/sobre', key: 'site.nav.about' },
];

const SITE_LOCALES: SiteLocale[] = ['pt', ...PREFIXED_LOCALES];
const LOCALE_LABEL: Record<SiteLocale, string> = { pt: 'PT', es: 'ES', en: 'EN' };

// Header público (institucional + blog) — usado fora do ProtectedRoute, em
// páginas que não têm nenhuma variação de conteúdo por sessão (por isso
// continuam de fora do RootRoute/ProtectedRoute). A única coisa que
// depende de `useAuth()` aqui é qual CTA mostrar: achado do QA Contínuo
// (ciclo 26) — um profissional já logado que abre um link de blog no
// mesmo navegador onde já está autenticado via sem isso, veria
// "Entrar"/"Cadastre-se" sem sentido. Troca só o rótulo/destino do botão;
// não faz nenhuma checagem de bloqueio/assinatura (isso continua sendo
// papel exclusivo do ProtectedRoute).
const SiteHeader: React.FC = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const { user } = useAuth();
  const locale = useSiteLocale();
  const [menuOpen, setMenuOpen] = useState(false);

  const { rest: unprefixedPath } = splitLocaleFromPath(location.pathname);

  // Com o menu móvel aberto (ele cobre a tela inteira), a página por baixo
  // não pode rolar — senão o gesto de fechar vira rolagem do conteúdo.
  useEffect(() => {
    if (!menuOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previous;
    };
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  const localeSwitch = (className: string) => (
    <nav aria-label={t('site.nav.language')} className={`flex items-center gap-3 text-[12px] font-semibold tracking-[0.12em] ${className}`}>
      {SITE_LOCALES.map((loc) => (
        <Link
          key={loc}
          to={localizedPath(unprefixedPath, loc)}
          hrefLang={loc}
          aria-current={loc === locale ? 'true' : undefined}
          onClick={closeMenu}
          className={loc === locale ? 'text-s-ink' : 'text-s-ink-3 transition-colors hover:text-s-ink'}
        >
          {LOCALE_LABEL[loc]}
        </Link>
      ))}
    </nav>
  );

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-s-line bg-s-bone/90 backdrop-blur-md">
        <div className={`${CONTAINER} flex h-16 items-center justify-between gap-6 lg:h-[76px]`}>
          <Link to={localizedPath('/', locale)} className="site-focus flex items-center gap-2.5" onClick={closeMenu}>
            <LogoMark size={26} innerColor="#F4EEE8" />
            <span className="text-[17px] font-extrabold tracking-[-0.02em] text-s-ink">FacialPlan</span>
          </Link>
  
          <nav className="hidden items-center gap-9 lg:flex">
            {NAV_ITEMS.map((item) => {
              const active = unprefixedPath.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={localizedPath(item.to, locale)}
                  aria-current={active ? 'page' : undefined}
                  className={`site-link pb-0.5 text-[14px] font-medium ${
                    active ? 'text-s-ink' : 'text-s-ink-2 hover:text-s-ink'
                  }`}
                >
                  {t(item.key)}
                </Link>
              );
            })}
          </nav>
  
          <div className="hidden items-center gap-7 lg:flex">
            {localeSwitch('')}
            <span aria-hidden="true" className="h-4 w-px bg-s-line" />
            {user ? (
              <Link
                to="/inicio"
                className="site-focus inline-flex h-10 items-center gap-2 rounded-[3px] bg-s-ink px-5 text-[13.5px] font-semibold text-s-bone transition-colors hover:bg-s-accent"
              >
                {t('site.nav.dashboard')}
              </Link>
            ) : (
              <>
                <Link to="/auth/login" className="site-link pb-0.5 text-[14px] font-medium text-s-ink-2 hover:text-s-ink">
                  {t('site.nav.login')}
                </Link>
                <Link
                  to="/auth/cadastro"
                  className="site-focus inline-flex h-10 items-center gap-2 rounded-[3px] bg-s-ink px-5 text-[13.5px] font-semibold text-s-bone transition-colors hover:bg-s-accent"
                >
                  {t('site.nav.cta')}
                </Link>
              </>
            )}
          </div>
  
          <button
            type="button"
            aria-label={menuOpen ? t('site.nav.closeMenu') : t('site.nav.openMenu')}
            aria-expanded={menuOpen}
            aria-controls="site-mobile-menu"
            className="site-focus -mr-2 flex h-11 w-11 items-center justify-center lg:hidden"
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X size={22} strokeWidth={1.5} className="text-s-ink" /> : <Menu size={22} strokeWidth={1.5} className="text-s-ink" />}
          </button>
        </div>
      </header>

      {/* Fora do <header> de propósito: o backdrop-filter do header vira o
          bloco de contenção de qualquer filho `position: fixed`, e o menu
          ficava recortado na altura da barra (64px). */}
      {menuOpen && (
        <div
          id="site-mobile-menu"
          className="fixed inset-x-0 bottom-0 top-16 z-40 flex flex-col overflow-y-auto bg-s-bone px-5 pb-8 pt-4 sm:px-8 lg:hidden"
        >
          <nav className="flex flex-col">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.to}
                to={localizedPath(item.to, locale)}
                onClick={closeMenu}
                className="flex items-center justify-between border-b border-s-line py-5 font-display text-[34px] leading-none tracking-[-0.01em] text-s-ink"
              >
                {t(item.key)}
                <ArrowRight size={20} strokeWidth={1.25} className="text-s-ink-3" />
              </Link>
            ))}
          </nav>

          {localeSwitch('mt-8')}

          <div className="mt-auto flex flex-col gap-3 pt-10">
            {user ? (
              <Link
                to="/inicio"
                onClick={closeMenu}
                className="flex h-[52px] items-center justify-center rounded-[3px] bg-s-ink text-[15px] font-semibold text-s-bone"
              >
                {t('site.nav.dashboard')}
              </Link>
            ) : (
              <>
                <Link
                  to="/auth/cadastro"
                  onClick={closeMenu}
                  className="flex h-[52px] items-center justify-center rounded-[3px] bg-s-ink text-[15px] font-semibold text-s-bone"
                >
                  {t('site.nav.cta')}
                </Link>
                <Link
                  to="/auth/login"
                  onClick={closeMenu}
                  className="flex h-[52px] items-center justify-center rounded-[3px] border border-s-line text-[15px] font-semibold text-s-ink"
                >
                  {t('site.nav.login')}
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default SiteHeader;
