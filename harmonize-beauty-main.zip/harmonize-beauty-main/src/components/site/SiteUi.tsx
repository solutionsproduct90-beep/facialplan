import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

// Peças visuais compartilhadas pelas páginas do site institucional e do
// blog. Ficam num arquivo só porque são pequenas e sempre usadas juntas —
// e porque o sistema do site é deliberadamente curto: uma largura de
// coluna, um rótulo, dois tipos de link e um fechamento de página. Tudo que
// não cabe aqui deve ser composição na própria página, não componente novo.

/** Largura e respiro lateral de todo bloco do site. */
export const CONTAINER = 'mx-auto w-full max-w-[1360px] px-5 sm:px-8 lg:px-12';

/** Rótulo de seção: versalete espaçado precedido de um fio curto. */
export const Eyebrow: React.FC<{ children: React.ReactNode; tone?: 'light' | 'dark'; className?: string }> = ({
  children,
  tone = 'light',
  className = '',
}) => (
  <p
    className={`flex items-center gap-3 text-[11.5px] font-semibold uppercase tracking-[0.2em] ${
      tone === 'dark' ? 'text-white/55' : 'text-s-ink-3'
    } ${className}`}
  >
    <span aria-hidden="true" className="h-px w-6 bg-current opacity-60" />
    {children}
  </p>
);

/**
 * CTA principal. Retângulo de canto quase reto e cor sólida (tinta), sem o
 * gradiente + sombra colorida do app — no site, o que dá peso ao botão é o
 * contraste com o fundo claro, não o efeito.
 */
export const PrimaryLink: React.FC<{
  to: string;
  children: React.ReactNode;
  tone?: 'ink' | 'light';
  className?: string;
}> = ({ to, children, tone = 'ink', className = '' }) => (
  <Link
    to={to}
    className={`site-focus group inline-flex h-[52px] items-center justify-center gap-3 rounded-[3px] px-7 text-[14.5px] font-semibold tracking-[0.01em] transition-colors duration-300 ${
      tone === 'ink' ? 'bg-s-ink text-s-bone hover:bg-s-accent' : 'bg-s-bone text-s-ink hover:bg-white'
    } ${className}`}
  >
    {children}
    <ArrowRight size={16} strokeWidth={1.75} className="transition-transform duration-300 group-hover:translate-x-1" />
  </Link>
);

/** Link secundário: texto sublinhado, com o fio "correndo" pro acento no hover. */
export const TextLink: React.FC<{ to: string; children: React.ReactNode; className?: string }> = ({
  to,
  children,
  className = '',
}) => (
  <Link
    to={to}
    className={`site-link-underlined inline-flex items-center gap-2 pb-1 text-[14.5px] font-semibold text-s-ink ${className}`}
  >
    {children}
  </Link>
);

/**
 * Divide um título no primeiro travessão, pra a segunda metade ganhar o
 * itálico da serifa (ex.: "A imagem nasce do plano — não o contrário").
 * Quando a tradução não tem travessão, o título sai inteiro, sem ênfase —
 * nunca quebra.
 */
export function splitAtDash(text: string): [string, string | null] {
  const index = text.indexOf('—');
  if (index === -1) return [text, null];
  return [text.slice(0, index).trim(), text.slice(index + 1).trim()];
}

/**
 * Fechamento de página: faixa cor de pele com título grande em serifa e a
 * ação. Substitui o "banner com gradiente da marca" que existia antes em
 * toda página — o gradiente em área grande era o traço que mais fazia o
 * site parecer template.
 */
export const ClosingCta: React.FC<{
  title: string;
  body?: string;
  to: string;
  label: string;
  children?: React.ReactNode;
}> = ({ title, body, to, label, children }) => (
  <section className="bg-s-blush">
    <div className={`${CONTAINER} grid gap-10 py-20 md:py-28 lg:grid-cols-12 lg:items-end`}>
      <h2 className="site-reveal font-display text-balance text-[38px] font-normal leading-[1.04] tracking-[-0.02em] text-s-ink sm:text-[52px] lg:col-span-8 lg:text-[68px]">
        {title}
      </h2>
      <div className="site-reveal flex flex-col items-start gap-6 lg:col-span-4 lg:pb-3">
        {body && <p className="text-pretty text-[16px] leading-relaxed text-s-ink-2">{body}</p>}
        <div className="flex flex-wrap items-center gap-x-7 gap-y-4">
          <PrimaryLink to={to}>{label}</PrimaryLink>
          {children}
        </div>
      </div>
    </div>
  </section>
);
