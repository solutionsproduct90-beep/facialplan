import React from 'react';
import { useTranslation } from 'react-i18next';
import AuthSelect from '@/components/harmonize/AuthSelect';

export interface AnamnesisSkinValues {
  skinType: string;
  skinTexture: string;
  oiliness: string;
  discromia: string[];
  vascularization: string[];
}

interface AnamnesisSkinFieldsProps extends AnamnesisSkinValues {
  onChange: (patch: Partial<AnamnesisSkinValues>) => void;
}

const SKIN_TYPE_OPTIONS = ['normal', 'dry', 'oily', 'combination', 'sensitive'] as const;
const SKIN_TEXTURE_OPTIONS = ['smooth', 'rough', 'enlarged_pores', 'irregular'] as const;
const OILINESS_OPTIONS = ['low', 'medium', 'high'] as const;
const DISCROMIA_OPTIONS = ['sun_spots', 'melasma', 'pih', 'vitiligo', 'other'] as const;
const VASCULARIZATION_OPTIONS = ['rosacea', 'telangiectasia', 'erythema', 'other'] as const;

const toggle = (arr: string[], value: string) => (arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value]);

/** Caracterização de pele — opcional, reaproveitada pelo formulário do
 * profissional e pelo formulário público de anamnese. */
const AnamnesisSkinFields: React.FC<AnamnesisSkinFieldsProps> = ({
  skinType,
  skinTexture,
  oiliness,
  discromia,
  vascularization,
  onChange,
}) => {
  const { t } = useTranslation();

  const chipRow = (
    labelKey: string,
    options: readonly string[],
    optionsNamespace: string,
    selected: string[],
    field: 'discromia' | 'vascularization',
  ) => (
    <div>
      <p className="text-[13px] font-semibold text-h-text-2 mb-2">{t(labelKey)}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => {
          const active = selected.includes(opt);
          return (
            <button
              key={opt}
              type="button"
              onClick={() => onChange({ [field]: toggle(selected, opt) } as Partial<AnamnesisSkinValues>)}
              className="px-3 py-2 rounded-full text-[12px] font-semibold transition-all"
              style={active ? { background: 'rgba(191,95,130,0.12)', color: '#BF5F82' } : { background: '#F5F4F2', color: '#6B6965' }}
            >
              {t(`${optionsNamespace}.${opt}`)}
            </button>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col gap-4">
      <AuthSelect
        label={t('anamnesis.form.skinTypeLabel')}
        options={SKIN_TYPE_OPTIONS.map((v) => ({ value: v, label: t(`anamnesis.form.skinTypeOptions.${v}`) }))}
        value={skinType}
        onChange={(v) => onChange({ skinType: v })}
      />
      <AuthSelect
        label={t('anamnesis.form.skinTextureLabel')}
        options={SKIN_TEXTURE_OPTIONS.map((v) => ({ value: v, label: t(`anamnesis.form.skinTextureOptions.${v}`) }))}
        value={skinTexture}
        onChange={(v) => onChange({ skinTexture: v })}
      />
      <AuthSelect
        label={t('anamnesis.form.oilinessLabel')}
        options={OILINESS_OPTIONS.map((v) => ({ value: v, label: t(`anamnesis.form.oilinessOptions.${v}`) }))}
        value={oiliness}
        onChange={(v) => onChange({ oiliness: v })}
      />
      {chipRow('anamnesis.form.discromiaLabel', DISCROMIA_OPTIONS, 'anamnesis.form.discromiaOptions', discromia, 'discromia')}
      {chipRow('anamnesis.form.vascularizationLabel', VASCULARIZATION_OPTIONS, 'anamnesis.form.vascularizationOptions', vascularization, 'vascularization')}
    </div>
  );
};

export default AnamnesisSkinFields;
