import React from 'react';

const SkeletonCard: React.FC<{ lines?: number }> = ({ lines = 2 }) => (
  <div className="bg-h-white rounded-r p-4 shadow-h-sm animate-pulse">
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-full bg-h-surface-3 flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="h-3.5 bg-h-surface-3 rounded-full w-3/4" />
        {lines >= 2 && <div className="h-2.5 bg-h-surface-3 rounded-full w-1/2" />}
      </div>
    </div>
  </div>
);

const SkeletonStats: React.FC = () => (
  <div className="grid grid-cols-2 gap-3">
    <div className="bg-h-white rounded-r-lg p-4 shadow-h-sm animate-pulse">
      <div className="h-8 bg-h-surface-3 rounded w-16 mb-2" />
      <div className="h-3 bg-h-surface-3 rounded w-20" />
    </div>
    <div className="flex flex-col gap-3">
      <div className="bg-h-white rounded-r-lg p-3 shadow-h-sm animate-pulse flex-1">
        <div className="h-5 bg-h-surface-3 rounded w-10 mb-1" />
        <div className="h-2.5 bg-h-surface-3 rounded w-16" />
      </div>
      <div className="bg-h-white rounded-r-lg p-3 shadow-h-sm animate-pulse flex-1">
        <div className="h-5 bg-h-surface-3 rounded w-10 mb-1" />
        <div className="h-2.5 bg-h-surface-3 rounded w-16" />
      </div>
    </div>
  </div>
);

export { SkeletonCard, SkeletonStats };
