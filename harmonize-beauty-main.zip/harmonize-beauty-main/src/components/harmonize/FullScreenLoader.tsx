import React from 'react';
import LogoMark from './LogoMark';

interface FullScreenLoaderProps {
  /**
   * Texto sob a marca. Só faz sentido quando a espera pode passar de um
   * instante e o silêncio viraria dúvida — é o caso do ProtectedRoute, que
   * aguarda a resolução da sessão E do perfil antes de decidir acesso. O
   * fallback de rota e o RootRoute omitem: ali a espera é o download de um
   * chunk, curta, e uma legenda que pisca incomoda mais do que informa.
   */
  label?: string;
}

// Tela cheia de carregamento com a marca pulsando. Existe como componente
// próprio porque três situações precisam exatamente do mesmo quadro e ele não
// pode divergir entre elas: a resolução da sessão em RootRoute, a espera do
// chunk de uma rota carregada sob demanda (o fallback do Suspense em App.tsx)
// e a resolução de sessão + perfil em ProtectedRoute.
//
// As três eram cópias separadas antes disto, e já haviam divergido: o
// ProtectedRoute pintava o fundo com `bg-background` enquanto as outras usavam
// `bg-h-bg`. Os dois tokens resolvem para a mesma cor a dois valores de
// distância (rgb(240 237 235) contra rgb(238 236 234)) — invisível na tela, e
// exatamente por isso capaz de ficar anos sem ninguém notar. Um lugar só, com
// o token de marca que os outros 23 arquivos do app usam.
//
// A marca em vez de um spinner genérico é deliberado: é o primeiro frame que o
// profissional vê ao abrir o app instalado como PWA, e um spinner anônimo ali
// faz parecer que abriu a coisa errada.
const FullScreenLoader: React.FC<FullScreenLoaderProps> = ({ label }) => (
  <div className="min-h-screen bg-h-bg flex flex-col items-center justify-center gap-3">
    <div className="animate-pulse">
      <LogoMark size={40} />
    </div>
    {label ? <p className="text-h-text-2 text-[13px] font-medium">{label}</p> : null}
  </div>
);

export default FullScreenLoader;
