import { describe, it, expect, vi, beforeAll, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';
import i18n from '@/i18n';
import BeforeAfterViewer from './BeforeAfterViewer';

beforeAll(async () => {
  await act(async () => {
    await i18n.changeLanguage('pt');
  });
});

// jsdom doesn't implement canvas 2D rendering; stub just enough of the API
// so the draw-mode canvas can mount/redraw without noisy "not implemented"
// errors, letting tests focus on component behaviour.
const originalGetContext = HTMLCanvasElement.prototype.getContext;
beforeEach(() => {
  HTMLCanvasElement.prototype.getContext = vi.fn(() => ({
    clearRect: vi.fn(),
    beginPath: vi.fn(),
    moveTo: vi.fn(),
    lineTo: vi.fn(),
    stroke: vi.fn(),
  })) as unknown as typeof HTMLCanvasElement.prototype.getContext;
});
afterEach(() => {
  HTMLCanvasElement.prototype.getContext = originalGetContext;
});

function mockRect(el: Element, width: number, height: number) {
  el.getBoundingClientRect = () =>
    ({
      width,
      height,
      left: 0,
      top: 0,
      right: width,
      bottom: height,
      x: 0,
      y: 0,
      toJSON: () => ({}),
    }) as DOMRect;
}

describe('BeforeAfterViewer', () => {
  it('renders all 5 mode tabs with the slider selected by default', () => {
    render(<BeforeAfterViewer />);
    expect(screen.getAllByRole('tab')).toHaveLength(5);
    expect(screen.getByTestId('mode-tab-slider')).toHaveAttribute('aria-selected', 'true');
    ['sideBySide', 'fade', 'xray', 'draw'].forEach((m) => {
      expect(screen.getByTestId(`mode-tab-${m}`)).toHaveAttribute('aria-selected', 'false');
    });
  });

  it('falls back to a placeholder (no <img>) when no photo URLs are given, in every mode', () => {
    const { container } = render(<BeforeAfterViewer />);
    expect(container.querySelector('img')).toBeNull();

    fireEvent.click(screen.getByTestId('mode-tab-sideBySide'));
    expect(container.querySelector('img')).toBeNull();

    fireEvent.click(screen.getByTestId('mode-tab-fade'));
    expect(container.querySelector('img')).toBeNull();

    fireEvent.click(screen.getByTestId('mode-tab-xray'));
    expect(container.querySelector('img')).toBeNull();

    fireEvent.click(screen.getByTestId('mode-tab-draw'));
    expect(container.querySelector('img')).toBeNull();
  });

  it('renders real photos in every mode when URLs are provided', () => {
    const props = {
      beforeImageUrl: 'https://example.com/before.jpg',
      afterImageUrl: 'https://example.com/after.jpg',
    };
    const { container } = render(<BeforeAfterViewer {...props} />);
    expect(container.querySelectorAll('img').length).toBeGreaterThan(0);

    fireEvent.click(screen.getByTestId('mode-tab-sideBySide'));
    expect(container.querySelectorAll('img').length).toBe(2);

    fireEvent.click(screen.getByTestId('mode-tab-fade'));
    expect(container.querySelectorAll('img').length).toBe(2);
  });

  it('switches to side-by-side mode', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-sideBySide'));
    expect(screen.getByTestId('mode-tab-sideBySide')).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByTestId('mode-tab-slider')).toHaveAttribute('aria-selected', 'false');
  });

  it('switches to fade mode and exposes a blend range control', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-fade'));
    const range = screen.getByTestId('fade-range') as HTMLInputElement;
    expect(range).toBeInTheDocument();
    fireEvent.change(range, { target: { value: '80' } });
    expect(range.value).toBe('80');
  });

  it('switches to x-ray mode: no lens until the pointer moves over the photo', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-xray'));
    expect(screen.getByTestId('xray-lens-area')).toBeInTheDocument();
    expect(screen.queryByTestId('xray-lens')).toBeNull();
  });

  it('shows the magnifier lens once the cursor moves over the x-ray photo', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-xray'));
    const area = screen.getByTestId('xray-lens-area');
    mockRect(area, 300, 400);
    fireEvent.mouseMove(area, { clientX: 150, clientY: 200 });
    expect(screen.getByTestId('xray-lens')).toBeInTheDocument();
    fireEvent.mouseLeave(area);
    expect(screen.queryByTestId('xray-lens')).toBeNull();
  });

  it('switches to draw mode and shows the temporary-annotation notice plus controls', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-draw'));
    expect(screen.getByTestId('draw-notice')).toBeInTheDocument();
    expect(screen.getByTestId('draw-canvas')).toBeInTheDocument();
    expect(screen.getByTestId('draw-clear')).toBeInTheDocument();
    expect(screen.getByTestId('draw-done')).toBeInTheDocument();
  });

  it('returns to the default mode when "done" is pressed in draw mode', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-draw'));
    expect(screen.getByTestId('mode-tab-draw')).toHaveAttribute('aria-selected', 'true');
    fireEvent.click(screen.getByTestId('draw-done'));
    expect(screen.getByTestId('mode-tab-slider')).toHaveAttribute('aria-selected', 'true');
  });

  it('lets the user pick a stroke color before drawing', () => {
    render(<BeforeAfterViewer />);
    fireEvent.click(screen.getByTestId('mode-tab-draw'));
    const redSwatch = screen.getByTestId('draw-color-#E05050');
    fireEvent.click(redSwatch);
    expect(redSwatch).toHaveAttribute('aria-pressed', 'true');
  });

  it('renders translated copy for the active locale (pt) and updates it after a language switch', async () => {
    render(<BeforeAfterViewer />);
    expect(screen.getByTestId('mode-tab-slider')).toHaveTextContent('Slider');
    expect(screen.getByTestId('mode-tab-draw')).toHaveTextContent('Riscar');

    fireEvent.click(screen.getByTestId('mode-tab-draw'));
    expect(screen.getByTestId('draw-notice')).toHaveTextContent(
      'Ferramenta de anotação temporária — não faz parte do resultado real',
    );

    await act(async () => {
      await i18n.changeLanguage('en');
    });
    expect(screen.getByTestId('mode-tab-draw')).toHaveTextContent('Draw');
    expect(screen.getByTestId('draw-notice')).toHaveTextContent('Temporary annotation tool');

    await act(async () => {
      await i18n.changeLanguage('pt');
    });
  });
});
