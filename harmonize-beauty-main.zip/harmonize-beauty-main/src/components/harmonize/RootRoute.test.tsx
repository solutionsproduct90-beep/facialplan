import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import RootRoute from './RootRoute';

const useAuthMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/pages/site/LandingPage', () => ({
  default: () => <div>Landing institucional</div>,
}));

// Renderiza "/" dentro de um <Routes> real com um stub em "/inicio", pra
// poder observar pra onde o <Navigate> de RootRoute efetivamente manda o
// usuário autenticado — RootRoute não renderiza mais o dashboard direto,
// só decide entre a landing e o redirect (ver App.tsx pra rota real).
function renderAtRoot() {
  return render(
    <MemoryRouter initialEntries={['/']}>
      <Routes>
        <Route path="/" element={<RootRoute />} />
        <Route path="/inicio" element={<div>Dashboard protegido</div>} />
      </Routes>
    </MemoryRouter>
  );
}

describe('RootRoute', () => {
  beforeEach(() => {
    useAuthMock.mockReset();
  });

  it('mostra a landing institucional para visitante sem sessão', () => {
    useAuthMock.mockReturnValue({ user: null, loading: false });

    renderAtRoot();

    expect(screen.getByText('Landing institucional')).toBeInTheDocument();
    expect(screen.queryByText('Dashboard protegido')).not.toBeInTheDocument();
  });

  it('redireciona pra /inicio quando há usuário autenticado, sem renderizar o app em "/"', () => {
    useAuthMock.mockReturnValue({ user: { id: 'user-1' }, loading: false });

    renderAtRoot();

    expect(screen.getByText('Dashboard protegido')).toBeInTheDocument();
    expect(screen.queryByText('Landing institucional')).not.toBeInTheDocument();
  });

  it('não decide nada enquanto a sessão ainda está carregando', () => {
    useAuthMock.mockReturnValue({ user: null, loading: true });

    renderAtRoot();

    expect(screen.queryByText('Landing institucional')).not.toBeInTheDocument();
    expect(screen.queryByText('Dashboard protegido')).not.toBeInTheDocument();
  });
});
