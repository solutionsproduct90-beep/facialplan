import React from 'react';
import { useTranslation } from 'react-i18next';
import { Switch } from '@/components/ui/switch';
import { usePushNotifications } from '@/hooks/usePushNotifications';

/**
 * Toggle de "Ativar notificações push" — usado no Perfil (ver Perfil.tsx).
 * Componente fino em cima de usePushNotifications: só decide o que mostrar
 * para cada `status`, toda a lógica de permissão/inscrição/Supabase vive no
 * hook.
 */
const PushNotificationsToggle: React.FC = () => {
  const { t } = useTranslation();
  const { status, loading, enable, disable } = usePushNotifications();

  const handleChange = (checked: boolean) => {
    if (loading) return;
    if (checked) {
      void enable();
    } else {
      void disable();
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[14px] font-semibold text-h-text">{t('profile.pushNotifications.title')}</p>
          <p className="text-[12px] text-h-text-3">{t('profile.pushNotifications.subtitle')}</p>
        </div>
        <Switch
          checked={status === 'enabled'}
          onCheckedChange={handleChange}
          disabled={loading || status === 'unsupported' || status === 'denied'}
          aria-label={t('profile.pushNotifications.title')}
        />
      </div>

      {status === 'denied' && (
        <p className="text-[11px] text-h-text-3">{t('profile.pushNotifications.deniedHint')}</p>
      )}
      {status === 'unsupported' && (
        <p className="text-[11px] text-h-text-3">{t('profile.pushNotifications.unsupportedHint')}</p>
      )}
      {/* Limitação conhecida do Safari/iOS (ver comentário completo em
          usePushNotifications.ts) — mostrada só enquanto o toggle ainda não
          foi ativado (quando `status === 'unsupported'` a mensagem acima já
          cobre o mesmo aviso, então não repete aqui). */}
      {status === 'idle' && (
        <p className="text-[11px] text-h-text-3">{t('profile.pushNotifications.iosHint')}</p>
      )}
    </div>
  );
};

export default PushNotificationsToggle;
