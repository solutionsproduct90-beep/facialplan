import React from 'react';
import { Mic, MicOff, Square } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useVoiceDictation } from '@/hooks/useVoiceDictation';

// Mapeia o idioma da UI (i18n, ex. "pt") para a tag BCP-47 que a Web Speech
// API espera (ex. "pt-BR") — mesmos 5 idiomas suportados pelo app (ver
// SUPPORTED_LANGUAGES em src/i18n/index.ts).
const LANGUAGE_TO_BCP47: Record<string, string> = {
  pt: 'pt-BR',
  en: 'en-US',
  es: 'es-ES',
  fr: 'fr-FR',
  it: 'it-IT',
};

interface VoiceDictationButtonProps {
  /** Valor atual do campo de texto controlado que recebe o ditado. */
  value: string;
  /** Chamado com o texto completo (valor anterior + transcrição) a cada atualização do reconhecimento. */
  onTranscript: (text: string) => void;
  /** BCP-47 explícito; por padrão deriva do idioma ativo da UI. */
  lang?: string;
  className?: string;
}

/**
 * Botão de microfone para ditar observações clínicas por voz em vez de
 * digitar — útil com o paciente na frente. Usa a Web Speech API nativa do
 * navegador (`SpeechRecognition`/`webkitSpeechRecognition`): 100%
 * client-side, sem enviar áudio a nenhum serviço (não é a mesma coisa que a
 * edge function `analyze-face`, que analisa fotos, não voz — ver
 * useVoiceDictation).
 *
 * Suporte varia por navegador (Chrome/Edge sim; Firefox e Safari não ou só
 * parcialmente) — quando a API não existe em `window`, renderiza desabilitado
 * com tooltip explicando em vez de simplesmente sumir, para o profissional
 * entender por que o recurso não está disponível.
 */
const VoiceDictationButton: React.FC<VoiceDictationButtonProps> = ({
  value,
  onTranscript,
  lang,
  className = '',
}) => {
  const { t, i18n } = useTranslation();
  const recognitionLang = lang || LANGUAGE_TO_BCP47[i18n.language] || 'pt-BR';
  const { isSupported, isRecording, start, stop } = useVoiceDictation({
    value,
    onTranscript,
    lang: recognitionLang,
  });

  if (!isSupported) {
    return (
      <button
        type="button"
        disabled
        title={t('voiceDictation.unsupportedTooltip')}
        aria-label={t('voiceDictation.unsupportedTooltip')}
        className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-h-text-3 opacity-40 cursor-not-allowed flex-shrink-0 ${className}`}
      >
        <MicOff size={16} />
      </button>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 flex-shrink-0">
      <button
        type="button"
        onClick={isRecording ? stop : start}
        aria-pressed={isRecording}
        aria-label={isRecording ? t('voiceDictation.stop') : t('voiceDictation.start')}
        title={isRecording ? t('voiceDictation.stop') : t('voiceDictation.start')}
        className={`inline-flex items-center justify-center w-8 h-8 rounded-full transition-colors press-scale ${
          isRecording
            ? 'bg-red-500 text-white'
            : 'text-h-g-mid hover:bg-h-surface-3/40'
        } ${className}`}
      >
        {isRecording ? <Square size={13} fill="currentColor" /> : <Mic size={16} />}
      </button>
      {isRecording && (
        <span role="status" className="text-[11px] font-medium text-red-500 animate-pulse">
          {t('voiceDictation.recording')}
        </span>
      )}
    </span>
  );
};

export default VoiceDictationButton;
