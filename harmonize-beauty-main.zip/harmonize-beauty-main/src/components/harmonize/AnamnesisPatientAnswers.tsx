import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  COMPOSITE_RISK_KEYS,
  SIMPLE_RISK_KEYS,
  type CompositeRiskKey,
  type PriorSurgery,
  type RiskFlags,
  type SimpleRiskKey,
  type YesNoWhich,
} from '@/types/anamnesis';

interface AnamnesisPatientAnswersProps {
  riskFlags: RiskFlags | null | undefined;
  /**
   * Chaves de pergunta habilitadas para este profissional (ver
   * `anamnesis_question_settings` / PerfilAnamnese.tsx). `undefined` mantém
   * o comportamento padrão de mostrar todas as 18 perguntas — usado antes
   * das configurações carregarem, para nunca esconder uma resposta já dada
   * por engano.
   */
  enabledKeys?: ReadonlySet<string>;
}

/**
 * Lista completa (não só os riscos ativos, ao contrário de
 * `AnamnesisRiskBanner`) das respostas do paciente — somente leitura. É a
 * peça central da separação "Anamnese do Paciente" (histórico respondido
 * pelo paciente) vs. "Avaliação Clínica" (preenchida pelo profissional):
 * o profissional NUNCA edita essas respostas por aqui, só visualiza.
 */
const AnamnesisPatientAnswers: React.FC<AnamnesisPatientAnswersProps> = ({ riskFlags, enabledKeys }) => {
  const { t } = useTranslation();
  const flags = riskFlags ?? {};
  const isEnabled = (key: string) => !enabledKeys || enabledKeys.has(key);

  const Row: React.FC<{ questionKey: string; yes: boolean; detail?: string }> = ({ questionKey, yes, detail }) => (
    <div className="py-2 flex flex-col gap-0.5" style={{ borderBottom: '0.5px solid rgba(0,0,0,0.05)' }}>
      <div className="flex items-start justify-between gap-3">
        <p className="text-[12px] text-h-text-2 leading-snug flex-1">{t(`anamnesis.form.questions.${questionKey}`)}</p>
        <span
          className="text-[11px] font-bold uppercase tracking-wide flex-shrink-0"
          style={{ color: yes ? '#E05050' : '#8A8884' }}
        >
          {yes ? t('common.yes') : t('common.no')}
        </span>
      </div>
      {yes && detail && <p className="text-[12px] text-h-text-3 pl-1">— {detail}</p>}
    </div>
  );

  return (
    <div className="flex flex-col">
      {(SIMPLE_RISK_KEYS as readonly SimpleRiskKey[])
        .filter((key) => isEnabled(key))
        .map((key) => (
          <Row key={key} questionKey={key} yes={!!flags[key]} />
        ))}

      {(COMPOSITE_RISK_KEYS as readonly CompositeRiskKey[])
        .filter((key) => isEnabled(key))
        .map((key) => {
          const value = flags[key] as YesNoWhich | PriorSurgery | undefined;
          const yes = !!value?.has;
          const which = (value as YesNoWhich | PriorSurgery | undefined)?.which;
          const when = (value as PriorSurgery | undefined)?.when;
          const detail = [which, when].filter(Boolean).join(' — ') || undefined;
          return <Row key={key} questionKey={key} yes={yes} detail={detail} />;
        })}
    </div>
  );
};

export default AnamnesisPatientAnswers;
