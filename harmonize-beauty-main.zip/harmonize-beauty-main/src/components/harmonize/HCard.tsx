import React from 'react';

interface HCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  // Escape hatch pra variações pontuais (ex.: o banner de alerta de
  // vencimento em EstoqueTab.tsx precisa de um fundo/borda âmbar que não
  // faz sentido virar uma classe utilitária reaproveitável em outro lugar)
  // sem duplicar o card inteiro fora do componente compartilhado.
  style?: React.CSSProperties;
}

const HCard: React.FC<HCardProps> = ({ children, className = '', onClick, style }) => (
  <div
    className={`bg-h-white rounded-r-lg p-4 shadow-h-sm ${onClick ? 'cursor-pointer press-scale' : ''} ${className}`}
    onClick={onClick}
    style={style}
  >
    {children}
  </div>
);

export default HCard;
