import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import i18n from "@/i18n";

const useAuthMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

const renderWithRouter = (initialPath = "/private") =>
  render(
    <MemoryRouter initialEntries={[initialPath]}>
      <Routes>
        <Route
          path="/private"
          element={
            <ProtectedRoute>
              <div>Conteúdo protegido</div>
            </ProtectedRoute>
          }
        />
        <Route path="/auth/login" element={<div>Tela de login</div>} />
        <Route path="/conta-bloqueada" element={<div>Tela de conta bloqueada</div>} />
        <Route path="/regularizar" element={<div>Tela de regularização</div>} />
        <Route path="/assinar" element={<div>Tela de assinatura</div>} />
      </Routes>
    </MemoryRouter>
  );

describe("ProtectedRoute", () => {
  beforeEach(async () => {
    useAuthMock.mockReset();
    // Locks the UI language to Portuguese (the app's fallback/default) so
    // assertions on rendered text are deterministic regardless of the test
    // environment's navigator language.
    await i18n.changeLanguage("pt");
  });

  it("shows a loading state while auth status is being resolved", () => {
    useAuthMock.mockReturnValue({ user: null, loading: true, profile: null, profileLoading: false });
    renderWithRouter();

    expect(screen.getByText("Carregando...")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
    expect(screen.queryByText("Tela de login")).not.toBeInTheDocument();
  });

  it("redirects to /auth/login when there is no authenticated user", () => {
    useAuthMock.mockReturnValue({ user: null, loading: false, profile: null, profileLoading: false });
    renderWithRouter();

    expect(screen.getByText("Tela de login")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
  });

  it("shows a loading state while an authenticated user's profile (access status) is still resolving", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: null,
      profileLoading: true,
    });
    renderWithRouter();

    expect(screen.getByText("Carregando...")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
    expect(screen.queryByText("Tela de login")).not.toBeInTheDocument();
  });

  it("redirects to /assinar when a user is authenticated and no profile info is available yet (fail-closed: profile/profileLoading omitted)", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Tela de assinatura")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
    expect(screen.queryByText("Tela de login")).not.toBeInTheDocument();
  });

  it("renders the protected children when the subscription is active and the account is not blocked", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: false, subscription_status: "active", role: "professional" },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Conteúdo protegido")).toBeInTheDocument();
  });

  it("redirects to /assinar for a freshly created profile with the default subscription_status ('inactive') — mandatory paywall until the Hotmart webhook activates the account", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: false, subscription_status: "inactive", role: "professional" },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Tela de assinatura")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
  });

  it("redirects to /assinar when subscription_status is null/undefined (no subscription record yet)", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: false, subscription_status: null, role: "professional" },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Tela de assinatura")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
  });

  it("does not block an admin account even with subscription_status 'inactive' (internal bypass for the team to test the app without paying)", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: false, subscription_status: "inactive", role: "admin" },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Conteúdo protegido")).toBeInTheDocument();
    expect(screen.queryByText("Tela de assinatura")).not.toBeInTheDocument();
  });

  it("redirects to /conta-bloqueada when is_blocked is true", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: true, subscription_status: "active" },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Tela de conta bloqueada")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
  });

  it.each(["past_due", "canceled", "refunded"])(
    "redirects to /regularizar when subscription_status is '%s'",
    (subscription_status) => {
      useAuthMock.mockReturnValue({
        user: { id: "user-1", email: "a@b.com" },
        loading: false,
        profile: { is_blocked: false, subscription_status },
        profileLoading: false,
      });
      renderWithRouter();

      expect(screen.getByText("Tela de regularização")).toBeInTheDocument();
      expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
    }
  );

  it("prioritizes /conta-bloqueada over /regularizar when both is_blocked and a past-due status are set", () => {
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: true, subscription_status: "past_due" },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Tela de conta bloqueada")).toBeInTheDocument();
    expect(screen.queryByText("Tela de regularização")).not.toBeInTheDocument();
  });

  it("renders the protected children when subscription_status is 'past_due' but still within the grace period", () => {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: false, subscription_status: "past_due", past_due_since: oneDayAgo },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Conteúdo protegido")).toBeInTheDocument();
    expect(screen.queryByText("Tela de regularização")).not.toBeInTheDocument();
  });

  it("redirects to /regularizar when subscription_status is 'past_due' and the grace period has already elapsed", () => {
    const fiveDaysAgo = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString();
    useAuthMock.mockReturnValue({
      user: { id: "user-1", email: "a@b.com" },
      loading: false,
      profile: { is_blocked: false, subscription_status: "past_due", past_due_since: fiveDaysAgo },
      profileLoading: false,
    });
    renderWithRouter();

    expect(screen.getByText("Tela de regularização")).toBeInTheDocument();
    expect(screen.queryByText("Conteúdo protegido")).not.toBeInTheDocument();
  });
});
