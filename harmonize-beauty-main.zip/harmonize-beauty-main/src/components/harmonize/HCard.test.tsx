import React from "react";
import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import HCard from "./HCard";

describe("HCard", () => {
  it("renders children content", () => {
    render(<HCard>Hello world</HCard>);
    expect(screen.getByText("Hello world")).toBeInTheDocument();
  });

  it("merges a custom className with the default classes", () => {
    render(<HCard className="custom-class">Content</HCard>);
    const el = screen.getByText("Content");
    expect(el).toHaveClass("custom-class");
    expect(el).toHaveClass("bg-h-white");
  });

  it("does not add pointer/press-scale classes when no onClick is given", () => {
    render(<HCard>No click</HCard>);
    const el = screen.getByText("No click");
    expect(el).not.toHaveClass("cursor-pointer");
    expect(el).not.toHaveClass("press-scale");
  });

  it("adds pointer/press-scale classes when onClick is provided", () => {
    render(<HCard onClick={() => {}}>Clickable</HCard>);
    const el = screen.getByText("Clickable");
    expect(el).toHaveClass("cursor-pointer");
    expect(el).toHaveClass("press-scale");
  });

  it("calls onClick when clicked", () => {
    const onClick = vi.fn();
    render(<HCard onClick={onClick}>Click me</HCard>);

    fireEvent.click(screen.getByText("Click me"));

    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("does not throw when clicked without an onClick handler", () => {
    render(<HCard>Static</HCard>);
    expect(() => fireEvent.click(screen.getByText("Static"))).not.toThrow();
  });
});
