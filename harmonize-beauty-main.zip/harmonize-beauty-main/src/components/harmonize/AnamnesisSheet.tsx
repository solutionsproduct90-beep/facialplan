import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import BottomSheet from '@/components/harmonize/BottomSheet';
import GradientButton from '@/components/harmonize/GradientButton';
import AnamnesisRiskFields from '@/components/harmonize/AnamnesisRiskFields';
import AnamnesisSkinFields, { type AnamnesisSkinValues } from '@/components/harmonize/AnamnesisSkinFields';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useEnabledAnamnesisQuestionKeys } from '@/hooks/useAnamnesisQuestionSettings';
import { EMPTY_RISK_FLAGS, type Anamnesis, type RiskFlags } from '@/types/anamnesis';
import type { Json } from '@/integrations/supabase/types';

interface AnamnesisSheetProps {
  open: boolean;
  onClose: () => void;
  patientId: string;
  initial: Anamnesis | null;
  onSaved: () => void;
  /**
   * Exceção sinalizada explicitamente: só quando NÃO existe anamnese ainda
   * (não há como/por que enviar o link — paciente já está presente, sem
   * WhatsApp, etc.) o profissional pode preencher em nome do paciente,
   * incluindo o histórico clínico (`AnamnesisRiskFields`). Quando uma
   * anamnese já existe (preenchida pelo paciente ou pelo profissional
   * anteriormente), esta sheet edita só a Avaliação Clínica — o histórico
   * do paciente nunca é reaberto para edição aqui, só visualizado
   * (ver AnamnesisPatientAnswers em PacienteDetalhe.tsx).
   */
  fillOnBehalf?: boolean;
}

/**
 * Formulário de anamnese preenchido pelo profissional direto na ficha do
 * paciente. Tem dois modos bem distintos (ver `fillOnBehalf` acima):
 *  - preenchimento em nome do paciente (sem anamnese prévia): histórico
 *    clínico + avaliação clínica, igual ao formulário público;
 *  - edição da Avaliação Clínica de uma anamnese já existente: só os campos
 *    que são sempre do profissional (tipo/textura/oleosidade de pele,
 *    discromias, vascularização) — o histórico do paciente é preservado
 *    intacto, nunca reescrito por aqui.
 *
 * `upsert` com apenas os campos abaixo: se a anamnese já existia com uma
 * foto enviada pelo paciente pelo link (photo_url), essa foto é preservada —
 * o profissional editando aqui nunca apaga a foto.
 */
const AnamnesisSheet: React.FC<AnamnesisSheetProps> = ({ open, onClose, patientId, initial, onSaved, fillOnBehalf = false }) => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [mainComplaint, setMainComplaint] = useState('');
  const [riskFlags, setRiskFlags] = useState<RiskFlags>(EMPTY_RISK_FLAGS);
  const [skin, setSkin] = useState<AnamnesisSkinValues>({
    skinType: '',
    skinTexture: '',
    oiliness: '',
    discromia: [],
    vascularization: [],
  });
  const [saving, setSaving] = useState(false);
  const enabledQuestionKeys = useEnabledAnamnesisQuestionKeys(user?.id);

  useEffect(() => {
    if (!open) return;
    setMainComplaint(initial?.main_complaint ?? '');
    setRiskFlags({ ...EMPTY_RISK_FLAGS, ...(initial?.risk_flags ?? {}) });
    setSkin({
      skinType: initial?.skin_type ?? '',
      skinTexture: initial?.skin_texture ?? '',
      oiliness: initial?.oiliness ?? '',
      discromia: initial?.discromia ?? [],
      vascularization: initial?.vascularization ?? [],
    });
  }, [open, initial]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('anamnesis').upsert(
        {
          patient_id: patientId,
          professional_id: user.id,
          main_complaint: mainComplaint || null,
          skin_type: skin.skinType || null,
          skin_texture: skin.skinTexture || null,
          oiliness: skin.oiliness || null,
          discromia: skin.discromia,
          vascularization: skin.vascularization,
          // Bug corrigido: antes `risk_flags`/`filled_by` eram sempre
          // reescritos, mesmo quando esta sheet só edita a Avaliação
          // Clínica — uma anamnese respondida pelo paciente (filled_by
          // 'patient_link') virava silenciosamente "preenchida pelo
          // profissional" ao salvar só o tipo de pele, por exemplo, e o
          // histórico do paciente podia ser sobrescrito com o estado local
          // (que em modo de edição de Avaliação Clínica nem chega a ser
          // mostrado/alterado na tela, mas ainda assim era reenviado).
          // Fora do modo `fillOnBehalf`, preserva ambos como já estavam.
          risk_flags: (fillOnBehalf ? riskFlags : (initial?.risk_flags ?? riskFlags)) as unknown as Json,
          filled_by: fillOnBehalf || !initial ? 'professional' : initial.filled_by,
        },
        { onConflict: 'patient_id' },
      );
      if (error) throw error;
      toast.success(t('anamnesis.form.saved'));
      onSaved();
      onClose();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('anamnesis.form.errorSaving');
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={fillOnBehalf ? t('anamnesis.form.title') : t('anamnesis.detail.clinicalSectionTitle')}
    >
      <div style={{ padding: '0 20px 24px' }} className="flex flex-col gap-5">
        <div className="flex flex-col gap-1.5">
          <label className="text-[13px] font-semibold text-h-text-2">{t('anamnesis.form.mainComplaintLabel')}</label>
          <textarea
            value={mainComplaint}
            onChange={(e) => setMainComplaint(e.target.value)}
            placeholder={t('anamnesis.form.mainComplaintPlaceholder')}
            rows={3}
            className="w-full rounded-[12px] p-3 text-[14px] bg-h-white border border-black/10 outline-none"
          />
        </div>

        {fillOnBehalf && (
          <div>
            <p className="text-[13px] font-bold text-h-text mb-1">{t('anamnesis.form.riskSectionTitle')}</p>
            <p className="text-[11px] text-h-text-3 mb-2">{t('anamnesis.form.fillOnBehalfNote')}</p>
            <AnamnesisRiskFields value={riskFlags} onChange={setRiskFlags} enabledKeys={enabledQuestionKeys} />
          </div>
        )}

        <div>
          <p className="text-[13px] font-bold text-h-text mb-2">{t('anamnesis.detail.clinicalSectionTitle')}</p>
          <AnamnesisSkinFields {...skin} onChange={(patch) => setSkin((prev) => ({ ...prev, ...patch }))} />
        </div>

        <GradientButton onClick={handleSave} disabled={saving}>
          {saving ? t('anamnesis.form.saving') : t('anamnesis.form.save')}
        </GradientButton>
      </div>
    </BottomSheet>
  );
};

export default AnamnesisSheet;
