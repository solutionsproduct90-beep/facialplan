import React from 'react';
import { useTranslation } from 'react-i18next';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '@/hooks/useOnlineStatus';

/**
 * Item de backlog "Modo offline-first (PWA) pra sala de procedimento":
 * aviso global de estado online/offline do navegador (via
 * `useOnlineStatus`). O cache local (IndexedDB) do progresso de uma sessão
 * em andamento e a sincronização automática com o Supabase, entregues numa
 * onda posterior, vivem em `useOfflineSessionDraft`
 * (src/hooks/useOfflineSessionDraft.ts) — este banner continua só o aviso
 * genérico de conectividade; o indicador de "salvo localmente, aguardando
 * sincronização" de uma sessão específica é o `PendingSyncIndicator`
 * complementar (src/components/harmonize/PendingSyncIndicator.tsx),
 * renderizado dentro das próprias telas de sessão (não aqui, que não sabe
 * de rascunhos por sessão). Ainda NÃO implementa service worker (assets
 * offline) — fora de escopo desta fatia.
 *
 * Deliberadamente não-bloqueante: some sozinho quando a conexão volta e
 * nunca impede o uso do app (o profissional pode continuar navegando e
 * tentando ações mesmo offline — elas é que podem falhar, daí o aviso).
 * Fica fixo no topo, acima do resto do layout, sem empurrar conteúdo (usa
 * position: fixed) para não recalcular os offsets de header já usados em
 * AppLayout/App.tsx (ver comentário do Toaster em App.tsx).
 */
const OfflineBanner: React.FC = () => {
  const { t } = useTranslation();
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-center gap-2 px-4 py-2 text-center text-[13px] font-semibold text-white"
      style={{
        background: '#D4900A',
        paddingTop: 'calc(env(safe-area-inset-top, 0px) + 8px)',
      }}
    >
      <WifiOff size={15} className="shrink-0" />
      <span>{t('offline.banner')}</span>
    </div>
  );
};

export default OfflineBanner;
