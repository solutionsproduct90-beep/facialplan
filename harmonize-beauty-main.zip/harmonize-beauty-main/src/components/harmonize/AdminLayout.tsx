import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import LogoMark from '@/components/harmonize/LogoMark';
import HarmonizeBadge from '@/components/harmonize/Badge';
import { LogOut } from 'lucide-react';

const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);

  const NAV_LINKS = [
    { path: '/admin', label: t('admin.nav.dashboard') },
    { path: '/admin/usuarios', label: t('admin.nav.users') },
    { path: '/admin/metricas', label: t('admin.nav.metrics') },
    { path: '/admin/erros', label: t('admin.nav.errors') },
    { path: '/admin/auditoria', label: t('admin.nav.audit') },
    { path: '/admin/inteligencia', label: t('admin.nav.intelligence') },
    // Compras da Hotmart que chegaram sem dono (squad w1-5). Fica no nav, e
    // não escondido dentro de Usuários, porque é uma FILA: cada linha aqui é
    // alguém que pagou e está vendo paywall — tem que doer estar cheia.
    { path: '/admin/compras-pendentes', label: t('admin.nav.pendingPurchases') },
  ];

  useEffect(() => {
    if (loading) return;
    if (!user) { navigate('/auth/login'); return; }

    const checkAdmin = async () => {
      const { data } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();
      if (data?.role !== 'admin') {
        navigate('/inicio');
      } else {
        setIsAdmin(true);
      }
    };
    checkAdmin();
  }, [user, loading, navigate]);

  if (loading || isAdmin === null) {
    return (
      <div className="min-h-screen bg-h-surface flex items-center justify-center">
        <div className="animate-pulse"><LogoMark size={48} /></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-h-surface">
      {/* Top nav */}
      <header
        className="fixed top-0 left-0 right-0 z-50 h-[56px] flex items-center justify-between px-5"
        style={{
          backgroundColor: 'rgba(247,246,244,0.96)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '0.5px solid rgba(0,0,0,0.06)',
        }}
      >
        <div className="flex items-center gap-3">
          <LogoMark size={28} />
          <span className="text-[16px] font-extrabold text-h-text">FacialPlan</span>
          <HarmonizeBadge variant="grad">Admin</HarmonizeBadge>
        </div>

        <div className="flex items-center gap-1">
          {NAV_LINKS.map(link => {
            const isActive = location.pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`px-3 py-1.5 text-[13px] font-semibold rounded-full transition-all ${
                  isActive ? 'text-gradient' : 'text-h-text-3 hover:text-h-text-2'
                }`}
                style={isActive ? { borderBottom: '2px solid transparent', backgroundImage: 'linear-gradient(135deg, #E05C8A, #A855B5, #7C5AC2)', backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' } : {}}
              >
                {link.label}
              </Link>
            );
          })}
        </div>

        <button onClick={signOut} className="min-h-[44px] min-w-[44px] flex items-center justify-center text-h-text-3">
          <LogOut size={18} />
        </button>
      </header>

      <main className="pt-[56px] max-w-[900px] mx-auto w-full px-5 py-6">
        {children}
      </main>
    </div>
  );
};

export default AdminLayout;
