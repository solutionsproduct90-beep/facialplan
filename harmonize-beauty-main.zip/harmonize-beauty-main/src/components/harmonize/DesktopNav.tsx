import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import LogoMark from '@/components/harmonize/LogoMark';
import { navItems, isNavItemActive } from '@/components/harmonize/navItems';

/**
 * Navegação de topo para telas md: (~768px) e maiores: logo à esquerda,
 * itens de navegação horizontais (ícone + texto lado a lado) à direita.
 * Substitui a BottomNav — pensada pra polegar em mobile — em telas grandes.
 */
const DesktopNav: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();

  return (
    <div
      className="hidden md:flex fixed top-0 left-0 right-0 z-[60] items-center justify-between px-8 h-16"
      style={{
        backgroundColor: 'rgba(247,246,244,0.96)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderBottom: '0.5px solid rgba(0,0,0,0.06)',
      }}
    >
      <button
        onClick={() => navigate('/inicio')}
        className="flex items-center gap-2.5 min-h-[44px]"
      >
        <LogoMark size={32} />
        <span style={{ fontSize: 17, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
          FacialPlan
        </span>
      </button>

      <nav className="flex items-center gap-1">
        {navItems.map((item) => {
          const isActive = isNavItemActive(item.path, location.pathname);
          const Icon = item.icon;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex items-center gap-2 h-10 px-4 rounded-full transition-colors min-h-[44px]"
              style={{ background: isActive ? 'rgba(168,85,181,0.10)' : 'transparent' }}
            >
              <Icon
                size={18}
                strokeWidth={isActive ? 2.5 : 1.75}
                style={{ color: isActive ? '#A855B5' : '#6B6965' }}
              />
              <span
                className="text-[13.5px]"
                style={{ fontWeight: isActive ? 700 : 600, color: isActive ? '#A855B5' : '#6B6965' }}
              >
                {t(item.labelKey)}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default DesktopNav;
