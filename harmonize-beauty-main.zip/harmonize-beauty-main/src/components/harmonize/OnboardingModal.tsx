import React, { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { UserPlus, ListChecks, Camera, Sparkles, LucideIcon } from 'lucide-react';
import BottomSheet from '@/components/harmonize/BottomSheet';
import GradientButton from '@/components/harmonize/GradientButton';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface OnboardingModalProps {
  open: boolean;
  // Chamado assim que o profissional pula/conclui/fecha o modal (botão ou
  // swipe-down/backdrop) — o componente pai deve esconder o modal na hora;
  // a gravação em `profiles.onboarding_completed_at` roda em paralelo (ver
  // comentário em `finish`), então esta prop não recebe o resultado dela.
  onDismiss: () => void;
}

// Um ícone por passo, na mesma ordem de `onboarding.steps.step1..4` no i18n
// — ver PENDING: mantenha as duas listas em sincronia se adicionar/remover
// um passo.
const STEP_ICONS: LucideIcon[] = [UserPlus, ListChecks, Camera, Sparkles];

/**
 * Onboarding leve, exibido uma única vez logo após o profissional confirmar
 * a conta (ver Home.tsx). V1 é só informativa — explica o fluxo principal
 * (Pacientes → Sessão → Estágio 1/2/3) em 4 telas de wizard, sem spotlight
 * sobre elementos reais da UI. Pular/fechar a qualquer momento marca como
 * visto do mesmo jeito que concluir o último passo, então nada aqui é
 * bloqueante.
 */
const OnboardingModal: React.FC<OnboardingModalProps> = ({ open, onDismiss }) => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(0);

  // Reseta pro primeiro passo toda vez que o modal reabre (evita reabrir já
  // no último passo se a pessoa tiver navegado nele numa sessão anterior —
  // hoje isso nunca deveria acontecer, já que fechar sempre marca como
  // completo, mas é uma garantia barata).
  useEffect(() => {
    if (open) setStep(0);
  }, [open]);

  const steps = STEP_ICONS.map((Icon, i) => ({
    Icon,
    title: t(`onboarding.steps.step${i + 1}.title`),
    description: t(`onboarding.steps.step${i + 1}.description`),
  }));
  const isLastStep = step === steps.length - 1;
  const current = steps[step];

  const finish = () => {
    // Esconde o modal já — não faz a pessoa esperar a resposta do banco pra
    // seguir usando o app. Se o UPDATE falhar (rede, RLS), o pior caso é o
    // onboarding reaparecer no próximo login, não travar a navegação agora.
    onDismiss();
    if (!user) return;

    const completedAt = new Date().toISOString();

    // Achado do QA Contínuo (ciclo 52): `onDismiss()` sozinho não bastava. Ele
    // só troca um `useState` LOCAL ao Home (`onboardingDismissed`), e App.tsx
    // renderiza `<Routes key={location.pathname}>` — a `key` no pathname
    // remonta a árvore de rotas inteira a cada navegação. Ou seja: dispensar o
    // onboarding, ir pra qualquer outra aba e voltar pra Início desmontava o
    // Home, zerava aquele estado, e o card de boas-vindas reaparecia. O
    // comentário acima já dizia que o pior caso era "reaparecer no próximo
    // login"; na prática reaparecia a cada ida e volta.
    //
    // A causa é que `showOnboarding`, em Home.tsx, deriva do cache do React
    // Query (`['profile', user.id]`), e este UPDATE nunca tocava esse cache.
    // Escrever o valor ali resolve na origem, porque é de onde a decisão de
    // exibir vem — e sobrevive ao remount, que é justamente o que o estado
    // local não fazia.
    queryClient.setQueryData(
      ['profile', user.id],
      (anterior: Record<string, unknown> | null | undefined) =>
        anterior ? { ...anterior, onboarding_completed_at: completedAt } : anterior,
    );

    // `.then()` não é decoração: o builder do postgrest-js é preguiçoso e só
    // constrói o fetch dentro dele. Descartar a cadeia com `void`, como este
    // trecho fazia, nunca mandava o UPDATE — a coluna ficava NULL para
    // sempre, e o onboarding voltava a cada login novo e em cada dispositivo.
    // Ver src/lib/logClientError.ts para a explicação completa e
    // src/test/fireAndForgetSupabase.test.ts para a trava.
    supabase
      .from('profiles')
      .update({ onboarding_completed_at: completedAt })
      .eq('id', user.id)
      .then(
        () => {},
        () => {},
      );
  };

  return (
    <BottomSheet open={open} onClose={finish} title={t('onboarding.title')}>
      <div style={{ padding: '4px 20px 20px', display: 'flex', flexDirection: 'column', gap: 20 }}>
        <div className="flex flex-col items-center text-center gap-3" style={{ padding: '8px 0' }}>
          <div
            style={{
              width: 64, height: 64, borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'rgba(168,85,181,0.10)', flexShrink: 0,
            }}
          >
            <current.Icon size={28} style={{ color: '#A855B5' }} />
          </div>
          <h3 style={{ fontSize: 18, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
            {current.title}
          </h3>
          <p style={{ fontSize: 14, color: '#6B6965', lineHeight: 1.5 }}>
            {current.description}
          </p>
        </div>

        {/* Indicador de progresso (bolinhas) */}
        <div className="flex items-center justify-center gap-2" role="presentation">
          {steps.map((_, i) => (
            <div
              key={i}
              style={{
                width: i === step ? 18 : 6, height: 6, borderRadius: 3,
                background: i === step ? '#BF5F82' : '#E5E3E0',
                transition: 'width 0.2s ease, background-color 0.2s ease',
              }}
            />
          ))}
        </div>

        <div className="flex flex-col gap-2">
          <GradientButton onClick={() => (isLastStep ? finish() : setStep((s) => s + 1))}>
            {isLastStep ? t('onboarding.done') : t('onboarding.next')}
          </GradientButton>
          <button
            type="button"
            onClick={finish}
            style={{
              minHeight: 44, background: 'none', border: 'none', cursor: 'pointer',
              fontSize: 13, fontWeight: 600, color: '#AAA8A5',
            }}
          >
            {t('onboarding.skip')}
          </button>
        </div>
      </div>
    </BottomSheet>
  );
};

export default OnboardingModal;
