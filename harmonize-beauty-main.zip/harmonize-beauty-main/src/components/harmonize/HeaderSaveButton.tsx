import React from 'react';
import { useTranslation } from 'react-i18next';
import GradientButton from '@/components/harmonize/GradientButton';

interface HeaderSaveButtonProps {
  onClick: () => void;
  saving: boolean;
  disabled?: boolean;
}

/**
 * "Salvar" solid pill for a screen's TopBar `rightAction`. A previous
 * version used a plain small pink text link there
 * (`text-[14px] font-semibold text-h-g-start`) that professionals reported
 * as "quase não dá pra ver" — replaced with a filled brand-gradient pill so
 * the primary action of the screen actually reads as a button, while still
 * keeping the ≥44px tap target the old link already had.
 */
const HeaderSaveButton: React.FC<HeaderSaveButtonProps> = ({ onClick, saving, disabled }) => {
  const { t } = useTranslation();
  return (
    <GradientButton
      onClick={onClick}
      disabled={saving || disabled}
      className="!w-auto !h-auto !min-h-[44px] px-5 py-2.5 text-[13px]"
    >
      {saving ? t('profile.saving') : t('profile.save')}
    </GradientButton>
  );
};

export default HeaderSaveButton;
