import React from 'react';

interface SecondaryButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

const SecondaryButton = React.forwardRef<HTMLButtonElement, SecondaryButtonProps>(
  ({ children, className = '', ...props }, ref) => (
    <button
      ref={ref}
      className={`w-full h-[48px] min-h-[44px] rounded-full bg-h-white shadow-h-sm font-semibold text-[15px] text-h-text transition-all active:scale-[0.98] ${className}`}
      {...props}
    >
      {children}
    </button>
  )
);

SecondaryButton.displayName = 'SecondaryButton';
export default SecondaryButton;
