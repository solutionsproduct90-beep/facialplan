import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface AnamnesisRiskBannerProps {
  title: string;
  labels: string[];
  children?: React.ReactNode;
}

/**
 * Banner de alerta para os pontos de risco marcados na anamnese do paciente
 * (`anamnesis.risk_flags`). Usado em dois lugares que precisam mostrar
 * exatamente a mesma informação:
 *  - Prontuário, na ficha do paciente (PacienteDetalhe.tsx) — sempre visível
 *    no topo da seção, nunca escondido num accordion;
 *  - Etapa 1 da sessão (SessaoEstagio1.tsx) — com o checkbox de
 *    reconhecimento explícito passado via `children`.
 * Não renderiza nada se não houver nenhum ponto de risco marcado.
 */
const AnamnesisRiskBanner: React.FC<AnamnesisRiskBannerProps> = ({ title, labels, children }) => {
  if (labels.length === 0) return null;

  return (
    <div
      className="rounded-r p-4"
      style={{ background: 'rgba(224,80,80,0.08)', border: '1px solid rgba(224,80,80,0.24)' }}
    >
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle size={16} style={{ color: '#E05050' }} />
        <p className="text-[13px] font-bold" style={{ color: '#E05050' }}>{title}</p>
      </div>
      <ul className="flex flex-col gap-1">
        {labels.map((label) => (
          <li key={label} className="text-[13px] text-h-text-2 pl-1">• {label}</li>
        ))}
      </ul>
      {children}
    </div>
  );
};

export default AnamnesisRiskBanner;
