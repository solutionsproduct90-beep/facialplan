import React, { useId } from 'react';

interface AuthInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

// O <label> PRECISA apontar para o <input>. Eram elementos irmãos, sem
// `htmlFor` nem `id` e sem aninhamento — ou seja, nenhuma associação, nem
// explícita nem implícita. Quem usa leitor de tela focava o campo e não ouvia
// nada que dissesse qual campo era aquele; o texto do rótulo era lido solto,
// antes, sem vínculo. Em Login e Cadastro, com dois campos seguidos, isso
// significa não conseguir distinguir e-mail de senha (achado do ciclo 56 do
// QA Contínuo, reproduzido ao vivo: `getByLabel(/E-mail/i)`, que usa o mesmo
// algoritmo de nome acessível de um leitor de tela, não encontrava o campo).
//
// Este componente é o campo de texto de TODO o fluxo de autenticação — a
// primeira tela que qualquer pessoa vê antes de conseguir usar o produto — e
// também dos formulários de paciente, leads e mini-site.
//
// `useId` em vez de um id recebido por prop: nenhum dos oito chamadores passa
// id, e gerar aqui mantém a correção contida no componente. Um id vindo por
// props ainda vence, pelo spread de `props` no input — por isso o `htmlFor`
// usa o mesmo valor resolvido.
const AuthInput = React.forwardRef<HTMLInputElement, AuthInputProps>(
  ({ label, className = '', ...props }, ref) => {
    const idGerado = useId();
    const inputId = props.id ?? idGerado;

    return (
    <div className="flex flex-col gap-1">
      <label htmlFor={inputId} style={{ fontSize: 12, fontWeight: 600, color: '#AAA8A5' }}>{label}</label>
      <input
        ref={ref}
        id={inputId}
        className={className}
        style={{
          height: 48,
          minHeight: 44,
          borderRadius: 12,
          padding: '0 16px',
          fontSize: 15,
          fontWeight: 500,
          fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif",
          color: '#1A1918',
          background: '#FFFFFF',
          border: '1px solid rgba(0,0,0,0.06)',
          boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
          outline: 'none',
          transition: 'box-shadow 0.2s',
        }}
        onFocus={(e) => { e.currentTarget.style.boxShadow = '0 0 0 3px rgba(168,85,181,0.12)'; }}
        onBlur={(e) => { e.currentTarget.style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)'; }}
        {...props}
      />
    </div>
    );
  }
);

AuthInput.displayName = 'AuthInput';
export default AuthInput;
