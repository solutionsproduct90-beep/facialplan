import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GhostButton from '@/components/harmonize/GhostButton';
import { formatDistanceToNow, type Locale } from 'date-fns';
import { ptBR, enUS, es } from 'date-fns/locale';

interface SessionCardProps {
  id: string;
  patientName: string;
  status: string;
  createdAt: string;
  selectedProcedure?: string | null;
  grouped?: boolean;
}

const statusVariant: Record<string, 'grad' | 'alta' | 'media' | 'baixa' | 'neutral'> = {
  stage1: 'grad',
  stage2: 'media',
  stage3: 'alta',
  complete: 'baixa',
  abandoned: 'neutral',
};

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es };

const SessionCard: React.FC<SessionCardProps> = ({ id, patientName, status, createdAt, selectedProcedure, grouped = false }) => {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const variant = statusVariant[status] || statusVariant.stage1;
  const label = t(`sessions.status.${status}` , { defaultValue: t('sessions.status.stage1') });
  const isActive = !['complete', 'abandoned'].includes(status);
  const initials = patientName.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
  const timeAgo = formatDistanceToNow(new Date(createdAt), {
    addSuffix: true,
    locale: dateFnsLocale[i18n.language] ?? ptBR,
  });

  const cardClass = grouped
    ? 'bg-transparent p-[14px] px-4 press-scale'
    : 'bg-h-white rounded-r p-[14px] px-4 shadow-h-sm press-scale';

  const stageRoutes: Record<string, string> = {
    stage1: `/sessoes/${id}/estagio-1`,
    stage2: `/sessoes/${id}/estagio-2`,
    stage3: `/sessoes/${id}/estagio-3`,
    complete: `/sessoes/${id}/present`,
  };
  // Sessões concluídas ficam salvas no banco e devem poder ser reabertas
  // (antes/depois, procedimentos, compartilhar) a qualquer momento — não
  // apenas as ativas. "abandoned" não tem uma tela de revisão pois nunca
  // chegou a gerar uma simulação.
  const isViewable = status === 'complete';

  return (
    <div className={cardClass} style={!grouped && isActive ? { borderLeft: '3px solid #BF5F82' } : {}}>
      <div className="flex items-center gap-3">
        {/* Avatar */}
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-[13px] font-bold flex-shrink-0"
          style={{
            background: isActive ? '#BF5F82' : '#E5E3E0',
            color: isActive ? '#fff' : '#6B6965',
          }}
        >
          {initials}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <p className="text-[14px] font-bold text-h-text truncate" style={{ letterSpacing: '-0.01em' }}>{patientName}</p>
          <p className="text-[11px] text-h-text-3 mt-0.5">
            {selectedProcedure ? `${selectedProcedure} · ` : ''}{timeAgo}
          </p>
        </div>

        {/* Action */}
        <div className="flex-shrink-0">
          {isActive ? (
            <button
              onClick={() => navigate(stageRoutes[status] ?? `/sessoes/${id}/estagio-1`)}
              className="h-[32px] px-3 rounded-full text-[12px] font-bold min-h-[32px]"
              style={{ backgroundColor: 'rgba(191,95,130,0.10)', color: '#BF5F82' }}
            >
              {t('sessions.card.resume')}
            </button>
          ) : isViewable ? (
            <button
              onClick={() => navigate(stageRoutes[status])}
              className="flex items-center gap-2"
            >
              <HarmonizeBadge variant={variant}>{label}</HarmonizeBadge>
              <span className="text-[12px] font-semibold text-h-g-start">
                {t('sessions.card.view')}
              </span>
            </button>
          ) : (
            <HarmonizeBadge variant={variant}>{label}</HarmonizeBadge>
          )}
        </div>
      </div>
    </div>
  );
};

export default SessionCard;
