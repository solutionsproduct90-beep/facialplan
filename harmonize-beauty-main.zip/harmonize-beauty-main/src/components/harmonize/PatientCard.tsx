import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ptBR, enUS, es, fr, it, type Locale } from 'date-fns/locale';
import HarmonizeBadge from '@/components/harmonize/Badge';
import { formatReturnRadarWindow, type ReturnRadar } from '@/lib/returnRadar';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

interface PatientCardProps {
  id: string;
  name: string;
  sessionCount: number;
  lastSessionDaysAgo: number | null;
  /** Radar de Retorno (ver src/lib/returnRadar.ts) calculado a partir da
   * última sessão CONCLUÍDA do paciente — `null`/`undefined` quando ainda não
   * há nenhuma (paciente novo, ou nenhuma sessão fechada com substância
   * reconhecida ainda), caso em que a linha simplesmente não aparece. */
  returnRadar?: ReturnRadar | null;
}

const PatientCard: React.FC<PatientCardProps> = ({ id, name, sessionCount, lastSessionDaysAgo, returnRadar }) => {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const initials = name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
  const hasSessions = sessionCount > 0;

  const meta = hasSessions
    ? t('patients.card.sessionsMeta', { count: sessionCount, days: lastSessionDaysAgo ?? '?' })
    : t('patients.card.noSessions');

  const locale = dateFnsLocale[i18n.language] ?? ptBR;

  return (
    <button
      onClick={() => navigate(`/pacientes/${id}`)}
      className="w-full bg-transparent p-[14px] px-4 text-left press-scale"
    >
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-[13px] font-bold flex-shrink-0"
          style={{
            background: '#BF5F82',
            color: '#fff',
          }}
        >
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[14px] font-bold text-h-text truncate" style={{ letterSpacing: '-0.01em' }}>{name}</p>
          <p className="text-[11px] text-h-text-3 mt-0.5">{meta}</p>
          {returnRadar && (
            <p
              className="text-[11px] mt-0.5 font-semibold"
              style={{ color: returnRadar.isOverdue ? '#E05050' : '#A855B5' }}
            >
              {returnRadar.isOverdue
                ? t('patients.card.returnRadarOverdue', { window: formatReturnRadarWindow(returnRadar, locale) })
                : t('patients.card.returnRadarUpcoming', { window: formatReturnRadarWindow(returnRadar, locale) })}
            </p>
          )}
        </div>
        <HarmonizeBadge variant={hasSessions ? 'grad' : 'neutral'}>
          {hasSessions ? t('patients.card.active') : t('patients.card.new')}
        </HarmonizeBadge>
      </div>
    </button>
  );
};

export default PatientCard;
