import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import OnboardingModal from './OnboardingModal';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const updateSpy = vi.fn();
const eqSpy = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (table: string) => ({
      update: (payload: Record<string, unknown>) => {
        updateSpy(table, payload);
        return { eq: (...args: unknown[]) => { eqSpy(...args); return Promise.resolve({ error: null }); } };
      },
    }),
  },
}));

// O modal grava no cache do React Query (ver `finish`), então precisa de um
// provider. Um client novo por caso mantém os casos independentes.
let queryClient: QueryClient;
const wrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
);
const renderModal = (ui: React.ReactElement) => render(ui, { wrapper });

describe('OnboardingModal', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    updateSpy.mockReset();
    eqSpy.mockReset();
    queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  });

  it('renders nothing meaningful when closed', () => {
    renderModal(<OnboardingModal open={false} onDismiss={() => {}} />);
    expect(screen.queryByText('Bem-vindo ao FacialPlan')).not.toBeInTheDocument();
  });

  it('shows the first step and a 4-dot progress indicator when open', () => {
    renderModal(<OnboardingModal open onDismiss={() => {}} />);

    expect(screen.getByText('Bem-vindo ao FacialPlan')).toBeInTheDocument();
    expect(screen.getByText('Cadastre seu primeiro paciente')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Avançar' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Pular' })).toBeInTheDocument();
  });

  it('walks through all 4 steps in order and shows "Começar" only on the last one', () => {
    renderModal(<OnboardingModal open onDismiss={() => {}} />);

    expect(screen.getByText('Cadastre seu primeiro paciente')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    expect(screen.getByText('Crie uma sessão')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    expect(screen.getByText('Faça upload de uma foto')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    expect(screen.getByText('A IA sugere, você decide')).toBeInTheDocument();

    // Último passo troca o rótulo do botão principal e não some o "Pular".
    expect(screen.getByRole('button', { name: 'Começar' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Avançar' })).not.toBeInTheDocument();
  });

  it('calls onDismiss and marks the profile as completed when finishing the last step', () => {
    const onDismiss = vi.fn();
    renderModal(<OnboardingModal open onDismiss={onDismiss} />);

    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    fireEvent.click(screen.getByRole('button', { name: 'Começar' }));

    expect(onDismiss).toHaveBeenCalledTimes(1);
    expect(updateSpy).toHaveBeenCalledWith('profiles', expect.objectContaining({
      onboarding_completed_at: expect.any(String),
    }));
    expect(eqSpy).toHaveBeenCalledWith('id', 'pro-1');
  });

  it('calls onDismiss and marks the profile as completed when Skip is tapped from the very first step', () => {
    const onDismiss = vi.fn();
    renderModal(<OnboardingModal open onDismiss={onDismiss} />);

    fireEvent.click(screen.getByRole('button', { name: 'Pular' }));

    expect(onDismiss).toHaveBeenCalledTimes(1);
    expect(updateSpy).toHaveBeenCalledWith('profiles', expect.objectContaining({
      onboarding_completed_at: expect.any(String),
    }));
  });

  it('does not attempt to write to profiles when there is no authenticated user yet', () => {
    useAuthMock.mockReturnValue({ user: null });
    const onDismiss = vi.fn();
    renderModal(<OnboardingModal open onDismiss={onDismiss} />);

    fireEvent.click(screen.getByRole('button', { name: 'Pular' }));

    expect(onDismiss).toHaveBeenCalledTimes(1);
    expect(updateSpy).not.toHaveBeenCalled();
  });

  it('resets back to the first step the next time it is reopened', () => {
    const { rerender } = renderModal(<OnboardingModal open onDismiss={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    expect(screen.getByText('Crie uma sessão')).toBeInTheDocument();

    rerender(<OnboardingModal open={false} onDismiss={() => {}} />);
    rerender(<OnboardingModal open onDismiss={() => {}} />);

    expect(screen.getByText('Cadastre seu primeiro paciente')).toBeInTheDocument();
  });
  // ── Regressão do ciclo 52 do QA Contínuo ─────────────────────────────────
  //
  // O bug: dispensar o onboarding só trocava um useState local ao Home, e
  // App.tsx renderiza `<Routes key={location.pathname}>` — a key no pathname
  // remonta a árvore de rotas a cada navegação, zerando aquele estado. Ir
  // pra outra aba e voltar pra Início trazia o card de boas-vindas de volta.
  //
  // Estes casos travam o conserto no lugar onde ele de fato importa: o cache
  // da query de perfil, que é de onde `showOnboarding` deriva em Home.tsx e
  // a única coisa ali que sobrevive ao remount.
  it('grava onboarding_completed_at no cache do perfil ao dispensar, para a dispensa sobreviver ao remount da rota', () => {
    queryClient.setQueryData(['profile', 'pro-1'], {
      id: 'pro-1',
      full_name: 'Dra. Teste',
      onboarding_completed_at: null,
    });

    renderModal(<OnboardingModal open onDismiss={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'Pular' }));

    const perfil = queryClient.getQueryData(['profile', 'pro-1']) as Record<string, unknown>;
    expect(perfil.onboarding_completed_at).toEqual(expect.any(String));
    // O resto do perfil não pode ser descartado no caminho: Home lê outros
    // campos desse mesmo cache.
    expect(perfil.full_name).toBe('Dra. Teste');
  });

  it('grava no cache também ao concluir o último passo, não só ao pular', () => {
    queryClient.setQueryData(['profile', 'pro-1'], { id: 'pro-1', onboarding_completed_at: null });

    renderModal(<OnboardingModal open onDismiss={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));
    fireEvent.click(screen.getByRole('button', { name: 'Começar' }));

    const perfil = queryClient.getQueryData(['profile', 'pro-1']) as Record<string, unknown>;
    expect(perfil.onboarding_completed_at).toEqual(expect.any(String));
  });

  it('usa a mesma marca de tempo no cache e no UPDATE, para o refetch não discordar do que a tela mostra', () => {
    queryClient.setQueryData(['profile', 'pro-1'], { id: 'pro-1', onboarding_completed_at: null });

    renderModal(<OnboardingModal open onDismiss={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'Pular' }));

    const perfil = queryClient.getQueryData(['profile', 'pro-1']) as Record<string, unknown>;
    const [, payload] = updateSpy.mock.calls[0] as [string, Record<string, unknown>];
    expect(perfil.onboarding_completed_at).toBe(payload.onboarding_completed_at);
  });

  it('não cria entrada no cache quando ainda não havia perfil carregado', () => {
    // Sem perfil em cache, Home nem exibiria o modal (`!!profile` na condição).
    // Inventar uma entrada parcial aqui faria a query servir um objeto sem os
    // campos que o resto da tela lê.
    renderModal(<OnboardingModal open onDismiss={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'Pular' }));

    expect(queryClient.getQueryData(['profile', 'pro-1'])).toBeUndefined();
  });
});
