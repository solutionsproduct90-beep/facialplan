import React, { useId } from 'react';
import { useTranslation } from 'react-i18next';
import SheetSelect from './SheetSelect';
import { DIAL_CODE_OPTIONS, OTHER_DIAL_CODE } from '@/lib/phone';

interface PhoneFieldProps {
  label: string;
  dial: string;
  onDialChange: (dial: string) => void;
  /** Número inteiro (com "+") digitado livremente quando `dial === OTHER_DIAL_CODE`. */
  customDial: string;
  onCustomDialChange: (value: string) => void;
  /** Número local, sem DDI — usado quando `dial` é um dos 5 mercados conhecidos. */
  local: string;
  onLocalChange: (value: string) => void;
  localPlaceholder?: string;
}

const inputClassName =
  'flex-1 min-w-0 h-[48px] min-h-[44px] rounded-r-sm px-4 text-[15px] font-normal text-h-text bg-h-white border border-h-surface-3/40 outline-none focus:ring-2 focus:ring-h-g-mid/30 placeholder:text-h-text-3';

// Campo de telefone com seletor de DDI: reaproveita o SheetSelect (mesmo
// padrão de dropdown do resto do app) pra escolher entre os 5 mercados do
// app (Brasil, EUA, Espanha, França, Itália) + "Outro", que troca o campo de
// número local por um único campo de texto livre (não dá pra separar DDI e
// número local de qualquer país do mundo com segurança sem uma lib de
// telefonia — ver comentário em src/lib/phone.ts).
const PhoneField: React.FC<PhoneFieldProps> = ({
  label,
  dial,
  onDialChange,
  customDial,
  onCustomDialChange,
  local,
  onLocalChange,
  localPlaceholder,
}) => {
  const { t } = useTranslation();

  const dialOptions = [
    ...DIAL_CODE_OPTIONS.map((o) => ({ value: o.dial, label: `${o.dial} ${t(o.labelKey)}` })),
    { value: OTHER_DIAL_CODE, label: t('patients.fields.dialCodes.other') },
  ];

  // Os dois <input> abaixo são ramos excludentes do mesmo campo (DDI "outro"
  // ou não), então compartilham o id: só um está montado por vez.
  const numeroId = useId();

  return (
    // O rótulo aponta para o campo do NÚMERO, que é o campo de verdade. O
    // seletor de DDI ao lado já tem nome próprio, pelo `title` que o
    // SheetSelect recebe — então cada controle é identificável sem precisar
    // de um grupo por cima. Uma primeira versão desta correção envolveu os
    // dois num `role="group"` também nomeado pelo rótulo, e o resultado foi
    // pior: grupo e campo passaram a ter o MESMO nome acessível, o que é
    // ambíguo para quem ouve em vez de ver.
    <div className="flex flex-col gap-1.5">
      <label htmlFor={numeroId} className="text-[13px] font-medium text-h-text-2">{label}</label>
      <div className="flex gap-2">
        <div className="w-[104px] flex-shrink-0">
          <SheetSelect
            value={dial}
            onChange={onDialChange}
            options={dialOptions}
            title={t('patients.fields.dialCodeSheetTitle')}
            className="h-[48px]"
          />
        </div>
        {dial === OTHER_DIAL_CODE ? (
          <input
            id={numeroId}
            type="tel"
            inputMode="tel"
            placeholder={t('patients.fields.dialCodeCustomPlaceholder')}
            value={customDial}
            onChange={(e) => onCustomDialChange(e.target.value)}
            className={inputClassName}
          />
        ) : (
          <input
            id={numeroId}
            type="tel"
            inputMode="tel"
            placeholder={localPlaceholder}
            value={local}
            onChange={(e) => onLocalChange(e.target.value)}
            className={inputClassName}
          />
        )}
      </div>
    </div>
  );
};

export default PhoneField;
