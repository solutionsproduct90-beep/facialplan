import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';

interface ConsentModalProps {
  open: boolean;
  onClose?: () => void;
  onConfirm: () => void;
  canClose?: boolean;
  loading?: boolean;
}

// Texto exibido ao profissional antes de coletar o consentimento verbal do
// paciente. Este é apenas o texto de EXIBIÇÃO na tela — o texto realmente
// GRAVADO no banco (tabela `consents`, ver PacienteDetalhe.tsx) é uma
// constante separada, mantida em português por ser um registro legal (LGPD),
// e não deve mudar conforme o idioma da interface.
const ConsentModal: React.FC<ConsentModalProps> = ({ open, onClose, onConfirm, canClose = false, loading = false }) => {
  const { t } = useTranslation();
  const [scrolledToBottom, setScrolledToBottom] = useState(false);
  const [checked, setChecked] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
    if (atBottom) setScrolledToBottom(true);
  }, []);

  useEffect(() => {
    if (!open) return;
    setScrolledToBottom(false);
    setChecked(false);

    // Se o texto já cabe inteiro na área visível, o usuário nunca vai
    // disparar um evento de scroll — sem isso o checkbox ficava travado
    // pra sempre nessas telas (comum em telas maiores ou textos curtos).
    const raf = requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (el && el.scrollHeight - el.clientHeight < 30) {
        setScrolledToBottom(true);
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [open]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose ?? (() => {})}
      title={t('consent.title')}
      dismissible={canClose}
    >
      <div style={{ padding: '0 20px 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Scrollable consent text */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          style={{
            maxHeight: '40vh',
            overflowY: 'auto',
            WebkitOverflowScrolling: 'touch' as any,
            background: '#F7F6F4',
            borderRadius: 12,
            padding: 20,
          }}
        >
          <p style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, whiteSpace: 'pre-line' }}>
            {t('consent.text')}
          </p>
        </div>

        {/* Scroll hint */}
        {!scrolledToBottom && (
          <p style={{ fontSize: 13, color: '#AAA8A5', textAlign: 'center', fontWeight: 500 }} className="animate-pulse">
            {t('consent.scrollHint')}
          </p>
        )}

        {/* Checkbox */}
        <label
          style={{
            display: 'flex', alignItems: 'flex-start', gap: 12,
            opacity: !scrolledToBottom ? 0.4 : 1,
            pointerEvents: !scrolledToBottom ? 'none' : 'auto',
          }}
        >
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            style={{ marginTop: 2, width: 20, height: 20, flexShrink: 0 }}
          />
          <span style={{ fontSize: 13, color: '#6B6965', lineHeight: 1.4 }}>
            {t('consent.checkboxLabel')}
          </span>
        </label>

        <GradientButton
          onClick={onConfirm}
          disabled={!checked || loading}
        >
          {loading ? t('consent.saving') : t('consent.confirm')}
        </GradientButton>
      </div>
    </BottomSheet>
  );
};

export default ConsentModal;
