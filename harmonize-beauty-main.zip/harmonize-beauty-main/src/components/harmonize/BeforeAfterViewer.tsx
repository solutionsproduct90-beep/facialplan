import React, { useState } from 'react';
import BeforeAfterSlider from './BeforeAfterSlider';
import SideBySide from './before-after/SideBySide';
import FadeCompare from './before-after/FadeCompare';
import XrayLens from './before-after/XrayLens';
import DrawAnnotate, { DrawStroke } from './before-after/DrawAnnotate';
import { useTranslation } from 'react-i18next';

export type BeforeAfterMode = 'slider' | 'sideBySide' | 'fade' | 'xray' | 'draw';

export const BEFORE_AFTER_MODES: BeforeAfterMode[] = ['slider', 'sideBySide', 'fade', 'xray', 'draw'];

export interface BeforeAfterViewerProps {
  /** Original / pre-procedure photo. Omit to show the standard placeholder. */
  beforeImageUrl?: string | null;
  /** Simulated result photo. Omit to show the standard placeholder. */
  afterImageUrl?: string | null;
  className?: string;
  /** Mode selected on mount, and the mode "Riscar" returns to when done. */
  defaultMode?: BeforeAfterMode;
}

/**
 * Before/after comparison widget with 5 view modes: a draggable slider
 * (the original behaviour, preserved as the default), side-by-side,
 * opacity fade, a magnifier ("x-ray") lens, and a freehand annotation tool
 * for live consultations. Freehand strokes persist while switching modes
 * within the same mount and are cleared only when the component unmounts
 * (i.e. navigating away from the session).
 */
const BeforeAfterViewer: React.FC<BeforeAfterViewerProps> = ({
  beforeImageUrl,
  afterImageUrl,
  className = '',
  defaultMode = 'slider',
}) => {
  const { t } = useTranslation();
  const [mode, setMode] = useState<BeforeAfterMode>(defaultMode);
  const [strokes, setStrokes] = useState<DrawStroke[]>([]);

  const before = beforeImageUrl ?? undefined;
  const after = afterImageUrl ?? undefined;

  return (
    <div className={className} data-testid="before-after-viewer">
      <div
        role="tablist"
        aria-label={t('beforeAfter.modes.ariaLabel')}
        className="flex gap-1 bg-h-white rounded-full shadow-h-sm p-1 mb-3 overflow-x-auto"
      >
        {BEFORE_AFTER_MODES.map((m) => (
          <button
            key={m}
            role="tab"
            type="button"
            aria-selected={mode === m}
            data-testid={`mode-tab-${m}`}
            onClick={() => setMode(m)}
            className={`flex-1 min-w-[62px] py-2 px-2 text-[11px] font-semibold rounded-full whitespace-nowrap transition-all ${
              mode === m ? 'bg-gradient-brand shadow-h-sm' : 'text-h-text-3'
            }`}
            style={mode === m ? { color: '#fff' } : undefined}
          >
            {t(`beforeAfter.modes.${m}`)}
          </button>
        ))}
      </div>

      {mode === 'slider' && <BeforeAfterSlider beforeImageUrl={before} afterImageUrl={after} />}
      {mode === 'sideBySide' && <SideBySide beforeImageUrl={before} afterImageUrl={after} />}
      {mode === 'fade' && <FadeCompare beforeImageUrl={before} afterImageUrl={after} />}
      {mode === 'xray' && <XrayLens beforeImageUrl={before} afterImageUrl={after} />}
      {mode === 'draw' && (
        <DrawAnnotate
          beforeImageUrl={before}
          afterImageUrl={after}
          strokes={strokes}
          onStrokesChange={setStrokes}
          onDone={() => setMode(defaultMode)}
        />
      )}
    </div>
  );
};

export default BeforeAfterViewer;
