import React from 'react';

interface LogoMarkProps {
  size?: number;
  /** Cor do "furo" do anel — precisa bater com o fundo onde a marca está. */
  innerColor?: string;
}

const LogoMark: React.FC<LogoMarkProps> = ({ size = 56, innerColor = '#EEECEA' }) => {
  const borderWidth = size * 0.12;

  return (
    <div
      className="rounded-full flex-shrink-0"
      style={{
        width: size,
        height: size,
        background: 'conic-gradient(from 0deg, #E05C8A, #A855B5, #7C5AC2, #E05C8A)',
        padding: borderWidth,
      }}
    >
      <div
        className="w-full h-full rounded-full"
        style={{ backgroundColor: innerColor }}
      />
    </div>
  );
};

export default LogoMark;
