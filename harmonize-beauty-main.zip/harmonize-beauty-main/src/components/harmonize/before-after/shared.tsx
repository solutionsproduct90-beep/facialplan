import React from 'react';
import { useTranslation } from 'react-i18next';

export type PhotoVariant = 'before' | 'after';

/**
 * Flat CSS `background` value standing in for the "after" photo when none
 * exists yet. Used by the x-ray lens, which needs a single background-image
 * value it can size/position dynamically (rather than the two-layer div
 * markup PhotoLayer renders below).
 */
export const AFTER_FALLBACK_BACKGROUND =
  'linear-gradient(135deg, rgba(224,92,138,0.35), rgba(168,85,181,0.45)), ' +
  'linear-gradient(135deg, #E5E3E0 0%, #EEECEA 100%)';

/** CSS `background-image` value for the "after" layer. */
export function afterBackgroundValue(url?: string): string {
  return url ? `url("${url}")` : AFTER_FALLBACK_BACKGROUND;
}

interface PhotoLayerProps {
  url?: string;
  variant: PhotoVariant;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Renders a real photo when a URL is available, otherwise the same
 * placeholder gradient used by the original before/after slider, so every
 * view mode degrades the same way when a simulation hasn't been generated
 * yet.
 */
export const PhotoLayer: React.FC<PhotoLayerProps> = ({ url, variant, className = '', style }) => {
  const { t } = useTranslation();

  if (url) {
    return (
      <img
        src={url}
        alt={variant === 'before' ? t('common.before') : t('common.after')}
        draggable={false}
        className={`w-full h-full object-cover ${className}`}
        style={style}
      />
    );
  }

  if (variant === 'before') {
    return (
      <div
        className={`w-full h-full bg-gradient-to-br from-h-surface-3 to-h-bg ${className}`}
        style={style}
      />
    );
  }

  return (
    <div
      className={`w-full h-full ${className}`}
      style={{
        background: 'linear-gradient(135deg, rgba(224,92,138,0.08), rgba(168,85,181,0.12))',
        filter: 'brightness(1.05) contrast(1.05)',
        ...style,
      }}
    >
      <div
        className="w-full h-full bg-gradient-to-br from-h-surface-3 to-h-bg"
        style={{ filter: 'brightness(1.08) saturate(1.1)' }}
      />
    </div>
  );
};
