import React from 'react';
import { PhotoLayer } from './shared';
import { useTranslation } from 'react-i18next';

interface SideBySideProps {
  beforeImageUrl?: string;
  afterImageUrl?: string;
}

const SideBySide: React.FC<SideBySideProps> = ({ beforeImageUrl, afterImageUrl }) => {
  const { t } = useTranslation();

  return (
    <div className="grid grid-cols-2 gap-1.5 w-full">
      <div className="relative aspect-[3/4] rounded-r overflow-hidden">
        <PhotoLayer variant="before" url={beforeImageUrl} />
        <div className="absolute bottom-2 left-2 bg-black/50 text-[10px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
          {t('common.before')}
        </div>
      </div>
      <div className="relative aspect-[3/4] rounded-r overflow-hidden">
        <PhotoLayer variant="after" url={afterImageUrl} />
        <div className="absolute bottom-2 right-2 bg-black/50 text-[10px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
          {t('common.after')}
        </div>
      </div>
    </div>
  );
};

export default SideBySide;
