import React, { useCallback, useEffect, useRef, useState } from 'react';
import { PhotoLayer, afterBackgroundValue } from './shared';
import { useTranslation } from 'react-i18next';

interface XrayLensProps {
  beforeImageUrl?: string;
  afterImageUrl?: string;
  zoom?: number;
}

const LENS_SIZE = 132;

const XrayLens: React.FC<XrayLensProps> = ({ beforeImageUrl, afterImageUrl, zoom = 2.2 }) => {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [point, setPoint] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const measure = () => setSize({ w: el.clientWidth, h: el.clientHeight });
    measure();
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const updateFromClient = useCallback((clientX: number, clientY: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return;
    const x = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));
    setPoint({ x, y });
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => updateFromClient(e.clientX, e.clientY);
  const handleMouseLeave = () => setPoint(null);
  const handleTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (touch) updateFromClient(touch.clientX, touch.clientY);
  };
  const handleTouchEnd = () => setPoint(null);

  const bgWidth = size.w * zoom;
  const bgHeight = size.h * zoom;
  const bgPosX = point ? -(point.x * bgWidth - LENS_SIZE / 2) : 0;
  const bgPosY = point ? -(point.y * bgHeight - LENS_SIZE / 2) : 0;

  return (
    <div
      ref={containerRef}
      data-testid="xray-lens-area"
      className="relative w-full aspect-[3/4] rounded-r overflow-hidden select-none touch-none"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onTouchStart={handleTouchMove}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
    >
      <PhotoLayer variant="before" url={beforeImageUrl} />

      <div className="absolute bottom-3 left-3 bg-black/50 text-[11px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
        {t('common.before')}
      </div>

      {!point && (
        <div className="absolute inset-x-0 bottom-3 flex justify-center px-6 pointer-events-none">
          <div className="bg-black/55 text-[11px] font-semibold px-3 py-1.5 rounded-full text-center" style={{ color: '#fff' }}>
            {t('beforeAfter.xray.instruction')}
          </div>
        </div>
      )}

      {point && (
        <div
          data-testid="xray-lens"
          className="absolute rounded-full pointer-events-none z-10"
          style={{
            left: point.x * size.w,
            top: point.y * size.h,
            width: LENS_SIZE,
            height: LENS_SIZE,
            transform: 'translate(-50%, -50%)',
            border: '3px solid #fff',
            boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
            backgroundImage: afterBackgroundValue(afterImageUrl),
            backgroundSize: `${bgWidth}px ${bgHeight}px`,
            backgroundPosition: `${bgPosX}px ${bgPosY}px`,
            backgroundRepeat: 'no-repeat',
          }}
        >
          <span
            className="absolute left-1/2 whitespace-nowrap text-[10px] font-bold px-2 py-1 rounded-full"
            style={{ top: -30, transform: 'translateX(-50%)', backgroundColor: 'rgba(0,0,0,0.65)', color: '#fff' }}
          >
            {t('beforeAfter.xray.badge', { zoom: zoom.toFixed(1) })}
          </span>
        </div>
      )}
    </div>
  );
};

export default XrayLens;
