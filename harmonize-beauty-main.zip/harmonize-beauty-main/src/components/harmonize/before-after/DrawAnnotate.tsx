import React, { useCallback, useEffect, useRef, useState } from 'react';
import { PhotoLayer } from './shared';
import { useTranslation } from 'react-i18next';

export interface DrawPoint {
  x: number; // normalized 0..1, relative to the canvas
  y: number; // normalized 0..1, relative to the canvas
}

export interface DrawStroke {
  color: string;
  points: DrawPoint[];
}

const DRAW_COLORS = ['#FFFFFF', '#E05050', '#D4900A', '#A855B5'];
const STROKE_WIDTH = 4;

interface DrawAnnotateProps {
  beforeImageUrl?: string;
  afterImageUrl?: string;
  strokes: DrawStroke[];
  onStrokesChange: (strokes: DrawStroke[]) => void;
  onDone?: () => void;
}

const DrawAnnotate: React.FC<DrawAnnotateProps> = ({
  beforeImageUrl,
  afterImageUrl,
  strokes,
  onStrokesChange,
  onDone,
}) => {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const currentPointsRef = useRef<DrawPoint[]>([]);
  const [color, setColor] = useState(DRAW_COLORS[0]);

  const redraw = useCallback((allStrokes: DrawStroke[]) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    const dpr = window.devicePixelRatio || 1;
    ctx.lineWidth = STROKE_WIDTH * dpr;
    allStrokes.forEach((stroke) => {
      if (stroke.points.length < 2) return;
      ctx.strokeStyle = stroke.color;
      ctx.beginPath();
      stroke.points.forEach((p, i) => {
        const x = p.x * canvas.width;
        const y = p.y * canvas.height;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    });
  }, []);

  const resizeCanvas = useCallback(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, container.clientWidth * dpr);
    canvas.height = Math.max(1, container.clientHeight * dpr);
    redraw(strokes);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [redraw]);

  useEffect(() => {
    resizeCanvas();
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(resizeCanvas);
    if (containerRef.current) ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, [resizeCanvas]);

  useEffect(() => {
    redraw(strokes);
  }, [strokes, redraw]);

  const relativePoint = (clientX: number, clientY: number): DrawPoint | null => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return null;
    return {
      x: Math.max(0, Math.min(1, (clientX - rect.left) / rect.width)),
      y: Math.max(0, Math.min(1, (clientY - rect.top) / rect.height)),
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture?.(e.pointerId);
    const p = relativePoint(e.clientX, e.clientY);
    if (!p) return;
    drawingRef.current = true;
    currentPointsRef.current = [p];
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return;
    const p = relativePoint(e.clientX, e.clientY);
    if (!p) return;
    currentPointsRef.current = [...currentPointsRef.current, p];
    redraw([...strokes, { color, points: currentPointsRef.current }]);
  };

  const finishStroke = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    if (currentPointsRef.current.length > 1) {
      onStrokesChange([...strokes, { color, points: currentPointsRef.current }]);
    }
    currentPointsRef.current = [];
  };

  const handleClear = () => onStrokesChange([]);

  return (
    <div className="w-full">
      <div
        className="mb-2 flex items-center gap-2 rounded-r-sm px-3 py-2"
        style={{ backgroundColor: 'rgba(212,144,10,0.10)' }}
        data-testid="draw-notice"
      >
        <span aria-hidden="true">✏️</span>
        <p className="text-[11px] font-semibold" style={{ color: '#D4900A' }}>
          {t('beforeAfter.draw.notice')}
        </p>
      </div>

      <div
        ref={containerRef}
        className="relative w-full aspect-[3/4] rounded-r overflow-hidden select-none touch-none"
      >
        <PhotoLayer variant="after" url={afterImageUrl ?? beforeImageUrl} />
        <canvas
          ref={canvasRef}
          data-testid="draw-canvas"
          className="absolute inset-0 w-full h-full"
          style={{ touchAction: 'none' }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={finishStroke}
          onPointerLeave={finishStroke}
          onPointerCancel={finishStroke}
        />
      </div>

      <div className="mt-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {DRAW_COLORS.map((c) => (
            <button
              key={c}
              type="button"
              aria-label={t('beforeAfter.draw.colorLabel')}
              aria-pressed={color === c}
              data-testid={`draw-color-${c}`}
              onClick={() => setColor(c)}
              className="w-7 h-7 rounded-full transition-transform active:scale-90"
              style={{
                backgroundColor: c,
                border: color === c ? '2px solid #1A1918' : '2px solid rgba(0,0,0,0.12)',
              }}
            />
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleClear}
            data-testid="draw-clear"
            className="text-[12px] font-semibold text-h-text-2 px-3 py-2 rounded-full"
            style={{ backgroundColor: 'rgba(0,0,0,0.05)' }}
          >
            {t('beforeAfter.draw.clear')}
          </button>
          <button
            type="button"
            onClick={onDone}
            data-testid="draw-done"
            className="text-[12px] font-bold px-4 py-2 rounded-full bg-gradient-brand"
            style={{ color: '#fff' }}
          >
            {t('beforeAfter.draw.done')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DrawAnnotate;
