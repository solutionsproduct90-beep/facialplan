import React, { useState } from 'react';
import { PhotoLayer } from './shared';
import { useTranslation } from 'react-i18next';

interface FadeCompareProps {
  beforeImageUrl?: string;
  afterImageUrl?: string;
}

const FadeCompare: React.FC<FadeCompareProps> = ({ beforeImageUrl, afterImageUrl }) => {
  const { t } = useTranslation();
  const [mix, setMix] = useState(50);

  return (
    <div className="w-full">
      <div className="relative w-full aspect-[3/4] rounded-r overflow-hidden select-none">
        <PhotoLayer variant="before" url={beforeImageUrl} className="absolute inset-0" />
        <div className="absolute inset-0" style={{ opacity: mix / 100 }}>
          <PhotoLayer variant="after" url={afterImageUrl} />
        </div>

        <div className="absolute bottom-3 left-3 bg-black/50 text-[11px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
          {t('common.before')}
        </div>
        <div className="absolute bottom-3 right-3 bg-black/50 text-[11px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
          {t('common.after')}
        </div>
      </div>

      <p className="text-[11px] text-h-text-3 text-center mt-3 mb-1.5">
        {t('beforeAfter.fade.instruction')}
      </p>
      <div className="px-1 flex items-center gap-2">
        <span className="text-[10px] font-semibold text-h-text-3 w-10">{t('common.before')}</span>
        <input
          type="range"
          min={0}
          max={100}
          value={mix}
          onChange={(e) => setMix(Number(e.target.value))}
          aria-label={t('beforeAfter.fade.instruction')}
          data-testid="fade-range"
          className="flex-1 accent-h-g-mid"
        />
        <span className="text-[10px] font-semibold text-h-text-3 w-10 text-right">{t('common.after')}</span>
      </div>
    </div>
  );
};

export default FadeCompare;
