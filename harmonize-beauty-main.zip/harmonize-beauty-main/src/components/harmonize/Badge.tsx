import React from 'react';

type BadgeVariant = 'alta' | 'media' | 'baixa' | 'grad' | 'neutral';

const variantStyles: Record<BadgeVariant, { bg: string; color: string }> = {
  alta: { bg: 'rgba(224,80,80,0.08)', color: '#E05050' },
  media: { bg: 'rgba(212,144,10,0.08)', color: '#D4900A' },
  baixa: { bg: 'rgba(45,184,122,0.10)', color: '#2DB87A' },
  grad: { bg: 'rgba(168,85,181,0.10)', color: '#A855B5' },
  neutral: { bg: '#E5E3E0', color: '#6B6965' },
};

interface BadgeProps {
  variant: BadgeVariant;
  children: React.ReactNode;
}

const HarmonizeBadge: React.FC<BadgeProps> = ({ variant, children }) => {
  const s = variantStyles[variant];
  return (
    <span
      className="inline-flex items-center font-semibold text-[11px] leading-none"
      style={{
        backgroundColor: s.bg,
        color: s.color,
        borderRadius: 980,
        padding: '3px 10px',
      }}
    >
      {children}
    </span>
  );
};

export default HarmonizeBadge;
