import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { CalendarClock, RefreshCw, Link2, SkipForward, Undo2 } from 'lucide-react';
import { toast } from 'sonner';
import HCard from '@/components/harmonize/HCard';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { SUBSTANCE_KEYS, SUBSTANCE_LABEL, type Substance } from '@/types/harmonize';
import {
  normalizeTreatmentPlans,
  normalizeTreatmentPlanSteps,
  sortTreatmentPlanSteps,
  nextStepOrder,
  computeStepExpectedDate,
  validateTreatmentPlanDraft,
  buildTreatmentPlanPayload,
  validateTreatmentPlanStepDraft,
  buildTreatmentPlanStepPayload,
  buildStepSessionLinkPayload,
  buildStepSkipPayload,
  buildStepSessionUnlinkPayload,
  type TreatmentPlanDraft,
  type TreatmentPlanStepDraft,
  type TreatmentPlanStepForList,
} from '@/lib/treatmentPlans';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

const STATUS_BADGE: Record<string, 'baixa' | 'media' | 'neutral'> = {
  pendente: 'media',
  concluida: 'baixa',
  pulada: 'neutral',
};

type SessionOption = { id: string; created_at: string };

/**
 * "Construtor de Protocolo Combinado Multi-Sessão" (Combo Plans) — seção
 * autocontida da ficha do paciente (mesmo padrão de AdverseEventsSection:
 * query própria + BottomSheet de registro) que permite ao profissional
 * desenhar, desde a primeira consulta, um protocolo faseado (ex.: toxina
 * hoje + bioestimulador em 30 dias + skinbooster em 60 dias) e, quando uma
 * sessão real é criada para o paciente, vincular manualmente essa sessão a
 * uma etapa pendente do plano — marcando-a como concluída. Ver
 * src/lib/treatmentPlans.ts para as funções puras de cálculo/validação e
 * supabase/migrations/20260911040000_add_treatment_plans.sql para o schema.
 */
const TreatmentPlanSection: React.FC<{
  patientId: string;
  /**
   * Sinal opcional de "abrir novo plano" vindo de fora (ver
   * PacienteDetalhe.tsx > sugestão de recorrência,
   * src/lib/recurrencePattern.ts) — um número que muda a cada clique no CTA
   * externo. A seção não expõe `openNewPlan` como ref/callback porque este
   * é o único consumidor externo até agora; um contador simples via prop já
   * resolve sem precisar de forwardRef/imperative handle. Incrementos
   * subsequentes reabrem o formulário mesmo que o profissional já tenha
   * fechado o BottomSheet sem salvar.
   */
  openNewPlanSignal?: number;
}> = ({ patientId, openNewPlanSignal }) => {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const queryClient = useQueryClient();
  const locale = dateFnsLocale[i18n.language] ?? ptBR;

  const [newPlanOpen, setNewPlanOpen] = useState(false);
  const [savingPlan, setSavingPlan] = useState(false);
  const [planDraft, setPlanDraft] = useState<TreatmentPlanDraft>({ name: '', description: '', startDate: format(new Date(), 'yyyy-MM-dd') });

  const [stepSheetPlanId, setStepSheetPlanId] = useState<string | null>(null);
  const [savingStep, setSavingStep] = useState(false);
  const [stepDraft, setStepDraft] = useState<TreatmentPlanStepDraft>({ substance: SUBSTANCE_KEYS[0], offsetDays: 0, notes: '' });

  // Sessão selecionada por etapa no select "vincular a esta etapa" — chave
  // é o id da etapa, valor é o id da sessão escolhida mas ainda não salva.
  const [linkSelection, setLinkSelection] = useState<Record<string, string>>({});
  const [linkingStepId, setLinkingStepId] = useState<string | null>(null);

  const plansQueryKey = ['treatment-plans', patientId];
  const {
    data: plansRaw,
    isLoading: loadingPlans,
    isError: plansError,
    refetch: refetchPlans,
  } = useQuery({
    queryKey: plansQueryKey,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('treatment_plans')
        .select('*')
        .eq('patient_id', patientId)
        .order('start_date', { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!patientId,
  });

  const plans = useMemo(() => normalizeTreatmentPlans(plansRaw ?? []), [plansRaw]);
  const planIds = useMemo(() => plans.map((p) => p.id), [plans]);

  const stepsQueryKey = ['treatment-plan-steps', patientId, planIds.join(',')];
  const { data: stepsRaw, isLoading: loadingSteps } = useQuery({
    queryKey: stepsQueryKey,
    queryFn: async () => {
      if (planIds.length === 0) return [];
      const { data, error } = await supabase
        .from('treatment_plan_steps')
        .select('*')
        .in('plan_id', planIds)
        .order('offset_days', { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
    enabled: planIds.length > 0,
  });

  const steps = useMemo(() => normalizeTreatmentPlanSteps(stepsRaw ?? []), [stepsRaw]);
  const stepsByPlan = useMemo(() => {
    const map = new Map<string, TreatmentPlanStepForList[]>();
    for (const step of steps) {
      const list = map.get(step.planId) ?? [];
      list.push(step);
      map.set(step.planId, list);
    }
    for (const [planId, list] of map) map.set(planId, sortTreatmentPlanSteps(list));
    return map;
  }, [steps]);

  const { data: sessions } = useQuery({
    queryKey: ['treatment-plan-sessions', patientId],
    queryFn: async (): Promise<SessionOption[]> => {
      const { data, error } = await supabase
        .from('sessions')
        .select('id, created_at')
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!patientId,
  });

  const invalidateAll = () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: plansQueryKey }),
      queryClient.invalidateQueries({ queryKey: stepsQueryKey }),
    ]);

  const openNewPlan = () => {
    setPlanDraft({ name: '', description: '', startDate: format(new Date(), 'yyyy-MM-dd') });
    setNewPlanOpen(true);
  };

  // Ignora o valor inicial de `openNewPlanSignal` (não deve abrir o
  // formulário sozinho ao montar a tela) e só reage a MUDANÇAS depois disso
  // — cada incremento do contador feito pelo pai é um novo pedido explícito
  // de abrir "Novo plano".
  const openNewPlanSignalMounted = useRef(false);
  useEffect(() => {
    if (!openNewPlanSignalMounted.current) {
      openNewPlanSignalMounted.current = true;
      return;
    }
    openNewPlan();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openNewPlanSignal]);

  const handleSavePlan = async () => {
    if (!user) return;
    const validationError = validateTreatmentPlanDraft(planDraft);
    if (validationError) {
      toast.error(t(`treatmentPlans.form.errors.${validationError}`));
      return;
    }
    setSavingPlan(true);
    try {
      const payload = buildTreatmentPlanPayload(planDraft, { professionalId: user.id, patientId });
      const { error } = await supabase.from('treatment_plans').insert(payload);
      if (error) throw error;
      await invalidateAll();
      setNewPlanOpen(false);
      toast.success(t('treatmentPlans.toastPlanSaved'));
    } catch (err: any) {
      toast.error(err.message || t('treatmentPlans.toastPlanError'));
    } finally {
      setSavingPlan(false);
    }
  };

  const openNewStep = (planId: string) => {
    setStepDraft({ substance: SUBSTANCE_KEYS[0], offsetDays: 0, notes: '' });
    setStepSheetPlanId(planId);
  };

  const handleSaveStep = async () => {
    if (!user || !stepSheetPlanId) return;
    const validationError = validateTreatmentPlanStepDraft(stepDraft);
    if (validationError) {
      toast.error(t(`treatmentPlans.form.errors.${validationError}`));
      return;
    }
    setSavingStep(true);
    try {
      const existing = stepsByPlan.get(stepSheetPlanId) ?? [];
      const payload = buildTreatmentPlanStepPayload(stepDraft, {
        professionalId: user.id,
        planId: stepSheetPlanId,
        stepOrder: nextStepOrder(existing),
      });
      const { error } = await supabase.from('treatment_plan_steps').insert(payload);
      if (error) throw error;
      await invalidateAll();
      setStepSheetPlanId(null);
      toast.success(t('treatmentPlans.toastStepSaved'));
    } catch (err: any) {
      toast.error(err.message || t('treatmentPlans.toastStepError'));
    } finally {
      setSavingStep(false);
    }
  };

  const handleLinkSession = async (stepId: string) => {
    const sessionId = linkSelection[stepId];
    if (!sessionId) return;
    setLinkingStepId(stepId);
    try {
      const { error } = await supabase
        .from('treatment_plan_steps')
        .update(buildStepSessionLinkPayload(sessionId))
        .eq('id', stepId);
      if (error) throw error;
      await invalidateAll();
      toast.success(t('treatmentPlans.toastLinked'));
    } catch (err: any) {
      toast.error(err.message || t('treatmentPlans.toastLinkError'));
    } finally {
      setLinkingStepId(null);
    }
  };

  const handleSkipStep = async (stepId: string) => {
    setLinkingStepId(stepId);
    try {
      const { error } = await supabase
        .from('treatment_plan_steps')
        .update(buildStepSkipPayload())
        .eq('id', stepId);
      if (error) throw error;
      await invalidateAll();
      toast.success(t('treatmentPlans.toastSkipped'));
    } catch (err: any) {
      toast.error(err.message || t('treatmentPlans.toastSkipError'));
    } finally {
      setLinkingStepId(null);
    }
  };

  /**
   * Desfaz uma etapa 'concluida' (sessão vinculada por engano) ou 'pulada'
   * (marcada como pulada sem querer), devolvendo pra 'pendente' — achado do
   * QA Contínuo (ciclo 23): `buildStepSessionUnlinkPayload` já existia e já
   * era testada em treatmentPlans.ts, mas nenhum botão da UI a chamava, sem
   * caminho nenhum de desfazer um vínculo/pulo errado.
   */
  const handleUnlinkStep = async (stepId: string) => {
    setLinkingStepId(stepId);
    try {
      const { error } = await supabase
        .from('treatment_plan_steps')
        .update(buildStepSessionUnlinkPayload())
        .eq('id', stepId);
      if (error) throw error;
      await invalidateAll();
      toast.success(t('treatmentPlans.toastUnlinked'));
    } catch (err: any) {
      toast.error(err.message || t('treatmentPlans.toastUnlinkError'));
    } finally {
      setLinkingStepId(null);
    }
  };

  return (
    <div id="treatment-plan-section">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <CalendarClock size={14} className="text-h-g-mid" />
          <p className="text-[13px] font-semibold text-h-text">{t('treatmentPlans.sectionTitle')}</p>
        </div>
        <button
          onClick={openNewPlan}
          data-testid="treatment-plan-add-new"
          className="flex items-center gap-1.5 press-scale"
          style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, fontSize: 12, fontWeight: 600 }}
        >
          {t('treatmentPlans.addPlan')}
        </button>
      </div>

      {loadingPlans ? (
        <div className="flex flex-col gap-2">
          <SkeletonCard lines={2} />
        </div>
      ) : plansError ? (
        <HCard className="flex flex-col items-center gap-2 text-center py-6">
          <p className="text-[13px] text-h-text-2">{t('treatmentPlans.error.load')}</p>
          <button
            onClick={() => refetchPlans()}
            className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
            style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
          >
            <RefreshCw size={14} />
            {t('treatmentPlans.error.retry')}
          </button>
        </HCard>
      ) : plans.length === 0 ? (
        <div className="bg-h-white rounded-r p-5 shadow-h-sm text-center">
          <p className="text-[14px] text-h-text-3">{t('treatmentPlans.empty')}</p>
          <p className="text-[12px] text-h-text-3 mt-1">{t('treatmentPlans.emptyHint')}</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {plans.map((plan) => {
            const planSteps = stepsByPlan.get(plan.id) ?? [];
            // Filtra contra `steps` (TODAS as etapas do paciente), não contra
            // `planSteps` (só as deste plano). O vínculo sessão-etapa é a
            // evidência de que aquele procedimento físico cumpriu aquela etapa
            // específica; oferecer a mesma sessão em dois planos deixava o
            // profissional registrar que um único atendimento cumpriu duas
            // etapas diferentes, inflando o progresso dos dois (achado do
            // ciclo 63 do QA Contínuo).
            const availableSessions = (sessions ?? []).filter((s) => !steps.some((st) => st.sessionId === s.id));
            return (
              <HCard key={plan.id}>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <div className="min-w-0">
                    <p className="text-[13px] font-semibold text-h-text">{plan.name}</p>
                    {plan.description && <p className="text-[12px] text-h-text-2 mt-0.5">{plan.description}</p>}
                  </div>
                </div>
                <p className="text-[11px] text-h-text-3 mb-3">
                  {t('treatmentPlans.planStartDate', { date: format(new Date(`${plan.startDate}T00:00:00`), 'PP', { locale }) })}
                </p>

                {loadingSteps && planSteps.length === 0 ? (
                  <SkeletonCard lines={1} />
                ) : planSteps.length === 0 ? (
                  <p className="text-[12px] text-h-text-3 mb-2">{t('treatmentPlans.noSteps')}</p>
                ) : (
                  <div className="flex flex-col gap-2 mb-2">
                    {planSteps.map((step) => {
                      const expectedDate = computeStepExpectedDate(plan.startDate, step.offsetDays);
                      const busy = linkingStepId === step.id;
                      return (
                        <div
                          key={step.id}
                          className="rounded-r-sm p-3"
                          style={{ background: 'rgba(191,95,130,0.04)' }}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="min-w-0">
                              <p className="text-[12px] font-semibold text-h-text">{SUBSTANCE_LABEL[step.substance as Substance]}</p>
                              <p className="text-[11px] text-h-text-3">
                                {t('treatmentPlans.step.expectedDate', { date: format(expectedDate, 'PP', { locale }) })}
                              </p>
                              {step.notes && <p className="text-[11px] text-h-text-3 mt-0.5">{step.notes}</p>}
                            </div>
                            <HarmonizeBadge variant={STATUS_BADGE[step.status] ?? 'neutral'}>
                              {t(`treatmentPlans.status.${step.status}`)}
                            </HarmonizeBadge>
                          </div>

                          {step.status === 'pendente' && (
                            <div className="flex items-center gap-2 mt-2">
                              <select
                                value={linkSelection[step.id] ?? ''}
                                onChange={(e) => setLinkSelection((prev) => ({ ...prev, [step.id]: e.target.value }))}
                                aria-label={t('treatmentPlans.step.linkSession')}
                                className="flex-1 min-w-0 bg-h-white shadow-h-sm rounded-r-sm px-[10px] h-[36px] text-[12px] font-medium text-h-text outline-none"
                              >
                                <option value="">{t('treatmentPlans.step.linkSessionPlaceholder')}</option>
                                {availableSessions.map((s) => (
                                  <option key={s.id} value={s.id}>
                                    {format(new Date(s.created_at), 'PP', { locale })}
                                  </option>
                                ))}
                              </select>
                              <button
                                onClick={() => handleLinkSession(step.id)}
                                disabled={!linkSelection[step.id] || busy}
                                className="flex items-center gap-1 text-[11px] font-bold press-scale disabled:opacity-40"
                                style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 36 }}
                              >
                                <Link2 size={13} />
                                {t('treatmentPlans.step.linkButton')}
                              </button>
                              <button
                                onClick={() => handleSkipStep(step.id)}
                                disabled={busy}
                                className="flex items-center gap-1 text-[11px] font-semibold text-h-text-3 press-scale disabled:opacity-40"
                                style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: 36 }}
                              >
                                <SkipForward size={13} />
                                {t('treatmentPlans.step.skip')}
                              </button>
                            </div>
                          )}

                          {(step.status === 'concluida' || step.status === 'pulada') && (
                            <div className="flex items-center gap-2 mt-2">
                              <button
                                onClick={() => handleUnlinkStep(step.id)}
                                disabled={busy}
                                className="flex items-center gap-1 text-[11px] font-semibold text-h-text-3 press-scale disabled:opacity-40"
                                style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: 36 }}
                              >
                                <Undo2 size={13} />
                                {t('treatmentPlans.step.unlink')}
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                <button
                  onClick={() => openNewStep(plan.id)}
                  className="text-[12px] font-semibold text-h-g-start min-h-[36px]"
                >
                  {t('treatmentPlans.addStep')}
                </button>
              </HCard>
            );
          })}
        </div>
      )}

      {/* Novo Plano */}
      <BottomSheet open={newPlanOpen} onClose={() => setNewPlanOpen(false)} title={t('treatmentPlans.form.newPlanTitle')}>
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('treatmentPlans.form.nameLabel')}</label>
            <input
              type="text"
              value={planDraft.name}
              onChange={(e) => setPlanDraft((prev) => ({ ...prev, name: e.target.value }))}
              placeholder={t('treatmentPlans.form.namePlaceholder')}
              aria-label={t('treatmentPlans.form.nameLabel')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('treatmentPlans.form.descriptionLabel')}</label>
            <textarea
              value={planDraft.description}
              onChange={(e) => setPlanDraft((prev) => ({ ...prev, description: e.target.value }))}
              placeholder={t('treatmentPlans.form.descriptionPlaceholder')}
              aria-label={t('treatmentPlans.form.descriptionLabel')}
              rows={3}
              className="rounded-r-sm px-[14px] py-3 text-[14px] font-medium text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30 resize-none"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('treatmentPlans.form.startDateLabel')}</label>
            <input
              type="date"
              value={planDraft.startDate}
              onChange={(e) => setPlanDraft((prev) => ({ ...prev, startDate: e.target.value }))}
              aria-label={t('treatmentPlans.form.startDateLabel')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
            />
          </div>

          <GradientButton onClick={handleSavePlan} disabled={savingPlan}>
            {savingPlan ? t('treatmentPlans.form.saving') : t('treatmentPlans.form.save')}
          </GradientButton>
        </div>
      </BottomSheet>

      {/* Nova Etapa */}
      <BottomSheet open={!!stepSheetPlanId} onClose={() => setStepSheetPlanId(null)} title={t('treatmentPlans.form.newStepTitle')}>
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('treatmentPlans.form.substanceLabel')}</label>
            <select
              value={stepDraft.substance}
              onChange={(e) => setStepDraft((prev) => ({ ...prev, substance: e.target.value }))}
              aria-label={t('treatmentPlans.form.substanceLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              {SUBSTANCE_KEYS.map((sub) => (
                <option key={sub} value={sub}>{SUBSTANCE_LABEL[sub]}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('treatmentPlans.form.offsetDaysLabel')}</label>
            <input
              type="number"
              min={0}
              value={stepDraft.offsetDays}
              onChange={(e) => setStepDraft((prev) => ({ ...prev, offsetDays: Number(e.target.value) }))}
              aria-label={t('treatmentPlans.form.offsetDaysLabel')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
            />
            <p className="text-[11px] text-h-text-3">{t('treatmentPlans.form.offsetDaysHint')}</p>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('treatmentPlans.form.notesLabel')}</label>
            <textarea
              value={stepDraft.notes}
              onChange={(e) => setStepDraft((prev) => ({ ...prev, notes: e.target.value }))}
              aria-label={t('treatmentPlans.form.notesLabel')}
              rows={3}
              className="rounded-r-sm px-[14px] py-3 text-[14px] font-medium text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30 resize-none"
            />
          </div>

          <GradientButton onClick={handleSaveStep} disabled={savingStep}>
            {savingStep ? t('treatmentPlans.form.saving') : t('treatmentPlans.form.saveStep')}
          </GradientButton>
        </div>
      </BottomSheet>
    </div>
  );
};

export default TreatmentPlanSection;
