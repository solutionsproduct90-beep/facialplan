import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AdverseEventsSection from './AdverseEventsSection';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const insertSpy = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/** Builder pra `adverse_events`: `.select().eq().order()` (lista) e `.insert()`. */
function createEventsBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    insert: (payload: Record<string, unknown>) => {
      insertSpy(payload);
      return Promise.resolve({ error: null });
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

/** Builder genérico pra `insumos`/`sessions`: só a listagem usada pelos selects do formulário. */
function createListBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

const renderSection = (patientId = 'pat-1') =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <AdverseEventsSection patientId={patientId} />
    </QueryClientProvider>,
  );

describe('AdverseEventsSection', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
    insertSpy.mockReset();
  });

  it('shows the empty state when the patient has no adverse events yet', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'adverse_events') return createEventsBuilder([]);
      if (table === 'insumos') return createListBuilder([]);
      if (table === 'sessions') return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    expect(await screen.findByText('Nenhum evento adverso registrado para este paciente.')).toBeInTheDocument();
  });

  it('lists a registered adverse event with its severity badge and linked insumo brand', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'adverse_events') {
        return createEventsBuilder([
          {
            id: 'ae-1',
            event_type: 'nodulo',
            severity: 'grave',
            description: 'Nódulo palpável na região malar.',
            occurred_at: '2026-09-05T14:00:00.000Z',
            created_at: '2026-09-05T14:05:00.000Z',
            insumo: { brand_name: 'Juvederm Voluma' },
          },
        ]);
      }
      if (table === 'insumos') return createListBuilder([]);
      if (table === 'sessions') return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    expect(await screen.findByText('Nódulo')).toBeInTheDocument();
    expect(screen.getByText('Grave')).toBeInTheDocument();
    expect(screen.getByText('Nódulo palpável na região malar.')).toBeInTheDocument();
    expect(screen.getByText(/Juvederm Voluma/)).toBeInTheDocument();
  });

  it('registers a new adverse event linked to the patient, an insumo and a session', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'adverse_events') return createEventsBuilder([]);
      if (table === 'insumos') return createListBuilder([{ id: 'ins-1', brand_name: 'Dysport' }]);
      if (table === 'sessions') return createListBuilder([{ id: 'ses-1', created_at: '2026-09-01T10:00:00.000Z' }]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Nenhum evento adverso registrado para este paciente.');

    fireEvent.click(screen.getByTestId('adverse-events-add-new'));
    fireEvent.change(screen.getByLabelText('Descrição'), { target: { value: 'Reação alérgica leve, resolvida com anti-histamínico.' } });

    fireEvent.click(screen.getByText('Salvar evento'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({
      professional_id: 'pro-1',
      patient_id: 'pat-1',
      description: 'Reação alérgica leve, resolvida com anti-histamínico.',
      event_type: 'nodulo',
      severity: 'leve',
    });
  });

  it('rejects an empty description instead of registering a bogus event', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'adverse_events') return createEventsBuilder([]);
      if (table === 'insumos') return createListBuilder([]);
      if (table === 'sessions') return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Nenhum evento adverso registrado para este paciente.');

    fireEvent.click(screen.getByTestId('adverse-events-add-new'));
    fireEvent.click(screen.getByText('Salvar evento'));

    await waitFor(() => expect(insertSpy).not.toHaveBeenCalled());
  });
});
