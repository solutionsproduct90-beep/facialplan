import React from 'react';
import { useTranslation } from 'react-i18next';
import { Drawer } from 'vaul';

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  snapPoints?: number[];
  dismissible?: boolean;
}

const BottomSheet: React.FC<BottomSheetProps> = ({
  open, onClose, children, title, snapPoints, dismissible = true
}) => {
  const { t } = useTranslation();

  return (
  <Drawer.Root
    open={open}
    onOpenChange={(o) => { if (!o) onClose(); }}
    dismissible={dismissible}
    snapPoints={snapPoints}
  >
    <Drawer.Portal>
      <Drawer.Overlay
        style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.4)',
          backdropFilter: 'blur(4px)',
          WebkitBackdropFilter: 'blur(4px)',
          zIndex: 60,
        }}
      />
      <Drawer.Content
        style={{
          position: 'fixed', bottom: 0, left: 0, right: 0,
          zIndex: 70,
          background: '#FFFFFF',
          borderRadius: '20px 20px 0 0',
          paddingBottom: 'env(safe-area-inset-bottom, 16px)',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          outline: 'none',
        }}
      >
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 8px' }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: '#E5E3E0' }} />
        </div>

        {/* Title — precisa ser o Drawer.Title (Dialog.Title do Radix por baixo) pra que o
            Radix associe o texto ao dialog via aria-labelledby; um <p> comum aqui faz o
            leitor de tela acusar "DialogContent requires a DialogTitle" em toda sheet do
            app. asChild mantém o <p> como elemento renderizado (zero mudança visual).
            Sheets sem `title` (ex. confirmação de cancelamento em Conta.tsx) ainda
            precisam de um Drawer.Title — por isso o fallback sr-only abaixo, que não
            altera nada visualmente mas garante o mesmo requisito de acessibilidade em
            toda sheet do app, com ou sem título visível. */}
        {title ? (
          <div style={{ padding: '0 20px 12px', borderBottom: '0.5px solid rgba(0,0,0,0.06)' }}>
            <Drawer.Title asChild>
              <p style={{
                fontSize: 17, fontWeight: 700, color: '#1A1918',
                letterSpacing: '-0.01em', textAlign: 'center',
                fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif",
              }}>
                {title}
              </p>
            </Drawer.Title>
          </div>
        ) : (
          <Drawer.Title className="sr-only">{t('common.sheetTitleFallback')}</Drawer.Title>
        )}

        {/* Content */}
        <div style={{ overflowY: 'auto', flex: 1, WebkitOverflowScrolling: 'touch' as any }}>
          {children}
        </div>
      </Drawer.Content>
    </Drawer.Portal>
  </Drawer.Root>
  );
};

export default BottomSheet;
