import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import RecuperarCompraHotmart from './RecuperarCompraHotmart';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const rpcMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { rpc: (...args: unknown[]) => rpcMock(...args) },
}));

vi.mock('sonner', () => ({
  toast: { error: (...args: unknown[]) => toastErrorMock(...args), success: vi.fn(), info: vi.fn() },
}));

async function openForm() {
  render(<RecuperarCompraHotmart />);
  fireEvent.click(screen.getByText('Já paguei e não liberou'));
  return screen.getByLabelText('E-mail usado na compra') as HTMLInputElement;
}

describe('RecuperarCompraHotmart', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    rpcMock.mockReset();
    toastErrorMock.mockReset();
    useAuthMock.mockReturnValue({ user: { id: 'pro-1', email: 'dona@conta.com' } });
  });

  it('não renderiza nada sem sessão — não há a quem liberar nem a quem atribuir a solicitação', () => {
    useAuthMock.mockReturnValue({ user: null });
    const { container } = render(<RecuperarCompraHotmart />);
    expect(container).toBeEmptyDOMElement();
  });

  it('pré-preenche com o e-mail da conta, que é o único que pode liberar na hora', async () => {
    const input = await openForm();
    expect(input.value).toBe('dona@conta.com');
  });

  it('libera o acesso quando a RPC confirma que a compra é do e-mail verificado da própria conta', async () => {
    rpcMock.mockResolvedValue({ data: 'activated', error: null });
    await openForm();
    fireEvent.click(screen.getByText('Verificar meu pagamento'));

    await waitFor(() => expect(screen.getByText('Assinatura liberada')).toBeTruthy());
    expect(rpcMock).toHaveBeenCalledWith('request_hotmart_purchase_recovery', {
      p_purchase_email: 'dona@conta.com',
    });
    expect(screen.getByText('Entrar no FacialPlan')).toBeTruthy();
  });

  it('TENTATIVA DE ABUSO: informar o e-mail de outra pessoa não libera nada — só vira solicitação para revisão', async () => {
    // A recusa é decidida no banco (request_hotmart_purchase_recovery só
    // libera para o e-mail verificado da própria conta); o que este teste
    // trava é o contrato do client: 'under_review' NUNCA pode virar tela de
    // acesso liberado, por mais que o e-mail digitado exista na fila.
    rpcMock.mockResolvedValue({ data: 'under_review', error: null });
    const input = await openForm();
    fireEvent.change(input, { target: { value: 'quem.pagou@outra.com' } });
    fireEvent.click(screen.getByText('Verificar meu pagamento'));

    await waitFor(() => expect(screen.getByText('Solicitação registrada')).toBeTruthy());
    expect(screen.queryByText('Assinatura liberada')).toBeNull();
    expect(screen.queryByText('Entrar no FacialPlan')).toBeNull();
    expect(rpcMock).toHaveBeenCalledWith('request_hotmart_purchase_recovery', {
      p_purchase_email: 'quem.pagou@outra.com',
    });
  });

  it('trata qualquer retorno inesperado da RPC como "em revisão" — o padrão é NÃO liberar', async () => {
    rpcMock.mockResolvedValue({ data: 'qualquer-coisa', error: null });
    await openForm();
    fireEvent.click(screen.getByText('Verificar meu pagamento'));
    await waitFor(() => expect(screen.getByText('Solicitação registrada')).toBeTruthy());
  });

  it('não chama a RPC com e-mail inválido', async () => {
    const input = await openForm();
    fireEvent.change(input, { target: { value: 'sem-arroba' } });
    // Submit disparado direto no form: num navegador a validação nativa do
    // <input type="email"> já barra o clique antes do handler, então clicar
    // aqui testaria o jsdom, não a guarda do componente — que é a rede de
    // proteção que importa se a validação nativa não rodar.
    fireEvent.submit(input.closest('form')!);
    expect(rpcMock).not.toHaveBeenCalled();
    expect(toastErrorMock).toHaveBeenCalled();
  });

  it('erro de rede não vira liberação nem solicitação registrada', async () => {
    rpcMock.mockResolvedValue({ data: null, error: { message: 'network' } });
    await openForm();
    fireEvent.click(screen.getByText('Verificar meu pagamento'));
    await waitFor(() => expect(toastErrorMock).toHaveBeenCalled());
    expect(screen.queryByText('Assinatura liberada')).toBeNull();
    expect(screen.queryByText('Solicitação registrada')).toBeNull();
  });
});
