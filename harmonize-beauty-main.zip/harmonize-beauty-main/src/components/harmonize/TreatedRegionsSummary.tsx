import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import HCard from '@/components/harmonize/HCard';
import {
  treatedRegionsSummary,
  formatTreatedRegionSince,
  type SessionForTreatedRegions,
} from '@/lib/treatedRegionsSummary';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

interface TreatedRegionsSummaryProps {
  /** Sessions already loaded by the parent (PacienteDetalhe) — no extra fetch,
   * mesmo padrão de PatientEvolutionTimeline. */
  sessions: SessionForTreatedRegions[] | undefined;
}

/**
 * Indicador Qualitativo de Regiões Tratadas — proposto por um comitê de
 * revisão como ALTERNATIVA a um score de harmonia em percentual (decisão de
 * produto já REJEITADA por ser pseudo-precisão de IA sem lastro clínico
 * mensurável). Em vez de um número, lista de forma descritiva quais regiões
 * faciais já foram acompanhadas ao longo da linha do tempo do paciente:
 * desde quando e em quantas sessões — ver src/lib/treatedRegionsSummary.ts
 * para a agregação em si, reaproveitada da mesma fonte de sessões concluídas
 * que a Linha do Tempo Evolutiva (P3) já usa.
 */
const TreatedRegionsSummary: React.FC<TreatedRegionsSummaryProps> = ({ sessions }) => {
  const { t, i18n } = useTranslation();
  const locale = dateFnsLocale[i18n.language] ?? ptBR;

  const regions = useMemo(() => treatedRegionsSummary(sessions), [sessions]);

  if (regions.length === 0) return null;

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
        <p className="text-[13px] font-semibold text-h-text">{t('patients.detail.treatedRegions.title')}</p>
      </div>

      <HCard>
        <div className="flex flex-col gap-3" data-testid="treated-regions-summary">
          {regions.map((r) => (
            <div
              key={r.region}
              className="flex items-center justify-between gap-3"
              data-testid={`treated-region-${r.region}`}
            >
              <p className="text-[13px] text-h-text">{r.label}</p>
              <p className="text-[11px] text-h-text-3 text-right flex-shrink-0">
                {t('patients.detail.treatedRegions.sinceCount', {
                  count: r.sessionCount,
                  date: formatTreatedRegionSince(r.firstTreatedAt, locale),
                })}
              </p>
            </div>
          ))}
        </div>
      </HCard>
    </div>
  );
};

export default TreatedRegionsSummary;
