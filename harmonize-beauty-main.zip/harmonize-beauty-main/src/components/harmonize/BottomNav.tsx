import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { navItems, isNavItemActive } from '@/components/harmonize/navItems';

const BottomNav: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around md:hidden"
      style={{
        backgroundColor: 'rgba(247,246,244,0.96)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderTop: '0.5px solid rgba(0,0,0,0.06)',
        paddingTop: 10,
        paddingBottom: 'calc(8px + env(safe-area-inset-bottom, 0px))',
      }}
    >
      {navItems.map((item) => {
        const isActive = isNavItemActive(item.path, location.pathname);
        const Icon = item.icon;

        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className="flex flex-col items-center gap-0.5 min-h-[44px] min-w-[44px] justify-center relative"
          >
            {isActive && (
              <div
                className="absolute top-[2px] rounded-[14px]"
                style={{ width: 48, height: 28, background: 'rgba(168,85,181,0.10)' }}
              />
            )}
            <Icon
              size={22}
              strokeWidth={isActive ? 2.5 : 1.5}
              style={{ color: isActive ? '#A855B5' : '#AAA8A5' }}
              className="relative z-10"
            />
            <span
              className="text-[10px] relative z-10"
              style={{
                fontWeight: isActive ? 700 : 500,
                color: isActive ? '#A855B5' : '#AAA8A5',
              }}
            >
              {t(item.labelKey)}
            </span>
          </button>
        );
      })}
    </div>
  );
};

export default BottomNav;
