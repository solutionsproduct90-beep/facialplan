import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AlertTriangle } from 'lucide-react';

import { useAuth } from '@/contexts/AuthContext';
import { graceDaysRemaining } from '@/lib/subscriptionAccess';

/**
 * Aviso dentro do app durante a carência de pagamento atrasado.
 *
 * O status 'past_due' dá alguns dias de acesso antes do bloqueio (ver
 * GRACE_PERIOD_DAYS em src/lib/subscriptionAccess.ts). Até aqui, o único
 * aviso era um e-mail — e e-mail de cobrança é exatamente o que cai em
 * promoções, é ignorado ou chega num endereço que a pessoa não usa. O
 * resultado prático era o profissional usar o app normalmente por três dias e
 * ser bloqueado sem aviso nenhum do lado dele, possivelmente no meio de um
 * atendimento, com o paciente na cadeira.
 *
 * Deliberadamente NÃO é dispensável. Um "x" transformaria o aviso em algo que
 * se fecha por reflexo no primeiro dia e nunca mais aparece, que é o mesmo
 * resultado do e-mail ignorado. Em compensação, ele fica no fluxo do conteúdo
 * (não é overlay fixo) e não impede nada: quem está na carência continua com
 * o app inteiro liberado.
 */
const SubscriptionGraceBanner: React.FC = () => {
  const { t } = useTranslation();
  const { profile } = useAuth();

  if (profile?.subscription_status !== 'past_due') return null;

  const days = graceDaysRemaining(profile.past_due_since);
  // null = fora da carência. Nesse caso o ProtectedRoute já mandou a pessoa
  // pra /regularizar, então não há o que avisar aqui.
  if (days === null) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="mb-4 flex items-start gap-3 rounded-r border px-4 py-3"
      style={{ borderColor: 'rgba(212,144,10,0.35)', background: 'rgba(212,144,10,0.10)' }}
    >
      <AlertTriangle size={18} className="shrink-0 mt-[1px] text-h-amber" />
      <div className="min-w-0">
        <p className="text-[13px] font-bold text-h-text">
          {t('account.graceBanner.title')}
        </p>
        <p className="text-[12px] text-h-text-2 mt-0.5 leading-relaxed">
          {t('account.graceBanner.message', { count: days })}
        </p>
        <Link
          to="/regularizar"
          className="inline-block mt-2 text-[12px] font-bold text-h-g-start underline underline-offset-2"
        >
          {t('account.graceBanner.cta')}
        </Link>
      </div>
    </div>
  );
};

export default SubscriptionGraceBanner;
