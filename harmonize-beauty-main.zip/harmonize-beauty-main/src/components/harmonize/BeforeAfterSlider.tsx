import React, { useRef, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';

interface BeforeAfterSliderProps {
  beforeImageUrl?: string;
  afterImageUrl?: string;
}

const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({ beforeImageUrl, afterImageUrl }) => {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState(50);
  const dragging = useRef(false);

  const updatePosition = useCallback((clientX: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = clientX - rect.left;
    const pct = Math.max(5, Math.min(95, (x / rect.width) * 100));
    setPosition(pct);
  }, []);

  const handleMouseDown = () => { dragging.current = true; };
  const handleMouseUp = () => { dragging.current = false; };
  const handleMouseMove = (e: React.MouseEvent) => {
    if (dragging.current) updatePosition(e.clientX);
  };

  const handleTouchStart = () => { dragging.current = true; };
  const handleTouchEnd = () => { dragging.current = false; };
  const handleTouchMove = (e: React.TouchEvent) => {
    if (dragging.current && e.touches[0]) {
      updatePosition(e.touches[0].clientX);
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[3/4] rounded-r overflow-hidden select-none cursor-col-resize"
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onMouseMove={handleMouseMove}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchMove={handleTouchMove}
    >
      {/* Before (full) */}
      <div className="absolute inset-0 bg-h-surface-3 flex items-center justify-center">
        {beforeImageUrl ? (
          <img
            src={beforeImageUrl}
            alt={t('common.before')}
            draggable={false}
            className="w-full h-full object-cover select-none"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-h-surface-3 to-h-bg" />
        )}
      </div>

      {/* After (clipped) — visível só à direita do handle, casando com o
          rótulo "Depois" (bottom-right). Antes desta correção o clip-path
          revelava a imagem "Depois" à ESQUERDA do handle, invertido com os
          rótulos. */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ clipPath: `inset(0 0 0 ${position}%)` }}
      >
        {afterImageUrl ? (
          <img
            src={afterImageUrl}
            alt={t('common.after')}
            draggable={false}
            className="w-full h-full object-cover select-none"
          />
        ) : (
          <div className="w-full h-full" style={{
            background: 'linear-gradient(135deg, rgba(224,92,138,0.08), rgba(168,85,181,0.12))',
            filter: 'brightness(1.05) contrast(1.05)',
          }}>
            <div className="w-full h-full bg-gradient-to-br from-h-surface-3 to-h-bg" style={{ filter: 'brightness(1.08) saturate(1.1)' }} />
          </div>
        )}
      </div>

      {/* Labels */}
      <div className="absolute bottom-3 left-3 bg-black/50 text-[11px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
        {t('common.before')}
      </div>
      <div className="absolute bottom-3 right-3 bg-black/50 text-[11px] font-bold px-2 py-1 rounded-full" style={{ color: '#fff' }}>
        {t('common.after')}
      </div>

      {/* Divider line */}
      <div
        className="absolute top-0 bottom-0 w-[2px] bg-white"
        style={{ left: `${position}%`, transform: 'translateX(-50%)' }}
      />

      {/* Handle — fica perto do topo da foto, não no meio vertical: no meio
          ele caía bem em cima da boca/nariz do paciente (rosto costuma ficar
          centralizado na foto), tampando exatamente a região que o
          antes/depois precisa comparar. A linha divisória (acima) já cobre
          a altura inteira, então mover o "botão" pra fora do rosto não
          perde a indicação visual do corte.

          Sem seta: a versão anterior desenhava um ícone de duas setas
          ("<" ">") dentro do círculo. Reposicionar o círculo (fix acima)
          não removia o ícone, e é exatamente esse ícone que o usuário
          reporta como bug persistente ("a seta ainda aparece") — não a
          posição. O grip abaixo (duas barrinhas verticais) mantém a
          affordance de "isto é arrastável" sem desenhar setas. */}
      <div
        className="absolute top-4 z-10"
        style={{ left: `${position}%`, transform: 'translateX(-50%)' }}
      >
        <div
          className="w-7 h-7 rounded-full bg-white shadow-h-md flex items-center justify-center gap-[3px]"
        >
          <span className="block w-[2px] h-3 rounded-full" style={{ background: '#A855B5' }} />
          <span className="block w-[2px] h-3 rounded-full" style={{ background: '#A855B5' }} />
        </div>
      </div>
    </div>
  );
};

export default BeforeAfterSlider;
