import React from 'react';
import { ChevronLeft } from 'lucide-react';
import { directionAtom } from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';

interface TopBarProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  leftAction?: React.ReactNode;
  /** Quando true, desce a TopBar em telas md: pra ficar abaixo da DesktopNav fixa (h-16). */
  offsetForDesktopNav?: boolean;
}

const TopBar: React.FC<TopBarProps> = ({ title, showBack = false, onBack, rightAction, leftAction, offsetForDesktopNav = false }) => {
  const navigate = useNavigate();

  // Em telas de nível raiz (Home, Pacientes, Sessões, Perfil), a DesktopNav fixa já cobre
  // logo + navegação. Sem um título de página, essa segunda faixa não tem conteúdo próprio
  // pra justificar existir em desktop — só duplicaria a DesktopNav com uma faixa quase vazia.
  // Quando há título (ex.: "Pacientes", "Sessões"), a faixa carrega informação/ações reais
  // (título da seção, botão de adicionar) que a DesktopNav não tem, então ela continua.
  const hideOnDesktop = offsetForDesktopNav && !title;

  return (
    <div
      className={`fixed left-0 right-0 z-50 flex items-end justify-between px-4 ${offsetForDesktopNav ? 'top-0 md:top-16' : 'top-0'} ${hideOnDesktop ? 'md:hidden' : ''}`}
      style={{
        backgroundColor: 'rgba(247,246,244,0.96)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderBottom: '0.5px solid rgba(0,0,0,0.06)',
        paddingTop: 'env(safe-area-inset-top, 0px)',
        height: 'calc(56px + env(safe-area-inset-top, 0px))',
      }}
    >
      <div
        className={`w-full mx-auto flex items-center justify-between ${offsetForDesktopNav ? 'max-w-[430px] md:max-w-[680px]' : ''}`}
        style={{ height: 56 }}
      >
        <div className="w-[60px] flex items-center">
          {leftAction ? (
            <div className="flex items-center">{leftAction}</div>
          ) : showBack ? (
            <button
              onClick={onBack || (() => { directionAtom.current = 'back'; navigate(-1); })}
              className="flex items-center text-h-g-start min-h-[44px] min-w-[44px]"
            >
              <ChevronLeft size={24} />
            </button>
          ) : null}
        </div>
        <div className="flex-1 text-center">
          {title && <h1 className="text-[17px] font-extrabold text-h-text truncate" style={{ letterSpacing: '-0.02em' }}>{title}</h1>}
        </div>
        <div className="w-[60px] flex items-center justify-end">
          {rightAction}
        </div>
      </div>
    </div>
  );
};

export default TopBar;
