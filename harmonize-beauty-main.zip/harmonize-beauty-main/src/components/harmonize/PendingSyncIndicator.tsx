import React from 'react';
import { useTranslation } from 'react-i18next';
import { CloudOff, RefreshCw } from 'lucide-react';

interface PendingSyncIndicatorProps {
  /** Há um rascunho local (IndexedDB) desta sessão ainda não confirmado no
   * Supabase — ver useOfflineSessionDraft. `false` esconde o indicador
   * inteiro (nada a mostrar). */
  pending: boolean;
  /** Uma tentativa de sincronização está em andamento agora mesmo. */
  syncing: boolean;
}

/**
 * Indicador complementar ao `OfflineBanner` (que só cobre o estado online/
 * offline do navegador, ver seu comentário) — este mostra, dentro do fluxo
 * de uma sessão específica, que há alterações salvas só localmente
 * aguardando sincronização com o Supabase (ver useOfflineSessionDraft).
 * Deliberadamente discreto (pill inline, não fixo/bloqueante como o
 * banner): o profissional pode seguir revisando/editando normalmente
 * enquanto isso — a sincronização acontece sozinha assim que a conexão
 * volta, sem exigir nenhuma ação aqui.
 */
const PendingSyncIndicator: React.FC<PendingSyncIndicatorProps> = ({ pending, syncing }) => {
  const { t } = useTranslation();

  if (!pending) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-semibold w-fit"
      style={{ background: 'rgba(212,144,10,0.10)', color: '#8A6608' }}
    >
      {syncing ? (
        <RefreshCw size={12} className="shrink-0 animate-spin" />
      ) : (
        <CloudOff size={12} className="shrink-0" />
      )}
      <span>{syncing ? t('offline.draftSyncing') : t('offline.draftPendingSync')}</span>
    </div>
  );
};

export default PendingSyncIndicator;
