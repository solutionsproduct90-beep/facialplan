import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import TreatmentPlanSection from './TreatmentPlanSection';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const insertSpy = vi.fn();
const updateSpy = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/** Builder pra `treatment_plans`: `.select().eq().order()` (lista) e `.insert()`. */
function createPlansBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    insert: (payload: Record<string, unknown>) => {
      insertSpy('treatment_plans', payload);
      return Promise.resolve({ error: null });
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

/** Builder pra `treatment_plan_steps`: `.select().in().order()` (lista), `.insert()` e `.update().eq()`. */
function createStepsBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    in: () => builder,
    order: () => builder,
    insert: (payload: Record<string, unknown>) => {
      insertSpy('treatment_plan_steps', payload);
      return Promise.resolve({ error: null });
    },
    update: (payload: Record<string, unknown>) => {
      const updateBuilder: any = {
        eq: (field: string, value: unknown) => {
          updateSpy(payload, { [field]: value });
          return Promise.resolve({ error: null });
        },
      };
      return updateBuilder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

/** Builder genérico pra `sessions`: só a listagem usada pelo select de vínculo. */
function createSessionsBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

const renderSection = (patientId = 'pat-1') =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <TreatmentPlanSection patientId={patientId} />
    </QueryClientProvider>,
  );

describe('TreatmentPlanSection', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
    insertSpy.mockReset();
    updateSpy.mockReset();
  });

  it('shows the empty state when the patient has no combo plan yet', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') return createPlansBuilder([]);
      if (table === 'treatment_plan_steps') return createStepsBuilder([]);
      if (table === 'sessions') return createSessionsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    expect(await screen.findByText('Nenhum protocolo combinado criado para este paciente.')).toBeInTheDocument();
  });

  it('lists a plan with its phased steps and the expected date computed from start date + offset', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          {
            id: 'plan-1',
            patient_id: 'pat-1',
            name: 'Protocolo de rejuvenescimento facial',
            description: 'Toxina + bioestimulador + skinbooster',
            start_date: '2026-01-01',
            created_at: '2026-01-01T10:00:00.000Z',
          },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'pendente', session_id: null, notes: null },
          { id: 'step-2', plan_id: 'plan-1', substance: 'bioestimulador', offset_days: 30, step_order: 1, status: 'pendente', session_id: null, notes: null },
        ]);
      }
      if (table === 'sessions') return createSessionsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();

    expect(await screen.findByText('Protocolo de rejuvenescimento facial')).toBeInTheDocument();
    expect(await screen.findByText('Toxina Botulínica')).toBeInTheDocument();
    expect(screen.getByText('Bioestimulador')).toBeInTheDocument();
    // Etapa "dia 0" cai na própria data de início do plano.
    expect(screen.getByText(/Previsto: 1 jan 2026/)).toBeInTheDocument();
    // Etapa "dia 30" = 2026-01-01 + 30 dias.
    expect(screen.getByText(/Previsto: 31 jan 2026/)).toBeInTheDocument();
  });

  it('creates a new combo plan with the name, description and start date entered', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') return createPlansBuilder([]);
      if (table === 'treatment_plan_steps') return createStepsBuilder([]);
      if (table === 'sessions') return createSessionsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Nenhum protocolo combinado criado para este paciente.');

    fireEvent.click(screen.getByTestId('treatment-plan-add-new'));
    fireEvent.change(screen.getByLabelText('Nome do plano'), { target: { value: 'Protocolo Combo VIP' } });
    fireEvent.change(screen.getByLabelText('Data de início'), { target: { value: '2026-09-11' } });
    fireEvent.click(screen.getByText('Criar plano'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledWith('treatment_plans', expect.objectContaining({
      professional_id: 'pro-1',
      patient_id: 'pat-1',
      name: 'Protocolo Combo VIP',
      start_date: '2026-09-11',
    })));
  });

  it('rejects an empty plan name instead of creating a bogus plan', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') return createPlansBuilder([]);
      if (table === 'treatment_plan_steps') return createStepsBuilder([]);
      if (table === 'sessions') return createSessionsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Nenhum protocolo combinado criado para este paciente.');

    fireEvent.click(screen.getByTestId('treatment-plan-add-new'));
    fireEvent.click(screen.getByText('Criar plano'));

    await waitFor(() => expect(insertSpy).not.toHaveBeenCalled());
  });

  it('adds a new step to an existing plan', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo Combo', description: null, start_date: '2026-01-01' },
        ]);
      }
      if (table === 'treatment_plan_steps') return createStepsBuilder([]);
      if (table === 'sessions') return createSessionsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Protocolo Combo');

    fireEvent.click(screen.getByText('Adicionar etapa'));
    fireEvent.change(screen.getByLabelText('Dias após o início'), { target: { value: '30' } });
    fireEvent.click(screen.getByText('Salvar etapa'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledWith('treatment_plan_steps', expect.objectContaining({
      professional_id: 'pro-1',
      plan_id: 'plan-1',
      offset_days: 30,
      step_order: 0,
    })));
  });

  it('links a real session to a pending step, marking it as completed', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo Combo', description: null, start_date: '2026-01-01' },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'pendente', session_id: null, notes: null },
        ]);
      }
      if (table === 'sessions') return createSessionsBuilder([{ id: 'ses-1', created_at: '2026-01-01T10:00:00.000Z' }]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Protocolo Combo');

    const select = await screen.findByLabelText('Vincular a esta etapa do plano');
    fireEvent.change(select, { target: { value: 'ses-1' } });
    fireEvent.click(screen.getByText('Vincular'));

    await waitFor(() =>
      expect(updateSpy).toHaveBeenCalledWith({ session_id: 'ses-1', status: 'concluida' }, { id: 'step-1' }),
    );
  });

  it('unlinks a completed step (wrong session linked by mistake), returning it to pendente', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo Combo', description: null, start_date: '2026-01-01' },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'concluida', session_id: 'ses-1', notes: null },
        ]);
      }
      if (table === 'sessions') return createSessionsBuilder([{ id: 'ses-1', created_at: '2026-01-01T10:00:00.000Z' }]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Protocolo Combo');

    fireEvent.click(await screen.findByText('Desvincular'));

    await waitFor(() =>
      expect(updateSpy).toHaveBeenCalledWith({ session_id: null, status: 'pendente' }, { id: 'step-1' }),
    );
  });

  it('unlinks a skipped step, also returning it to pendente (not deleting the step)', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo Combo', description: null, start_date: '2026-01-01' },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'pulada', session_id: null, notes: null },
        ]);
      }
      if (table === 'sessions') return createSessionsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Protocolo Combo');

    fireEvent.click(await screen.findByText('Desvincular'));

    await waitFor(() =>
      expect(updateSpy).toHaveBeenCalledWith({ session_id: null, status: 'pendente' }, { id: 'step-1' }),
    );
  });

  it('never shows "Desvincular" for a pending step, and never shows "Vincular"/"Pular" for a completed one', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo Combo', description: null, start_date: '2026-01-01' },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'pendente', session_id: null, notes: null },
          { id: 'step-2', plan_id: 'plan-1', substance: 'bioestimulador', offset_days: 30, step_order: 1, status: 'concluida', session_id: 'ses-1', notes: null },
        ]);
      }
      if (table === 'sessions') return createSessionsBuilder([{ id: 'ses-1', created_at: '2026-01-01T10:00:00.000Z' }]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Protocolo Combo');
    await screen.findByText('Bioestimulador');

    // Só a etapa pendente mostra Vincular/Pular; só a concluída mostra Desvincular.
    expect(screen.getAllByText('Vincular')).toHaveLength(1);
    expect(screen.getAllByText('Pular')).toHaveLength(1);
    expect(screen.getAllByText('Desvincular')).toHaveLength(1);
  });

  // ── Uma sessão não cumpre duas etapas (achado do ciclo 63 do QA) ─────────
  //
  // O filtro de sessões disponíveis olhava só as etapas do plano sendo
  // renderizado, então um paciente com dois protocolos combinados via a mesma
  // sessão oferecida nos dois. O vínculo é a evidência de que aquele
  // atendimento físico cumpriu aquela etapa; aceitar o duplo vínculo faz um
  // único atendimento inflar o progresso de dois protocolos.
  it('não oferece, no plano B, uma sessão já vinculada a uma etapa do plano A', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-a', patient_id: 'pat-1', name: 'Plano A', description: null, start_date: '2026-01-01', created_at: '2026-01-01T10:00:00.000Z' },
          { id: 'plan-b', patient_id: 'pat-1', name: 'Plano B', description: null, start_date: '2026-01-01', created_at: '2026-01-02T10:00:00.000Z' },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          // Plano A: etapa concluída, consumindo ses-1.
          { id: 'step-a', plan_id: 'plan-a', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'concluida', session_id: 'ses-1', notes: null },
          // Plano B: etapa pendente — o select dela não pode oferecer ses-1.
          { id: 'step-b', plan_id: 'plan-b', substance: 'bioestimulador', offset_days: 0, step_order: 0, status: 'pendente', session_id: null, notes: null },
        ]);
      }
      if (table === 'sessions') {
        return createSessionsBuilder([
          { id: 'ses-1', created_at: '2026-01-05T10:00:00.000Z' },
          { id: 'ses-2', created_at: '2026-01-06T10:00:00.000Z' },
        ]);
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Plano B');

    // `find` e não `get`: os planos renderizam antes das etapas chegarem, e
    // o select de vínculo só existe depois que a etapa pendente aparece.
    const select = await screen.findByLabelText('Vincular a esta etapa do plano');
    const opcoes = Array.from(select.querySelectorAll('option')).map((o) => (o as HTMLOptionElement).value);

    // ses-1 está fora; ses-2, que está livre, continua disponível. As duas
    // asserções juntas: sem a segunda, um filtro que escondesse tudo passaria.
    expect(opcoes).not.toContain('ses-1');
    expect(opcoes).toContain('ses-2');
  });

  it('oferece a sessão normalmente quando ela não está vinculada a plano nenhum', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'treatment_plans') {
        return createPlansBuilder([
          { id: 'plan-a', patient_id: 'pat-1', name: 'Plano A', description: null, start_date: '2026-01-01', created_at: '2026-01-01T10:00:00.000Z' },
        ]);
      }
      if (table === 'treatment_plan_steps') {
        return createStepsBuilder([
          { id: 'step-a', plan_id: 'plan-a', substance: 'toxina_botulinica', offset_days: 0, step_order: 0, status: 'pendente', session_id: null, notes: null },
        ]);
      }
      if (table === 'sessions') return createSessionsBuilder([{ id: 'ses-1', created_at: '2026-01-05T10:00:00.000Z' }]);
      throw new Error(`unexpected table ${table}`);
    });

    renderSection();
    await screen.findByText('Plano A');

    // `find` e não `get`: os planos renderizam antes das etapas chegarem, e
    // o select de vínculo só existe depois que a etapa pendente aparece.
    const select = await screen.findByLabelText('Vincular a esta etapa do plano');
    const opcoes = Array.from(select.querySelectorAll('option')).map((o) => (o as HTMLOptionElement).value);
    expect(opcoes).toContain('ses-1');
  });
});
