import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import TopBar from '@/components/harmonize/TopBar';
import BottomNav from '@/components/harmonize/BottomNav';
import DesktopNav from '@/components/harmonize/DesktopNav';
import LogoMark from '@/components/harmonize/LogoMark';
import SubscriptionGraceBanner from '@/components/harmonize/SubscriptionGraceBanner';

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  leftAction?: React.ReactNode;
  hideNav?: boolean;
  /**
   * Larga a área de conteúdo no desktop (`md:max-w-[1040px]` em vez do
   * `md:max-w-[680px]` padrão) — telas que usam o espaço extra pra um
   * dashboard de várias colunas em vez da mesma coluna única esticada (ver
   * Painel.tsx, único uso até agora). Mobile não muda (`max-w-[430px]`
   * continua igual com ou sem `wide`): o objetivo aqui é justamente fazer
   * desktop e mobile DIVERGIREM, não alargar os dois.
   */
  wide?: boolean;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, title, showBack, onBack, rightAction, leftAction, hideNav, wide }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-h-bg gap-4">
        <LogoMark size={48} />
        <div className="flex gap-1.5">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-[6px] h-[6px] rounded-full"
              style={{
                background: '#BF5F82',
                animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth/login" replace />;
  }

  return (
    <div className="min-h-screen bg-h-bg relative">
      {/* Wash decorativo pra preencher o espaço extra em telas grandes — some em mobile. */}
      <div
        className="hidden md:block fixed inset-0 -z-10 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(224,92,138,0.07), transparent 60%), ' +
            'radial-gradient(ellipse 50% 35% at 100% 100%, rgba(124,90,194,0.05), transparent 55%)',
        }}
      />
      <TopBar
        title={title}
        showBack={showBack}
        onBack={onBack}
        rightAction={rightAction}
        leftAction={leftAction}
        offsetForDesktopNav={!hideNav}
      />
      <div
        className={`scroll-container pb-[calc(80px+env(safe-area-inset-bottom,0px))] md:pb-10 ${
          hideNav ? 'pt-[calc(56px+env(safe-area-inset-top,0px))]' : 'pt-[calc(56px+env(safe-area-inset-top,0px))] md:pt-[120px]'
        }`}
      >
        <div className={`max-w-[430px] ${wide ? 'md:max-w-[1040px]' : 'md:max-w-[680px]'} mx-auto px-4 py-4 md:py-8`}>
          {/* Aviso de carência de pagamento: no fluxo do conteúdo, acima de
              qualquer tela do app, para não mexer nos offsets de header nem
              virar overlay. Renderiza null quando não há carência. */}
          <SubscriptionGraceBanner />
          {children}
        </div>
      </div>
      {!hideNav && <DesktopNav />}
      {!hideNav && <BottomNav />}
    </div>
  );
};

export default AppLayout;
