import { Home, Users, Layers, CalendarDays, LayoutDashboard, User, type LucideIcon } from 'lucide-react';

export interface NavItem {
  labelKey: string;
  icon: LucideIcon;
  path: string;
}

/**
 * Itens de navegação principais do app, compartilhados entre a BottomNav
 * (mobile) e a DesktopNav (topo, telas md+).
 */
export const navItems: NavItem[] = [
  { labelKey: 'nav.home', icon: Home, path: '/inicio' },
  { labelKey: 'nav.patients', icon: Users, path: '/pacientes' },
  { labelKey: 'nav.sessions', icon: Layers, path: '/sessoes' },
  { labelKey: 'nav.agenda', icon: CalendarDays, path: '/agenda' },
  { labelKey: 'nav.panel', icon: LayoutDashboard, path: '/painel' },
  { labelKey: 'nav.profile', icon: User, path: '/perfil' },
];

export const isNavItemActive = (path: string, pathname: string): boolean => pathname.startsWith(path);
