import React from "react";
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { render, screen, act } from "@testing-library/react";
import OfflineBanner from "./OfflineBanner";
import i18n from "@/i18n";

function setOnLine(value: boolean) {
  Object.defineProperty(window.navigator, "onLine", {
    configurable: true,
    value,
  });
}

describe("OfflineBanner", () => {
  const originalOnLine = window.navigator.onLine;

  beforeEach(async () => {
    await i18n.changeLanguage("pt");
  });

  afterEach(() => {
    setOnLine(originalOnLine);
  });

  it("renders nothing while online", () => {
    setOnLine(true);
    render(<OfflineBanner />);
    expect(screen.queryByText("Você está sem conexão — algumas ações podem falhar")).not.toBeInTheDocument();
  });

  it("shows the warning when the browser starts offline", () => {
    setOnLine(false);
    render(<OfflineBanner />);
    expect(screen.getByText("Você está sem conexão — algumas ações podem falhar")).toBeInTheDocument();
    expect(screen.getByRole("status")).toBeInTheDocument();
  });

  it("appears on an 'offline' event and disappears again on 'online'", () => {
    setOnLine(true);
    render(<OfflineBanner />);
    expect(screen.queryByRole("status")).not.toBeInTheDocument();

    act(() => {
      setOnLine(false);
      window.dispatchEvent(new Event("offline"));
    });
    expect(screen.getByRole("status")).toBeInTheDocument();

    act(() => {
      setOnLine(true);
      window.dispatchEvent(new Event("online"));
    });
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
  });
});
