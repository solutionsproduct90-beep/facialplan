import React from 'react';
import { useTranslation } from 'react-i18next';
import { AlertTriangle } from 'lucide-react';
import type { AnalysisProvenance } from '@/lib/analysisProvenance';
import { provenanceStampKeys, patientProvenanceStampKeys } from '@/lib/analysisProvenance';

interface AnalysisProvenanceBannerProps {
  provenance: AnalysisProvenance;
  /** 'professional' (padrão) fala com quem opera o app e traz a instrução do
   * que fazer (refazer a análise); 'patient' é a versão exibida na
   * apresentação/link público, sem jargão e sem instrução operacional. */
  audience?: 'professional' | 'patient';
}

/**
 * Aviso PERSISTENTE de proveniência da análise da Etapa 1 — substitui, nas
 * telas, o toast transitório que era o único sinal de que a análise gravada
 * era de demonstração (ver src/lib/analysisProvenance.ts para o histórico do
 * achado). Fica renderizado enquanto a sessão carregar aquela análise: some
 * só quando a análise for de fato da IA ('ai').
 *
 * Deliberadamente NÃO é um asterisco discreto nem um ícone com tooltip: uma
 * análise fabricada que chega a um PDF assinado ou a um prontuário exportado é
 * risco clínico/legal, então o bloco ocupa espaço, usa o mesmo vermelho de
 * alerta do banner de risco da anamnese (AnamnesisRiskBanner) e repete a
 * instrução do que fazer. 'unknown' (sessão antiga, sem marcador) usa o âmbar
 * de "atenção" — é uma ressalva, não a afirmação de que o dado é falso.
 */
const AnalysisProvenanceBanner: React.FC<AnalysisProvenanceBannerProps> = ({
  provenance,
  audience = 'professional',
}) => {
  const { t } = useTranslation();

  const keys = audience === 'patient'
    ? patientProvenanceStampKeys(provenance)
    : provenanceStampKeys(provenance);
  if (!keys) return null;

  const isDemo = provenance === 'mock';
  const accent = isDemo ? '224,80,80' : '212,144,10';
  const accentSolid = isDemo ? '#E05050' : '#D4900A';

  return (
    <div
      role="alert"
      data-testid="analysis-provenance-banner"
      data-provenance={provenance}
      className="rounded-r p-4"
      style={{ background: `rgba(${accent},0.08)`, border: `1px solid rgba(${accent},0.28)` }}
    >
      <div className="flex items-center gap-2 mb-1.5">
        <AlertTriangle size={16} className="flex-shrink-0" style={{ color: accentSolid }} />
        <p className="text-[13px] font-bold" style={{ color: accentSolid }}>{t(keys.title)}</p>
      </div>
      <p className="text-[12px] text-h-text-2 leading-relaxed">{t(keys.body)}</p>
      {keys.action && (
        <p className="text-[12px] font-semibold text-h-text-2 leading-relaxed mt-2">{t(keys.action)}</p>
      )}
    </div>
  );
};

export default AnalysisProvenanceBanner;
