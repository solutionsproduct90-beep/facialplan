import React, { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Loader2, ShieldQuestion } from 'lucide-react';
import { requestAdversarialRiskCheck } from '@/lib/adversarialRiskCheck';
import type { AdversarialRiskCheckRequest } from '@/lib/adversarialRiskCheck';

interface AdversarialRiskCheckProps {
  /**
   * Becomes `true` exactly when the risky decision the professional is
   * about to confirm is live on screen (skin screening: the "proceed
   * anyway" checkbox+justification are valid; dose threshold: the
   * procedure consent sheet is open with a dose over threshold).
   *
   * The request fires ONCE on this false→true transition and never refires
   * while `active` stays true — even if `request`'s contents keep changing
   * (e.g. the professional still editing the justification text). This is
   * deliberate: it must never become a per-keystroke API call. Going back
   * to `false` (closing the sheet, unchecking the box) resets it, so the
   * next activation fires a fresh request.
   */
  active: boolean;
  /** Null while there is nothing to check yet — treated the same as `active=false`. */
  request: AdversarialRiskCheckRequest | null;
}

type Status = 'idle' | 'loading' | 'ready' | 'unavailable';

/**
 * Segunda checagem automática de IA ("advogado do diabo") — ver
 * src/lib/adversarialRiskCheck.ts para o contrato completo e a razão de
 * ser. Puramente informativo: NUNCA desabilita nem esconde o botão de
 * confirmação do fluxo que a usa, e some de vista sem nenhum aviso quando o
 * recurso está indisponível (sem OPENAI_API_KEY no servidor, erro de
 * rede, etc.) — o profissional nunca vê um erro por causa deste widget.
 * `data-testid="adversarial-risk-check"` no card final identifica o widget
 * pronto para os testes; nada é renderizado antes disso (nem sequer um
 * placeholder), e nada é renderizado depois de "pular".
 */
const AdversarialRiskCheck: React.FC<AdversarialRiskCheckProps> = ({ active, request }) => {
  const { t } = useTranslation();
  const [status, setStatus] = useState<Status>('idle');
  const [skipped, setSkipped] = useState(false);
  const [counterpoint, setCounterpoint] = useState('');

  // Updated every render so the effect below always reads the freshest
  // request without needing it in the dependency array (which would refire
  // the fetch on every keystroke — see the `active` doc comment above).
  const requestRef = useRef(request);
  requestRef.current = request;
  const wasActiveRef = useRef(false);

  const isActive = active && !!request;

  useEffect(() => {
    if (!isActive) {
      wasActiveRef.current = false;
      setStatus('idle');
      setSkipped(false);
      setCounterpoint('');
      return;
    }
    if (wasActiveRef.current) return; // already fired for this activation
    wasActiveRef.current = true;

    let cancelled = false;
    setStatus('loading');
    setSkipped(false);
    setCounterpoint('');

    const currentRequest = requestRef.current;
    if (!currentRequest) return;
    requestAdversarialRiskCheck(currentRequest).then((result) => {
      if (cancelled) return;
      if (result.available && result.counterpoint) {
        setCounterpoint(result.counterpoint);
        setStatus('ready');
      } else {
        setStatus('unavailable');
      }
    });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deliberate: see the `active` doc comment above.
  }, [isActive]);

  if (!isActive || skipped || status === 'idle' || status === 'unavailable') {
    return null;
  }

  return (
    <div
      className="rounded-r-sm p-3.5"
      style={{ background: 'rgba(90,90,220,0.06)', border: '1px solid rgba(90,90,220,0.22)' }}
      data-testid="adversarial-risk-check"
    >
      {status === 'loading' && (
        <div className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-[12px] text-h-text-2">
            <Loader2 size={14} className="animate-spin flex-shrink-0" style={{ color: '#5A5ADC' }} />
            {t('adversarialCheck.loading')}
          </span>
          <button
            type="button"
            onClick={() => setSkipped(true)}
            data-testid="adversarial-risk-check-skip"
            className="text-[11px] font-bold underline flex-shrink-0"
            style={{ color: '#5A5ADC' }}
          >
            {t('adversarialCheck.skip')}
          </button>
        </div>
      )}
      {status === 'ready' && (
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <ShieldQuestion size={16} style={{ color: '#5A5ADC', flexShrink: 0 }} />
            <p className="text-[12px] font-bold" style={{ color: '#3F3FB0' }}>
              {t('adversarialCheck.title')}
            </p>
          </div>
          <p className="text-[12px] leading-relaxed text-h-text-2">{counterpoint}</p>
          <p className="text-[10px] text-h-text-3">{t('adversarialCheck.disclaimer')}</p>
        </div>
      )}
    </div>
  );
};

export default AdversarialRiskCheck;
