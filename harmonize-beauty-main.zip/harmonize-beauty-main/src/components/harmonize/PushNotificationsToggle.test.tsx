import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import PushNotificationsToggle from "./PushNotificationsToggle";
import i18n from "@/i18n";

// Notification / PushManager / navigator.serviceWorker não existem no jsdom
// deste ambiente de teste, então são mockados aqui — mesmo espírito do mock
// da Web Speech API em VoiceDictationButton.test.tsx, só que para as APIs
// de Web Push.

const useAuthMock = vi.fn();
vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

const upsertSpy = vi.fn();
const deleteEqSpy = vi.fn();
vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => {
      if (table !== "push_subscriptions") throw new Error(`tabela inesperada: ${table}`);
      return {
        upsert: (payload: unknown, opts: unknown) => {
          upsertSpy(payload, opts);
          return Promise.resolve({ error: null });
        },
        delete: () => ({
          eq: (column: string, value: string) => {
            deleteEqSpy(column, value);
            return Promise.resolve({ error: null });
          },
        }),
      };
    },
  },
}));

vi.mock("sonner", () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));
import { toast } from "sonner";

type MockSubscription = {
  endpoint: string;
  toJSON: () => { keys: { p256dh: string; auth: string } };
  unsubscribe: ReturnType<typeof vi.fn>;
};

function createMockSubscription(endpoint = "https://push.example.com/abc123"): MockSubscription {
  return {
    endpoint,
    toJSON: () => ({ keys: { p256dh: "p256dh-value", auth: "auth-value" } }),
    unsubscribe: vi.fn(async () => true),
  };
}

function installPushApis(options: {
  permission: NotificationPermission;
  requestPermissionResult?: NotificationPermission;
  existingSubscription?: MockSubscription | null;
  subscribeResult?: MockSubscription;
}) {
  const requestPermission = vi.fn(async () => options.requestPermissionResult ?? options.permission);
  (window as unknown as { Notification: unknown }).Notification = {
    permission: options.permission,
    requestPermission,
  };
  (window as unknown as { PushManager: unknown }).PushManager = function PushManager() {};

  let currentSubscription: MockSubscription | null = options.existingSubscription ?? null;
  const pushManager = {
    getSubscription: vi.fn(async () => currentSubscription),
    subscribe: vi.fn(async () => {
      currentSubscription = options.subscribeResult ?? createMockSubscription();
      return currentSubscription;
    }),
  };
  const registration = { pushManager };
  const serviceWorker = {
    register: vi.fn(async () => registration),
    getRegistration: vi.fn(async () => registration),
    ready: Promise.resolve(registration),
  };
  Object.defineProperty(navigator, "serviceWorker", { value: serviceWorker, configurable: true });

  return { requestPermission, pushManager, registration, serviceWorker, unsubscribeCurrent: () => currentSubscription };
}

function removePushApis() {
  delete (window as unknown as { Notification?: unknown }).Notification;
  delete (window as unknown as { PushManager?: unknown }).PushManager;
  Object.defineProperty(navigator, "serviceWorker", { value: undefined, configurable: true });
}

describe("PushNotificationsToggle", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" } });
    vi.clearAllMocks();
  });

  afterEach(() => {
    removePushApis();
  });

  it("navegador sem suporte: mostra o toggle desabilitado com texto explicando, sem travar a tela", async () => {
    removePushApis();
    render(<PushNotificationsToggle />);

    const toggle = await screen.findByRole("switch");
    expect(toggle).toBeDisabled();
    expect(toggle).not.toBeChecked();
    expect(screen.getByText(/instale o app/i)).toBeInTheDocument();
  });

  it("permissão concedida: pede permissão, inscreve no push manager e salva a inscrição no Supabase", async () => {
    installPushApis({ permission: "default", requestPermissionResult: "granted" });
    render(<PushNotificationsToggle />);

    const toggle = await screen.findByRole("switch");
    await waitFor(() => expect(toggle).not.toBeDisabled());
    expect(toggle).not.toBeChecked();

    fireEvent.click(toggle);

    await waitFor(() => expect(toggle).toBeChecked());
    expect(upsertSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        professional_id: "pro-1",
        endpoint: "https://push.example.com/abc123",
        p256dh: "p256dh-value",
        auth: "auth-value",
      }),
      { onConflict: "endpoint" },
    );
    expect(toast.success).toHaveBeenCalled();
  });

  it("permissão negada: não crasha, avisa o profissional e mantém o toggle desligado e desabilitado (sem reperguntar)", async () => {
    const { requestPermission } = installPushApis({ permission: "default", requestPermissionResult: "denied" });
    render(<PushNotificationsToggle />);

    const toggle = await screen.findByRole("switch");
    await waitFor(() => expect(toggle).not.toBeDisabled());

    fireEvent.click(toggle);

    await waitFor(() => expect(toast.error).toHaveBeenCalled());
    expect(toggle).not.toBeChecked();
    expect(upsertSpy).not.toHaveBeenCalled();
    expect(requestPermission).toHaveBeenCalledTimes(1);

    // Re-renderiza (ex.: profissional volta à tela depois) — como a
    // permissão do navegador já está 'denied', o toggle nasce desabilitado
    // e requestPermission não é chamado de novo sozinho.
    installPushApis({ permission: "denied" });
    render(<PushNotificationsToggle />);
    const toggles = await screen.findAllByRole("switch");
    const secondToggle = toggles[toggles.length - 1];
    await waitFor(() => expect(secondToggle).toBeDisabled());
  });

  it("desligar o toggle cancela a inscrição no navegador e remove a linha correspondente no Supabase", async () => {
    const existing = createMockSubscription("https://push.example.com/existing");
    installPushApis({ permission: "granted", existingSubscription: existing });
    render(<PushNotificationsToggle />);

    const toggle = await screen.findByRole("switch");
    await waitFor(() => expect(toggle).toBeChecked());

    fireEvent.click(toggle);

    await waitFor(() => expect(toggle).not.toBeChecked());
    expect(existing.unsubscribe).toHaveBeenCalledTimes(1);
    expect(deleteEqSpy).toHaveBeenCalledWith("endpoint", "https://push.example.com/existing");
  });
});
