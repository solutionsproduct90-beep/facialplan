import React, { useState } from 'react';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { ChevronDown, Check } from 'lucide-react';

export interface SheetSelectOption {
  value: string;
  label: string;
}

interface SheetSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: SheetSelectOption[];
  /** Título do BottomSheet que lista as opções. */
  title: string;
  placeholder?: string;
  className?: string;
  /**
   * Disparado ao abrir o sheet (toque no gatilho), antes de qualquer escolha.
   * Usado por telas que precisam saber que o campo foi ao menos olhado —
   * mesmo que o usuário feche sem trocar o valor (ver SessaoEstagio1's
   * exigência de revisão mínima antes de aceitar uma sugestão de IA).
   */
  onOpen?: () => void;
}

// Dropdown customizado com a cara do resto do app: um gatilho no estilo dos
// campos da tela (mesmo visual do antigo <select> nativo) que abre um
// BottomSheet com a lista de opções — em vez do menu padrão do navegador.
// Usa o mesmo padrão de Drawer aninhado já validado em AuthSelect/AnamnesisSheet.
const SheetSelect: React.FC<SheetSelectProps> = ({ value, onChange, options, title, placeholder, className, onOpen }) => {
  const [open, setOpen] = useState(false);
  const selected = options.find(o => o.value === value);

  return (
    <>
      <button
        type="button"
        onClick={() => { onOpen?.(); setOpen(true); }}
        className={`w-full bg-h-surface rounded-r-sm px-3 py-3 flex items-center justify-between gap-2 min-h-[44px] text-left ${className ?? ''}`}
      >
        <span className={`text-[14px] font-semibold truncate ${selected ? 'text-h-text' : 'text-h-text-3'}`}>
          {selected?.label ?? placeholder ?? ''}
        </span>
        <ChevronDown size={16} className="text-h-text-3 flex-shrink-0" />
      </button>

      <BottomSheet open={open} onClose={() => setOpen(false)} title={title}>
        <div style={{ padding: '4px 12px 12px' }} className="flex flex-col gap-0.5">
          {options.map(opt => {
            const isSelected = opt.value === value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => { onChange(opt.value); setOpen(false); }}
                className="w-full flex items-center justify-between gap-2 px-4 py-3 rounded-r-sm text-left min-h-[44px]"
                style={{ background: isSelected ? 'rgba(168,85,181,0.08)' : 'transparent' }}
              >
                <span className={`text-[14px] ${isSelected ? 'font-bold text-h-g-mid' : 'font-medium text-h-text'}`}>
                  {opt.label}
                </span>
                {isSelected && <Check size={16} className="text-h-g-mid flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      </BottomSheet>
    </>
  );
};

export default SheetSelect;
