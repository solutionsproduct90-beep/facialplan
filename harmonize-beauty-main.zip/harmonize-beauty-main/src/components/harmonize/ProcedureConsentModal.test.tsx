import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import ProcedureConsentModal from './ProcedureConsentModal';
import type { ProcedureConsentSummary } from '@/lib/procedureConsent';
import type { AdversarialRiskCheckRequest, AdversarialRiskCheckResult } from '@/lib/adversarialRiskCheck';
import i18n from '@/i18n';

const requestAdversarialRiskCheckMock = vi.fn<
  (request: AdversarialRiskCheckRequest) => Promise<AdversarialRiskCheckResult>
>();

vi.mock('@/lib/adversarialRiskCheck', async () => {
  const actual = await vi.importActual<typeof import('@/lib/adversarialRiskCheck')>(
    '@/lib/adversarialRiskCheck'
  );
  return {
    ...actual,
    requestAdversarialRiskCheck: (request: AdversarialRiskCheckRequest) =>
      requestAdversarialRiskCheckMock(request),
  };
});

const SUMMARY: ProcedureConsentSummary = {
  substances: ['toxina_botulinica'],
  totalsBySubstance: { toxina_botulinica: 120 },
  pointCount: 2,
  regionLabels: ['Glabela', 'Terço Frontal'],
};

const DOSE_REQUEST: AdversarialRiskCheckRequest = {
  type: 'dose_threshold',
  // Obrigatório desde o gate de consentimento no servidor (squad w1-3).
  patientId: 'pat-1',
  doseThreshold: {
    overages: [
      {
        substance: 'toxina_botulinica',
        total: 120,
        unit: 'unidades',
        threshold: 100,
        points: [{ region: 'glabela', quantity: 120 }],
      },
    ],
    isFirstSession: false,
  },
};

/** Fills the form up to the point where the confirm button would be enabled. */
async function fillFormUntilConfirmable() {
  await waitFor(() => expect(screen.queryByText('Role para baixo para continuar ↓')).not.toBeInTheDocument());
  fireEvent.change(screen.getByTestId('procedure-consent-name-input'), { target: { value: 'Maria Silva' } });
  fireEvent.click(screen.getByTestId('procedure-consent-checkbox'));
}

describe('ProcedureConsentModal', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    requestAdversarialRiskCheckMock.mockReset();
  });

  it('never shows the adversarial widget when there is nothing over threshold', async () => {
    render(
      <ProcedureConsentModal
        open={true}
        summary={SUMMARY}
        onConfirm={vi.fn()}
        adversarialRequest={null}
      />
    );
    await fillFormUntilConfirmable();
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();
    expect(requestAdversarialRiskCheckMock).not.toHaveBeenCalled();
    expect(screen.getByTestId('procedure-consent-confirm')).toBeEnabled();
  });

  it('shows loading then the AI counterpoint when a dose is over threshold, without ever disabling the confirm button because of it', async () => {
    let resolveCheck: (value: AdversarialRiskCheckResult) => void = () => {};
    requestAdversarialRiskCheckMock.mockReturnValue(
      new Promise((resolve) => {
        resolveCheck = resolve;
      })
    );

    render(
      <ProcedureConsentModal
        open={true}
        summary={SUMMARY}
        onConfirm={vi.fn()}
        adversarialRequest={DOSE_REQUEST}
      />
    );
    await fillFormUntilConfirmable();

    expect(await screen.findByText(/Consultando uma segunda opinião crítica da IA/)).toBeInTheDocument();
    // The professional can confirm right away — the AI check never gates it.
    expect(screen.getByTestId('procedure-consent-confirm')).toBeEnabled();

    resolveCheck({ available: true, counterpoint: 'Risco concreto: dose de toxina acima do teto de face inteira.' });

    await waitFor(() =>
      expect(
        screen.getByText('Risco concreto: dose de toxina acima do teto de face inteira.')
      ).toBeInTheDocument()
    );
    expect(screen.getByTestId('procedure-consent-confirm')).toBeEnabled();
  });

  it('calls onConfirm with the typed name once the professional confirms, regardless of the AI check still loading', async () => {
    requestAdversarialRiskCheckMock.mockReturnValue(new Promise(() => {})); // never resolves
    const onConfirm = vi.fn();

    render(
      <ProcedureConsentModal
        open={true}
        summary={SUMMARY}
        onConfirm={onConfirm}
        adversarialRequest={DOSE_REQUEST}
      />
    );
    await fillFormUntilConfirmable();
    await screen.findByText(/Consultando uma segunda opinião crítica da IA/);

    fireEvent.click(screen.getByTestId('procedure-consent-confirm'));
    expect(onConfirm).toHaveBeenCalledWith('Maria Silva');
  });

  it('hides the widget entirely (no error) when the AI check is unavailable', async () => {
    requestAdversarialRiskCheckMock.mockResolvedValue({ available: false });

    render(
      <ProcedureConsentModal
        open={true}
        summary={SUMMARY}
        onConfirm={vi.fn()}
        adversarialRequest={DOSE_REQUEST}
      />
    );
    await fillFormUntilConfirmable();

    await waitFor(() => expect(requestAdversarialRiskCheckMock).toHaveBeenCalledTimes(1));
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();
    expect(screen.getByTestId('procedure-consent-confirm')).toBeEnabled();
  });

  it('does not fetch the AI check while the sheet is closed', () => {
    render(
      <ProcedureConsentModal
        open={false}
        summary={SUMMARY}
        onConfirm={vi.fn()}
        adversarialRequest={DOSE_REQUEST}
      />
    );
    expect(requestAdversarialRiskCheckMock).not.toHaveBeenCalled();
  });
});
