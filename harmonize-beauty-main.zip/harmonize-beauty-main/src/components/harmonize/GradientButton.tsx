import React from 'react';

interface GradientButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

const GradientButton = React.forwardRef<HTMLButtonElement, GradientButtonProps>(
  ({ children, className = '', ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={`w-full h-[48px] min-h-[44px] rounded-full bg-gradient-brand font-bold text-[15px] shadow-gradient press-scale disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
        style={{ color: '#FFFFFF', letterSpacing: '-0.01em' }}
        
        {...props}
      >
        {children}
      </button>
    );
  }
);

GradientButton.displayName = 'GradientButton';

export default GradientButton;
