import React from "react";
import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import HarmonizeBadge from "./Badge";

describe("HarmonizeBadge", () => {
  it("renders its children text", () => {
    render(<HarmonizeBadge variant="neutral">Admin</HarmonizeBadge>);
    expect(screen.getByText("Admin")).toBeInTheDocument();
  });

  it("applies the 'alta' variant colors", () => {
    render(<HarmonizeBadge variant="alta">10</HarmonizeBadge>);
    const el = screen.getByText("10");
    expect(el).toHaveStyle({ color: "#E05050" });
  });

  it("applies the 'media' variant colors", () => {
    render(<HarmonizeBadge variant="media">5</HarmonizeBadge>);
    const el = screen.getByText("5");
    expect(el).toHaveStyle({ color: "#D4900A" });
  });

  it("applies the 'baixa' variant colors", () => {
    render(<HarmonizeBadge variant="baixa">1</HarmonizeBadge>);
    const el = screen.getByText("1");
    expect(el).toHaveStyle({ color: "#2DB87A" });
  });

  it("applies the 'grad' variant colors", () => {
    render(<HarmonizeBadge variant="grad">Admin</HarmonizeBadge>);
    const el = screen.getByText("Admin");
    expect(el).toHaveStyle({ color: "#A855B5" });
  });

  it("applies the 'neutral' variant colors by default styling", () => {
    render(<HarmonizeBadge variant="neutral">0</HarmonizeBadge>);
    const el = screen.getByText("0");
    expect(el).toHaveStyle({ color: "#6B6965", backgroundColor: "#E5E3E0" });
  });

  it("renders as a span with pill-shaped border radius", () => {
    render(<HarmonizeBadge variant="neutral">Tag</HarmonizeBadge>);
    const el = screen.getByText("Tag");
    expect(el.tagName).toBe("SPAN");
    expect(el).toHaveStyle({ borderRadius: "980px" });
  });
});
