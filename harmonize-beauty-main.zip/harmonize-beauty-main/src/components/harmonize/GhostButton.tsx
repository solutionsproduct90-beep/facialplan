import React from 'react';

const GhostButton = React.forwardRef<HTMLButtonElement, React.ButtonHTMLAttributes<HTMLButtonElement>>(
  ({ children, className = '', ...props }, ref) => (
    <button
      ref={ref}
      className={`w-full h-[48px] min-h-[44px] rounded-full font-bold text-[15px] text-h-g-start transition-all active:scale-[0.98] ${className}`}
      style={{ backgroundColor: 'rgba(224,92,138,0.10)' }}
      {...props}
    >
      {children}
    </button>
  )
);

GhostButton.displayName = 'GhostButton';
export default GhostButton;
