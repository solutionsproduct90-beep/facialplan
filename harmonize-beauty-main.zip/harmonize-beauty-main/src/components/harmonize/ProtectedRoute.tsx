import React from 'react';
import { Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { decideAccess } from '@/lib/subscriptionAccess';
import FullScreenLoader from './FullScreenLoader';

// As regras de quem entra vivem em src/lib/subscriptionAccess.ts — inclusive
// os comentários sobre a carência de 'past_due' e sobre os outros dois lugares
// que precisam concordar com elas (RLS e edge functions). Aqui fica só a
// tradução da decisão em navegação, pra que a mesma regra possa ser
// consultada fora de um componente de rota (ex.: a espera pela liberação
// depois do checkout, em useSubscriptionActivationWatch).
const DESTINATION: Record<Exclude<ReturnType<typeof decideAccess>, 'allow'>, string> = {
  blocked: '/conta-bloqueada',
  regularizar: '/regularizar',
  assinar: '/assinar',
};

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading, profile, profileLoading } = useAuth();
  const { t } = useTranslation();

  // Só espera o perfil carregar quando já há um usuário autenticado — evita
  // um segundo spinner desnecessário no caminho (mais comum) de visitante
  // não logado, que nem dispara a query de perfil no AuthContext.
  if (loading || (user && profileLoading)) {
    return <FullScreenLoader label={t('common.loading')} />;
  }

  if (!user) {
    return <Navigate to="/auth/login" replace />;
  }

  const decision = decideAccess(profile);
  if (decision !== 'allow') {
    return <Navigate to={DESTINATION[decision]} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
