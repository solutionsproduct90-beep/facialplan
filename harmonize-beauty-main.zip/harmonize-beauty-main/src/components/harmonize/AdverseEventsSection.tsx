import React, { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { AlertTriangle, ShieldAlert, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import HCard from '@/components/harmonize/HCard';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import {
  normalizeAdverseEvents,
  validateAdverseEventDraft,
  buildAdverseEventPayload,
  ADVERSE_EVENT_TYPES,
  ADVERSE_EVENT_SEVERITIES,
  type AdverseEventDraft,
  type AdverseEventSeverity,
} from '@/lib/adverseEvents';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

const SEVERITY_BADGE: Record<AdverseEventSeverity, 'baixa' | 'media' | 'alta'> = {
  leve: 'baixa',
  moderada: 'media',
  grave: 'alta',
};

type InsumoOption = { id: string; brand_name: string };
type SessionOption = { id: string; created_at: string };

/**
 * Seção "Eventos adversos" da ficha do paciente — farmacovigilância por
 * lote/marca de insumo (ver comentário na migration
 * 20260910200000_add_adverse_events.sql). Diferente de agenda/estoque, não
 * é uma aba do /painel: fica dentro de PacienteDetalhe.tsx porque um evento
 * adverso só faz sentido no contexto de UM paciente específico — mas segue
 * o mesmo padrão de seção autocontida (query própria + BottomSheet de
 * registro) já usado por EstoqueTab/AgendaTab.
 */
const AdverseEventsSection: React.FC<{ patientId: string }> = ({ patientId }) => {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const queryClient = useQueryClient();
  const locale = dateFnsLocale[i18n.language] ?? ptBR;

  const [sheetOpen, setSheetOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [draftEventType, setDraftEventType] = useState<string>('nodulo');
  const [draftSeverity, setDraftSeverity] = useState<string>('leve');
  const [draftDescription, setDraftDescription] = useState('');
  const [draftDate, setDraftDate] = useState('');
  const [draftTime, setDraftTime] = useState('');
  const [draftSessionId, setDraftSessionId] = useState('');
  const [draftInsumoId, setDraftInsumoId] = useState('');

  const eventsQueryKey = ['adverse-events', patientId];

  const {
    data: eventsRaw,
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: eventsQueryKey,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('adverse_events')
        .select('*, insumo:insumos(brand_name)')
        .eq('patient_id', patientId)
        .order('occurred_at', { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!patientId,
  });

  const { data: insumos } = useQuery({
    queryKey: ['adverse-events-insumos', user?.id],
    queryFn: async (): Promise<InsumoOption[]> => {
      const { data, error } = await supabase
        .from('insumos')
        .select('id, brand_name')
        .eq('professional_id', user!.id)
        .order('brand_name', { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  const { data: sessions } = useQuery({
    queryKey: ['adverse-events-sessions', patientId],
    queryFn: async (): Promise<SessionOption[]> => {
      const { data, error } = await supabase
        .from('sessions')
        .select('id, created_at')
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!patientId,
  });

  const events = useMemo(() => normalizeAdverseEvents(eventsRaw ?? []), [eventsRaw]);

  const openNew = () => {
    setDraftEventType('nodulo');
    setDraftSeverity('leve');
    setDraftDescription('');
    setDraftSessionId('');
    setDraftInsumoId('');
    const now = new Date();
    setDraftDate(format(now, 'yyyy-MM-dd'));
    setDraftTime(format(now, 'HH:mm'));
    setSheetOpen(true);
  };

  const handleSave = async () => {
    if (!user) return;
    const draft: AdverseEventDraft = {
      eventType: draftEventType,
      severity: draftSeverity,
      description: draftDescription,
      occurredAtDate: draftDate,
      occurredAtTime: draftTime,
    };
    const validationError = validateAdverseEventDraft(draft);
    if (validationError) {
      toast.error(t(`adverseEvents.form.errors.${validationError}`));
      return;
    }

    setSaving(true);
    try {
      const payload = buildAdverseEventPayload(draft, {
        professionalId: user.id,
        patientId,
        sessionId: draftSessionId || null,
        insumoId: draftInsumoId || null,
      });
      const { error } = await supabase.from('adverse_events').insert(payload);
      if (error) throw error;
      await queryClient.invalidateQueries({ queryKey: eventsQueryKey });
      setSheetOpen(false);
      toast.success(t('adverseEvents.toastSaved'));
    } catch (err: any) {
      toast.error(err.message || t('adverseEvents.toastError'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <ShieldAlert size={14} style={{ color: '#E05050' }} />
          <p className="text-[13px] font-semibold text-h-text">{t('adverseEvents.title')}</p>
        </div>
        <button
          onClick={openNew}
          data-testid="adverse-events-add-new"
          className="flex items-center gap-1.5 press-scale"
          style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, fontSize: 12, fontWeight: 600 }}
        >
          {t('adverseEvents.addNew')}
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col gap-2">
          <SkeletonCard lines={2} />
        </div>
      ) : isError ? (
        <HCard className="flex flex-col items-center gap-2 text-center py-6">
          <p className="text-[13px] text-h-text-2">{t('adverseEvents.error.load')}</p>
          <button
            onClick={() => refetch()}
            className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
            style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
          >
            <RefreshCw size={14} />
            {t('adverseEvents.error.retry')}
          </button>
        </HCard>
      ) : events.length === 0 ? (
        <div className="bg-h-white rounded-r p-5 shadow-h-sm text-center">
          <p className="text-[14px] text-h-text-3">{t('adverseEvents.empty')}</p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {events.map((ev) => (
            <HCard key={ev.id}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-[13px] font-semibold text-h-text">
                    {t(`adverseEvents.eventType.${ev.eventType}`)}
                  </p>
                  <p className="text-[11px] text-h-text-3 mt-0.5">
                    {format(new Date(ev.occurredAt), 'PPp', { locale })}
                    {ev.insumoBrandName ? ` · ${ev.insumoBrandName}` : ''}
                  </p>
                  <p className="text-[12px] text-h-text-2 leading-snug mt-1.5">{ev.description}</p>
                </div>
                <HarmonizeBadge variant={SEVERITY_BADGE[ev.severity]}>
                  {t(`adverseEvents.severity.${ev.severity}`)}
                </HarmonizeBadge>
              </div>
            </HCard>
          ))}
        </div>
      )}

      <BottomSheet open={sheetOpen} onClose={() => setSheetOpen(false)} title={t('adverseEvents.form.title')}>
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          <div className="flex items-start gap-2 p-3 rounded-r-sm" style={{ background: 'rgba(224,80,80,0.06)' }}>
            <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" style={{ color: '#E05050' }} />
            <p className="text-[11px] text-h-text-2 leading-snug">{t('adverseEvents.form.disclaimer')}</p>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.eventTypeLabel')}</label>
            <select
              value={draftEventType}
              onChange={(e) => setDraftEventType(e.target.value)}
              aria-label={t('adverseEvents.form.eventTypeLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              {ADVERSE_EVENT_TYPES.map((type) => (
                <option key={type} value={type}>{t(`adverseEvents.eventType.${type}`)}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.severityLabel')}</label>
            <select
              value={draftSeverity}
              onChange={(e) => setDraftSeverity(e.target.value)}
              aria-label={t('adverseEvents.form.severityLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              {ADVERSE_EVENT_SEVERITIES.map((sev) => (
                <option key={sev} value={sev}>{t(`adverseEvents.severity.${sev}`)}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.dateLabel')}</label>
              <input
                type="date"
                value={draftDate}
                onChange={(e) => setDraftDate(e.target.value)}
                aria-label={t('adverseEvents.form.dateLabel')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.timeLabel')}</label>
              <input
                type="time"
                value={draftTime}
                onChange={(e) => setDraftTime(e.target.value)}
                aria-label={t('adverseEvents.form.timeLabel')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.insumoLabel')}</label>
            <select
              value={draftInsumoId}
              onChange={(e) => setDraftInsumoId(e.target.value)}
              aria-label={t('adverseEvents.form.insumoLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              <option value="">{t('adverseEvents.form.insumoPlaceholder')}</option>
              {(insumos ?? []).map((i) => (
                <option key={i.id} value={i.id}>{i.brand_name}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.sessionLabel')}</label>
            <select
              value={draftSessionId}
              onChange={(e) => setDraftSessionId(e.target.value)}
              aria-label={t('adverseEvents.form.sessionLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              <option value="">{t('adverseEvents.form.sessionPlaceholder')}</option>
              {(sessions ?? []).map((s) => (
                <option key={s.id} value={s.id}>
                  {format(new Date(s.created_at), 'PP', { locale })}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('adverseEvents.form.descriptionLabel')}</label>
            <textarea
              value={draftDescription}
              onChange={(e) => setDraftDescription(e.target.value)}
              placeholder={t('adverseEvents.form.descriptionPlaceholder')}
              aria-label={t('adverseEvents.form.descriptionLabel')}
              rows={4}
              className="rounded-r-sm px-[14px] py-3 text-[14px] font-medium text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30 resize-none"
            />
          </div>

          <GradientButton onClick={handleSave} disabled={saving}>
            {saving ? t('panel.saving') : t('adverseEvents.form.save')}
          </GradientButton>
        </div>
      </BottomSheet>
    </div>
  );
};

export default AdverseEventsSection;
