import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/client';
import HCard from '@/components/harmonize/HCard';
import BottomSheet from '@/components/harmonize/BottomSheet';
import GhostButton from '@/components/harmonize/GhostButton';
import GradientButton from '@/components/harmonize/GradientButton';
import BeforeAfterViewer from '@/components/harmonize/BeforeAfterViewer';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

export interface EvolutionTimelineSession {
  id: string;
  created_at: string | null;
  status: string | null;
  original_image_url: string | null;
  selected_procedure: string | null;
}

interface PatientEvolutionTimelineProps {
  /** Sessions already loaded by the parent (PacienteDetalhe) — no extra fetch. */
  sessions: EvolutionTimelineSession[] | undefined;
}

/**
 * Galeria cronológica com a foto frontal de cada sessão CONCLUÍDA do
 * paciente, mais um comparador entre duas datas quaisquer escolhidas pelo
 * usuário na linha do tempo. Diferente do antes/depois de uma única sessão
 * (Etapa 3 / SessaoPresent, que compara a foto original com a simulação
 * dessa mesma sessão), aqui as duas fotos comparadas podem vir de sessões
 * completamente diferentes — o objetivo é mostrar a evolução real do
 * paciente ao longo de múltiplos atendimentos.
 *
 * Reaproveita BeforeAfterViewer (com seus 5 modos: slider, lado a lado,
 * fade, raio-x e riscar) em vez de criar um novo comparador — o widget já
 * cobre exatamente "duas fotos lado a lado / sobrepostas com controles",
 * que é tudo que este comparador precisa.
 */
const PatientEvolutionTimeline: React.FC<PatientEvolutionTimelineProps> = ({ sessions }) => {
  const { t, i18n } = useTranslation();
  const locale = dateFnsLocale[i18n.language] ?? ptBR;
  const [signedUrls, setSignedUrls] = useState<Record<string, string | null>>({});
  const [selected, setSelected] = useState<string[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);

  // Só sessões concluídas têm uma foto frontal "final" e estável o
  // suficiente para representar aquele ponto da evolução — stage1/stage2
  // ainda estão em andamento e "abandoned" nunca chegou a gerar simulação.
  // Ordenadas da mais antiga para a mais recente: é uma LINHA DO TEMPO.
  const completed = useMemo(
    () =>
      (sessions ?? [])
        .filter((s) => s.status === 'complete' && !!s.original_image_url && !!s.created_at)
        .sort((a, b) => new Date(a.created_at as string).getTime() - new Date(b.created_at as string).getTime()),
    [sessions]
  );

  const completedKey = completed.map((s) => s.id).join(',');

  useEffect(() => {
    if (completed.length === 0) {
      setSignedUrls({});
      return;
    }
    let cancelled = false;
    (async () => {
      // `createSignedUrls` em lote (uma única chamada de rede pra todas as
      // fotos da linha do tempo) em vez de um `createSignedUrl` por sessão —
      // evitando o N+1 de antes, que abria uma requisição HTTP por foto.
      const paths = completed.map((s) => s.original_image_url as string);
      const { data, error } = await supabase.storage.from('patient-photos').createSignedUrls(paths, 3600);
      if (cancelled) return;
      if (error || !data) {
        setSignedUrls({});
        return;
      }
      // Uma falha ao assinar uma foto específica (item com `error` != null e
      // `signedUrl: null`) não deve derrubar as demais — cada sessão cai em
      // `null` isoladamente, mesmo comportamento de antes por sessão.
      const urlByPath = new Map(data.map((d) => [d.path, d.signedUrl]));
      const entries = completed.map((s) => [s.id, urlByPath.get(s.original_image_url as string) ?? null] as const);
      setSignedUrls(Object.fromEntries(entries));
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [completedKey]);

  if (completed.length === 0) return null;

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      // Ao escolher uma terceira foto, mantém a última seleção e troca a
      // mais antiga das duas — evita ter que "desmarcar" manualmente pra
      // trocar de comparação.
      if (prev.length >= 2) return [prev[1], id];
      return [...prev, id];
    });
  };

  // Ordem cronológica na comparação, independente da ordem de clique do
  // usuário — a mais antiga das duas sempre entra como "antes".
  const selectedSessions = completed
    .filter((s) => selected.includes(s.id))
    .sort((a, b) => new Date(a.created_at as string).getTime() - new Date(b.created_at as string).getTime());
  const canCompare = selectedSessions.length === 2;

  const formatDate = (dateStr: string) => format(new Date(dateStr), 'PP', { locale });

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
        <p className="text-[13px] font-semibold text-h-text">{t('patients.detail.evolutionTimeline.title')}</p>
      </div>

      <HCard>
        <div className="flex gap-3 overflow-x-auto pb-1" data-testid="evolution-timeline-gallery">
          {completed.map((s) => {
            const isSelected = selected.includes(s.id);
            const url = signedUrls[s.id];
            return (
              <button
                key={s.id}
                type="button"
                data-testid={`evolution-photo-${s.id}`}
                aria-pressed={isSelected}
                onClick={() => toggleSelect(s.id)}
                className="flex flex-col items-center gap-1 flex-shrink-0 press-scale"
                style={{ width: 72 }}
              >
                <div
                  className="w-[72px] h-[72px] rounded-r overflow-hidden bg-h-surface-3 flex items-center justify-center"
                  style={{
                    outline: isSelected ? '3px solid #BF5F82' : '1px solid rgba(0,0,0,0.06)',
                    outlineOffset: isSelected ? '-3px' : '-1px',
                  }}
                >
                  {url ? (
                    <img src={url} alt={s.selected_procedure || formatDate(s.created_at as string)} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-h-surface-3 to-h-bg" />
                  )}
                </div>
                <p className="text-[10px] text-h-text-3 text-center leading-tight">
                  {formatDate(s.created_at as string)}
                </p>
              </button>
            );
          })}
        </div>

        <div className="mt-3 flex flex-col gap-2">
          <p className="text-[11px] text-h-text-3 text-center">
            {selected.length < 2
              ? t('patients.detail.evolutionTimeline.hintSelect')
              : t('patients.detail.evolutionTimeline.hintReady')}
          </p>
          <GradientButton disabled={!canCompare} onClick={() => setCompareOpen(true)}>
            {t('patients.detail.evolutionTimeline.compareButton')}
          </GradientButton>
        </div>
      </HCard>

      <BottomSheet
        open={compareOpen && canCompare}
        onClose={() => setCompareOpen(false)}
        title={
          canCompare
            ? t('patients.detail.evolutionTimeline.compareTitle', {
                from: formatDate(selectedSessions[0].created_at as string),
                to: formatDate(selectedSessions[1].created_at as string),
              })
            : undefined
        }
      >
        {canCompare && (
          <div className="px-5 pb-5 flex flex-col gap-4">
            <BeforeAfterViewer
              beforeImageUrl={signedUrls[selectedSessions[0].id]}
              afterImageUrl={signedUrls[selectedSessions[1].id]}
            />
            <GhostButton onClick={() => setCompareOpen(false)}>
              {t('patients.detail.evolutionTimeline.close')}
            </GhostButton>
          </div>
        )}
      </BottomSheet>
    </div>
  );
};

export default PatientEvolutionTimeline;
