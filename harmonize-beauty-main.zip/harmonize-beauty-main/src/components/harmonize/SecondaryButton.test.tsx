import React from "react";
import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import SecondaryButton from "./SecondaryButton";

describe("SecondaryButton", () => {
  it("renders its children", () => {
    render(<SecondaryButton>Cancelar</SecondaryButton>);
    expect(screen.getByRole("button", { name: "Cancelar" })).toBeInTheDocument();
  });

  it("fires onClick when clicked", () => {
    const onClick = vi.fn();
    render(<SecondaryButton onClick={onClick}>Voltar</SecondaryButton>);

    fireEvent.click(screen.getByRole("button", { name: "Voltar" }));

    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("is disabled when the disabled prop is set and does not fire onClick", () => {
    const onClick = vi.fn();
    render(
      <SecondaryButton disabled onClick={onClick}>
        Voltar
      </SecondaryButton>
    );

    const button = screen.getByRole("button", { name: "Voltar" });
    expect(button).toBeDisabled();

    fireEvent.click(button);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("merges a custom className with its default classes", () => {
    render(<SecondaryButton className="my-extra-class">Ok</SecondaryButton>);
    const button = screen.getByRole("button", { name: "Ok" });
    expect(button).toHaveClass("my-extra-class");
    expect(button).toHaveClass("bg-h-white");
  });

  it("forwards a ref to the underlying button element", () => {
    const ref = React.createRef<HTMLButtonElement>();
    render(<SecondaryButton ref={ref}>Ref test</SecondaryButton>);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
    expect(ref.current?.textContent).toBe("Ref test");
  });
});
