import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  SIMPLE_RISK_KEYS,
  type CompositeRiskKey,
  type RiskFlags,
  type SimpleRiskKey,
} from '@/types/anamnesis';

interface AnamnesisRiskFieldsProps {
  value: RiskFlags;
  onChange: (next: RiskFlags) => void;
  /**
   * Chaves de pergunta habilitadas para este profissional (configurável em
   * /perfil/anamnese — ver `anamnesis_question_settings`). `undefined`
   * mostra todas as 18 perguntas (comportamento padrão / enquanto as
   * configurações carregam).
   */
  enabledKeys?: ReadonlySet<string>;
}

const inputClass =
  'w-full h-[40px] rounded-[10px] px-3 text-[13px] bg-h-white border border-black/10 outline-none';

const CheckRow: React.FC<{ label: string; checked: boolean; onToggle: () => void; children?: React.ReactNode }> = ({
  label,
  checked,
  onToggle,
  children,
}) => (
  <div className="bg-h-white rounded-r-sm shadow-h-sm p-3">
    <label className="flex items-start gap-3 cursor-pointer">
      <input
        type="checkbox"
        checked={checked}
        onChange={onToggle}
        style={{ marginTop: 2, width: 20, height: 20, flexShrink: 0 }}
      />
      <span className="text-[13px] text-h-text leading-snug">{label}</span>
    </label>
    {checked && children && <div className="mt-2 pl-8">{children}</div>}
  </div>
);

/**
 * As 18 perguntas de histórico clínico/risco de `anamnesis.risk_flags`, em
 * linguagem simples para o paciente entender — reaproveitado tanto pelo
 * formulário do profissional (AnamnesisSheet.tsx) quanto pelo formulário
 * público (AnamneseCompartilhada.tsx), pra manter as duas telas idênticas.
 */
const AnamnesisRiskFields: React.FC<AnamnesisRiskFieldsProps> = ({ value, onChange, enabledKeys }) => {
  const { t } = useTranslation();
  const isEnabled = (key: string) => !enabledKeys || enabledKeys.has(key);

  const setSimple = (key: SimpleRiskKey, next: boolean) => onChange({ ...value, [key]: next });

  const setComposite = (key: CompositeRiskKey, patch: Record<string, unknown>) =>
    onChange({ ...value, [key]: { ...(value[key] as Record<string, unknown>), ...patch } });

  return (
    <div className="flex flex-col gap-2">
      {(SIMPLE_RISK_KEYS as readonly SimpleRiskKey[]).filter(isEnabled).map((key) => (
        <CheckRow
          key={key}
          label={t(`anamnesis.form.questions.${key}`)}
          checked={!!value[key]}
          onToggle={() => setSimple(key, !value[key])}
        />
      ))}

      {isEnabled('allergy') && (
        <CheckRow
          label={t('anamnesis.form.questions.allergy')}
          checked={!!value.allergy?.has}
          onToggle={() => setComposite('allergy', { has: !value.allergy?.has })}
        >
          <input
            type="text"
            placeholder={t('anamnesis.form.whichPlaceholder')}
            value={value.allergy?.which ?? ''}
            onChange={(e) => setComposite('allergy', { which: e.target.value })}
            className={inputClass}
          />
        </CheckRow>
      )}

      {isEnabled('prior_surgery') && (
        <CheckRow
          label={t('anamnesis.form.questions.prior_surgery')}
          checked={!!value.prior_surgery?.has}
          onToggle={() => setComposite('prior_surgery', { has: !value.prior_surgery?.has })}
        >
          <div className="flex flex-col gap-2">
            <input
              type="text"
              placeholder={t('anamnesis.form.whichPlaceholder')}
              value={value.prior_surgery?.which ?? ''}
              onChange={(e) => setComposite('prior_surgery', { which: e.target.value })}
              className={inputClass}
            />
            <input
              type="text"
              placeholder={t('anamnesis.form.whenPlaceholder')}
              value={value.prior_surgery?.when ?? ''}
              onChange={(e) => setComposite('prior_surgery', { when: e.target.value })}
              className={inputClass}
            />
          </div>
        </CheckRow>
      )}

      {isEnabled('on_medication') && (
        <CheckRow
          label={t('anamnesis.form.questions.on_medication')}
          checked={!!value.on_medication?.has}
          onToggle={() => setComposite('on_medication', { has: !value.on_medication?.has })}
        >
          <input
            type="text"
            placeholder={t('anamnesis.form.whichPlaceholder')}
            value={value.on_medication?.which ?? ''}
            onChange={(e) => setComposite('on_medication', { which: e.target.value })}
            className={inputClass}
          />
        </CheckRow>
      )}
    </div>
  );
};

export default AnamnesisRiskFields;
