import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CheckCircle2, Clock, HelpCircle } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import GradientButton from '@/components/harmonize/GradientButton';

// Bloco "já paguei e não liberou", montado nas duas telas de paywall
// (/assinar e /regularizar). Existe porque a ativação depende do postback
// PURCHASE_APPROVED da Hotmart casar o comprador com um profiles PELO
// E-MAIL, e esse casamento falha em casos reais e frequentes: pagou com um
// e-mail e se cadastrou com outro, pagou antes de ter conta, postback
// perdido. Sem este caminho, o cliente que já pagou só tinha o mailto de
// suporte — e churnava antes de alguém responder.
//
// A REGRA DE SEGURANÇA, que o componente inteiro existe para respeitar:
// digitar um e-mail NUNCA libera acesso. Quem decide é
// request_hotmart_purchase_recovery no banco (ver
// 20260917153000_add_hotmart_pending_purchases.sql), e ela só libera quando o
// e-mail informado é o e-mail VERIFICADO da própria conta — posse provada
// pelo Supabase Auth, não auto-declarada. Todo o resto vira solicitação para
// o admin conferir contra o painel da Hotmart.
//
// Por isso a UI não diferencia "não achei compra com esse e-mail" de "achei,
// mas não é sua": a RPC devolve 'under_review' nos dois casos de propósito,
// e mostrar mensagens diferentes aqui recriaria no cliente o oráculo de
// enumeração que a função evita no servidor.
type Outcome = 'activated' | 'under_review';

const RecuperarCompraHotmart: React.FC = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  // Pré-preenchido com o e-mail da conta: é o único valor que pode liberar
  // acesso na hora, então é também o palpite mais útil — quem pagou com outro
  // e-mail troca, e cai no caminho de revisão.
  const [email, setEmail] = useState(user?.email ?? '');
  const [submitting, setSubmitting] = useState(false);
  const [outcome, setOutcome] = useState<Outcome | null>(null);

  // Sem sessão não há a quem liberar nem a quem atribuir a solicitação — a
  // RPC rejeitaria de qualquer forma, então nem oferece o caminho.
  if (!user) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    const trimmed = email.trim();
    if (!trimmed.includes('@')) {
      toast.error(t('account.recoverPurchase.invalidEmail'));
      return;
    }
    setSubmitting(true);
    const { data, error } = await supabase.rpc('request_hotmart_purchase_recovery', {
      p_purchase_email: trimmed,
    });
    setSubmitting(false);
    if (error) {
      toast.error(t('account.recoverPurchase.error'));
      return;
    }
    setOutcome(data === 'activated' ? 'activated' : 'under_review');
  };

  if (outcome === 'activated') {
    return (
      <div className="mt-6 rounded-r p-4" style={{ backgroundColor: 'rgba(45,184,122,0.08)' }}>
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle2 size={18} style={{ color: '#2DB87A' }} />
          <p className="text-[14px] font-bold text-h-text">{t('account.recoverPurchase.activatedTitle')}</p>
        </div>
        <p className="text-[13px] text-h-text-2 mb-3 leading-relaxed">
          {t('account.recoverPurchase.activatedMessage')}
        </p>
        {/* Navegação com recarga completa de propósito: o AuthContext carrega
            subscription_status uma única vez por sessão de página, então um
            navigate() do react-router levaria o ProtectedRoute a decidir com
            o perfil antigo (ainda sem assinatura) e devolver a pessoa para
            este mesmo paywall. */}
        <GradientButton onClick={() => window.location.assign('/inicio')}>
          {t('account.recoverPurchase.enterApp')}
        </GradientButton>
      </div>
    );
  }

  if (outcome === 'under_review') {
    return (
      <div className="mt-6 rounded-r p-4" style={{ backgroundColor: 'rgba(217,119,6,0.08)' }}>
        <div className="flex items-center gap-2 mb-2">
          <Clock size={18} style={{ color: '#D97706' }} />
          <p className="text-[14px] font-bold text-h-text">{t('account.recoverPurchase.reviewTitle')}</p>
        </div>
        <p className="text-[13px] text-h-text-2 leading-relaxed">
          {t('account.recoverPurchase.reviewMessage')}
        </p>
      </div>
    );
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="w-full mt-6 flex items-center justify-center gap-2 min-h-[44px] text-[13px] font-semibold text-h-text-2"
      >
        <HelpCircle size={15} />
        {t('account.recoverPurchase.trigger')}
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="mt-6 rounded-r p-4 bg-h-white shadow-h-sm">
      <p className="text-[14px] font-bold text-h-text mb-1">{t('account.recoverPurchase.formTitle')}</p>
      <p className="text-[12px] text-h-text-3 mb-3 leading-relaxed">
        {t('account.recoverPurchase.formDescription')}
      </p>
      <label htmlFor="recover-purchase-email" className="block text-[12px] font-semibold text-h-text-2 mb-1">
        {t('account.recoverPurchase.emailLabel')}
      </label>
      <input
        id="recover-purchase-email"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="w-full h-[44px] rounded-r-sm px-3 text-[14px] text-h-text bg-h-surface outline-none mb-3"
        placeholder={t('account.recoverPurchase.emailPlaceholder')}
      />
      <GradientButton type="submit" disabled={submitting}>
        {submitting ? t('common.loading') : t('account.recoverPurchase.submit')}
      </GradientButton>
    </form>
  );
};

export default RecuperarCompraHotmart;
