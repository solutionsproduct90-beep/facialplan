import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import SessionRealResultsGallery from './SessionRealResultsGallery';
import i18n from '@/i18n';

const fromMock = vi.fn();
const insertSpy = vi.fn();
const deleteSpy = vi.fn();
const uploadSpy = vi.fn();
const removeSpy = vi.fn();
const rpcSpy = vi.fn();

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: {
      from: () => ({
        // API em lote (createSignedUrls) usada pela galeria desde a correção
        // do N+1 — uma chamada só recebendo todos os paths, devolvendo um
        // array na mesma ordem.
        createSignedUrls: async (paths: string[]) => ({
          data: paths.map((path) => ({ path, signedUrl: `https://signed.example/${path}`, signedURL: null, error: null })),
          error: null,
        }),
        upload: (...args: unknown[]) => {
          uploadSpy(...args);
          return Promise.resolve({ error: null });
        },
        remove: (...args: unknown[]) => {
          removeSpy(...args);
          return Promise.resolve({ error: null });
        },
      }),
    },
    rpc: (...args: unknown[]) => {
      rpcSpy(...args);
      return Promise.resolve({ error: null });
    },
  },
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/** Builder pra `session_real_results`: `.select().eq().order()` (lista),
 * `.insert()` e `.delete().eq()`. */
function createResultsBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    insert: (payload: Record<string, unknown>) => {
      insertSpy(payload);
      return Promise.resolve({ error: null });
    },
    delete: () => ({
      eq: (...args: unknown[]) => {
        deleteSpy(...args);
        return Promise.resolve({ error: null });
      },
    }),
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

/** Builder pra `session_simulation_accuracy_ratings`: `.select().eq().maybeSingle()`. */
function createRatingBuilder(row: unknown | null) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    maybeSingle: () => Promise.resolve({ data: row, error: null }),
  };
  return builder;
}

const renderGallery = (sessionId = 'ses-1', professionalId = 'pro-1', hasSimulation = false) =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <SessionRealResultsGallery sessionId={sessionId} professionalId={professionalId} hasSimulation={hasSimulation} />
    </QueryClientProvider>,
  );

describe('SessionRealResultsGallery', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    fromMock.mockReset();
    insertSpy.mockReset();
    deleteSpy.mockReset();
    uploadSpy.mockReset();
    removeSpy.mockReset();
    rpcSpy.mockReset();
  });

  it('shows the empty state when the session has no real result photos yet', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') return createResultsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery();
    expect(await screen.findByText('Nenhuma foto do resultado real ainda.')).toBeInTheDocument();
  });

  it('lists existing real result photos as signed thumbnails', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') {
        return createResultsBuilder([
          { id: 'rr-1', photo_url: 'pro-1/ses-1_real_result_1.jpg', uploaded_at: '2026-09-01T10:00:00.000Z' },
          { id: 'rr-2', photo_url: 'pro-1/ses-1_real_result_2.jpg', uploaded_at: '2026-09-05T10:00:00.000Z' },
        ]);
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery();
    const images = await screen.findAllByRole('img');
    expect(images).toHaveLength(2);
    expect(images[0]).toHaveAttribute('src', 'https://signed.example/pro-1/ses-1_real_result_1.jpg');
    await waitFor(() => expect(rpcSpy).toHaveBeenCalledWith('log_data_access', expect.objectContaining({ p_action: 'view_patient_photo' })));
  });

  it('uploads a new real result photo and links it to the session', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') return createResultsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery();
    await screen.findByText('Nenhuma foto do resultado real ainda.');

    const file = new File(['fake-bytes'], 'resultado.jpg', { type: 'image/jpeg' });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, { target: { files: [file] } });

    await waitFor(() => expect(uploadSpy).toHaveBeenCalledTimes(1));
    expect(uploadSpy.mock.calls[0][0]).toMatch(/^pro-1\/ses-1_real_result_\d+\.jpg$/);

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({
      professional_id: 'pro-1',
      session_id: 'ses-1',
    });
  });

  it('rejects a file over the 10MB limit without uploading', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') return createResultsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery();
    await screen.findByText('Nenhuma foto do resultado real ainda.');

    const bigFile = new File([new Uint8Array(11 * 1024 * 1024)], 'grande.jpg', { type: 'image/jpeg' });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, { target: { files: [bigFile] } });

    await waitFor(() => expect(uploadSpy).not.toHaveBeenCalled());
    expect(insertSpy).not.toHaveBeenCalled();
  });

  it('deletes a real result photo', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') {
        return createResultsBuilder([
          { id: 'rr-1', photo_url: 'pro-1/ses-1_real_result_1.jpg', uploaded_at: '2026-09-01T10:00:00.000Z' },
        ]);
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery();
    const deleteButton = await screen.findByLabelText('Remover foto');
    fireEvent.click(deleteButton);

    await waitFor(() => expect(deleteSpy).toHaveBeenCalledWith('id', 'rr-1'));
    await waitFor(() => expect(removeSpy).toHaveBeenCalledWith(['pro-1/ses-1_real_result_1.jpg']));
  });

  it('does not show the simulation accuracy rating when there is no simulation, even with real result photos', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') {
        return createResultsBuilder([
          { id: 'rr-1', photo_url: 'pro-1/ses-1_real_result_1.jpg', uploaded_at: '2026-09-01T10:00:00.000Z' },
        ]);
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery('ses-1', 'pro-1', false);
    await screen.findAllByRole('img');

    expect(screen.queryByText('Índice de Precisão da Simulação')).not.toBeInTheDocument();
  });

  it('does not show the simulation accuracy rating when there is a simulation but no real result photo yet', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') return createResultsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery('ses-1', 'pro-1', true);
    await screen.findByText('Nenhuma foto do resultado real ainda.');

    expect(screen.queryByText('Índice de Precisão da Simulação')).not.toBeInTheDocument();
  });

  it('shows the simulation accuracy rating once both the simulation and a real result photo exist', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_real_results') {
        return createResultsBuilder([
          { id: 'rr-1', photo_url: 'pro-1/ses-1_real_result_1.jpg', uploaded_at: '2026-09-01T10:00:00.000Z' },
        ]);
      }
      if (table === 'session_simulation_accuracy_ratings') return createRatingBuilder(null);
      throw new Error(`unexpected table ${table}`);
    });

    renderGallery('ses-1', 'pro-1', true);

    expect(await screen.findByText('Índice de Precisão da Simulação')).toBeInTheDocument();
    expect(screen.getByTestId('simulation-accuracy-rating-3')).toBeInTheDocument();
  });
});
