import React from "react";
import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import GradientButton from "./GradientButton";

describe("GradientButton", () => {
  it("renders its children", () => {
    render(<GradientButton>Continuar</GradientButton>);
    expect(screen.getByRole("button", { name: "Continuar" })).toBeInTheDocument();
  });

  it("fires onClick when clicked", () => {
    const onClick = vi.fn();
    render(<GradientButton onClick={onClick}>Enviar</GradientButton>);

    fireEvent.click(screen.getByRole("button", { name: "Enviar" }));

    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("is disabled when the disabled prop is set and does not fire onClick", () => {
    const onClick = vi.fn();
    render(
      <GradientButton disabled onClick={onClick}>
        Enviar
      </GradientButton>
    );

    const button = screen.getByRole("button", { name: "Enviar" });
    expect(button).toBeDisabled();

    fireEvent.click(button);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("merges a custom className with its default classes", () => {
    render(<GradientButton className="my-extra-class">Ok</GradientButton>);
    const button = screen.getByRole("button", { name: "Ok" });
    expect(button).toHaveClass("my-extra-class");
    expect(button).toHaveClass("bg-gradient-brand");
  });

  it("forwards a ref to the underlying button element", () => {
    const ref = React.createRef<HTMLButtonElement>();
    render(<GradientButton ref={ref}>Ref test</GradientButton>);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
    expect(ref.current?.textContent).toBe("Ref test");
  });

  it("passes through arbitrary button props such as type", () => {
    render(<GradientButton type="submit">Submit</GradientButton>);
    expect(screen.getByRole("button", { name: "Submit" })).toHaveAttribute("type", "submit");
  });
});
