import React, { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { CalendarDays, CalendarPlus, CheckCircle2, XCircle, Trash2, RefreshCw, User, Download, Clock, Send, X as XIcon } from 'lucide-react';
import { toast } from 'sonner';
import HCard from '@/components/harmonize/HCard';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { normalizeAppointments, groupAppointmentsByDay, dayHeadingKind, type AppointmentStatus } from '@/lib/agenda';
import { downloadAppointmentIcs } from '@/lib/icalExport';
import { normalizeWaitlistEntries, findWaitlistCandidatesForSlot, buildWaitlistBackToWaitingPayload, type WaitlistEntry } from '@/lib/waitlist';
import { buildWaitlistOfferMessage } from '@/lib/whatsappTemplates';
import { buildReactivationWhatsAppLink } from '@/lib/patientReactivation';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

type PatientOption = { id: string; name: string };

/**
 * Aba "Agenda" do /painel — mini sistema de agendamento (não um Calendly/
 * Google Calendar): lista cronológica de compromissos agrupados por dia,
 * com CRUD simples. Sem grade de calendário mensal, sincronização externa
 * ou lembrete automático nesta V1 (ver comentário na migration
 * 20260910190000_add_appointments.sql) — próximos passos naturais, não
 * omissão por esquecimento.
 */
const AgendaTab: React.FC = () => {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const queryClient = useQueryClient();
  const locale = dateFnsLocale[i18n.language] ?? ptBR;

  const [sheetOpen, setSheetOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [draftDate, setDraftDate] = useState('');
  const [draftTime, setDraftTime] = useState('');
  const [draftPatientId, setDraftPatientId] = useState('');
  const [draftNote, setDraftNote] = useState('');
  const [draftDuration, setDraftDuration] = useState('');

  // Fila de espera (appointment_waitlist) — cadastro de "paciente + período
  // desejado" e a sugestão de a quem oferecer um horário liberado por
  // cancelamento (ver handleSetStatus abaixo). Estado próprio, separado do
  // formulário de compromisso acima, cada sheet com seu próprio draft.
  const [waitlistSheetOpen, setWaitlistSheetOpen] = useState(false);
  const [waitlistSaving, setWaitlistSaving] = useState(false);
  const [waitlistDraftPatientId, setWaitlistDraftPatientId] = useState('');
  const [waitlistDraftStart, setWaitlistDraftStart] = useState('');
  const [waitlistDraftEnd, setWaitlistDraftEnd] = useState('');

  // Sheet de candidatos aberta a partir do toast "Ver fila" mostrado logo
  // depois de cancelar um compromisso — guarda o próprio compromisso
  // cancelado (pro texto/mensagem de oferta) e a lista já filtrada/ordenada
  // de candidatos naquele momento (não recalculada ao vivo: se a fila mudar
  // enquanto a sheet está aberta, o profissional fecha e reabre pela lista
  // de compromissos pra ver o estado atual — mantém o fluxo simples).
  const [candidatesSheetOpen, setCandidatesSheetOpen] = useState(false);
  const [candidatesSlot, setCandidatesSlot] = useState<{ scheduledAt: string; candidates: WaitlistEntry[] } | null>(null);
  const [offeringId, setOfferingId] = useState<string | null>(null);

  const {
    data: appointmentsRaw,
    isLoading: loadingAppointments,
    isError: appointmentsError,
    refetch: refetchAppointments,
  } = useQuery({
    queryKey: ['agenda-appointments', user?.id],
    queryFn: () =>
      // Paginado (src/lib/fetchAllRows.ts): a agenda não tem corte por data
      // (mostra passado e futuro), então é a leitura da aba que cresce sem
      // limite — e o teto de linhas por resposta do PostgREST (Max Rows, 1000
      // por padrão) é aplicado em silêncio, com `error: null`.
      fetchAllRows((from, to) =>
        supabase
          .from('appointments')
          .select('id, patient_id, note, scheduled_at, duration_minutes, status, patient:patients(name)')
          .eq('professional_id', user!.id)
          .order('scheduled_at', { ascending: true })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const {
    data: patients,
    isLoading: loadingPatients,
    isError: patientsError,
    refetch: refetchPatients,
  } = useQuery({
    queryKey: ['agenda-patients', user?.id],
    queryFn: (): Promise<PatientOption[]> =>
      // Paginado: um paciente fora do teto não apareceria no seletor de
      // agendamento nem na fila de espera.
      fetchAllRows<PatientOption>((from, to) =>
        supabase
          .from('patients')
          .select('id, name')
          .eq('professional_id', user!.id)
          .eq('is_deleted', false)
          .order('name', { ascending: true })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const {
    data: waitlistRaw,
    isLoading: loadingWaitlist,
    isError: waitlistError,
    refetch: refetchWaitlist,
  } = useQuery({
    queryKey: ['agenda-waitlist', user?.id],
    queryFn: () =>
      // Idem: a fila de espera guarda histórico (entradas atendidas/expiradas
      // continuam na tabela), então também cresce sem limite.
      fetchAllRows((from, to) =>
        supabase
          .from('appointment_waitlist')
          .select('id, patient_id, desired_start_date, desired_end_date, status, created_at, patient:patients(name, phone)')
          .eq('professional_id', user!.id)
          .order('created_at', { ascending: true })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const isLoading = loadingAppointments || loadingPatients || loadingWaitlist;
  const hasError = appointmentsError || patientsError || waitlistError;

  const appointments = useMemo(() => normalizeAppointments(appointmentsRaw ?? []), [appointmentsRaw]);
  const dayGroups = useMemo(() => groupAppointmentsByDay(appointments), [appointments]);
  const waitlist = useMemo(() => normalizeWaitlistEntries(waitlistRaw ?? []), [waitlistRaw]);
  const waitingEntries = useMemo(() => waitlist.filter((entry) => entry.status === 'waiting'), [waitlist]);

  const handleRetry = () => {
    refetchAppointments();
    refetchPatients();
    refetchWaitlist();
  };

  const resetDraft = () => {
    setDraftDate('');
    setDraftTime('');
    setDraftPatientId('');
    setDraftNote('');
    setDraftDuration('');
  };

  const openNew = () => {
    setEditingId(null);
    resetDraft();
    const now = new Date();
    setDraftDate(format(now, 'yyyy-MM-dd'));
    setDraftTime(format(now, 'HH:mm'));
    setSheetOpen(true);
  };

  const openEdit = (id: string) => {
    const appt = appointments.find((a) => a.id === id);
    if (!appt) return;
    const scheduled = new Date(appt.scheduledAt);
    setEditingId(id);
    setDraftDate(format(scheduled, 'yyyy-MM-dd'));
    setDraftTime(format(scheduled, 'HH:mm'));
    setDraftPatientId(appt.patientId ?? '');
    setDraftNote(appt.note ?? '');
    setDraftDuration(appt.durationMinutes != null ? String(appt.durationMinutes) : '');
    setSheetOpen(true);
  };

  const invalidateAgenda = () => queryClient.invalidateQueries({ queryKey: ['agenda-appointments', user?.id] });
  const invalidateWaitlist = () => queryClient.invalidateQueries({ queryKey: ['agenda-waitlist', user?.id] });

  const resetWaitlistDraft = () => {
    setWaitlistDraftPatientId('');
    setWaitlistDraftStart('');
    setWaitlistDraftEnd('');
  };

  const openAddToWaitlist = () => {
    resetWaitlistDraft();
    const today = format(new Date(), 'yyyy-MM-dd');
    setWaitlistDraftStart(today);
    setWaitlistDraftEnd(today);
    setWaitlistSheetOpen(true);
  };

  const handleSaveWaitlistEntry = async () => {
    if (!user) return;
    if (!waitlistDraftPatientId) {
      toast.error(t('agenda.waitlist.form.errors.invalidPatient'));
      return;
    }
    if (!waitlistDraftStart || !waitlistDraftEnd || waitlistDraftEnd < waitlistDraftStart) {
      toast.error(t('agenda.waitlist.form.errors.invalidPeriod'));
      return;
    }
    setWaitlistSaving(true);
    try {
      const { error } = await supabase.from('appointment_waitlist').insert({
        professional_id: user.id,
        patient_id: waitlistDraftPatientId,
        desired_start_date: waitlistDraftStart,
        desired_end_date: waitlistDraftEnd,
      });
      if (error) throw error;
      await invalidateWaitlist();
      setWaitlistSheetOpen(false);
      toast.success(t('agenda.waitlist.toastAdded'));
    } catch (err: any) {
      toast.error(err.message || t('agenda.waitlist.toastError'));
    } finally {
      setWaitlistSaving(false);
    }
  };

  const handleRemoveWaitlistEntry = async (id: string) => {
    const { error } = await supabase.from('appointment_waitlist').delete().eq('id', id);
    if (error) {
      toast.error(error.message || t('agenda.waitlist.toastError'));
      return;
    }
    await invalidateWaitlist();
    toast.success(t('agenda.waitlist.toastRemoved'));
  };

  /**
   * Botão "Oferecer este horário" da sheet de candidatos — abre o WhatsApp
   * do profissional com a mensagem de oferta já pronta pro paciente
   * candidato (mesmo link `wa.me` manual usado no resto do app, ver
   * `buildReactivationWhatsAppLink` em patientReactivation.ts) e SÓ DEPOIS
   * de abrir a janela marca a entrada como `status: 'offered'`, pra o
   * profissional saber quem já foi contatado se voltar na fila mais tarde.
   * Nunca dispara sozinho: só roda quando o profissional clica no botão, e
   * sempre abre o link pronto pra ele revisar/enviar — nunca envio
   * silencioso em background.
   *
   * Achado do QA Contínuo (ciclo 24): `window.open` pode ser bloqueado pelo
   * navegador e devolve `null` — sem essa checagem a entrada virava
   * `'offered'` mesmo sem o profissional nunca ter visto a mensagem, e uma
   * entrada `'offered'` não é mais sugerida em nenhum horário futuro
   * (`findWaitlistCandidatesForSlot` filtra só `'waiting'`). Se o popup for
   * bloqueado, avisa e NÃO marca `'offered'` — o candidato continua na
   * sheet pro profissional tentar de novo. Como segunda camada de defesa (o
   * profissional pode fechar a aba sem enviar mesmo com o popup abrindo
   * normalmente), o botão "Voltar pra fila" abaixo dá uma saída pra
   * qualquer entrada `'offered'` por engano, sem precisar recriar o
   * registro (mesmo padrão do "Desvincular" do Combo Plan, ciclo 23).
   */
  const handleOfferSlot = async (entry: WaitlistEntry, scheduledAt: string) => {
    setOfferingId(entry.id);
    try {
      const dateTimeLabel = format(new Date(scheduledAt), 'PPPp', { locale });
      const message = buildWaitlistOfferMessage(entry.patientName, dateTimeLabel, i18n.language);
      const waLink = buildReactivationWhatsAppLink(entry.patientPhone, message);
      const popup = window.open(waLink, '_blank', 'noopener,noreferrer');
      if (!popup) {
        toast.error(t('agenda.waitlist.toastPopupBlocked'));
        return;
      }
      // .eq('status', 'waiting') + checar se alguma linha voltou: sem isso,
      // duas sheets de candidatos abertas com o mesmo snapshot (dois
      // cancelamentos em sequência, antes de a fila recarregar) permitiam
      // ofertar o mesmo candidato duas vezes — a entrada já 'offered' virava
      // 'offered' de novo silenciosamente, sem indicar que a oferta anterior
      // (pra outro horário) é que valia. Achado do QA Contínuo.
      const { data: updated, error } = await supabase
        .from('appointment_waitlist')
        .update({ status: 'offered' })
        .eq('id', entry.id)
        .eq('status', 'waiting')
        .select('id');
      if (error) throw error;
      if (!updated || updated.length === 0) {
        toast.error(t('agenda.waitlist.toastAlreadyOffered'));
        await invalidateWaitlist();
        setCandidatesSlot((prev) =>
          prev ? { ...prev, candidates: prev.candidates.filter((c) => c.id !== entry.id) } : prev,
        );
        return;
      }
      await invalidateWaitlist();
      setCandidatesSlot((prev) =>
        prev ? { ...prev, candidates: prev.candidates.filter((c) => c.id !== entry.id) } : prev,
      );
      toast.success(t('agenda.waitlist.toastOffered'));
    } catch (err: any) {
      toast.error(err.message || t('agenda.waitlist.toastError'));
    } finally {
      setOfferingId(null);
    }
  };

  /**
   * "Voltar pra fila" — segunda camada de defesa pra uma entrada `'offered'`
   * que na prática nunca foi contatada (aba do WhatsApp fechada sem enviar,
   * número errado, etc.). Devolve pra `'waiting'` preservando `createdAt`
   * (posição de chegada), em vez de o profissional precisar remover e o
   * paciente se recadastrar do zero. Ver `handleOfferSlot` acima.
   */
  const handleBackToWaitlistEntry = async (id: string) => {
    const { error } = await supabase
      .from('appointment_waitlist')
      .update(buildWaitlistBackToWaitingPayload())
      .eq('id', id);
    if (error) {
      toast.error(error.message || t('agenda.waitlist.toastError'));
      return;
    }
    await invalidateWaitlist();
    toast.success(t('agenda.waitlist.toastBackToWaiting'));
  };

  const handleSave = async () => {
    if (!user) return;
    if (!draftDate || !draftTime) {
      toast.error(t('agenda.form.invalidDate'));
      return;
    }
    const scheduledAt = new Date(`${draftDate}T${draftTime}`);
    if (Number.isNaN(scheduledAt.getTime())) {
      toast.error(t('agenda.form.invalidDate'));
      return;
    }
    const durationMinutes = draftDuration.trim() ? Number(draftDuration) : null;

    setSaving(true);
    try {
      const payload = {
        patient_id: draftPatientId || null,
        note: draftNote.trim() || null,
        scheduled_at: scheduledAt.toISOString(),
        duration_minutes: Number.isFinite(durationMinutes) ? durationMinutes : null,
      };
      if (editingId) {
        const { error } = await supabase.from('appointments').update(payload).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('appointments')
          .insert({ ...payload, professional_id: user.id });
        if (error) throw error;
      }
      await invalidateAgenda();
      setSheetOpen(false);
      toast.success(t('agenda.toastSaved'));
    } catch (err: any) {
      toast.error(err.message || t('agenda.toastError'));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('appointments').delete().eq('id', id);
    if (error) {
      toast.error(error.message || t('agenda.toastError'));
      return;
    }
    await invalidateAgenda();
    setSheetOpen(false);
    toast.success(t('agenda.toastRemoved'));
  };

  /**
   * "Integração com Google Calendar/iCal" do backlog de features: em vez de
   * OAuth/API real do Google Calendar (exigiria credenciais que este
   * projeto não tem), geramos e baixamos um .ics padrão (RFC 5545) — já
   * importável manualmente no Google Calendar, Outlook e Apple Calendar.
   * Ver comentário de escopo completo em src/lib/icalExport.ts.
   */
  const handleAddToCalendar = (appt: (typeof appointments)[number]) => {
    downloadAppointmentIcs(
      {
        id: appt.id,
        patientName: appt.patientName,
        note: appt.note,
        scheduledAt: appt.scheduledAt,
        durationMinutes: appt.durationMinutes,
      },
      t,
    );
    toast.success(t('agenda.ical.toastDownloaded'));
  };

  const handleSetStatus = async (id: string, status: AppointmentStatus) => {
    const appt = appointments.find((a) => a.id === id);
    const { error } = await supabase.from('appointments').update({ status }).eq('id', id);
    if (error) {
      toast.error(error.message || t('agenda.toastError'));
      return;
    }
    await invalidateAgenda();
    toast.success(t('agenda.toastStatusUpdated'));

    // Cancelamento libera um horário — sugere, por um toast discreto com
    // ação (nunca envio automático), a quem da fila de espera oferecer esse
    // horário, em ordem de chegada na fila. Só dispara pra 'cancelado': um
    // compromisso marcado 'concluido' não libera horário nenhum.
    if (status === 'cancelado' && appt) {
      const candidates = findWaitlistCandidatesForSlot(waitingEntries, appt.scheduledAt);
      if (candidates.length > 0) {
        toast(t('agenda.waitlist.suggestionToast', { count: candidates.length }), {
          action: {
            label: t('agenda.waitlist.viewQueue'),
            onClick: () => {
              setCandidatesSlot({ scheduledAt: appt.scheduledAt, candidates });
              setCandidatesSheetOpen(true);
            },
          },
        });
      }
    }
  };

  const dayHeading = (dateKey: string) => {
    const kind = dayHeadingKind(dateKey);
    if (kind === 'today') return t('agenda.day.today');
    if (kind === 'tomorrow') return t('agenda.day.tomorrow');
    const [y, m, d] = dateKey.split('-').map(Number);
    return format(new Date(y, m - 1, d), 'PPPP', { locale });
  };

  if (isLoading) {
    return (
      <div className="flex flex-col gap-3">
        <SkeletonCard lines={2} />
        <SkeletonCard lines={2} />
      </div>
    );
  }

  if (hasError) {
    return (
      <HCard className="flex flex-col items-center gap-2 text-center py-6">
        <p className="text-[13px] text-h-text-2">{t('agenda.error.load')}</p>
        <button
          onClick={handleRetry}
          className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
          style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
        >
          <RefreshCw size={14} />
          {t('agenda.error.retry')}
        </button>
      </HCard>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <HCard>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarDays size={16} style={{ color: '#7C5AC2' }} />
            <p className="text-[13px] font-semibold text-h-text">{t('agenda.title')}</p>
          </div>
          <button
            onClick={openNew}
            data-testid="agenda-add-new"
            className="flex items-center gap-1.5 press-scale"
            style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, fontSize: 12, fontWeight: 600 }}
          >
            <CalendarPlus size={14} />
            {t('agenda.addNew')}
          </button>
        </div>
      </HCard>

      {dayGroups.length === 0 ? (
        <HCard className="flex flex-col items-center gap-3 text-center py-6">
          <p className="text-[13px] text-h-text-2">{t('agenda.empty')}</p>
          <button
            onClick={openNew}
            style={{ color: '#BF5F82', background: 'none', border: 'none', fontSize: 13, fontWeight: 700, cursor: 'pointer', minHeight: 44 }}
          >
            {t('agenda.emptyCta')}
          </button>
        </HCard>
      ) : (
        dayGroups.map((group) => (
          <div key={group.dateKey} className="flex flex-col gap-2">
            <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide px-1">
              {dayHeading(group.dateKey)}
            </p>
            <HCard className="!p-0 overflow-hidden">
              <div className="flex flex-col divide-y divide-black/5">
                {group.items.map((appt) => {
                  const isDone = appt.status !== 'agendado';
                  return (
                    <div key={appt.id} className="flex items-center gap-3 p-3">
                      <button
                        onClick={() => openEdit(appt.id)}
                        data-testid={`agenda-item-${appt.id}`}
                        className="flex-1 min-w-0 flex items-center gap-3 text-left"
                      >
                        <div
                          className="flex flex-col items-center justify-center flex-shrink-0 w-[44px]"
                          style={{ opacity: isDone ? 0.5 : 1 }}
                        >
                          <span className="text-[13px] font-extrabold text-h-text">
                            {format(new Date(appt.scheduledAt), 'HH:mm')}
                          </span>
                        </div>
                        <div className="min-w-0" style={{ opacity: isDone ? 0.5 : 1 }}>
                          <p className="text-[13px] font-semibold text-h-text truncate flex items-center gap-1">
                            <User size={11} className="flex-shrink-0 text-h-text-3" />
                            {appt.patientName ?? t('agenda.noPatient')}
                          </p>
                          {appt.note && (
                            <p className="text-[11px] text-h-text-3 truncate">{appt.note}</p>
                          )}
                          {isDone && (
                            <p className="text-[10px] font-bold uppercase tracking-wide" style={{ color: appt.status === 'concluido' ? '#2DB87A' : '#AAA8A5' }}>
                              {t(`agenda.status.${appt.status}`)}
                            </p>
                          )}
                        </div>
                      </button>
                      {!isDone && (
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button
                            onClick={() => handleAddToCalendar(appt)}
                            aria-label={t('agenda.ical.addToCalendar')}
                            title={t('agenda.ical.addToCalendar')}
                            data-testid={`agenda-ical-${appt.id}`}
                            className="press-scale"
                            style={{ color: '#7C5AC2', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, minWidth: 32 }}
                          >
                            <Download size={18} />
                          </button>
                          <button
                            onClick={() => handleSetStatus(appt.id, 'concluido')}
                            aria-label={t('agenda.actions.complete')}
                            className="press-scale"
                            style={{ color: '#2DB87A', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, minWidth: 32 }}
                          >
                            <CheckCircle2 size={20} />
                          </button>
                          <button
                            onClick={() => handleSetStatus(appt.id, 'cancelado')}
                            aria-label={t('agenda.actions.cancel')}
                            className="press-scale"
                            style={{ color: '#AAA8A5', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, minWidth: 32 }}
                          >
                            <XCircle size={20} />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </HCard>
          </div>
        ))
      )}

      <HCard>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Clock size={16} style={{ color: '#7C5AC2' }} />
            <p className="text-[13px] font-semibold text-h-text">{t('agenda.waitlist.sectionTitle')}</p>
          </div>
          <button
            onClick={openAddToWaitlist}
            data-testid="waitlist-add-new"
            className="flex items-center gap-1.5 press-scale"
            style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, fontSize: 12, fontWeight: 600 }}
          >
            <CalendarPlus size={14} />
            {t('agenda.waitlist.addNew')}
          </button>
        </div>
        {waitlist.length === 0 ? (
          <p className="text-[12px] text-h-text-3 py-2">{t('agenda.waitlist.empty')}</p>
        ) : (
          <div className="flex flex-col divide-y divide-black/5">
            {waitlist.map((entry) => (
              <div key={entry.id} className="flex items-center gap-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-semibold text-h-text truncate flex items-center gap-1">
                    <User size={11} className="flex-shrink-0 text-h-text-3" />
                    {entry.patientName ?? t('agenda.noPatient')}
                  </p>
                  <p className="text-[11px] text-h-text-3">
                    {t('agenda.waitlist.period', { start: entry.desiredStartDate, end: entry.desiredEndDate })}
                  </p>
                  {entry.status !== 'waiting' && (
                    <p className="text-[10px] font-bold uppercase tracking-wide" style={{ color: '#AAA8A5' }}>
                      {t(`agenda.waitlist.status.${entry.status}`)}
                    </p>
                  )}
                </div>
                {entry.status === 'offered' && (
                  <button
                    onClick={() => handleBackToWaitlistEntry(entry.id)}
                    aria-label={t('agenda.waitlist.backToWaiting')}
                    title={t('agenda.waitlist.backToWaiting')}
                    data-testid={`waitlist-back-to-waiting-${entry.id}`}
                    className="press-scale flex-shrink-0 text-[11px] font-semibold"
                    style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
                  >
                    {t('agenda.waitlist.backToWaiting')}
                  </button>
                )}
                <button
                  onClick={() => handleRemoveWaitlistEntry(entry.id)}
                  aria-label={t('agenda.waitlist.remove')}
                  title={t('agenda.waitlist.remove')}
                  data-testid={`waitlist-remove-${entry.id}`}
                  className="press-scale flex-shrink-0"
                  style={{ color: '#AAA8A5', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, minWidth: 32 }}
                >
                  <XIcon size={18} />
                </button>
              </div>
            ))}
          </div>
        )}
      </HCard>

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title={editingId ? t('agenda.form.editTitle') : t('agenda.form.newTitle')}
      >
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.form.dateLabel')}</label>
              <input
                type="date"
                value={draftDate}
                onChange={(e) => setDraftDate(e.target.value)}
                aria-label={t('agenda.form.dateLabel')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.form.timeLabel')}</label>
              <input
                type="time"
                value={draftTime}
                onChange={(e) => setDraftTime(e.target.value)}
                aria-label={t('agenda.form.timeLabel')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.form.patientLabel')}</label>
            <select
              value={draftPatientId}
              onChange={(e) => setDraftPatientId(e.target.value)}
              aria-label={t('agenda.form.patientLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              <option value="">{t('agenda.form.patientPlaceholder')}</option>
              {(patients ?? []).map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.form.noteLabel')}</label>
            <input
              value={draftNote}
              onChange={(e) => setDraftNote(e.target.value)}
              placeholder={t('agenda.form.notePlaceholder')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.form.durationLabel')}</label>
            <input
              type="number"
              min={1}
              step={1}
              inputMode="numeric"
              value={draftDuration}
              onChange={(e) => setDraftDuration(e.target.value)}
              placeholder="30"
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
            />
          </div>

          <div className="flex gap-3">
            {editingId && (
              <button
                onClick={() => handleDelete(editingId)}
                className="flex-1 flex items-center justify-center gap-2 rounded-full py-3 min-h-[44px]"
                style={{ background: 'rgba(224,80,80,0.08)', color: '#E05050' }}
              >
                <Trash2 size={15} />
                <span className="text-[13px] font-bold">{t('agenda.form.remove')}</span>
              </button>
            )}
            <div className="flex-1">
              <GradientButton onClick={handleSave} disabled={saving}>
                {saving ? t('panel.saving') : t('agenda.form.save')}
              </GradientButton>
            </div>
          </div>
        </div>
      </BottomSheet>

      <BottomSheet
        open={waitlistSheetOpen}
        onClose={() => setWaitlistSheetOpen(false)}
        title={t('agenda.waitlist.form.title')}
      >
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.waitlist.form.patientLabel')}</label>
            <select
              value={waitlistDraftPatientId}
              onChange={(e) => setWaitlistDraftPatientId(e.target.value)}
              aria-label={t('agenda.waitlist.form.patientLabel')}
              className="w-full bg-h-white shadow-h-sm rounded-r-sm px-[14px] h-[48px] min-h-[44px] text-[14px] font-semibold text-h-text outline-none"
            >
              <option value="">{t('agenda.waitlist.form.patientPlaceholder')}</option>
              {(patients ?? []).map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.waitlist.form.startDateLabel')}</label>
              <input
                type="date"
                value={waitlistDraftStart}
                onChange={(e) => setWaitlistDraftStart(e.target.value)}
                aria-label={t('agenda.waitlist.form.startDateLabel')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('agenda.waitlist.form.endDateLabel')}</label>
              <input
                type="date"
                value={waitlistDraftEnd}
                onChange={(e) => setWaitlistDraftEnd(e.target.value)}
                aria-label={t('agenda.waitlist.form.endDateLabel')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              />
            </div>
          </div>

          <GradientButton onClick={handleSaveWaitlistEntry} disabled={waitlistSaving}>
            {waitlistSaving ? t('panel.saving') : t('agenda.waitlist.form.save')}
          </GradientButton>
        </div>
      </BottomSheet>

      <BottomSheet
        open={candidatesSheetOpen}
        onClose={() => setCandidatesSheetOpen(false)}
        title={t('agenda.waitlist.candidatesSheet.title')}
      >
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          {candidatesSlot && (
            <p className="text-[12px] text-h-text-2">
              {t('agenda.waitlist.candidatesSheet.subtitle', {
                dateTime: format(new Date(candidatesSlot.scheduledAt), 'PPPp', { locale }),
              })}
            </p>
          )}
          <div className="flex flex-col divide-y divide-black/5">
            {(candidatesSlot?.candidates ?? []).map((candidate, index) => (
              <div key={candidate.id} className="flex items-center gap-3 py-2.5">
                <span className="text-[12px] font-extrabold text-h-text-3 w-[20px] flex-shrink-0">{index + 1}</span>
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-semibold text-h-text truncate">
                    {candidate.patientName ?? t('agenda.noPatient')}
                  </p>
                  <p className="text-[11px] text-h-text-3">
                    {t('agenda.waitlist.period', { start: candidate.desiredStartDate, end: candidate.desiredEndDate })}
                  </p>
                </div>
                <button
                  onClick={() => candidatesSlot && handleOfferSlot(candidate, candidatesSlot.scheduledAt)}
                  disabled={offeringId === candidate.id}
                  data-testid={`waitlist-offer-${candidate.id}`}
                  className="flex items-center gap-1.5 flex-shrink-0 rounded-full press-scale"
                  style={{
                    color: '#FFFFFF',
                    background: offeringId === candidate.id ? '#D8B7C6' : '#BF5F82',
                    border: 'none',
                    cursor: offeringId === candidate.id ? 'default' : 'pointer',
                    minHeight: 36,
                    padding: '0 14px',
                    fontSize: 12,
                    fontWeight: 700,
                  }}
                >
                  <Send size={13} />
                  {t('agenda.waitlist.candidatesSheet.offerButton')}
                </button>
              </div>
            ))}
          </div>
        </div>
      </BottomSheet>
    </div>
  );
};

export default AgendaTab;
