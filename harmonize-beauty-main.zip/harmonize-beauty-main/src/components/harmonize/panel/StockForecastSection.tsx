import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { TrendingUp, CalendarClock } from 'lucide-react';
import HCard from '@/components/harmonize/HCard';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { normalizeTreatmentPlans, normalizeTreatmentPlanSteps } from '@/lib/treatmentPlans';
import {
  buildForecastSteps,
  stepsInForecastWindow,
  extractHistoricalDoseSamples,
  buildInsumoSubstanceMap,
  nonExpiredStockBySubstance,
  buildStockForecast,
  doseHistoryLookbackStart,
  FORECAST_WINDOW_DAYS,
  type SubstanceStockForecast,
} from '@/lib/stockForecast';
import { SUBSTANCE_LABEL } from '@/types/harmonize';
import type { InsumoStockRow } from '@/lib/stock';
import type { InsumoStockBatch } from '@/lib/stockBatches';

type Props = {
  /** Insumos já buscados/normalizados pela aba Estoque (EstoqueTab) — reaproveitados aqui para não duplicar a query de `insumos`. */
  insumos: InsumoStockRow[];
  /** Lotes já buscados/normalizados pela aba Estoque — reaproveitados aqui para não duplicar a query de `insumo_stock_batches`. */
  batches: InsumoStockBatch[];
};

/**
 * Seção "Previsão de necessidade de estoque" (proposta #4 do ciclo de
 * Produto & Features de 13/09) — cruza três sistemas que já existiam
 * isolados: Combo Plans (`treatment_plans`/`treatment_plan_steps`), o
 * histórico real de sessões concluídas e o estoque por lote/validade.
 * Renderizada dentro da aba "Estoque" do /painel (EstoqueTab), não em
 * "overview" nem numa aba própria: é fundamentalmente uma pergunta sobre
 * estoque ("vou ter insumo suficiente esta semana?"), então mora ao lado do
 * saldo/alerta de vencimento que já respondem perguntas de estoque — e
 * reaproveita os `insumos`/`batches` que a aba já busca, em vez de duplicar
 * as queries.
 *
 * Toda a lógica de negócio (janela de 7 dias, contagem vs. estimativa,
 * comparação com estoque não vencido) vive em src/lib/stockForecast.ts,
 * testável sem Supabase — este componente só busca as 2 tabelas que faltam
 * (Combo Plans e histórico de sessões) e monta a UI fina em cima do
 * resultado puro.
 *
 * IMPORTANTE (ver comentário de cabeçalho de stockForecast.ts): nem
 * `appointments` nem `treatment_plan_steps` guardam uma dose/quantidade real
 * — só a substância. Por isso esta seção NUNCA mostra uma "quantidade
 * necessária" inventada: ou mostra a CONTAGEM de etapas pendentes por
 * substância (sempre honesta), ou uma ESTIMATIVA baseada na dose média REAL
 * observada em sessões já concluídas (só quando há amostra suficiente,
 * rotulada como estimativa). A Agenda (`appointments`) fica de fora desta
 * v1 — não tem vínculo confiável com substância/dose, ver `agendaNote` na
 * i18n.
 */
const StockForecastSection: React.FC<Props> = ({ insumos, batches }) => {
  const { user } = useAuth();
  const { t } = useTranslation();

  const { data: plansRaw } = useQuery({
    queryKey: ['stock-forecast-plans', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('treatment_plans')
        .select('id, patient_id, name, start_date')
        .eq('professional_id', user!.id);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  // Só etapas PENDENTES entram na previsão (concluída/pulada não representam
  // necessidade futura) — filtrado já na query pra não trazer o histórico
  // inteiro de etapas de todo Combo Plan do profissional.
  const { data: stepsRaw } = useQuery({
    queryKey: ['stock-forecast-steps', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('treatment_plan_steps')
        .select('id, plan_id, substance, offset_days, status')
        .eq('professional_id', user!.id)
        .eq('status', 'pendente');
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  // Janela mais larga que a de FaturamentoTab (12 meses, ver comentário de
  // DOSE_HISTORY_LOOKBACK_MONTHS) — aqui a amostra é por PONTO de uma
  // substância específica, mais esparsa que "toda sessão do mês".
  const { data: sessionsRaw } = useQuery({
    queryKey: ['stock-forecast-sessions', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sessions')
        .select('status, stage2_overlay')
        .eq('professional_id', user!.id)
        .gte('created_at', doseHistoryLookbackStart().toISOString());
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  const forecast = useMemo<SubstanceStockForecast[]>(() => {
    const plans = normalizeTreatmentPlans(plansRaw ?? []);
    const steps = normalizeTreatmentPlanSteps(stepsRaw ?? []);
    const forecastSteps = buildForecastSteps(plans, steps);
    const stepsInWindow = stepsInForecastWindow(forecastSteps);
    const historicalDoses = extractHistoricalDoseSamples((sessionsRaw ?? []) as { status: string | null; stage2_overlay: unknown }[]);
    const insumoSubstanceById = buildInsumoSubstanceMap(insumos.map((i) => ({ id: i.id, substance: i.substance })));
    const availableStockBySubstance = nonExpiredStockBySubstance(batches, insumoSubstanceById);
    return buildStockForecast({ stepsInWindow, historicalDoses, availableStockBySubstance });
  }, [plansRaw, stepsRaw, sessionsRaw, insumos, batches]);

  // Nenhuma etapa de Combo Plan prevista pra semana: estado vazio explícito,
  // NUNCA "0 necessário" (que pareceria uma garantia de que nada será
  // consumido, em vez de "não há dado pra prever nada").
  if (forecast.length === 0) {
    return (
      <HCard className="flex flex-col items-center gap-1.5 text-center py-5">
        <div data-testid="stock-forecast-empty" className="flex flex-col items-center gap-1.5">
          <CalendarClock size={18} style={{ color: '#AAA8A5' }} />
          <p className="text-[12px] text-h-text-3">{t('stockForecast.empty', { days: FORECAST_WINDOW_DAYS })}</p>
        </div>
      </HCard>
    );
  }

  return (
    <HCard>
      <div data-testid="stock-forecast-section" className="flex items-center gap-2 mb-1">
        <TrendingUp size={16} style={{ color: '#2D8AB8' }} />
        <p className="text-[13px] font-semibold text-h-text">{t('stockForecast.title')}</p>
      </div>
      <p className="text-[11px] text-h-text-3 mb-3">{t('stockForecast.subtitle', { days: FORECAST_WINDOW_DAYS })}</p>

      <div className="flex flex-col gap-3">
        {forecast.map((entry) => (
          <div
            key={entry.substance}
            data-testid={`forecast-${entry.substance}`}
            className="flex flex-col gap-1 pb-3 border-b border-black/5 last:border-0 last:pb-0"
          >
            <p className="text-[12.5px] font-semibold text-h-text">
              {entry.mode === 'estimate'
                ? t('stockForecast.estimateLabel', {
                    quantity: entry.estimatedQuantityNeeded,
                    unit: entry.unit,
                    substance: SUBSTANCE_LABEL[entry.substance],
                  })
                : t('stockForecast.countLabel', { count: entry.stepsInWindow, substance: SUBSTANCE_LABEL[entry.substance] })}
            </p>
            <p className="text-[11px] text-h-text-3">
              {entry.mode === 'estimate'
                ? t('stockForecast.estimateBasis', { count: entry.sampleSize })
                : t('stockForecast.countBasis')}
            </p>
            <div className="flex items-center justify-between gap-2 text-[11px] mt-0.5">
              <span className="text-h-text-3">{t('stockForecast.availableStock', { quantity: entry.availableStock, unit: entry.unit })}</span>
              {entry.stockSufficient != null && (
                <span
                  data-testid={`forecast-sufficiency-${entry.substance}`}
                  className="font-bold flex-shrink-0"
                  style={{ color: entry.stockSufficient ? '#2DB87A' : '#E05050' }}
                >
                  {entry.stockSufficient ? t('stockForecast.stockSufficient') : t('stockForecast.stockInsufficient')}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <p className="text-[10px] text-h-text-3 mt-3">{t('stockForecast.agendaNote')}</p>
    </HCard>
  );
};

export default StockForecastSection;
