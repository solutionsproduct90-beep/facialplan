import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, RefreshCw, Award } from 'lucide-react';
import HCard from '@/components/harmonize/HCard';
import { SkeletonStats, SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { normalizeInsumos, formatCurrency, isCurrencyCode } from '@/lib/budget';
import {
  computeMonthlyBillingSummary,
  rankSubstancesByMargin,
  buildMonthlyRevenueChartData,
  billingLookbackStart,
  type SessionForBilling,
} from '@/lib/faturamento';
import { fetchAllRows } from '@/lib/fetchAllRows';

const CHART_MONTHS = 6;

/**
 * Aba "Faturamento" do /painel (ideia do squad de Produto: "Painel de
 * Faturamento Agregado") — diferente do card ROI da aba "overview"
 * (panel.ts, potencial financeiro de QUALQUER sessão com pontos lançados,
 * concluída ou não), aqui a métrica é faturamento no sentido estrito:
 * receita/margem/ticket médio só de sessões CONCLUÍDAS (`status ===
 * 'complete'`), a mesma convenção de "procedimento fechado" já usada em
 * /admin/metricas (src/lib/adminMetrics.ts). Auto-contida como
 * Agenda/EstoqueTab — busca os próprios dados de `sessions`/`insumos`/
 * `profiles`, montada só quando esta aba está ativa.
 *
 * Janela de busca de `sessions`: começa no 1º dia do mês `CHART_MONTHS - 1`
 * meses atrás (ver `billingLookbackStart` em src/lib/faturamento.ts), pra
 * cobrir os 6 meses inteiros do gráfico sem trazer o histórico completo do
 * profissional a cada carregamento da aba — mais larga que os 90 dias de
 * `SESSIONS_LOOKBACK_DAYS` em Painel.tsx (que só precisa cobrir o mês
 * corrente + a folga de streak), então tem sua própria query em vez de
 * reaproveitar a de `overview`.
 */
const FaturamentoTab: React.FC = () => {
  const { user } = useAuth();
  const { t } = useTranslation();

  const {
    data: profile,
    isLoading: loadingProfile,
    isError: profileError,
    refetch: refetchProfile,
  } = useQuery({
    queryKey: ['billing-profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('labor_fee_per_session, currency')
        .eq('id', user!.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const {
    data: insumosData,
    isLoading: loadingInsumos,
    isError: insumosError,
    refetch: refetchInsumos,
  } = useQuery({
    queryKey: ['billing-insumos', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('insumos')
        .select('id, substance, brand_name, cost_per_unit, price_per_unit, active')
        .eq('professional_id', user!.id);
      if (error) throw error;
      return normalizeInsumos(data);
    },
    enabled: !!user,
  });

  const {
    data: sessionsData,
    isLoading: loadingSessions,
    isError: sessionsError,
    refetch: refetchSessions,
  } = useQuery({
    queryKey: ['billing-sessions', user?.id],
    // Paginado (src/lib/fetchAllRows.ts): sem .range(), o teto de 1000 linhas
    // do PostgREST corta a janela de 6 meses em silêncio a partir de ~6
    // sessões/dia — receita, margem, ticket médio e ranking de substâncias
    // passariam a ser calculados sobre um recorte parcial. Achado do QA
    // Contínuo, mesmo risco já corrigido em AgendaTab.tsx/Painel.tsx.
    queryFn: () =>
      fetchAllRows<SessionForBilling>((from, to) =>
        supabase
          .from('sessions')
          .select('created_at, status, stage2_overlay')
          .eq('professional_id', user!.id)
          .gte('created_at', billingLookbackStart(CHART_MONTHS).toISOString())
          .range(from, to),
      ),
    enabled: !!user,
  });

  const isLoading = loadingProfile || loadingInsumos || loadingSessions;
  const hasError = profileError || insumosError || sessionsError;
  const handleRetry = () => {
    refetchProfile();
    refetchInsumos();
    refetchSessions();
  };

  const currency = isCurrencyCode(profile?.currency) ? profile.currency : 'BRL';
  const laborFeePerSession = profile?.labor_fee_per_session ?? null;
  // `?? []` isolado num useMemo próprio: inline direto na dependência dos
  // memos abaixo, o eslint-plugin-react-hooks acusa (com razão) que o
  // fallback `[]` cria um array novo a cada render, mudando de identidade
  // mesmo com `sessionsData` inalterado.
  const sessions = useMemo(() => sessionsData ?? [], [sessionsData]);

  const summary = useMemo(
    () => computeMonthlyBillingSummary(sessions, insumosData, laborFeePerSession),
    [sessions, insumosData, laborFeePerSession],
  );
  const ranking = useMemo(() => rankSubstancesByMargin(sessions, insumosData), [sessions, insumosData]);
  const chartData = useMemo(
    () => buildMonthlyRevenueChartData(sessions, insumosData, laborFeePerSession, CHART_MONTHS),
    [sessions, insumosData, laborFeePerSession],
  );

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <SkeletonStats />
        <SkeletonCard lines={2} />
        <SkeletonCard lines={2} />
      </div>
    );
  }

  if (hasError) {
    return (
      <HCard className="flex flex-col items-center gap-2 text-center py-6">
        <p className="text-[13px] text-h-text-2">{t('panel.billing.error.load')}</p>
        <button
          onClick={handleRetry}
          className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
          style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
        >
          <RefreshCw size={14} />
          {t('panel.billing.error.retry')}
        </button>
      </HCard>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {summary.sessionsCount === 0 ? (
        <HCard className="text-center py-6">
          <p className="text-[13px] text-h-text-2">{t('panel.billing.empty')}</p>
        </HCard>
      ) : (
        <>
          {/* ── Resumo do mês ── */}
          <div className="grid grid-cols-2 gap-3">
            <HCard>
              <p className="text-[18px] font-extrabold leading-none text-h-text" style={{ letterSpacing: '-0.01em' }}>
                {formatCurrency(summary.revenue, currency)}
              </p>
              <p className="text-[11px] font-semibold text-h-text-3 mt-1">{t('panel.billing.summary.revenue')}</p>
            </HCard>
            <HCard>
              <p className="text-[18px] font-extrabold leading-none" style={{ color: '#1D9A64', letterSpacing: '-0.01em' }}>
                {formatCurrency(summary.margin, currency)}
              </p>
              <p className="text-[11px] font-semibold text-h-text-3 mt-1">
                {t('panel.billing.summary.margin', { pct: Math.round(summary.marginPct * 100) })}
              </p>
            </HCard>
            <HCard>
              <p className="text-[18px] font-extrabold leading-none text-h-text" style={{ letterSpacing: '-0.01em' }}>
                {formatCurrency(summary.avgTicket, currency)}
              </p>
              <p className="text-[11px] font-semibold text-h-text-3 mt-1">{t('panel.billing.summary.avgTicket')}</p>
            </HCard>
            <HCard>
              <p className="text-[18px] font-extrabold leading-none text-h-text" style={{ letterSpacing: '-0.01em' }}>
                {summary.sessionsCount}
              </p>
              <p className="text-[11px] font-semibold text-h-text-3 mt-1">{t('panel.billing.summary.sessions')}</p>
            </HCard>
          </div>

          {/* ── Receita por mês (últimos 6 meses) ── */}
          <HCard>
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp size={16} style={{ color: '#BF5F82' }} />
              <p className="text-[13px] font-semibold text-h-text">{t('panel.billing.chartTitle')}</p>
            </div>
            <div className="w-full" style={{ height: 200 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 4, right: 8, left: -20, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E3E0" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#6B6965' }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#6B6965' }} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.12)', fontSize: 12 }}
                    formatter={(value: number) => [formatCurrency(value, currency), t('panel.billing.summary.revenue')]}
                  />
                  <Bar dataKey="revenue" fill="#BF5F82" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </HCard>

          {/* ── Substâncias mais lucrativas ── */}
          {ranking.length > 0 && (
            <HCard className="!p-0 overflow-hidden">
              <div className="flex items-center gap-2 p-4 pb-2">
                <Award size={16} style={{ color: '#D4900A' }} />
                <p className="text-[13px] font-semibold text-h-text">{t('panel.billing.rankingTitle')}</p>
              </div>
              <div className="flex flex-col divide-y divide-black/5">
                {ranking.map((r, i) => (
                  <div key={r.substance} className="flex items-center gap-3 px-4 py-3">
                    <span
                      className="w-[22px] h-[22px] rounded-full flex items-center justify-center flex-shrink-0 text-[11px] font-extrabold"
                      style={{ background: i === 0 ? 'rgba(212,144,10,0.15)' : 'rgba(0,0,0,0.04)', color: i === 0 ? '#D4900A' : '#AAA8A5' }}
                    >
                      {i + 1}
                    </span>
                    <p className="flex-1 text-[13px] font-semibold text-h-text truncate">{r.label}</p>
                    <p className="text-[13px] font-bold" style={{ color: '#1D9A64' }}>
                      {formatCurrency(r.margin, currency)}
                    </p>
                  </div>
                ))}
              </div>
            </HCard>
          )}
        </>
      )}
    </div>
  );
};

export default FaturamentoTab;
