import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { QueryClientProvider, QueryClient } from '@tanstack/react-query';
import StockForecastSection from './StockForecastSection';
import { MIN_DOSE_HISTORY_SAMPLE_SIZE } from '@/lib/stockForecast';
import type { InsumoStockRow } from '@/lib/stock';
import type { InsumoStockBatch } from '@/lib/stockBatches';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

/** Builder genérico `.select().eq().eq().gte()` (lista) pras 3 tabelas que este componente busca. */
function createListBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    gte: () => builder,
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

const TODAY = new Date();

function isoDateInDays(days: number): string {
  const d = new Date(TODAY);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

const insumo: InsumoStockRow = {
  id: 'ins-1',
  substance: 'toxina_botulinica',
  brandName: 'Dysport',
  active: true,
  quantityOnHand: 100,
  lowStockThreshold: null,
};

const batchAmple: InsumoStockBatch = {
  id: 'batch-1',
  insumoId: 'ins-1',
  batchNumber: 'L1',
  expiresOn: null,
  quantityReceived: 200,
  quantityRemaining: 200,
  receivedOn: '2026-01-01',
};

function mockTables(opts: { plans?: unknown[]; steps?: unknown[]; sessions?: unknown[] }) {
  fromMock.mockImplementation((table: string) => {
    if (table === 'treatment_plans') return createListBuilder(opts.plans ?? []);
    if (table === 'treatment_plan_steps') return createListBuilder(opts.steps ?? []);
    if (table === 'sessions') return createListBuilder(opts.sessions ?? []);
    throw new Error(`unexpected table ${table}`);
  });
}

const renderSection = (insumos: InsumoStockRow[] = [], batches: InsumoStockBatch[] = []) =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <StockForecastSection insumos={insumos} batches={batches} />
    </QueryClientProvider>,
  );

describe('StockForecastSection', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
  });

  it('shows the empty state — never a misleading "0 needed" — when there is no pending Combo Plan step in the window', async () => {
    mockTables({ plans: [], steps: [], sessions: [] });
    renderSection([], []);
    expect(await screen.findByTestId('stock-forecast-empty')).toBeInTheDocument();
    expect(screen.queryByTestId('stock-forecast-section')).not.toBeInTheDocument();
  });

  it('falls back to (a) step-count mode, labeled as steps and not as a quantity, when there is not enough dose history', async () => {
    mockTables({
      plans: [{ id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo', start_date: isoDateInDays(0) }],
      steps: [
        { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, status: 'pendente' },
        { id: 'step-2', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 3, status: 'pendente' },
      ],
      sessions: [], // sem histórico nenhum -> amostra insuficiente
    });
    renderSection([insumo], [batchAmple]);

    const entry = await screen.findByTestId('forecast-toxina_botulinica');
    expect(entry).toHaveTextContent('2 etapas de Toxina Botulínica previstas esta semana');
    expect(entry).toHaveTextContent('Sem histórico suficiente para estimar quantidade');
    // Modo contagem não compara com estoque — não deve renderizar o badge de suficiência.
    expect(screen.queryByTestId('forecast-sufficiency-toxina_botulinica')).not.toBeInTheDocument();
  });

  it('excludes steps outside the 7-day window and non-pending steps from the count', async () => {
    mockTables({
      plans: [{ id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo', start_date: isoDateInDays(0) }],
      steps: [
        { id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, status: 'pendente' }, // dentro
        { id: 'step-2', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 30, status: 'pendente' }, // fora da janela
      ],
      sessions: [],
    });
    renderSection([insumo], [batchAmple]);

    const entry = await screen.findByTestId('forecast-toxina_botulinica');
    expect(entry).toHaveTextContent('1 etapa de Toxina Botulínica prevista esta semana');
  });

  it('uses (b) real historical average dose to estimate quantity when there is enough sample, and compares it against non-expired stock', async () => {
    const sessions = Array.from({ length: MIN_DOSE_HISTORY_SAMPLE_SIZE }, () => ({
      status: 'complete',
      stage2_overlay: [{ substance: 'toxina_botulinica', quantity: 20 }],
    }));
    mockTables({
      plans: [{ id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo', start_date: isoDateInDays(0) }],
      steps: [{ id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, status: 'pendente' }],
      sessions,
    });
    renderSection([insumo], [batchAmple]);

    const entry = await screen.findByTestId('forecast-toxina_botulinica');
    expect(entry).toHaveTextContent('≈ 20 unidades de Toxina Botulínica estimados para esta semana');
    expect(entry).toHaveTextContent('Estimativa baseada em 5 aplicações reais registradas');
    expect(screen.getByTestId('forecast-sufficiency-toxina_botulinica')).toHaveTextContent('Estoque suficiente');
  });

  it('flags insufficient stock when the estimated need exceeds non-expired stock', async () => {
    const sessions = Array.from({ length: MIN_DOSE_HISTORY_SAMPLE_SIZE }, () => ({
      status: 'complete',
      stage2_overlay: [{ substance: 'toxina_botulinica', quantity: 50 }],
    }));
    mockTables({
      plans: [{ id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo', start_date: isoDateInDays(0) }],
      steps: [{ id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, status: 'pendente' }],
      sessions,
    });
    const lowBatch: InsumoStockBatch = { ...batchAmple, quantityRemaining: 5 };
    renderSection([insumo], [lowBatch]);

    expect(await screen.findByTestId('forecast-sufficiency-toxina_botulinica')).toHaveTextContent('Estoque pode não ser suficiente');
  });

  it('ignores an expired batch when computing available stock', async () => {
    const sessions = Array.from({ length: MIN_DOSE_HISTORY_SAMPLE_SIZE }, () => ({
      status: 'complete',
      stage2_overlay: [{ substance: 'toxina_botulinica', quantity: 10 }],
    }));
    mockTables({
      plans: [{ id: 'plan-1', patient_id: 'pat-1', name: 'Protocolo', start_date: isoDateInDays(0) }],
      steps: [{ id: 'step-1', plan_id: 'plan-1', substance: 'toxina_botulinica', offset_days: 0, status: 'pendente' }],
      sessions,
    });
    const expiredBatch: InsumoStockBatch = { ...batchAmple, expiresOn: '2020-01-01', quantityRemaining: 500 };
    renderSection([insumo], [expiredBatch]);

    const entry = await screen.findByTestId('forecast-toxina_botulinica');
    expect(entry).toHaveTextContent('Estoque não vencido: 0 unidades');
  });
});
