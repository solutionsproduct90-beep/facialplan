import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AgendaOverviewWidget from './AgendaOverviewWidget';
import i18n from '@/i18n';
import { createRangeSlicer } from '@/test/supabaseMock';

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

/** Builder pra `appointments`: só a leitura paginada que o widget faz. */
function createAppointmentsBuilder(rows: unknown[]) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) =>
      Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
  };
  return builder;
}

function renderWidget(rows: unknown[], onOpenAgenda = vi.fn()) {
  useAuthMock.mockReturnValue({ user: { id: 'prof-1' } });
  fromMock.mockImplementation((table: string) => {
    if (table === 'appointments') return createAppointmentsBuilder(rows);
    throw new Error(`unexpected table ${table}`);
  });
  const queryClient = new QueryClient();
  render(
    <QueryClientProvider client={queryClient}>
      <AgendaOverviewWidget onOpenAgenda={onOpenAgenda} />
    </QueryClientProvider>,
  );
  return { onOpenAgenda };
}

describe('AgendaOverviewWidget', () => {
  it('shows the next scheduled appointments, excluding concluded/cancelled', async () => {
    renderWidget([
      { id: 'a1', patient_id: 'p1', note: null, scheduled_at: '2026-09-15T09:00:00', duration_minutes: null, status: 'agendado', patient: { name: 'Maria' } },
      { id: 'a2', patient_id: 'p2', note: null, scheduled_at: '2026-09-15T08:00:00', duration_minutes: null, status: 'concluido', patient: { name: 'Joana' } },
    ]);
    await waitFor(() => expect(screen.getByText('Maria')).toBeInTheDocument());
    expect(screen.queryByText('Joana')).not.toBeInTheDocument();
  });

  it('shows an empty state when there is nothing scheduled', async () => {
    renderWidget([]);
    await waitFor(() => expect(screen.getByText(i18n.t('panel.agendaWidget.empty'))).toBeInTheDocument());
  });

  it('calls onOpenAgenda when the header or an item is clicked', async () => {
    const { onOpenAgenda } = renderWidget([
      { id: 'a1', patient_id: 'p1', note: null, scheduled_at: '2026-09-15T09:00:00', duration_minutes: null, status: 'agendado', patient: { name: 'Maria' } },
    ]);
    await waitFor(() => expect(screen.getByText('Maria')).toBeInTheDocument());

    fireEvent.click(screen.getByTestId('agenda-widget-open-agenda'));
    expect(onOpenAgenda).toHaveBeenCalledTimes(1);

    fireEvent.click(screen.getByTestId('agenda-widget-item-a1'));
    expect(onOpenAgenda).toHaveBeenCalledTimes(2);
  });
});
