import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import EstoqueOverviewWidget from './EstoqueOverviewWidget';
import i18n from '@/i18n';
import { createQueryBuilder } from '@/test/supabaseMock';

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

function isoInDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function renderWidget(insumos: unknown[], batches: unknown[], onOpenEstoque = vi.fn()) {
  useAuthMock.mockReturnValue({ user: { id: 'prof-1' } });
  fromMock.mockImplementation((table: string) => {
    if (table === 'insumos') return createQueryBuilder({ data: insumos });
    if (table === 'insumo_stock_batches') return createQueryBuilder({ data: batches });
    throw new Error(`unexpected table ${table}`);
  });
  render(
    <QueryClientProvider client={new QueryClient()}>
      <EstoqueOverviewWidget onOpenEstoque={onOpenEstoque} />
    </QueryClientProvider>,
  );
  return { onOpenEstoque };
}

describe('EstoqueOverviewWidget', () => {
  it('shows the all-good state when nothing is low or expiring', async () => {
    renderWidget(
      [{ id: 'i1', substance: 'acido_hialuronico', brand_name: 'X', active: true, quantity_on_hand: 10, low_stock_threshold: 2 }],
      [],
    );
    await waitFor(() => expect(screen.getByText(i18n.t('panel.estoqueWidget.allGood'))).toBeInTheDocument());
  });

  it('counts active low-stock items and batches expiring within 30 days', async () => {
    renderWidget(
      [
        { id: 'i1', substance: 'acido_hialuronico', brand_name: 'X', active: true, quantity_on_hand: 1, low_stock_threshold: 2 },
        { id: 'i2', substance: 'toxina_botulinica', brand_name: 'Y', active: false, quantity_on_hand: 0, low_stock_threshold: 2 },
      ],
      [
        { id: 'b1', insumo_id: 'i1', batch_number: 'L1', expires_on: isoInDays(10), quantity_received: 5, quantity_remaining: 3, received_on: isoInDays(-30) },
        { id: 'b2', insumo_id: 'i1', batch_number: 'L2', expires_on: isoInDays(10), quantity_received: 5, quantity_remaining: 0, received_on: isoInDays(-30) },
      ],
    );
    await waitFor(() =>
      expect(screen.getByText(i18n.t('panel.estoqueWidget.lowStockCount', { count: 1 }))).toBeInTheDocument(),
    );
    expect(screen.getByText(i18n.t('panel.estoqueWidget.expiringSoonCount', { count: 1 }))).toBeInTheDocument();
  });

  it('calls onOpenEstoque when the header is clicked', async () => {
    const { onOpenEstoque } = renderWidget([], []);
    await waitFor(() => expect(screen.getByText(i18n.t('panel.estoqueWidget.allGood'))).toBeInTheDocument());
    fireEvent.click(screen.getByTestId('estoque-widget-open'));
    expect(onOpenEstoque).toHaveBeenCalledTimes(1);
  });
});
