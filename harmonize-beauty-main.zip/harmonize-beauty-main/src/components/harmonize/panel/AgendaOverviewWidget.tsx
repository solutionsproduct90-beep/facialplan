import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { CalendarDays, User, ChevronRight, RefreshCw } from 'lucide-react';
import HCard from '@/components/harmonize/HCard';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { normalizeAppointments, upcomingAppointments, dayHeadingKind } from '@/lib/agenda';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

/**
 * Widget compacto de agenda na aba "Visão Geral" do Painel — vislumbre dos
 * próximos compromissos sem precisar trocar pra aba "Agenda" (ver
 * `upcomingAppointments` em src/lib/agenda.ts). Usa a MESMA `queryKey`
 * (`['agenda-appointments', user.id]`) e a mesma leitura paginada que
 * AgendaTab.tsx já usa — compartilha o cache do React Query em vez de duas
 * leituras independentes da mesma tabela: se o profissional já abriu a aba
 * "Agenda" nesta sessão, este widget renderiza na hora, sem round-trip novo.
 *
 * Somente leitura — abrir/editar um compromisso continua sendo tarefa da
 * aba "Agenda" completa (`onOpenAgenda`, que o Painel liga a
 * `setActiveTab('agenda')`).
 */
const AgendaOverviewWidget: React.FC<{ onOpenAgenda: () => void }> = ({ onOpenAgenda }) => {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const locale = dateFnsLocale[i18n.language] ?? ptBR;

  const {
    data: appointmentsRaw,
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ['agenda-appointments', user?.id],
    queryFn: () =>
      fetchAllRows((from, to) =>
        supabase
          .from('appointments')
          .select('id, patient_id, note, scheduled_at, duration_minutes, status, patient:patients(name)')
          .eq('professional_id', user!.id)
          .order('scheduled_at', { ascending: true })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const upcoming = useMemo(
    () => upcomingAppointments(normalizeAppointments(appointmentsRaw ?? [])),
    [appointmentsRaw],
  );

  const timeLabel = (dateKey: string, scheduledAt: string) => {
    const kind = dayHeadingKind(dateKey);
    const time = format(new Date(scheduledAt), 'HH:mm');
    if (kind === 'today') return t('panel.agendaWidget.todayAt', { time });
    if (kind === 'tomorrow') return t('panel.agendaWidget.tomorrowAt', { time });
    return t('panel.agendaWidget.dateAt', { date: format(new Date(scheduledAt), 'dd/MM', { locale }), time });
  };

  return (
    <HCard data-testid="agenda-overview-widget">
      <button
        onClick={onOpenAgenda}
        data-testid="agenda-widget-open-agenda"
        className="flex items-center justify-between w-full press-scale"
        style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
      >
        <div className="flex items-center gap-2">
          <CalendarDays size={16} style={{ color: '#7C5AC2' }} />
          <p className="text-[13px] font-semibold text-h-text">{t('panel.agendaWidget.title')}</p>
        </div>
        <div className="flex items-center gap-1" style={{ color: '#AAA8A5' }}>
          <span className="text-[11px] font-semibold">{t('panel.agendaWidget.viewAll')}</span>
          <ChevronRight size={14} />
        </div>
      </button>

      <div className="mt-2">
        {isLoading ? (
          <SkeletonCard lines={2} />
        ) : isError ? (
          <div className="flex items-center justify-between py-2">
            <p className="text-[12px] text-h-text-2">{t('agenda.error.load')}</p>
            <button
              onClick={() => refetch()}
              className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
              style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
            >
              <RefreshCw size={14} />
              {t('agenda.error.retry')}
            </button>
          </div>
        ) : upcoming.length === 0 ? (
          <p className="text-[12.5px] text-h-text-2 py-1">{t('panel.agendaWidget.empty')}</p>
        ) : (
          <div className="flex flex-col divide-y divide-black/5">
            {upcoming.map((appt) => {
              const dateKey = format(new Date(appt.scheduledAt), 'yyyy-MM-dd');
              return (
                <button
                  key={appt.id}
                  onClick={onOpenAgenda}
                  data-testid={`agenda-widget-item-${appt.id}`}
                  className="flex items-center gap-3 py-2.5 w-full text-left press-scale"
                  style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-[12.5px] font-semibold text-h-text truncate flex items-center gap-1">
                      <User size={11} className="flex-shrink-0 text-h-text-3" />
                      {appt.patientName ?? t('agenda.noPatient')}
                    </p>
                    {appt.note && <p className="text-[11px] text-h-text-3 truncate">{appt.note}</p>}
                  </div>
                  <span className="text-[11.5px] font-bold flex-shrink-0" style={{ color: '#7C5AC2' }}>
                    {timeLabel(dateKey, appt.scheduledAt)}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </HCard>
  );
};

export default AgendaOverviewWidget;
