import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Package, PackagePlus, PackageMinus, AlertTriangle, Clock, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import HCard from '@/components/harmonize/HCard';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { normalizeInsumoStock, isLowStock, type InsumoStockRow } from '@/lib/stock';
import {
  normalizeStockBatches,
  daysUntilExpiry,
  batchesExpiringSoon,
  describeExpiryDays,
  type InsumoStockBatch,
} from '@/lib/stockBatches';
import { INSUMO_CATEGORY_LABEL, INSUMO_CATEGORY_DEFAULT_UNIT, INSUMO_CATEGORY_KEYS } from '@/types/harmonize';
import { fetchAllRows } from '@/lib/fetchAllRows';
import StockForecastSection from './StockForecastSection';

type MovementKind = 'entrada' | 'saida';

// Janela de alerta de vencimento — 30 dias, mesmo valor usado em todo
// src/lib/stockBatches.ts (isBatchExpiringSoon/batchesExpiringSoon), aqui
// nomeada pra não espalhar o número mágico "30" pela tela.
const EXPIRING_SOON_WINDOW_DAYS = 30;

/**
 * Aba "Estoque" do /painel — controle de estoque dos insumos/marcas
 * cadastrados em `/perfil/insumos`: saldo agregado (herdado da V1, ver
 * src/lib/stock.ts), registro manual de entrada/saída, e agora (ERP
 * completo) rastreio por lote/validade (src/lib/stockBatches.ts) com
 * alerta de vencimento — o decremento automático ao concluir uma sessão
 * (FEFO) acontece do lado do servidor via RPC `consume_insumo_stock_fefo`,
 * chamada em SessaoEstagio3.tsx#handleComplete, não nesta tela. Também
 * renderiza `StockForecastSection` (proposta #4 do ciclo de Produto de
 * 13/09: cruza Combo Plans + histórico de sessões + este mesmo estoque pra
 * projetar necessidade dos próximos 7 dias) reaproveitando os `insumos`/
 * `batches` já buscados aqui, em vez de duplicar as queries.
 */
const EstoqueTab: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  const [movementSheetOpen, setMovementSheetOpen] = useState(false);
  const [movementKind, setMovementKind] = useState<MovementKind>('entrada');
  const [movementInsumo, setMovementInsumo] = useState<InsumoStockRow | null>(null);
  const [movementQuantity, setMovementQuantity] = useState('');
  const [movementNote, setMovementNote] = useState('');
  // Lote/validade só fazem sentido numa entrada (o que está SENDO recebido
  // agora) — nunca aparecem no formulário de saída. Ambos opcionais: sem
  // número de lote informado, a movimentação segue como na V1 (saldo
  // agregado, sem registro de lote), preservando o fluxo mais rápido de
  // quem não quer rastrear lote pra tudo que entra.
  const [movementBatchNumber, setMovementBatchNumber] = useState('');
  const [movementExpiresOn, setMovementExpiresOn] = useState('');
  const [saving, setSaving] = useState(false);

  const {
    data: insumosRaw,
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ['stock-insumos', user?.id],
    // Paginado (src/lib/fetchAllRows.ts): sem .range(), o teto de 1000
    // linhas do PostgREST corta a lista de insumos em silêncio — achado do
    // QA Contínuo, mesmo padrão já aplicado em AgendaTab.tsx/Painel.tsx.
    queryFn: () =>
      fetchAllRows((from, to) =>
        supabase
          .from('insumos')
          .select('id, substance, brand_name, active, quantity_on_hand, low_stock_threshold')
          .eq('professional_id', user!.id)
          .order('substance', { ascending: true })
          .order('brand_name', { ascending: true })
          .range(from, to),
      ),
    enabled: !!user,
  });

  // Lotes com saldo (a maioria, na prática — lotes esgotados só importam
  // pra auditoria em insumo_stock_movements, não pra esta tela) de todos os
  // insumos do profissional, buscados uma vez e agrupados/filtrados no
  // client com as funções puras de stockBatches.ts — mesmo padrão dos
  // demais cálculos desta aba.
  const { data: batchesRaw } = useQuery({
    queryKey: ['stock-batches', user?.id],
    // Mesmo motivo da paginação de `insumos` acima: profissional com estoque
    // ativo há tempo suficiente acumula mais de 1000 lotes.
    queryFn: () =>
      fetchAllRows((from, to) =>
        supabase
          .from('insumo_stock_batches')
          .select('id, insumo_id, batch_number, expires_on, quantity_received, quantity_remaining, received_on')
          .eq('professional_id', user!.id)
          .range(from, to),
      ),
    enabled: !!user,
  });

  const insumos = useMemo(() => normalizeInsumoStock(insumosRaw ?? []), [insumosRaw]);
  const batches = useMemo(() => normalizeStockBatches(batchesRaw ?? []), [batchesRaw]);

  const openBatches = useMemo(() => batches.filter((b) => b.quantityRemaining > 0), [batches]);
  const soonExpiring = useMemo(
    () => batchesExpiringSoon(openBatches, EXPIRING_SOON_WINDOW_DAYS),
    [openBatches],
  );
  const insumoById = useMemo(() => new Map(insumos.map((i) => [i.id, i])), [insumos]);
  // Só o lote de vencimento mais próximo importa pro badge por insumo — um
  // insumo com 3 lotes vencendo não precisa de 3 badges na mesma linha.
  const nearestExpiringByInsumo = useMemo(() => {
    const map = new Map<string, InsumoStockBatch>();
    for (const batch of soonExpiring) {
      const current = map.get(batch.insumoId);
      if (!current || (batch.expiresOn ?? '') < (current.expiresOn ?? '')) {
        map.set(batch.insumoId, batch);
      }
    }
    return map;
  }, [soonExpiring]);

  const expiryLabel = (expiresOn: string | null): string | null => {
    const days = daysUntilExpiry(expiresOn);
    if (days == null) return null;
    const desc = describeExpiryDays(days);
    if (desc.kind === 'today') return t('stock.batches.expiresToday');
    if (desc.kind === 'expired') return t('stock.batches.expiredDaysAgo', { count: desc.daysAgo });
    return t('stock.batches.expiresInDays', { count: desc.daysLeft });
  };

  const openMovement = (insumo: InsumoStockRow, kind: MovementKind) => {
    setMovementInsumo(insumo);
    setMovementKind(kind);
    setMovementQuantity('');
    setMovementNote('');
    setMovementBatchNumber('');
    setMovementExpiresOn('');
    setMovementSheetOpen(true);
  };

  const handleSaveMovement = async () => {
    if (!user || !movementInsumo) return;
    const qty = Number(movementQuantity.replace(',', '.'));
    if (!Number.isFinite(qty) || qty <= 0) {
      toast.error(t('stock.form.invalidQuantity'));
      return;
    }
    setSaving(true);
    try {
      const trimmedBatchNumber = movementKind === 'entrada' ? movementBatchNumber.trim() : '';
      let batchId: string | null = null;

      // Entrada COM número de lote: cria o lote (saldo inicial = quantidade
      // recebida, garantido pelo trigger do banco mesmo que quantity_remaining
      // não seja enviado aqui) antes da movimentação, pra linkar as duas.
      if (trimmedBatchNumber) {
        const { data: batchRow, error: batchError } = await supabase
          .from('insumo_stock_batches')
          .insert({
            insumo_id: movementInsumo.id,
            professional_id: user.id,
            batch_number: trimmedBatchNumber,
            expires_on: movementExpiresOn || null,
            quantity_received: qty,
          })
          .select('id')
          .single();
        if (batchError) throw batchError;
        batchId = (batchRow as { id: string } | null)?.id ?? null;
      }

      const { error } = await supabase.from('insumo_stock_movements').insert({
        insumo_id: movementInsumo.id,
        professional_id: user.id,
        quantity_delta: movementKind === 'entrada' ? qty : -qty,
        note: movementNote.trim() || null,
        ...(batchId ? { batch_id: batchId } : {}),
      });
      if (error) throw error;
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['stock-insumos', user.id] }),
        queryClient.invalidateQueries({ queryKey: ['stock-batches', user.id] }),
      ]);
      setMovementSheetOpen(false);
      toast.success(t('stock.toastSaved'));
    } catch (err: any) {
      toast.error(err.message || t('stock.toastError'));
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col gap-3">
        <SkeletonCard lines={2} />
        <SkeletonCard lines={2} />
      </div>
    );
  }

  if (isError) {
    return (
      <HCard className="flex flex-col items-center gap-2 text-center py-6">
        <p className="text-[13px] text-h-text-2">{t('stock.error.load')}</p>
        <button
          onClick={() => refetch()}
          className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
          style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
        >
          <RefreshCw size={14} />
          {t('stock.error.retry')}
        </button>
      </HCard>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <HCard>
        <div className="flex items-center gap-2 mb-1.5">
          <Package size={16} style={{ color: '#D4900A' }} />
          <p className="text-[13px] font-semibold text-h-text">{t('stock.title')}</p>
        </div>
        <p className="text-[11px] text-h-text-3">{t('stock.subtitle')}</p>
      </HCard>

      {soonExpiring.length > 0 && (
        <HCard style={{ background: 'rgba(212,144,10,0.06)', border: '1px solid rgba(212,144,10,0.25)' }}>
          <div className="flex items-center gap-2 mb-2">
            <Clock size={15} style={{ color: '#D4900A' }} />
            <p className="text-[12px] font-bold text-h-text">{t('stock.batches.expiringTitle')}</p>
          </div>
          <div className="flex flex-col gap-1.5">
            {soonExpiring.map((batch) => {
              const insumo = insumoById.get(batch.insumoId);
              const label = expiryLabel(batch.expiresOn);
              return (
                <div key={batch.id} data-testid={`stock-expiring-${batch.id}`} className="flex items-center justify-between gap-2 text-[12px]">
                  <span className="text-h-text-2 truncate">
                    {insumo?.brandName ?? '—'} · {t('stock.batches.lot', { lot: batch.batchNumber })}
                  </span>
                  <span className="font-bold flex-shrink-0" style={{ color: '#D4900A' }}>
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        </HCard>
      )}

      <StockForecastSection insumos={insumos} batches={batches} />

      {insumos.length === 0 ? (
        <HCard className="flex flex-col items-center gap-3 text-center py-6">
          <p className="text-[13px] text-h-text-2">{t('stock.empty')}</p>
          <button
            onClick={() => navigate('/perfil/insumos')}
            style={{ color: '#BF5F82', background: 'none', border: 'none', fontSize: 13, fontWeight: 700, cursor: 'pointer', minHeight: 44 }}
          >
            {t('stock.emptyCta')}
          </button>
        </HCard>
      ) : (
        INSUMO_CATEGORY_KEYS.map((substance) => {
          const items = insumos.filter((i) => i.substance === substance);
          if (items.length === 0) return null;
          const unit = INSUMO_CATEGORY_DEFAULT_UNIT[substance];
          return (
            <div key={substance} className="flex flex-col gap-2">
              <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide px-1">
                {t(`profile.insumos.categories.${substance}`, { defaultValue: INSUMO_CATEGORY_LABEL[substance] })}
              </p>
              <HCard className="!p-0 overflow-hidden">
                <div className="flex flex-col divide-y divide-black/5">
                  {items.map((insumo) => {
                    const low = isLowStock(insumo.quantityOnHand, insumo.lowStockThreshold);
                    const nearestExpiring = nearestExpiringByInsumo.get(insumo.id);
                    return (
                      <div key={insumo.id} className="flex items-center gap-3 p-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-semibold text-h-text truncate">{insumo.brandName}</p>
                          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                            <span
                              className={`text-[12px] font-bold ${low ? '' : 'text-h-text-2'}`}
                              style={low ? { color: '#E05050' } : undefined}
                            >
                              {insumo.quantityOnHand} {unit}
                            </span>
                            {low && (
                              <span
                                data-testid={`stock-low-${insumo.id}`}
                                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide"
                                style={{ color: '#E05050' }}
                              >
                                <AlertTriangle size={11} />
                                {insumo.quantityOnHand <= 0 ? t('stock.outOfStock') : t('stock.lowStock')}
                              </span>
                            )}
                            {nearestExpiring && (
                              <span
                                data-testid={`stock-expiring-badge-${insumo.id}`}
                                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide"
                                style={{ color: '#D4900A' }}
                              >
                                <Clock size={11} />
                                {expiryLabel(nearestExpiring.expiresOn)}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button
                            onClick={() => openMovement(insumo, 'entrada')}
                            aria-label={t('stock.actions.stockIn')}
                            className="press-scale"
                            style={{ color: '#2DB87A', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, minWidth: 32 }}
                          >
                            <PackagePlus size={20} />
                          </button>
                          <button
                            onClick={() => openMovement(insumo, 'saida')}
                            aria-label={t('stock.actions.stockOut')}
                            className="press-scale"
                            style={{ color: '#AAA8A5', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, minWidth: 32 }}
                          >
                            <PackageMinus size={20} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </HCard>
            </div>
          );
        })
      )}

      <BottomSheet
        open={movementSheetOpen}
        onClose={() => setMovementSheetOpen(false)}
        title={movementKind === 'entrada' ? t('stock.form.stockInTitle') : t('stock.form.stockOutTitle')}
      >
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
          {movementInsumo && (
            <p className="text-[13px] font-semibold text-h-text">{movementInsumo.brandName}</p>
          )}
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('stock.form.quantityInputLabel')}</label>
            <input
              type="number"
              min={0}
              step="0.01"
              inputMode="decimal"
              autoFocus
              value={movementQuantity}
              onChange={(e) => setMovementQuantity(e.target.value)}
              placeholder="0"
              aria-label={t('stock.form.quantityInputLabel')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
            />
          </div>
          {movementKind === 'entrada' && (
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('stock.form.batchNumberLabel')}</label>
                <input
                  value={movementBatchNumber}
                  onChange={(e) => setMovementBatchNumber(e.target.value)}
                  placeholder={t('stock.form.batchNumberPlaceholder')}
                  aria-label={t('stock.form.batchNumberLabel')}
                  className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('stock.form.expiresOnLabel')}</label>
                <input
                  type="date"
                  value={movementExpiresOn}
                  onChange={(e) => setMovementExpiresOn(e.target.value)}
                  aria-label={t('stock.form.expiresOnLabel')}
                  className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
                />
              </div>
            </div>
          )}
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('stock.form.noteLabel')}</label>
            <input
              value={movementNote}
              onChange={(e) => setMovementNote(e.target.value)}
              placeholder={t('stock.form.notePlaceholder')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
            />
          </div>
          <GradientButton onClick={handleSaveMovement} disabled={saving}>
            {saving ? t('panel.saving') : t('stock.form.save')}
          </GradientButton>
        </div>
      </BottomSheet>
    </div>
  );
};

export default EstoqueTab;
