import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { TrendingUp, RefreshCw, ChevronRight } from 'lucide-react';
import HCard from '@/components/harmonize/HCard';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { formatCurrency, isCurrencyCode, normalizeInsumos } from '@/lib/budget';
import { computeMonthlyBillingSummary, billingLookbackStart, type SessionForBilling } from '@/lib/faturamento';

const CHART_MONTHS = 6;

/**
 * Widget compacto de faturamento no dashboard do Painel (desktop) —
 * receita e margem do MÊS CORRENTE, de sessões concluídas (mesma convenção
 * de FaturamentoTab.tsx). Usa as MESMAS `queryKey`s
 * (`billing-profile`/`billing-insumos`/`billing-sessions`) e a mesma função
 * pura `computeMonthlyBillingSummary` que a aba completa já usa —
 * compartilha o cache do React Query em vez de duplicar a leitura.
 *
 * Só desktop (ver `hidden md:block` em Painel.tsx) — mesma razão de
 * EstoqueOverviewWidget.tsx: no mobile a aba "Faturamento" já é um toque de
 * distância, então este resumo seria peso de rolagem sem ganho real.
 */
const FaturamentoOverviewWidget: React.FC<{ onOpenFaturamento: () => void }> = ({ onOpenFaturamento }) => {
  const { user } = useAuth();
  const { t } = useTranslation();

  const {
    data: profile,
    isLoading: loadingProfile,
    isError: profileError,
    refetch: refetchProfile,
  } = useQuery({
    queryKey: ['billing-profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('labor_fee_per_session, currency')
        .eq('id', user!.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const {
    data: insumosData,
    isLoading: loadingInsumos,
    isError: insumosError,
    refetch: refetchInsumos,
  } = useQuery({
    queryKey: ['billing-insumos', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('insumos')
        .select('id, substance, brand_name, cost_per_unit, price_per_unit, active')
        .eq('professional_id', user!.id);
      if (error) throw error;
      return normalizeInsumos(data);
    },
    enabled: !!user,
  });

  const {
    data: sessionsData,
    isLoading: loadingSessions,
    isError: sessionsError,
    refetch: refetchSessions,
  } = useQuery({
    queryKey: ['billing-sessions', user?.id],
    queryFn: () =>
      fetchAllRows<SessionForBilling>((from, to) =>
        supabase
          .from('sessions')
          .select('created_at, status, stage2_overlay')
          .eq('professional_id', user!.id)
          .gte('created_at', billingLookbackStart(CHART_MONTHS).toISOString())
          .range(from, to),
      ),
    enabled: !!user,
  });

  const isLoading = loadingProfile || loadingInsumos || loadingSessions;
  const hasError = profileError || insumosError || sessionsError;

  const currency = isCurrencyCode(profile?.currency) ? profile.currency : 'BRL';
  const laborFeePerSession = profile?.labor_fee_per_session ?? null;
  const sessions = useMemo(() => sessionsData ?? [], [sessionsData]);
  const summary = useMemo(
    () => computeMonthlyBillingSummary(sessions, insumosData, laborFeePerSession),
    [sessions, insumosData, laborFeePerSession],
  );

  const handleRetry = () => {
    refetchProfile();
    refetchInsumos();
    refetchSessions();
  };

  return (
    <HCard data-testid="faturamento-overview-widget">
      <button
        onClick={onOpenFaturamento}
        data-testid="faturamento-widget-open"
        className="flex items-center justify-between w-full press-scale"
        style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
      >
        <div className="flex items-center gap-2">
          <TrendingUp size={16} style={{ color: '#1D9A64' }} />
          <p className="text-[13px] font-semibold text-h-text">{t('panel.faturamentoWidget.title')}</p>
        </div>
        <div className="flex items-center gap-1" style={{ color: '#AAA8A5' }}>
          <span className="text-[11px] font-semibold">{t('panel.faturamentoWidget.viewAll')}</span>
          <ChevronRight size={14} />
        </div>
      </button>

      <div className="mt-2">
        {isLoading ? (
          <SkeletonCard lines={2} />
        ) : hasError ? (
          <div className="flex items-center justify-between py-2">
            <p className="text-[12px] text-h-text-2">{t('panel.faturamentoWidget.errorLoad')}</p>
            <button
              onClick={handleRetry}
              className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
              style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
            >
              <RefreshCw size={14} />
              {t('panel.faturamentoWidget.retry')}
            </button>
          </div>
        ) : summary.sessionsCount === 0 ? (
          <p className="text-[12.5px] text-h-text-2 py-1">{t('panel.faturamentoWidget.empty')}</p>
        ) : (
          <div className="flex items-baseline justify-between py-1">
            <div>
              <p className="text-[17px] font-extrabold text-h-text" style={{ letterSpacing: '-0.01em' }}>
                {formatCurrency(summary.revenue, currency)}
              </p>
              <p className="text-[11px] text-h-text-3">{t('panel.faturamentoWidget.revenueThisMonth')}</p>
            </div>
            <div className="text-right">
              <p className="text-[13px] font-bold" style={{ color: '#1D9A64' }}>
                {t('panel.faturamentoWidget.marginPct', { pct: Math.round(summary.marginPct * 100) })}
              </p>
              <p className="text-[11px] text-h-text-3">{t('panel.faturamentoWidget.marginLabel')}</p>
            </div>
          </div>
        )}
      </div>
    </HCard>
  );
};

export default FaturamentoOverviewWidget;
