import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { Package, AlertTriangle, Clock, RefreshCw, CheckCircle2, ChevronRight } from 'lucide-react';
import HCard from '@/components/harmonize/HCard';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { normalizeInsumoStock, isLowStock } from '@/lib/stock';
import { normalizeStockBatches, batchesExpiringSoon } from '@/lib/stockBatches';

const EXPIRING_SOON_WINDOW_DAYS = 30;

/**
 * Widget compacto de estoque no dashboard do Painel (desktop) — vislumbre
 * de "o que precisa de atenção" sem abrir a aba "Estoque" completa. Usa as
 * MESMAS `queryKey`s (`stock-insumos`/`stock-batches`) e as mesmas funções
 * puras que EstoqueTab.tsx já usa, então compartilha o cache do React
 * Query em vez de duplicar a leitura das tabelas `insumos`/
 * `insumo_stock_batches`.
 *
 * Só desktop (ver `hidden md:block` em Painel.tsx): no mobile, a aba
 * "Estoque" já é um toque de distância pela barra de pílulas, então este
 * resumo entraria como peso extra de rolagem sem ganho real — mesma lógica
 * de "telas diferentes por tamanho de tela" aplicada ao resto do Painel.
 */
const EstoqueOverviewWidget: React.FC<{ onOpenEstoque: () => void }> = ({ onOpenEstoque }) => {
  const { user } = useAuth();
  const { t } = useTranslation();

  const {
    data: insumosRaw,
    isLoading: loadingInsumos,
    isError: insumosError,
    refetch: refetchInsumos,
  } = useQuery({
    queryKey: ['stock-insumos', user?.id],
    queryFn: () =>
      fetchAllRows((from, to) =>
        supabase
          .from('insumos')
          .select('id, substance, brand_name, active, quantity_on_hand, low_stock_threshold')
          .eq('professional_id', user!.id)
          .order('substance', { ascending: true })
          .order('brand_name', { ascending: true })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const {
    data: batchesRaw,
    isLoading: loadingBatches,
    isError: batchesError,
    refetch: refetchBatches,
  } = useQuery({
    queryKey: ['stock-batches', user?.id],
    queryFn: () =>
      fetchAllRows((from, to) =>
        supabase
          .from('insumo_stock_batches')
          .select('id, insumo_id, batch_number, expires_on, quantity_received, quantity_remaining, received_on')
          .eq('professional_id', user!.id)
          .range(from, to),
      ),
    enabled: !!user,
  });

  const isLoading = loadingInsumos || loadingBatches;
  const hasError = insumosError || batchesError;

  const lowStockCount = useMemo(() => {
    const insumos = normalizeInsumoStock(insumosRaw ?? []);
    return insumos.filter((i) => i.active && isLowStock(i.quantityOnHand, i.lowStockThreshold)).length;
  }, [insumosRaw]);

  const expiringSoonCount = useMemo(() => {
    const batches = normalizeStockBatches(batchesRaw ?? []).filter((b) => b.quantityRemaining > 0);
    return batchesExpiringSoon(batches, EXPIRING_SOON_WINDOW_DAYS).length;
  }, [batchesRaw]);

  const handleRetry = () => {
    refetchInsumos();
    refetchBatches();
  };

  return (
    <HCard data-testid="estoque-overview-widget">
      <button
        onClick={onOpenEstoque}
        data-testid="estoque-widget-open"
        className="flex items-center justify-between w-full press-scale"
        style={{ background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
      >
        <div className="flex items-center gap-2">
          <Package size={16} style={{ color: '#7C5AC2' }} />
          <p className="text-[13px] font-semibold text-h-text">{t('panel.estoqueWidget.title')}</p>
        </div>
        <div className="flex items-center gap-1" style={{ color: '#AAA8A5' }}>
          <span className="text-[11px] font-semibold">{t('panel.estoqueWidget.viewAll')}</span>
          <ChevronRight size={14} />
        </div>
      </button>

      <div className="mt-2">
        {isLoading ? (
          <SkeletonCard lines={2} />
        ) : hasError ? (
          <div className="flex items-center justify-between py-2">
            <p className="text-[12px] text-h-text-2">{t('panel.estoqueWidget.errorLoad')}</p>
            <button
              onClick={handleRetry}
              className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
              style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
            >
              <RefreshCw size={14} />
              {t('panel.estoqueWidget.retry')}
            </button>
          </div>
        ) : lowStockCount === 0 && expiringSoonCount === 0 ? (
          <div className="flex items-center gap-2 py-1">
            <CheckCircle2 size={14} style={{ color: '#2DB87A' }} />
            <p className="text-[12.5px] text-h-text-2">{t('panel.estoqueWidget.allGood')}</p>
          </div>
        ) : (
          <div className="flex flex-col gap-1.5 py-1">
            {lowStockCount > 0 && (
              <div className="flex items-center gap-2">
                <AlertTriangle size={13} style={{ color: '#D97706' }} />
                <p className="text-[12.5px] text-h-text-2">
                  {t('panel.estoqueWidget.lowStockCount', { count: lowStockCount })}
                </p>
              </div>
            )}
            {expiringSoonCount > 0 && (
              <div className="flex items-center gap-2">
                <Clock size={13} style={{ color: '#D97706' }} />
                <p className="text-[12.5px] text-h-text-2">
                  {t('panel.estoqueWidget.expiringSoonCount', { count: expiringSoonCount })}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </HCard>
  );
};

export default EstoqueOverviewWidget;
