import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import EstoqueTab from './EstoqueTab';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const insertSpy = vi.fn();
const batchInsertSpy = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom');
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/** Builder pra `insumos`: `.select().eq().order().order()` (lista). */
function createInsumosBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    // `.range()` — a tela agora pagina via fetchAllRows (teto de 1000 linhas
    // do PostgREST). Devolve a lista inteira de qualquer forma: nenhum teste
    // aqui tem 1000+ linhas, então a primeira página já é a última.
    range: () => builder,
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

/**
 * Builder genérico pra qualquer tabela lida com `.select().eq()...` (lista) —
 * usado tanto pra `insumo_stock_batches` quanto, por padrão vazio, pelas 3
 * tabelas que StockForecastSection busca (`treatment_plans`,
 * `treatment_plan_steps`, `sessions`). Inclui `.gte()` na cadeia (usado pela
 * query de `sessions`) além de `.select()`/`.eq()`.
 */
function createBatchesBuilder(rows: unknown[] = []) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    gte: () => builder,
    range: () => builder,
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

/** Builder pra `insumo_stock_batches` no fluxo de INSERT (registrar lote na entrada). */
function createBatchesInsertBuilder() {
  return {
    insert: (payload: Record<string, unknown>) => {
      batchInsertSpy(payload);
      return {
        select: () => ({
          single: () => Promise.resolve({ data: { id: 'batch-new-1' }, error: null }),
        }),
      };
    },
  };
}

/** Builder pra `insumo_stock_movements`: só o insert usado ao registrar entrada/saída. */
function createMovementsBuilder() {
  return {
    insert: (payload: Record<string, unknown>) => {
      insertSpy(payload);
      return Promise.resolve({ error: null });
    },
  };
}

const renderTab = () =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <MemoryRouter>
        <EstoqueTab />
      </MemoryRouter>
    </QueryClientProvider>,
  );

describe('EstoqueTab', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
    navigateMock.mockReset();
    insertSpy.mockReset();
    batchInsertSpy.mockReset();
  });

  it('shows the empty state with a link to register supplies when there are none', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') return createInsumosBuilder([]);
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    expect(await screen.findByText('Nenhum insumo cadastrado ainda.')).toBeInTheDocument();

    fireEvent.click(screen.getByText('Cadastrar insumos'));
    expect(navigateMock).toHaveBeenCalledWith('/perfil/insumos');
  });

  it('lists insumos grouped by substance with their current balance and unit', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 8, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    expect(await screen.findByText('Juvederm Voluma')).toBeInTheDocument();
    expect(screen.getByText('8 ml')).toBeInTheDocument();
  });

  it('highlights a zeroed-out balance as out of stock when no threshold is configured', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'toxina_botulinica', brand_name: 'Dysport', active: true, quantity_on_hand: 0, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    expect(await screen.findByTestId('stock-low-ins-1')).toHaveTextContent('Sem estoque');
  });

  it('highlights a balance at or below a configured threshold as low stock (not out of stock)', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'bioestimulador', brand_name: 'Sculptra', active: true, quantity_on_hand: 2, low_stock_threshold: 3 },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    expect(await screen.findByTestId('stock-low-ins-1')).toHaveTextContent('Estoque baixo');
  });

  it('registers a stock-in movement with a positive delta', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 5, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      if (table === 'insumo_stock_movements') return createMovementsBuilder();
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('Juvederm Voluma');

    fireEvent.click(screen.getByLabelText('Entrada'));
    fireEvent.change(screen.getByLabelText('Quantidade'), { target: { value: '4' } });
    fireEvent.click(screen.getByText('Confirmar'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({
      insumo_id: 'ins-1',
      professional_id: 'pro-1',
      quantity_delta: 4,
    });
    // Sem número de lote informado, nenhum lote é criado — comportamento
    // idêntico à V1 mini que não sabe de lote/validade.
    expect(batchInsertSpy).not.toHaveBeenCalled();
  });

  it('registers a stock-out movement with a negative delta', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 5, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      if (table === 'insumo_stock_movements') return createMovementsBuilder();
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('Juvederm Voluma');

    fireEvent.click(screen.getByLabelText('Saída'));
    fireEvent.change(screen.getByLabelText('Quantidade'), { target: { value: '2' } });
    fireEvent.click(screen.getByText('Confirmar'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({ quantity_delta: -2 });
  });

  it('rejects a zero or negative quantity instead of registering a bogus movement', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 5, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesBuilder([]);
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('Juvederm Voluma');

    fireEvent.click(screen.getByLabelText('Entrada'));
    fireEvent.change(screen.getByLabelText('Quantidade'), { target: { value: '0' } });
    fireEvent.click(screen.getByText('Confirmar'));

    await waitFor(() => expect(insertSpy).not.toHaveBeenCalled());
  });

  it('creates a batch and links it to the movement when a lot number is provided on stock-in', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 5, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') return createBatchesInsertBuilder();
      if (table === 'insumo_stock_movements') return createMovementsBuilder();
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('Juvederm Voluma');

    fireEvent.click(screen.getByLabelText('Entrada'));
    fireEvent.change(screen.getByLabelText('Quantidade'), { target: { value: '10' } });
    fireEvent.change(screen.getByLabelText('Número do lote (opcional)'), { target: { value: 'L2026-01' } });
    fireEvent.change(screen.getByLabelText('Validade (opcional)'), { target: { value: '2026-12-31' } });
    fireEvent.click(screen.getByText('Confirmar'));

    await waitFor(() => expect(batchInsertSpy).toHaveBeenCalledTimes(1));
    expect(batchInsertSpy.mock.calls[0][0]).toMatchObject({
      insumo_id: 'ins-1',
      professional_id: 'pro-1',
      batch_number: 'L2026-01',
      expires_on: '2026-12-31',
      quantity_received: 10,
    });
    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({ batch_id: 'batch-new-1', quantity_delta: 10 });
  });

  it('shows the expiring-soon banner and a per-insumo badge for a batch expiring within 30 days', async () => {
    const inTwoWeeks = new Date();
    inTwoWeeks.setDate(inTwoWeeks.getDate() + 14);
    const expiresOn = inTwoWeeks.toISOString().slice(0, 10);

    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 5, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') {
        return createBatchesBuilder([
          {
            id: 'batch-1',
            insumo_id: 'ins-1',
            batch_number: 'L2026-01',
            expires_on: expiresOn,
            quantity_received: 10,
            quantity_remaining: 6,
            received_on: '2026-01-01',
          },
        ]);
      }
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    expect(await screen.findByText('Lotes vencendo em breve')).toBeInTheDocument();
    expect(screen.getByTestId('stock-expiring-batch-1')).toHaveTextContent('Juvederm Voluma');
    expect(screen.getByTestId('stock-expiring-batch-1')).toHaveTextContent('lote L2026-01');
    expect(screen.getByTestId('stock-expiring-badge-ins-1')).toBeInTheDocument();
  });

  it('does not show the expiring-soon banner when no batch is close to expiry', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'insumos') {
        return createInsumosBuilder([
          { id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', active: true, quantity_on_hand: 5, low_stock_threshold: null },
        ]);
      }
      if (table === 'insumo_stock_batches') {
        return createBatchesBuilder([
          {
            id: 'batch-1',
            insumo_id: 'ins-1',
            batch_number: 'L2026-01',
            expires_on: '2030-01-01',
            quantity_received: 10,
            quantity_remaining: 6,
            received_on: '2026-01-01',
          },
        ]);
      }
      // StockForecastSection (renderizada dentro de EstoqueTab) busca essas 3
      // tabelas por conta própria — vazias por padrão em todo teste que não
      // exercita a previsão de estoque especificamente (ver
      // StockForecastSection.test.tsx).
      if (table === 'treatment_plans') return createBatchesBuilder([]);
      if (table === 'treatment_plan_steps') return createBatchesBuilder([]);
      if (table === 'sessions') return createBatchesBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('Juvederm Voluma');
    expect(screen.queryByText('Lotes vencendo em breve')).not.toBeInTheDocument();
    expect(screen.queryByTestId('stock-expiring-badge-ins-1')).not.toBeInTheDocument();
  });
});
