import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import FaturamentoOverviewWidget from './FaturamentoOverviewWidget';
import i18n from '@/i18n';
import { createQueryBuilder } from '@/test/supabaseMock';

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

function renderWidget(sessions: unknown[], onOpenFaturamento = vi.fn()) {
  useAuthMock.mockReturnValue({ user: { id: 'prof-1' } });
  fromMock.mockImplementation((table: string) => {
    if (table === 'profiles') {
      return createQueryBuilder({ data: [] }, { data: { labor_fee_per_session: 0, currency: 'BRL' } });
    }
    if (table === 'insumos') {
      return createQueryBuilder({
        data: [{ id: 'ins1', substance: 'acido_hialuronico', brand_name: 'X', cost_per_unit: 100, price_per_unit: 400, active: true }],
      });
    }
    if (table === 'sessions') return createQueryBuilder({ data: sessions });
    throw new Error(`unexpected table ${table}`);
  });
  render(
    <QueryClientProvider client={new QueryClient()}>
      <FaturamentoOverviewWidget onOpenFaturamento={onOpenFaturamento} />
    </QueryClientProvider>,
  );
  return { onOpenFaturamento };
}

describe('FaturamentoOverviewWidget', () => {
  it('shows an empty state when there are no completed sessions this month', async () => {
    renderWidget([]);
    await waitFor(() => expect(screen.getByText(i18n.t('panel.faturamentoWidget.empty'))).toBeInTheDocument());
  });

  it('shows revenue and margin for completed sessions this month', async () => {
    renderWidget([
      {
        created_at: new Date().toISOString(),
        status: 'complete',
        stage2_overlay: [{ id: 'p1', region: 'labio_superior', substance: 'acido_hialuronico', quantity: 1, unit: 'ml', x: 0.5, y: 0.5, source: 'manual' }],
      },
    ]);
    await waitFor(() => expect(screen.getByText(i18n.t('panel.faturamentoWidget.revenueThisMonth'))).toBeInTheDocument());
    expect(screen.getByText(i18n.t('panel.faturamentoWidget.marginLabel'))).toBeInTheDocument();
  });

  it('calls onOpenFaturamento when the header is clicked', async () => {
    const { onOpenFaturamento } = renderWidget([]);
    await waitFor(() => expect(screen.getByText(i18n.t('panel.faturamentoWidget.empty'))).toBeInTheDocument());
    fireEvent.click(screen.getByTestId('faturamento-widget-open'));
    expect(onOpenFaturamento).toHaveBeenCalledTimes(1);
  });
});
