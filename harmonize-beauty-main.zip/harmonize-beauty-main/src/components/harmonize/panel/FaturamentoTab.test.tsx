import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import FaturamentoTab from './FaturamentoTab';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

/** Builder pra `profiles`: `.select().eq().single()`. */
function createProfileBuilder(row: Record<string, unknown>) {
  return {
    select: () => ({
      eq: () => ({
        single: () => Promise.resolve({ data: row, error: null }),
      }),
    }),
  };
}

/** Builder pra `insumos`/`sessions`: `.select().eq()[.gte()]` thenable. */
function createListBuilder(rows: unknown[]) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    gte: () => builder,
    // `.range()` — `sessions` agora pagina via fetchAllRows (teto de 1000
    // linhas do PostgREST). Devolve a lista inteira: nenhum teste aqui tem
    // 1000+ linhas.
    range: () => builder,
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: rows, error: null }).then(onFulfilled),
  };
  return builder;
}

const renderTab = () =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <FaturamentoTab />
    </QueryClientProvider>,
  );

describe('FaturamentoTab', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
  });

  it('shows the empty state when there are no closed sessions this month', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'profiles') return createProfileBuilder({ labor_fee_per_session: null, currency: 'BRL' });
      if (table === 'insumos') return createListBuilder([]);
      if (table === 'sessions') return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    expect(await screen.findByText('Nenhuma sessão concluída este mês ainda.')).toBeInTheDocument();
  });

  it('aggregates revenue, margin, average ticket and the most profitable substance from closed sessions only', async () => {
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 10).toISOString();

    fromMock.mockImplementation((table: string) => {
      if (table === 'profiles') return createProfileBuilder({ labor_fee_per_session: null, currency: 'BRL' });
      if (table === 'insumos') {
        return createListBuilder([
          { id: 'ins-ha', substance: 'acido_hialuronico', brand_name: 'Juvederm Voluma', cost_per_unit: 400, price_per_unit: 1500, active: true },
        ]);
      }
      if (table === 'sessions') {
        return createListBuilder([
          {
            created_at: thisMonth,
            status: 'complete',
            stage2_overlay: [
              { id: 'p1', region: 'malar_direita', label: 'Malar Direita', substance: 'acido_hialuronico', quantity: 1, unit: 'ml', x: 0.5, y: 0.5, source: 'manual', insumoId: 'ins-ha' },
            ],
          },
          {
            // sessão não concluída — não deve entrar na soma
            created_at: thisMonth,
            status: 'stage2',
            stage2_overlay: [
              { id: 'p2', region: 'malar_esquerda', label: 'Malar Esquerda', substance: 'acido_hialuronico', quantity: 5, unit: 'ml', x: 0.5, y: 0.5, source: 'manual', insumoId: 'ins-ha' },
            ],
          },
        ]);
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();

    // Receita do mês e ticket médio coincidem (uma única sessão concluída) — duas ocorrências do mesmo valor.
    expect(await screen.findAllByText('R$ 1.500,00')).toHaveLength(2);
    // Margem do card de resumo e margem da única substância do ranking também coincidem aqui (1500 - 400).
    expect(screen.getAllByText('R$ 1.100,00')).toHaveLength(2);
    expect(screen.getByText('Margem (73%)')).toBeInTheDocument();
    expect(screen.getByText('Ácido Hialurônico')).toBeInTheDocument();
  });
});
