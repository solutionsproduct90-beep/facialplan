import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent, within, act } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AgendaTab from './AgendaTab';
import i18n from '@/i18n';
import { createRangeSlicer } from '@/test/supabaseMock';

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const insertSpy = vi.fn();
const updateSpy = vi.fn();
const deleteSpy = vi.fn();

// `toast(...)` chamável (o toast de sugestão de fila, com `action`) precisa
// de uma referência acessível tanto pela factory de `vi.mock` quanto pelos
// próprios testes (pra inspecionar a mensagem e disparar `action.onClick`) —
// por isso `vi.hoisted`, diferente de `toast.success`/`toast.error` (usados
// só internamente pelo componente, nunca verificados nos testes existentes).
const { toastMock } = vi.hoisted(() => {
  const fn = Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn() });
  return { toastMock: fn };
});

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

vi.mock('sonner', () => ({
  toast: toastMock,
}));

/** Builder pra `appointments`: `.select().eq().order()` (lista) + insert/update/delete. */
function createAppointmentsBuilder(rows: unknown[]) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
    insert: (payload: Record<string, unknown>) => {
      insertSpy(payload);
      return Promise.resolve({ error: null });
    },
    update: (payload: Record<string, unknown>) => {
      updateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
    delete: () => {
      deleteSpy();
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
  return builder;
}

/** Builder pra `patients`: só o `.select().eq().eq().order()` usado pro dropdown. */
function createPatientsBuilder(rows: unknown[]) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
  };
  return builder;
}

const waitlistInsertSpy = vi.fn();
const waitlistDeleteSpy = vi.fn();
const waitlistUpdateSpy = vi.fn();

/** Builder pra `appointment_waitlist`: `.select().eq().order()` (lista) + insert/update/delete. */
function createWaitlistBuilder(rows: unknown[]) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
    insert: (payload: Record<string, unknown>) => {
      waitlistInsertSpy(payload);
      return Promise.resolve({ error: null });
    },
    update: (payload: Record<string, unknown>) => {
      waitlistUpdateSpy(payload);
      // Encadeia `.eq()` quantas vezes for chamado (handleOfferSlot faz
      // `.eq('id', ...).eq('status', 'waiting')`) e é thenable direto
      // (resolve pra `{ error: null }`, sem `data`) OU aceita um `.select()`
      // final que resolve com `data` — handleOfferSlot usa esse `data` pra
      // saber se a linha ainda estava 'waiting'.
      const updateBuilder: any = {
        eq: () => updateBuilder,
        select: () => Promise.resolve({ data: [{ id: 'row' }], error: null }),
        then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ error: null }).then(onFulfilled),
      };
      return updateBuilder;
    },
    delete: () => {
      waitlistDeleteSpy();
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
  return builder;
}

const renderTab = () =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <AgendaTab />
    </QueryClientProvider>,
  );

describe('AgendaTab', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
    insertSpy.mockReset();
    updateSpy.mockReset();
    deleteSpy.mockReset();
    waitlistInsertSpy.mockReset();
    waitlistUpdateSpy.mockReset();
    waitlistDeleteSpy.mockReset();
    toastMock.mockReset();
    toastMock.success.mockReset();
    toastMock.error.mockReset();
  });

  it('shows the empty state with a call to action when there are no appointments', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') return createAppointmentsBuilder([]);
      if (table === 'patients') return createPatientsBuilder([]);
      if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();

    expect(await screen.findByText('Nenhum compromisso agendado ainda.')).toBeInTheDocument();
  });

  it('lists appointments grouped by day, showing the linked patient or "no patient" copy', async () => {
    const scheduledAt = new Date(2026, 8, 20, 14, 30).toISOString();
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') {
        return createAppointmentsBuilder([
          {
            id: 'a1',
            patient_id: 'p1',
            note: 'Retorno de avaliação',
            scheduled_at: scheduledAt,
            duration_minutes: 30,
            status: 'agendado',
            patient: { name: 'Maria Silva' },
          },
          {
            id: 'a2',
            patient_id: null,
            note: null,
            scheduled_at: new Date(2026, 8, 21, 9, 0).toISOString(),
            duration_minutes: null,
            status: 'agendado',
            patient: null,
          },
        ]);
      }
      if (table === 'patients') return createPatientsBuilder([{ id: 'p1', name: 'Maria Silva' }]);
      if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();

    expect(await screen.findByText('Maria Silva')).toBeInTheDocument();
    expect(screen.getByText('Sem paciente vinculado')).toBeInTheDocument();
    expect(screen.getByText('14:30')).toBeInTheDocument();
  });

  it('creates a new appointment tied to the professional, with no patient selected by default', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') return createAppointmentsBuilder([]);
      if (table === 'patients') return createPatientsBuilder([{ id: 'p1', name: 'Maria Silva' }]);
      if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('Nenhum compromisso agendado ainda.');

    fireEvent.click(screen.getByTestId('agenda-add-new'));
    fireEvent.change(screen.getByLabelText('Data'), { target: { value: '2026-09-20' } });
    fireEvent.change(screen.getByLabelText('Hora'), { target: { value: '15:00' } });
    fireEvent.click(screen.getByText('Salvar'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0];
    expect(payload).toMatchObject({ professional_id: 'pro-1', patient_id: null, note: null });
    expect(new Date(payload.scheduled_at).toISOString()).toBe(new Date(2026, 8, 20, 15, 0).toISOString());
  });

  it('marks an appointment as completed from the quick action, without opening the edit sheet', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') {
        return createAppointmentsBuilder([
          {
            id: 'a1',
            patient_id: null,
            note: null,
            scheduled_at: new Date(2026, 8, 20, 14, 30).toISOString(),
            duration_minutes: null,
            status: 'agendado',
            patient: null,
          },
        ]);
      }
      if (table === 'patients') return createPatientsBuilder([]);
      if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    await screen.findByText('14:30');

    fireEvent.click(screen.getByLabelText('Concluir'));

    await waitFor(() => expect(updateSpy).toHaveBeenCalledWith({ status: 'concluido' }));
  });

  it('deletes an appointment from the edit sheet', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') {
        return createAppointmentsBuilder([
          {
            id: 'a1',
            patient_id: null,
            note: 'Nota',
            scheduled_at: new Date(2026, 8, 20, 14, 30).toISOString(),
            duration_minutes: null,
            status: 'agendado',
            patient: null,
          },
        ]);
      }
      if (table === 'patients') return createPatientsBuilder([]);
      if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderTab();
    fireEvent.click(await screen.findByTestId('agenda-item-a1'));
    fireEvent.click(await screen.findByText('Excluir'));

    await waitFor(() => expect(deleteSpy).toHaveBeenCalledTimes(1));
  });

  describe('fila de espera', () => {
    it('shows the empty state for the waitlist when there are no entries', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') return createAppointmentsBuilder([]);
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();

      expect(await screen.findByText('Nenhum paciente na fila de espera.')).toBeInTheDocument();
    });

    it('adds a patient to the waitlist for the professional, with the chosen desired period', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') return createAppointmentsBuilder([]);
        if (table === 'patients') return createPatientsBuilder([{ id: 'p1', name: 'Maria Silva' }]);
        if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();
      await screen.findByText('Nenhum paciente na fila de espera.');

      fireEvent.click(screen.getByTestId('waitlist-add-new'));
      fireEvent.change(screen.getByLabelText('Paciente'), { target: { value: 'p1' } });
      fireEvent.change(screen.getByLabelText('A partir de'), { target: { value: '2026-09-14' } });
      fireEvent.change(screen.getByLabelText('Até'), { target: { value: '2026-09-20' } });
      fireEvent.click(screen.getByText('Adicionar à fila'));

      await waitFor(() => expect(waitlistInsertSpy).toHaveBeenCalledTimes(1));
      expect(waitlistInsertSpy).toHaveBeenCalledWith({
        professional_id: 'pro-1',
        patient_id: 'p1',
        desired_start_date: '2026-09-14',
        desired_end_date: '2026-09-20',
      });
    });

    it('rejects adding to the waitlist without a selected patient', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') return createAppointmentsBuilder([]);
        if (table === 'patients') return createPatientsBuilder([{ id: 'p1', name: 'Maria Silva' }]);
        if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();
      await screen.findByText('Nenhum paciente na fila de espera.');

      fireEvent.click(screen.getByTestId('waitlist-add-new'));
      fireEvent.click(screen.getByText('Adicionar à fila'));

      await waitFor(() => expect(toastMock.error).toHaveBeenCalledWith('Selecione um paciente.'));
      expect(waitlistInsertSpy).not.toHaveBeenCalled();
    });

    it('lists a waitlist entry with the linked patient and desired period', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') return createAppointmentsBuilder([]);
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') {
          return createWaitlistBuilder([
            {
              id: 'w1',
              patient_id: 'p1',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'waiting',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Maria Silva', phone: '5511999998888' },
            },
          ]);
        }
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();

      expect(await screen.findByTestId('waitlist-remove-w1')).toBeInTheDocument();
      expect(screen.getByText('Maria Silva')).toBeInTheDocument();
      expect(screen.getByText('2026-09-14 – 2026-09-20')).toBeInTheDocument();
    });

    it('removes a waitlist entry', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') return createAppointmentsBuilder([]);
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') {
          return createWaitlistBuilder([
            {
              id: 'w1',
              patient_id: 'p1',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'waiting',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Maria Silva', phone: '5511999998888' },
            },
          ]);
        }
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();
      fireEvent.click(await screen.findByTestId('waitlist-remove-w1'));

      await waitFor(() => expect(waitlistDeleteSpy).toHaveBeenCalledTimes(1));
    });

    it('suggests waitlist candidates, in queue arrival order, when a covering appointment is cancelled', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') {
          return createAppointmentsBuilder([
            {
              id: 'a1',
              patient_id: null,
              note: null,
              scheduled_at: new Date(2026, 8, 18, 14, 30).toISOString(),
              duration_minutes: null,
              status: 'agendado',
              patient: null,
            },
          ]);
        }
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') {
          return createWaitlistBuilder([
            {
              id: 'later',
              patient_id: 'p2',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'waiting',
              created_at: '2026-09-05T00:00:00.000Z',
              patient: { name: 'Segundo Paciente', phone: '5511999990002' },
            },
            {
              id: 'earliest',
              patient_id: 'p1',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'waiting',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Primeiro Paciente', phone: '5511999990001' },
            },
            {
              id: 'out-of-range',
              patient_id: 'p3',
              desired_start_date: '2026-10-01',
              desired_end_date: '2026-10-05',
              status: 'waiting',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Fora do período', phone: '5511999990003' },
            },
          ]);
        }
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();
      await screen.findByText('14:30');

      fireEvent.click(screen.getByLabelText('Cancelar'));
      await waitFor(() => expect(updateSpy).toHaveBeenCalledWith({ status: 'cancelado' }));

      await waitFor(() =>
        expect(toastMock).toHaveBeenCalledWith(
          '2 pacientes na fila de espera podem querer este horário.',
          expect.objectContaining({ action: expect.objectContaining({ label: 'Ver fila' }) }),
        ),
      );

      // Abre a sheet de candidatos pela mesma ação do toast — mostra só os
      // dois candidatos cujo período cobre o dia liberado (18/09), na ordem
      // de chegada na fila (earliest antes de later), sem o "fora do
      // período".
      const [, options] = toastMock.mock.calls[0];
      act(() => options.action.onClick());

      // Escopado ao dialog da sheet de candidatos (não à lista geral da fila
      // logo abaixo dos compromissos, que também mostra os três nomes) —
      // só ali importa a ordem de chegada e o corte por período.
      const dialog = await screen.findByRole('dialog');
      const offerButtons = within(dialog).getAllByText('Oferecer este horário');
      expect(offerButtons).toHaveLength(2);
      const names = within(dialog).getAllByText(/Primeiro Paciente|Segundo Paciente|Fora do período/);
      expect(names.map((el) => el.textContent)).toEqual(['Primeiro Paciente', 'Segundo Paciente']);
    });

    it('does not suggest anything when cancelling a slot with no matching waitlist entries', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') {
          return createAppointmentsBuilder([
            {
              id: 'a1',
              patient_id: null,
              note: null,
              scheduled_at: new Date(2026, 8, 18, 14, 30).toISOString(),
              duration_minutes: null,
              status: 'agendado',
              patient: null,
            },
          ]);
        }
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') return createWaitlistBuilder([]);
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();
      await screen.findByText('14:30');

      fireEvent.click(screen.getByLabelText('Cancelar'));
      await waitFor(() => expect(updateSpy).toHaveBeenCalledWith({ status: 'cancelado' }));

      expect(toastMock).not.toHaveBeenCalled();
    });

    it('sends the WhatsApp offer and marks the waitlist entry as offered when "Oferecer este horário" is clicked', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') {
          return createAppointmentsBuilder([
            {
              id: 'a1',
              patient_id: null,
              note: null,
              scheduled_at: new Date(2026, 8, 18, 14, 30).toISOString(),
              duration_minutes: null,
              status: 'agendado',
              patient: null,
            },
          ]);
        }
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') {
          return createWaitlistBuilder([
            {
              id: 'w1',
              patient_id: 'p1',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'waiting',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Maria Silva', phone: '5511999998888' },
            },
          ]);
        }
        throw new Error(`unexpected table ${table}`);
      });
      const openSpy = vi.spyOn(window, 'open').mockReturnValue({} as Window);

      renderTab();
      await screen.findByText('14:30');

      fireEvent.click(screen.getByLabelText('Cancelar'));
      await waitFor(() => expect(toastMock).toHaveBeenCalled());

      const [, options] = toastMock.mock.calls[0];
      act(() => options.action.onClick());

      fireEvent.click(await screen.findByTestId('waitlist-offer-w1'));

      await waitFor(() => expect(openSpy).toHaveBeenCalledTimes(1));
      const [waLink] = openSpy.mock.calls[0];
      expect(waLink).toContain('https://wa.me/5511999998888');
      expect(decodeURIComponent(String(waLink))).toContain('Maria Silva');

      await waitFor(() => expect(waitlistUpdateSpy).toHaveBeenCalledWith({ status: 'offered' }));
      await waitFor(() => expect(toastMock.success).toHaveBeenCalledWith('Oferta enviada!'));

      openSpy.mockRestore();
    });

    it('warns and does NOT mark the entry as offered when the WhatsApp popup is blocked by the browser', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') {
          return createAppointmentsBuilder([
            {
              id: 'a1',
              patient_id: null,
              note: null,
              scheduled_at: new Date(2026, 8, 18, 14, 30).toISOString(),
              duration_minutes: null,
              status: 'agendado',
              patient: null,
            },
          ]);
        }
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') {
          return createWaitlistBuilder([
            {
              id: 'w1',
              patient_id: 'p1',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'waiting',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Maria Silva', phone: '5511999998888' },
            },
          ]);
        }
        throw new Error(`unexpected table ${table}`);
      });
      // Simula popup bloqueado pelo navegador — window.open devolve null.
      const openSpy = vi.spyOn(window, 'open').mockReturnValue(null);

      renderTab();
      await screen.findByText('14:30');

      fireEvent.click(screen.getByLabelText('Cancelar'));
      await waitFor(() => expect(toastMock).toHaveBeenCalled());

      const [, options] = toastMock.mock.calls[0];
      act(() => options.action.onClick());

      fireEvent.click(await screen.findByTestId('waitlist-offer-w1'));

      await waitFor(() => expect(openSpy).toHaveBeenCalledTimes(1));
      await waitFor(() =>
        expect(toastMock.error).toHaveBeenCalledWith(
          'O navegador bloqueou a janela do WhatsApp. Verifique as permissões de pop-up e tente novamente.',
        ),
      );
      // Sem UPDATE nenhum na fila: a entrada continua 'waiting', pra poder
      // tentar de novo (a chamada de `toastMock.success` vista aqui é a do
      // cancelamento do compromisso em si, não relacionada à oferta).
      expect(waitlistUpdateSpy).not.toHaveBeenCalled();
      expect(toastMock.success).not.toHaveBeenCalledWith('Oferta enviada!');

      openSpy.mockRestore();
    });

    it('lets the professional move an already-offered entry back to the waitlist', async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'appointments') return createAppointmentsBuilder([]);
        if (table === 'patients') return createPatientsBuilder([]);
        if (table === 'appointment_waitlist') {
          return createWaitlistBuilder([
            {
              id: 'w1',
              patient_id: 'p1',
              desired_start_date: '2026-09-14',
              desired_end_date: '2026-09-20',
              status: 'offered',
              created_at: '2026-09-01T00:00:00.000Z',
              patient: { name: 'Maria Silva', phone: '5511999998888' },
            },
          ]);
        }
        throw new Error(`unexpected table ${table}`);
      });

      renderTab();
      fireEvent.click(await screen.findByTestId('waitlist-back-to-waiting-w1'));

      await waitFor(() => expect(waitlistUpdateSpy).toHaveBeenCalledWith({ status: 'waiting' }));
      await waitFor(() =>
        expect(toastMock.success).toHaveBeenCalledWith('Paciente voltou pra fila de espera.'),
      );
    });
  });
});
