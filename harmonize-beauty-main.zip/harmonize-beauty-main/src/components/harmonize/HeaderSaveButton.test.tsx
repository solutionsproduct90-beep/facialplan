import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import HeaderSaveButton from "./HeaderSaveButton";
import i18n from "@/i18n";

describe("HeaderSaveButton", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
  });

  it("renders as a solid gradient pill, not a plain text link", () => {
    render(<HeaderSaveButton onClick={() => {}} saving={false} />);
    const button = screen.getByRole("button", { name: "Salvar" });
    // O bug reportado era o botão ser "quase invisível" (texto rosa pequeno
    // sem fundo). Garante que a versão nova tem fundo sólido da marca.
    expect(button).toHaveClass("bg-gradient-brand");
    // Sobrescreve a largura/altura cheias do GradientButton (que preenche o
    // BottomSheet) via `!important` — cabe ao lado do título no header.
    expect(button).toHaveClass("!w-auto");
  });

  it("shows the saving label and disables itself while saving", () => {
    render(<HeaderSaveButton onClick={() => {}} saving />);
    const button = screen.getByRole("button", { name: "Salvando..." });
    expect(button).toBeDisabled();
  });

  it("fires onClick when tapped", () => {
    const onClick = vi.fn();
    render(<HeaderSaveButton onClick={onClick} saving={false} />);
    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("respects an explicit disabled prop even when not saving", () => {
    render(<HeaderSaveButton onClick={() => {}} saving={false} disabled />);
    expect(screen.getByRole("button", { name: "Salvar" })).toBeDisabled();
  });
});
