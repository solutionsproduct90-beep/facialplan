import React from 'react';
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import i18n from '@/i18n';
import AuthInput from './AuthInput';
import AuthSelect from './AuthSelect';
import PhoneField from './PhoneField';

// Trava a associação entre rótulo e controle nos três campos de formulário do
// app.
//
// O QUE ESTAVA ERRADO (ciclo 56 do QA Contínuo): nos três, o <label> e o
// controle eram irmãos dentro de uma <div>, sem `htmlFor`, sem `id` e sem
// aninhamento — nenhuma associação, nem explícita nem implícita. Quem usa
// leitor de tela focava o campo e não ouvia qual campo era; o rótulo era lido
// solto, antes, sem vínculo. Em Login e Cadastro, com dois campos seguidos,
// isso significa não conseguir distinguir e-mail de senha.
//
// POR QUE ESTES CASOS USAM getByLabelText E NÃO getByPlaceholderText:
// `getByLabelText` resolve o nome acessível pelo mesmo algoritmo que NVDA,
// VoiceOver e TalkBack usam. Um teste que buscasse por placeholder passaria
// com os campos exatamente tão inacessíveis quanto antes — foi assim que o
// defeito sobreviveu à suíte até aqui. Estes casos falham se a associação
// sumir, que é a única coisa que eles precisam fazer.
describe('associação de rótulo nos campos de formulário', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
  });

  it('AuthInput: o rótulo nomeia o campo', () => {
    render(<AuthInput label="E-mail" type="email" />);
    expect(screen.getByLabelText('E-mail')).toHaveAttribute('type', 'email');
  });

  it('AuthInput: dois campos na mesma tela não se confundem', () => {
    // O caso que motivou o achado: Login tem e-mail e senha em sequência.
    render(
      <>
        <AuthInput label="E-mail" type="email" />
        <AuthInput label="Senha" type="password" />
      </>,
    );

    expect(screen.getByLabelText('E-mail')).toHaveAttribute('type', 'email');
    expect(screen.getByLabelText('Senha')).toHaveAttribute('type', 'password');
  });

  it('AuthInput: ids gerados são únicos por instância', () => {
    // Dois campos com o MESMO rótulo continuam sendo dois campos. Se o id
    // fosse constante, o rótulo do segundo apontaria para o primeiro.
    render(
      <>
        <AuthInput label="Telefone" />
        <AuthInput label="Telefone" />
      </>,
    );

    const campos = screen.getAllByLabelText('Telefone');
    expect(campos).toHaveLength(2);
    expect(campos[0].id).not.toBe(campos[1].id);
  });

  it('AuthInput: um id vindo por props vence, e o rótulo acompanha', () => {
    render(<AuthInput label="E-mail" id="email-customizado" />);

    const campo = screen.getByLabelText('E-mail');
    expect(campo.id).toBe('email-customizado');
  });

  it('AuthSelect: o gatilho é nomeado pelo rótulo', () => {
    // Aqui o controle é um <button> que abre uma folha, então a associação é
    // por aria-labelledby em vez de htmlFor.
    render(
      <AuthSelect
        label="País"
        options={[{ value: 'br', label: 'Brasil' }]}
        value="br"
        onChange={() => {}}
      />,
    );

    expect(screen.getByLabelText('País')).toBeInTheDocument();
  });

  it('PhoneField: o rótulo nomeia o campo do número', () => {
    // O rótulo aponta para o campo do número; o seletor de DDI ao lado tem
    // nome próprio pelo `title` do SheetSelect. Nomear também um grupo por
    // cima daria ao grupo e ao campo o MESMO nome, que é ambíguo para quem
    // ouve — foi a primeira tentativa e este caso pegou.
    render(
      <PhoneField
        label="Telefone"
        dial="+55"
        local="11999999999"
        customDial=""
        onDialChange={() => {}}
        onLocalChange={() => {}}
        onCustomDialChange={() => {}}
      />,
    );

    const campo = screen.getByLabelText('Telefone');
    expect(campo).toHaveAttribute('type', 'tel');
    // Um nome acessível só: nem o container nem o seletor de DDI podem
    // responder por "Telefone" também.
    expect(screen.getAllByLabelText('Telefone')).toHaveLength(1);
  });
});
