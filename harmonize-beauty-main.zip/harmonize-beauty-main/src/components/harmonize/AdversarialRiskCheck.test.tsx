import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import AdversarialRiskCheck from './AdversarialRiskCheck';
import type { AdversarialRiskCheckRequest, AdversarialRiskCheckResult } from '@/lib/adversarialRiskCheck';
import i18n from '@/i18n';

const requestAdversarialRiskCheckMock = vi.fn<
  (request: AdversarialRiskCheckRequest) => Promise<AdversarialRiskCheckResult>
>();

vi.mock('@/lib/adversarialRiskCheck', async () => {
  const actual = await vi.importActual<typeof import('@/lib/adversarialRiskCheck')>(
    '@/lib/adversarialRiskCheck'
  );
  return {
    ...actual,
    requestAdversarialRiskCheck: (request: AdversarialRiskCheckRequest) =>
      requestAdversarialRiskCheckMock(request),
  };
});

const SAMPLE_REQUEST: AdversarialRiskCheckRequest = {
  type: 'dose_threshold',
  // `patientId` passou a ser obrigatório com o gate de consentimento no
  // servidor (squad w1-3, ver supabase/functions/_shared/consentGate.ts).
  patientId: 'pat-1',
  doseThreshold: {
    overages: [
      {
        substance: 'toxina_botulinica',
        total: 120,
        unit: 'unidades',
        threshold: 100,
        points: [{ region: 'glabela', quantity: 120 }],
      },
    ],
    isFirstSession: false,
  },
};

/** Deferred promise so tests can control exactly when the "AI response" arrives. */
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => {
    resolve = r;
  });
  return { promise, resolve };
}

describe('AdversarialRiskCheck', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    requestAdversarialRiskCheckMock.mockReset();
  });

  it('renders nothing when inactive', () => {
    render(<AdversarialRiskCheck active={false} request={SAMPLE_REQUEST} />);
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();
    expect(requestAdversarialRiskCheckMock).not.toHaveBeenCalled();
  });

  it('renders nothing and never fetches when active but there is no request yet', () => {
    render(<AdversarialRiskCheck active={true} request={null} />);
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();
    expect(requestAdversarialRiskCheckMock).not.toHaveBeenCalled();
  });

  it('shows a loading state with a skip option, then the counterpoint once it resolves', async () => {
    const { promise, resolve } = deferred<AdversarialRiskCheckResult>();
    requestAdversarialRiskCheckMock.mockReturnValue(promise);

    render(<AdversarialRiskCheck active={true} request={SAMPLE_REQUEST} />);

    expect(await screen.findByText(/Consultando uma segunda opinião crítica da IA/)).toBeInTheDocument();
    const skipButton = screen.getByTestId('adversarial-risk-check-skip');
    expect(skipButton).toBeInTheDocument();
    expect(skipButton).not.toBeDisabled();

    resolve({ available: true, counterpoint: 'Risco concreto específico deste caso.' });

    await waitFor(() => expect(screen.getByText('Risco concreto específico deste caso.')).toBeInTheDocument());
    expect(screen.getByText('Segunda opinião crítica da IA')).toBeInTheDocument();
    expect(screen.queryByTestId('adversarial-risk-check-skip')).not.toBeInTheDocument();
  });

  it('hides entirely when the check is unavailable (e.g. no server-side API key) — no error is ever shown', async () => {
    requestAdversarialRiskCheckMock.mockResolvedValue({ available: false });

    render(<AdversarialRiskCheck active={true} request={SAMPLE_REQUEST} />);

    await waitFor(() => expect(requestAdversarialRiskCheckMock).toHaveBeenCalledTimes(1));
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();
    expect(screen.queryByText(/erro/i)).not.toBeInTheDocument();
  });

  it('skipping hides the widget immediately and a later "ready" resolution never reappears', async () => {
    const { promise, resolve } = deferred<AdversarialRiskCheckResult>();
    requestAdversarialRiskCheckMock.mockReturnValue(promise);

    render(<AdversarialRiskCheck active={true} request={SAMPLE_REQUEST} />);

    fireEvent.click(await screen.findByTestId('adversarial-risk-check-skip'));
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();

    resolve({ available: true, counterpoint: 'Contraponto que chegou tarde demais.' });
    // Give the promise microtask a chance to settle.
    await Promise.resolve();
    await Promise.resolve();

    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();
    expect(screen.queryByText('Contraponto que chegou tarde demais.')).not.toBeInTheDocument();
  });

  it('fires exactly once per activation — does not refetch on every keystroke while the request keeps changing', async () => {
    requestAdversarialRiskCheckMock.mockResolvedValue({ available: true, counterpoint: 'x' });

    const { rerender } = render(<AdversarialRiskCheck active={true} request={SAMPLE_REQUEST} />);
    await waitFor(() => expect(requestAdversarialRiskCheckMock).toHaveBeenCalledTimes(1));

    // Parent re-renders with a brand new request object (e.g. justification
    // text still changing) while `active` stays true — must not refetch.
    const updatedRequest: AdversarialRiskCheckRequest = {
      type: 'dose_threshold',
      patientId: 'pat-1',
      doseThreshold: {
        overages: [
          {
            substance: 'toxina_botulinica',
            total: 150,
            unit: 'unidades',
            threshold: 100,
            points: [{ region: 'glabela', quantity: 150 }],
          },
        ],
        isFirstSession: false,
      },
    };
    rerender(<AdversarialRiskCheck active={true} request={updatedRequest} />);
    rerender(<AdversarialRiskCheck active={true} request={updatedRequest} />);

    expect(requestAdversarialRiskCheckMock).toHaveBeenCalledTimes(1);
  });

  it('refetches on the next activation after becoming inactive in between', async () => {
    requestAdversarialRiskCheckMock.mockResolvedValue({ available: true, counterpoint: 'x' });

    const { rerender } = render(<AdversarialRiskCheck active={true} request={SAMPLE_REQUEST} />);
    await waitFor(() => expect(requestAdversarialRiskCheckMock).toHaveBeenCalledTimes(1));

    rerender(<AdversarialRiskCheck active={false} request={SAMPLE_REQUEST} />);
    expect(screen.queryByTestId('adversarial-risk-check')).not.toBeInTheDocument();

    rerender(<AdversarialRiskCheck active={true} request={SAMPLE_REQUEST} />);
    await waitFor(() => expect(requestAdversarialRiskCheckMock).toHaveBeenCalledTimes(2));
  });
});
