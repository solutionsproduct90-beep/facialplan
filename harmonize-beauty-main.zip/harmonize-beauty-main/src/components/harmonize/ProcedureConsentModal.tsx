import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import type { ProcedureConsentSummary } from '@/lib/procedureConsent';
import { SUBSTANCE_LABEL, SUBSTANCE_DEFAULT_UNIT } from '@/types/harmonize';
import AdversarialRiskCheck from '@/components/harmonize/AdversarialRiskCheck';
import type { AdversarialRiskCheckRequest } from '@/lib/adversarialRiskCheck';

interface ProcedureConsentModalProps {
  open: boolean;
  summary: ProcedureConsentSummary;
  onConfirm: (signerName: string) => void;
  onClose?: () => void;
  loading?: boolean;
  /**
   * Segunda checagem automática de IA ("advogado do diabo" — ver
   * src/lib/adversarialRiskCheck.ts) para quando a dose planejada está
   * acima do limiar de atenção. Null quando não há nada acima do limiar —
   * neste caso o widget não é renderizado. Puramente informativo: nunca
   * afeta `canConfirm` abaixo.
   */
  adversarialRequest?: AdversarialRiskCheckRequest | null;
}

const formatQuantity = (n: number) => String(Math.round(n * 100) / 100);

/**
 * Collects the per-session TCLE (Termo de Consentimento Livre e Esclarecido)
 * for the specific plan built in Estágio 2 — distinct from the broad,
 * one-time consent collected by ConsentModal at the start of the patient
 * relationship. The "signature" in this v1 is a typed full name; timestamp
 * and the request's IP address are recorded server-side by the
 * record-consent edge function when this is confirmed.
 *
 * Rendered entirely via t() in the professional's current UI language (see
 * consent.procedure.* in src/i18n/locales/*.json) — unlike the text
 * actually persisted to consents.consent_text, which stays in Portuguese
 * regardless of UI language (see buildProcedureConsentText in
 * src/lib/procedureConsent.ts for why).
 */
const ProcedureConsentModal: React.FC<ProcedureConsentModalProps> = ({
  open,
  summary,
  onConfirm,
  onClose,
  loading = false,
  adversarialRequest = null,
}) => {
  const { t } = useTranslation();
  const [scrolledToBottom, setScrolledToBottom] = useState(false);
  const [checked, setChecked] = useState(false);
  const [signerName, setSignerName] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
    if (atBottom) setScrolledToBottom(true);
  }, []);

  useEffect(() => {
    if (!open) return;
    setScrolledToBottom(false);
    setChecked(false);
    setSignerName('');

    // Same fix as ConsentModal.tsx: if the text already fits without
    // scrolling, no scroll event ever fires and the checkbox stays stuck
    // disabled forever.
    const raf = requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (el && el.scrollHeight - el.clientHeight < 30) {
        setScrolledToBottom(true);
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [open]);

  const canConfirm = scrolledToBottom && checked && signerName.trim().length >= 3 && !loading;

  const risksForSubstances = summary.substances.flatMap(
    (s) => t(`consent.procedure.risks.${s}`, { returnObjects: true }) as string[]
  );
  const generalNotes = t('consent.procedure.generalNotes', { returnObjects: true }) as string[];

  return (
    <BottomSheet
      open={open}
      onClose={onClose ?? (() => {})}
      title={t('consent.procedure.title')}
      dismissible={!!onClose}
    >
      <div style={{ padding: '0 20px 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Scrollable consent text */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          data-testid="procedure-consent-text"
          style={{
            maxHeight: '38vh',
            overflowY: 'auto',
            WebkitOverflowScrolling: 'touch',
            background: '#F7F6F4',
            borderRadius: 12,
            padding: 20,
          } as React.CSSProperties & { WebkitOverflowScrolling?: string }}
        >
          <p style={{ fontSize: 14, fontWeight: 700, color: '#1A1918', lineHeight: 1.5 }}>
            {t('consent.procedure.heading')}
          </p>

          <ul style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, margin: '12px 0 0', paddingLeft: 18 }}>
            {summary.substances.map((s) => (
              <li key={s}>
                {t('consent.procedure.substanceLine', {
                  substance: SUBSTANCE_LABEL[s],
                  quantity: formatQuantity(summary.totalsBySubstance[s] ?? 0),
                  unit: SUBSTANCE_DEFAULT_UNIT[s],
                })}
              </li>
            ))}
          </ul>
          <p style={{ fontSize: 13, color: '#6B6965', marginTop: 8 }}>
            {t('consent.procedure.pointsPlanned', { count: summary.pointCount })}
          </p>

          <p style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, marginTop: 16 }}>
            {t('consent.procedure.risksIntro')}
          </p>
          <ul style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, margin: '8px 0 0', paddingLeft: 18 }}>
            {risksForSubstances.map((risk, i) => (
              <li key={i}>{risk}</li>
            ))}
          </ul>

          <p style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, marginTop: 16 }}>
            {t('consent.procedure.generalNotesIntro')}
          </p>
          <ul style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, margin: '8px 0 0', paddingLeft: 18 }}>
            {generalNotes.map((note, i) => (
              <li key={i}>{note}</li>
            ))}
          </ul>

          <p style={{ fontSize: 14, color: '#1A1918', lineHeight: 1.6, marginTop: 16 }}>
            {t('consent.procedure.closing')}
          </p>
        </div>

        {/* Scroll hint */}
        {!scrolledToBottom && (
          <p style={{ fontSize: 13, color: '#AAA8A5', textAlign: 'center', fontWeight: 500 }} className="animate-pulse">
            {t('consent.procedure.scrollHint')}
          </p>
        )}

        {/* Typed full-name "signature" */}
        <div style={{ opacity: !scrolledToBottom ? 0.4 : 1, pointerEvents: !scrolledToBottom ? 'none' : 'auto' }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: '#6B6965', display: 'block', marginBottom: 6 }}>
            {t('consent.procedure.nameLabel')}
          </label>
          <input
            type="text"
            value={signerName}
            onChange={(e) => setSignerName(e.target.value)}
            placeholder={t('consent.procedure.namePlaceholder')}
            data-testid="procedure-consent-name-input"
            className="w-full bg-h-white rounded-r-sm shadow-h-sm px-4 h-[48px] text-[14px] text-h-text outline-none placeholder:text-h-text-3"
          />
          <p style={{ fontSize: 10, color: '#AAA8A5', marginTop: 4 }}>{t('consent.procedure.nameHint')}</p>
        </div>

        {/* Checkbox */}
        <label
          style={{
            display: 'flex', alignItems: 'flex-start', gap: 12,
            opacity: !scrolledToBottom ? 0.4 : 1,
            pointerEvents: !scrolledToBottom ? 'none' : 'auto',
          }}
        >
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            data-testid="procedure-consent-checkbox"
            style={{ marginTop: 2, width: 20, height: 20, flexShrink: 0 }}
          />
          <span style={{ fontSize: 13, color: '#6B6965', lineHeight: 1.4 }}>
            {t('consent.procedure.checkboxLabel')}
          </span>
        </label>

        {/* Segunda checagem automática de IA ("advogado do diabo") — só
            dispara quando há dose acima do limiar (adversarialRequest !=
            null) e esta sheet está aberta; some completamente quando
            indisponível (sem OPENAI_API_KEY, erro de rede etc.) e nunca
            afeta `canConfirm`/o botão abaixo. */}
        <AdversarialRiskCheck active={open} request={adversarialRequest} />

        <GradientButton
          onClick={() => onConfirm(signerName.trim())}
          disabled={!canConfirm}
          data-testid="procedure-consent-confirm"
        >
          {loading ? t('consent.procedure.saving') : t('consent.procedure.confirm')}
        </GradientButton>
      </div>
    </BottomSheet>
  );
};

export default ProcedureConsentModal;
