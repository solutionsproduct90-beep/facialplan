import React, { useState, useId } from 'react';
import { useTranslation } from 'react-i18next';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { ChevronDown, Check } from 'lucide-react';

interface AuthSelectProps {
  label: string;
  options: { value: string; label: string }[];
  value: string;
  onChange: (val: string) => void;
  className?: string;
}

// Mesmo defeito de associação que o AuthInput tinha, com uma forma diferente:
// aqui o controle é um <button> que abre uma folha, não um <select>. Em vez de
// `htmlFor`, o caminho que funciona em todos os leitores de tela é dar um id
// ao rótulo e referenciá-lo com `aria-labelledby` no gatilho — assim o nome
// acessível do botão passa a ser "<rótulo>, <valor selecionado>", em vez de só
// o valor solto.
const AuthSelect: React.FC<AuthSelectProps> = ({ label, options, value, onChange }) => {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const selected = options.find(o => o.value === value);
  const labelId = useId();

  return (
    <div className="flex flex-col gap-1.5">
      <label id={labelId} style={{ fontSize: 13, fontWeight: 600, color: '#6B6965', fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}>
        {label}
      </label>

      {/* Trigger */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-labelledby={labelId}
        aria-haspopup="dialog"
        aria-expanded={open}
        className="min-h-[44px]"
        style={{
          height: 48, borderRadius: 12, padding: '0 16px',
          background: '#FFFFFF', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
          fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif", fontSize: 15, fontWeight: 500,
          color: selected ? '#1A1918' : '#AAA8A5',
          width: '100%', textAlign: 'left',
        }}
      >
        {selected?.label ?? t('common.selectPlaceholder')}
        <ChevronDown size={16} color="#AAA8A5" />
      </button>

      {/* Sheet */}
      <BottomSheet
        open={open}
        onClose={() => setOpen(false)}
        title={label}
      >
        <div style={{ padding: '8px 16px 16px' }}>
          {options.map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => { onChange(opt.value); setOpen(false); }}
              className="min-h-[44px]"
              style={{
                width: '100%', padding: 16, borderRadius: 12,
                background: value === opt.value ? 'rgba(191,95,130,0.08)' : 'transparent',
                border: 'none', cursor: 'pointer', marginBottom: 4,
                display: 'flex', alignItems: 'center',
                justifyContent: 'space-between',
                fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif", fontSize: 15,
                fontWeight: value === opt.value ? 700 : 500,
                color: value === opt.value ? '#BF5F82' : '#1A1918',
              }}
            >
              {opt.label}
              {value === opt.value && (
                <Check size={18} color="#BF5F82" />
              )}
            </button>
          ))}
        </div>
      </BottomSheet>
    </div>
  );
};

export default AuthSelect;
