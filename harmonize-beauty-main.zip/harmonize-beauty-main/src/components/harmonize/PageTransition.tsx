import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

type Direction = 'forward' | 'back';

export const directionAtom = { current: 'forward' as Direction };

export const useNavigateWithDirection = () => {
  const navigate = useNavigate();
  return {
    push: (path: string, options?: { state?: any }) => {
      directionAtom.current = 'forward';
      navigate(path, options);
    },
    back: () => {
      directionAtom.current = 'back';
      navigate(-1);
    },
  };
};

const pageVariants = {
  initial: () => ({
    x: directionAtom.current === 'forward' ? '100%' : '-25%',
    opacity: 0,
  }),
  animate: { x: 0, opacity: 1 },
  exit: () => ({
    x: directionAtom.current === 'forward' ? '-25%' : '100%',
    opacity: 0,
  }),
};

const pageTransition = {
  type: 'spring' as const,
  stiffness: 380,
  damping: 36,
  mass: 0.8,
};

export const PageTransition: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <motion.div
    variants={pageVariants}
    initial="initial"
    animate="animate"
    exit="exit"
    transition={pageTransition}
    style={{ position: 'relative', width: '100%' }}
  >
    {children}
  </motion.div>
);

export default PageTransition;
