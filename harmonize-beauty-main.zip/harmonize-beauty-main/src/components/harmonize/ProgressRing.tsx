import React from 'react';

interface ProgressRingProps {
  pct: number; // 0 a 1
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  children?: React.ReactNode;
}

/**
 * Anel de progresso circular genérico (SVG puro, sem lib externa) — usado
 * pelo card de meta do Painel (`/painel`). `children` renderiza centralizado
 * por cima do anel (normalmente "3/5" ou um ícone de conquista).
 */
const ProgressRing: React.FC<ProgressRingProps> = ({
  pct,
  size = 88,
  strokeWidth = 8,
  color = '#BF5F82',
  trackColor = 'rgba(0,0,0,0.06)',
  children,
}) => {
  const clamped = Math.max(0, Math.min(1, pct));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - clamped);

  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={trackColor} strokeWidth={strokeWidth} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.4s ease' }}
        />
      </svg>
      {children && (
        <div
          style={{
            position: 'absolute', inset: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          {children}
        </div>
      )}
    </div>
  );
};

export default ProgressRing;
