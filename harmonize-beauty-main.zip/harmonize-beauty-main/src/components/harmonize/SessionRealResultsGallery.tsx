import React, { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Camera, X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { logDataAccess } from '@/lib/auditLog';
import SimulationAccuracyRating from './SimulationAccuracyRating';

const MAX_FILE_SIZE = 10 * 1024 * 1024;

type RealResultRow = {
  id: string;
  photo_url: string;
  uploaded_at: string;
};

/**
 * Captura de Resultado Real Pós-Procedimento (ideia do squad de Produto —
 * ver migration 20260911023351_add_session_real_results.sql): até esta
 * feature, a única foto "depois" que a plataforma guardava era a simulação
 * gerada por IA no Estágio 3 (sessions.simulation_url) — nunca o resultado
 * real, fotografado pelo profissional depois de a sessão já estar
 * concluída. Renderizada dentro de cada card de sessão CONCLUÍDA no
 * histórico de PacienteDetalhe.tsx (não faz sentido capturar "resultado
 * real" de uma sessão que ainda não terminou o procedimento).
 *
 * Modelada desde já para múltiplas fotos ao longo do tempo por sessão (grid
 * ordenado por `uploaded_at`, nunca um slot único) — é o pré-requisito
 * citado pelo Produto para uma futura linha do tempo evolutiva entre
 * sessões do mesmo paciente.
 *
 * Também é quem decide quando mostrar o Índice de Precisão da Simulação
 * (SimulationAccuracyRating, backlog P4): só faz sentido pedir ao
 * profissional pra comparar as duas fotos quando AMBAS existem — a
 * simulação do Estágio 3 (`hasSimulation`, resolvido pelo chamador a partir
 * de `sessions.simulation_url`) e pelo menos uma foto de resultado real
 * (`rows`, já carregado aqui). Evita uma segunda consulta só pra saber se a
 * galeria de resultado real está vazia.
 */
const SessionRealResultsGallery: React.FC<{ sessionId: string; professionalId: string; hasSimulation?: boolean }> = ({
  sessionId,
  professionalId,
  hasSimulation = false,
}) => {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});
  const loggedRef = useRef(false);

  const queryKey = ['session-real-results', sessionId];

  const { data: rows } = useQuery({
    queryKey,
    queryFn: async (): Promise<RealResultRow[]> => {
      const { data, error } = await supabase
        .from('session_real_results')
        .select('id, photo_url, uploaded_at')
        .eq('session_id', sessionId)
        .order('uploaded_at', { ascending: true });
      if (error) throw error;
      return (data as RealResultRow[]) ?? [];
    },
    enabled: !!sessionId,
  });

  // Assina cada storagePath (bucket privado `patient-photos`, sem acesso
  // público) pra exibição — mesmo padrão já usado pra `anamnesis.photo_url`
  // em PacienteDetalhe.tsx. Reaproveita a mesma ação de auditoria
  // `view_patient_photo` já existente (ver src/lib/auditLog.ts): uma foto de
  // resultado real também é uma foto sensível do paciente, e o enum de
  // audit_log no banco não tem uma ação dedicada — não vale abrir uma
  // migration só pra isso nesta v1.
  useEffect(() => {
    if (!rows || rows.length === 0) {
      setSignedUrls({});
      return;
    }
    let cancelled = false;
    (async () => {
      // `createSignedUrls` em lote (uma única chamada de rede pra todas as
      // fotos da galeria) em vez de um `createSignedUrl` por foto — evitando
      // o N+1 de antes.
      const paths = rows.map((row) => row.photo_url);
      const { data, error } = await supabase.storage.from('patient-photos').createSignedUrls(paths, 3600);
      if (cancelled) return;
      if (error || !data) {
        setSignedUrls({});
        return;
      }
      // Uma falha ao assinar uma foto específica (item com `error` != null e
      // `signedUrl: null`) não deve derrubar as demais — cada foto some
      // isoladamente da galeria, mesmo comportamento de antes por foto (só
      // entrava no mapa quando havia signedUrl).
      const urlByPath = new Map(data.map((d) => [d.path, d.signedUrl]));
      const entries = rows
        .map((row) => [row.id, urlByPath.get(row.photo_url) ?? null] as const)
        .filter((e): e is [string, string] => Boolean(e[1]));
      setSignedUrls(Object.fromEntries(entries));
      if (!loggedRef.current) {
        loggedRef.current = true;
        logDataAccess('view_patient_photo', 'session', sessionId);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [rows, sessionId]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > MAX_FILE_SIZE) {
      toast.error(t('sessionRealResults.toastFileTooLarge'));
      return;
    }

    setUploading(true);
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      // Sufixo com timestamp (em vez de upsert num nome fixo, como a foto
      // frontal em NovaSessao.tsx) porque aqui cada envio é uma foto NOVA a
      // acumular na linha do tempo, nunca a substituição da anterior.
      const path = `${professionalId}/${sessionId}_real_result_${Date.now()}.${ext}`;
      const { error: uploadErr } = await supabase.storage
        .from('patient-photos')
        .upload(path, file, { contentType: file.type });
      if (uploadErr) throw uploadErr;

      const { error: insertErr } = await supabase.from('session_real_results').insert({
        professional_id: professionalId,
        session_id: sessionId,
        photo_url: path,
      });
      if (insertErr) throw insertErr;

      await queryClient.invalidateQueries({ queryKey });
      toast.success(t('sessionRealResults.toastUploaded'));
    } catch (err) {
      console.error('[SessionRealResultsGallery] Falha ao enviar foto de resultado real:', err);
      toast.error(t('sessionRealResults.toastUploadFailed'));
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (row: RealResultRow) => {
    try {
      const { error } = await supabase.from('session_real_results').delete().eq('id', row.id);
      if (error) throw error;
      // Melhor esforço: a linha do banco (fonte de verdade da galeria) já
      // caiu mesmo que a remoção do arquivo no storage falhe — nunca trava
      // a UI por causa disso, mesmo padrão de outras limpezas best-effort
      // deste app (ver handleExportPdf em SessaoEstagio3.tsx).
      void supabase.storage.from('patient-photos').remove([row.photo_url]);
      await queryClient.invalidateQueries({ queryKey });
      toast.success(t('sessionRealResults.toastDeleted'));
    } catch (err) {
      console.error('[SessionRealResultsGallery] Falha ao remover foto de resultado real:', err);
      toast.error(t('sessionRealResults.toastDeleteFailed'));
    }
  };

  return (
    <div className="mt-3 pt-3" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
      <div className="flex items-center justify-between mb-2">
        <p className="text-[11px] font-bold uppercase tracking-wide text-h-text-3">
          {t('sessionRealResults.title')}
        </p>
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          data-testid="real-results-add"
          className="flex items-center gap-1 text-[11px] font-semibold disabled:opacity-50"
          style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 32 }}
        >
          <Camera size={12} />
          {uploading ? t('sessionRealResults.uploading') : t('sessionRealResults.add')}
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>

      {!rows || rows.length === 0 ? (
        <p className="text-[11px] text-h-text-3">{t('sessionRealResults.empty')}</p>
      ) : (
        <div className="grid grid-cols-4 gap-2">
          {rows.map((row) => (
            <div key={row.id} className="relative aspect-square rounded-r-sm overflow-hidden bg-h-surface">
              {signedUrls[row.id] ? (
                <img src={signedUrls[row.id]} alt={t('sessionRealResults.title')} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full animate-pulse" />
              )}
              <button
                type="button"
                onClick={() => handleDelete(row)}
                aria-label={t('sessionRealResults.delete')}
                className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(0,0,0,0.55)', border: 'none', cursor: 'pointer' }}
              >
                <X size={11} color="#fff" />
              </button>
            </div>
          ))}
        </div>
      )}

      {hasSimulation && rows && rows.length > 0 && (
        <SimulationAccuracyRating sessionId={sessionId} professionalId={professionalId} />
      )}
    </div>
  );
};

export default SessionRealResultsGallery;
