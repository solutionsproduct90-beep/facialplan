import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import VoiceDictationButton from "./VoiceDictationButton";
import i18n from "@/i18n";

vi.mock("sonner", () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));
import { toast } from "sonner";

// A Web Speech API (`SpeechRecognition`/`webkitSpeechRecognition`) não existe
// no jsdom do ambiente de teste, então é mockada aqui — mesmo espírito do
// mock de `@mediapipe/tasks-vision` em SessaoEstagio2.test.tsx, só que como
// global de `window` em vez de módulo npm, já que é isso que o navegador
// expõe de verdade.
let lastInstance: SpeechRecognition | null = null;

// Factory (não classe) para o mock: evita aliasing de `this` — quando uma
// função "construtora" retorna um objeto explicitamente, `new Ctor()` usa
// esse objeto no lugar do `this` implícito, então não há necessidade de
// referenciar `this` em nenhum momento aqui.
function MockSpeechRecognitionCtor(): SpeechRecognition {
  const instance = {
    lang: "",
    continuous: false,
    interimResults: false,
    maxAlternatives: 1,
    onresult: null,
    onerror: null,
    onend: null,
    onstart: null,
    start: vi.fn(),
    stop: vi.fn(),
    abort: vi.fn(),
  } as unknown as SpeechRecognition;

  (instance.stop as ReturnType<typeof vi.fn>).mockImplementation(() => {
    instance.onend?.(new Event("end"));
  });

  lastInstance = instance;
  return instance;
}

function makeResultEvent(transcript: string, isFinal: boolean): SpeechRecognitionEvent {
  return {
    resultIndex: 0,
    results: {
      length: 1,
      0: { isFinal, length: 1, 0: { transcript, confidence: 1 } },
    },
  } as unknown as SpeechRecognitionEvent;
}

function installSpeechRecognition() {
  (window as unknown as { SpeechRecognition: unknown }).SpeechRecognition = MockSpeechRecognitionCtor;
}

function removeSpeechRecognition() {
  delete (window as unknown as { SpeechRecognition?: unknown }).SpeechRecognition;
  delete (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;
}

describe("VoiceDictationButton", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    lastInstance = null;
    vi.clearAllMocks();
  });

  afterEach(() => {
    removeSpeechRecognition();
  });

  describe("navegador sem suporte à Web Speech API", () => {
    beforeEach(() => {
      removeSpeechRecognition();
    });

    it("renderiza desabilitado com tooltip explicando em vez de sumir", () => {
      render(<VoiceDictationButton value="" onTranscript={vi.fn()} />);

      const button = screen.getByRole("button");
      expect(button).toBeDisabled();
      expect(button).toHaveAttribute(
        "title",
        "Ditado por voz não é compatível com este navegador. Tente Chrome ou Edge."
      );
    });

    it("nunca inicia reconhecimento ao clicar (botão desabilitado)", () => {
      const onTranscript = vi.fn();
      render(<VoiceDictationButton value="" onTranscript={onTranscript} />);

      fireEvent.click(screen.getByRole("button"));

      expect(onTranscript).not.toHaveBeenCalled();
      expect(lastInstance).toBeNull();
    });
  });

  describe("navegador com suporte (Web Speech API mockada)", () => {
    beforeEach(() => {
      installSpeechRecognition();
    });

    it("inicia a gravação ao clicar e mostra indicação visual de 'gravando'", () => {
      render(<VoiceDictationButton value="" onTranscript={vi.fn()} />);

      const button = screen.getByRole("button", { name: "Ditar por voz" });
      fireEvent.click(button);

      expect(lastInstance).not.toBeNull();
      expect(lastInstance!.start).toHaveBeenCalledTimes(1);
      expect(screen.getByText("Gravando…")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Parar ditado" })).toBeInTheDocument();
    });

    it("dispara onTranscript com o texto transcrito anexado ao valor atual", () => {
      const onTranscript = vi.fn();
      render(<VoiceDictationButton value="Paciente relatou dor leve." onTranscript={onTranscript} />);

      fireEvent.click(screen.getByRole("button", { name: "Ditar por voz" }));
      expect(lastInstance).not.toBeNull();

      lastInstance!.onresult?.(makeResultEvent("edema discreto na região malar", true));

      expect(onTranscript).toHaveBeenCalledWith(
        "Paciente relatou dor leve. edema discreto na região malar"
      );
    });

    it("para a gravação ao clicar em 'parar ditado'", () => {
      render(<VoiceDictationButton value="" onTranscript={vi.fn()} />);

      fireEvent.click(screen.getByRole("button", { name: "Ditar por voz" }));
      const instance = lastInstance!;

      fireEvent.click(screen.getByRole("button", { name: "Parar ditado" }));

      expect(instance.stop).toHaveBeenCalledTimes(1);
      expect(screen.queryByText("Gravando…")).not.toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Ditar por voz" })).toBeInTheDocument();
    });

    it("mostra um toast de erro claro quando a permissão de microfone é negada", () => {
      render(<VoiceDictationButton value="" onTranscript={vi.fn()} />);

      fireEvent.click(screen.getByRole("button", { name: "Ditar por voz" }));
      lastInstance!.onerror?.({ error: "not-allowed" } as SpeechRecognitionErrorEvent);

      expect(toast.error).toHaveBeenCalledWith(
        "Permissão de microfone negada. Habilite o microfone nas configurações do navegador para ditar."
      );
    });

    it("não mostra toast para 'no-speech' (silêncio, não é uma falha real)", () => {
      render(<VoiceDictationButton value="" onTranscript={vi.fn()} />);

      fireEvent.click(screen.getByRole("button", { name: "Ditar por voz" }));
      lastInstance!.onerror?.({ error: "no-speech" } as SpeechRecognitionErrorEvent);

      expect(toast.error).not.toHaveBeenCalled();
    });
  });
});
