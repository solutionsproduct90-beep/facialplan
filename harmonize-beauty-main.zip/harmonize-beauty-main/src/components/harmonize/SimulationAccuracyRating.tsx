import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const SCALE = [1, 2, 3, 4, 5] as const;

type RatingRow = {
  rating: number;
};

/**
 * Índice de Precisão da Simulação (backlog P4) — o controle onde o
 * profissional avalia, com o próprio julgamento clínico, o quão perto a
 * simulação de IA do Estágio 3 chegou do resultado real (as duas fotos já
 * lado a lado no card de sessão, ver SessionRealResultsGallery.tsx, que só
 * renderiza este componente quando ambas existem).
 *
 * Escala Likert 1-5, NÃO um score automático de IA visual — decisão de
 * produto já documentada em src/types/harmonize.ts e reforçada em
 * src/lib/panel.ts (computeSimulationAccuracyStats): comparar pixels/
 * embeddings das duas fotos seria pseudo-precisão sem lastro clínico. Uma
 * nota por sessão (upsert por `session_id`) — o profissional pode revisar a
 * nota já dada, diferente das fotos de resultado real (enviadas, nunca
 * "corrigidas" in-place).
 */
const SimulationAccuracyRating: React.FC<{ sessionId: string; professionalId: string }> = ({
  sessionId,
  professionalId,
}) => {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);

  const queryKey = ['session-simulation-accuracy-rating', sessionId];

  const { data: row } = useQuery({
    queryKey,
    queryFn: async (): Promise<RatingRow | null> => {
      const { data, error } = await supabase
        .from('session_simulation_accuracy_ratings')
        .select('rating')
        .eq('session_id', sessionId)
        .maybeSingle();
      if (error) throw error;
      return (data as RatingRow | null) ?? null;
    },
    enabled: !!sessionId,
  });

  const currentRating = row?.rating ?? null;

  const handleRate = async (rating: number) => {
    if (saving) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('session_simulation_accuracy_ratings')
        .upsert(
          { session_id: sessionId, professional_id: professionalId, rating },
          { onConflict: 'session_id' },
        );
      if (error) throw error;
      await queryClient.invalidateQueries({ queryKey });
      toast.success(t('simulationAccuracyRating.toastSaved'));
    } catch (err) {
      console.error('[SimulationAccuracyRating] Falha ao salvar autoavaliação:', err);
      toast.error(t('simulationAccuracyRating.toastSaveFailed'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-3 pt-3" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
      <p className="text-[11px] font-bold uppercase tracking-wide text-h-text-3 mb-1">
        {t('simulationAccuracyRating.title')}
      </p>
      <p className="text-[11px] text-h-text-3 mb-2">{t('simulationAccuracyRating.disclaimer')}</p>
      <div className="flex items-center gap-1.5">
        {SCALE.map((n) => (
          <button
            key={n}
            type="button"
            data-testid={`simulation-accuracy-rating-${n}`}
            aria-label={t(`simulationAccuracyRating.scale.${n}`)}
            aria-pressed={currentRating === n}
            disabled={saving}
            onClick={() => handleRate(n)}
            className="flex-1 h-8 min-h-[32px] rounded-r-sm text-[13px] font-bold disabled:opacity-50"
            style={{
              background: currentRating === n ? '#BF5F82' : 'rgba(0,0,0,0.04)',
              color: currentRating === n ? '#fff' : '#AAA8A5',
              border: 'none',
              cursor: 'pointer',
            }}
          >
            {n}
          </button>
        ))}
      </div>
      {currentRating != null && (
        <p className="text-[11px] text-h-text-2 mt-1.5">{t(`simulationAccuracyRating.scale.${currentRating}`)}</p>
      )}
    </div>
  );
};

export default SimulationAccuracyRating;
