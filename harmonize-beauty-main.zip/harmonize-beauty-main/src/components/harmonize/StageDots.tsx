import React from 'react';

interface StageDotsProps {
  currentStage: 1 | 2 | 3;
  activeColor?: string;
}

const StageDots: React.FC<StageDotsProps> = ({ currentStage, activeColor }) => {
  const stages = [1, 2, 3] as const;
  const color = activeColor || '#BF5F82';
  const lineColor = activeColor || '#A855B5';

  return (
    <div className="flex items-center gap-0">
      {stages.map((stage, i) => {
        const isDone = stage < currentStage;
        const isActive = stage === currentStage;

        return (
          <React.Fragment key={stage}>
            {i > 0 && (
              <div
                className="w-8 h-[2px]"
                style={{
                  background: isDone || isActive ? lineColor : '#E5E3E0',
                }}
              />
            )}
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center text-[12px] font-bold flex-shrink-0"
              style={
                isDone
                  ? { background: lineColor, color: '#fff' }
                  : isActive
                  ? { background: `${color}18`, border: `2px solid ${color}`, color: color }
                  : { background: '#E5E3E0', color: '#AAA8A5' }
              }
            >
              {stage}
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
};

export default StageDots;
