import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import SimulationAccuracyRating from './SimulationAccuracyRating';
import i18n from '@/i18n';

const fromMock = vi.fn();
const upsertSpy = vi.fn();

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
  },
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/** Builder pra `session_simulation_accuracy_ratings`: `.select().eq().maybeSingle()` (leitura) e `.upsert(payload, opts)` (escrita). */
function createRatingBuilder(row: unknown | null) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    maybeSingle: () => Promise.resolve({ data: row, error: null }),
    upsert: (payload: Record<string, unknown>, opts: unknown) => {
      upsertSpy(payload, opts);
      return Promise.resolve({ error: null });
    },
  };
  return builder;
}

const renderRating = (sessionId = 'ses-1', professionalId = 'pro-1') =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <SimulationAccuracyRating sessionId={sessionId} professionalId={professionalId} />
    </QueryClientProvider>,
  );

describe('SimulationAccuracyRating', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    fromMock.mockReset();
    upsertSpy.mockReset();
  });

  it('renders the 1-5 scale with no rating selected yet, and the "not automated" disclaimer', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_simulation_accuracy_ratings') return createRatingBuilder(null);
      throw new Error(`unexpected table ${table}`);
    });

    renderRating();

    expect(await screen.findByText('Índice de Precisão da Simulação')).toBeInTheDocument();
    expect(
      screen.getByText('Quão perto a simulação chegou do resultado real? Avaliação sua, não um score automático de IA.'),
    ).toBeInTheDocument();
    for (const n of [1, 2, 3, 4, 5]) {
      expect(screen.getByTestId(`simulation-accuracy-rating-${n}`)).toHaveAttribute('aria-pressed', 'false');
    }
    // Sem nota salva ainda: nenhuma descrição de escala é mostrada como selecionada.
    expect(screen.queryByText('Correspondeu bem')).not.toBeInTheDocument();
  });

  it('shows the previously saved rating as selected, with its description', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_simulation_accuracy_ratings') return createRatingBuilder({ rating: 4 });
      throw new Error(`unexpected table ${table}`);
    });

    renderRating();

    await waitFor(() => expect(screen.getByTestId('simulation-accuracy-rating-4')).toHaveAttribute('aria-pressed', 'true'));
    expect(screen.getByText('Correspondeu bem')).toBeInTheDocument();
  });

  it('saves the rating the professional picks, linked to the session and professional', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_simulation_accuracy_ratings') return createRatingBuilder(null);
      throw new Error(`unexpected table ${table}`);
    });

    renderRating('ses-9', 'pro-9');
    await screen.findByText('Índice de Precisão da Simulação');

    fireEvent.click(screen.getByTestId('simulation-accuracy-rating-5'));

    await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
    expect(upsertSpy.mock.calls[0][0]).toEqual({
      session_id: 'ses-9',
      professional_id: 'pro-9',
      rating: 5,
    });
    expect(upsertSpy.mock.calls[0][1]).toEqual({ onConflict: 'session_id' });
  });

  it('lets the professional revise an already-saved rating', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'session_simulation_accuracy_ratings') return createRatingBuilder({ rating: 2 });
      throw new Error(`unexpected table ${table}`);
    });

    renderRating();
    await waitFor(() => expect(screen.getByTestId('simulation-accuracy-rating-2')).toHaveAttribute('aria-pressed', 'true'));

    fireEvent.click(screen.getByTestId('simulation-accuracy-rating-5'));

    await waitFor(() =>
      expect(upsertSpy).toHaveBeenCalledWith(
        expect.objectContaining({ rating: 5 }),
        { onConflict: 'session_id' },
      ),
    );
  });
});
