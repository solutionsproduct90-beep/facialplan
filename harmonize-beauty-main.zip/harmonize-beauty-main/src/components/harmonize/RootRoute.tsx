import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import FullScreenLoader from './FullScreenLoader';
import LandingPage from '@/pages/site/LandingPage';

// "/" é sempre a raiz de marketing, como em qualquer SaaS com site
// institucional separado do app (Linear, Notion, Cal.com): landing pública
// pra visitante sem sessão, e um simples redirect pra "/inicio" — o
// dashboard de verdade, com sua própria URL — pra quem já está logado.
// "/" nunca renderiza o app diretamente, só decide pra onde mandar.
const RootRoute: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <FullScreenLoader />;
  }

  if (!user) {
    return <LandingPage />;
  }

  return <Navigate to="/inicio" replace />;
};

export default RootRoute;
