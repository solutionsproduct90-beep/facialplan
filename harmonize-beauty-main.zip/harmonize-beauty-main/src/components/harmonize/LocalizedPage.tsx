import React from 'react';
import { useParams } from 'react-router-dom';
import NotFound from '@/pages/NotFound';
import { isPrefixedLocale } from '@/lib/siteLocale';

/**
 * Guarda de rota pras variantes com prefixo de idioma (/:lang/recursos
 * etc.) — react-router casa `:lang` com qualquer segmento; isto garante
 * que só um locale de verdade (ver PREFIXED_LOCALES) renderiza a página,
 * e qualquer outra coisa em `/xx/recursos` cai no 404 normal em vez de
 * mostrar a página com um idioma inválido.
 */
const LocalizedPage: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useParams<{ lang: string }>();
  if (!isPrefixedLocale(lang)) return <NotFound />;
  return <>{children}</>;
};

export default LocalizedPage;
