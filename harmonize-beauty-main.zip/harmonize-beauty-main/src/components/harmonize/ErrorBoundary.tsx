import React from 'react';
import { supabase } from '@/integrations/supabase/client';
import HCard from './HCard';
import GradientButton from './GradientButton';
import SecondaryButton from './SecondaryButton';
import LogoMark from './LogoMark';

interface ErrorBoundaryProps {
  children: React.ReactNode;
  /** Optional custom fallback renderer. Receives the error and a reset callback. */
  fallback?: (error: Error, reset: () => void) => React.ReactNode;
}

interface ErrorBoundaryState {
  error: Error | null;
}

/**
 * Global React Error Boundary for FacialPlan.
 *
 * Catches render-time errors anywhere in the wrapped subtree so a single
 * broken component (ex: um `undefined` inesperado vindo de uma resposta do
 * Supabase) não derruba a tela inteira em branco. Mostra uma UI de fallback
 * amigável usando os componentes visuais do design system e permite ao
 * usuário tentar novamente (reset local do boundary) sem precisar recarregar
 * a página inteira.
 *
 * Log de erros: segue o mesmo padrão usado nas edge functions (ex:
 * `analyze-face`), que gravam em `public.error_logs` (colunas
 * `professional_id`, `stage`, `error_type`, `message`). A tabela permite
 * INSERT client-side apenas quando `auth.uid() = professional_id` (RLS), por
 * isso aqui buscamos o usuário autenticado via `supabase.auth.getUser()` e
 * só tentamos gravar quando ele existe. Isso é best-effort: se não houver
 * sessão ou o insert falhar (ex: rede indisponível — justamente o cenário em
 * que um error boundary dispara), caímos de volta em `console.error` com
 * contexto completo, para nunca mascarar o erro original.
 */
class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary] Erro não tratado capturado na árvore de UI:', {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      url: typeof window !== 'undefined' ? window.location.href : undefined,
      timestamp: new Date().toISOString(),
    });

    void this.logErrorToSupabase(error);
  }

  private async logErrorToSupabase(error: Error) {
    try {
      const { data, error: authError } = await supabase.auth.getUser();
      const professionalId = data?.user?.id;

      if (authError || !professionalId) {
        // Sem sessão autenticada: RLS não permitiria o insert de qualquer
        // forma. O console.error já registrado acima é o log disponível.
        return;
      }

      const { error: insertError } = await supabase.from('error_logs').insert({
        professional_id: professionalId,
        stage: 'client_ui',
        error_type: 'react_render_error',
        message: `${error.message}\n${error.stack ?? ''}`.slice(0, 4000),
      });

      if (insertError) {
        // eslint-disable-next-line no-console
        console.error('[ErrorBoundary] Falha ao gravar em error_logs:', insertError);
      }
    } catch (loggingError) {
      // Nunca deixe uma falha no logging quebrar a recuperação do boundary.
      // eslint-disable-next-line no-console
      console.error('[ErrorBoundary] Exceção ao tentar logar erro no Supabase:', loggingError);
    }
  }

  private handleReset = () => {
    this.setState({ error: null });
  };

  render() {
    const { error } = this.state;

    if (error) {
      if (this.props.fallback) {
        return this.props.fallback(error, this.handleReset);
      }

      return (
        <div className="min-h-screen bg-h-bg flex flex-col items-center justify-center px-6 py-10">
          <div className="w-full max-w-sm flex flex-col items-center gap-5">
            <LogoMark size={48} />

            <HCard className="w-full text-center flex flex-col items-center gap-2">
              <h1 className="text-[18px] font-extrabold text-h-text tracking-tight">
                Ops, algo deu errado
              </h1>
              <p className="text-[13px] text-h-text-2 leading-relaxed">
                Encontramos um erro inesperado nesta tela. Você pode tentar novamente
                — se o problema continuar, volte para o início.
              </p>
              {import.meta.env.DEV && (
                <p className="text-[11px] text-h-red font-mono break-all mt-1">
                  {error.message}
                </p>
              )}
            </HCard>

            <div className="w-full flex flex-col gap-3">
              <GradientButton onClick={this.handleReset}>Tentar novamente</GradientButton>
              <SecondaryButton onClick={() => { window.location.href = '/'; }}>
                Voltar para o início
              </SecondaryButton>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
