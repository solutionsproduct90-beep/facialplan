import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Não há infraestrutura de teste com Postgres real neste repositório (mesma
// situação de manualPointJustificationRpc.test.ts, no mesmo diretório) —
// verificamos estaticamente, no texto da própria migration, que a RLS de
// `appointment_waitlist` segue o padrão de posse direta
// (`professional_id = auth.uid()`) já usado por appointments/patients/
// insumos, e que insert/update também travam o `patient_id` informado ao
// mesmo profissional (mesmo raciocínio de appointments/adverse_events/
// anamnesis nesta base).
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260911130000_add_appointment_waitlist.sql',
);
const sql = readFileSync(migrationPath, 'utf8');

describe('appointment_waitlist (migration SQL)', () => {
  it('enables row level security on the table', () => {
    expect(sql).toContain('ALTER TABLE public.appointment_waitlist ENABLE ROW LEVEL SECURITY');
  });

  it('restricts SELECT to the owning professional', () => {
    const match = sql.match(
      /CREATE POLICY "Professionals can view own waitlist entries"\nON public\.appointment_waitlist FOR SELECT\nTO authenticated\nUSING \(([\s\S]*?)\);/,
    );
    expect(match).not.toBeNull();
    expect(match![1]).toContain('auth.uid() = professional_id');
  });

  it('restricts INSERT to the owning professional AND requires the patient to belong to that same professional', () => {
    const match = sql.match(
      /CREATE POLICY "Professionals can insert own waitlist entries"\nON public\.appointment_waitlist FOR INSERT\nTO authenticated\nWITH CHECK \(([\s\S]*?)\);/,
    );
    expect(match).not.toBeNull();
    expect(match![1]).toContain('auth.uid() = professional_id');
    expect(match![1]).toMatch(/EXISTS \(\s*SELECT 1 FROM public\.patients p WHERE p\.id = patient_id AND p\.professional_id = auth\.uid\(\)\s*\)/);
  });

  it('restricts UPDATE to the owning professional (USING) AND re-checks patient ownership (WITH CHECK)', () => {
    const match = sql.match(
      /CREATE POLICY "Professionals can update own waitlist entries"\nON public\.appointment_waitlist FOR UPDATE\nTO authenticated\nUSING \(([\s\S]*?)\)\nWITH CHECK \(([\s\S]*?)\);/,
    );
    expect(match).not.toBeNull();
    expect(match![1]).toContain('auth.uid() = professional_id');
    expect(match![2]).toContain('auth.uid() = professional_id');
    expect(match![2]).toMatch(/EXISTS \(\s*SELECT 1 FROM public\.patients p WHERE p\.id = patient_id AND p\.professional_id = auth\.uid\(\)\s*\)/);
  });

  it('restricts DELETE to the owning professional', () => {
    const match = sql.match(
      /CREATE POLICY "Professionals can delete own waitlist entries"\nON public\.appointment_waitlist FOR DELETE\nTO authenticated\nUSING \(([\s\S]*?)\);/,
    );
    expect(match).not.toBeNull();
    expect(match![1]).toContain('auth.uid() = professional_id');
  });

  it('never grants a policy to PUBLIC or anon — every policy is scoped TO authenticated', () => {
    const policyBlocks = sql.match(/CREATE POLICY[\s\S]*?;/g) ?? [];
    expect(policyBlocks.length).toBeGreaterThan(0);
    for (const block of policyBlocks) {
      expect(block).toContain('TO authenticated');
    }
  });

  it('requires patient_id (NOT NULL) — a waitlist entry always needs a patient to offer the slot to', () => {
    expect(sql).toMatch(/patient_id uuid NOT NULL REFERENCES public\.patients\(id\) ON DELETE CASCADE/);
  });

  it('constrains status to the four documented values, defaulting to "waiting"', () => {
    expect(sql).toMatch(/status text NOT NULL DEFAULT 'waiting'/);
    expect(sql).toMatch(/CHECK \(status IN \('waiting', 'offered', 'fulfilled', 'expired'\)\)/);
  });

  it('constrains the desired period so the end date is never before the start date', () => {
    expect(sql).toMatch(/desired_end_date date NOT NULL CHECK \(desired_end_date >= desired_start_date\)/);
  });
});
