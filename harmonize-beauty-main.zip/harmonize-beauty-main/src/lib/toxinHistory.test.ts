import { describe, it, expect } from 'vitest';
import { buildLastToxinDatesByRegion, TOXIN_HISTORY_EXCLUDED_STATUS } from './toxinHistory';

/**
 * Regressão do ciclo 76 do QA Contínuo.
 *
 * O histórico de toxina por região alimenta duas checagens de segurança
 * clínica: o Alerta de Intervalo Mínimo (90 dias na mesma região, ao vivo no
 * Estágio 2) e o gate `toxinMinInterval` do Selo de Conformidade no PDF. As
 * duas liam só sessões com `status = 'complete'`, e uma aplicação registrada
 * numa sessão que nunca chegou ao fim do Estágio 3 ficava invisível — mesmo
 * com os pontos já persistidos em `stage2_overlay`.
 */

const ponto = (substance: string, region: string) => ({
  region,
  substance,
  quantity: 4,
});

describe('buildLastToxinDatesByRegion', () => {
  it('conta a aplicação de uma sessão que não foi finalizada', () => {
    // O caso do achado: a toxina foi registrada, a sessão ficou em stage2.
    const datas = buildLastToxinDatesByRegion([
      { created_at: '2026-07-01T10:00:00.000Z', stage2_overlay: [ponto('toxina_botulinica', 'testa')] },
    ]);

    expect(datas.testa).toBe('2026-07-01T10:00:00.000Z');
  });

  it('mantém a data mais recente quando a região aparece em várias sessões', () => {
    const datas = buildLastToxinDatesByRegion([
      { created_at: '2026-03-01T10:00:00.000Z', stage2_overlay: [ponto('toxina_botulinica', 'testa')] },
      { created_at: '2026-08-01T10:00:00.000Z', stage2_overlay: [ponto('toxina_botulinica', 'testa')] },
      { created_at: '2026-05-01T10:00:00.000Z', stage2_overlay: [ponto('toxina_botulinica', 'testa')] },
    ]);

    expect(datas.testa).toBe('2026-08-01T10:00:00.000Z');
  });

  it('ignora substância que não é toxina', () => {
    // Ácido hialurônico não tem intervalo mínimo de reaplicação por
    // anticorpos: entrar aqui geraria alerta onde não há risco.
    const datas = buildLastToxinDatesByRegion([
      { created_at: '2026-07-01T10:00:00.000Z', stage2_overlay: [ponto('acido_hialuronico', 'labios')] },
    ]);

    expect(datas).toEqual({});
  });

  it('não quebra com overlay ausente, nulo ou fora de formato', () => {
    const datas = buildLastToxinDatesByRegion([
      { created_at: '2026-07-01T10:00:00.000Z', stage2_overlay: null },
      { created_at: null, stage2_overlay: [ponto('toxina_botulinica', 'testa')] },
      { created_at: '2026-07-02T10:00:00.000Z', stage2_overlay: 'não é lista' },
      { created_at: '2026-07-03T10:00:00.000Z', stage2_overlay: [null] },
    ]);

    expect(datas).toEqual({});
  });

  it('nada a somar quando não há sessão anterior', () => {
    expect(buildLastToxinDatesByRegion(null)).toEqual({});
    expect(buildLastToxinDatesByRegion([])).toEqual({});
  });

  it('exclui apenas o status marcado à mão como abandonado', () => {
    // A exclusão é uma decisão: 'abandoned' é marcado pelo profissional, uma
    // afirmação de que a sessão não aconteceu. Qualquer outro status em
    // aberto conta.
    expect(TOXIN_HISTORY_EXCLUDED_STATUS).toBe('abandoned');
  });
});

/**
 * Trava de call site.
 *
 * O bug não estava no cálculo, estava no filtro da query — e existia
 * duplicado em duas telas, o que é como ele sobreviveu. Estes testes leem os
 * dois arquivos para garantir que nenhum deles volte a restringir o
 * histórico de toxina a sessões concluídas, e que os dois continuem passando
 * pela função compartilhada.
 */
describe('call sites do histórico de toxina', () => {
  const PAGINAS = ['src/pages/SessaoEstagio2.tsx', 'src/pages/SessaoEstagio3.tsx'];

  it.each(PAGINAS)('%s não filtra o histórico por status complete', async (caminho) => {
    const { readFileSync } = await import('fs');
    const fonte = readFileSync(caminho, 'utf-8');

    expect(fonte).not.toMatch(/\.eq\(\s*['"]status['"]\s*,\s*['"]complete['"]\s*\)/);
  });

  it.each(PAGINAS)('%s usa a função e a constante compartilhadas', async (caminho) => {
    const { readFileSync } = await import('fs');
    const fonte = readFileSync(caminho, 'utf-8');

    expect(fonte).toMatch(/buildLastToxinDatesByRegion\(/);
    expect(fonte).toMatch(/TOXIN_HISTORY_EXCLUDED_STATUS/);
  });
});
