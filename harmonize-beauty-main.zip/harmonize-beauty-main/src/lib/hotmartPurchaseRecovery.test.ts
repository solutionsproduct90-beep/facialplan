import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Verificação estática (mesmo padrão de adminIntelligenceConsentRpc.test.ts —
// não há infraestrutura de teste com Postgres real neste repositório) da
// migration do caminho de recuperação de compra da Hotmart.
//
// O que está sendo protegido aqui não é sintaxe: é a REGRA DE NEGÓCIO que
// separa "recuperar quem pagou" de "dar assinatura de graça para quem digitar
// o e-mail certo". A tabela de compras pendentes é, por construção, uma lista
// de e-mails que pagaram; se o autoatendimento liberasse com base no e-mail
// informado, qualquer um com acesso a um desses e-mails teria o app.
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260917153000_add_hotmart_pending_purchases.sql',
);
const sql = readFileSync(migrationPath, 'utf8');

function extractFunctionBody(functionName: string): string {
  const re = new RegExp(
    `CREATE (?:OR REPLACE )?FUNCTION public\\.${functionName}\\(`
    + `[\\s\\S]*?AS \\$\\$([\\s\\S]*?)\\$\\$;`,
  );
  const match = sql.match(re);
  if (!match) throw new Error(`não achou a função ${functionName} na migration — regex precisa ser ajustado`);
  return match[1];
}

describe('migration 20260917153000 — tabela hotmart_pending_purchases', () => {
  it('liga RLS e só concede SELECT a admin (a tabela é uma lista de quem pagou — não pode vazar para o profissional comum)', () => {
    expect(sql).toMatch(/ALTER TABLE public\.hotmart_pending_purchases ENABLE ROW LEVEL SECURITY/);
    const policy = sql.match(/CREATE POLICY "Admins can view hotmart pending purchases"[\s\S]*?;/)?.[0] ?? '';
    expect(policy).toMatch(/FOR SELECT/);
    expect(policy).toContain("has_role(auth.uid(), 'admin')");
    // Nenhuma policy de escrita para cliente nenhum: quem grava é a service
    // role (webhook) ou função SECURITY DEFINER.
    expect(sql).not.toMatch(/CREATE POLICY[\s\S]*?ON public\.hotmart_pending_purchases FOR (INSERT|UPDATE|DELETE)/);
  });

  it('documenta a tabela e todas as colunas com COMMENT', () => {
    expect(sql).toMatch(/COMMENT ON TABLE public\.hotmart_pending_purchases IS/);
    for (const column of [
      'buyer_email', 'transaction_id', 'event', 'target_status', 'subscriber_code',
      'payload_excerpt', 'received_at', 'claim_requested_by', 'claim_requested_at',
      'resolved_at', 'resolved_profile_id', 'resolution',
    ]) {
      expect(sql).toContain(`COMMENT ON COLUMN public.hotmart_pending_purchases.${column} IS`);
    }
  });

  it('indexa as duas buscas do app: pendência por e-mail e fila do admin', () => {
    expect(sql).toMatch(
      /CREATE INDEX IF NOT EXISTS hotmart_pending_purchases_unresolved_email_idx[\s\S]*?\(buyer_email, received_at DESC\)[\s\S]*?WHERE resolved_at IS NULL/,
    );
    expect(sql).toMatch(/hotmart_pending_purchases_resolved_received_idx[\s\S]*?\(resolved_at, received_at DESC\)/);
  });
});

describe('reconciliação no cadastro (handle_new_user)', () => {
  const body = extractFunctionBody('handle_new_user');

  it('procura compra pendente pelo e-mail do usuário recém-criado, em minúsculas e só entre as não resolvidas', () => {
    expect(body).toMatch(/FROM public\.hotmart_pending_purchases[\s\S]*?WHERE buyer_email = lower\(NEW\.email\)[\s\S]*?AND resolved_at IS NULL/);
    // A mais recente é a que descreve o estado atual da assinatura (uma
    // compra aprovada seguida de reembolso não pode ativar ninguém).
    expect(body).toMatch(/ORDER BY received_at DESC\s*\n\s*LIMIT 1/);
  });

  it('aplica a compra pelo mesmo caminho dos outros dois fluxos, marcando a resolução como "signup"', () => {
    expect(body).toMatch(/PERFORM public\.apply_hotmart_pending_purchase\(NEW\.id, v_pending_id, 'signup'\)/);
  });

  it('nunca deixa uma falha da reconciliação derrubar o signUp', () => {
    expect(body).toMatch(/EXCEPTION WHEN OTHERS THEN[\s\S]*?RAISE WARNING/);
  });

  it('preserva o bloco de aceite dos termos que já existia (20260917093000)', () => {
    expect(body).toContain('public.terms_acceptances');
    expect(body).toContain("'cadastro_sem_ip'");
  });
});

describe('autoatendimento do paywall (request_hotmart_purchase_recovery)', () => {
  const body = extractFunctionBody('request_hotmart_purchase_recovery');

  it('exige sessão autenticada', () => {
    expect(body).toMatch(/IF v_uid IS NULL THEN\s*\n\s*RAISE EXCEPTION 'not authenticated'/);
  });

  it('só libera acesso quando o e-mail informado É o e-mail VERIFICADO da própria conta', () => {
    // As quatro condições precisam estar todas na mesma guarda: compra
    // pendente existe, é de ativação, o e-mail da conta está confirmado, e o
    // e-mail informado é exatamente o da conta. Tirar qualquer uma delas
    // transforma a função num "digite o e-mail de quem pagou e ganhe acesso".
    const guard = body.match(/IF v_pending\.id IS NOT NULL[\s\S]*?THEN/)?.[0] ?? '';
    expect(guard).toContain("v_pending.target_status = 'active'");
    expect(guard).toContain('v_own_confirmed IS NOT NULL');
    expect(guard).toContain('v_email = v_own_email');
    // O e-mail da conta vem de auth.users, não de nada enviado pelo cliente.
    expect(body).toMatch(/FROM auth\.users u\s*\n\s*WHERE u\.id = v_uid/);
  });

  it('audita toda liberação por autoatendimento', () => {
    expect(body).toMatch(/INSERT INTO public\.audit_log[\s\S]*?'hotmart_purchase_self_recovery'/);
  });

  it('devolve a MESMA resposta para "não existe compra" e para "existe, mas é de outra pessoa" (nada de oráculo de enumeração)', () => {
    // Um único RETURN 'activated', dentro da guarda acima; todo o resto do
    // corpo converge para 'under_review'.
    expect(body.match(/RETURN 'activated'/g)).toHaveLength(1);
    expect(body.match(/RETURN 'under_review'/g)).toHaveLength(1);
    const activatedIndex = body.indexOf("RETURN 'activated'");
    const underReviewIndex = body.indexOf("RETURN 'under_review'");
    expect(underReviewIndex).toBeGreaterThan(activatedIndex);
  });

  it('registra o pedido de revisão só quando há compra pendente de verdade, e a primeira reivindicação não é sobrescrita', () => {
    const claimBlock = body.match(/UPDATE public\.hotmart_pending_purchases\s*\n\s*SET claim_requested_by[\s\S]*?;/)?.[0] ?? '';
    expect(claimBlock).toMatch(/AND claim_requested_by IS NULL/);
    expect(body).toMatch(/IF v_pending\.id IS NOT NULL AND v_pending\.claim_requested_by IS NULL THEN/);
  });

  it('é executável por authenticated e por mais ninguém', () => {
    expect(sql).toMatch(/REVOKE ALL ON FUNCTION public\.request_hotmart_purchase_recovery\(text\) FROM PUBLIC/);
    expect(sql).toMatch(/GRANT EXECUTE ON FUNCTION public\.request_hotmart_purchase_recovery\(text\) TO authenticated/);
  });
});

describe('vínculo manual do admin (admin_link_hotmart_pending_purchase)', () => {
  const body = extractFunctionBody('admin_link_hotmart_pending_purchase');

  it('exige admin e grava audit_log na mesma transação', () => {
    expect(body).toContain("has_role(auth.uid(), 'admin')");
    expect(body).toMatch(/RAISE EXCEPTION 'not authorized'/);
    expect(body).toMatch(/INSERT INTO public\.audit_log[\s\S]*?'admin_link_hotmart_purchase'/);
  });

  it('libera o profile que o ADMIN escolheu, não quem reivindicou (a reivindicação é palpite, não prova)', () => {
    expect(body).toMatch(/PERFORM public\.apply_hotmart_pending_purchase\(p_profile_id, p_pending_id, 'admin_manual'\)/);
    expect(body).not.toContain('claim_requested_by');
  });
});

describe('aplicação da compra (apply_hotmart_pending_purchase)', () => {
  const body = extractFunctionBody('apply_hotmart_pending_purchase');

  it('recusa compra inexistente ou já consumida', () => {
    expect(body).toMatch(/WHERE id = p_pending_id AND resolved_at IS NULL/);
    expect(body).toMatch(/RAISE EXCEPTION 'pending purchase not found or already resolved'/);
  });

  it('não é chamável por nenhum role de cliente — quem autoriza é o chamador', () => {
    expect(sql).toMatch(/REVOKE ALL ON FUNCTION public\.apply_hotmart_pending_purchase\(uuid, uuid, text\) FROM PUBLIC/);
    expect(sql).not.toMatch(/GRANT EXECUTE ON FUNCTION public\.apply_hotmart_pending_purchase/);
  });

  it('marca resolvidas TODAS as pendências do mesmo e-mail, para uma compra antiga não reaparecer depois', () => {
    expect(body).toMatch(/UPDATE public\.hotmart_pending_purchases\s*\n\s*SET resolved_at = now\(\)[\s\S]*?WHERE buyer_email = v_pending\.buyer_email\s*\n\s*AND resolved_at IS NULL/);
  });

  it('só carimba past_due_since quando o status aplicado é past_due', () => {
    expect(body).toMatch(/past_due_since = CASE WHEN v_pending\.target_status = 'past_due' THEN now\(\) ELSE NULL END/);
  });
});
