import { describe, it, expect } from 'vitest';
import { formatProfessionalRegistration } from './professionalRegistration';

describe('formatProfessionalRegistration', () => {
  it('formats "TYPE NUMBER" when both are present, for any council category', () => {
    expect(formatProfessionalRegistration('CRM', '123456')).toBe('CRM 123456');
    expect(formatProfessionalRegistration('CRO', '98765')).toBe('CRO 98765');
    expect(formatProfessionalRegistration('CRBM', '456')).toBe('CRBM 456');
  });

  it('returns null when only the council type is filled in', () => {
    expect(formatProfessionalRegistration('CRM', null)).toBeNull();
    expect(formatProfessionalRegistration('CRM', undefined)).toBeNull();
    expect(formatProfessionalRegistration('CRM', '')).toBeNull();
  });

  it('returns null when only the council number is filled in', () => {
    expect(formatProfessionalRegistration(null, '123456')).toBeNull();
    expect(formatProfessionalRegistration(undefined, '123456')).toBeNull();
    expect(formatProfessionalRegistration('', '123456')).toBeNull();
  });

  it('returns null when neither is filled in', () => {
    expect(formatProfessionalRegistration(null, null)).toBeNull();
    expect(formatProfessionalRegistration(undefined, undefined)).toBeNull();
  });

  it('treats whitespace-only values as missing', () => {
    expect(formatProfessionalRegistration('  ', '123456')).toBeNull();
    expect(formatProfessionalRegistration('CRM', '   ')).toBeNull();
  });

  it('trims surrounding whitespace on valid values', () => {
    expect(formatProfessionalRegistration(' CRM ', ' 123456 ')).toBe('CRM 123456');
  });
});
