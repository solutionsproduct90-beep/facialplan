// Pure, jsPDF-agnostic pagination helper for the PDF built in
// SessaoEstagio3.tsx (handleExportPdf). Kept separate from the jsPDF
// drawing code — same rationale as clinicalAnalysisPdf.ts — so the "does
// this fit on the current page" arithmetic can be unit-tested without
// needing jsPDF/canvas in the test environment.

/** The minimal slice of jsPDF's `doc` this module needs — just enough to
 * start a new page. Kept as a narrow structural interface (rather than
 * importing the real `jsPDF` type) so tests can pass a plain mock object. */
export interface PdfPager {
  addPage: () => void;
}

/**
 * "Measure before draw": call this with the full height a block (a section
 * title plus its immediate body, or any other undivisible chunk) is about
 * to occupy — BEFORE drawing any part of it — and use the returned Y as
 * where drawing actually starts.
 *
 * Bug this fixes (P2 "Quebra de página do PDF corta seção ao meio"): the
 * PDF used to reserve space for a section title alone (e.g. 36pt for
 * "ANÁLISE CLÍNICA") and draw it immediately, then separately measure and
 * reserve space for the section's body underneath. When the title fit but
 * the body didn't, jsPDF pushed the body to a new page while the title
 * stayed drawn at the bottom of the previous one — an orphaned heading
 * with its content starting on the next page. Reserving `neededHeight` for
 * the title AND body together, before drawing either, means the page break
 * (if any) happens before the title is drawn, and the whole unit moves to
 * the new page together instead of splitting.
 *
 * Returns `currentY` unchanged when `neededHeight` still fits above
 * `pageHeight - margin`; otherwise calls `doc.addPage()` and returns
 * `topY` (the top-of-page Y a caller should resume drawing from — defaults
 * to `margin` when the page uses the same margin on top and bottom).
 */
export function ensureSpace(
  doc: PdfPager,
  currentY: number,
  neededHeight: number,
  pageHeight: number,
  margin: number,
  topY: number = margin,
): number {
  if (currentY + neededHeight > pageHeight - margin) {
    doc.addPage();
    return topY;
  }
  return currentY;
}
