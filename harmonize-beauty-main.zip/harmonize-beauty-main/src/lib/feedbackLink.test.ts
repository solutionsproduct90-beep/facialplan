import { describe, it, expect } from 'vitest';
import { isValidFeedbackToken, buildFeedbackLink } from './feedbackLink';

describe('isValidFeedbackToken', () => {
  it('accepts a well-formed uuid, as produced by gen_random_uuid()', () => {
    expect(isValidFeedbackToken('8ce48925-2a03-4b67-b118-e17df300570a')).toBe(true);
    expect(isValidFeedbackToken('8CE48925-2A03-4B67-B118-E17DF300570A')).toBe(true);
  });

  it('rejects missing, empty and non-uuid values', () => {
    expect(isValidFeedbackToken(undefined)).toBe(false);
    expect(isValidFeedbackToken(null)).toBe(false);
    expect(isValidFeedbackToken('')).toBe(false);
    expect(isValidFeedbackToken('not-a-token')).toBe(false);
  });

  it('rejects a session id smuggled into the token slot (wrong shape only coincidentally similar)', () => {
    expect(isValidFeedbackToken('8ce489252a034b67b118e17df300570a')).toBe(false);
  });

  it('rejects values that try to inject extra content around a valid uuid', () => {
    expect(isValidFeedbackToken('8ce48925-2a03-4b67-b118-e17df300570a; DROP TABLE sessions;')).toBe(false);
    expect(isValidFeedbackToken(' 8ce48925-2a03-4b67-b118-e17df300570a')).toBe(false);
  });
});

describe('buildFeedbackLink', () => {
  it('joins origin and token into the public feedback URL', () => {
    expect(buildFeedbackLink('https://app.harmonize.com', '8ce48925-2a03-4b67-b118-e17df300570a')).toBe(
      'https://app.harmonize.com/feedback/8ce48925-2a03-4b67-b118-e17df300570a'
    );
  });

  it('strips a trailing slash from the origin before joining', () => {
    expect(buildFeedbackLink('https://app.harmonize.com/', 'token-value')).toBe(
      'https://app.harmonize.com/feedback/token-value'
    );
  });
});
