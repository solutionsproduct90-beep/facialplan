/**
 * Helpers for the public, unauthenticated minisite lead-capture link
 * (`/m/:slug` — see supabase/migrations/20260911030000_add_profile_minisite_slug.sql
 * and the public-minisite edge function). Kept framework-free so the slug
 * shape rules, normalization and URL format can be unit tested without
 * mounting the pages that use them — same reasoning as src/lib/presentLink.ts.
 */

// 3-60 chars, lowercase letters/digits/hyphen, never starting or ending with
// a hyphen — mirrors the CHECK constraint on profiles.minisite_slug.
const SLUG_REGEX = /^[a-z0-9][a-z0-9-]{1,58}[a-z0-9]$/;

// Combining diacritical marks (U+0300-U+036F) left behind by
// String.prototype.normalize('NFD') — e.g. "á".normalize('NFD') becomes "a"
// + U+0301. Written as an escape (not a literal character) to avoid any
// mojibake risk in the source file itself.
const COMBINING_DIACRITICS_REGEX = /[̀-ͯ]/g;

const MIN_SLUG_LENGTH = 3;
const MAX_SLUG_LENGTH = 60;

/**
 * Cheap client-side shape check for a minisite slug, run before ever
 * sending it to the public-minisite edge function or writing it to
 * `profiles.minisite_slug`. This is NOT the security boundary (the DB
 * CHECK constraint and the edge function's slug lookup are) — it just gives
 * immediate feedback in the UI and avoids obviously-malformed values.
 */
export function isValidMinisiteSlug(slug: string | null | undefined): slug is string {
  return typeof slug === 'string' && SLUG_REGEX.test(slug);
}

/**
 * Builds the absolute, shareable minisite URL for a given slug.
 * `origin` should be `window.location.origin` at the call site.
 */
export function buildMinisiteLink(origin: string, slug: string): string {
  return `${origin.replace(/\/+$/, '')}/m/${slug}`;
}

/**
 * Normalizes free text (clinic name, professional name) into a candidate
 * slug: lowercase, strip accents, replace anything that isn't a-z0-9 with a
 * hyphen, collapse repeats, trim leading/trailing hyphens, and clamp to the
 * valid length range. Returns '' when there's no usable content left (e.g.
 * input was only punctuation/emoji) — callers should fall back to a random
 * slug in that case rather than writing an invalid/empty value.
 */
export function slugify(input: string): string {
  const base = input
    .normalize('NFD')
    .replace(COMBINING_DIACRITICS_REGEX, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');

  if (!base) return '';
  if (base.length < MIN_SLUG_LENGTH) return base.padEnd(MIN_SLUG_LENGTH, '0');
  return base.slice(0, MAX_SLUG_LENGTH).replace(/-$/, '0');
}

/**
 * Short random suffix (e.g. "a1b2c3") appended to a base slug to resolve
 * uniqueness conflicts when auto-generating a slug for a professional —
 * cheap alternative to a round-trip "is this slug taken?" check before
 * every attempt (see useMinisiteLink.ts: it just retries the INSERT/UPDATE
 * with a fresh suffix on a unique-violation error).
 */
export function randomSlugSuffix(): string {
  return Math.random().toString(36).slice(2, 8);
}

/**
 * Builds an auto-generated slug candidate from the professional's clinic
 * name / full name, falling back to a generic "profissional" base when
 * neither yields usable characters (e.g. name is entirely emoji/CJK).
 */
export function buildAutoSlugCandidate(nameHint: string | null | undefined): string {
  const base = slugify(nameHint ?? '') || 'profissional';
  const trimmedBase = base.length + 7 > MAX_SLUG_LENGTH ? base.slice(0, MAX_SLUG_LENGTH - 7) : base;
  return `${trimmedBase}-${randomSlugSuffix()}`;
}
