import { describe, it, expect } from "vitest";
import { computeExportLayout, computeCoverRect, EXPORT_WIDTH, EXPORT_HEIGHT } from "./beforeAfterExport";

describe("computeExportLayout", () => {
  it("splits the canvas into two equal photo halves and a bottom watermark bar", () => {
    const layout = computeExportLayout(1080, 1080);
    expect(layout.halfWidth).toBe(540);
    expect(layout.photoAreaHeight + layout.watermarkBarHeight).toBe(1080);
    expect(layout.watermarkBarHeight).toBeGreaterThan(0);
  });

  it("defaults to a 1:1 (square) canvas", () => {
    const layout = computeExportLayout();
    expect(layout.width).toBe(EXPORT_WIDTH);
    expect(layout.height).toBe(EXPORT_HEIGHT);
    expect(layout.width).toBe(layout.height);
  });

  it("scales proportionally with a different target size", () => {
    const layout = computeExportLayout(2160, 2160);
    expect(layout.halfWidth).toBe(1080);
    expect(layout.watermarkBarHeight).toBeGreaterThan(computeExportLayout(1080, 1080).watermarkBarHeight);
  });
});

describe("computeCoverRect", () => {
  it("scales a wider-than-box image up to fill height, centering horizontally", () => {
    // Image is portrait 100x200, box is a 100x100 square: scale must fill
    // both dimensions with no gaps (the "cover" behaviour), so it ends up
    // taller than the box and centered.
    const rect = computeCoverRect(100, 200, 0, 0, 100, 100);
    expect(rect.drawWidth).toBeCloseTo(100);
    expect(rect.drawHeight).toBeCloseTo(200);
    expect(rect.dx).toBeCloseTo(0);
    expect(rect.dy).toBeCloseTo(-50);
  });

  it("scales a shorter-than-box image up to fill width, centering vertically", () => {
    const rect = computeCoverRect(200, 100, 0, 0, 100, 100);
    expect(rect.drawWidth).toBeCloseTo(200);
    expect(rect.drawHeight).toBeCloseTo(100);
    expect(rect.dx).toBeCloseTo(-50);
    expect(rect.dy).toBeCloseTo(0);
  });

  it("offsets the rect by the box origin (right-hand half of the canvas)", () => {
    // Square 100x100 image into a 540x1000 box: scale is driven by the
    // taller dimension (10x), so the image overflows horizontally and gets
    // centered — dx starts left of boxX by half the overflow (540 - 230).
    const rect = computeCoverRect(100, 100, 540, 0, 540, 1000);
    expect(rect.dx).toBeCloseTo(310);
    expect(rect.drawWidth).toBeCloseTo(1000);
    expect(rect.drawHeight).toBeCloseTo(1000);
  });

  it("never leaves gaps: draw dimensions are always >= the box on both axes", () => {
    const rect = computeCoverRect(37, 211, 0, 0, 540, 918);
    expect(rect.drawWidth).toBeGreaterThanOrEqual(540 - 1e-9);
    expect(rect.drawHeight).toBeGreaterThanOrEqual(918 - 1e-9);
  });
});
