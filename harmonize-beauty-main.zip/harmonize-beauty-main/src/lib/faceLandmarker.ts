// Carregamento client-side do FaceLandmarker do MediaPipe (WASM) —
// compartilhado entre o reposicionamento real de pontos na Etapa 2
// (SessaoEstagio2.tsx) e a animação de "escaneamento" da tela de
// carregamento da Nova Sessão (NovaSessao.tsx). Extraído para um módulo à
// parte para as duas telas dividirem o mesmo cache: o download do modelo
// (alguns MB, via CDN) só precisa acontecer uma vez por sessão do
// navegador, então se a animação de carregamento já o inicializou, a
// Etapa 2 reaproveita a mesma instância em vez de baixar tudo de novo.
import type { FaceLandmarker as FaceLandmarkerType } from '@mediapipe/tasks-vision';

// `@mediapipe/tasks-vision` declara seu tipo `Connection` ({ start, end })
// internamente mas não o exporta (ver vision.d.ts) — redeclarado aqui,
// estruturalmente idêntico, só para tipar os conjuntos de conexões abaixo.
type Connection = { start: number; end: number };

// VERSÃO DO WASM (não confundir com a versão do pacote npm): o glue JS que
// `await import('@mediapipe/tasks-vision')` resolve abaixo vem do
// `node_modules` (ver package.json, hoje ^1.0.1 — resolvido pelo bundler,
// nada a ver com esta constante). Esta URL só define de onde o
// FilesetResolver baixa o BINÁRIO .wasm em si, e foi deliberadamente
// mantida pinada em 0.10.14 em vez de acompanhar o 1.0.1 do pacote npm:
// investigamos (WebSearch/npm, set/2026) e não encontramos changelog do
// `@mediapipe/tasks-vision` que confirme ausência de breaking change de
// ABI entre o binário 0.10.x e o 1.x para a API usada aqui
// (FilesetResolver.forVisionTasks, FaceLandmarker.createFromOptions,
// landmarker.detect) — o histórico de releases do google-ai-edge/mediapipe
// não documenta isso a esse nível de detalhe, e o próprio pacote não
// publica um CHANGELOG.md. A superfície TypeScript (vision.d.ts) é idêntica
// nas duas versões para essas três chamadas, o que reduz o risco, mas não
// prova compatibilidade do WASM compilado. Dado que o glue JS já roda em
// 1.0.1 (via npm) contra um WASM 0.10.14 (via CDN) SEM que a investigação
// anterior tenha encontrado indício de quebra — e que subir a versão do
// WASM é reversível a qualquer momento — optamos por NÃO arriscar trocar
// aqui sem antes validar em dispositivo real (câmeras/navegadores
// variados). Bump para 1.0.1 fica registrado como follow-up explícito, não
// como "esquecido".
const MEDIAPIPE_WASM_BASE = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
const FACE_LANDMARKER_MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';

// Um único `import()` dinâmico cacheado, compartilhado por
// loadFaceLandmarker e loadFaceMeshConnections abaixo — em vez de cada
// função chamar `import('@mediapipe/tasks-vision')` por conta própria.
// IMPORTANTE: isto não é só uma otimização; duas chamadas de `import()`
// concorrentes (mesma tick) ao mesmo specifier, cada uma dentro do seu
// próprio `.then()`, se mostraram capazes de travar a resolução uma da
// outra sob o mock de módulo do Vitest (`vi.mock`) — sintoma observado nos
// testes desta tela (SessaoEstagio2.test.tsx): a promise do landmarker
// nunca resolvia enquanto uma segunda chamada a loadFaceMeshConnections
// também estivesse em voo. Compartilhar a MESMA promise de import (chamada
// uma única vez) eliminou o problema, e continua correto em produção (o
// módulo real também só precisa ser buscado uma vez).
let modulePromise: Promise<typeof import('@mediapipe/tasks-vision')> | null = null;
function loadModule(): Promise<typeof import('@mediapipe/tasks-vision')> {
  if (!modulePromise) modulePromise = import('@mediapipe/tasks-vision');
  return modulePromise;
}

let landmarkerPromise: Promise<FaceLandmarkerType> | null = null;

/**
 * Carrega (uma única vez, com cache em nível de módulo) o FaceLandmarker do
 * MediaPipe Tasks Vision — 100% client-side, sem enviar a foto a nenhum
 * servidor além do próprio Supabase. Ver
 * https://ai.google.dev/edge/mediapipe/solutions/vision/face_landmarker
 *
 * `delegate: 'GPU'` e `outputFaceBlendshapes: true` foram adicionados junto
 * com a reformulação da Etapa 2 (malha/linhas de técnica, ver
 * SessaoEstagio2.tsx): GPU acelera a detecção nos dispositivos que suportam
 * WebGL (o próprio MediaPipe cai para CPU automaticamente quando não há
 * suporte, sem exigir tratamento explícito aqui); blendshapes não é
 * consumido ainda nesta etapa, mas já habilitamos a saída porque não tem
 * custo perceptível medir e deixa o caminho pronto para uma futura
 * pré-visualização 3D/expressão sem precisar recriar o FaceLandmarker.
 */
export function loadFaceLandmarker(): Promise<FaceLandmarkerType> {
  if (!landmarkerPromise) {
    landmarkerPromise = (async () => {
      const { FilesetResolver, FaceLandmarker } = await loadModule();
      const vision = await FilesetResolver.forVisionTasks(MEDIAPIPE_WASM_BASE);
      return FaceLandmarker.createFromOptions(vision, {
        baseOptions: { modelAssetPath: FACE_LANDMARKER_MODEL_URL, delegate: 'GPU' },
        runningMode: 'IMAGE',
        numFaces: 1,
        outputFaceBlendshapes: true,
      });
    })();
  }
  return landmarkerPromise;
}

export type FaceMeshConnections = {
  faceOval: Connection[];
  lips: Connection[];
  leftEye: Connection[];
  rightEye: Connection[];
  leftEyebrow: Connection[];
  rightEyebrow: Connection[];
};

let meshConnectionsPromise: Promise<FaceMeshConnections> | null = null;

/**
 * Conjuntos de conexões (pares de índice de landmark) do contorno oficial do
 * MediaPipe — usados pela Etapa 2 para desenhar a malha de fundo discreta
 * sobre a foto (efeito "scanner real"), em vez da tesselação completa
 * (`FACE_LANDMARKS_TESSELATION`), visualmente poluída demais para um overlay
 * clínico. São propriedades estáticas de dados puros da classe
 * `FaceLandmarker` (não exigem o runtime WASM inicializado), mas mesmo assim
 * passam pelo mesmo `import()` dinâmico cacheado pelo módulo — sem custo
 * extra de rede na prática (o import já resolvido é reaproveitado), mantendo
 * o princípio de só carregar o pacote MediaPipe sob demanda.
 */
export function loadFaceMeshConnections(): Promise<FaceMeshConnections> {
  if (!meshConnectionsPromise) {
    meshConnectionsPromise = (async () => {
      const { FaceLandmarker } = await loadModule();
      return {
        faceOval: FaceLandmarker.FACE_LANDMARKS_FACE_OVAL,
        lips: FaceLandmarker.FACE_LANDMARKS_LIPS,
        leftEye: FaceLandmarker.FACE_LANDMARKS_LEFT_EYE,
        rightEye: FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE,
        leftEyebrow: FaceLandmarker.FACE_LANDMARKS_LEFT_EYEBROW,
        rightEyebrow: FaceLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW,
      };
    })();
  }
  return meshConnectionsPromise;
}

/** Uso exclusivo de testes — força um novo carregamento na próxima chamada. */
export function __resetFaceLandmarkerForTests(): void {
  modulePromise = null;
  landmarkerPromise = null;
  meshConnectionsPromise = null;
}
