import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { SUBSTANCE_DEFAULT_UNIT, SUBSTANCE_KEYS } from '@/types/harmonize';
import { computeStepExpectedDate, type TreatmentPlanStepStatus } from './treatmentPlans';
import { daysUntilExpiry, type InsumoStockBatch } from './stockBatches';

// Funções puras da "Previsão de Necessidade de Estoque" (Painel > Estoque) —
// cruza três sistemas que já existiam isolados: Combo Plans
// (treatmentPlans.ts), estoque por lote/validade (stockBatches.ts) e
// histórico de sessões concluídas (mesma tabela `sessions`/`stage2_overlay`
// usada por faturamento.ts). Ver comentário de cabeçalho de
// StockForecastSection.tsx para o desenho completo da tela.
//
// ACHADO QUE MOLDOU ESTE ARQUIVO: nem `appointments` nem
// `treatment_plan_steps` guardam uma QUANTIDADE/dose — só a substância. Uma
// "previsão de X ml/unidades necessários" direto dos Combo Plans seria dado
// inventado. Por isso este arquivo produz DUAS formas honestas de previsão
// por substância (nunca uma terceira "quantidade" fabricada sem base):
//
//  (a) CONTAGEM de etapas pendentes de Combo Plan por substância nos
//      próximos N dias — sempre disponível, não depende de nenhum histórico;
//  (b) ESTIMATIVA de quantidade = contagem × dose média REAL observada nos
//      pontos de aplicação (`ApplicationPoint.quantity`) de sessões já
//      CONCLUÍDAS daquela substância — só quando há amostra histórica
//      suficiente (ver MIN_DOSE_HISTORY_SAMPLE_SIZE); com amostra
//      insuficiente, a substância cai para (a) em vez de estimar com base
//      fraca.
//
// A Agenda (`appointments`) fica de fora propositalmente: não tem nenhum
// vínculo confiável com substância/dose (é só data/paciente/observação), e
// inferir uma substância a partir do procedimento seria dado inventado da
// mesma forma que a "quantidade" original. Registrado aqui como limitação
// conhecida da v1, não como omissão por esquecimento — próxima iteração
// natural seria a Agenda ganhar uma substância prevista opcional por
// consulta, o que já daria uma segunda fonte de contagem pra esta previsão.

/** Janela padrão de projeção — "esta semana", contando hoje como dia 0. */
export const FORECAST_WINDOW_DAYS = 7;

// Mesmo espírito de `MIN_SAMPLE_SIZE` em adminIntelligence.ts (segundo cinto
// de segurança contra estatística fraca), mas aqui o motivo não é privacidade
// — é honestidade: com menos de 5 aplicações reais registradas para uma
// substância, uma "média" oscila demais (uma única sessão fora da curva muda
// o resultado inteiro) para virar uma quantidade que o profissional vai usar
// pra decidir compra de insumo. Abaixo disso, cai para a contagem simples
// (opção a) só para aquela substância — as demais continuam estimando
// normalmente se tiverem amostra própria suficiente.
export const MIN_DOSE_HISTORY_SAMPLE_SIZE = 5;

// Janela de busca do histórico de sessões concluídas usada para calcular a
// dose média — 12 meses dá volume suficiente pra bater
// MIN_DOSE_HISTORY_SAMPLE_SIZE na maioria dos profissionais ativos, sem
// trazer o histórico completo da conta a cada carregamento da aba. Mais larga
// que os 6 meses de `billingLookbackStart` (faturamento.ts) porque ali a
// amostra é por SESSÃO (mais frequente) e aqui é por PONTO de uma substância
// específica (mais esparsa) — não reaproveitado daquele arquivo para não
// acoplar duas abas por um detalhe de janela que pode divergir no futuro.
export const DOSE_HISTORY_LOOKBACK_MONTHS = 12;

/** Início (dia 1 do mês) da janela de busca do histórico de doses, N meses atrás. */
export function doseHistoryLookbackStart(monthsCount = DOSE_HISTORY_LOOKBACK_MONTHS, now: Date = new Date()): Date {
  return new Date(now.getFullYear(), now.getMonth() - (monthsCount - 1), 1);
}

/** Etapa de Combo Plan já com a data prevista calculada, pronta para o filtro de janela. */
export type ForecastStepInput = {
  substance: Substance;
  status: TreatmentPlanStepStatus;
  expectedDate: Date;
};

/** Insumo/marca reduzido ao necessário para mapear lote → substância. */
export type InsumoForForecast = { id: string; substance: string };

/** Um ponto de aplicação de sessão concluída, reduzido ao necessário para a amostra histórica de dose. */
export type HistoricalDoseSample = { substance: Substance; quantity: number };

/** Sessão reduzida ao mínimo necessário para extrair amostras de dose — mesmo shape de `SessionForBilling` em faturamento.ts. */
export type SessionForDoseHistory = {
  status: string | null;
  stage2_overlay: unknown;
};

// Mesma convenção de "procedimento fechado" já usada em faturamento.ts e
// adminMetrics.ts — repetida aqui (não importada) pelo mesmo motivo que
// aqueles dois arquivos já não compartilham a constante entre si.
const CLOSED_SESSION_STATUS = 'complete';

/**
 * Converte planos + etapas cruas (já normalizadas por
 * normalizeTreatmentPlans/normalizeTreatmentPlanSteps) na entrada que o
 * cálculo de janela precisa: data prevista de cada etapa = start_date do
 * plano + offset_days (nunca uma data fixa, ver computeStepExpectedDate).
 * Etapa cujo plano não veio junto na mesma busca é descartada — nunca deveria
 * acontecer (ambas as queries filtram pelo mesmo professional_id), mas não
 * trava o cálculo se acontecer.
 */
export function buildForecastSteps(
  plans: { id: string; startDate: string }[],
  steps: { planId: string; substance: Substance; offsetDays: number; status: TreatmentPlanStepStatus }[],
): ForecastStepInput[] {
  const startDateByPlan = new Map(plans.map((p) => [p.id, p.startDate]));
  const out: ForecastStepInput[] = [];
  for (const step of steps) {
    const startDate = startDateByPlan.get(step.planId);
    if (!startDate) continue;
    out.push({
      substance: step.substance,
      status: step.status,
      expectedDate: computeStepExpectedDate(startDate, step.offsetDays),
    });
  }
  return out;
}

/**
 * true quando `expectedDate` cai nos próximos `windowDays` dias, contando
 * hoje como dia 0 (ex.: janela de 7 dias = hoje + próximos 6 dias). Comparação
 * por dia corrido, não por timestamp exato — `expectedDate` é derivada de uma
 * coluna `date` do Postgres (sem hora), então comparar milissegundos criaria
 * um viés de fuso/hora do dia sem sentido aqui.
 */
export function isStepInForecastWindow(expectedDate: Date, now: Date = new Date(), windowDays = FORECAST_WINDOW_DAYS): boolean {
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const expected = new Date(expectedDate.getFullYear(), expectedDate.getMonth(), expectedDate.getDate());
  const diffDays = Math.round((expected.getTime() - today.getTime()) / (24 * 60 * 60 * 1000));
  return diffDays >= 0 && diffDays < windowDays;
}

/** Só etapas PENDENTES (concluída/pulada não representam necessidade futura de insumo) dentro da janela. */
export function stepsInForecastWindow(
  steps: ForecastStepInput[],
  now: Date = new Date(),
  windowDays = FORECAST_WINDOW_DAYS,
): ForecastStepInput[] {
  return steps.filter((s) => s.status === 'pendente' && isStepInForecastWindow(s.expectedDate, now, windowDays));
}

/**
 * Extrai as amostras de dose real (substância + quantidade) dos pontos de
 * aplicação de sessões já CONCLUÍDAS — a única fonte honesta de "quanto
 * normalmente se usa" desta substância, já que nem appointments nem
 * treatment_plan_steps guardam dose nenhuma. Ponto sem quantidade válida
 * (>0) é ignorado, mesma postura defensiva de `aggregateConsumptionByInsumo`
 * em stockBatches.ts.
 */
export function extractHistoricalDoseSamples(sessions: SessionForDoseHistory[]): HistoricalDoseSample[] {
  const out: HistoricalDoseSample[] = [];
  for (const s of sessions) {
    if (s.status !== CLOSED_SESSION_STATUS) continue;
    const points = Array.isArray(s.stage2_overlay) ? (s.stage2_overlay as ApplicationPoint[]) : [];
    for (const p of points) {
      if (!p || typeof p !== 'object') continue;
      if (!SUBSTANCE_KEYS.includes(p.substance)) continue;
      if (!Number.isFinite(p.quantity) || p.quantity <= 0) continue;
      out.push({ substance: p.substance, quantity: p.quantity });
    }
  }
  return out;
}

/** Mapa insumoId → Substance, só para insumos cuja categoria é uma das 3 Substance (as únicas que ApplicationPoint/Combo Plan conhecem) — insumo de uma das 8 categorias novas (fios, PRP etc.) nunca entra aqui, não tem etapa de Combo Plan correspondente. */
export function buildInsumoSubstanceMap(insumos: InsumoForForecast[]): Map<string, Substance> {
  const map = new Map<string, Substance>();
  for (const insumo of insumos) {
    if (SUBSTANCE_KEYS.includes(insumo.substance as Substance)) {
      map.set(insumo.id, insumo.substance as Substance);
    }
  }
  return map;
}

/**
 * Soma, por substância, o saldo de lotes de estoque NÃO vencidos (vencido =
 * `daysUntilExpiry < 0`) — comparar a necessidade prevista contra estoque já
 * vencido daria uma falsa sensação de cobertura. Lote sem validade cadastrada
 * conta normalmente (ausência de validade não é "vencido", ver
 * isBatchExpiringSoon em stockBatches.ts). Lote cujo insumo não mapeia para
 * nenhuma das 3 Substance é ignorado.
 */
export function nonExpiredStockBySubstance(
  batches: InsumoStockBatch[],
  insumoSubstanceById: Map<string, Substance>,
  now: Date = new Date(),
): Partial<Record<Substance, number>> {
  const totals: Partial<Record<Substance, number>> = {};
  for (const batch of batches) {
    if (batch.quantityRemaining <= 0) continue;
    const days = daysUntilExpiry(batch.expiresOn, now);
    if (days != null && days < 0) continue;
    const substance = insumoSubstanceById.get(batch.insumoId);
    if (!substance) continue;
    totals[substance] = Math.round(((totals[substance] ?? 0) + batch.quantityRemaining) * 100) / 100;
  }
  return totals;
}

export type StockForecastMode = 'count' | 'estimate';

export type SubstanceStockForecast = {
  substance: Substance;
  unit: 'ml' | 'unidades';
  /** Quantas etapas pendentes desta substância caem na janela de previsão. */
  stepsInWindow: number;
  /** 'estimate' quando há amostra histórica suficiente (opção b), 'count' quando cai para a contagem simples (opção a). */
  mode: StockForecastMode;
  /** Dose média real observada, arredondada a 2 casas — null em modo 'count'. */
  averageDosePerStep: number | null;
  /** stepsInWindow × averageDosePerStep, arredondado a 2 casas — null em modo 'count' (nunca fabricado sem base). */
  estimatedQuantityNeeded: number | null;
  /** Quantas amostras históricas alimentaram averageDosePerStep — 0 em modo 'count'. */
  sampleSize: number;
  /** Saldo de lotes não vencidos desta substância, somado entre todas as marcas. */
  availableStock: number;
  /** availableStock >= estimatedQuantityNeeded — null em modo 'count' (não há quantidade nenhuma pra comparar honestamente). */
  stockSufficient: boolean | null;
};

/**
 * Monta a previsão final, uma linha por substância com pelo menos uma etapa
 * pendente na janela — substância sem nenhuma etapa na janela simplesmente
 * NÃO aparece no resultado (nunca uma linha "0 necessário", que pareceria
 * "não precisa comprar nada" em vez de "não há dado pra essa substância").
 * `steps` já deve vir filtrada para pendente + dentro da janela
 * (`stepsInForecastWindow`) — separado desta função para cada etapa do
 * cálculo ser testável isoladamente.
 */
export function buildStockForecast(params: {
  stepsInWindow: ForecastStepInput[];
  historicalDoses: HistoricalDoseSample[];
  availableStockBySubstance: Partial<Record<Substance, number>>;
  minHistorySampleSize?: number;
}): SubstanceStockForecast[] {
  const { stepsInWindow, historicalDoses, availableStockBySubstance, minHistorySampleSize = MIN_DOSE_HISTORY_SAMPLE_SIZE } = params;

  const countBySubstance = new Map<Substance, number>();
  for (const step of stepsInWindow) {
    countBySubstance.set(step.substance, (countBySubstance.get(step.substance) ?? 0) + 1);
  }

  const dosesBySubstance = new Map<Substance, number[]>();
  for (const sample of historicalDoses) {
    const arr = dosesBySubstance.get(sample.substance) ?? [];
    arr.push(sample.quantity);
    dosesBySubstance.set(sample.substance, arr);
  }

  const out: SubstanceStockForecast[] = [];
  for (const substance of SUBSTANCE_KEYS) {
    const stepsCount = countBySubstance.get(substance);
    if (!stepsCount) continue; // sem etapa pendente na janela — substância não entra na previsão, nunca "0"

    const doses = dosesBySubstance.get(substance) ?? [];
    const sampleSize = doses.length;
    const availableStock = availableStockBySubstance[substance] ?? 0;

    if (sampleSize >= minHistorySampleSize) {
      const average = Math.round((doses.reduce((sum, q) => sum + q, 0) / sampleSize) * 100) / 100;
      const estimated = Math.round(average * stepsCount * 100) / 100;
      out.push({
        substance,
        unit: SUBSTANCE_DEFAULT_UNIT[substance],
        stepsInWindow: stepsCount,
        mode: 'estimate',
        averageDosePerStep: average,
        estimatedQuantityNeeded: estimated,
        sampleSize,
        availableStock,
        stockSufficient: availableStock >= estimated,
      });
    } else {
      out.push({
        substance,
        unit: SUBSTANCE_DEFAULT_UNIT[substance],
        stepsInWindow: stepsCount,
        mode: 'count',
        averageDosePerStep: null,
        estimatedQuantityNeeded: null,
        sampleSize,
        availableStock,
        stockSufficient: null,
      });
    }
  }

  return out;
}
