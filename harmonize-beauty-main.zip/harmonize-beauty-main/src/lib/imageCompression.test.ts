import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { compressImageFile } from './imageCompression';

/**
 * jsdom não decodifica imagens de verdade nem implementa canvas 2D sem o
 * pacote opcional `canvas` (não instalado aqui) — `getContext('2d')` sempre
 * devolve `null` e `toBlob` nunca chama o callback (ver src/test/setup.ts).
 * Isso já cobre, "de graça", o caminho de fallback (canvas indisponível →
 * devolve o arquivo original) em qualquer outro teste que dispare a
 * compressão (ex. NovaSessao.tsx). Para testar de verdade a MATEMÁTICA de
 * redimensionamento e o corte "reencodar só ajuda se ficar menor", este
 * arquivo troca `Image`/`HTMLCanvasElement.prototype.getContext`/`toBlob`
 * por dublês locais, restaurados a cada teste — nunca afeta outros arquivos
 * de teste.
 */

class FakeImage {
  onload: (() => void) | null = null;
  onerror: (() => void) | null = null;
  naturalWidth = 0;
  naturalHeight = 0;
  private _src = '';
  set src(value: string) {
    this._src = value;
    queueMicrotask(() => {
      if (FakeImage.nextShouldFail) {
        this.onerror?.();
      } else {
        this.naturalWidth = FakeImage.nextWidth;
        this.naturalHeight = FakeImage.nextHeight;
        this.onload?.();
      }
    });
  }
  get src() {
    return this._src;
  }

  static nextWidth = 0;
  static nextHeight = 0;
  static nextShouldFail = false;
}

/** Contexto 2D dublê — só registra as chamadas de desenho, não desenha nada de verdade. */
function makeFakeContext() {
  return {
    fillStyle: '',
    fillRect: vi.fn(),
    drawImage: vi.fn(),
  };
}

/** Instala um <canvas> dublê cujo `getContext`/`toBlob` são controláveis por teste,
 * preservando `document.createElement` para qualquer outra tag. */
function stubCanvas({
  hasContext = true,
  blobSize,
}: {
  hasContext?: boolean;
  blobSize: number | null;
}) {
  const ctx = makeFakeContext();
  const originalCreateElement = document.createElement.bind(document);
  const spy = vi.spyOn(document, 'createElement').mockImplementation((tagName: string, options?: ElementCreationOptions) => {
    if (tagName !== 'canvas') return originalCreateElement(tagName, options);
    const canvas = originalCreateElement('canvas') as HTMLCanvasElement;
    Object.defineProperty(canvas, 'getContext', {
      value: (id: string) => (id === '2d' && hasContext ? ctx : null),
    });
    Object.defineProperty(canvas, 'toBlob', {
      value: (callback: (b: Blob | null) => void, type: string) => {
        queueMicrotask(() => {
          callback(blobSize === null ? null : new Blob([new Uint8Array(blobSize)], { type }));
        });
      },
    });
    return canvas;
  });
  /** Devolve o <canvas> dublê que a chamada mais recente produziu — outros
   * elementos (inclusive de infraestrutura de teste) também passam por
   * `document.createElement`, então o índice do resultado não é confiável. */
  const getLastCanvas = (): HTMLCanvasElement => {
    for (let i = spy.mock.calls.length - 1; i >= 0; i--) {
      if (spy.mock.calls[i][0] === 'canvas') return spy.mock.results[i].value as HTMLCanvasElement;
    }
    throw new Error('nenhum <canvas> foi criado');
  };

  return { ctx, spy, getLastCanvas };
}

const makeFile = (bytes: number, name = 'foto.jpg', type = 'image/jpeg') =>
  new File([new Uint8Array(bytes)], name, { type });

describe('compressImageFile', () => {
  beforeEach(() => {
    vi.stubGlobal('Image', FakeImage);
    FakeImage.nextShouldFail = false;
    FakeImage.nextWidth = 0;
    FakeImage.nextHeight = 0;
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('returns non-image files untouched, without touching Image/canvas at all', async () => {
    const file = new File(['not-an-image'], 'laudo.pdf', { type: 'application/pdf' });
    const result = await compressImageFile(file);
    expect(result).toBe(file);
  });

  it('downscales an image larger than maxDimension, preserving aspect ratio, and re-encodes as JPEG', async () => {
    FakeImage.nextWidth = 4000;
    FakeImage.nextHeight = 3000; // 4:3 — maior lado (largura) deve cair para 1800
    const { getLastCanvas } = stubCanvas({ blobSize: 500 * 1024 }); // bem menor que o arquivo de entrada
    const original = makeFile(5 * 1024 * 1024, 'paciente.png', 'image/png');

    const result = await compressImageFile(original);

    expect(result).not.toBe(original);
    expect(result.type).toBe('image/jpeg');
    expect(result.name).toBe('paciente.jpg'); // extensão trocada pra refletir o novo formato
    expect(result.size).toBe(500 * 1024);

    const canvas = getLastCanvas();
    expect(canvas.width).toBe(1800);
    expect(canvas.height).toBe(1350); // 3000 * (1800/4000), aspect ratio preservado
  });

  it('does not upscale an image already smaller than maxDimension on its largest side', async () => {
    FakeImage.nextWidth = 1200;
    FakeImage.nextHeight = 800;
    const { getLastCanvas } = stubCanvas({ blobSize: 100 * 1024 });
    const original = makeFile(2 * 1024 * 1024);

    await compressImageFile(original);

    const canvas = getLastCanvas();
    expect(canvas.width).toBe(1200);
    expect(canvas.height).toBe(800);
  });

  it('keeps the original file when the re-encoded version would not be smaller', async () => {
    FakeImage.nextWidth = 800;
    FakeImage.nextHeight = 600;
    // Arquivo de entrada já bem pequeno/eficiente — a versão "comprimida" sai maior.
    stubCanvas({ blobSize: 200 * 1024 });
    const original = makeFile(50 * 1024);

    const result = await compressImageFile(original);

    expect(result).toBe(original);
  });

  it('falls back to the original file when the image fails to load', async () => {
    FakeImage.nextShouldFail = true;
    const original = makeFile(1024 * 1024);

    const result = await compressImageFile(original);

    expect(result).toBe(original);
  });

  it('falls back to the original file when canvas 2D context is unavailable', async () => {
    FakeImage.nextWidth = 2000;
    FakeImage.nextHeight = 2000;
    stubCanvas({ hasContext: false, blobSize: 1 });
    const original = makeFile(1024 * 1024);

    const result = await compressImageFile(original);

    expect(result).toBe(original);
  });

  it('falls back to the original file when toBlob yields no blob', async () => {
    FakeImage.nextWidth = 2000;
    FakeImage.nextHeight = 2000;
    stubCanvas({ blobSize: null });
    const original = makeFile(1024 * 1024);

    const result = await compressImageFile(original);

    expect(result).toBe(original);
  });

  it('respects custom maxDimension/quality options', async () => {
    FakeImage.nextWidth = 1000;
    FakeImage.nextHeight = 1000;
    const { getLastCanvas } = stubCanvas({ blobSize: 10 });
    const original = makeFile(1024 * 1024);

    await compressImageFile(original, { maxDimension: 400, quality: 0.5 });

    const canvas = getLastCanvas();
    expect(canvas.width).toBe(400);
    expect(canvas.height).toBe(400);
  });
});
