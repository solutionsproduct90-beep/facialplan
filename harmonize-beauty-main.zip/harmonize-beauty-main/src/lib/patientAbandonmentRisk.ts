// Score de Risco de Abandono do Paciente — combina 3 sinais de engajamento
// já calculados em outros módulos do app (nenhum dado novo é buscado aqui,
// nenhuma IA/API externa é chamada):
//
//  1. Radar de Retorno (src/lib/returnRadar.ts): quão atrasado o paciente
//     está em relação à janela de manutenção prevista pra substância da
//     última sessão concluída.
//  2. Central de Depoimentos/NPS (patient_feedback.nps_score, ver Painel.tsx
//     e a migration 20260911000000_add_patient_feedback.sql): a nota (0-10)
//     do feedback mais recente do paciente, se ele já respondeu algum.
//  3. Falta em compromisso da Agenda (`appointments`, ver
//     20260910190000_add_appointments.sql): NÃO existe hoje um status
//     distinto de "no-show" nessa tabela — só 'agendado'/'concluido'/
//     'cancelado' (uma falta e um cancelamento avisado caem no mesmo valor).
//     Criar essa distinção é fora do escopo desta função (exigiria migration
//     + mudança de UI na Agenda só pra alimentar este score). Por isso o
//     parâmetro `recentNoShowCount` é OPCIONAL: hoje nenhuma tela ainda o
//     preenche (fica implicitamente 0/"sem sinal"), mas a função já está
//     pronta pra receber esse dado no dia em que a Agenda passar a
//     distinguir falta de cancelamento, sem precisar mudar a assinatura.
//
// Heurística (sem machine learning, só regras somadas — cada sinal vira um
// nível categórico, cada nível tem um peso fixo, os pesos se somam num
// score, e o score cai numa de 3 faixas):
//
//   Atraso do Radar de Retorno (`delay`):
//     'none'     (peso 0)   — sem radar (paciente sem sessão concluída com
//                             substância reconhecida ainda) OU dentro da
//                             janela prevista.
//     'moderate' (peso 1)   — já passou do fim da janela (`isOverdue`), mas
//                             por menos do que a duração da própria janela
//                             (windowEnd - windowStart).
//     'severe'   (peso 2)   — atrasado por 2x ou mais a duração da janela —
//                             o "atraso > 2x a janela esperada" do pedido.
//
//   Feedback/NPS mais recente (`feedback`) — mesma faixa promotor/neutro/
//   detrator usada em DepoimentoPublico.tsx (scoreColor):
//     'promoter'  (peso 0)   — nota 9-10.
//     'passive'   (peso 0.5) — nota 7-8: neutro, discreto sinal de cautela.
//     'none'      (peso 0.5) — paciente ainda não respondeu feedback nenhum.
//                              MESMO peso do 'passive' de propósito: a
//                              ausência de nota não é por si só um alarme
//                              (a maioria dos pacientes nunca chega a
//                              responder), mas também não deve ser tratada
//                              como "tudo bem" — funciona como um sinal
//                              neutro que só pesa de verdade quando somado a
//                              outro sinal ruim (é o "ausente" do pedido).
//     'detractor' (peso 2)   — nota 0-6: sinal negativo real e explícito.
//
//   Falta recente na Agenda (`noShowCount`, contagem, peso 1 por falta até
//   no máximo 2): hoje sempre 0 (ver nota acima), mas somado normalmente
//   quando/se um dia for alimentado.
//
//   Score total = pesoDelay + pesoFeedback + min(noShowCount, 2).
//   Faixas:  score >= 3        → 'alto'
//            2 <= score < 3    → 'medio'
//            score < 2         → 'baixo'
//
// Exemplos do pedido conferidos com esses pesos:
//   - atraso severo + nota baixa (detractor) + 1 falta = 2 + 2 + 1 = 5 → alto
//   - atraso severo + SEM nota nenhuma + 1 falta        = 2 + 0.5 + 1 = 3.5 → alto
//   - apenas atraso moderado, sem outro sinal            = 1 + 0.5 + 0 = 1.5 → baixo
//
// Dados ausentes nunca quebram o cálculo: sem radar, sem feedback e sem
// no-show ainda dá um score numérico válido (0.5, 'baixo') — nunca
// `undefined`/`NaN`.
import type { ReturnRadar } from '@/lib/returnRadar';

export type PatientAbandonmentDelayTier = 'none' | 'moderate' | 'severe';
export type PatientAbandonmentFeedbackTier = 'promoter' | 'passive' | 'none' | 'detractor';
export type PatientAbandonmentRiskLevel = 'baixo' | 'medio' | 'alto';

const DELAY_WEIGHT: Record<PatientAbandonmentDelayTier, number> = {
  none: 0,
  moderate: 1,
  severe: 2,
};

const FEEDBACK_WEIGHT: Record<PatientAbandonmentFeedbackTier, number> = {
  promoter: 0,
  passive: 0.5,
  none: 0.5,
  detractor: 2,
};

const MAX_NO_SHOW_WEIGHT = 2;

const HIGH_RISK_THRESHOLD = 3;
const MEDIUM_RISK_THRESHOLD = 2;

export type PatientAbandonmentRiskInput = {
  /** Resultado de `returnRadarForSessions`/`computeReturnRadar` — `null`/`undefined`
   * quando o paciente ainda não tem radar calculável (sem sessão concluída
   * com substância reconhecida). */
  returnRadar?: ReturnRadar | null;
  /** `nps_score` (0-10) da linha mais recente de `patient_feedback` do
   * paciente — `null`/`undefined` quando ele nunca respondeu nenhum
   * feedback ainda. */
  latestFeedbackNpsScore?: number | null;
  /** Faltas recentes registradas na Agenda — hoje sempre indisponível (ver
   * comentário de arquivo); omitir equivale a 0. */
  recentNoShowCount?: number | null;
  now?: Date;
};

export type PatientAbandonmentRisk = {
  level: PatientAbandonmentRiskLevel;
  /** Soma dos pesos dos 3 sinais — nunca NaN, sempre >= 0. Exposto para
   * ordenar pacientes dentro de uma mesma faixa (`level`) por urgência. */
  score: number;
  delay: PatientAbandonmentDelayTier;
  feedback: PatientAbandonmentFeedbackTier;
  noShowCount: number;
};

/** Classifica o atraso do Radar de Retorno em `none`/`moderate`/`severe` —
 * ver tabela de pesos no comentário do topo do arquivo. */
export function classifyPatientAbandonmentDelay(
  radar: ReturnRadar | null | undefined,
  now: Date = new Date(),
): PatientAbandonmentDelayTier {
  if (!radar || !radar.isOverdue) return 'none';

  const windowLengthMs = radar.windowEnd.getTime() - radar.windowStart.getTime();
  const overdueMs = now.getTime() - radar.windowEnd.getTime();
  if (windowLengthMs <= 0) return 'moderate';

  return overdueMs >= windowLengthMs * 2 ? 'severe' : 'moderate';
}

/** Classifica a nota de feedback mais recente em promotor/neutro/ausente/
 * detrator — mesma faixa 0-6/7-8/9-10 usada em DepoimentoPublico.tsx. */
export function classifyPatientAbandonmentFeedback(
  npsScore: number | null | undefined,
): PatientAbandonmentFeedbackTier {
  if (npsScore === null || npsScore === undefined || Number.isNaN(npsScore)) return 'none';
  if (npsScore <= 6) return 'detractor';
  if (npsScore <= 8) return 'passive';
  return 'promoter';
}

/**
 * Calcula o score/categoria de risco de abandono de um paciente a partir dos
 * 3 sinais já disponíveis no cliente. Função pura e determinística — mesma
 * entrada sempre produz a mesma saída, nenhuma chamada de rede. Ver
 * comentário no topo do arquivo para as regras completas.
 */
export function computePatientAbandonmentRisk(
  input: PatientAbandonmentRiskInput,
): PatientAbandonmentRisk {
  const now = input.now ?? new Date();
  const delay = classifyPatientAbandonmentDelay(input.returnRadar, now);
  const feedback = classifyPatientAbandonmentFeedback(input.latestFeedbackNpsScore);
  const noShowCount = Math.max(0, input.recentNoShowCount ?? 0);

  const score = DELAY_WEIGHT[delay] + FEEDBACK_WEIGHT[feedback] + Math.min(noShowCount, MAX_NO_SHOW_WEIGHT);

  const level: PatientAbandonmentRiskLevel =
    score >= HIGH_RISK_THRESHOLD ? 'alto' : score >= MEDIUM_RISK_THRESHOLD ? 'medio' : 'baixo';

  return { level, score, delay, feedback, noShowCount };
}

/** Peso numérico de cada faixa, maior = mais urgente — pronto para ordenar
 * uma lista de pacientes com `.sort((a, b) => b - a)` sobre o resultado
 * desta função (ou, mais simples, direto por `risk.score`, que já carrega a
 * mesma ordem com mais granularidade dentro de uma mesma faixa). */
export function patientAbandonmentRiskRank(level: PatientAbandonmentRiskLevel): number {
  return level === 'alto' ? 2 : level === 'medio' ? 1 : 0;
}
