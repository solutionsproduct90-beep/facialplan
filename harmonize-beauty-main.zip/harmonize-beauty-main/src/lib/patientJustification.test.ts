import { describe, it, expect } from 'vitest';
import { extractPatientExplanation, formatPatientExplanation } from './patientJustification';

const join = (finding: string, clinicalGoal: string) => `${finding} ${clinicalGoal}`;

describe('extractPatientExplanation', () => {
  it('returns parts for the current 3-part justification format', () => {
    const result = extractPatientExplanation({
      finding: 'Volume reduzido no lábio superior',
      clinicalGoal: 'Restaurar volume e contorno do vermelhão',
      technicalNote: 'Aplicação em bolus retrovermelhão, evitando comissuras',
    });
    expect(result).toEqual({
      kind: 'parts',
      finding: 'Volume reduzido no lábio superior',
      clinicalGoal: 'Restaurar volume e contorno do vermelhão',
    });
  });

  it('returns null for a manual point with no justification', () => {
    expect(extractPatientExplanation(undefined)).toBeNull();
    expect(extractPatientExplanation(null)).toBeNull();
  });

  it('returns null when finding and clinicalGoal are both empty/missing', () => {
    expect(extractPatientExplanation({ technicalNote: 'só técnica, sem achado/objetivo' })).toBeNull();
    expect(extractPatientExplanation({ finding: '', clinicalGoal: '' })).toBeNull();
  });

  it('falls back to a single field when only one of finding/clinicalGoal is present', () => {
    expect(extractPatientExplanation({ finding: 'Achado isolado' })).toEqual({
      kind: 'parts',
      finding: 'Achado isolado',
      clinicalGoal: '',
    });
  });

  it('accepts the legacy single-string justification format defensively', () => {
    expect(extractPatientExplanation('texto legado único, pré-migração')).toEqual({
      kind: 'raw',
      text: 'texto legado único, pré-migração',
    });
  });

  it('returns null for an empty/whitespace-only legacy string', () => {
    expect(extractPatientExplanation('   ')).toBeNull();
    expect(extractPatientExplanation('')).toBeNull();
  });
});

describe('formatPatientExplanation', () => {
  it('joins finding + clinicalGoal via the given template', () => {
    const explanation = extractPatientExplanation({
      finding: 'Volume reduzido',
      clinicalGoal: 'Restaurar volume',
    })!;
    expect(formatPatientExplanation(explanation, join)).toBe('Volume reduzido Restaurar volume');
  });

  it('returns just the one present part when the other is missing', () => {
    const explanation = extractPatientExplanation({ clinicalGoal: 'Restaurar volume' })!;
    expect(formatPatientExplanation(explanation, join)).toBe('Restaurar volume');
  });

  it('returns the raw legacy text untouched, ignoring the join template', () => {
    const explanation = extractPatientExplanation('texto legado único')!;
    expect(formatPatientExplanation(explanation, join)).toBe('texto legado único');
  });
});
