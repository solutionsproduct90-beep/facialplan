// Telefone do paciente com DDI (código do país).
//
// Decisão de armazenamento: a coluna `patients.phone` continua `text` em
// formato livre (nenhuma migration precisou mudar o schema). O que muda é
// o que a UI escreve nela:
//   - Cadastros novos / edições salvas a partir de agora gravam o telefone
//     já com DDI, ex. "+5521658924242" (sem espaços/traços).
//   - Registros antigos, gravados só com o número local (ex. "21658924242",
//     sem "+"), continuam exatamente como estão — não há backfill. Isso é
//     deliberado: não dá pra inferir com segurança o DDI de um número livre
//     já salvo (o app hoje atende BR/US/ES/FR/IT), e reescrever dados de
//     produção por um palpite arriscaria corromper telefones válidos.
//     Esses registros aparecem no formulário de edição com o DDI padrão
//     (Brasil, +55) pré-selecionado e o número local intacto — o
//     profissional pode corrigir o DDI se o paciente for de outro país.
//
// parsePhoneForEdit / composePhone fazem essa ida-e-volta entre o valor
// livre salvo no banco e os dois campos do formulário (DDI + número local).

export interface DialCodeOption {
  /** Código ISO 3166-1 alpha-2, usado só para achar o DDI padrão por geolocalização. */
  country: string;
  /** DDI com "+", ex. "+55". */
  dial: string;
  /** Chave de tradução do rótulo (ver `patients.fields.dialCodes.*`). */
  labelKey: string;
}

// Os 5 mercados do app (ver src/i18n/index.ts) + "outro" pra digitação livre.
export const DIAL_CODE_OPTIONS: DialCodeOption[] = [
  { country: 'BR', dial: '+55', labelKey: 'patients.fields.dialCodes.br' },
  { country: 'US', dial: '+1', labelKey: 'patients.fields.dialCodes.us' },
  { country: 'ES', dial: '+34', labelKey: 'patients.fields.dialCodes.es' },
  { country: 'FR', dial: '+33', labelKey: 'patients.fields.dialCodes.fr' },
  { country: 'IT', dial: '+39', labelKey: 'patients.fields.dialCodes.it' },
];

/** Valor de `dial` que sinaliza "outro país" — o profissional digita o DDI livremente. */
export const OTHER_DIAL_CODE = 'OTHER';

export const DEFAULT_DIAL_CODE = '+55';

// Do mais longo pro mais curto, pra achar o match certo ao separar um
// telefone salvo como "+<ddi><numero>" (ex. "+1" não pode "roubar" o match
// de um "+39..." só porque também é prefixo válido de outro número).
const KNOWN_DIAL_CODES = [...DIAL_CODE_OPTIONS.map((o) => o.dial)].sort((a, b) => b.length - a.length);

/** Mesma lógica de geolocalização usada pra detectar idioma (ver src/i18n/index.ts e api/geo.ts),
 * mas mapeando pro DDI em vez do idioma. País fora dos 5 mercados cai no default (Brasil). */
export function dialCodeForCountry(country: string | null | undefined): string {
  const match = country && DIAL_CODE_OPTIONS.find((o) => o.country === country);
  return match ? match.dial : DEFAULT_DIAL_CODE;
}

export function digitsOnly(value: string): string {
  return value.replace(/\D/g, '');
}

export interface ParsedPhone {
  /** Um dos `DIAL_CODE_OPTIONS[].dial`, ou `OTHER_DIAL_CODE` quando não reconhecido. */
  dial: string;
  /** Preenchido só quando `dial === OTHER_DIAL_CODE`: o número inteiro (DDI + local)
   * digitado/colado livremente, ex. "+351911222333" — não dá pra separar com
   * segurança o DDI do número local de um país fora dos 5 mercados sem uma
   * lib de telefonia, então esse caso usa um único campo de texto livre. */
  customDial: string;
  /** Número local, sem o DDI (só usado quando `dial` é um dos 5 conhecidos). */
  local: string;
}

/** Separa um telefone salvo no banco em DDI + número local, pro formulário de edição. */
export function parsePhoneForEdit(stored: string | null | undefined, fallbackDial = DEFAULT_DIAL_CODE): ParsedPhone {
  const value = (stored ?? '').trim();
  if (!value) return { dial: fallbackDial, customDial: '', local: '' };

  if (value.startsWith('+')) {
    const known = KNOWN_DIAL_CODES.find((code) => value.startsWith(code));
    if (known) {
      return { dial: known, customDial: '', local: value.slice(known.length).trim() };
    }
    // DDI não reconhecido (um dos 5 mercados) — mantém o valor inteiro
    // editável como "outro código", sem tentar adivinhar onde o DDI termina.
    return { dial: OTHER_DIAL_CODE, customDial: value, local: '' };
  }

  // Legado: número salvo sem "+" (formato anterior a este recurso). Mantém
  // o número local como está e assume o DDI padrão — ver nota no topo do arquivo.
  return { dial: fallbackDial, customDial: '', local: value };
}

/** Junta DDI + número local no formato salvo no banco (ex. "+5521658924242"), ou `null` se vazio. */
export function composePhone(dial: string, customDial: string, local: string): string | null {
  if (dial === OTHER_DIAL_CODE) {
    const digits = digitsOnly(customDial);
    return digits ? `+${digits}` : null;
  }
  const localDigits = digitsOnly(local);
  return localDigits ? `${dial}${localDigits}` : null;
}
