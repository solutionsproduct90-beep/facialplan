// Copiloto de Justificativa Clínica (backlog P6) — rascunho de justificativa
// estruturada oferecido em SessaoEstagio2.tsx quando o profissional cria/edita
// MANUALMENTE um ponto de aplicação (sem vir de sugestão de IA do Estágio 1,
// que já traz sua própria `JustificationParts`, ver src/types/harmonize.ts).
// Alimentado por `get_manual_point_justification_stats` (SECURITY DEFINER,
// ver supabase/migrations/20260911100000_add_manual_point_justification_stats_rpc.sql),
// que devolve estatísticas já agregadas em SQL para uma combinação exata de
// substância+região, aplicando o corte de amostra mínima inteiramente lá
// (nunca em TypeScript) — mesmo `MIN_SAMPLE_SIZE` de src/lib/adminIntelligence.ts,
// segundo cinto de segurança redundante aqui, igual ao padrão já usado pelas
// três funções de src/lib/adminIntelligence.ts.
//
// DECISÃO DE PRIVACIDADE — o rascunho gerado aqui NUNCA descreve o paciente
// atual: toda frase fala do padrão observado na base agregada ("dose típica
// observada na base para esta combinação"), nunca "este paciente apresenta
// X". O texto é sempre um RASCUNHO editável — nunca é aceito automaticamente,
// nunca substitui o julgamento clínico do profissional (ver
// sessions.stage2.justificationCopilot.disclaimer no i18n e o comentário de
// uso em SessaoEstagio2.tsx).
import { MIN_SAMPLE_SIZE } from './adminIntelligence';
import type { JustificationParts } from '@/types/harmonize';

/** Linha crua devolvida por `get_manual_point_justification_stats` — já agregada/cortada em SQL, nenhuma coluna de paciente/profissional/sessão. */
export type ManualPointJustificationStatsRow = {
  avg_quantity: number | null;
  quantity_sample_size: number;
  avg_accuracy_rating: number | null;
  accuracy_sample_size: number;
  adverse_event_rate: number | null;
  adverse_event_sample_size: number;
};

export type ManualPointJustificationStats = {
  /** Dose média histórica para esta combinação exata substância+região. */
  avgQuantity: number;
  quantitySampleSize: number;
  /** Nota média de precisão de simulação (1-5) para a mesma combinação, ou null sem amostra suficiente. */
  avgAccuracyRating: number | null;
  /** Taxa de eventos adversos (0-1) em nível de SUBSTÂNCIA (a tabela de farmacovigilância não guarda região), ou null sem amostra suficiente. */
  adverseEventRate: number | null;
};

/**
 * Reaplica o corte de amostra mínima do lado do cliente (segundo cinto de
 * segurança redundante com o `HAVING`/early-return da RPC, mesmo padrão de
 * defesa em profundidade de `mapDoseAccuracyGroups` etc. em
 * src/lib/adminIntelligence.ts) e devolve `null` quando não há dado
 * suficiente nem para a estatística primária (dose média) — esse `null` é o
 * sinal para a UI não mostrar sugestão nenhuma, sem erro, sem alarme: estado
 * normal e esperado no começo da vida da base.
 */
export function mapManualPointJustificationStatsRow(
  row: ManualPointJustificationStatsRow | null | undefined,
  minSampleSize = MIN_SAMPLE_SIZE,
): ManualPointJustificationStats | null {
  if (!row || row.avg_quantity == null || row.quantity_sample_size < minSampleSize) return null;

  const accuracyOk = row.avg_accuracy_rating != null && row.accuracy_sample_size >= minSampleSize;
  const adverseOk = row.adverse_event_rate != null && row.adverse_event_sample_size >= minSampleSize;

  return {
    avgQuantity: row.avg_quantity,
    quantitySampleSize: row.quantity_sample_size,
    avgAccuracyRating: accuracyOk ? row.avg_accuracy_rating : null,
    adverseEventRate: adverseOk ? row.adverse_event_rate : null,
  };
}

/** Mesma assinatura mínima de `t` do i18next usada em src/lib/namedProtocols.ts (`Translate`), suficiente para as chamadas abaixo. */
type Translate = (key: string, options?: Record<string, unknown>) => string;

/**
 * Monta o RASCUNHO de `JustificationParts` a partir das estatísticas
 * agregadas — sempre um ponto de partida editável, nunca uma afirmação
 * clínica sobre o paciente atual. `technicalNote` sempre traz a dose média
 * (única estatística garantida, já que `stats` só existe quando ela passou
 * no corte de amostra mínima); a nota média de simulação e a taxa de eventos
 * adversos são acrescentadas só quando disponíveis (`avgAccuracyRating`/
 * `adverseEventRate` não nulos) — cada uma delas pode faltar independente da
 * outra sem impedir o rascunho de ser oferecido.
 */
export function buildManualPointJustificationDraft(
  stats: ManualPointJustificationStats,
  context: { regionLabel: string; substanceLabel: string; unit: string },
  t: Translate,
): JustificationParts {
  const finding = t('sessions.stage2.justificationCopilot.finding', {
    region: context.regionLabel,
    substance: context.substanceLabel,
    count: stats.quantitySampleSize,
  });

  const clinicalGoal = t('sessions.stage2.justificationCopilot.clinicalGoalPlaceholder');

  const technicalNoteParts = [
    t('sessions.stage2.justificationCopilot.technicalNoteDose', {
      quantity: stats.avgQuantity,
      unit: context.unit,
    }),
  ];

  if (stats.avgAccuracyRating != null) {
    technicalNoteParts.push(
      t('sessions.stage2.justificationCopilot.technicalNoteAccuracy', { rating: stats.avgAccuracyRating }),
    );
  }

  if (stats.adverseEventRate != null) {
    technicalNoteParts.push(
      t('sessions.stage2.justificationCopilot.technicalNoteAdverseRate', {
        // 0.0345 -> 3.5 (uma casa decimal já é precisão suficiente para uma taxa aproximada).
        percent: Math.round(stats.adverseEventRate * 1000) / 10,
      }),
    );
  }

  return {
    finding,
    clinicalGoal,
    technicalNote: technicalNoteParts.join(' '),
  };
}
