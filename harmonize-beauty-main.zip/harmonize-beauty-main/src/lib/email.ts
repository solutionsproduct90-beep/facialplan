// Validação simples de formato de e-mail para o cadastro/edição de
// paciente: o campo é opcional, então só valida quando algo foi digitado
// (string vazia nunca é "inválida" — ver uso em NovoPaciente/EditarPaciente).
// Mesma regex usada na constraint CHECK da migration
// 20260910170000_add_patient_email.sql — mantém as duas em sincronia caso
// uma delas mude.
const EMAIL_FORMAT_REGEX = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export function isValidEmail(value: string): boolean {
  return EMAIL_FORMAT_REGEX.test(value.trim());
}
