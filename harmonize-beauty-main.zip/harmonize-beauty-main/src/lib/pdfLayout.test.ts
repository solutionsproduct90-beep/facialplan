import { describe, it, expect, vi } from "vitest";
import { ensureSpace, type PdfPager } from "./pdfLayout";

const PAGE_HEIGHT = 842; // A4 in pt, same unit used by SessaoEstagio3.tsx
const MARGIN = 70;
const TOP_Y = 56;

function makePager() {
  const addPage = vi.fn();
  const doc: PdfPager = { addPage };
  return { doc, addPage };
}

describe("ensureSpace", () => {
  it("returns currentY unchanged and does not start a new page when the block fits", () => {
    const { doc, addPage } = makePager();
    const y = ensureSpace(doc, 400, 100, PAGE_HEIGHT, MARGIN, TOP_Y);
    expect(y).toBe(400);
    expect(addPage).not.toHaveBeenCalled();
  });

  it("starts a new page and returns topY when the block would overflow the bottom margin", () => {
    const { doc, addPage } = makePager();
    // 780 + 100 = 880 > 842 - 70 = 772 → doesn't fit
    const y = ensureSpace(doc, 780, 100, PAGE_HEIGHT, MARGIN, TOP_Y);
    expect(addPage).toHaveBeenCalledTimes(1);
    expect(y).toBe(TOP_Y);
  });

  it("treats landing exactly on the bottom margin as fitting (boundary is inclusive)", () => {
    const { doc, addPage } = makePager();
    const y = ensureSpace(doc, 700, 72, PAGE_HEIGHT, MARGIN, TOP_Y); // 700+72 === 772 === pageHeight-margin
    expect(y).toBe(700);
    expect(addPage).not.toHaveBeenCalled();
  });

  it("defaults topY to margin when not given", () => {
    const { doc } = makePager();
    const y = ensureSpace(doc, 800, 50, PAGE_HEIGHT, MARGIN);
    expect(y).toBe(MARGIN);
  });

  // Regression test for the P2 bug: "Quebra de página do PDF corta seção ao
  // meio" — a section title (e.g. "ANÁLISE CLÍNICA") drawn without checking
  // whether its body fits underneath ends up orphaned at the bottom of a
  // page while the body is pushed to the next one.
  describe("measure-before-draw prevents an orphaned section title", () => {
    const TITLE_HEIGHT = 36;
    const BODY_HEIGHT = 240; // e.g. the clinical-analysis quote box

    it("(buggy pattern) reserving only the title's height lets the title get orphaned", () => {
      const { doc, addPage } = makePager();
      let y = 750; // title alone (36) fits: 750+36=786 <= 772? no — pick a y where title fits but body doesn't
      y = 730; // 730+36=766 <= 772 → title fits on this page
      const pages: { what: string; page: number }[] = [];
      let page = 0;
      const buggyDoc: PdfPager = { addPage: () => { page++; addPage(); } };

      // old behavior: ensureSpace() only for the title...
      y = ensureSpace(buggyDoc, y, TITLE_HEIGHT, PAGE_HEIGHT, MARGIN, TOP_Y);
      pages.push({ what: "title", page });
      y += 26; // drawSectionTitle's real y advance after drawing

      // ...then, separately, ensureSpace() for the body underneath.
      y = ensureSpace(buggyDoc, y, BODY_HEIGHT, PAGE_HEIGHT, MARGIN, TOP_Y);
      pages.push({ what: "body", page });

      // This is the bug: the title was drawn on page 0, but the body it
      // introduces landed on page 1 — an orphaned heading.
      expect(pages[0].page).not.toBe(pages[1].page);
    });

    it("(fixed pattern) reserving title+body together before drawing keeps both on the same page", () => {
      let y = 730; // same starting point as the buggy scenario above
      const pages: { what: string; page: number }[] = [];
      let page = 0;
      const fixedDoc: PdfPager = { addPage: () => { page++; } };

      // fixed behavior: a single ensureSpace() call for title+body combined,
      // BEFORE anything is drawn — mirrors drawSectionTitle(label, bodyHeight)
      // in SessaoEstagio3.tsx.
      y = ensureSpace(fixedDoc, y, TITLE_HEIGHT + BODY_HEIGHT, PAGE_HEIGHT, MARGIN, TOP_Y);
      pages.push({ what: "title", page });
      y += 26;
      pages.push({ what: "body", page });

      expect(pages[0].page).toBe(pages[1].page);
      expect(page).toBe(1); // it did break — just before drawing, not mid-section
    });

    it("(fixed pattern) when the combined block already fits, no page break happens at all", () => {
      const y = 400;
      const { doc, addPage } = makePager();
      const y1 = ensureSpace(doc, y, TITLE_HEIGHT + BODY_HEIGHT, PAGE_HEIGHT, MARGIN, TOP_Y);
      expect(y1).toBe(400);
      expect(addPage).not.toHaveBeenCalled();
    });
  });
});
