import { describe, it, expect } from 'vitest';
import {
  startOfWeek,
  startOfMonth,
  countSessionsInPeriod,
  computeGoalProgress,
  computeMonthlyPotential,
  computeSubscriptionRoi,
  computeActiveDayStreak,
  formatRoiMultiple,
  computeSimulationAccuracyStats,
  aggregateReturnRadarAlerts,
  getConversionBenchmarkBucket,
} from './panel';
import type { ApplicationPoint, Insumo } from '@/types/harmonize';
import type { SessionForReturnRadar } from './returnRadar';

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'malar_direita',
  label: 'Malar Direita',
  substance: 'acido_hialuronico',
  quantity: 2,
  unit: 'ml',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

const insumo = (overrides: Partial<Insumo> = {}): Insumo => ({
  id: 'ins-ha-voluma',
  substance: 'acido_hialuronico',
  brandName: 'Juvederm Voluma',
  costPerUnit: 400,
  pricePerUnit: 1500,
  active: true,
  ...overrides,
});

describe('startOfWeek', () => {
  it('rewinds to Monday, regardless of which day of the week is passed', () => {
    // quarta-feira 2026-09-09 -> segunda 2026-09-07
    expect(startOfWeek(new Date(2026, 8, 9, 15, 30))).toEqual(new Date(2026, 8, 7));
    // domingo 2026-09-13 -> segunda 2026-09-07 (semana anterior)
    expect(startOfWeek(new Date(2026, 8, 13, 8, 0))).toEqual(new Date(2026, 8, 7));
    // a própria segunda-feira não se move
    expect(startOfWeek(new Date(2026, 8, 7, 23, 59))).toEqual(new Date(2026, 8, 7));
  });
});

describe('startOfMonth', () => {
  it('returns the 1st of the given month at local midnight', () => {
    expect(startOfMonth(new Date(2026, 8, 30, 12, 0))).toEqual(new Date(2026, 8, 1));
  });
});

describe('countSessionsInPeriod', () => {
  const now = new Date(2026, 8, 10, 12, 0); // quinta-feira, 10/set/2026

  it('counts only sessions created since the start of the current week', () => {
    const sessions = [
      { created_at: new Date(2026, 8, 9).toISOString() }, // esta semana
      { created_at: new Date(2026, 8, 7).toISOString() }, // esta semana (segunda)
      { created_at: new Date(2026, 8, 6).toISOString() }, // semana passada (domingo)
    ];
    expect(countSessionsInPeriod(sessions, 'weekly', now)).toBe(2);
  });

  it('counts sessions created since the start of the current month', () => {
    const sessions = [
      { created_at: new Date(2026, 8, 1).toISOString() },
      { created_at: new Date(2026, 7, 31).toISOString() }, // mês passado
    ];
    expect(countSessionsInPeriod(sessions, 'monthly', now)).toBe(1);
  });

  it('ignores sessions without created_at instead of throwing', () => {
    expect(countSessionsInPeriod([{ created_at: null }], 'weekly', now)).toBe(0);
  });
});

describe('computeGoalProgress', () => {
  it('returns null when no target is configured — no invented goal', () => {
    expect(computeGoalProgress(3, null)).toBeNull();
    expect(computeGoalProgress(3, undefined)).toBeNull();
    expect(computeGoalProgress(3, 0)).toBeNull();
  });

  it('computes progress pct, clamped at 1, and the achieved flag', () => {
    expect(computeGoalProgress(2, 5)).toEqual({ current: 2, target: 5, pct: 0.4, achieved: false });
    expect(computeGoalProgress(5, 5)).toEqual({ current: 5, target: 5, pct: 1, achieved: true });
    expect(computeGoalProgress(8, 5)).toEqual({ current: 8, target: 5, pct: 1, achieved: true });
  });
});

describe('computeMonthlyPotential', () => {
  const insumos: Insumo[] = [insumo()];
  const now = new Date(2026, 8, 15);

  it('sums the budget of sessions created this month that already have priced points', () => {
    const sessions = [
      { created_at: new Date(2026, 8, 1).toISOString(), stage2_overlay: [point({ insumoId: 'ins-ha-voluma', quantity: 2 })] },
      { created_at: new Date(2026, 8, 10).toISOString(), stage2_overlay: [point({ insumoId: 'ins-ha-voluma', quantity: 1 })] },
      { created_at: new Date(2026, 7, 31).toISOString(), stage2_overlay: [point({ insumoId: 'ins-ha-voluma', quantity: 10 })] }, // mês passado
    ];
    // 2*1500 + 1*1500 = 4500
    expect(computeMonthlyPotential(sessions, insumos, null, now)).toBe(4500);
  });

  it('skips sessions with no overlay yet (still on stage 1)', () => {
    const sessions = [
      { created_at: new Date(2026, 8, 5).toISOString(), stage2_overlay: null },
      { created_at: new Date(2026, 8, 5).toISOString(), stage2_overlay: [] },
    ];
    expect(computeMonthlyPotential(sessions, insumos, null, now)).toBe(0);
  });
});

describe('computeSubscriptionRoi', () => {
  it('reports hasData: false when no subscription value is configured — never a fabricated multiple', () => {
    expect(computeSubscriptionRoi(5000, null)).toEqual({ hasData: false, multiple: 0 });
    expect(computeSubscriptionRoi(5000, 0)).toEqual({ hasData: false, multiple: 0 });
  });

  it('divides the monthly potential by the configured subscription value', () => {
    expect(computeSubscriptionRoi(4500, 150)).toEqual({ hasData: true, multiple: 30 });
  });
});

describe('formatRoiMultiple', () => {
  it('drops the trailing .0 for whole multiples', () => {
    expect(formatRoiMultiple(30)).toBe('30');
    expect(formatRoiMultiple(1)).toBe('1');
  });

  it('keeps one decimal place for fractional multiples', () => {
    expect(formatRoiMultiple(2.34)).toBe('2.3');
  });

  it('falls back to 0 for non-finite input', () => {
    expect(formatRoiMultiple(NaN)).toBe('0');
    expect(formatRoiMultiple(Infinity)).toBe('0');
  });
});

describe('computeActiveDayStreak', () => {
  const today = new Date(2026, 8, 10, 18, 0); // quinta-feira

  it('counts consecutive days including today when today already has activity', () => {
    const dates = [
      new Date(2026, 8, 10).toISOString(),
      new Date(2026, 8, 9).toISOString(),
      new Date(2026, 8, 8).toISOString(),
    ];
    expect(computeActiveDayStreak(dates, today)).toBe(3);
  });

  it('does not break the streak just because today has no activity yet', () => {
    const dates = [new Date(2026, 8, 9).toISOString(), new Date(2026, 8, 8).toISOString()];
    expect(computeActiveDayStreak(dates, today)).toBe(2);
  });

  it('breaks the streak when yesterday also has no activity', () => {
    const dates = [new Date(2026, 8, 8).toISOString()]; // 2 dias atrás — ontem ficou sem sessão
    expect(computeActiveDayStreak(dates, today)).toBe(0);
  });

  it('returns 0 for no activity at all', () => {
    expect(computeActiveDayStreak([], today)).toBe(0);
  });

  it('ignores null/invalid entries without throwing', () => {
    expect(computeActiveDayStreak([null, undefined, 'not-a-date', new Date(2026, 8, 10).toISOString()], today)).toBe(1);
  });
});

describe('computeSimulationAccuracyStats', () => {
  it('returns null when there are no ratings yet, never an invented average', () => {
    expect(computeSimulationAccuracyStats([])).toBeNull();
  });

  it('averages the Likert scale and the percentage of ratings that matched well (4 or 5)', () => {
    const stats = computeSimulationAccuracyStats([
      { rating: 5 },
      { rating: 4 },
      { rating: 3 },
      { rating: 2 },
    ]);
    expect(stats).toEqual({ average: 3.5, count: 4, goodMatchPercentage: 50 });
  });

  it('treats a single low rating as 0% good match, not a rounding artifact', () => {
    const stats = computeSimulationAccuracyStats([{ rating: 1 }]);
    expect(stats).toEqual({ average: 1, count: 1, goodMatchPercentage: 0 });
  });

  it('treats every rating 4 or 5 as 100% good match', () => {
    const stats = computeSimulationAccuracyStats([{ rating: 4 }, { rating: 5 }, { rating: 5 }]);
    expect(stats?.goodMatchPercentage).toBe(100);
    expect(stats?.average).toBeCloseTo(4.667, 2);
    expect(stats?.count).toBe(3);
  });
});

describe('aggregateReturnRadarAlerts', () => {
  const now = new Date(2026, 8, 10, 12, 0); // quinta-feira, 10/set/2026

  const completedSession = (createdAt: Date, substance: string): SessionForReturnRadar => ({
    status: 'complete',
    created_at: createdAt.toISOString(),
    stage2_overlay: [{ id: 'p1', substance }],
  });

  it('counts patients whose return window has already opened by the end of this week, separately from the overdue ones', () => {
    const patients = [
      // dueThisWeek: toxina botulínica aplicada há 4 meses — janela (4-6 meses) abre hoje mesmo.
      { sessions: [completedSession(new Date(2026, 4, 10), 'toxina_botulinica')] },
      // overdue: ácido hialurônico aplicado há mais de 18 meses — já passou do fim da janela.
      { sessions: [completedSession(new Date(2024, 11, 1), 'acido_hialuronico')] },
      // nem um nem outro: bioestimulador aplicado há poucos dias — janela só abre daqui a 1 ano.
      { sessions: [completedSession(new Date(2026, 8, 1), 'bioestimulador')] },
      // sem nenhuma sessão concluída ainda — não conta em nada.
      { sessions: [] },
    ];

    expect(aggregateReturnRadarAlerts(patients, now)).toEqual({ dueThisWeek: 1, overdue: 1 });
  });

  it('never double-counts a patient in both buckets — overdue takes priority over dueThisWeek', () => {
    const overdue = { sessions: [completedSession(new Date(2024, 11, 1), 'acido_hialuronico')] };
    const result = aggregateReturnRadarAlerts([overdue], now);
    expect(result).toEqual({ overdue: 1, dueThisWeek: 0 });
  });

  it('returns zero counts for an empty or missing patient list, never throwing', () => {
    expect(aggregateReturnRadarAlerts([], now)).toEqual({ dueThisWeek: 0, overdue: 0 });
    expect(aggregateReturnRadarAlerts(null, now)).toEqual({ dueThisWeek: 0, overdue: 0 });
    expect(aggregateReturnRadarAlerts(undefined, now)).toEqual({ dueThisWeek: 0, overdue: 0 });
  });
});

describe('getConversionBenchmarkBucket', () => {
  it('returns the bucket from the single row the RPC returns when there is enough data', () => {
    expect(getConversionBenchmarkBucket([{ conversion_bucket: 'top_third' }])).toBe('top_third');
    expect(getConversionBenchmarkBucket([{ conversion_bucket: 'middle_third' }])).toBe('middle_third');
    expect(getConversionBenchmarkBucket([{ conversion_bucket: 'bottom_third' }])).toBe('bottom_third');
  });

  it('returns null for zero rows (RPC found no comparison group with enough peers) — never a fabricated bucket', () => {
    expect(getConversionBenchmarkBucket([])).toBeNull();
    expect(getConversionBenchmarkBucket(null)).toBeNull();
    expect(getConversionBenchmarkBucket(undefined)).toBeNull();
  });

  it('returns null for an unexpected bucket value instead of trusting it blindly', () => {
    expect(getConversionBenchmarkBucket([{ conversion_bucket: 'unexpected' }])).toBeNull();
    expect(getConversionBenchmarkBucket([{ conversion_bucket: null }])).toBeNull();
  });
});
