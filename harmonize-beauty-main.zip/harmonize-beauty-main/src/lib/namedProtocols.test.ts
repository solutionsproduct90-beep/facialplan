import { describe, it, expect } from 'vitest';
import {
  NAMED_PROTOCOLS,
  getNamedProtocol,
  isWellFormedProtocols,
  protocolNameKey,
  protocolDescriptionKey,
  protocolVarianceNoteKey,
  protocolContraindicationsKey,
  protocolDisplayName,
  protocolDisplayDescription,
  protocolDisplayVarianceNote,
  protocolDisplayContraindications,
  suggestedDoseForProtocolPoint,
  protocolDoseRangeBySubstance,
  projectedDoseRangeBySubstance,
  protocolThresholdWarnings,
  protocolToApplicationPoints,
} from './namedProtocols';
import { FACE_REGION_KEYS } from '@/lib/faceRegions';
import { DOSE_ALERT_THRESHOLD, SUBSTANCE_DEFAULT_DEPTH, SUBSTANCE_DEFAULT_DEVICE } from '@/types/harmonize';
import type { ApplicationPoint } from '@/types/harmonize';

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'mandibula_esquerda',
  label: 'Ângulo Mandibular Esquerdo',
  substance: 'toxina_botulinica',
  quantity: 8,
  unit: 'unidades',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

describe('NAMED_PROTOCOLS — well-formedness', () => {
  it('has exactly the 6 protocols defined by the committee', () => {
    expect(NAMED_PROTOCOLS.length).toBe(6);
  });

  it('has unique ids', () => {
    const ids = NAMED_PROTOCOLS.map((p) => p.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('every protocol has at least one point, each referencing a valid FaceRegionKey', () => {
    for (const protocol of NAMED_PROTOCOLS) {
      expect(protocol.points.length).toBeGreaterThan(0);
      for (const pt of protocol.points) {
        expect(FACE_REGION_KEYS).toContain(pt.region);
      }
    }
  });

  it('every point has a coherent dose range (min > 0, min <= max)', () => {
    for (const protocol of NAMED_PROTOCOLS) {
      for (const pt of protocol.points) {
        expect(pt.doseRange.min).toBeGreaterThan(0);
        expect(pt.doseRange.min).toBeLessThanOrEqual(pt.doseRange.max);
      }
    }
  });

  it('every protocol declares at least one contraindication and a non-empty variance note', () => {
    for (const protocol of NAMED_PROTOCOLS) {
      expect(protocol.contraindications.length).toBeGreaterThan(0);
      expect(protocol.varianceNote.length).toBeGreaterThan(0);
    }
  });

  it('is reported well-formed by isWellFormedProtocols()', () => {
    expect(isWellFormedProtocols()).toBe(true);
  });

  it('flags a protocol list with an unknown region slug as not well-formed', () => {
    const broken = [
      { ...NAMED_PROTOCOLS[0], points: [{ ...NAMED_PROTOCOLS[0].points[0], region: 'regiao_inexistente' as never }] },
    ];
    expect(isWellFormedProtocols(broken)).toBe(false);
  });

  it('flags a protocol with an inverted dose range (min > max) as not well-formed', () => {
    const broken = [
      { ...NAMED_PROTOCOLS[0], points: [{ ...NAMED_PROTOCOLS[0].points[0], doseRange: { min: 2, max: 1 } }] },
    ];
    expect(isWellFormedProtocols(broken)).toBe(false);
  });

  // "ATENÇÃO DE IMPLEMENTAÇÃO" do comitê: Fox Eyes usa a MESMA região
  // (tempora_esquerda/direita) para duas substâncias diferentes em
  // profundidades diferentes — são pontos distintos, não um conflito de
  // dado a ser deduplicado.
  it('Fox Eyes keeps two distinct points (toxin + HA) for the same tempora region, not merged', () => {
    const foxEyes = getNamedProtocol('fox_eyes')!;
    const leftTemporaPoints = foxEyes.points.filter((p) => p.region === 'tempora_esquerda');
    expect(leftTemporaPoints).toHaveLength(2);
    expect(new Set(leftTemporaPoints.map((p) => p.substance))).toEqual(
      new Set(['toxina_botulinica', 'acido_hialuronico']),
    );
  });

  // Facelift Líquido soma 6.4–10.0 mL de AH por desenho, acima do limiar de
  // atenção de 6 mL (DOSE_ALERT_THRESHOLD.acido_hialuronico) — o comitê
  // pediu que isso fosse sinalizado proativamente, então o campo estático
  // precisa bater com o cálculo dinâmico.
  it('exceedsDefaultThreshold is set exactly on protocols whose own dose sum already exceeds the alert threshold', () => {
    for (const protocol of NAMED_PROTOCOLS) {
      const ownWarnings = protocolThresholdWarnings(protocol, []);
      const selfExceedsAny = ownWarnings.some((w) => w.selfExceeds);
      expect(!!protocol.exceedsDefaultThreshold).toBe(selfExceedsAny);
    }
  });

  it('Facelift Líquido is the only protocol flagged as exceeding the threshold by design', () => {
    const flagged = NAMED_PROTOCOLS.filter((p) => p.exceedsDefaultThreshold).map((p) => p.id);
    expect(flagged).toEqual(['facelift_liquido']);
  });
});

describe('getNamedProtocol', () => {
  it('finds a protocol by id', () => {
    expect(getNamedProtocol('boca_russa')?.name).toBe('Boca Russa');
  });

  it('returns undefined for an unknown or missing id', () => {
    expect(getNamedProtocol('nao_existe')).toBeUndefined();
    expect(getNamedProtocol(undefined)).toBeUndefined();
  });
});

describe('protocol*Key / protocolDisplay*', () => {
  const translate = (key: string, options?: Record<string, unknown>) => options?.defaultValue ?? key;

  it('builds stable i18n keys namespaced under namedProtocols.protocols', () => {
    expect(protocolNameKey('boca_russa')).toBe('namedProtocols.protocols.boca_russa.name');
    expect(protocolDescriptionKey('boca_russa')).toBe('namedProtocols.protocols.boca_russa.description');
    expect(protocolVarianceNoteKey('boca_russa')).toBe('namedProtocols.protocols.boca_russa.varianceNote');
    expect(protocolContraindicationsKey('boca_russa')).toBe('namedProtocols.protocols.boca_russa.contraindications');
  });

  it('resolves display name/description/varianceNote via translate, falling back to the pt data', () => {
    expect(protocolDisplayName('boca_russa', translate)).toBe('Boca Russa');
    expect(protocolDisplayDescription('boca_russa', translate)).toMatch(/preenchimento labial/i);
    expect(protocolDisplayVarianceNote('boca_russa', translate)).toMatch(/anatomia de base/i);
  });

  it('lets translate override the fallback (simulating a loaded locale)', () => {
    expect(protocolDisplayName('boca_russa', () => 'Russian Lips')).toBe('Russian Lips');
  });

  it('returns undefined for an unknown or missing protocol id', () => {
    expect(protocolDisplayName('nao_existe', translate)).toBeUndefined();
    expect(protocolDisplayName(undefined, translate)).toBeUndefined();
    expect(protocolDisplayDescription(undefined, translate)).toBeUndefined();
    expect(protocolDisplayVarianceNote(undefined, translate)).toBeUndefined();
  });

  it('protocolDisplayContraindications falls back to the pt array and returns [] for an unknown protocol', () => {
    const translateArrays = (key: string, options?: Record<string, unknown>) => options?.defaultValue ?? key;
    const contraindications = protocolDisplayContraindications('botox_baby', translateArrays);
    expect(contraindications).toEqual(getNamedProtocol('botox_baby')!.contraindications);
    expect(protocolDisplayContraindications(undefined, translateArrays)).toEqual([]);
  });

  it('protocolDisplayContraindications uses the translated array when translate returns one', () => {
    const translated = protocolDisplayContraindications('botox_baby', () => ['x', 'y']);
    expect(translated).toEqual(['x', 'y']);
  });
});

describe('suggestedDoseForProtocolPoint', () => {
  it('returns the midpoint rounded to 0.1 for an HA (ml) point', () => {
    const bocaRussa = getNamedProtocol('boca_russa')!;
    // labio_superior: 0.4-0.6 -> midpoint 0.5
    expect(suggestedDoseForProtocolPoint(bocaRussa.points[0])).toBeCloseTo(0.5, 5);
  });

  it('returns the midpoint rounded to a whole unit for a toxin (unidades) point', () => {
    const botoxBaby = getNamedProtocol('botox_baby')!;
    // glabela: 10-14 -> midpoint 12
    const glabela = botoxBaby.points.find((p) => p.region === 'glabela')!;
    expect(suggestedDoseForProtocolPoint(glabela)).toBe(12);
  });
});

describe('protocolDoseRangeBySubstance', () => {
  it('sums the HA dose range across Facelift Líquido — 6.4 to 10.0 mL by design', () => {
    const facelift = getNamedProtocol('facelift_liquido')!;
    const ranges = protocolDoseRangeBySubstance(facelift);
    expect(ranges.acido_hialuronico).toEqual({ min: 6.4, max: 10.0 });
  });

  it('sums the toxin dose range across Botox Baby — 26 to 40 U', () => {
    const botoxBaby = getNamedProtocol('botox_baby')!;
    const ranges = protocolDoseRangeBySubstance(botoxBaby);
    expect(ranges.toxina_botulinica).toEqual({ min: 26, max: 40 });
  });

  it('sums the toxin dose range across Contorno em V — 40 to 60 U (masseter only)', () => {
    const vContour = getNamedProtocol('contorno_em_v')!;
    const ranges = protocolDoseRangeBySubstance(vContour);
    expect(ranges.toxina_botulinica).toEqual({ min: 40, max: 60 });
  });

  it('reports a range per substance present in a mixed protocol (Fox Eyes: toxin + HA)', () => {
    const foxEyes = getNamedProtocol('fox_eyes')!;
    const ranges = protocolDoseRangeBySubstance(foxEyes);
    expect(ranges.toxina_botulinica).toEqual({ min: 16, max: 24 });
    expect(ranges.acido_hialuronico).toEqual({ min: 1.0, max: 1.6 });
  });
});

describe('projectedDoseRangeBySubstance / protocolThresholdWarnings — interação entre protocolos', () => {
  it('projects the protocol alone (no existing points) as just its own range', () => {
    const botoxBaby = getNamedProtocol('botox_baby')!;
    expect(projectedDoseRangeBySubstance(botoxBaby, [])).toEqual({ toxina_botulinica: { min: 26, max: 40 } });
  });

  // Comitê: Botox Baby + Contorno em V (toxina no masseter) na mesma sessão
  // — ao adicionar o SEGUNDO protocolo de toxina, a soma projetada deve
  // combinar a faixa própria do protocolo sendo adicionado com a dose JÁ
  // APLICADA (concreta, não mais uma faixa) dos pontos de Botox Baby que o
  // profissional já confirmou antes.
  it('combines a second toxin protocol with points already in the session (Botox Baby already applied + Contorno em V)', () => {
    const vContour = getNamedProtocol('contorno_em_v')!;
    const existingFromBotoxBaby = protocolToApplicationPoints(getNamedProtocol('botox_baby')!, undefined, () => 'id');
    // Botox Baby nas doses sugeridas (ponto médio, arredondado à unidade):
    // terco_frontal 8 + glabela 12 + tempora_esq 7 + tempora_dir 7 = 34 U.
    const botoxBabyAppliedTotal = 34;
    expect(existingFromBotoxBaby.reduce((sum, p) => sum + p.quantity, 0)).toBe(botoxBabyAppliedTotal);

    const projected = projectedDoseRangeBySubstance(vContour, existingFromBotoxBaby);
    // Contorno em V soma 40-60 U de toxina (só o masseter) por si só —
    // combinado com os 34 U já aplicados, a projeção é 74-94 U.
    expect(projected.toxina_botulinica).toEqual({ min: 74, max: 94 });
  });

  it('does not flag a single, isolated protocol whose own sum stays under threshold', () => {
    const bocaRussa = getNamedProtocol('boca_russa')!;
    expect(protocolThresholdWarnings(bocaRussa, [])).toEqual([]);
  });

  it('flags Facelift Líquido by itself (self-caused, no existing points needed)', () => {
    const facelift = getNamedProtocol('facelift_liquido')!;
    const warnings = protocolThresholdWarnings(facelift, []);
    expect(warnings).toHaveLength(1);
    expect(warnings[0]).toMatchObject({
      substance: 'acido_hialuronico',
      threshold: DOSE_ALERT_THRESHOLD.acido_hialuronico,
      selfExceeds: true,
    });
  });

  it('flags a combined excess that neither protocol alone would cause', () => {
    const vContour = getNamedProtocol('contorno_em_v')!;
    // 90 U of toxin already applied manually this session — Contorno em V's
    // own 40-60 U stays under 100 alone, but combined it exceeds.
    const existing: ApplicationPoint[] = [point({ quantity: 90 })];
    const warnings = protocolThresholdWarnings(vContour, existing);
    expect(warnings).toHaveLength(1);
    expect(warnings[0].substance).toBe('toxina_botulinica');
    expect(warnings[0].selfExceeds).toBe(false);
    expect(warnings[0].range).toEqual({ min: 130, max: 150 });
  });
});

describe('protocolToApplicationPoints', () => {
  it('converts every ProtocolPoint into an ApplicationPoint tagged with the protocolId', () => {
    const bocaRussa = getNamedProtocol('boca_russa')!;
    const points = protocolToApplicationPoints(bocaRussa, undefined, () => 'fixed-id');
    expect(points).toHaveLength(2);
    for (const p of points) {
      expect(p.protocolId).toBe('boca_russa');
      expect(p.source).toBe('manual');
    }
  });

  it('sets the suggested (midpoint) dose and correct unit for each point', () => {
    const bocaRussa = getNamedProtocol('boca_russa')!;
    const [upper, lower] = protocolToApplicationPoints(bocaRussa, undefined, () => 'id');
    expect(upper.quantity).toBeCloseTo(0.5, 5);
    expect(upper.unit).toBe('ml');
    expect(lower.quantity).toBeCloseTo(0.4, 5);
  });

  it('falls back to the substance default depth/device when the protocol point omits them (toxin points)', () => {
    const botoxBaby = getNamedProtocol('botox_baby')!;
    const points = protocolToApplicationPoints(botoxBaby, undefined, () => 'id');
    for (const p of points) {
      expect(p.depth).toBe(SUBSTANCE_DEFAULT_DEPTH.toxina_botulinica);
      expect(p.device).toBe(SUBSTANCE_DEFAULT_DEVICE.toxina_botulinica);
      expect(p.technique).toBe('intramuscular');
    }
  });

  it('uses the explicit depth/device declared on the protocol point when present (HA points)', () => {
    const facelift = getNamedProtocol('facelift_liquido')!;
    const mentoPoint = protocolToApplicationPoints(facelift, undefined, () => 'id').find((p) => p.region === 'mento')!;
    expect(mentoPoint.depth).toBe('supraperiosteal');
    expect(mentoPoint.device).toBe('canula');
    expect(mentoPoint.technique).toBe('bolus');
  });

  it('produces two distinct points for Fox Eyes on the same region (tempora_esquerda), one per substance', () => {
    const foxEyes = getNamedProtocol('fox_eyes')!;
    let counter = 0;
    const points = protocolToApplicationPoints(foxEyes, undefined, () => `id-${counter++}`);
    const leftTempora = points.filter((p) => p.region === 'tempora_esquerda');
    expect(leftTempora).toHaveLength(2);
    expect(new Set(leftTempora.map((p) => p.id)).size).toBe(2);
    expect(new Set(leftTempora.map((p) => p.substance))).toEqual(new Set(['toxina_botulinica', 'acido_hialuronico']));
  });

  it('falls back to the region fallback position when no landmarks are available', () => {
    const bocaRussa = getNamedProtocol('boca_russa')!;
    const [upper] = protocolToApplicationPoints(bocaRussa, undefined, () => 'id');
    expect(upper.x).toBeGreaterThanOrEqual(0);
    expect(upper.x).toBeLessThanOrEqual(1);
    expect(upper.landmarkIndex).toBeUndefined();
  });

  it('uses the landmark position (and records landmarkIndex) when landmarks are available', () => {
    const bocaRussa = getNamedProtocol('boca_russa')!;
    // labio_superior's first landmark index is 13 (see faceRegions.ts).
    const landmarks = Array.from({ length: 478 }, () => ({ x: 0, y: 0 }));
    landmarks[13] = { x: 0.42, y: 0.61 };
    const [upper] = protocolToApplicationPoints(bocaRussa, landmarks, () => 'id');
    expect(upper.x).toBe(0.42);
    expect(upper.y).toBe(0.61);
    expect(upper.landmarkIndex).toBe(13);
  });
});
