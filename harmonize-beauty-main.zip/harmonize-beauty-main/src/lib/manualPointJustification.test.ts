import { describe, it, expect } from 'vitest';
import {
  mapManualPointJustificationStatsRow,
  buildManualPointJustificationDraft,
  type ManualPointJustificationStatsRow,
  type ManualPointJustificationStats,
} from './manualPointJustification';

// Chaves que nunca podem aparecer em nenhuma forma agregada devolvida por
// este arquivo — mesmo espírito de src/lib/adminIntelligence.test.ts.
const FORBIDDEN_KEYS = ['patient', 'patient_id', 'patientId', 'name', 'phone', 'professional_id', 'professionalId', 'session_id', 'sessionId'];

function assertNoForbiddenKeys(obj: object) {
  for (const key of Object.keys(obj)) {
    expect(FORBIDDEN_KEYS).not.toContain(key);
  }
}

describe('mapManualPointJustificationStatsRow', () => {
  const row = (overrides: Partial<ManualPointJustificationStatsRow> = {}): ManualPointJustificationStatsRow => ({
    avg_quantity: 1.2,
    quantity_sample_size: 8,
    avg_accuracy_rating: 4.3,
    accuracy_sample_size: 6,
    adverse_event_rate: 0.02,
    adverse_event_sample_size: 40,
    ...overrides,
  });

  it('mapeia todas as estatísticas para camelCase quando todas passam no corte de amostra mínima', () => {
    expect(mapManualPointJustificationStatsRow(row(), 5)).toEqual({
      avgQuantity: 1.2,
      quantitySampleSize: 8,
      avgAccuracyRating: 4.3,
      adverseEventRate: 0.02,
    });
  });

  it('devolve null (sem sugestão) quando a amostra da dose média — a estatística primária — está abaixo do mínimo', () => {
    expect(mapManualPointJustificationStatsRow(row({ quantity_sample_size: 3 }), 5)).toBeNull();
  });

  it('devolve null quando a RPC não devolveu linha nenhuma para a combinação (estado normal, não um erro)', () => {
    expect(mapManualPointJustificationStatsRow(null, 5)).toBeNull();
    expect(mapManualPointJustificationStatsRow(undefined, 5)).toBeNull();
  });

  it('devolve null quando avg_quantity vem nulo mesmo com sample_size presente (defesa em profundidade)', () => {
    expect(mapManualPointJustificationStatsRow(row({ avg_quantity: null }), 5)).toBeNull();
  });

  it('mantém a dose média mas zera avgAccuracyRating quando só a amostra de precisão está abaixo do mínimo', () => {
    const mapped = mapManualPointJustificationStatsRow(row({ accuracy_sample_size: 2 }), 5);
    expect(mapped).not.toBeNull();
    expect(mapped?.avgAccuracyRating).toBeNull();
    expect(mapped?.avgQuantity).toBe(1.2);
  });

  it('mantém a dose média mas zera adverseEventRate quando só a amostra de eventos adversos está abaixo do mínimo', () => {
    const mapped = mapManualPointJustificationStatsRow(row({ adverse_event_sample_size: 4 }), 5);
    expect(mapped).not.toBeNull();
    expect(mapped?.adverseEventRate).toBeNull();
    expect(mapped?.avgQuantity).toBe(1.2);
  });

  it('trata avg_accuracy_rating/adverse_event_rate nulos vindos da RPC como "sem dado", independente da amostra', () => {
    const mapped = mapManualPointJustificationStatsRow(row({ avg_accuracy_rating: null, adverse_event_rate: null }), 5);
    expect(mapped?.avgAccuracyRating).toBeNull();
    expect(mapped?.adverseEventRate).toBeNull();
  });

  it('mantém uma amostra exatamente no mínimo', () => {
    expect(mapManualPointJustificationStatsRow(row({ quantity_sample_size: 5 }), 5)).not.toBeNull();
  });

  it('nunca inclui campo de paciente/profissional/sessão no shape de retorno', () => {
    const mapped = mapManualPointJustificationStatsRow(row(), 5);
    assertNoForbiddenKeys(mapped as object);
  });
});

describe('buildManualPointJustificationDraft', () => {
  // Stub de `t` que devolve a própria chave + os parâmetros de interpolação
  // serializados — o suficiente para testar a lógica de composição (quais
  // linhas entram, com quais valores) sem depender do texto localizado real.
  const fakeT = (key: string, options?: Record<string, unknown>) =>
    options ? `${key}|${JSON.stringify(options)}` : key;

  const stats = (overrides: Partial<ManualPointJustificationStats> = {}): ManualPointJustificationStats => ({
    avgQuantity: 1.2,
    quantitySampleSize: 8,
    avgAccuracyRating: 4.3,
    adverseEventRate: 0.02,
    ...overrides,
  });

  const context = { regionLabel: 'Lábio Superior', substanceLabel: 'Ácido Hialurônico', unit: 'ml' };

  it('inclui achado, objetivo (placeholder genérico) e nota técnica de dose sempre', () => {
    const draft = buildManualPointJustificationDraft(stats({ avgAccuracyRating: null, adverseEventRate: null }), context, fakeT);
    expect(draft.finding).toContain('sessions.stage2.justificationCopilot.finding');
    expect(draft.finding).toContain('Lábio Superior');
    expect(draft.clinicalGoal).toBe('sessions.stage2.justificationCopilot.clinicalGoalPlaceholder');
    expect(draft.technicalNote).toContain('sessions.stage2.justificationCopilot.technicalNoteDose');
    expect(draft.technicalNote).toContain('"quantity":1.2');
    expect(draft.technicalNote).toContain('"unit":"ml"');
  });

  it('acrescenta a linha de precisão de simulação só quando avgAccuracyRating não é null', () => {
    const withRating = buildManualPointJustificationDraft(stats({ avgAccuracyRating: 4.3, adverseEventRate: null }), context, fakeT);
    expect(withRating.technicalNote).toContain('technicalNoteAccuracy');
    expect(withRating.technicalNote).toContain('"rating":4.3');

    const withoutRating = buildManualPointJustificationDraft(stats({ avgAccuracyRating: null, adverseEventRate: null }), context, fakeT);
    expect(withoutRating.technicalNote).not.toContain('technicalNoteAccuracy');
  });

  it('acrescenta a linha de taxa de eventos adversos só quando adverseEventRate não é null, convertendo proporção em percentual com 1 casa decimal', () => {
    const withRate = buildManualPointJustificationDraft(stats({ avgAccuracyRating: null, adverseEventRate: 0.0345 }), context, fakeT);
    expect(withRate.technicalNote).toContain('technicalNoteAdverseRate');
    expect(withRate.technicalNote).toContain('"percent":3.5');

    const withoutRate = buildManualPointJustificationDraft(stats({ avgAccuracyRating: null, adverseEventRate: null }), context, fakeT);
    expect(withoutRate.technicalNote).not.toContain('technicalNoteAdverseRate');
  });

  it('inclui as três linhas de nota técnica quando as três estatísticas estão disponíveis', () => {
    const draft = buildManualPointJustificationDraft(stats(), context, fakeT);
    expect(draft.technicalNote).toContain('technicalNoteDose');
    expect(draft.technicalNote).toContain('technicalNoteAccuracy');
    expect(draft.technicalNote).toContain('technicalNoteAdverseRate');
  });

  it('nunca menciona o paciente atual — sempre fala do padrão observado na base agregada', () => {
    const draft = buildManualPointJustificationDraft(stats(), context, fakeT);
    const fullText = `${draft.finding} ${draft.clinicalGoal} ${draft.technicalNote}`.toLowerCase();
    expect(fullText).not.toMatch(/est[ae] paciente/);
  });
});
