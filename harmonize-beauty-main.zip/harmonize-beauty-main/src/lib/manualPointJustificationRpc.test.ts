import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Não há infraestrutura de teste com Postgres real neste repositório (nenhuma
// das RPCs SECURITY DEFINER existentes — has_role, get_patient_anamnesis, as
// três da Central de Inteligência — tem teste de integração contra um banco
// vivo). Verificamos estaticamente, no texto da própria migration, as duas
// propriedades de segurança pedidas: (1) a checagem de autorização aceita
// QUALQUER profissional autenticado, não só admin; (2) o corte de amostra
// mínima (>= 5, mesmo MIN_SAMPLE_SIZE de src/lib/adminIntelligence.ts)
// acontece dentro da própria função SQL, não só em TypeScript.
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260911100000_add_manual_point_justification_stats_rpc.sql',
);
const sql = readFileSync(migrationPath, 'utf8');

// Só o CORPO executável da função (entre "AS $$" e o "$$;" de fechamento) —
// os comentários de cabeçalho do arquivo comparam de propósito com o padrão
// `has_role(auth.uid(), 'admin')` das RPCs irmãs (só pra documentar a
// diferença), então checar autorização no arquivo inteiro daria falso
// positivo. O que importa é o que a função de fato EXECUTA.
const functionBodyMatch = sql.match(/AS \$\$([\s\S]*?)\$\$;/);
if (!functionBodyMatch) throw new Error('não achou o corpo da função na migration — o regex precisa ser ajustado');
const functionBody = functionBodyMatch[1];

describe('get_manual_point_justification_stats (migration SQL)', () => {
  it('autoriza qualquer usuário autenticado — não checa role de admin como as RPCs da Central de Inteligência', () => {
    expect(functionBody).toContain('auth.uid() IS NULL');
    expect(functionBody).not.toContain("has_role(auth.uid(), 'admin')");
    expect(functionBody).not.toContain('has_role(');
  });

  it('concede EXECUTE para "authenticated" (qualquer profissional logado), nunca para PUBLIC', () => {
    expect(sql).toMatch(/REVOKE ALL ON FUNCTION public\.get_manual_point_justification_stats\(text, text\) FROM PUBLIC/);
    expect(sql).toMatch(/GRANT EXECUTE ON FUNCTION public\.get_manual_point_justification_stats\(text, text\) TO authenticated/);
  });

  it('é SECURITY DEFINER com search_path fixo (mesmo padrão de robustez das RPCs irmãs)', () => {
    expect(sql).toContain('SECURITY DEFINER');
    expect(sql).toContain('SET search_path = public');
  });

  it('aplica o corte de amostra mínima (5, mesmo MIN_SAMPLE_SIZE de src/lib/adminIntelligence.ts) à estatística primária, devolvendo nenhuma linha abaixo do corte', () => {
    expect(sql).toMatch(/v_quantity_n\s*<\s*5\s*THEN\s*\n\s*RETURN;/);
  });

  it('aplica o corte de amostra mínima independentemente às duas estatísticas secundárias (precisão de simulação e taxa de eventos adversos)', () => {
    expect(sql).toMatch(/v_accuracy_n\s*>=\s*5/);
    expect(sql).toMatch(/v_total_points_n\s*>=\s*5/);
  });

  it('nunca devolve coluna de paciente/profissional/sessão no RETURNS TABLE nem no RETURN QUERY final — só as 6 estatísticas agregadas', () => {
    const returnsTableMatch = sql.match(/RETURNS TABLE\(([\s\S]*?)\)\s*\nLANGUAGE/);
    const returnQueryMatch = sql.match(/RETURN QUERY SELECT([\s\S]*?);\nEND;/);
    expect(returnsTableMatch).not.toBeNull();
    expect(returnQueryMatch).not.toBeNull();
    for (const forbidden of ['patient_id', 'professional_id', 'session_id', 'patient_name']) {
      expect(returnsTableMatch![1]).not.toContain(forbidden);
      expect(returnQueryMatch![1]).not.toContain(forbidden);
    }
  });
});
