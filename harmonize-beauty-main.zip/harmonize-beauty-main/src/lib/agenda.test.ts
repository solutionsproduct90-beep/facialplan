import { describe, it, expect } from 'vitest';
import { normalizeAppointments, groupAppointmentsByDay, dayHeadingKind, upcomingAppointments } from './agenda';

const SCHEDULED_AT = new Date(2026, 8, 15, 14, 0).toISOString();

describe('normalizeAppointments', () => {
  it('normalizes rows with a nested patient object (single-relation join)', () => {
    const rows = [
      {
        id: 'a1',
        patient_id: 'p1',
        note: 'Retorno',
        scheduled_at: SCHEDULED_AT,
        duration_minutes: 30,
        status: 'agendado',
        patient: { name: 'Maria' },
      },
    ];
    expect(normalizeAppointments(rows)).toEqual([
      {
        id: 'a1',
        patientId: 'p1',
        patientName: 'Maria',
        note: 'Retorno',
        scheduledAt: SCHEDULED_AT,
        durationMinutes: 30,
        status: 'agendado',
      },
    ]);
  });

  it('normalizes rows where the join comes back as an array of one (PostgREST quirk)', () => {
    const rows = [
      {
        id: 'a1',
        patient_id: 'p1',
        note: null,
        scheduled_at: SCHEDULED_AT,
        duration_minutes: null,
        status: 'agendado',
        patient: [{ name: 'Maria' }],
      },
    ];
    expect(normalizeAppointments(rows)[0].patientName).toBe('Maria');
  });

  it('handles a compromisso without a linked patient ("retorno a definir")', () => {
    const rows = [
      {
        id: 'a1',
        patient_id: null,
        note: 'Retorno a definir',
        scheduled_at: SCHEDULED_AT,
        duration_minutes: null,
        status: 'agendado',
        patient: null,
      },
    ];
    const [appt] = normalizeAppointments(rows);
    expect(appt.patientId).toBeNull();
    expect(appt.patientName).toBeNull();
  });

  it('falls back to "agendado" for a missing/invalid status instead of throwing', () => {
    const rows = [
      { id: 'a1', scheduled_at: SCHEDULED_AT, status: 'made-up' },
      { id: 'a2', scheduled_at: SCHEDULED_AT },
    ];
    const result = normalizeAppointments(rows);
    expect(result[0].status).toBe('agendado');
    expect(result[1].status).toBe('agendado');
  });

  it('discards rows without an id or with an invalid scheduled_at', () => {
    const rows = [
      { scheduled_at: SCHEDULED_AT }, // sem id
      { id: 'a1', scheduled_at: 'not-a-date' },
      { id: 'a2', scheduled_at: SCHEDULED_AT, status: 'concluido' },
    ];
    const result = normalizeAppointments(rows);
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe('a2');
  });

  it('returns an empty list for non-array input', () => {
    expect(normalizeAppointments(null)).toEqual([]);
    expect(normalizeAppointments(undefined)).toEqual([]);
  });
});

describe('groupAppointmentsByDay', () => {
  const appt = (id: string, scheduledAt: string) => ({
    id,
    patientId: null,
    patientName: null,
    note: null,
    scheduledAt,
    durationMinutes: null,
    status: 'agendado' as const,
  });

  it('groups appointments by local day and sorts groups chronologically', () => {
    const groups = groupAppointmentsByDay([
      appt('a3', '2026-09-16T10:00:00'),
      appt('a1', '2026-09-15T09:00:00'),
      appt('a2', '2026-09-15T18:00:00'),
    ]);
    expect(groups.map((g) => g.dateKey)).toEqual(['2026-09-15', '2026-09-16']);
    expect(groups[0].items.map((i) => i.id)).toEqual(['a1', 'a2']); // ordenado por hora dentro do dia
    expect(groups[1].items.map((i) => i.id)).toEqual(['a3']);
  });

  it('returns an empty list for no appointments', () => {
    expect(groupAppointmentsByDay([])).toEqual([]);
  });
});

describe('dayHeadingKind', () => {
  const now = new Date(2026, 8, 15, 10, 0); // 15/set/2026, 10h

  it('classifies the current local day as "today"', () => {
    expect(dayHeadingKind('2026-09-15', now)).toBe('today');
  });

  it('classifies the next local day as "tomorrow"', () => {
    expect(dayHeadingKind('2026-09-16', now)).toBe('tomorrow');
  });

  it('classifies anything else (past or further out) as "other"', () => {
    expect(dayHeadingKind('2026-09-14', now)).toBe('other');
    expect(dayHeadingKind('2026-09-20', now)).toBe('other');
  });

  it('handles a month rollover when computing "tomorrow"', () => {
    const endOfMonth = new Date(2026, 8, 30, 23, 0); // 30/set/2026
    expect(dayHeadingKind('2026-10-01', endOfMonth)).toBe('tomorrow');
  });
});

describe('upcomingAppointments', () => {
  const appt = (id: string, scheduledAt: string, status: 'agendado' | 'concluido' | 'cancelado' = 'agendado') => ({
    id,
    patientId: null,
    patientName: null,
    note: null,
    scheduledAt: new Date(scheduledAt).toISOString(),
    durationMinutes: null,
    status,
  });

  it('sorts chronologically and excludes concluído/cancelado', () => {
    const result = upcomingAppointments([
      appt('a3', '2026-09-16T10:00:00'),
      appt('a1', '2026-09-15T09:00:00'),
      appt('done', '2026-09-15T08:00:00', 'concluido'),
      appt('cancelled', '2026-09-15T07:00:00', 'cancelado'),
      appt('a2', '2026-09-15T18:00:00'),
    ]);
    expect(result.map((a) => a.id)).toEqual(['a1', 'a2', 'a3']);
  });

  it('caps the result to `limit` (default 4)', () => {
    const items = Array.from({ length: 6 }, (_, i) => appt(`a${i}`, `2026-09-${15 + i}T10:00:00`));
    expect(upcomingAppointments(items)).toHaveLength(4);
    expect(upcomingAppointments(items, { limit: 2 })).toHaveLength(2);
  });

  it('returns an empty list when there is nothing scheduled', () => {
    expect(upcomingAppointments([])).toEqual([]);
    expect(upcomingAppointments([appt('a1', '2026-09-15T10:00:00', 'concluido')])).toEqual([]);
  });
});
