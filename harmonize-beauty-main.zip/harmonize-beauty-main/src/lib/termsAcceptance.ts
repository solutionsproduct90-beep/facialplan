// Lado-cliente do registro de aceite dos Termos de Uso e da Política de
// Privacidade no cadastro (squad w1-4).
//
// O aceite é registrado em DUAS etapas porque, no instante em que ele
// acontece, a pessoa ainda não tem conta — logo não há JWT nem user_id para
// amarrar nada. Ver o comentário longo em
// supabase/migrations/20260917093000_add_terms_acceptances.sql:
//
//   1. aqui: sorteia um token opaco e chama a edge function
//      `record-terms-acceptance`, que grava a linha com o IP e o user agent
//      REAIS vistos pelo servidor (mesmo padrão do TCLE por procedimento do
//      squad P0-3 — o IP nunca vem do cliente);
//   2. em Cadastro.tsx: o mesmo token vai em `options.data` do signUp, e o
//      trigger handle_new_user reivindica a linha assim que o usuário existe.
import { supabase } from '@/integrations/supabase/client';
import { PRIVACY_VERSION, TERMS_VERSION } from '@/lib/legalDocs';

/**
 * Sorteia o token que liga a linha de aceite ao signUp seguinte.
 *
 * `crypto.randomUUID` não existe em contexto inseguro antigo (http:// em
 * navegador velho) — o fallback mantém o formato aceito pela edge function
 * (`[A-Za-z0-9-]{20,64}`) para que o cadastro nunca quebre por causa disto.
 */
function newClaimToken(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `t-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}-${Math.random().toString(36).slice(2, 12)}`;
}

/**
 * Registra o aceite no servidor e devolve o token a ser enviado no signUp.
 *
 * NUNCA lança e NUNCA bloqueia o cadastro: se a função estiver fora do ar ou
 * a rede do consultório cair, devolve `null` e o cadastro segue — o trigger
 * grava o aceite assim mesmo, sem IP, com `source = 'cadastro_sem_ip'`, o que
 * deixa a lacuna de evidência auditável em vez de impedir alguém de criar
 * conta. Perder o IP é ruim; perder o cadastro inteiro por causa do IP é pior.
 */
export async function recordTermsAcceptance(): Promise<string | null> {
  const claimToken = newClaimToken();
  try {
    const { error } = await supabase.functions.invoke('record-terms-acceptance', {
      body: {
        claimToken,
        termsVersion: TERMS_VERSION,
        privacyVersion: PRIVACY_VERSION,
      },
    });
    if (error) return null;
    return claimToken;
  } catch {
    return null;
  }
}

/**
 * Metadados de aceite enviados em `supabase.auth.signUp({ options: { data } })`.
 *
 * As versões vão SEMPRE, mesmo quando o token é null — são elas que permitem
 * ao trigger gravar o aceite no caminho de fallback. O timestamp autoritativo
 * é o do servidor (terms_acceptances.accepted_at); não mandamos um daqui de
 * propósito, porque carimbo de tempo autodeclarado pelo cliente não serve
 * como prova.
 */
export function buildTermsAcceptanceMetadata(claimToken: string | null): Record<string, string> {
  const metadata: Record<string, string> = {
    terms_version: TERMS_VERSION,
    privacy_version: PRIVACY_VERSION,
  };
  if (claimToken) metadata.terms_claim_token = claimToken;
  return metadata;
}
