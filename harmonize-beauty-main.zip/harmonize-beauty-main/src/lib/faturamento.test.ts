import { describe, it, expect } from 'vitest';
import {
  computeMonthlyBillingSummary,
  rankSubstancesByMargin,
  buildMonthlyRevenueChartData,
  billingLookbackStart,
  type SessionForBilling,
} from './faturamento';
import type { ApplicationPoint, Insumo } from '@/types/harmonize';

const NOW = new Date(2026, 8, 15, 12, 0); // 15/set/2026

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'malar_direita',
  label: 'Malar Direita',
  substance: 'acido_hialuronico',
  quantity: 2,
  unit: 'ml',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

const insumoHA = (overrides: Partial<Insumo> = {}): Insumo => ({
  id: 'ins-ha',
  substance: 'acido_hialuronico',
  brandName: 'Juvederm Voluma',
  costPerUnit: 400,
  pricePerUnit: 1500,
  active: true,
  ...overrides,
});

const insumoToxina = (overrides: Partial<Insumo> = {}): Insumo => ({
  id: 'ins-tox',
  substance: 'toxina_botulinica',
  brandName: 'Botox',
  costPerUnit: 30,
  pricePerUnit: 100,
  active: true,
  ...overrides,
});

const session = (overrides: Partial<SessionForBilling> = {}): SessionForBilling => ({
  created_at: new Date(2026, 8, 10).toISOString(),
  status: 'complete',
  stage2_overlay: [point({ insumoId: 'ins-ha' })],
  ...overrides,
});

describe('computeMonthlyBillingSummary', () => {
  it('returns everything zeroed when there are no sessions', () => {
    expect(computeMonthlyBillingSummary([], [insumoHA()], null, NOW)).toEqual({
      sessionsCount: 0,
      revenue: 0,
      cost: 0,
      margin: 0,
      marginPct: 0,
      avgTicket: 0,
    });
  });

  it('sums revenue/cost/margin only from CLOSED sessions of the current month, ignoring open ones', () => {
    const sessions = [
      session(), // fechada, este mês -> conta
      session({ status: 'stage2', created_at: new Date(2026, 8, 11).toISOString() }), // não concluída -> ignora
      session({ created_at: new Date(2026, 7, 20).toISOString() }), // mês passado -> ignora
    ];
    const summary = computeMonthlyBillingSummary(sessions, [insumoHA()], null, NOW);
    expect(summary.sessionsCount).toBe(1);
    expect(summary.revenue).toBe(3000); // 2ml * 1500
    expect(summary.cost).toBe(800); // 2ml * 400
    expect(summary.margin).toBe(2200);
    expect(summary.marginPct).toBeCloseTo(2200 / 3000);
    expect(summary.avgTicket).toBe(3000);
  });

  it('skips closed sessions with no application points (nothing to bill yet)', () => {
    const sessions = [session({ stage2_overlay: [] })];
    expect(computeMonthlyBillingSummary(sessions, [insumoHA()], null, NOW).sessionsCount).toBe(0);
  });

  it('includes labor fee once per session and averages ticket across multiple sessions', () => {
    const sessions = [
      session({ created_at: new Date(2026, 8, 5).toISOString() }),
      session({ created_at: new Date(2026, 8, 12).toISOString(), stage2_overlay: [point({ insumoId: 'ins-ha', quantity: 1 })] }),
    ];
    const summary = computeMonthlyBillingSummary(sessions, [insumoHA()], 50, NOW);
    // sessão 1: 2ml*1500 + 50 = 3050 | sessão 2: 1ml*1500 + 50 = 1550
    expect(summary.revenue).toBe(4600);
    expect(summary.sessionsCount).toBe(2);
    expect(summary.avgTicket).toBe(2300);
  });
});

describe('rankSubstancesByMargin', () => {
  it('ranks substances by summed margin, best first, excluding labor fee entirely', () => {
    const sessions = [
      session({
        stage2_overlay: [
          point({ id: 'p1', substance: 'acido_hialuronico', insumoId: 'ins-ha', quantity: 1 }), // margem 1100
          point({ id: 'p2', substance: 'toxina_botulinica', insumoId: 'ins-tox', quantity: 10, unit: 'unidades' }), // margem 700
        ],
      }),
    ];
    const ranking = rankSubstancesByMargin(sessions, [insumoHA(), insumoToxina()], NOW);
    expect(ranking).toEqual([
      { substance: 'acido_hialuronico', label: 'Ácido Hialurônico', revenue: 1500, cost: 400, margin: 1100 },
      { substance: 'toxina_botulinica', label: 'Toxina Botulínica', revenue: 1000, cost: 300, margin: 700 },
    ]);
  });

  it('excludes points without a chosen/active insumo (unpriced) and ignores non-closed or other-month sessions', () => {
    const sessions = [
      session({ stage2_overlay: [point({ insumoId: undefined })] }),
      session({ status: 'stage2' }),
      session({ created_at: new Date(2026, 7, 1).toISOString() }),
    ];
    expect(rankSubstancesByMargin(sessions, [insumoHA()], NOW)).toEqual([]);
  });
});

describe('buildMonthlyRevenueChartData', () => {
  it('returns exactly monthsCount points in chronological order, zero-filled when a month has no revenue', () => {
    const sessions = [session({ created_at: new Date(2026, 8, 10).toISOString() })]; // set/2026
    const chart = buildMonthlyRevenueChartData(sessions, [insumoHA()], null, 6, NOW);
    expect(chart).toHaveLength(6);
    expect(chart.map((c) => c.key)).toEqual(['2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09']);
    expect(chart[5]).toEqual({ key: '2026-09', label: 'set/26', revenue: 3000 });
    expect(chart[0].revenue).toBe(0);
  });

  it('ignores sessions outside the lookback window and non-closed sessions', () => {
    const sessions = [
      session({ created_at: new Date(2025, 0, 1).toISOString() }), // muito antigo
      session({ status: 'stage2' }), // não concluída
    ];
    const chart = buildMonthlyRevenueChartData(sessions, [insumoHA()], null, 6, NOW);
    expect(chart.every((c) => c.revenue === 0)).toBe(true);
  });
});

describe('billingLookbackStart', () => {
  it('returns the 1st of the month, monthsCount-1 months before now', () => {
    expect(billingLookbackStart(6, NOW)).toEqual(new Date(2026, 3, 1));
  });
});
