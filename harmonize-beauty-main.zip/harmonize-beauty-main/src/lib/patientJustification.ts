import type { ApplicationPoint } from '@/types/harmonize';

// Formato aceito na prática para `ApplicationPoint.justification` — o tipo
// oficial em src/types/harmonize.ts já é só `JustificationParts | undefined`,
// mas `stage2_overlay` é um `Json` do Supabase (sem validação de schema em
// runtime) e a versão pública trafega um subconjunto de campos vindo da edge
// function, não o `ApplicationPoint` completo — por isso aceitamos qualquer
// shape parcial compatível aqui, não só o tipo "oficial".
type JustificationLike =
  | { finding?: unknown; clinicalGoal?: unknown; technicalNote?: unknown }
  | string
  | null
  | undefined;

export type PatientExplanation =
  | { kind: 'parts'; finding: string; clinicalGoal: string }
  | { kind: 'raw'; text: string };

/**
 * Extrai a explicação clínica voltada ao PACIENTE a partir da justificativa
 * de um ApplicationPoint — usada na tela "Apresentar" (SessaoPresent.tsx e
 * SessaoPresentPublico.tsx) para que a lista "O que será feito" deixe de ser
 * só "Região — dose de Substância" e explique o porquê de cada procedimento.
 *
 * Ao contrário de `justificationPdfText` (SessaoEstagio3.tsx, usada no PDF
 * PARA O PROFISSIONAL), esta função descarta `technicalNote` de propósito:
 * é jargão de técnica de aplicação (ex: "Aplicação em bolus retrovermelhão,
 * evitando comissuras") que não ajuda um paciente leigo a entender o
 * procedimento — `finding` + `clinicalGoal` já são escritos em linguagem
 * descritiva razoável (ex: "Volume reduzido no lábio superior" +
 * "Restaurar volume e contorno do vermelhão").
 *
 * Aceita defensivamente o formato antigo (string única) que um ponto
 * persistido antes da migração para justificativa em 3 partes ainda pode
 * trazer do banco — mesmo raciocínio de `justificationPdfText`. Pontos
 * manuais (sem justification) ou sem finding/clinicalGoal reconhecíveis
 * retornam null, e a UI simplesmente não mostra a linha de explicação.
 */
export function extractPatientExplanation(justification: JustificationLike): PatientExplanation | null {
  if (!justification) return null;
  if (typeof justification === 'string') {
    const text = justification.trim();
    return text ? { kind: 'raw', text } : null;
  }
  const finding = typeof justification.finding === 'string' ? justification.finding.trim() : '';
  const clinicalGoal = typeof justification.clinicalGoal === 'string' ? justification.clinicalGoal.trim() : '';
  if (!finding && !clinicalGoal) return null;
  return { kind: 'parts', finding, clinicalGoal };
}

/** Junta finding+clinicalGoal (ou o texto legado) em uma frase única, pronta pra UI. */
export function formatPatientExplanation(
  explanation: PatientExplanation,
  joinTemplate: (finding: string, clinicalGoal: string) => string,
): string {
  if (explanation.kind === 'raw') return explanation.text;
  if (explanation.finding && explanation.clinicalGoal) {
    return joinTemplate(explanation.finding, explanation.clinicalGoal);
  }
  return explanation.finding || explanation.clinicalGoal;
}

export type ApplicationPointJustification = ApplicationPoint['justification'];
