import type { TFunction } from 'i18next';

// Mapeia códigos de erro do Supabase Auth (AuthError.code, ver
// @supabase/auth-js/src/lib/error-codes.ts) para chaves de i18n com
// mensagens amigáveis. Sem isso, cada tela de auth mostrava `err.message`
// direto no toast — mensagens técnicas em inglês como
// "Invalid login credentials" ou "For security purposes, you can only
// request this after 57 seconds." vazavam pro usuário final sem tradução.
const AUTH_ERROR_CODE_KEYS: Record<string, string> = {
  invalid_credentials: 'auth.errors.invalidCredentials',
  email_not_confirmed: 'auth.errors.emailNotConfirmed',
  user_banned: 'auth.errors.userBanned',
  user_already_exists: 'auth.errors.userAlreadyExists',
  email_exists: 'auth.errors.userAlreadyExists',
  identity_already_exists: 'auth.errors.userAlreadyExists',
  weak_password: 'auth.errors.weakPassword',
  same_password: 'auth.errors.samePassword',
  email_address_invalid: 'auth.errors.invalidEmail',
  email_address_not_authorized: 'auth.errors.invalidEmail',
  signup_disabled: 'auth.errors.signupDisabled',
  email_provider_disabled: 'auth.errors.signupDisabled',
  session_expired: 'auth.errors.sessionExpired',
  session_not_found: 'auth.errors.sessionExpired',
  refresh_token_not_found: 'auth.errors.sessionExpired',
  over_request_rate_limit: 'auth.errors.rateLimited',
  over_email_send_rate_limit: 'auth.errors.rateLimited',
  over_sms_send_rate_limit: 'auth.errors.rateLimited',
  captcha_failed: 'auth.errors.generic',
};

// Respostas mais antigas do GoTrue (ou erros que nunca chegam a virar um
// AuthApiError com `code`, como falha de rede) não têm `code` populado —
// a mensagem crua ainda serve de pista, principalmente pro rate limit de
// reenvio/reset, que é o caso mais comum de aparecer sem `code`.
const MESSAGE_PATTERN_KEYS: Array<[RegExp, string]> = [
  [/security purposes/i, 'auth.errors.rateLimited'],
  [/rate limit/i, 'auth.errors.rateLimited'],
  [/invalid login credentials/i, 'auth.errors.invalidCredentials'],
  [/email not confirmed/i, 'auth.errors.emailNotConfirmed'],
  [/already registered/i, 'auth.errors.userAlreadyExists'],
  [/user already registered/i, 'auth.errors.userAlreadyExists'],
  [/password should be at least/i, 'auth.errors.weakPassword'],
  [/new password should be different/i, 'auth.errors.samePassword'],
  [/failed to fetch|networkerror|load failed/i, 'auth.errors.networkError'],
];

/**
 * Traduz um erro do Supabase Auth pra uma mensagem amigável no idioma atual.
 * Cai em `fallbackKey` (chave de i18n) quando não reconhece o erro — nunca
 * devolve `err.message` cru.
 */
export function translateAuthError(err: unknown, t: TFunction, fallbackKey: string): string {
  const code = (err as { code?: string } | null | undefined)?.code;
  const message = (err as { message?: string } | null | undefined)?.message;

  if (code && AUTH_ERROR_CODE_KEYS[code]) {
    return t(AUTH_ERROR_CODE_KEYS[code]);
  }

  if (message) {
    for (const [pattern, key] of MESSAGE_PATTERN_KEYS) {
      if (pattern.test(message)) return t(key);
    }
  }

  return t(fallbackKey);
}
