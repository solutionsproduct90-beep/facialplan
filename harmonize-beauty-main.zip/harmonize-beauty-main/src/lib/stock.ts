import type { InsumoCategory } from '@/types/harmonize';
import { INSUMO_CATEGORY_KEYS } from '@/types/harmonize';

// Funções puras usadas pela aba "Estoque" do /painel (controle de estoque
// "mini" em cima do cadastro de insumos/marcas já existente — ver
// comentário na migration 20260910190100_add_insumo_stock.sql). Separadas
// do componente pelo mesmo motivo de src/lib/panel.ts e src/lib/agenda.ts:
// testáveis sem montar a tela nem tocar Supabase.

/** Linha de `insumos` com as colunas de estoque, pronta pra aba Estoque renderizar. */
export type InsumoStockRow = {
  id: string;
  substance: InsumoCategory;
  brandName: string;
  active: boolean;
  quantityOnHand: number;
  lowStockThreshold: number | null;
};

/**
 * Normaliza linhas de `insumos` (com `quantity_on_hand`/`low_stock_threshold`
 * adicionados em 20260910190100_add_insumo_stock.sql) pro shape usado pela
 * aba Estoque. Mesma postura defensiva de `normalizeInsumos` em
 * src/lib/budget.ts: linha malformada é descartada, não quebra a lista
 * inteira.
 */
export function normalizeInsumoStock(raw: unknown): InsumoStockRow[] {
  if (!Array.isArray(raw)) return [];
  const out: InsumoStockRow[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.substance !== 'string' || !INSUMO_CATEGORY_KEYS.includes(r.substance as InsumoCategory)) continue;
    if (typeof r.brand_name !== 'string' || !r.brand_name) continue;
    const quantityOnHand = Number(r.quantity_on_hand);
    if (!Number.isFinite(quantityOnHand)) continue;
    const thresholdRaw = r.low_stock_threshold;
    const thresholdNum = thresholdRaw == null ? NaN : Number(thresholdRaw);
    out.push({
      id: r.id,
      substance: r.substance as InsumoCategory,
      brandName: r.brand_name,
      active: r.active !== false,
      quantityOnHand,
      lowStockThreshold: Number.isFinite(thresholdNum) ? thresholdNum : null,
    });
  }
  return out;
}

export type StockMovementForCalc = { quantityDelta: number };

/**
 * Saldo a partir de um histórico de movimentações — soma direto dos deltas
 * (positivo = entrada, negativo = saída; ver migration). Serve tanto pra
 * validar de forma independente o saldo que o trigger do banco mantém em
 * `insumos.quantity_on_hand` quanto pra uma atualização otimista no client
 * antes do refetch.
 */
export function computeStockBalance(movements: StockMovementForCalc[]): number {
  return movements.reduce((sum, m) => sum + m.quantityDelta, 0);
}

/**
 * Estoque baixo: com limiar configurado (`lowStockThreshold`), é atingir ou
 * ficar abaixo dele. Sem limiar — o caso comum numa V1 "mini", onde
 * ninguém configura isso de cara — só destaca quando o saldo está zerado
 * ou negativo, nunca um limiar inventado pelo app.
 */
export function isLowStock(quantityOnHand: number, lowStockThreshold: number | null | undefined): boolean {
  if (lowStockThreshold != null && lowStockThreshold > 0) {
    return quantityOnHand <= lowStockThreshold;
  }
  return quantityOnHand <= 0;
}
