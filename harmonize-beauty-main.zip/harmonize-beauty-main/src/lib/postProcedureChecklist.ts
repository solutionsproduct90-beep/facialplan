import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { SUBSTANCE_KEYS } from '@/types/harmonize';
import { isVascularRiskApplication } from '@/lib/faceRegions';

// Checklist de Pós-Procedimento Personalizado (ideia do squad de Produto):
// complemento AUTOMÁTICO às "Orientações pré/pós-procedimento" já existentes
// (texto livre configurado pelo profissional em Perfil.tsx, um único valor
// reaproveitado igual em toda sessão — ver hasCareInstructionsContent em
// clinicalAnalysisPdf.ts). Este checklist, em vez disso, é gerado a partir
// das substâncias de fato usadas NESTA sessão (ApplicationPoint.substance em
// stage2Overlay) — um punhado curto de cuidados genéricos e responsáveis por
// substância (ver sessions.stage3.postCareChecklist.items.* nos 5 idiomas em
// src/i18n/locales/). Não substitui o texto livre do profissional (os dois
// aparecem juntos no PDF e no compartilhamento) e não promete nada além do
// genérico — sem dosagem, sem prazo de resultado, sem garantia clínica.
//
// Consumido por SessaoEstagio3.tsx (seção do PDF + sufixo das mensagens de
// WhatsApp/e-mail) e duplicado manualmente na edge function
// send-patient-email (ver comentário lá) porque, como toda edge function
// deste projeto, ela não importa de src/ — mantenha as duas listas de itens
// em sincronia se o conteúdo mudar.
//
// Sinais de alerta de emergência (achado de Produto/segurança, 14/09): o
// alerta de zona de risco vascular do Estágio 2 (`isVascularRiskApplication`
// em `src/lib/faceRegions.ts`) só era visível ao profissional NO MOMENTO da
// aplicação — nunca chegava ao paciente depois. `hasVascularRiskWarning`/
// `postProcedureEmergencyWarning` abaixo reaproveitam o MESMO ponto marcado
// nesta sessão (nunca "essa substância pode ter risco em geral") para anexar
// uma seção extra, condicional, orientando a buscar pronto-socorro diante de
// certos sintomas — também duplicada na edge function send-patient-email.

/** Substâncias de fato usadas na sessão, deduplicadas e devolvidas na ordem
 * estável de `SUBSTANCE_KEYS` — não a ordem de criação/edição dos pontos na
 * Etapa 2 — pra o checklist não mudar de ordem entre exportações da mesma
 * sessão só porque o profissional reordenou pontos. */
export function substancesInSession(points: ApplicationPoint[] | null | undefined): Substance[] {
  if (!points || points.length === 0) return [];
  const used = new Set(points.map((point) => point.substance));
  return SUBSTANCE_KEYS.filter((substance) => used.has(substance));
}

/** Se há alguma substância na sessão pra gerar checklist — uma sessão sem
 * nenhum ponto de aplicação (ex. ainda no Estágio 2) omite a seção inteira
 * em vez de aparecer vazia, mesmo padrão de `hasCareInstructionsContent` em
 * clinicalAnalysisPdf.ts. */
export function hasPostProcedureChecklistContent(points: ApplicationPoint[] | null | undefined): boolean {
  return substancesInSession(points).length > 0;
}

export type PostProcedureChecklistSection = {
  substance: Substance;
  label: string;
  items: string[];
};

/** Monta uma seção `{substance, label, items[]}` por substância usada na
 * sessão, via a função de tradução dada (tipicamente o `t` de
 * `useTranslation()` — mesmo padrão de `procedureDisplayName` em
 * procedureCatalog.ts). `items` espera que a chave
 * `sessions.stage3.postCareChecklist.items.<substance>` resolva para um
 * array via `{ returnObjects: true }` (mesmo mecanismo já usado para
 * `sessions.stage3.messages` em SessaoEstagio3.tsx). Lista vazia quando a
 * sessão não tem nenhum ponto de aplicação. */
export function postProcedureChecklistSections(
  points: ApplicationPoint[] | null | undefined,
  translate: (key: string, options?: Record<string, unknown>) => unknown,
): PostProcedureChecklistSection[] {
  return substancesInSession(points).map((substance) => ({
    substance,
    label: translate(`sessions.stage3.postCareChecklist.substanceLabel.${substance}`) as string,
    items: translate(`sessions.stage3.postCareChecklist.items.${substance}`, { returnObjects: true }) as string[],
  }));
}

/** True se ALGUM ponto de aplicação desta sessão específica foi de fato marcado
 * como zona de risco vascular (`isVascularRiskApplication` em
 * `src/lib/faceRegions.ts` — ácido hialurônico numa das
 * HIGH_VASCULAR_RISK_REGIONS, o mesmo critério do alerta educativo do Estágio
 * 2). NUNCA "essa substância pode ter risco em geral": uma sessão só de
 * ácido hialurônico fora de zona de risco devolve false. Decide se a seção
 * de sinais de alerta de emergência aparece na tela, no PDF e no e-mail de
 * pós-procedimento. */
export function hasVascularRiskWarning(points: ApplicationPoint[] | null | undefined): boolean {
  if (!points || points.length === 0) return false;
  return points.some((point) => isVascularRiskApplication(point.region, point.substance));
}

export type PostProcedureEmergencyWarning = {
  title: string;
  intro: string;
  signs: string[];
};

/** Seção de sinais de alerta de emergência — só existe (não-null) quando
 * `hasVascularRiskWarning` é true para os pontos desta sessão. Estruturada em
 * {title, intro, signs[]} como `postProcedureChecklistSections`, pra cada
 * consumidor (PDF, texto de compartilhamento, e-mail) desenhar/formatar do
 * seu próprio jeito sem duplicar a decisão de quando incluir a seção. As
 * chaves de tradução (`sessions.stage3.postCareChecklist.emergency.*`)
 * replicam a mesma lista de sintomas já associada a risco vascular no app
 * (ver `sessions.stage2.vascularRisk.alert` nos 5 idiomas). */
export function postProcedureEmergencyWarning(
  points: ApplicationPoint[] | null | undefined,
  translate: (key: string, options?: Record<string, unknown>) => unknown,
): PostProcedureEmergencyWarning | null {
  if (!hasVascularRiskWarning(points)) return null;
  return {
    title: translate('sessions.stage3.postCareChecklist.emergency.title') as string,
    intro: translate('sessions.stage3.postCareChecklist.emergency.intro') as string,
    signs: translate('sessions.stage3.postCareChecklist.emergency.signs', { returnObjects: true }) as string[],
  };
}

/** Texto plano (título + nota + uma seção com marcadores "•" por substância,
 * mais o bloco de sinais de alerta de emergência quando aplicável) pronto
 * para ser anexado às mensagens de WhatsApp/e-mail do compartilhamento (ver
 * handleShareWhatsApp/handleShareEmail em SessaoEstagio3.tsx) — mesmo
 * mecanismo de anexação condicional já usado para o texto livre do
 * profissional (`hasCareInstructionsContent`/`shareCareInstructionsSuffix`),
 * mas para este checklist automático. String vazia quando a sessão não tem
 * nenhuma substância aplicada, para o chamador omitir o anexo inteiro sem
 * deixar `\n\n` sobrando na mensagem. */
export function postProcedureChecklistShareText(
  points: ApplicationPoint[] | null | undefined,
  translate: (key: string, options?: Record<string, unknown>) => unknown,
): string {
  const sections = postProcedureChecklistSections(points, translate);
  if (sections.length === 0) return '';
  const title = translate('sessions.stage3.postCareChecklist.title') as string;
  const note = translate('sessions.stage3.postCareChecklist.note') as string;
  const blocks = sections.map(
    ({ label, items }) => `${label.toUpperCase()}\n${items.map((item) => `• ${item}`).join('\n')}`,
  );
  const emergency = postProcedureEmergencyWarning(points, translate);
  const emergencyBlock = emergency
    ? [`${emergency.title.toUpperCase()}\n${emergency.intro}\n${emergency.signs.map((sign) => `• ${sign}`).join('\n')}`]
    : [];
  return [`${title}:`, note, ...blocks, ...emergencyBlock].join('\n\n');
}
