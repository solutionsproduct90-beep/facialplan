// Protocolos Nomeados — pacotes reconhecíveis de mercado (ex. "Boca Russa",
// "Botox Baby") definidos por um comitê técnico simulado a partir de
// pesquisa real na web (fontes citadas por protocolo, ver comentário em
// cada entrada de NAMED_PROTOCOLS abaixo), cada um combinando múltiplos
// pontos de aplicação — possivelmente de mais de uma substância — para
// alcançar um resultado estético específico, em vez de um único
// ponto/substância como no catálogo de Procedimentos nomeados
// (src/lib/procedureCatalog.ts, backlog #47).
//
// DELIBERADAMENTE PARALELO a NamedProcedure, não uma extensão dele: o
// comitê recomendou explicitamente não forçar protocolos multi-ponto/
// multi-substância dentro do tipo NamedProcedure existente (desenhado para
// 1 substância + 1-2 regiões) — ver o comentário de arquivo em
// procedureCatalog.ts. NamedProtocol reaproveita os mesmos tipos de base
// (DoseRange, FaceRegionKey, Substance, ApplicationTechnique/Depth/Device)
// em vez de duplicá-los.
//
// AVISO GERAL — PONTO DE PARTIDA DE PESQUISA, NÃO VALIDAÇÃO CLÍNICA: as
// faixas de dose/técnica abaixo vieram de pesquisa (artigos de clínicas,
// papers, guias de injetoras — fontes por protocolo nos comentários
// abaixo), não de um consenso clínico formal nem de bula de produto. O
// texto completo desse aviso (exibido na UI sempre que um protocolo é
// usado) vive em `namedProtocols.committeeDisclaimer` nos arquivos de
// i18n — mesmo espírito de ressalva não-bloqueante já usado em
// DOSE_ALERT_THRESHOLD (src/types/harmonize.ts) e HIGH_VASCULAR_RISK_REGIONS
// (src/lib/faceRegions.ts): um ponto de partida sempre editável, nunca um
// limite regulatório.
import type {
  ApplicationPoint,
  ApplicationDepth,
  ApplicationDevice,
  ApplicationTechnique,
  Substance,
} from '@/types/harmonize';
import {
  SUBSTANCE_DEFAULT_DEPTH,
  SUBSTANCE_DEFAULT_DEVICE,
  SUBSTANCE_DEFAULT_TECHNIQUE,
  SUBSTANCE_DEFAULT_UNIT,
  DOSE_ALERT_THRESHOLD,
  isDoseOverThreshold,
  sumDoseBySubstance,
} from '@/types/harmonize';
import type { FaceRegionKey } from '@/lib/faceRegions';
import { FACE_REGION_KEYS, landmarkPositionForRegion, regionFallbackPosition, regionLabel } from '@/lib/faceRegions';
import type { DoseRange } from '@/lib/procedureCatalog';

export type { DoseRange };

/** Um ponto de aplicação sugerido dentro de um protocolo — mesma forma de
 * dado de um ApplicationPoint pré-confirmação, mas sem posição (x/y — só
 * resolvida ao converter para ApplicationPoint de verdade, contra os
 * landmarks reais da foto) nem quantidade fixa (uma faixa, não um número —
 * ver DoseRange em procedureCatalog.ts). `technique` é sempre declarado
 * explicitamente pelos dados de pesquisa abaixo; `depth`/`device` só para
 * ácido hialurônico (onde a escolha cânula/agulha e o plano de aplicação
 * são clinicamente centrais) — ausentes num ponto de toxina caem no
 * SUBSTANCE_DEFAULT_DEPTH/DEVICE de sempre (ver protocolToApplicationPoints
 * abaixo), igual ao que já acontece hoje para qualquer ApplicationPoint sem
 * esses campos.
 */
export type ProtocolPoint = {
  region: FaceRegionKey;
  substance: Substance;
  doseRange: DoseRange;
  technique?: ApplicationTechnique;
  depth?: ApplicationDepth;
  device?: ApplicationDevice;
};

export type NamedProtocol = {
  id: string;
  /** Nome em português — fonte da chave de tradução
   * `namedProtocols.protocols.<id>.name` (ver protocolNameKey abaixo) e
   * `defaultValue` enquanto a tradução do idioma ativo não estiver
   * completa — mesmo padrão de fallback de procedureDisplayName em
   * procedureCatalog.ts. */
  name: string;
  description: string;
  points: ProtocolPoint[];
  /** Contraindicações e observações de segurança específicas deste
   * protocolo (além de toda contraindicação geral já associada a cada
   * substância/região individualmente) — levantadas junto com as faixas de
   * dose na mesma pesquisa, não uma lista clinicamente exaustiva. */
  contraindications: string[];
  /** Nota de variação esperada entre o resultado simulado e o real —
   * alguns protocolos (ex. Fox Eyes, que é um efeito buscado sem
   * dose-padrão publicada) variam mais que outros. */
  varianceNote: string;
  /** true quando a SOMA das faixas do próprio protocolo (sem nenhum outro
   * ponto da sessão) já ultrapassa DOSE_ALERT_THRESHOLD de alguma
   * substância POR DESENHO (ex. Facelift Líquido, que soma 6.4–10.0 mL de
   * AH contra um limiar de 6 mL) — usado para sinalizar isso PROATIVAMENTE
   * na própria tela de seleção do protocolo, antes de aplicar os pontos,
   * em vez de esperar o alerta padrão da Etapa 2 (que só aparece depois
   * que os pontos já estão inseridos). Ausente/false para todo protocolo
   * cuja soma própria fica dentro da referência de atenção — ver também
   * protocolThresholdWarnings() abaixo, que recalcula isso dinamicamente
   * (inclusive combinado com pontos já existentes na sessão), tornando este
   * campo estático redundante com o cálculo mas útil como documentação de
   * dados e para o teste de bem-formação não depender só do cálculo.
   */
  exceedsDefaultThreshold?: boolean;
};

const round2 = (n: number): number => Math.round(n * 100) / 100;

function doseStepFor(substance: Substance): number {
  return SUBSTANCE_DEFAULT_UNIT[substance] === 'unidades' ? 1 : 0.1;
}

/**
 * Dose sugerida (ponto médio da faixa) para pré-preencher um ponto de
 * aplicação convertido a partir de um ProtocolPoint — arredondada ao mesmo
 * "step" de quantidade já usado no editor da Etapa 2 (1 unidade para
 * toxina, 0.1 ml para as demais substâncias). Mesma lógica de
 * suggestedDoseForLevel em procedureCatalog.ts, mas a partir de um
 * DoseRange solto em vez de um NamedProcedure.doseRangeByLevel.
 */
export function suggestedDoseForProtocolPoint(point: ProtocolPoint): number {
  const mid = (point.doseRange.min + point.doseRange.max) / 2;
  const step = doseStepFor(point.substance);
  return Math.round(mid / step) * step;
}

// ---------------------------------------------------------------------------
// Os 6 protocolos — dados levantados pelo comitê técnico simulado (pesquisa
// real na web, fontes por protocolo abaixo). Faixas de dose sempre um
// PONTO DE PARTIDA editável, nunca uma prescrição — ver aviso de arquivo
// acima.
// ---------------------------------------------------------------------------
export const NAMED_PROTOCOLS: NamedProtocol[] = [
  {
    // Fontes: artigos de clínicas e guias de injetoras sobre a técnica
    // "Boca Russa" (ênfase em altura/arco do cupido via fanning
    // submucoso, faixas de 0.3-0.6 mL por lábio para um resultado
    // esculpido, não aumentado em volume total).
    id: 'boca_russa',
    name: 'Boca Russa',
    description:
      'Técnica de preenchimento labial que prioriza altura e formato de coração do lábio (arco do cupido), resultado mais esculpido que inchado.',
    points: [
      { region: 'labio_superior', substance: 'acido_hialuronico', doseRange: { min: 0.4, max: 0.6 }, technique: 'fanning', depth: 'submucoso', device: 'agulha' },
      { region: 'labio_inferior', substance: 'acido_hialuronico', doseRange: { min: 0.3, max: 0.5 }, technique: 'fanning', depth: 'submucoso', device: 'agulha' },
    ],
    contraindications: [
      'Histórico de herpes labial recorrente — o trauma da agulha pode reativar o vírus.',
      'Por desenho, este protocolo não inclui a comissura labial (região de alto risco vascular).',
    ],
    varianceNote:
      'O resultado depende muito da anatomia de base da paciente (altura de mucosa, proporção entre lábio superior e inferior).',
  },
  {
    // Fontes: bula da BOTOX Cosmetic (FDA) e guias de "baby botox" — doses
    // reduzidas (cerca de metade das faixas cheias por região) para
    // suavizar linhas preservando movimento, terço frontal/glabela/têmporas
    // (reaproveitando a mesma região de têmpora já usada para "pés de
    // galinha" no catálogo de Procedimentos nomeados, ver
    // toxina_pes_de_galinha em procedureCatalog.ts).
    id: 'botox_baby',
    name: 'Botox Baby',
    description:
      'Toxina em doses reduzidas na testa, entre sobrancelhas e ao redor dos olhos, suaviza linhas preservando movimento natural — sem efeito congelado.',
    points: [
      { region: 'terco_frontal', substance: 'toxina_botulinica', doseRange: { min: 6, max: 10 }, technique: 'intramuscular' },
      { region: 'glabela', substance: 'toxina_botulinica', doseRange: { min: 10, max: 14 }, technique: 'intramuscular' },
      { region: 'tempora_esquerda', substance: 'toxina_botulinica', doseRange: { min: 5, max: 8 }, technique: 'intramuscular' },
      { region: 'tempora_direita', substance: 'toxina_botulinica', doseRange: { min: 5, max: 8 }, technique: 'intramuscular' },
    ],
    contraindications: [
      'Doença neuromuscular (ex. miastenia gravis) — contraindicação padrão de toxina botulínica.',
      'Gestação e lactação — contraindicação padrão de toxina botulínica.',
    ],
    varianceNote:
      'A mesma dose gera um efeito mais ou menos perceptível dependendo da força muscular basal da paciente — ajuste conforme avaliação dinâmica.',
  },
  {
    // Fontes: artigos de clínicas sobre a tendência estética "Fox Eyes" —
    // combinação de toxina lateral (depressores/orbicular) com bolus de AH
    // supraperiosteal na têmpora para sustentação. Sem dose-padrão
    // publicada em bula (é um efeito buscado, não um procedimento único) —
    // faixas conservadoras a partir do consenso encontrado.
    id: 'fox_eyes',
    name: 'Fox Eyes',
    description:
      'Combinação de toxina e preenchimento que suaviza o puxão pra baixo no canto externo do olho e dá sustentação na têmpora, efeito de olhar alongado e levantado.',
    points: [
      { region: 'tempora_esquerda', substance: 'toxina_botulinica', doseRange: { min: 8, max: 12 }, technique: 'intramuscular' },
      { region: 'tempora_direita', substance: 'toxina_botulinica', doseRange: { min: 8, max: 12 }, technique: 'intramuscular' },
      // Mesma região (tempora_*) da toxina acima, MAS uma substância e
      // profundidade diferentes — dois pontos distintos por desenho, não um
      // conflito de dado (ver ATENÇÃO DE IMPLEMENTAÇÃO no PR/comitê): a UI
      // (SessaoEstagio2) precisa listar os dois separadamente.
      { region: 'tempora_esquerda', substance: 'acido_hialuronico', doseRange: { min: 0.5, max: 0.8 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
      { region: 'tempora_direita', substance: 'acido_hialuronico', doseRange: { min: 0.5, max: 0.8 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
    ],
    contraindications: [
      'Proximidade do ramo temporal do nervo facial — requer mão experiente.',
      'Risco de "inflar" a têmpora se a dose de preenchimento for excessiva — comece pela faixa mínima.',
    ],
    varianceNote:
      'Não existe dose-padrão publicada para "Fox Eyes" — é um efeito buscado, não uma bula — por isso a variação de resultado aqui é maior que nos demais protocolos.',
  },
  {
    // Fontes: artigos sobre afinamento de mandíbula com toxina no masseter
    // (faixas usuais de 20-30 U/lado) combinado a projeção de mento com AH
    // supraperiosteal em bolus.
    id: 'contorno_em_v',
    name: 'Contorno em V',
    description:
      'Toxina no masseter pra afinar o ângulo da mandíbula, combinada com preenchimento no queixo pra projetar e alongar a ponta — contorno de rosto mais afilado.',
    points: [
      { region: 'mandibula_esquerda', substance: 'toxina_botulinica', doseRange: { min: 20, max: 30 }, technique: 'intramuscular' },
      { region: 'mandibula_direita', substance: 'toxina_botulinica', doseRange: { min: 20, max: 30 }, technique: 'intramuscular' },
      { region: 'mento', substance: 'acido_hialuronico', doseRange: { min: 1.0, max: 2.0 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
    ],
    contraindications: [
      'Bruxismo/DTM é indicação, não contraindicação, mas exige avaliação funcional prévia.',
      'Dose excessiva no masseter pode comprometer a força de mastigação.',
    ],
    varianceNote:
      'O efeito pleno do masseter só é visível em 8 a 12 semanas — a simulação mostra a projeção estimada do resultado, não o tempo de instalação.',
  },
  {
    // Fontes: artigos sobre "facelift líquido" (têmporas + malar +
    // mandíbula + mento com AH) como levantamento não cirúrgico por reforço
    // volumétrico multi-região. Soma das faixas ultrapassa por desenho o
    // limiar de atenção de AH do app (6 mL) — ver exceedsDefaultThreshold.
    id: 'facelift_liquido',
    name: 'Facelift Líquido',
    description:
      'Preenchimento em várias áreas (têmporas, bochechas, mandíbula, queixo) pra repor volume e suavizar contorno — levantamento sem cirurgia.',
    points: [
      { region: 'tempora_esquerda', substance: 'acido_hialuronico', doseRange: { min: 0.7, max: 1.0 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
      { region: 'tempora_direita', substance: 'acido_hialuronico', doseRange: { min: 0.7, max: 1.0 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
      { region: 'malar_esquerda', substance: 'acido_hialuronico', doseRange: { min: 1.0, max: 1.5 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
      { region: 'malar_direita', substance: 'acido_hialuronico', doseRange: { min: 1.0, max: 1.5 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
      { region: 'mandibula_esquerda', substance: 'acido_hialuronico', doseRange: { min: 1.0, max: 1.5 }, technique: 'linear_retrograda', depth: 'subcutaneo', device: 'canula' },
      { region: 'mandibula_direita', substance: 'acido_hialuronico', doseRange: { min: 1.0, max: 1.5 }, technique: 'linear_retrograda', depth: 'subcutaneo', device: 'canula' },
      { region: 'mento', substance: 'acido_hialuronico', doseRange: { min: 1.0, max: 2.0 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
    ],
    exceedsDefaultThreshold: true,
    contraindications: [
      'Toda contraindicação geral de ácido hialurônico se aplica a cada um dos pontos — maior superfície de risco cumulativo por ser um protocolo de várias regiões.',
    ],
    varianceNote:
      'A variação entre o resultado simulado e o real tende a ser proporcionalmente maior aqui (4 regiões, efeito cumulativo) do que em protocolos de uma região só.',
  },
  {
    // Fontes: artigos sobre preenchimento de olheira (sulco lacrimal) em
    // técnica de cânula/plano profundo combinado a leve suporte malar para
    // suavizar a transição pálpebra-bochecha.
    id: 'olhar_descansado',
    name: 'Olhar Descansado',
    description:
      'Preenchimento da olheira combinado com leve suporte na maçã do rosto, suaviza a transição pálpebra-bochecha e reduz sombra de olheira funda.',
    points: [
      // TODO(comitê): avaliar se olheira_esquerda/olheira_direita deveriam
      // entrar em HIGH_VASCULAR_RISK_REGIONS (src/lib/faceRegions.ts) — é
      // uma das regiões mais arriscadas tecnicamente (proximidade da
      // artéria angular, pele fina), mas ainda não está na lista hoje.
      // Sugestão do comitê, não obrigatória para este squad — deixada como
      // comentário para não mexer na lista de risco vascular fora deste
      // escopo (a técnica de cânula + plano profundo já indicados abaixo
      // reduzem, mas não eliminam, o risco).
      { region: 'olheira_esquerda', substance: 'acido_hialuronico', doseRange: { min: 0.3, max: 0.5 }, technique: 'linear_retrograda', depth: 'supraperiosteal', device: 'canula' },
      { region: 'olheira_direita', substance: 'acido_hialuronico', doseRange: { min: 0.3, max: 0.5 }, technique: 'linear_retrograda', depth: 'supraperiosteal', device: 'canula' },
      { region: 'malar_esquerda', substance: 'acido_hialuronico', doseRange: { min: 0.5, max: 0.8 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
      { region: 'malar_direita', substance: 'acido_hialuronico', doseRange: { min: 0.5, max: 0.8 }, technique: 'bolus', depth: 'supraperiosteal', device: 'canula' },
    ],
    contraindications: [
      'Olheira é uma das regiões mais arriscadas tecnicamente (proximidade da artéria angular, pele fina) — a técnica de cânula e o plano profundo indicados aqui reduzem, mas não eliminam, esse risco.',
    ],
    varianceNote:
      'Olheira com componente pigmentar ou muscular não responde bem a preenchimento isolado — o resultado real pode divergir bastante da simulação nesses casos.',
  },
];

export function getNamedProtocol(id: string | undefined): NamedProtocol | undefined {
  if (!id) return undefined;
  return NAMED_PROTOCOLS.find((p) => p.id === id);
}

/** Todo protocolo referencia só regiões válidas de FACE_REGION_KEYS e faixas
 * de dose coerentes (min > 0, min <= max) — validado em runtime pelo mesmo
 * motivo de isWellFormedCatalog em procedureCatalog.ts: dado estático
 * editado à mão, propenso a erro de digitação ao crescer a lista. */
export function isWellFormedProtocols(protocols: NamedProtocol[] = NAMED_PROTOCOLS): boolean {
  const knownRegions = new Set<string>(FACE_REGION_KEYS);
  return protocols.every(
    (p) =>
      p.points.length > 0 &&
      p.points.every(
        (pt) => knownRegions.has(pt.region) && pt.doseRange.min > 0 && pt.doseRange.min <= pt.doseRange.max,
      ),
  );
}

export function protocolNameKey(id: string): string {
  return `namedProtocols.protocols.${id}.name`;
}

export function protocolDescriptionKey(id: string): string {
  return `namedProtocols.protocols.${id}.description`;
}

export function protocolVarianceNoteKey(id: string): string {
  return `namedProtocols.protocols.${id}.varianceNote`;
}

export function protocolContraindicationsKey(id: string): string {
  return `namedProtocols.protocols.${id}.contraindications`;
}

type Translate = (key: string, options?: Record<string, unknown>) => unknown;

/** Nome exibível do protocolo, resolvido via `translate` (tipicamente o `t`
 * de `useTranslation()`) com fallback para o nome em português cadastrado —
 * mesmo padrão de procedureDisplayName em procedureCatalog.ts. */
export function protocolDisplayName(id: string | undefined, translate: Translate): string | undefined {
  const protocol = getNamedProtocol(id);
  if (!protocol) return undefined;
  return translate(protocolNameKey(protocol.id), { defaultValue: protocol.name }) as string;
}

export function protocolDisplayDescription(id: string | undefined, translate: Translate): string | undefined {
  const protocol = getNamedProtocol(id);
  if (!protocol) return undefined;
  return translate(protocolDescriptionKey(protocol.id), { defaultValue: protocol.description }) as string;
}

export function protocolDisplayVarianceNote(id: string | undefined, translate: Translate): string | undefined {
  const protocol = getNamedProtocol(id);
  if (!protocol) return undefined;
  return translate(protocolVarianceNoteKey(protocol.id), { defaultValue: protocol.varianceNote }) as string;
}

/** Contraindicações traduzidas (array) do protocolo, com fallback para a
 * lista em português cadastrada — usa `returnObjects: true` (mesmo padrão
 * já usado em outras telas do app para listas traduzidas, ex.
 * `sessions.stage3.messages` em SessaoEstagio3.tsx). */
export function protocolDisplayContraindications(id: string | undefined, translate: Translate): string[] {
  const protocol = getNamedProtocol(id);
  if (!protocol) return [];
  const translated = translate(protocolContraindicationsKey(protocol.id), {
    returnObjects: true,
    defaultValue: protocol.contraindications,
  });
  return Array.isArray(translated) ? (translated as string[]) : protocol.contraindications;
}

/** Soma das faixas de dose (min e max somados separadamente) do PRÓPRIO
 * protocolo, por substância — ex. Facelift Líquido soma 6.4–10.0 mL de AH.
 * Base de projectedDoseRangeBySubstance abaixo, e do campo estático
 * `exceedsDefaultThreshold`. */
export function protocolDoseRangeBySubstance(protocol: NamedProtocol): Partial<Record<Substance, DoseRange>> {
  const totals: Partial<Record<Substance, DoseRange>> = {};
  for (const pt of protocol.points) {
    const prev = totals[pt.substance] ?? { min: 0, max: 0 };
    totals[pt.substance] = {
      min: round2(prev.min + pt.doseRange.min),
      max: round2(prev.max + pt.doseRange.max),
    };
  }
  return totals;
}

/**
 * Soma projetada por substância ao aplicar `protocol` NUMA sessão que já
 * tem `existingPoints` — soma a dose já presente na sessão (qualquer
 * origem: manual, IA ou outro protocolo já aplicado) à faixa do próprio
 * protocolo. Base do alerta de "interação entre protocolos" (item do
 * comitê): dois protocolos de toxina na mesma sessão podem somar perto do
 * limiar de 100 U mesmo que nenhum dos dois isoladamente o ultrapasse.
 * Só inclui substâncias presentes no protocolo sendo adicionado — uma
 * substância só nos pontos já existentes (sem nenhum ponto no protocolo)
 * não é o que o profissional está prestes a decidir aqui.
 */
export function projectedDoseRangeBySubstance(
  protocol: NamedProtocol,
  existingPoints: ApplicationPoint[],
): Partial<Record<Substance, DoseRange>> {
  const existingTotals = sumDoseBySubstance(existingPoints);
  const ownRanges = protocolDoseRangeBySubstance(protocol);
  const result: Partial<Record<Substance, DoseRange>> = {};
  (Object.keys(ownRanges) as Substance[]).forEach((substance) => {
    const range = ownRanges[substance]!;
    const existing = existingTotals[substance] ?? 0;
    result[substance] = { min: round2(range.min + existing), max: round2(range.max + existing) };
  });
  return result;
}

/**
 * Substâncias cuja soma PROJETADA (protocolo + pontos já existentes na
 * sessão) ultrapassa DOSE_ALERT_THRESHOLD — usado para decidir se a tela de
 * seleção do protocolo mostra o alerta de excesso PROATIVAMENTE, antes de
 * aplicar os pontos, em vez de esperar o alerta padrão da Etapa 2. Cada
 * entrada também diz se o excesso já vem do protocolo sozinho
 * (`selfExceeds`, ex. Facelift Líquido) ou só aparece ao combinar com
 * pontos já existentes (ex. um segundo protocolo de toxina na mesma
 * sessão) — mesmo não-bloqueante de sempre: quem decide se prossegue é o
 * profissional.
 */
export function protocolThresholdWarnings(
  protocol: NamedProtocol,
  existingPoints: ApplicationPoint[] = [],
): Array<{ substance: Substance; range: DoseRange; threshold: number; selfExceeds: boolean }> {
  const projected = projectedDoseRangeBySubstance(protocol, existingPoints);
  const ownRanges = protocolDoseRangeBySubstance(protocol);
  const warnings: Array<{ substance: Substance; range: DoseRange; threshold: number; selfExceeds: boolean }> = [];
  (Object.keys(projected) as Substance[]).forEach((substance) => {
    const range = projected[substance]!;
    if (isDoseOverThreshold(substance, range.max) || isDoseOverThreshold(substance, range.min)) {
      const ownRange = ownRanges[substance]!;
      warnings.push({
        substance,
        range,
        threshold: DOSE_ALERT_THRESHOLD[substance],
        selfExceeds: isDoseOverThreshold(substance, ownRange.min),
      });
    }
  });
  return warnings;
}

/**
 * Converte os ProtocolPoint de um protocolo em ApplicationPoint de verdade,
 * prontos para entrar em `stage2_overlay` — cada um com posição resolvida
 * contra os landmarks reais da foto (mesma função landmarkPositionForRegion
 * já usada pelo restante da Etapa 2), quantidade sugerida (ponto médio da
 * faixa, ver suggestedDoseForProtocolPoint), técnica/profundidade/
 * dispositivo com fallback para o padrão da substância quando o protocolo
 * não especifica (hoje só relevante para depth/device de toxina), `source:
 * 'manual'` (é uma escolha do profissional, não uma sugestão de IA) e
 * `protocolId` marcando a origem. Nunca trava nada — todo campo aqui é só
 * o ponto de partida, livremente editável depois como qualquer outro ponto
 * (mesmo contrato de `procedureId`/NamedProcedure).
 */
function defaultProtocolPointId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `protocol-${Date.now()}-${Math.random()}`;
}

export function protocolToApplicationPoints(
  protocol: NamedProtocol,
  landmarks: { x: number; y: number }[] | undefined,
  makeId: () => string = defaultProtocolPointId,
): ApplicationPoint[] {
  return protocol.points.map((pt): ApplicationPoint => {
    const fromLandmark = landmarkPositionForRegion(pt.region, landmarks);
    const fallback = regionFallbackPosition(pt.region);
    return {
      id: makeId(),
      region: pt.region,
      label: regionLabel(pt.region),
      substance: pt.substance,
      quantity: suggestedDoseForProtocolPoint(pt),
      unit: SUBSTANCE_DEFAULT_UNIT[pt.substance],
      x: fromLandmark?.x ?? fallback.x,
      y: fromLandmark?.y ?? fallback.y,
      landmarkIndex: fromLandmark?.landmarkIndex,
      source: 'manual',
      technique: pt.technique ?? SUBSTANCE_DEFAULT_TECHNIQUE[pt.substance],
      depth: pt.depth ?? SUBSTANCE_DEFAULT_DEPTH[pt.substance],
      device: pt.device ?? SUBSTANCE_DEFAULT_DEVICE[pt.substance],
      protocolId: protocol.id,
    };
  });
}
