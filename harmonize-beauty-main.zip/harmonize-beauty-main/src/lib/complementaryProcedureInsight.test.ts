import { describe, it, expect } from 'vitest';
import {
  mapComplementaryProcedureInsightRow,
  complementaryProcedureInsightText,
} from './complementaryProcedureInsight';

describe('mapComplementaryProcedureInsightRow', () => {
  it('devolve a chave do procedimento complementar quando a RPC devolve uma linha com dado', () => {
    expect(mapComplementaryProcedureInsightRow({ complementary_procedure_key: 'preenchimento_malar' })).toBe(
      'preenchimento_malar',
    );
  });

  it('devolve null quando não há linha nenhuma (RPC sem amostra suficiente — estado normal)', () => {
    expect(mapComplementaryProcedureInsightRow(null)).toBeNull();
    expect(mapComplementaryProcedureInsightRow(undefined)).toBeNull();
  });

  it('devolve null quando a linha existe mas a chave vem vazia/nula', () => {
    expect(mapComplementaryProcedureInsightRow({ complementary_procedure_key: null })).toBeNull();
    expect(mapComplementaryProcedureInsightRow({ complementary_procedure_key: '' })).toBeNull();
  });
});

describe('complementaryProcedureInsightText', () => {
  const translate = (key: string, options?: Record<string, unknown>) => {
    if (key === 'sessions.stage2.complementaryProcedureInsight.text') {
      return `Pacientes com ${options?.selectedProcedure} combinam com frequência com ${options?.complementaryProcedure}.`;
    }
    // Mesmo padrão de fallback de procedureDisplayName: devolve o defaultValue passado.
    return (options?.defaultValue as string) ?? key;
  };

  it('monta o texto do insight com os dois nomes de procedimento resolvidos', () => {
    const text = complementaryProcedureInsightText('preenchimento_labial', 'preenchimento_malar', translate);
    expect(text).toBe('Pacientes com Preenchimento Labial combinam com frequência com Preenchimento Malar.');
  });

  it('devolve undefined quando o procedimento selecionado não existe (mais) no catálogo', () => {
    expect(complementaryProcedureInsightText('procedimento_removido', 'preenchimento_malar', translate)).toBeUndefined();
  });

  it('devolve undefined quando o procedimento complementar devolvido pela RPC não existe (mais) no catálogo', () => {
    expect(complementaryProcedureInsightText('preenchimento_labial', 'procedimento_removido', translate)).toBeUndefined();
  });
});
