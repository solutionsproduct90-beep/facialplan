import { describe, it, expect, vi } from 'vitest';
import { fetchAllRows, SUPABASE_MAX_ROWS_PER_RESPONSE } from './fetchAllRows';

/**
 * Regressão do ciclo 86 do QA Contínuo.
 *
 * O PostgREST trunca no teto de linhas por resposta em silêncio: devolve
 * `error: null` com as primeiras N linhas. Telas de admin que agregavam no
 * cliente calculavam sobre esse recorte sem saber.
 */
describe('fetchAllRows', () => {
  /** Tabela dublê de `total` linhas, servida em faixas. */
  const tabela = (total: number, pageSize: number) =>
    vi.fn(async (from: number, to: number) => {
      const fatia = Array.from({ length: Math.max(0, Math.min(to, total - 1) - from + 1) }, (_, i) => ({
        id: from + i,
      }));
      return { data: fatia, error: null };
    });

  it('traz todas as linhas quando há mais de uma página', async () => {
    const runPage = tabela(2500, 1000);

    const linhas = await fetchAllRows<{ id: number }>(runPage, 1000);

    expect(linhas).toHaveLength(2500);
    // 3 páginas: 1000 + 1000 + 500 (a última incompleta encerra o laço).
    expect(runPage).toHaveBeenCalledTimes(3);
    expect(linhas[0].id).toBe(0);
    expect(linhas[2499].id).toBe(2499);
  });

  it('para na primeira página quando a tabela cabe nela', async () => {
    const runPage = tabela(10, 1000);

    const linhas = await fetchAllRows<{ id: number }>(runPage, 1000);

    expect(linhas).toHaveLength(10);
    expect(runPage).toHaveBeenCalledTimes(1);
  });

  it('não pede outra página quando a tabela tem exatamente o tamanho de uma', async () => {
    // Caso de borda real: com 1000 linhas exatas, a primeira página vem cheia,
    // então é preciso pedir a segunda para descobrir que acabou.
    const runPage = tabela(1000, 1000);

    const linhas = await fetchAllRows<{ id: number }>(runPage, 1000);

    expect(linhas).toHaveLength(1000);
    expect(runPage).toHaveBeenCalledTimes(2);
  });

  it('tabela vazia devolve lista vazia, sem laço', async () => {
    const runPage = tabela(0, 1000);

    expect(await fetchAllRows<{ id: number }>(runPage, 1000)).toEqual([]);
    expect(runPage).toHaveBeenCalledTimes(1);
  });

  it('relança o erro em vez de devolver dado parcial', async () => {
    // Meio relatório é pior que um erro visível: a metade tem a mesma
    // aparência do todo, que é exatamente o defeito corrigido aqui.
    const runPage = vi
      .fn()
      .mockResolvedValueOnce({ data: Array.from({ length: 1000 }, (_, i) => ({ id: i })), error: null })
      .mockResolvedValueOnce({ data: null, error: new Error('falha na segunda página') });

    await expect(fetchAllRows<{ id: number }>(runPage, 1000)).rejects.toThrow('falha na segunda página');
  });

  it('o teto padrão é o do PostgREST', () => {
    expect(SUPABASE_MAX_ROWS_PER_RESPONSE).toBe(1000);
  });
});
