import { describe, it, expect } from 'vitest';
import {
  computeSessionComplianceSummary,
  fingerprintConsentText,
  type SessionComplianceInput,
} from './complianceSummary';
import type { ApplicationPoint } from '@/types/harmonize';

function point(overrides: Partial<ApplicationPoint>): ApplicationPoint {
  return {
    id: 'p1',
    region: 'testa',
    label: 'Testa',
    substance: 'toxina_botulinica',
    quantity: 10,
    unit: 'unidades',
    x: 0.5,
    y: 0.3,
    source: 'manual',
    ...overrides,
  };
}

const FULLY_COMPLIANT_INPUT: SessionComplianceInput = {
  sessionId: 'sess-1',
  sessionCreatedAt: '2026-05-01T10:00:00.000Z',
  applicationPoints: [point({ region: 'testa', substance: 'toxina_botulinica', quantity: 20 })],
  skinScreening: {
    hasSuspiciousFinding: false,
    referredToDermatology: false,
    proceededDespiteFinding: false,
    proceedJustification: null,
    updatedAt: '2026-05-01T09:00:00.000Z',
  },
  anamnesisCreatedAt: '2026-04-01T00:00:00.000Z',
  patientConsentGiven: true,
  patientLastConsentAt: '2026-04-01T00:00:00.000Z',
  procedureConsent: {
    createdAt: '2026-05-01T09:30:00.000Z',
    consentText: 'Texto do TCLE de procedimento',
    ipAddress: '203.0.113.5',
  },
  priorToxinDatesByRegion: {},
};

describe('computeSessionComplianceSummary', () => {
  it('marks every gate as met and allMet=true when every related record is present and clean', () => {
    const summary = computeSessionComplianceSummary(FULLY_COMPLIANT_INPUT);
    expect(summary.sessionId).toBe('sess-1');
    expect(summary.allMet).toBe(true);
    expect(summary.gates.every((g) => g.status === 'met')).toBe(true);
    // toxinMinInterval gate is included (session has a toxin point) and prior data was supplied.
    expect(summary.gates.map((g) => g.key)).toContain('toxinMinInterval');
  });

  it('never throws when every related record is null/undefined, and reports attention where data is missing', () => {
    const input: SessionComplianceInput = {
      sessionId: 'sess-2',
      sessionCreatedAt: undefined,
      applicationPoints: undefined,
      skinScreening: undefined,
      anamnesisCreatedAt: undefined,
      patientConsentGiven: undefined,
      patientLastConsentAt: undefined,
      procedureConsent: undefined,
      priorToxinDatesByRegion: undefined,
    };
    expect(() => computeSessionComplianceSummary(input)).not.toThrow();
    const summary = computeSessionComplianceSummary(input);
    expect(summary.allMet).toBe(false);
    const byKey = Object.fromEntries(summary.gates.map((g) => [g.key, g]));
    expect(byKey.skinScreening.status).toBe('attention');
    expect(byKey.anamnesis.status).toBe('attention');
    expect(byKey.consentGeneral.status).toBe('attention');
    expect(byKey.consentProcedure.status).toBe('attention');
    // No application points at all -> nothing over threshold, no risky region touched.
    expect(byKey.doseThreshold.status).toBe('met');
    expect(byKey.vascularRiskZone.status).toBe('met');
    // toxinMinInterval omitted entirely: no prior data supplied to check against.
    expect(summary.gates.map((g) => g.key)).not.toContain('toxinMinInterval');
  });

  it('flags skinScreening as attention when a suspicious finding was recorded without a decision', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      skinScreening: {
        hasSuspiciousFinding: true,
        referredToDermatology: false,
        proceededDespiteFinding: false,
        proceedJustification: null,
        updatedAt: '2026-05-01T09:00:00.000Z',
      },
    });
    const gate = summary.gates.find((g) => g.key === 'skinScreening')!;
    expect(gate.status).toBe('attention');
  });

  it('treats a suspicious finding as met once referred to dermatology', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      skinScreening: {
        hasSuspiciousFinding: true,
        referredToDermatology: true,
        proceededDespiteFinding: false,
        proceedJustification: null,
        updatedAt: '2026-05-01T09:00:00.000Z',
      },
    });
    expect(summary.gates.find((g) => g.key === 'skinScreening')!.status).toBe('met');
  });

  it('treats a suspicious finding as met when the professional proceeded with a real justification', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      skinScreening: {
        hasSuspiciousFinding: true,
        referredToDermatology: false,
        proceededDespiteFinding: true,
        proceedJustification: 'Lesão avaliada previamente por dermatologista, sem contraindicação.',
        updatedAt: '2026-05-01T09:00:00.000Z',
      },
    });
    expect(summary.gates.find((g) => g.key === 'skinScreening')!.status).toBe('met');
  });

  it('flags consentProcedure as attention when no real IP was captured, even with a signed consent', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      procedureConsent: {
        createdAt: '2026-05-01T09:30:00.000Z',
        consentText: 'Texto do TCLE',
        ipAddress: null,
      },
    });
    const gate = summary.gates.find((g) => g.key === 'consentProcedure')!;
    expect(gate.status).toBe('attention');
    // Fingerprint is still computed — the gap is the IP proof, not the consent text itself.
    expect(gate.fingerprint).toBeDefined();
  });

  it('flags doseThreshold as attention and names the substance when the session total exceeds the alert threshold', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      applicationPoints: [
        point({ region: 'testa', substance: 'toxina_botulinica', quantity: 60 }),
        point({ id: 'p2', region: 'glabela', substance: 'toxina_botulinica', quantity: 60 }),
      ],
    });
    const gate = summary.gates.find((g) => g.key === 'doseThreshold')!;
    expect(gate.status).toBe('attention');
    expect(gate.context).toEqual(['toxina_botulinica']);
  });

  it('flags vascularRiskZone as attention and names the region when a point sits in a high-risk zone', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      applicationPoints: [point({ region: 'glabela', substance: 'acido_hialuronico', quantity: 1 })],
    });
    const gate = summary.gates.find((g) => g.key === 'vascularRiskZone')!;
    expect(gate.status).toBe('attention');
    expect(gate.context).toEqual(['glabela']);
  });

  it('flags toxinMinInterval as attention when a toxin region was reapplied before the minimum interval', () => {
    const recent = new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(); // 10 days ago
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      applicationPoints: [point({ region: 'testa', substance: 'toxina_botulinica', quantity: 10 })],
      priorToxinDatesByRegion: { testa: recent },
    });
    const gate = summary.gates.find((g) => g.key === 'toxinMinInterval')!;
    expect(gate.status).toBe('attention');
    expect(gate.context).toEqual(['testa']);
  });

  it('omits toxinMinInterval when the session has no toxin points at all', () => {
    const summary = computeSessionComplianceSummary({
      ...FULLY_COMPLIANT_INPUT,
      applicationPoints: [point({ region: 'malar_esquerdo', substance: 'acido_hialuronico', quantity: 1 })],
      priorToxinDatesByRegion: { testa: '2020-01-01T00:00:00.000Z' },
    });
    expect(summary.gates.map((g) => g.key)).not.toContain('toxinMinInterval');
  });
});

describe('fingerprintConsentText', () => {
  it('is deterministic: the same text always produces the same fingerprint', () => {
    expect(fingerprintConsentText('texto do TCLE')).toBe(fingerprintConsentText('texto do TCLE'));
  });

  it('changes when the text changes, even by one character', () => {
    expect(fingerprintConsentText('texto do TCLE')).not.toBe(fingerprintConsentText('texto do tcle'));
  });

  it('returns a non-empty hex-like string for empty input, without throwing', () => {
    expect(() => fingerprintConsentText('')).not.toThrow();
    expect(fingerprintConsentText('')).toMatch(/^[0-9a-f]+$/);
  });
});
