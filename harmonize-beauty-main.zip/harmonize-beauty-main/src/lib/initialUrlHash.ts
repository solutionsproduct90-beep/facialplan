/**
 * O fragmento (`#...`) da URL no instante em que o app carregou.
 *
 * Existe por causa de uma corrida com o próprio supabase-js. O link de
 * recuperação de senha chega como
 * `/reset-password#access_token=...&type=recovery`. O client do Supabase é
 * criado com `detectSessionInUrl` no padrão (`true`), então, assim que o
 * módulo do client é importado, ele dispara sozinho uma inicialização que
 * valida o `access_token` contra `/auth/v1/user` e, SÓ DEPOIS de essa
 * resposta de rede chegar, executa `window.location.hash = ''`
 * (node_modules/@supabase/auth-js/dist/module/GoTrueClient.js,
 * `_getSessionFromURL`).
 *
 * Quem lê `window.location.hash` dentro de um efeito do React está, na
 * prática, apostando corrida contra essa requisição: em rede rápida o hash
 * já sumiu quando o componente monta, e a tela conclui "link inválido" para
 * um link perfeitamente válido. O desfecho correto dependia da rede estar
 * LENTA, que é o contrário do que se espera e a razão de isso passar batido
 * em teste manual.
 *
 * A captura de verdade acontece num script inline no `index.html`, que roda
 * no parse do HTML — antes de qualquer módulo — e guarda o valor em
 * `window.__facialplanInitialHash`.
 *
 * A primeira tentativa desta correção era um `export const` avaliado neste
 * módulo, importado por src/main.tsx só pelo efeito colateral. Funcionava em
 * desenvolvimento e nos testes, e NÃO funcionava no build de produção: sem
 * nenhum binding usado no ponto do import, o Rollup materializa o módulo
 * apenas onde os bindings são de fato consumidos — o chunk preguiçoso da
 * própria tela de reset, carregado só quando a rota abre. A captura voltava
 * a acontecer tarde demais e a corrida continuava idêntica. Um script inline
 * no HTML não passa por tree-shaking nem por code splitting, então não tem
 * como ser movido.
 *
 * O `window.location.hash` no fallback cobre os casos sem esse script: a
 * suíte de testes e a pré-renderização.
 *
 * Achados dos ciclos 71 e 72 do QA Contínuo.
 */
declare global {
  interface Window {
    /** Preenchido pelo script inline de `index.html`. */
    __facialplanInitialHash?: string;
  }
}

export const INITIAL_URL_HASH =
  typeof window !== 'undefined' ? window.__facialplanInitialHash ?? window.location.hash : '';

/** `true` quando o fragmento é o de um link de recuperação de senha. */
export function isRecoveryHash(hash: string): boolean {
  return hash.includes('type=recovery');
}

/**
 * `true` quando o Supabase devolveu um erro no próprio fragmento — link
 * expirado ou já usado chegam como `#error=access_denied&error_code=...`.
 */
export function isAuthErrorHash(hash: string): boolean {
  return hash.includes('error=') || hash.includes('error_code=');
}
