import { describe, it, expect, vi, afterEach } from 'vitest';
import {
  PHASE_FRAME_COUNTS,
  TOTAL_FRAME_COUNT,
  TOTAL_DURATION_S,
  VIDEO_FPS,
  VIDEO_WIDTH,
  getTotalFrameCount,
  getPhaseAtFrame,
  getPhaseAtTime,
  getWipeX,
  isWebCodecsSupported,
  pickSupportedH264Config,
  pickSupportedMediaRecorderH264Type,
  getMp4VideoCodecFourCc,
  isH264FourCc,
  validateH264Mp4,
  generateBeforeAfterVideo,
} from './videoExport';

// ---------------------------------------------------------------------------
// Timeline / frações de tempo por fase
// ---------------------------------------------------------------------------

describe('timeline de frames', () => {
  it('soma 1.8s + 2.4s + 1.6s + 0.8s = 6.6s no total, em frames exatos @30fps', () => {
    expect(PHASE_FRAME_COUNTS).toEqual({ holdBefore: 54, wipe: 72, holdAfter: 48, breathe: 24 });
    expect(TOTAL_FRAME_COUNT).toBe(198);
    expect(TOTAL_DURATION_S).toBeCloseTo(6.6, 5);
    expect(getTotalFrameCount(VIDEO_FPS)).toBe(198);
  });

  it('escala a contagem total de frames para outros fps', () => {
    expect(getTotalFrameCount(60)).toBe(396);
    expect(getTotalFrameCount(15)).toBe(99);
  });

  it('fica em holdBefore do frame 0 até o frame 53', () => {
    expect(getPhaseAtFrame(0).phase).toBe('holdBefore');
    expect(getPhaseAtFrame(53).phase).toBe('holdBefore');
    expect(getPhaseAtFrame(0).progress).toBe(0);
  });

  it('entra em wipe exatamente no frame 54 e sai no frame 125', () => {
    expect(getPhaseAtFrame(54).phase).toBe('wipe');
    expect(getPhaseAtFrame(54).progress).toBe(0);
    expect(getPhaseAtFrame(125).phase).toBe('wipe');
    expect(getPhaseAtFrame(125).frameInPhase).toBe(71);
  });

  it('entra em holdAfter no frame 126 e sai no frame 173', () => {
    expect(getPhaseAtFrame(126).phase).toBe('holdAfter');
    expect(getPhaseAtFrame(126).progress).toBe(0);
    expect(getPhaseAtFrame(173).phase).toBe('holdAfter');
  });

  it('entra em breathe no frame 174 até o último frame (197)', () => {
    expect(getPhaseAtFrame(174).phase).toBe('breathe');
    expect(getPhaseAtFrame(174).progress).toBe(0);
    expect(getPhaseAtFrame(197).phase).toBe('breathe');
  });

  it('grampeia frames negativos em holdBefore e frames além do total em breathe', () => {
    expect(getPhaseAtFrame(-10).phase).toBe('holdBefore');
    expect(getPhaseAtFrame(-10).progress).toBe(0);
    const past = getPhaseAtFrame(500);
    expect(past.phase).toBe('breathe');
    expect(past.progress).toBe(1);
  });

  it('getPhaseAtTime converte segundos para o frame equivalente', () => {
    expect(getPhaseAtTime(0).phase).toBe('holdBefore');
    expect(getPhaseAtTime(1.8).phase).toBe('wipe');
    expect(getPhaseAtTime(4.2).phase).toBe('holdAfter');
    expect(getPhaseAtTime(5.8).phase).toBe('breathe');
  });

  it('respeita a mesma proporção de fases em fps diferente de 30', () => {
    // @ 60fps cada fase deve durar o dobro de frames.
    expect(getPhaseAtFrame(107, 60).phase).toBe('holdBefore');
    expect(getPhaseAtFrame(108, 60).phase).toBe('wipe');
  });
});

describe('getWipeX', () => {
  it('mantém a linha de corte em 0 durante holdBefore e em width durante holdAfter/breathe', () => {
    expect(getWipeX(getPhaseAtFrame(0), VIDEO_WIDTH)).toBe(0);
    expect(getWipeX(getPhaseAtFrame(126), VIDEO_WIDTH)).toBe(VIDEO_WIDTH);
    expect(getWipeX(getPhaseAtFrame(180), VIDEO_WIDTH)).toBe(VIDEO_WIDTH);
  });

  it('varre de 0 a width durante o wipe, sem retroceder', () => {
    const xs = [54, 70, 90, 110, 125].map((frame) => getWipeX(getPhaseAtFrame(frame), VIDEO_WIDTH));
    expect(xs[0]).toBe(0);
    for (let i = 1; i < xs.length; i++) {
      expect(xs[i]).toBeGreaterThanOrEqual(xs[i - 1]);
    }
    expect(xs[xs.length - 1]).toBeLessThanOrEqual(VIDEO_WIDTH);
    expect(xs[xs.length - 1]).toBeGreaterThan(VIDEO_WIDTH * 0.9);
  });
});

// ---------------------------------------------------------------------------
// Detecção de suporte a WebCodecs / MediaRecorder — nunca fixar um único
// nível/resolução (é essa falta de fallback que quebrou o vídeo do
// concorrente).
// ---------------------------------------------------------------------------

describe('isWebCodecsSupported', () => {
  const original = { VideoEncoder: (globalThis as any).VideoEncoder, VideoFrame: (globalThis as any).VideoFrame };

  afterEach(() => {
    (globalThis as any).VideoEncoder = original.VideoEncoder;
    (globalThis as any).VideoFrame = original.VideoFrame;
  });

  it('é false quando VideoEncoder/VideoFrame não existem no navegador', () => {
    delete (globalThis as any).VideoEncoder;
    delete (globalThis as any).VideoFrame;
    expect(isWebCodecsSupported()).toBe(false);
  });

  it('é true quando ambos existem', () => {
    (globalThis as any).VideoEncoder = class {};
    (globalThis as any).VideoFrame = class {};
    expect(isWebCodecsSupported()).toBe(true);
  });
});

describe('pickSupportedH264Config', () => {
  const original = { VideoEncoder: (globalThis as any).VideoEncoder, VideoFrame: (globalThis as any).VideoFrame };

  afterEach(() => {
    (globalThis as any).VideoEncoder = original.VideoEncoder;
    (globalThis as any).VideoFrame = original.VideoFrame;
  });

  it('devolve null quando WebCodecs nem existe', async () => {
    delete (globalThis as any).VideoEncoder;
    expect(await pickSupportedH264Config()).toBeNull();
  });

  it('devolve null quando nenhuma combinação de resolução/nível é suportada', async () => {
    (globalThis as any).VideoEncoder = { isConfigSupported: vi.fn().mockResolvedValue({ supported: false }) };
    (globalThis as any).VideoFrame = class {};
    expect(await pickSupportedH264Config()).toBeNull();
  });

  it('escala a resolução pra baixo até achar um nível suportado (o bug do concorrente era travar em 1080x1440 @ level 3.0)', async () => {
    const isConfigSupported = vi.fn().mockImplementation(async (config: { width: number }) => ({
      supported: config.width === 720,
    }));
    (globalThis as any).VideoEncoder = { isConfigSupported };
    (globalThis as any).VideoFrame = class {};
    const config = await pickSupportedH264Config();
    expect(config).not.toBeNull();
    expect(config?.width).toBe(720);
    expect(config?.codec.startsWith('avc1.')).toBe(true);
  });

  it('prefere a resolução nativa quando ela é suportada, sem precisar degradar', async () => {
    (globalThis as any).VideoEncoder = { isConfigSupported: vi.fn().mockResolvedValue({ supported: true }) };
    (globalThis as any).VideoFrame = class {};
    const config = await pickSupportedH264Config();
    expect(config?.width).toBe(1080);
    expect(config?.height).toBe(1440);
  });

  it('não aborta a escada quando uma combinação lança em vez de responder supported:false', async () => {
    const isConfigSupported = vi
      .fn()
      .mockRejectedValueOnce(new Error('NotSupportedError'))
      .mockResolvedValue({ supported: true });
    (globalThis as any).VideoEncoder = { isConfigSupported };
    (globalThis as any).VideoFrame = class {};
    const config = await pickSupportedH264Config();
    expect(config).not.toBeNull();
  });
});

describe('pickSupportedMediaRecorderH264Type', () => {
  const original = (globalThis as any).MediaRecorder;

  afterEach(() => {
    (globalThis as any).MediaRecorder = original;
  });

  it('devolve null quando MediaRecorder não existe', () => {
    delete (globalThis as any).MediaRecorder;
    expect(pickSupportedMediaRecorderH264Type()).toBeNull();
  });

  it('nunca devolve um tipo webm/vp8/vp9 — só aceita candidatos H.264 explícitos', () => {
    (globalThis as any).MediaRecorder = {
      isTypeSupported: (type: string) => type === 'video/webm;codecs=vp9',
    };
    expect(pickSupportedMediaRecorderH264Type()).toBeNull();
  });

  it('devolve o primeiro tipo H.264/mp4 que o navegador confirma suportar', () => {
    (globalThis as any).MediaRecorder = {
      isTypeSupported: (type: string) => type === 'video/mp4;codecs=avc1',
    };
    expect(pickSupportedMediaRecorderH264Type()).toBe('video/mp4;codecs=avc1');
  });
});

// ---------------------------------------------------------------------------
// Validação do codec real dentro do container MP4 — a rede de segurança
// contra o bug "VideoEncoder não lançou erro, mas o resultado é VP9".
// ---------------------------------------------------------------------------

function u32(n: number): number[] {
  return [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff];
}

function asciiBytes(str: string): number[] {
  return Array.from(str, (c) => c.charCodeAt(0));
}

function concatBytes(arrays: Uint8Array[]): Uint8Array {
  const total = arrays.reduce((sum, arr) => sum + arr.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const arr of arrays) {
    out.set(arr, offset);
    offset += arr.length;
  }
  return out;
}

/** Constrói uma box ISO-BMFF (`size` + `type` + payload) a partir de bytes crus. */
function box(type: string, payload: Uint8Array = new Uint8Array(0)): Uint8Array {
  const size = 8 + payload.length;
  const header = new Uint8Array([...u32(size), ...asciiBytes(type)]);
  return concatBytes([header, payload]);
}

/** Sample entry mínima o bastante pro parser ler o fourcc; conteúdo interno é irrelevante. */
function sampleEntry(fourCc: string): Uint8Array {
  const reserved = new Uint8Array(78);
  const size = 8 + reserved.length;
  const header = new Uint8Array([...u32(size), ...asciiBytes(fourCc)]);
  return concatBytes([header, reserved]);
}

function buildFakeMp4(fourCc: string, { withVmhd = true } = {}): ArrayBuffer {
  const stsdPayload = concatBytes([
    new Uint8Array(4), // version + flags
    new Uint8Array(u32(1)), // entry_count = 1
    sampleEntry(fourCc),
  ]);
  const stsdBox = box('stsd', stsdPayload);
  const stblBox = box('stbl', stsdBox);
  const vmhdBox = withVmhd ? box('vmhd', new Uint8Array(12)) : new Uint8Array(0);
  const minfBox = box('minf', concatBytes([vmhdBox, stblBox]));
  const mdiaBox = box('mdia', minfBox);
  const trakBox = box('trak', mdiaBox);
  const moovBox = box('moov', trakBox);
  const ftypBox = box('ftyp', new Uint8Array([...asciiBytes('isom'), ...u32(0), ...asciiBytes('isom')]));
  const file = concatBytes([ftypBox, moovBox]);
  return file.buffer.slice(file.byteOffset, file.byteOffset + file.byteLength) as ArrayBuffer;
}

describe('getMp4VideoCodecFourCc', () => {
  it('lê "avc1" de um container gerado com sample entry H.264', () => {
    expect(getMp4VideoCodecFourCc(buildFakeMp4('avc1'))).toBe('avc1');
  });

  it('lê "vp09" de um container cuja trilha de vídeo é, na verdade, VP9 (reprodução do bug do concorrente)', () => {
    expect(getMp4VideoCodecFourCc(buildFakeMp4('vp09'))).toBe('vp09');
  });

  it('funciona mesmo sem a box vmhd (assume o primeiro trak)', () => {
    expect(getMp4VideoCodecFourCc(buildFakeMp4('avc1', { withVmhd: false }))).toBe('avc1');
  });

  it('devolve null para um buffer que não é um MP4/ISO-BMFF reconhecível', () => {
    const garbage = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8]).buffer;
    expect(getMp4VideoCodecFourCc(garbage)).toBeNull();
  });
});

describe('isH264FourCc', () => {
  it('aceita avc1 e avc3', () => {
    expect(isH264FourCc('avc1')).toBe(true);
    expect(isH264FourCc('avc3')).toBe(true);
  });

  it('rejeita vp8, vp9, hevc, av1 e null', () => {
    expect(isH264FourCc('vp08')).toBe(false);
    expect(isH264FourCc('vp09')).toBe(false);
    expect(isH264FourCc('hev1')).toBe(false);
    expect(isH264FourCc('av01')).toBe(false);
    expect(isH264FourCc(null)).toBe(false);
  });
});

describe('validateH264Mp4', () => {
  it('aprova um .mp4 cuja trilha de vídeo é realmente avc1', async () => {
    const blob = new Blob([buildFakeMp4('avc1')], { type: 'video/mp4' });
    const result = await validateH264Mp4(blob);
    expect(result).toEqual({ ok: true, codec: 'avc1' });
  });

  it('rejeita e explica quando o .mp4 na verdade contém VP9 — exatamente o bug do concorrente', async () => {
    const blob = new Blob([buildFakeMp4('vp09')], { type: 'video/mp4' });
    const result = await validateH264Mp4(blob);
    expect(result.ok).toBe(false);
    expect(result.codec).toBe('vp09');
    expect(result.reason).toMatch(/vp09/);
    expect(result.reason).toMatch(/H\.264/);
  });

  it('rejeita com motivo quando a trilha de vídeo não é localizável', async () => {
    const blob = new Blob([new Uint8Array([0, 0, 0, 0])], { type: 'video/mp4' });
    const result = await validateH264Mp4(blob);
    expect(result.ok).toBe(false);
    expect(result.codec).toBeNull();
    expect(result.reason).toBeTruthy();
  });
});

// ── Regressão do ciclo 70 do QA Contínuo ────────────────────────────────
//
// Os dois ImageBitmap (foto antes e depois) nunca eram fechados. Cada um
// guarda a foto já decodificada — foto de celular passa de 3000x4000, então
// são dezenas de MB por imagem, possivelmente na GPU — e o botão
// "Regenerar" da tela de apresentação chama esta função de novo sem
// recarregar a página, empilhando um par por clique. No celular, que é o
// alvo da feature, o Safari do iOS mata a aba nesse cenário em vez de
// degradar.
//
// O teste usa o caminho de erro (nenhum encoder H.264 disponível) porque é
// o único alcançável no ambiente de teste, que não tem Canvas nem
// WebCodecs — e é justamente o caminho onde um `close()` colocado só depois
// do encode bem-sucedido não seria executado.
describe('generateBeforeAfterVideo — liberação dos bitmaps', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  /** ImageBitmap dublê: só o suficiente para `drawImage` e `close`. */
  const fakeBitmap = () => ({ width: 3024, height: 4032, close: vi.fn() });

  it('fecha os dois bitmaps quando a geração falha', async () => {
    const before = fakeBitmap();
    const after = fakeBitmap();
    const bitmaps = [before, after];

    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, blob: async () => new Blob(['x']) }));
    vi.stubGlobal('createImageBitmap', vi.fn().mockImplementation(async () => bitmaps.shift()));
    // Sem VideoEncoder e sem MediaRecorder: a função lança em vez de gerar
    // um arquivo com codec errado.
    vi.stubGlobal('VideoEncoder', undefined);
    vi.stubGlobal('MediaRecorder', undefined);

    await expect(
      generateBeforeAfterVideo({ beforeUrl: 'https://x/a.jpg', afterUrl: 'https://x/b.jpg', title: 't' })
    ).rejects.toThrow();

    expect(before.close).toHaveBeenCalledTimes(1);
    expect(after.close).toHaveBeenCalledTimes(1);
  });

  it('fecha o bitmap que carregou quando o outro falha', async () => {
    const before = fakeBitmap();
    let chamada = 0;

    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async () => {
        chamada += 1;
        // A segunda foto não existe mais no Storage (URL assinada expirada,
        // arquivo removido): a primeira não pode ficar pendurada.
        return chamada === 1 ? { ok: true, blob: async () => new Blob(['x']) } : { ok: false, status: 404 };
      })
    );
    vi.stubGlobal('createImageBitmap', vi.fn().mockResolvedValue(before));
    vi.stubGlobal('VideoEncoder', undefined);
    vi.stubGlobal('MediaRecorder', undefined);

    await expect(
      generateBeforeAfterVideo({ beforeUrl: 'https://x/a.jpg', afterUrl: 'https://x/b.jpg', title: 't' })
    ).rejects.toThrow();

    expect(before.close).toHaveBeenCalledTimes(1);
  });
});
