import type { ApplicationPoint } from '@/types/harmonize';

/**
 * Uma sessão anterior da mesma paciente, reduzida ao que o histórico de
 * toxina precisa ler.
 */
export type PastSessionForToxinHistory = {
  created_at: string | null;
  stage2_overlay: unknown;
};

/**
 * Status de sessão que NÃO conta como aplicação realizada.
 *
 * A query antes filtrava `status = 'complete'`, com a justificativa de que
 * uma sessão em andamento "não representa uma aplicação de fato realizada".
 * Essa premissa não se sustenta: `stage2_overlay` é persistido a cada
 * mudança no Estágio 2 — a tela se chama "Pontos de Aplicação", não "Pontos
 * Planejados" — enquanto `status: 'complete'` só é gravado no fim do Estágio
 * 3, depois de gerar a simulação e fechar a documentação. Entre um e outro
 * existe uma sessão real, com toxina registrada, que o filtro escondia.
 *
 * E não é um caso de canto: o produto tem um sistema inteiro de
 * reengajamento por e-mail (src/lib/sessionAbandonment.ts) construído sobre
 * o fato de que sessões ficam paradas em stage1/stage2/stage3 sem nunca
 * chegar a 'complete'. O Alerta de Intervalo Mínimo ficava cego justamente
 * para o padrão de uso que o produto já sabe ser comum.
 *
 * `'abandoned'` continua de fora porque é marcado à mão pelo profissional:
 * é uma afirmação explícita de que aquela sessão não aconteceu, e respeitar
 * isso vale mais que a heurística. Se em campo aparecerem sessões marcadas
 * como abandonadas depois de uma aplicação real, essa escolha precisa ser
 * revista.
 *
 * Achado do ciclo 76 do QA Contínuo.
 */
export const TOXIN_HISTORY_EXCLUDED_STATUS = 'abandoned';

/**
 * Data da última aplicação de toxina botulínica por região, a partir das
 * sessões anteriores da paciente.
 *
 * Função pura, compartilhada por SessaoEstagio2 (Alerta de Intervalo Mínimo,
 * ao vivo) e SessaoEstagio3 (gate `toxinMinInterval` do Selo de
 * Conformidade, no PDF). As duas telas tinham cópias idênticas deste laço, e
 * é por isso que o filtro errado precisou ser corrigido em dois lugares —
 * daqui em diante, um só.
 */
export function buildLastToxinDatesByRegion(
  pastSessions: readonly PastSessionForToxinHistory[] | null | undefined,
): Record<string, string> {
  const lastByRegion: Record<string, string> = {};
  (pastSessions ?? []).forEach((past) => {
    if (!past.created_at) return;
    const overlay = (past.stage2_overlay as ApplicationPoint[] | null) ?? [];
    if (!Array.isArray(overlay)) return;
    overlay.forEach((point) => {
      if (point?.substance !== 'toxina_botulinica' || !point.region) return;
      const current = lastByRegion[point.region];
      if (!current || new Date(past.created_at as string) > new Date(current)) {
        lastByRegion[point.region] = past.created_at as string;
      }
    });
  });
  return lastByRegion;
}
