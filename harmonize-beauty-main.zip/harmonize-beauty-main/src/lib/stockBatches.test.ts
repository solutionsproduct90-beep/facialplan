import { describe, it, expect } from 'vitest';
import {
  normalizeStockBatches,
  sortBatchesFefo,
  computeFefoConsumption,
  daysUntilExpiry,
  isBatchExpiringSoon,
  batchesExpiringSoon,
  describeExpiryDays,
  totalBatchQuantity,
  aggregateConsumptionByInsumo,
  type InsumoStockBatch,
} from './stockBatches';

function batch(overrides: Partial<InsumoStockBatch>): InsumoStockBatch {
  return {
    id: 'b1',
    insumoId: 'ins-1',
    batchNumber: 'L1',
    expiresOn: null,
    quantityReceived: 10,
    quantityRemaining: 10,
    receivedOn: '2026-01-01',
    ...overrides,
  };
}

describe('normalizeStockBatches', () => {
  it('normalizes a well-formed row, coercing numeric-as-string quantities', () => {
    const rows = [
      {
        id: 'b1',
        insumo_id: 'ins-1',
        batch_number: 'ABC123',
        expires_on: '2026-12-31',
        quantity_received: '10',
        quantity_remaining: '7',
        received_on: '2026-09-01',
      },
    ];
    expect(normalizeStockBatches(rows)).toEqual([
      {
        id: 'b1',
        insumoId: 'ins-1',
        batchNumber: 'ABC123',
        expiresOn: '2026-12-31',
        quantityReceived: 10,
        quantityRemaining: 7,
        receivedOn: '2026-09-01',
      },
    ]);
  });

  it('defaults expiresOn to null when absent, without inventing a date', () => {
    const rows = [
      { id: 'b1', insumo_id: 'ins-1', batch_number: 'L1', quantity_received: 5, quantity_remaining: 5, received_on: '2026-01-01' },
    ];
    expect(normalizeStockBatches(rows)[0].expiresOn).toBeNull();
  });

  it('discards a row missing required fields', () => {
    const rows = [
      { id: 'b1', insumo_id: 'ins-1', batch_number: '', quantity_received: 5, quantity_remaining: 5, received_on: '2026-01-01' },
      { id: 'b2', insumo_id: 'ins-1', batch_number: 'L2', quantity_received: 'nao-numero', quantity_remaining: 5, received_on: '2026-01-01' },
      { id: 'b3', insumo_id: 'ins-1', batch_number: 'L3', quantity_received: 5, quantity_remaining: 5, received_on: '2026-01-01' },
    ];
    const result = normalizeStockBatches(rows);
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe('b3');
  });

  it('returns an empty list for non-array input', () => {
    expect(normalizeStockBatches(null)).toEqual([]);
    expect(normalizeStockBatches(undefined)).toEqual([]);
  });
});

describe('sortBatchesFefo', () => {
  it('orders by nearest expiry first (FEFO)', () => {
    const batches = [
      batch({ id: 'far', expiresOn: '2027-01-01' }),
      batch({ id: 'near', expiresOn: '2026-10-01' }),
      batch({ id: 'mid', expiresOn: '2026-12-01' }),
    ];
    expect(sortBatchesFefo(batches).map((b) => b.id)).toEqual(['near', 'mid', 'far']);
  });

  it('falls back to FIFO (received date) among batches without expiry — same substance, no expiry tracking', () => {
    const batches = [
      batch({ id: 'newer', expiresOn: null, receivedOn: '2026-06-01' }),
      batch({ id: 'older', expiresOn: null, receivedOn: '2026-01-01' }),
    ];
    expect(sortBatchesFefo(batches).map((b) => b.id)).toEqual(['older', 'newer']);
  });

  it('puts batches without expiry after batches with expiry, regardless of receipt date', () => {
    const batches = [
      batch({ id: 'no-expiry', expiresOn: null, receivedOn: '2020-01-01' }),
      batch({ id: 'has-expiry', expiresOn: '2030-01-01', receivedOn: '2026-06-01' }),
    ];
    expect(sortBatchesFefo(batches).map((b) => b.id)).toEqual(['has-expiry', 'no-expiry']);
  });

  it('does not mutate the input array', () => {
    const batches = [batch({ id: 'a', expiresOn: '2027-01-01' }), batch({ id: 'b', expiresOn: '2026-01-01' })];
    const original = [...batches];
    sortBatchesFefo(batches);
    expect(batches).toEqual(original);
  });
});

describe('computeFefoConsumption', () => {
  it('consumes a single batch fully sufficient for the requested quantity', () => {
    const batches = [batch({ id: 'b1', quantityRemaining: 10 })];
    expect(computeFefoConsumption(batches, 4)).toEqual({ steps: [{ batchId: 'b1', quantity: 4 }], unmatchedQuantity: 0 });
  });

  it('picks the nearest-expiry batch first across multiple batches, spilling into the next when exhausted', () => {
    const batches = [
      batch({ id: 'far', expiresOn: '2027-01-01', quantityRemaining: 5 }),
      batch({ id: 'near', expiresOn: '2026-10-01', quantityRemaining: 3 }),
    ];
    const plan = computeFefoConsumption(batches, 6);
    expect(plan).toEqual({
      steps: [
        { batchId: 'near', quantity: 3 },
        { batchId: 'far', quantity: 3 },
      ],
      unmatchedQuantity: 0,
    });
  });

  it('falls back to FIFO ordering when expiry makes no difference (no batch has one)', () => {
    const batches = [
      batch({ id: 'newer', expiresOn: null, receivedOn: '2026-06-01', quantityRemaining: 4 }),
      batch({ id: 'older', expiresOn: null, receivedOn: '2026-01-01', quantityRemaining: 4 }),
    ];
    const plan = computeFefoConsumption(batches, 5);
    expect(plan.steps).toEqual([
      { batchId: 'older', quantity: 4 },
      { batchId: 'newer', quantity: 1 },
    ]);
  });

  it('reports the unmatched leftover instead of throwing when batches cannot cover the request', () => {
    const batches = [batch({ id: 'b1', quantityRemaining: 2 })];
    expect(computeFefoConsumption(batches, 5)).toEqual({ steps: [{ batchId: 'b1', quantity: 2 }], unmatchedQuantity: 3 });
  });

  it('returns the full quantity as unmatched when there are no batches at all — never blocks the flow', () => {
    expect(computeFefoConsumption([], 5)).toEqual({ steps: [], unmatchedQuantity: 5 });
  });

  it('ignores batches with no remaining balance', () => {
    const batches = [batch({ id: 'empty', quantityRemaining: 0 }), batch({ id: 'has', quantityRemaining: 3 })];
    expect(computeFefoConsumption(batches, 2)).toEqual({ steps: [{ batchId: 'has', quantity: 2 }], unmatchedQuantity: 0 });
  });

  it('returns an empty plan for a zero or negative quantity', () => {
    const batches = [batch({ id: 'b1', quantityRemaining: 5 })];
    expect(computeFefoConsumption(batches, 0)).toEqual({ steps: [], unmatchedQuantity: 0 });
    expect(computeFefoConsumption(batches, -1)).toEqual({ steps: [], unmatchedQuantity: 0 });
  });
});

describe('daysUntilExpiry', () => {
  const now = new Date('2026-09-11T15:00:00');

  it('returns 0 for a batch expiring today, regardless of time of day', () => {
    expect(daysUntilExpiry('2026-09-11', now)).toBe(0);
  });

  it('returns a positive count for a future expiry', () => {
    expect(daysUntilExpiry('2026-10-11', now)).toBe(30);
  });

  it('returns a negative count for an already-expired batch', () => {
    expect(daysUntilExpiry('2026-09-01', now)).toBe(-10);
  });

  it('returns null when there is no expiry to compute from', () => {
    expect(daysUntilExpiry(null, now)).toBeNull();
    expect(daysUntilExpiry(undefined, now)).toBeNull();
  });
});

describe('isBatchExpiringSoon / batchesExpiringSoon', () => {
  const now = new Date('2026-09-11T00:00:00');

  it('flags a batch expiring within the default 30-day window', () => {
    expect(isBatchExpiringSoon(batch({ expiresOn: '2026-10-01', quantityRemaining: 1 }), 30, now)).toBe(true);
  });

  it('does not flag a batch expiring well outside the window', () => {
    expect(isBatchExpiringSoon(batch({ expiresOn: '2027-01-01', quantityRemaining: 1 }), 30, now)).toBe(false);
  });

  it('flags an already-expired batch too — more urgent, not less', () => {
    expect(isBatchExpiringSoon(batch({ expiresOn: '2026-01-01', quantityRemaining: 1 }), 30, now)).toBe(true);
  });

  it('never flags a batch without a tracked expiry', () => {
    expect(isBatchExpiringSoon(batch({ expiresOn: null, quantityRemaining: 1 }), 30, now)).toBe(false);
  });

  it('never flags a batch with no remaining balance, even if its expiry is near', () => {
    expect(isBatchExpiringSoon(batch({ expiresOn: '2026-09-15', quantityRemaining: 0 }), 30, now)).toBe(false);
  });

  it('filters and sorts by soonest expiry first', () => {
    const batches = [
      batch({ id: 'b-far', expiresOn: '2027-01-01', quantityRemaining: 1 }),
      batch({ id: 'b-soon', expiresOn: '2026-09-20', quantityRemaining: 1 }),
      batch({ id: 'b-expired', expiresOn: '2026-08-01', quantityRemaining: 1 }),
      batch({ id: 'b-no-expiry', expiresOn: null, quantityRemaining: 1 }),
    ];
    expect(batchesExpiringSoon(batches, 30, now).map((b) => b.id)).toEqual(['b-expired', 'b-soon']);
  });
});

describe('describeExpiryDays', () => {
  it('classifies a future date as upcoming, with the number of days left', () => {
    expect(describeExpiryDays(5)).toEqual({ kind: 'upcoming', daysLeft: 5 });
  });

  it('classifies zero as today', () => {
    expect(describeExpiryDays(0)).toEqual({ kind: 'today' });
  });

  it('classifies a negative count as expired, with the number of days ago', () => {
    expect(describeExpiryDays(-3)).toEqual({ kind: 'expired', daysAgo: 3 });
  });
});

describe('totalBatchQuantity', () => {
  it('sums the remaining balance across batches', () => {
    expect(totalBatchQuantity([batch({ quantityRemaining: 3 }), batch({ quantityRemaining: 2 })])).toBe(5);
  });

  it('returns 0 for no batches', () => {
    expect(totalBatchQuantity([])).toBe(0);
  });
});

describe('aggregateConsumptionByInsumo', () => {
  it('sums quantity per insumoId across application points', () => {
    const points = [
      { insumoId: 'ins-1', quantity: 2 },
      { insumoId: 'ins-2', quantity: 1 },
      { insumoId: 'ins-1', quantity: 1.5 },
    ];
    const result = aggregateConsumptionByInsumo(points);
    expect(result.get('ins-1')).toBe(3.5);
    expect(result.get('ins-2')).toBe(1);
    expect(result.size).toBe(2);
  });

  it('ignores points without an insumoId — nothing to decrement, must never block session completion', () => {
    const points = [{ insumoId: undefined, quantity: 2 }, { insumoId: 'ins-1', quantity: 1 }];
    const result = aggregateConsumptionByInsumo(points);
    expect(result.size).toBe(1);
    expect(result.get('ins-1')).toBe(1);
  });

  it('ignores points with a non-positive or invalid quantity', () => {
    const points = [
      { insumoId: 'ins-1', quantity: 0 },
      { insumoId: 'ins-1', quantity: -2 },
      { insumoId: 'ins-1', quantity: NaN },
    ];
    expect(aggregateConsumptionByInsumo(points).size).toBe(0);
  });

  it('returns an empty map for no points', () => {
    expect(aggregateConsumptionByInsumo([]).size).toBe(0);
  });
});
