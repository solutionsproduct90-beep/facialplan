import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Verificação estática do texto da migration (mesmo padrão de
// manualPointJustificationRpc.test.ts — não há infraestrutura de teste com
// Postgres real neste repositório): confere as propriedades de segurança e
// privacidade pedidas para get_complementary_procedure_insight (1) autoriza
// qualquer profissional autenticado; (2) filtra por
// patients.ai_improvement_consent = true; (3) corta por amostra mínima (5,
// mesmo MIN_SAMPLE_SIZE de src/lib/adminIntelligence.ts); (4) nunca devolve
// contagem exata nem coluna de identidade.
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260914110000_add_complementary_procedure_insight_rpc.sql',
);
const sql = readFileSync(migrationPath, 'utf8');

const functionBodyMatch = sql.match(/AS \$\$([\s\S]*?)\$\$;/);
if (!functionBodyMatch) throw new Error('não achou o corpo da função na migration — o regex precisa ser ajustado');
const functionBody = functionBodyMatch[1];

describe('get_complementary_procedure_insight (migration SQL)', () => {
  it('autoriza qualquer usuário autenticado — não checa role de admin, mesmo padrão de get_manual_point_justification_stats', () => {
    expect(functionBody).toContain('auth.uid() IS NULL');
    expect(functionBody).not.toContain("has_role(auth.uid(), 'admin')");
  });

  it('é SECURITY DEFINER com search_path fixo (mesmo padrão das demais RPCs da Central de Inteligência)', () => {
    expect(sql).toContain('SECURITY DEFINER');
    expect(sql).toContain('SET search_path = public');
  });

  it('concede EXECUTE para "authenticated" (qualquer profissional logado), nunca para PUBLIC', () => {
    expect(sql).toMatch(/REVOKE ALL ON FUNCTION public\.get_complementary_procedure_insight\(text\) FROM PUBLIC/);
    expect(sql).toMatch(/GRANT EXECUTE ON FUNCTION public\.get_complementary_procedure_insight\(text\) TO authenticated/);
  });

  it('filtra por patients.ai_improvement_consent = true antes de qualquer agregação', () => {
    expect(functionBody).toMatch(/JOIN public\.patients p ON p\.id = s\.patient_id AND p\.ai_improvement_consent = true/);
  });

  it('aplica o corte de amostra mínima (>= 5, mesmo MIN_SAMPLE_SIZE de src/lib/adminIntelligence.ts) sobre a contagem de pacientes distintos', () => {
    expect(functionBody).toMatch(/co\.n\s*>=\s*5/);
    expect(functionBody).toMatch(/count\(DISTINCT pp\.patient_id\)/);
  });

  it('nunca devolve a contagem exata (n) nem coluna de identidade — só a chave do procedimento complementar', () => {
    const returnsTableMatch = sql.match(/RETURNS TABLE\(([\s\S]*?)\)\s*\nLANGUAGE/);
    expect(returnsTableMatch).not.toBeNull();
    expect(returnsTableMatch![1].trim()).toBe('complementary_procedure_key text');

    const finalSelectMatch = functionBody.match(/SELECT co\.procedure_key([\s\S]*?)LIMIT 1;/);
    expect(finalSelectMatch).not.toBeNull();
    for (const forbidden of ['patient_id', 'professional_id', 'session_id', 'patient_name', ' n\n', ', n']) {
      expect(finalSelectMatch![0]).not.toContain(forbidden);
    }
  });

  it('agrega por PACIENTE (patient_id), não por sessão isolada', () => {
    expect(functionBody).toMatch(/SELECT DISTINCT s\.patient_id/);
  });
});
