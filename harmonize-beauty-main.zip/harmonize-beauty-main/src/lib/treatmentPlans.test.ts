import { describe, it, expect } from 'vitest';
import { format } from 'date-fns';
import {
  normalizeTreatmentPlans,
  normalizeTreatmentPlanSteps,
  sortTreatmentPlanSteps,
  nextStepOrder,
  computeStepExpectedDate,
  validateTreatmentPlanDraft,
  buildTreatmentPlanPayload,
  validateTreatmentPlanStepDraft,
  buildTreatmentPlanStepPayload,
  buildStepSessionLinkPayload,
  buildStepSessionUnlinkPayload,
  buildStepSkipPayload,
} from './treatmentPlans';

describe('normalizeTreatmentPlans', () => {
  it('normalizes a well-formed row', () => {
    const rows = [
      {
        id: 'plan-1',
        patient_id: 'pat-1',
        name: 'Protocolo de rejuvenescimento facial',
        description: 'Toxina + bioestimulador + skinbooster',
        start_date: '2026-09-11',
        created_at: '2026-09-11T10:00:00.000Z',
      },
    ];
    expect(normalizeTreatmentPlans(rows)).toEqual([
      {
        id: 'plan-1',
        patientId: 'pat-1',
        name: 'Protocolo de rejuvenescimento facial',
        description: 'Toxina + bioestimulador + skinbooster',
        startDate: '2026-09-11',
        createdAt: '2026-09-11T10:00:00.000Z',
      },
    ]);
  });

  it('discards a row with an invalid start_date instead of throwing', () => {
    const rows = [{ id: 'plan-1', patient_id: 'pat-1', name: 'Plano', start_date: 'not-a-date' }];
    expect(normalizeTreatmentPlans(rows)).toEqual([]);
  });

  it('discards a row without a name', () => {
    const rows = [{ id: 'plan-1', patient_id: 'pat-1', name: '   ', start_date: '2026-09-11' }];
    expect(normalizeTreatmentPlans(rows)).toEqual([]);
  });
});

describe('normalizeTreatmentPlanSteps', () => {
  it('normalizes a well-formed row', () => {
    const rows = [
      {
        id: 'step-1',
        plan_id: 'plan-1',
        substance: 'toxina_botulinica',
        offset_days: 0,
        step_order: 0,
        status: 'pendente',
        session_id: null,
        notes: null,
        created_at: '2026-09-11T10:00:00.000Z',
      },
    ];
    expect(normalizeTreatmentPlanSteps(rows)).toEqual([
      {
        id: 'step-1',
        planId: 'plan-1',
        substance: 'toxina_botulinica',
        offsetDays: 0,
        stepOrder: 0,
        status: 'pendente',
        sessionId: null,
        notes: null,
        createdAt: '2026-09-11T10:00:00.000Z',
      },
    ]);
  });

  it('discards a step with an unknown substance', () => {
    const rows = [{ id: 's1', plan_id: 'p1', substance: 'botox_pirata', offset_days: 30, status: 'pendente' }];
    expect(normalizeTreatmentPlanSteps(rows)).toEqual([]);
  });

  it('discards a step with a negative offset', () => {
    const rows = [{ id: 's1', plan_id: 'p1', substance: 'bioestimulador', offset_days: -5, status: 'pendente' }];
    expect(normalizeTreatmentPlanSteps(rows)).toEqual([]);
  });

  it('discards a step with an unknown status', () => {
    const rows = [{ id: 's1', plan_id: 'p1', substance: 'bioestimulador', offset_days: 30, status: 'em_andamento' }];
    expect(normalizeTreatmentPlanSteps(rows)).toEqual([]);
  });

  it('keeps other valid steps when one row in the batch is malformed', () => {
    const rows = [
      { id: 's1', plan_id: 'p1', substance: 'toxina_botulinica', offset_days: 0, status: 'pendente' },
      { id: 's2', plan_id: 'p1', substance: 'substancia_invalida', offset_days: 30, status: 'pendente' },
    ];
    expect(normalizeTreatmentPlanSteps(rows)).toHaveLength(1);
    expect(normalizeTreatmentPlanSteps(rows)[0].id).toBe('s1');
  });
});

describe('sortTreatmentPlanSteps', () => {
  it('sorts by offsetDays ascending', () => {
    const steps = [
      { id: 'c', offsetDays: 60, stepOrder: 0 },
      { id: 'a', offsetDays: 0, stepOrder: 0 },
      { id: 'b', offsetDays: 30, stepOrder: 0 },
    ];
    expect(sortTreatmentPlanSteps(steps).map((s) => s.id)).toEqual(['a', 'b', 'c']);
  });

  it('breaks ties on equal offsetDays using stepOrder', () => {
    const steps = [
      { id: 'second', offsetDays: 0, stepOrder: 1 },
      { id: 'first', offsetDays: 0, stepOrder: 0 },
    ];
    expect(sortTreatmentPlanSteps(steps).map((s) => s.id)).toEqual(['first', 'second']);
  });

  it('does not mutate the original array', () => {
    const steps = [{ id: 'b', offsetDays: 30, stepOrder: 0 }, { id: 'a', offsetDays: 0, stepOrder: 0 }];
    const original = [...steps];
    sortTreatmentPlanSteps(steps);
    expect(steps).toEqual(original);
  });
});

describe('nextStepOrder', () => {
  it('returns 0 for an empty plan', () => {
    expect(nextStepOrder([])).toBe(0);
  });

  it('returns max(stepOrder) + 1', () => {
    expect(nextStepOrder([{ stepOrder: 0 }, { stepOrder: 2 }, { stepOrder: 1 }])).toBe(3);
  });
});

describe('computeStepExpectedDate', () => {
  const ymd = (d: Date) => format(d, 'yyyy-MM-dd');

  it('adds offsetDays to the plan start date (dia 0 = mesma data)', () => {
    const result = computeStepExpectedDate('2026-09-11', 0);
    expect(ymd(result)).toBe('2026-09-11');
  });

  it('computes "toxina hoje + bioestimulador em 30 dias + skinbooster em 60 dias"', () => {
    const start = '2026-01-01';
    expect(ymd(computeStepExpectedDate(start, 0))).toBe('2026-01-01');
    expect(ymd(computeStepExpectedDate(start, 30))).toBe('2026-01-31');
    expect(ymd(computeStepExpectedDate(start, 60))).toBe('2026-03-02');
  });

  it('accepts a Date instance for the start date, not only a string', () => {
    const start = new Date(2026, 0, 1); // 1 jan 2026, local time
    const result = computeStepExpectedDate(start, 10);
    expect(result.getDate()).toBe(11);
    expect(result.getMonth()).toBe(0);
    expect(result.getFullYear()).toBe(2026);
  });

  it('recalculates automatically when the plan start date changes, without touching the step', () => {
    const offsetDays = 30;
    const originalStart = '2026-01-01';
    const postponedStart = '2026-01-15';
    expect(ymd(computeStepExpectedDate(originalStart, offsetDays))).toBe('2026-01-31');
    expect(ymd(computeStepExpectedDate(postponedStart, offsetDays))).toBe('2026-02-14');
  });
});

describe('validateTreatmentPlanDraft / buildTreatmentPlanPayload', () => {
  it('rejects an empty name', () => {
    expect(validateTreatmentPlanDraft({ name: '   ', description: '', startDate: '2026-09-11' })).toBe('invalidName');
  });

  it('rejects an invalid start date', () => {
    expect(validateTreatmentPlanDraft({ name: 'Protocolo', description: '', startDate: '' })).toBe('invalidStartDate');
  });

  it('accepts a well-formed draft', () => {
    expect(validateTreatmentPlanDraft({ name: 'Protocolo', description: '', startDate: '2026-09-11' })).toBeNull();
  });

  it('builds the insert payload, trimming name and nulling an empty description', () => {
    const payload = buildTreatmentPlanPayload(
      { name: '  Protocolo Combo  ', description: '  ', startDate: '2026-09-11' },
      { professionalId: 'prof-1', patientId: 'pat-1' },
    );
    expect(payload).toEqual({
      professional_id: 'prof-1',
      patient_id: 'pat-1',
      name: 'Protocolo Combo',
      description: null,
      start_date: '2026-09-11',
    });
  });
});

describe('validateTreatmentPlanStepDraft / buildTreatmentPlanStepPayload', () => {
  it('rejects an unknown substance', () => {
    expect(validateTreatmentPlanStepDraft({ substance: 'coisa_qualquer', offsetDays: 30, notes: '' })).toBe('invalidSubstance');
  });

  it('rejects a negative offset', () => {
    expect(validateTreatmentPlanStepDraft({ substance: 'toxina_botulinica', offsetDays: -1, notes: '' })).toBe('invalidOffset');
  });

  it('accepts offsetDays of 0 (etapa no mesmo dia do início do plano)', () => {
    expect(validateTreatmentPlanStepDraft({ substance: 'toxina_botulinica', offsetDays: 0, notes: '' })).toBeNull();
  });

  it('builds the insert payload with the given step order, rounding a fractional offset', () => {
    const payload = buildTreatmentPlanStepPayload(
      { substance: 'bioestimulador', offsetDays: 30.7, notes: '  Aplicar em camadas  ' },
      { professionalId: 'prof-1', planId: 'plan-1', stepOrder: 2 },
    );
    expect(payload).toEqual({
      professional_id: 'prof-1',
      plan_id: 'plan-1',
      substance: 'bioestimulador',
      offset_days: 31,
      step_order: 2,
      notes: 'Aplicar em camadas',
    });
  });
});

describe('vincular sessão a etapa', () => {
  it('buildStepSessionLinkPayload marks the step as concluded and stores the session id', () => {
    expect(buildStepSessionLinkPayload('session-42')).toEqual({ session_id: 'session-42', status: 'concluida' });
  });

  it('buildStepSessionUnlinkPayload returns the step to pendente, not pulada', () => {
    expect(buildStepSessionUnlinkPayload()).toEqual({ session_id: null, status: 'pendente' });
  });

  it('buildStepSkipPayload marks the step as skipped without a linked session', () => {
    expect(buildStepSkipPayload()).toEqual({ status: 'pulada', session_id: null });
  });
});
