import { describe, it, expect } from 'vitest';
import {
  normalizeAdverseEvents,
  validateAdverseEventDraft,
  buildAdverseEventPayload,
  severityRank,
  type AdverseEventDraft,
} from './adverseEvents';

describe('normalizeAdverseEvents', () => {
  it('normalizes a well-formed row, including the joined insumo brand name', () => {
    const rows = [
      {
        id: 'ae-1',
        patient_id: 'pat-1',
        session_id: 'ses-1',
        insumo_id: 'ins-1',
        event_type: 'nodulo',
        severity: 'moderada',
        description: 'Nódulo palpável na região malar direita, 3 dias após aplicação.',
        occurred_at: '2026-09-05T14:00:00.000Z',
        created_at: '2026-09-05T14:05:00.000Z',
        insumo: { brand_name: 'Juvederm Voluma' },
      },
    ];
    expect(normalizeAdverseEvents(rows)).toEqual([
      {
        id: 'ae-1',
        patientId: 'pat-1',
        sessionId: 'ses-1',
        insumoId: 'ins-1',
        insumoBrandName: 'Juvederm Voluma',
        eventType: 'nodulo',
        severity: 'moderada',
        description: 'Nódulo palpável na região malar direita, 3 dias após aplicação.',
        occurredAt: '2026-09-05T14:00:00.000Z',
        createdAt: '2026-09-05T14:05:00.000Z',
      },
    ]);
  });

  it('handles the insumo join arriving as an array of one item (PostgREST version quirk)', () => {
    const rows = [
      {
        id: 'ae-1',
        event_type: 'outro',
        severity: 'leve',
        description: 'Vermelhidão leve, resolvida em 24h.',
        occurred_at: '2026-09-05T14:00:00.000Z',
        insumo: [{ brand_name: 'Dysport' }],
      },
    ];
    expect(normalizeAdverseEvents(rows)[0].insumoBrandName).toBe('Dysport');
  });

  it('nulls out insumoBrandName and the optional foreign keys when absent', () => {
    const rows = [
      {
        id: 'ae-1',
        event_type: 'reacao_alergica',
        severity: 'grave',
        description: 'Edema generalizado, atendimento de emergência.',
        occurred_at: '2026-09-05T14:00:00.000Z',
      },
    ];
    const result = normalizeAdverseEvents(rows)[0];
    expect(result.patientId).toBeNull();
    expect(result.sessionId).toBeNull();
    expect(result.insumoId).toBeNull();
    expect(result.insumoBrandName).toBeNull();
  });

  it('discards a row with an unknown event type, unknown severity, empty description or invalid date', () => {
    const rows = [
      { id: 'ae-1', event_type: 'infarto', severity: 'leve', description: 'x', occurred_at: '2026-09-05T14:00:00.000Z' },
      { id: 'ae-2', event_type: 'nodulo', severity: 'catastrofica', description: 'x', occurred_at: '2026-09-05T14:00:00.000Z' },
      { id: 'ae-3', event_type: 'nodulo', severity: 'leve', description: '   ', occurred_at: '2026-09-05T14:00:00.000Z' },
      { id: 'ae-4', event_type: 'nodulo', severity: 'leve', description: 'x', occurred_at: 'not-a-date' },
      { id: 'ae-5', event_type: 'oclusao_vascular', severity: 'grave', description: 'Evento válido.', occurred_at: '2026-09-05T14:00:00.000Z' },
    ];
    const result = normalizeAdverseEvents(rows);
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe('ae-5');
  });

  it('returns an empty list for non-array input', () => {
    expect(normalizeAdverseEvents(null)).toEqual([]);
    expect(normalizeAdverseEvents(undefined)).toEqual([]);
  });
});

describe('validateAdverseEventDraft', () => {
  const validDraft: AdverseEventDraft = {
    eventType: 'nodulo',
    severity: 'moderada',
    description: 'Nódulo palpável, sem sinais de infecção.',
    occurredAtDate: '2026-09-05',
    occurredAtTime: '14:00',
  };

  it('accepts a fully valid draft', () => {
    expect(validateAdverseEventDraft(validDraft)).toBeNull();
  });

  it('rejects an unknown event type', () => {
    expect(validateAdverseEventDraft({ ...validDraft, eventType: 'infarto' })).toBe('invalidEventType');
  });

  it('rejects an unknown severity', () => {
    expect(validateAdverseEventDraft({ ...validDraft, severity: 'catastrofica' })).toBe('invalidSeverity');
  });

  it('rejects an empty or whitespace-only description', () => {
    expect(validateAdverseEventDraft({ ...validDraft, description: '   ' })).toBe('invalidDescription');
  });

  it('rejects a missing date or time', () => {
    expect(validateAdverseEventDraft({ ...validDraft, occurredAtDate: '' })).toBe('invalidDate');
    expect(validateAdverseEventDraft({ ...validDraft, occurredAtTime: '' })).toBe('invalidDate');
  });
});

describe('buildAdverseEventPayload', () => {
  it('combines date and time into a single ISO occurred_at and carries the optional links through', () => {
    const draft: AdverseEventDraft = {
      eventType: 'nodulo',
      severity: 'grave',
      description: '  Nódulo extenso, encaminhado para avaliação.  ',
      occurredAtDate: '2026-09-05',
      occurredAtTime: '14:30',
    };
    const payload = buildAdverseEventPayload(draft, {
      professionalId: 'pro-1',
      patientId: 'pat-1',
      sessionId: 'ses-1',
      insumoId: 'ins-1',
    });
    expect(payload).toMatchObject({
      professional_id: 'pro-1',
      patient_id: 'pat-1',
      session_id: 'ses-1',
      insumo_id: 'ins-1',
      event_type: 'nodulo',
      severity: 'grave',
      description: 'Nódulo extenso, encaminhado para avaliação.',
    });
    expect(new Date(payload.occurred_at).toISOString()).toBe(payload.occurred_at);
  });

  it('carries null through for unlinked session/insumo', () => {
    const draft: AdverseEventDraft = {
      eventType: 'outro',
      severity: 'leve',
      description: 'Evento sem sessão ou insumo identificado.',
      occurredAtDate: '2026-09-05',
      occurredAtTime: '09:00',
    };
    const payload = buildAdverseEventPayload(draft, {
      professionalId: 'pro-1',
      patientId: 'pat-1',
      sessionId: null,
      insumoId: null,
    });
    expect(payload.session_id).toBeNull();
    expect(payload.insumo_id).toBeNull();
  });
});

describe('severityRank', () => {
  it('orders leve < moderada < grave', () => {
    expect(severityRank('leve')).toBeLessThan(severityRank('moderada'));
    expect(severityRank('moderada')).toBeLessThan(severityRank('grave'));
  });
});
