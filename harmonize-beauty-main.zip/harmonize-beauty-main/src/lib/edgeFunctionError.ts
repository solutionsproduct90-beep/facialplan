// Leitura do corpo de erro de uma edge function chamada via
// `supabase.functions.invoke`.
//
// Achado do squad w1-3: as edge functions deste repo já devolvem mensagens
// de erro escritas para o profissional ler ("Assinatura inativa. Regularize
// seu pagamento..." em analyze-face/generate-simulation, entre outras) — mas
// nenhuma delas chegava à tela. O motivo é o contrato do supabase-js v2:
// numa resposta não-2xx ele devolve `{ data: null, error: FunctionsHttpError }`
// e guarda a Response crua em `error.context`, sem nunca ler o JSON. O
// código do client então caía no `error.message` genérico do SDK ("Edge
// Function returned a non-2xx status code") e a mensagem acionável se
// perdia.
//
// Isso não era problema enquanto as recusas eram raras e técnicas; virou
// problema com o gate de consentimento do paciente (ver
// supabase/functions/_shared/consentGate.ts), onde a mensagem é justamente
// a instrução do que o profissional precisa fazer para destravar.
//
// Cobre as duas formas que as functions deste repo usam:
//   - resposta 2xx com `{ error: "..." }` no corpo (padrão antigo, ainda
//     usado em alguns caminhos) — vem em `data`;
//   - resposta não-2xx com o mesmo corpo — vem em `error.context`.

/** Código de recusa por falta de consentimento do paciente. Duplicado do
 * servidor (PATIENT_CONSENT_REQUIRED_CODE em
 * supabase/functions/_shared/consentGate.ts) de propósito: as edge functions
 * são Deno/TS fora do bundle do client, e o repo já mantém constantes assim
 * em sincronia manual (ver KNOWN_REGIONS em analyze-face vs
 * src/lib/faceRegions.ts). Se mudar lá, mude aqui. */
export const PATIENT_CONSENT_REQUIRED_CODE = 'patient_consent_required';

export interface EdgeFunctionErrorBody {
  /** Mensagem já escrita para o profissional, em PT (texto legal/acionável fica no servidor). */
  error?: string;
  /** Código estável de recusa, quando a function define um (ex.: PATIENT_CONSENT_REQUIRED_CODE). */
  code?: string;
  /** Status HTTP da resposta, quando ela veio como não-2xx (ver `hasResponseContext`
   * abaixo). O gate de assinatura (`_shared/subscriptionGate.ts`, em analyze-face,
   * generate-simulation, read-insumo-label etc.) sempre responde 402 mas NUNCA
   * define um `code` estável como o do consentimento — então `isSubscriptionInactiveRefusal`
   * abaixo reconhece essa recusa pelo status, não por um código. Ausente numa
   * resposta 2xx com `{ error }` no corpo (padrão antigo) porque não há Response
   * não-2xx pra ler o status. */
  status?: number;
}

function hasResponseContext(err: unknown): err is { context: Response } {
  return (
    !!err &&
    typeof err === 'object' &&
    'context' in err &&
    typeof (err as { context?: unknown }).context === 'object' &&
    (err as { context?: unknown }).context !== null &&
    typeof (err as { context: { json?: unknown } }).context.json === 'function'
  );
}

/**
 * Extrai `{ error, code }` de uma chamada a `supabase.functions.invoke`.
 * Nunca lança: uma resposta sem corpo JSON (ex.: 502 de gateway com HTML)
 * simplesmente devolve `null`, e quem chama cai no texto traduzido de
 * fallback.
 */
export async function readEdgeFunctionError(
  invokeError: unknown,
  data: unknown,
): Promise<EdgeFunctionErrorBody | null> {
  if (data && typeof data === 'object') {
    const body = data as EdgeFunctionErrorBody;
    if (typeof body.error === 'string' && body.error) {
      return { error: body.error, code: typeof body.code === 'string' ? body.code : undefined };
    }
  }

  if (hasResponseContext(invokeError)) {
    try {
      // `context` é a Response crua; clonamos para não consumir o corpo de
      // quem eventualmente já o tenha lido antes.
      const parsed = await invokeError.context.clone().json();
      if (parsed && typeof parsed === 'object') {
        const body = parsed as EdgeFunctionErrorBody;
        return {
          error: typeof body.error === 'string' ? body.error : undefined,
          code: typeof body.code === 'string' ? body.code : undefined,
          status: invokeError.context.status,
        };
      }
    } catch {
      // Corpo não-JSON ou já consumido — sem mensagem útil a extrair.
    }
  }

  return null;
}

/** Atalho de leitura: esta falha foi uma recusa por falta de consentimento do paciente? */
export function isPatientConsentRefusal(body: EdgeFunctionErrorBody | null): boolean {
  return body?.code === PATIENT_CONSENT_REQUIRED_CODE;
}

/**
 * Atalho de leitura: esta falha foi o gate de assinatura inativa
 * (`_shared/subscriptionGate.ts`) recusando a chamada? Reconhece pelo status
 * HTTP (402) — diferente de `isPatientConsentRefusal`, este gate não define
 * um `code` estável no corpo, só a mensagem já escrita pra o profissional (ver
 * `EdgeFunctionErrorBody.status`). Quem chama isso precisa BLOQUEAR o fluxo
 * (nunca cair num fallback de demonstração): gerar uma análise/simulação
 * fabricada pra quem está inadimplente esconde exatamente a única coisa que
 * ele precisa fazer.
 */
export function isSubscriptionInactiveRefusal(body: EdgeFunctionErrorBody | null): boolean {
  return body?.status === 402;
}
