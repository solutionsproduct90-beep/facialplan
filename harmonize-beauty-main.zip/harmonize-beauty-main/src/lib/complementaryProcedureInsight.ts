// Sugestão Complementar de Procedimento (Produto & Features, ciclo 14/09,
// squad P9-4) — ver comentário de arquivo em
// supabase/migrations/20260914100000_add_complementary_procedure_insight_rpc.sql
// para as decisões de produto/privacidade completas (coocorrência POR
// PACIENTE, agregação CROSS-PROFISSIONAL — mesmo escopo de
// get_manual_point_justification_stats —, corte de amostra mínima).
//
// Alimenta um insight PASSIVO no Estágio 2 quando o profissional seleciona um
// Procedimento nomeado do catálogo (ver src/lib/procedureCatalog.ts, backlog
// #47): "pacientes com [procedimento selecionado] combinam com frequência com
// [outro procedimento]". DIFERENTE do Recomendador de marca por
// custo-benefício (suggestInsumo em src/lib/budget.ts, que otimiza margem de
// uma substância já escolhida) e do Plano B / Combo Plans (reduceToPlanB em
// src/lib/procedureCatalog.ts, 100% manual) — este é um padrão de mercado
// observado na própria base, nunca preenche nada sozinho, nunca bloqueia o
// fluxo, só aparece quando a RPC devolve uma linha.
import { getProcedure, procedureNameKey } from './procedureCatalog';

/** Linha crua devolvida por `get_complementary_procedure_insight` — a própria RPC já aplica o corte de amostra mínima e o filtro de consentimento em SQL, nunca uma contagem exata nem coluna de paciente. */
export type ComplementaryProcedureInsightRow = {
  complementary_procedure_key: string | null;
};

/**
 * Extrai a chave do procedimento complementar da linha crua devolvida pela
 * RPC — que já aplica o corte de amostra mínima inteiramente em SQL (nunca em
 * TypeScript, mesmo padrão de mapManualPointJustificationStatsRow em
 * src/lib/manualPointJustification.ts). Aqui só resta tratar "zero linhas"
 * (`row` ausente) ou uma chave vazia/nula como `null` — o sinal para a UI não
 * mostrar insight nenhum, sem erro, sem estado vazio chamativo: ausência de
 * padrão suficiente é o comportamento NORMAL, não uma falha.
 */
export function mapComplementaryProcedureInsightRow(
  row: ComplementaryProcedureInsightRow | null | undefined,
): string | null {
  if (!row || !row.complementary_procedure_key) return null;
  return row.complementary_procedure_key;
}

/** Mesma assinatura mínima de `t` do i18next usada em src/lib/namedProtocols.ts (`Translate`). */
type Translate = (key: string, options?: Record<string, unknown>) => string;

/**
 * Texto exibível do insight ("Pacientes com [A] combinam com frequência com
 * [B].") já com os dois nomes de procedimento resolvidos via `translate` (com
 * fallback para o nome em português do catálogo, mesmo padrão de
 * procedureDisplayName) — ou `undefined` quando o procedimento selecionado ou
 * o complementar devolvido não são (mais) reconhecidos no catálogo (dado
 * desatualizado/removido), caso em que o chamador simplesmente não mostra
 * nada, o mesmo tratamento de uma RPC sem amostra suficiente.
 */
export function complementaryProcedureInsightText(
  selectedProcedureId: string,
  complementaryProcedureId: string,
  translate: Translate,
): string | undefined {
  const selected = getProcedure(selectedProcedureId);
  const complementary = getProcedure(complementaryProcedureId);
  if (!selected || !complementary) return undefined;

  const selectedName = translate(procedureNameKey(selected.id), { defaultValue: selected.name });
  const complementaryName = translate(procedureNameKey(complementary.id), { defaultValue: complementary.name });

  return translate('sessions.stage2.complementaryProcedureInsight.text', {
    selectedProcedure: selectedName,
    complementaryProcedure: complementaryName,
  });
}
