import { describe, it, expect } from 'vitest';
import { computeBudget, computeInstallments, computeCashDiscount, normalizeInsumos, priceForPoint, suggestInsumo, formatCurrency } from './budget';
import type { ApplicationPoint, Insumo } from '@/types/harmonize';

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'malar_direita',
  label: 'Malar Direita',
  substance: 'acido_hialuronico',
  quantity: 2,
  unit: 'ml',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

const insumo = (overrides: Partial<Insumo> = {}): Insumo => ({
  id: 'ins-ha-voluma',
  substance: 'acido_hialuronico',
  brandName: 'Juvederm Voluma',
  costPerUnit: 400,
  pricePerUnit: 1500,
  active: true,
  ...overrides,
});

const insumos: Insumo[] = [
  insumo({ id: 'ins-ha-voluma', substance: 'acido_hialuronico', costPerUnit: 400, pricePerUnit: 1500 }),
  insumo({ id: 'ins-tox-dysport', substance: 'toxina_botulinica', brandName: 'Dysport', costPerUnit: 15, pricePerUnit: 40 }),
  insumo({ id: 'ins-ha-inactive', substance: 'acido_hialuronico', brandName: 'Descontinuada', active: false, costPerUnit: 1, pricePerUnit: 1 }),
];

describe('computeBudget', () => {
  it('returns zeroed budget when insumos have not been loaded (null)', () => {
    const budget = computeBudget([point()], null, 100);
    expect(budget.totalCost).toBe(0);
    expect(budget.totalPrice).toBe(0);
    expect(budget.unpriced).toEqual([]);
  });

  it('computes cost, price and margin from each point\'s chosen insumo, adding the labor fee once', () => {
    const points = [
      point({ id: 'p1', substance: 'acido_hialuronico', quantity: 2, unit: 'ml', insumoId: 'ins-ha-voluma' }),
      point({ id: 'p2', substance: 'toxina_botulinica', quantity: 20, unit: 'unidades', insumoId: 'ins-tox-dysport' }),
    ];
    const budget = computeBudget(points, insumos, 100);
    // cost: 2*400 + 20*15 = 1100 ; price: 2*1500 + 20*40 + 100(labor) = 3900
    expect(budget.totalCost).toBe(1100);
    expect(budget.totalPrice).toBe(3900);
    expect(budget.margin).toBe(2800);
    expect(budget.marginPct).toBeCloseTo(2800 / 3900);
    expect(budget.totalMl).toBe(2);
    expect(budget.totalUnits).toBe(20);
    expect(budget.unpriced).toEqual([]);
  });

  it('flags a point with no insumo chosen as unpriced, without charging the labor fee', () => {
    const points = [point({ substance: 'bioestimulador', quantity: 1, unit: 'ml' })];
    const budget = computeBudget(points, insumos, 100);
    expect(budget.totalPrice).toBe(0);
    expect(budget.unpriced).toHaveLength(1);
  });

  it('flags a point whose insumo is inactive or does not exist as unpriced', () => {
    const points = [
      point({ id: 'p1', insumoId: 'ins-ha-inactive' }),
      point({ id: 'p2', insumoId: 'does-not-exist' }),
    ];
    const budget = computeBudget(points, insumos, 100);
    expect(budget.unpriced.map((p) => p.id)).toEqual(['p1', 'p2']);
    expect(budget.totalPrice).toBe(0);
  });

  it('respects includedIds — excluding a point drops it from the total (Plano A/B toggle)', () => {
    const points = [
      point({ id: 'p1', substance: 'acido_hialuronico', quantity: 2, unit: 'ml', insumoId: 'ins-ha-voluma' }),
      point({ id: 'p2', substance: 'toxina_botulinica', quantity: 20, unit: 'unidades', insumoId: 'ins-tox-dysport' }),
    ];
    const onlyFirst = computeBudget(points, insumos, 100, new Set(['p1']));
    expect(onlyFirst.totalMl).toBe(2);
    expect(onlyFirst.totalUnits).toBe(0);
    // cost: 2*400=800 ; price: 2*1500 + 100(labor) = 3100
    expect(onlyFirst.totalCost).toBe(800);
    expect(onlyFirst.totalPrice).toBe(3100);
  });

  it('flags points without a chosen insumo, without breaking the rest', () => {
    const points = [
      point({ id: 'p1', substance: 'acido_hialuronico', quantity: 1, unit: 'ml', insumoId: 'ins-ha-voluma' }),
      point({ id: 'p2', substance: 'bioestimulador', quantity: 1, unit: 'ml' }),
    ];
    const budget = computeBudget(points, insumos, undefined);
    expect(budget.unpriced.map(p => p.id)).toEqual(['p2']);
    expect(budget.totalCost).toBe(400);
  });
});

describe('priceForPoint', () => {
  it('returns the price for a point with an active chosen insumo', () => {
    expect(priceForPoint(point({ quantity: 2, insumoId: 'ins-ha-voluma' }), insumos)).toBe(3000);
  });

  it('returns null when there is no insumo chosen, or it is missing/inactive', () => {
    expect(priceForPoint(point(), insumos)).toBeNull();
    expect(priceForPoint(point({ insumoId: 'ins-ha-inactive' }), insumos)).toBeNull();
    expect(priceForPoint(point({ insumoId: 'nope' }), insumos)).toBeNull();
    expect(priceForPoint(point({ insumoId: 'ins-ha-voluma' }), null)).toBeNull();
  });
});

describe('computeInstallments', () => {
  it('splits the total evenly with no interest, from 1x up to the max', () => {
    const installments = computeInstallments(1200, 3);
    expect(installments).toEqual([
      { n: 1, value: 1200 },
      { n: 2, value: 600 },
      { n: 3, value: 400 },
    ]);
  });

  it('returns an empty list for a non-positive total', () => {
    expect(computeInstallments(0, 12)).toEqual([]);
    expect(computeInstallments(-10, 12)).toEqual([]);
  });

  it('returns an empty list when the professional has not configured a max — never assumes a default', () => {
    expect(computeInstallments(1200, null)).toEqual([]);
    expect(computeInstallments(1200, undefined)).toEqual([]);
    expect(computeInstallments(1200, 0)).toEqual([]);
  });
});

describe('computeCashDiscount', () => {
  it('applies the given percentage off the total', () => {
    expect(computeCashDiscount(1000, 5)).toBe(950);
  });

  it('returns null for a non-positive total', () => {
    expect(computeCashDiscount(0, 5)).toBeNull();
  });

  it('returns null when the professional has not configured a discount — never assumes a default', () => {
    expect(computeCashDiscount(1000, null)).toBeNull();
    expect(computeCashDiscount(1000, undefined)).toBeNull();
    expect(computeCashDiscount(1000, 0)).toBeNull();
  });
});

describe('normalizeInsumos', () => {
  it('returns an empty list for null/undefined/malformed input', () => {
    expect(normalizeInsumos(null)).toEqual([]);
    expect(normalizeInsumos(undefined)).toEqual([]);
    expect(normalizeInsumos('not an array')).toEqual([]);
    expect(normalizeInsumos({})).toEqual([]);
  });

  it('discards rows with an unknown substance, missing brand, or non-numeric cost/price', () => {
    const rows = [
      { id: 'a', substance: 'fios_pdo', brand_name: 'X', cost_per_unit: 1, price_per_unit: 2, active: true },
      { id: 'b', substance: 'acido_hialuronico', brand_name: '', cost_per_unit: 1, price_per_unit: 2, active: true },
      { id: 'c', substance: 'acido_hialuronico', brand_name: 'Y', cost_per_unit: 'abc', price_per_unit: 2, active: true },
      { id: '', substance: 'acido_hialuronico', brand_name: 'Z', cost_per_unit: 1, price_per_unit: 2, active: true },
    ];
    expect(normalizeInsumos(rows)).toEqual([]);
  });

  it('normalizes a valid row, converting snake_case to camelCase and coercing numeric strings', () => {
    const rows = [
      { id: 'ins-1', substance: 'toxina_botulinica', brand_name: 'Dysport', cost_per_unit: '15.5', price_per_unit: '40', active: true },
    ];
    expect(normalizeInsumos(rows)).toEqual([
      { id: 'ins-1', substance: 'toxina_botulinica', brandName: 'Dysport', costPerUnit: 15.5, pricePerUnit: 40, active: true },
    ]);
  });

  it('defaults active to true when the column is missing/null, but keeps an explicit false', () => {
    const rows = [
      { id: 'a', substance: 'acido_hialuronico', brand_name: 'X', cost_per_unit: 1, price_per_unit: 2, active: null },
      { id: 'b', substance: 'acido_hialuronico', brand_name: 'Y', cost_per_unit: 1, price_per_unit: 2, active: false },
    ];
    const normalized = normalizeInsumos(rows);
    expect(normalized.find(i => i.id === 'a')?.active).toBe(true);
    expect(normalized.find(i => i.id === 'b')?.active).toBe(false);
  });

  it('carries concentration/expiresOn (read-insumo-label AI suggestion or manual entry) when present, omitting them when absent', () => {
    const rows = [
      { id: 'a', substance: 'acido_hialuronico', brand_name: 'X', cost_per_unit: 1, price_per_unit: 2, active: true, concentration: '20mg/mL', expires_on: '2027-05-01' },
      { id: 'b', substance: 'acido_hialuronico', brand_name: 'Y', cost_per_unit: 1, price_per_unit: 2, active: true, concentration: null, expires_on: null },
    ];
    const normalized = normalizeInsumos(rows);
    expect(normalized.find(i => i.id === 'a')).toMatchObject({ concentration: '20mg/mL', expiresOn: '2027-05-01' });
    const b = normalized.find(i => i.id === 'b');
    expect(b?.concentration).toBeUndefined();
    expect(b?.expiresOn).toBeUndefined();
  });
});

describe('formatCurrency', () => {
  it('defaults to BRL when no currency is given', () => {
    expect(formatCurrency(1234.5)).toMatch(/R\$\s*1\.234,50/);
  });

  it('formats BRL as pt-BR currency', () => {
    expect(formatCurrency(1234.5, 'BRL')).toMatch(/R\$\s*1\.234,50/);
  });

  it('formats USD as en-US currency', () => {
    expect(formatCurrency(1234.5, 'USD')).toMatch(/\$1,234\.50/);
  });

  it('formats EUR as de-DE currency', () => {
    expect(formatCurrency(1234.5, 'EUR')).toMatch(/1\.234,50\s*€/);
  });

  it('formats GBP as en-GB currency', () => {
    expect(formatCurrency(1234.5, 'GBP')).toMatch(/£1,234\.50/);
  });
});

describe('suggestInsumo', () => {
  it('returns null when insumos have not been loaded (null/undefined)', () => {
    expect(suggestInsumo(null, 'acido_hialuronico')).toBeNull();
    expect(suggestInsumo(undefined, 'acido_hialuronico')).toBeNull();
  });

  it('returns null when there is no active insumo for the substance', () => {
    expect(suggestInsumo(insumos, 'bioestimulador')).toBeNull();
  });

  it('picks the insumo with the highest absolute margin (price - cost) for the substance', () => {
    const options: Insumo[] = [
      insumo({ id: 'low-margin', substance: 'acido_hialuronico', costPerUnit: 400, pricePerUnit: 1500 }), // margin 1100
      insumo({ id: 'high-margin', substance: 'acido_hialuronico', brandName: 'Restylane', costPerUnit: 300, pricePerUnit: 1600 }), // margin 1300
      insumo({ id: 'other-substance', substance: 'toxina_botulinica', costPerUnit: 1, pricePerUnit: 1000 }),
    ];
    expect(suggestInsumo(options, 'acido_hialuronico')?.id).toBe('high-margin');
  });

  it('ignores inactive insumos even when they have the best margin', () => {
    const options: Insumo[] = [
      insumo({ id: 'active-lower', substance: 'acido_hialuronico', costPerUnit: 400, pricePerUnit: 1500, active: true }), // margin 1100
      insumo({ id: 'inactive-higher', substance: 'acido_hialuronico', costPerUnit: 1, pricePerUnit: 5000, active: false }), // margin 4999, but inactive
    ];
    expect(suggestInsumo(options, 'acido_hialuronico')?.id).toBe('active-lower');
  });

  it('breaks a tie in absolute margin by the higher margin percentage', () => {
    const options: Insumo[] = [
      // both have margin 100, but the second has a much better margin percentage
      insumo({ id: 'expensive-tie', substance: 'acido_hialuronico', costPerUnit: 1000, pricePerUnit: 1100 }),
      insumo({ id: 'cheap-tie', substance: 'acido_hialuronico', costPerUnit: 10, pricePerUnit: 110 }),
    ];
    expect(suggestInsumo(options, 'acido_hialuronico')?.id).toBe('cheap-tie');
  });

  it('keeps the first registered brand when margin and margin percentage fully tie', () => {
    const options: Insumo[] = [
      insumo({ id: 'first', substance: 'acido_hialuronico', costPerUnit: 400, pricePerUnit: 1500 }),
      insumo({ id: 'second', substance: 'acido_hialuronico', costPerUnit: 400, pricePerUnit: 1500 }),
    ];
    expect(suggestInsumo(options, 'acido_hialuronico')?.id).toBe('first');
  });
});
