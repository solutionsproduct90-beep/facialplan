import { describe, it, expect } from "vitest";
import { isValidEmail } from "./email";

describe("isValidEmail — validação de formato do e-mail (opcional) do paciente", () => {
  it("accepts well-formed emails", () => {
    expect(isValidEmail("paciente@exemplo.com")).toBe(true);
    expect(isValidEmail("nome.sobrenome@clinica.com.br")).toBe(true);
    expect(isValidEmail("  paciente@exemplo.com  ")).toBe(true);
  });

  it("rejects malformed emails", () => {
    expect(isValidEmail("paciente@")).toBe(false);
    expect(isValidEmail("paciente@exemplo")).toBe(false);
    expect(isValidEmail("@exemplo.com")).toBe(false);
    expect(isValidEmail("paciente exemplo.com")).toBe(false);
    expect(isValidEmail("paciente@exe mplo.com")).toBe(false);
  });
});
