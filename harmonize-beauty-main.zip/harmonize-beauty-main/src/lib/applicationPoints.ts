// Agrupamento e divisão de ApplicationPoint em múltiplos pontos discretos
// dentro da mesma região/sugestão — ver comentário de `groupId` em
// src/types/harmonize.ts. Hoje só oferecido na UI (SessaoEstagio2.tsx) para
// toxina_botulinica: clinicamente, glabela costuma levar de 3 a 5 pontos de
// aplicação e o terço frontal de 4 a 6, não um bolus único carregando a dose
// inteira — diferente de ácido hialurônico/bioestimulador, que seguem bem o
// modelo de ponto único já existente.
import type { ApplicationPoint, Substance } from '@/types/harmonize';

/** Só toxina botulínica ganha a opção de desdobrar uma região em vários
 * pontos nesta UI — ver comentário de arquivo acima. */
export function supportsMultiPoint(substance: Substance): boolean {
  return substance === 'toxina_botulinica';
}

/** Chave de agrupamento de um ponto: `groupId` quando presente, senão o
 * próprio `id` — ou seja, todo ponto sem groupId é, por padrão, seu próprio
 * grupo de 1 (comportamento idêntico ao modelo anterior). */
export function groupKeyOf(point: ApplicationPoint): string {
  return point.groupId ?? point.id;
}

export type ApplicationPointGroup = { key: string; points: ApplicationPoint[] };

/** Agrupa a lista plana de pontos por `groupKeyOf`, preservando a ordem de
 * primeira aparição — é o que permite uma única sugestão aceita (ex.
 * "Glabela") renderizar e ser editada como um conjunto de 1..n pontos. */
export function groupApplicationPoints(points: ApplicationPoint[]): ApplicationPointGroup[] {
  const order: string[] = [];
  const map = new Map<string, ApplicationPoint[]>();
  for (const p of points) {
    const key = groupKeyOf(p);
    if (!map.has(key)) {
      map.set(key, []);
      order.push(key);
    }
    map.get(key)!.push(p);
  }
  return order.map((key) => ({ key, points: map.get(key)! }));
}

function clamp01(v: number): number {
  return Math.min(0.96, Math.max(0.04, v));
}

// Espalha visualmente os pontos de um grupo desdobrado ao redor da posição
// original, para não empilhar marcadores exatamente um sobre o outro.
function offsetForIndex(index: number): { dx: number; dy: number } {
  const sign = index % 2 === 0 ? 1 : -1;
  const magnitude = 0.03 + Math.floor(index / 2) * 0.015;
  return { dx: sign * magnitude, dy: sign * magnitude * 0.6 };
}

/**
 * Desdobra um grupo em mais um ponto discreto (item 2 do backlog P0): a dose
 * TOTAL do grupo é preservada e redistribuída igualmente entre todos os
 * pontos resultantes — adicionar um ponto não aumenta a dose da região,
 * apenas discretiza a aplicação em mais sítios. O profissional pode ajustar
 * cada quantidade manualmente depois pela edição normal do ponto. No-op se o
 * grupo não existir.
 */
export function addPointToGroup(points: ApplicationPoint[], key: string, newId: string): ApplicationPoint[] {
  const groupPts = points.filter((p) => groupKeyOf(p) === key);
  if (groupPts.length === 0) return points;

  const total = groupPts.reduce((sum, p) => sum + p.quantity, 0);
  const newCount = groupPts.length + 1;
  const evenShare = Math.round((total / newCount) * 100) / 100;
  const template = groupPts[groupPts.length - 1];

  // Quando o ponto template tem uma linha de punctura seriada (ver
  // TechniqueLine em src/types/harmonize.ts), o novo ponto do grupo é
  // posicionado num dos pontos-guia da PRÓPRIA linha — já pensados para
  // representar micropunções ao longo do trajeto real da técnica — em vez do
  // offset diagonal genérico abaixo, que não tem relação nenhuma com a
  // direção da linha desenhada. Percorre o `path` ciclicamente (módulo do
  // comprimento) para continuar funcionando mesmo desdobrando o grupo além
  // do número de pontos-guia disponíveis.
  let newX: number;
  let newY: number;
  if (template.line?.pattern === 'punctura_seriada' && template.line.path.length > 0) {
    const guide = template.line.path[groupPts.length % template.line.path.length];
    newX = clamp01(guide.x);
    newY = clamp01(guide.y);
  } else {
    const { dx, dy } = offsetForIndex(groupPts.length);
    newX = clamp01(template.x + dx);
    newY = clamp01(template.y + dy);
  }

  const newPoint: ApplicationPoint = {
    ...template,
    id: newId,
    groupId: key,
    quantity: evenShare,
    x: newX,
    y: newY,
    // Não é mais o mesmo landmark do ponto original — deixa a posição
    // explícita acima decidir, em vez de herdar um índice que descreve outro
    // lugar da foto. Pelo mesmo motivo, o novo ponto não herda a linha de
    // técnica do template (cada ponto do grupo é seu próprio ponto de
    // punção a partir daqui, sem uma linha derivada).
    landmarkIndex: undefined,
    line: undefined,
  };

  return points
    .map((p) => (groupKeyOf(p) === key ? { ...p, groupId: key, quantity: evenShare } : p))
    .concat(newPoint);
}

/**
 * Remove um ponto de um grupo, redistribuindo a dose total remanescente
 * entre os pontos que sobraram — nunca remove o último ponto de um grupo
 * (uma região sempre precisa de pelo menos 1 ponto de aplicação).
 */
export function removePointFromGroup(points: ApplicationPoint[], key: string, pointId: string): ApplicationPoint[] {
  const groupPts = points.filter((p) => groupKeyOf(p) === key);
  if (groupPts.length <= 1) return points;

  const total = groupPts.reduce((sum, p) => sum + p.quantity, 0);
  const remainingCount = groupPts.length - 1;
  const evenShare = Math.round((total / remainingCount) * 100) / 100;

  return points
    .filter((p) => p.id !== pointId)
    .map((p) => (groupKeyOf(p) === key ? { ...p, quantity: evenShare } : p));
}
