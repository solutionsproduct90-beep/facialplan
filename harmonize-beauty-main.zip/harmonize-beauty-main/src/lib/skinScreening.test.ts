import { describe, it, expect } from "vitest";
import {
  SKIN_SCREENING_CRITERION_KEYS,
  isSkinScreeningComplete,
  hasSuspiciousFinding,
  canProceedDespiteFinding,
  type SkinScreeningAnswers,
} from "./skinScreening";

const allFalse: SkinScreeningAnswers = {
  asymmetry: false,
  irregularBorders: false,
  colorVariation: false,
  diameterOver6mm: false,
  recentEvolution: false,
};

const allUnanswered: SkinScreeningAnswers = {
  asymmetry: null,
  irregularBorders: null,
  colorVariation: null,
  diameterOver6mm: null,
  recentEvolution: null,
};

describe("isSkinScreeningComplete", () => {
  it("is false when no criteria were answered", () => {
    expect(isSkinScreeningComplete(allUnanswered)).toBe(false);
  });

  it("is false when only some criteria were answered", () => {
    expect(
      isSkinScreeningComplete({ ...allFalse, recentEvolution: null })
    ).toBe(false);
  });

  it("is true once every criterion has an explicit true/false answer", () => {
    expect(isSkinScreeningComplete(allFalse)).toBe(true);
    expect(isSkinScreeningComplete({ ...allFalse, asymmetry: true })).toBe(true);
  });

  it("covers all five ABCDE criteria", () => {
    expect(SKIN_SCREENING_CRITERION_KEYS).toEqual([
      "asymmetry",
      "irregularBorders",
      "colorVariation",
      "diameterOver6mm",
      "recentEvolution",
    ]);
  });
});

describe("hasSuspiciousFinding", () => {
  it("is false when every criterion is false", () => {
    expect(hasSuspiciousFinding(allFalse)).toBe(false);
  });

  it("is true when any single criterion is positive", () => {
    for (const key of SKIN_SCREENING_CRITERION_KEYS) {
      expect(hasSuspiciousFinding({ ...allFalse, [key]: true })).toBe(true);
    }
  });

  it("is true when multiple criteria are positive", () => {
    expect(
      hasSuspiciousFinding({ ...allFalse, asymmetry: true, colorVariation: true })
    ).toBe(true);
  });

  it("ignores unanswered (null) criteria rather than treating them as positive", () => {
    expect(hasSuspiciousFinding(allUnanswered)).toBe(false);
  });
});

describe("canProceedDespiteFinding", () => {
  it("refuses when the acknowledgement checkbox is not checked", () => {
    expect(canProceedDespiteFinding("Paciente ciente, decisão compartilhada.", false)).toBe(
      false
    );
  });

  it("refuses when the justification is empty", () => {
    expect(canProceedDespiteFinding("", true)).toBe(false);
  });

  it("refuses when the justification is too short / trivial", () => {
    expect(canProceedDespiteFinding("ok", true)).toBe(false);
    expect(canProceedDespiteFinding("   ", true)).toBe(false);
  });

  it("allows proceeding once acknowledged with a real justification", () => {
    expect(
      canProceedDespiteFinding(
        "Lesão já em acompanhamento dermatológico prévio, longe do sítio de aplicação.",
        true
      )
    ).toBe(true);
  });
});
