import type { AccessProfile } from '@/contexts/AuthContext';

/**
 * Regras de acesso do paywall, no cliente, num lugar só.
 *
 * ATENÇÃO — ESTE É O TERCEIRO DE TRÊS LUGARES QUE PRECISAM CONCORDAR:
 *
 *   1. `public.has_active_subscription(uuid)` no banco (RLS) — a única que
 *      realmente protege os dados.
 *   2. `supabase/functions/_shared/subscriptionGate.ts` — as edge functions.
 *   3. este arquivo — a navegação do app.
 *
 * Os três são mantidos em sincronia manualmente. Uma divergência aqui não
 * vaza dado (a RLS continua valendo), mas produz o pior tipo de bug de
 * produto: a tela deixa entrar e a query volta vazia, ou o contrário.
 * Mudou a regra num, mude nos três.
 */

/**
 * Valores reais de `profiles.subscription_status` gravados pelo webhook da
 * Hotmart (ver supabase/functions/hotmart-webhook): 'active' | 'canceled' |
 * 'refunded' | 'past_due'. O default de coluna é 'inactive' (perfil recém-
 * criado, ainda sem nenhuma assinatura).
 *
 * 'canceled'/'refunded' bloqueiam na hora, sem carência — são cancelamentos
 * deliberados.
 */
export const BLOCKING_STATUSES_NO_GRACE: ReadonlySet<string> = new Set(['canceled', 'refunded']);

/**
 * 'past_due' (pagamento atrasado, sinalizado pelos eventos PURCHASE_DELAYED/
 * SUBSCRIPTION_DELAYED da Hotmart) tem uma carência curta antes do bloqueio
 * efetivo: cartão que falhou numa tentativa e passa na seguinte é rotina, e
 * derrubar o acesso do profissional no meio de um atendimento por causa disso
 * custa mais do que os poucos dias de acesso concedidos.
 *
 * Mesmo número em `subscriptionGate.ts` e em
 * `20260916130000_add_past_due_grace_period.sql`.
 */
export const GRACE_PERIOD_DAYS = 3;

export function isWithinPastDueGrace(
  pastDueSince: string | null | undefined,
  now: number = Date.now(),
): boolean {
  if (!pastDueSince) return false;
  const since = new Date(pastDueSince).getTime();
  // Data inválida gravada na coluna vira "fora da carência" em vez de
  // NaN < graceMs (que já seria false, mas por acidente e não por decisão).
  if (Number.isNaN(since)) return false;
  return now - since < GRACE_PERIOD_DAYS * 24 * 60 * 60 * 1000;
}

/**
 * Para onde este perfil pode ir:
 *
 * - `allow`       — acesso liberado ao app.
 * - `blocked`     — suspensão manual por admin (/conta-bloqueada).
 * - `regularizar` — assinatura existiu e caiu (/regularizar).
 * - `assinar`     — nunca assinou, ou está no default 'inactive' (/assinar).
 *
 * A ordem das checagens importa: `is_blocked` vence qualquer status de
 * assinatura, porque uma conta suspensa pela equipe não volta a funcionar só
 * por estar em dia com o pagamento.
 */
export type AccessDecision = 'allow' | 'blocked' | 'regularizar' | 'assinar';

export function decideAccess(
  profile: AccessProfile | null | undefined,
  now: number = Date.now(),
): AccessDecision {
  if (profile?.is_blocked) return 'blocked';

  // Conta interna da equipe: passa por qualquer status de assinatura. A
  // suspensão manual acima continua valendo, e é a única coisa que barra um
  // admin.
  //
  // Esta checagem vem ANTES dos status de propósito, e é o ponto onde as três
  // camadas precisam concordar: `has_active_subscription()` no banco testa
  // `role = 'admin' OR …` e `subscriptionGate.ts` faz
  // `if (role === 'admin' || …) return true` — as duas antes de olhar
  // 'past_due'. Enquanto isto ficava depois, um admin com 'past_due' vencido
  // era expulso do app pelo cliente e aceito pelo banco e pelas edge
  // functions; justamente a pessoa que precisa entrar para consertar a
  // situação.
  if (profile?.role === 'admin') return 'allow';

  const status = profile?.subscription_status;

  if (status && BLOCKING_STATUSES_NO_GRACE.has(status)) return 'regularizar';

  if (status === 'past_due') {
    return isWithinPastDueGrace(profile?.past_due_since, now) ? 'allow' : 'regularizar';
  }

  // Paywall obrigatório: sem 'active' confirmado pelo webhook, o acesso fica
  // bloqueado — inclui o default 'inactive' e a ausência de registro
  // (null/undefined), ou seja, todo perfil recém-criado antes de assinar.
  if (status !== 'active') return 'assinar';

  return 'allow';
}

/** Açúcar para quem só precisa do sim/não, sem o destino do redirecionamento. */
export function hasAppAccess(
  profile: AccessProfile | null | undefined,
  now: number = Date.now(),
): boolean {
  return decideAccess(profile, now) === 'allow';
}

/**
 * Quantos dias inteiros de carência ainda restam, arredondando para cima, ou
 * `null` quando não há carência em curso (sem data, data inválida, ou prazo
 * já vencido).
 *
 * Arredonda para cima de propósito: faltando 4 horas, a mensagem certa para
 * quem lê é "1 dia", e não "0 dias" — que soa como acesso já perdido — nem
 * um número quebrado. O bloqueio em si continua sendo decidido por
 * `isWithinPastDueGrace`, com o instante exato; isto aqui é só o texto.
 */
export function graceDaysRemaining(
  pastDueSince: string | null | undefined,
  now: number = Date.now(),
): number | null {
  if (!isWithinPastDueGrace(pastDueSince, now)) return null;
  const since = new Date(pastDueSince as string).getTime();
  const remainingMs = since + GRACE_PERIOD_DAYS * 24 * 60 * 60 * 1000 - now;
  return Math.max(1, Math.ceil(remainingMs / (24 * 60 * 60 * 1000)));
}
