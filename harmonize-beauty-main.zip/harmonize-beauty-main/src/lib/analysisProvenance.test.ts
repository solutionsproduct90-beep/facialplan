import { describe, it, expect } from 'vitest';
import {
  analysisProvenance,
  isDemoAnalysis,
  requiresProvenanceStamp,
  provenanceStampKeys,
  patientProvenanceStampKeys,
} from './analysisProvenance';
import type { Stage1Analysis } from '@/types/harmonize';
import pt from '@/i18n/locales/pt.json';
import en from '@/i18n/locales/en.json';
import es from '@/i18n/locales/es.json';
import fr from '@/i18n/locales/fr.json';
import itLocale from '@/i18n/locales/it.json';

const baseAnalysis = {
  suggestions: [],
  patientSummary: 'Rosto oval...',
} as unknown as Stage1Analysis;

describe('analysisProvenance', () => {
  it("lê 'ai' quando a análise foi gravada pela IA de verdade", () => {
    expect(analysisProvenance({ ...baseAnalysis, source: 'ai' })).toBe('ai');
  });

  it("lê 'mock' quando a análise é a de demonstração do fallback", () => {
    expect(analysisProvenance({ ...baseAnalysis, source: 'mock' })).toBe('mock');
  });

  // Regressão do achado que originou esta feature: análise fabricada persistida
  // sem marcador de proveniência. Toda sessão criada antes do carimbo cai aqui,
  // e tratá-la como 'ai' seria afirmar que um dado possivelmente inventado é
  // leitura clínica real — exatamente o risco que se quer eliminar.
  it("nunca assume 'ai' para uma análise SEM marcador (linha antiga) — vira 'unknown'", () => {
    expect(analysisProvenance(baseAnalysis)).toBe('unknown');
    expect(analysisProvenance(null)).toBe('unknown');
    expect(analysisProvenance(undefined)).toBe('unknown');
  });

  it("trata um `source` de tipo inesperado (jsonb não validado) como 'unknown'", () => {
    expect(analysisProvenance({ ...baseAnalysis, source: 42 } as unknown as Stage1Analysis)).toBe('unknown');
    expect(analysisProvenance({ ...baseAnalysis, source: 'AI' } as unknown as Stage1Analysis)).toBe('unknown');
  });

  it('isDemoAnalysis só é verdadeiro para a análise de demonstração', () => {
    expect(isDemoAnalysis({ ...baseAnalysis, source: 'mock' })).toBe(true);
    expect(isDemoAnalysis({ ...baseAnalysis, source: 'ai' })).toBe(false);
    expect(isDemoAnalysis(baseAnalysis)).toBe(false);
  });

  it('requiresProvenanceStamp dispensa o carimbo só quando a análise é de IA', () => {
    expect(requiresProvenanceStamp({ ...baseAnalysis, source: 'ai' })).toBe(false);
    expect(requiresProvenanceStamp({ ...baseAnalysis, source: 'mock' })).toBe(true);
    expect(requiresProvenanceStamp(baseAnalysis)).toBe(true);
  });
});

describe('chaves de carimbo (PDF clínico, exportação, telas)', () => {
  it('não carimba nada quando a análise é de IA', () => {
    expect(provenanceStampKeys('ai')).toBeNull();
    expect(patientProvenanceStampKeys('ai')).toBeNull();
  });

  it('carimba a análise de demonstração com título, corpo e instrução do que fazer', () => {
    expect(provenanceStampKeys('mock')).toEqual({
      title: 'sessions.analysisProvenance.demo.title',
      body: 'sessions.analysisProvenance.demo.body',
      action: 'sessions.analysisProvenance.demo.action',
    });
  });

  it('carimba a sessão sem origem registrada com o texto próprio, não com o de demonstração', () => {
    expect(provenanceStampKeys('unknown')).toEqual({
      title: 'sessions.analysisProvenance.unknown.title',
      body: 'sessions.analysisProvenance.unknown.body',
      action: 'sessions.analysisProvenance.unknown.action',
    });
  });

  // A versão paciente não traz `action`: "refazer a análise" é tarefa do
  // profissional, não de quem está recebendo a apresentação.
  it('usa texto voltado ao paciente, sem instrução operacional, no carimbo do paciente', () => {
    expect(patientProvenanceStampKeys('mock')).toEqual({
      title: 'sessions.analysisProvenance.patient.demoTitle',
      body: 'sessions.analysisProvenance.patient.demoBody',
    });
    expect(patientProvenanceStampKeys('unknown')).toEqual({
      title: 'sessions.analysisProvenance.patient.unknownTitle',
      body: 'sessions.analysisProvenance.patient.unknownBody',
    });
  });

  // Uma chave devolvida aqui mas ausente de um arquivo de tradução faria o
  // i18next renderizar a própria chave ("sessions.analysisProvenance...") no
  // lugar do aviso — no PDF entregue ao paciente. Pior do que não avisar: dá a
  // impressão de defeito e o aviso se perde. Por isso as 5 línguas são
  // checadas, não só o pt (fonte).
  it.each([
    ['pt', pt],
    ['en', en],
    ['es', es],
    ['fr', fr],
    ['it', itLocale],
  ])('tem todas as chaves de carimbo traduzidas em %s', (_lang, bundle) => {
    const keys = [
      ...Object.values(provenanceStampKeys('mock') ?? {}),
      ...Object.values(provenanceStampKeys('unknown') ?? {}),
      ...Object.values(patientProvenanceStampKeys('mock') ?? {}),
      ...Object.values(patientProvenanceStampKeys('unknown') ?? {}),
      'sessions.analysisProvenance.badgeDemo',
      'sessions.analysisProvenance.badgeUnknown',
      'sessions.analysisProvenance.export.demoNotice',
      'sessions.analysisProvenance.export.unknownNotice',
    ];
    for (const key of keys) {
      const value = key
        .split('.')
        .reduce<unknown>((node, part) => (node as Record<string, unknown> | undefined)?.[part], bundle);
      expect(typeof value, `chave ausente: ${key}`).toBe('string');
      expect((value as string).length).toBeGreaterThan(0);
    }
  });
});
