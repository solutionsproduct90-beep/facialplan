import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { retryFetch } from "./retryFetch";

describe("retryFetch", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("resolve na primeira tentativa sem precisar reintentar", async () => {
    const fn = vi.fn().mockResolvedValue("ok");

    const result = await retryFetch(fn, { attempts: 3, baseDelayMs: 10 });

    expect(result).toBe("ok");
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("reintenta após falha(s) transitória(s) e resolve com sucesso", async () => {
    const fn = vi
      .fn()
      .mockRejectedValueOnce(new Error("network error"))
      .mockRejectedValueOnce(new Error("network error"))
      .mockResolvedValue("ok-apos-retry");

    const onRetry = vi.fn();

    const promise = retryFetch(fn, { attempts: 3, baseDelayMs: 10, onRetry });

    // Avança os timers de backoff conforme as rejeições ocorrem.
    await vi.runAllTimersAsync();

    const result = await promise;

    expect(result).toBe("ok-apos-retry");
    expect(fn).toHaveBeenCalledTimes(3);
    expect(onRetry).toHaveBeenCalledTimes(2);
  });

  it("lança o último erro após esgotar todas as tentativas", async () => {
    const error = new Error("falha persistente");
    const fn = vi.fn().mockRejectedValue(error);

    const promise = retryFetch(fn, { attempts: 3, baseDelayMs: 10 });
    // Evita unhandled rejection warning antes do runAllTimersAsync resolver.
    promise.catch(() => {});

    await vi.runAllTimersAsync();

    await expect(promise).rejects.toThrow("falha persistente");
    expect(fn).toHaveBeenCalledTimes(3);
  });

  it("não reintenta quando shouldRetry retorna false", async () => {
    const error = new Error("erro de validação, não deve reintentar");
    const fn = vi.fn().mockRejectedValue(error);
    const shouldRetry = vi.fn().mockReturnValue(false);

    await expect(
      retryFetch(fn, { attempts: 3, baseDelayMs: 10, shouldRetry })
    ).rejects.toThrow("erro de validação, não deve reintentar");

    expect(fn).toHaveBeenCalledTimes(1);
    expect(shouldRetry).toHaveBeenCalledTimes(1);
  });
});
