import { describe, it, expect } from 'vitest';
import { isValidPresentToken, buildPresentLink } from './presentLink';

describe('isValidPresentToken', () => {
  it('accepts a well-formed uuid, as produced by gen_random_uuid()', () => {
    expect(isValidPresentToken('8ce48925-2a03-4b67-b118-e17df300570a')).toBe(true);
    expect(isValidPresentToken('8CE48925-2A03-4B67-B118-E17DF300570A')).toBe(true);
  });

  it('rejects missing, empty and non-uuid values', () => {
    expect(isValidPresentToken(undefined)).toBe(false);
    expect(isValidPresentToken(null)).toBe(false);
    expect(isValidPresentToken('')).toBe(false);
    expect(isValidPresentToken('not-a-token')).toBe(false);
  });

  it('rejects a session id smuggled into the token slot (wrong shape only coincidentally similar)', () => {
    // Right length category but missing dashes / malformed groups should still fail.
    expect(isValidPresentToken('8ce489252a034b67b118e17df300570a')).toBe(false);
  });

  it('rejects values that try to inject extra content around a valid uuid', () => {
    expect(isValidPresentToken('8ce48925-2a03-4b67-b118-e17df300570a; DROP TABLE sessions;')).toBe(false);
    expect(isValidPresentToken(' 8ce48925-2a03-4b67-b118-e17df300570a')).toBe(false);
  });
});

describe('buildPresentLink', () => {
  it('joins origin and token into the public present URL', () => {
    expect(buildPresentLink('https://app.harmonize.com', '8ce48925-2a03-4b67-b118-e17df300570a')).toBe(
      'https://app.harmonize.com/present/8ce48925-2a03-4b67-b118-e17df300570a'
    );
  });

  it('strips a trailing slash from the origin before joining', () => {
    expect(buildPresentLink('https://app.harmonize.com/', 'token-value')).toBe(
      'https://app.harmonize.com/present/token-value'
    );
  });
});
