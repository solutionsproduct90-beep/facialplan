// Proveniência da análise clínica da Etapa 1 (`sessions.stage1_analysis`) —
// risco clínico/legal apontado pelo squad w1-2: a edge function `analyze-face`
// tem um caminho de fallback que devolve MOCK_ANALYSIS (uma análise FABRICADA,
// de demonstração, idêntica para qualquer rosto) quando OPENAI_API_KEY não
// está configurada, e `NovaSessao.handleAnalyze` faz o mesmo quando a própria
// invocação da function falha. Nos dois casos o dado fabricado era GRAVADO no
// banco e o único aviso era um toast transitório — o toast some, o dado fica
// para sempre. Daí em diante nem o PDF clínico (src/lib/clinicalAnalysisPdf.ts
// + SessaoEstagio3.tsx) nem a exportação de prontuário
// (src/lib/patientRecordExport.ts) tinham como distinguir uma leitura real de
// IA de uma demonstração: um laudo assinado, ou um prontuário entregue a um
// paciente/órgão, podia conter análise inventada apresentada como leitura real.
//
// FORMA DE PERSISTÊNCIA ESCOLHIDA — campo `source` DENTRO do próprio JSON
// `stage1_analysis`, não uma coluna nova em `sessions`. As duas opções foram
// pesadas:
//  - Coluna `stage1_analysis_source text`: consultável/indexável direto e
//    auditável no schema, mas cria uma SEGUNDA fonte de verdade sobre o mesmo
//    fato. A análise sempre é escrita como um objeto JSON inteiro (um único
//    `update` em analyze-face/NovaSessao); manter coluna e JSON em sincronia
//    passaria a depender de disciplina manual — exatamente a classe de bug que
//    este repo já paga caro no paywall de 3 camadas.
//  - Campo no JSON: `Stage1Analysis.source?: 'ai' | 'mock'` JÁ EXISTE no
//    contrato (src/types/harmonize.ts) e o fallback do client já gravava
//    `source: 'mock'` — ou seja, o padrão já existia e só não era respeitado
//    pela edge function nem lido por ninguém. A proveniência viaja grudada no
//    dado que ela qualifica: é impossível copiar a análise para outro lugar e
//    perder o carimbo no caminho.
// A única vantagem real da coluna (listar todas as sessões de demonstração)
// foi resolvida sem duplicar estado, com um índice de expressão sobre
// `stage1_analysis->>'source'` — ver
// supabase/migrations/20260917120000_index_stage1_analysis_source.sql.
//
// LINHAS ANTIGAS (sem marcador): toda sessão criada antes desta mudança tem
// `stage1_analysis` sem `source`, e o valor ausente NÃO pode ser lido como
// "real" — aquelas linhas podem perfeitamente ser MOCK_ANALYSIS gravado pelo
// fallback antigo (é justamente o bug que originou este trabalho). Por isso a
// ausência vira um terceiro estado explícito, 'unknown', que também recebe
// carimbo/aviso (mais brando que 'mock', porque pode ser uma análise real) em
// vez de ser silenciosamente promovido a 'ai'.

import type { Stage1Analysis } from '@/types/harmonize';

/**
 * - 'ai': a análise foi de fato produzida pela IA (carimbo `source: 'ai'`
 *   gravado por analyze-face no caminho de sucesso).
 * - 'mock': análise de DEMONSTRAÇÃO, fabricada — nunca olhou a foto deste
 *   paciente.
 * - 'unknown': sessão sem marcador (anterior a esta feature, ou gravada por
 *   algum caminho fora do fluxo atual). Nunca equivale a 'ai'.
 */
export type AnalysisProvenance = 'ai' | 'mock' | 'unknown';

/**
 * Lê a proveniência de uma análise vinda do banco. `stage1_analysis` chega
 * sempre por cast não validado (`as unknown as Stage1Analysis`) a partir de um
 * jsonb, então nada aqui confia no tipo: qualquer valor que não seja
 * exatamente 'ai' ou 'mock' (inclusive `null`, número, objeto) cai em
 * 'unknown' — errar para o lado do aviso, nunca para o lado do silêncio.
 *
 * Uma sessão SEM análise nenhuma também devolve 'unknown', mas nesse caso não
 * há conteúdo clínico para carimbar; quem renderiza decide (as telas só
 * chamam isto quando têm uma análise em mãos).
 */
export function analysisProvenance(analysis: Stage1Analysis | null | undefined): AnalysisProvenance {
  const source = (analysis as { source?: unknown } | null | undefined)?.source;
  if (source === 'ai') return 'ai';
  if (source === 'mock') return 'mock';
  return 'unknown';
}

/** Atalho para o caso mais grave: conteúdo fabricado apresentado como clínico. */
export function isDemoAnalysis(analysis: Stage1Analysis | null | undefined): boolean {
  return analysisProvenance(analysis) === 'mock';
}

/**
 * Se esta análise precisa de carimbo/aviso em qualquer saída visível ao
 * profissional ou ao paciente. Só 'ai' dispensa — ver comentário sobre linhas
 * antigas no topo do arquivo.
 */
export function requiresProvenanceStamp(analysis: Stage1Analysis | null | undefined): boolean {
  return analysisProvenance(analysis) !== 'ai';
}

/** Chaves i18n de um carimbo. `action` (o que fazer a respeito) só existe na
 * versão profissional — mantida como campo OPCIONAL do mesmo tipo, em vez de
 * dois tipos distintos, para que quem renderiza (banner React e PDF) trate os
 * dois públicos com o mesmo código, sem narrowing por `in`. */
export type ProvenanceStampKeys = { title: string; body: string; action?: string };

/** Chaves i18n do carimbo, por proveniência. `null` quando não há o que avisar.
 *
 * Devolver CHAVES (e não texto) mantém esta camada pura e testável sem i18n, e
 * permite que o mesmo par título/corpo seja reaproveitado pela tela (banner
 * React), pelo PDF (jsPDF desenha texto plano) e pela exportação de prontuário
 * — nenhum dos três precisa reimplementar a regra de "o que avisar quando". */
export function provenanceStampKeys(provenance: AnalysisProvenance): ProvenanceStampKeys | null {
  if (provenance === 'ai') return null;
  const branch = provenance === 'mock' ? 'demo' : 'unknown';
  return {
    title: `sessions.analysisProvenance.${branch}.title`,
    body: `sessions.analysisProvenance.${branch}.body`,
    action: `sessions.analysisProvenance.${branch}.action`,
  };
}

/** Mesma regra do carimbo profissional acima, na versão voltada ao PACIENTE
 * (tela de apresentação e link público): linguagem sem jargão, sem instrução
 * operacional de "refazer a análise" — quem refaz é o profissional, não o
 * paciente. */
export function patientProvenanceStampKeys(provenance: AnalysisProvenance): ProvenanceStampKeys | null {
  if (provenance === 'ai') return null;
  const suffix = provenance === 'mock' ? 'demo' : 'unknown';
  return {
    title: `sessions.analysisProvenance.patient.${suffix}Title`,
    body: `sessions.analysisProvenance.patient.${suffix}Body`,
  };
}
