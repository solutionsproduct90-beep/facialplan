// Selo/Relatório de Conformidade Clínica por Sessão.
//
// Este squad NÃO inventa nenhum gate clínico novo nem adiciona bloqueio ao
// fluxo — os gates abaixo já existem, dispersos, cada um construído por um
// squad anterior:
//   - skinScreening: triagem ABCDE de lesão suspeita (P0-1, `skin_screenings`
//     — ver src/lib/skinScreening.ts e src/pages/SessaoTriagemPele.tsx).
//   - anamnesis: anamnese obrigatória antes de prosseguir (gate P0-4 — ver
//     `loadAnamnesis`/`anamnesisGate` em src/pages/SessaoEstagio1.tsx).
//   - consentGeneral: TCLE geral do paciente (`patients.consent_given` /
//     `last_consent_at`, ver PacienteDetalhe.tsx/NovaSessao.tsx).
//   - consentProcedure: TCLE por procedimento com IP real registrado (P0-3,
//     `record-consent`/`recordConsentIp` — ver
//     supabase/functions/_shared/consentUtils.ts e
//     src/test/recordConsentIp.test.ts).
//   - doseThreshold: teto de dose por substância (`DOSE_ALERT_THRESHOLD`/
//     `isDoseOverThreshold` em src/types/harmonize.ts).
//   - vascularRiskZone: guardrail anatômico de zona de risco vascular (P2-7,
//     `HIGH_VASCULAR_RISK_REGIONS`/`isHighVascularRiskRegion` em
//     src/lib/faceRegions.ts).
//   - toxinMinInterval: intervalo mínimo entre aplicações de toxina na mesma
//     região (P3-7, `TOXIN_MIN_REINJECTION_INTERVAL_DAYS`/`daysSince` em
//     src/types/harmonize.ts — mesmo cálculo já feito ao vivo em
//     SessaoEstagio2.tsx via `lastToxinDatesByRegion`).
//
// Todo gate aqui já bloqueia (raro) ou apenas alerta (a maioria — ver os
// comentários "educativo, não bloqueante" em cada arquivo de origem) no
// fluxo principal. Este módulo não repete nem substitui isso: só torna
// visível, de forma auditável (PDF + admin), se a trilha esperada para UMA
// sessão específica está completa. Por isso nunca usamos um status que soe
// punitivo ("reprovado") — apenas `met` (cumprido) ou `attention` (atenção),
// sempre em tom de trilha informativa.

import type { ApplicationPoint, Substance } from '@/types/harmonize';
import {
  DOSE_ALERT_THRESHOLD,
  TOXIN_MIN_REINJECTION_INTERVAL_DAYS,
  daysSince,
  isDoseOverThreshold,
  sumDoseBySubstance,
} from '@/types/harmonize';
import { isVascularRiskApplication } from '@/lib/faceRegions';
import { canProceedDespiteFinding } from '@/lib/skinScreening';

export type ComplianceGateStatus = 'met' | 'attention';

export type ComplianceGateKey =
  | 'skinScreening'
  | 'anamnesis'
  | 'consentGeneral'
  | 'consentProcedure'
  | 'doseThreshold'
  | 'vascularRiskZone'
  | 'toxinMinInterval';

export interface ComplianceGate {
  key: ComplianceGateKey;
  status: ComplianceGateStatus;
  /** Data mais relevante pro status deste gate (quando o evento aconteceu) — null quando não há nada a datar (ex. gate nunca ocorreu). */
  at: string | null;
  /**
   * Chaves cruas (substância/região), não traduzidas, quando o gate precisa
   * apontar QUAL substância/região está em atenção — ex. `['toxina_botulinica']`
   * para doseThreshold, `['glabela']` para vascularRiskZone. Vazio quando o
   * gate não precisa desse detalhe ou está `met`. Tradução para exibição é
   * responsabilidade de quem consome (PDF/admin), igual ao padrão já usado
   * em `patientRecordExport.ts` (dados crus, tradução na borda).
   */
  context: string[];
  /**
   * Fingerprint não-criptográfico do texto de consentimento aceito (só
   * presente no gate `consentProcedure` quando há texto) — prova de
   * integridade "no olho" (o mesmo texto sempre produz o mesmo fingerprint),
   * não um mecanismo de segurança. Ver `fingerprintConsentText` abaixo.
   */
  fingerprint?: string;
}

export interface SessionComplianceSummary {
  sessionId: string;
  generatedAt: string;
  gates: ComplianceGate[];
  /** true quando todo gate presente está `met`. */
  allMet: boolean;
}

export interface SkinScreeningForCompliance {
  hasSuspiciousFinding: boolean;
  referredToDermatology: boolean;
  proceededDespiteFinding: boolean;
  proceedJustification: string | null;
  /** `updated_at` da linha em `skin_screenings` — ver migration 20260910073606. */
  updatedAt: string | null;
}

export interface ProcedureConsentForCompliance {
  createdAt: string | null;
  consentText: string | null;
  ipAddress: string | null;
}

export interface SessionComplianceInput {
  sessionId: string;
  /** `sessions.created_at` — usado como data de referência para gates sem data própria (ex. doseThreshold/vascularRiskZone, que não têm uma linha/timestamp dedicado). */
  sessionCreatedAt: string | null | undefined;
  /** `sessions.stage2_overlay` já desserializado. */
  applicationPoints: ApplicationPoint[] | null | undefined;

  /** Linha de `skin_screenings` para esta sessão — null/undefined quando a triagem ainda não foi feita (gate P0-1). */
  skinScreening: SkinScreeningForCompliance | null | undefined;

  /** `anamnesis.created_at` do PACIENTE desta sessão — anamnese é por paciente, não por sessão (ver anamnesisGate em SessaoEstagio1.tsx), então uma anamnese de sessão anterior do mesmo paciente já cumpre este gate. */
  anamnesisCreatedAt: string | null | undefined;

  /** `patients.consent_given`/`last_consent_at` — TCLE geral, capturado uma vez por paciente (não por sessão). */
  patientConsentGiven: boolean | null | undefined;
  patientLastConsentAt: string | null | undefined;

  /** Linha de `consents` (consent_type='procedimento') desta sessão específica — null/undefined quando o TCLE de procedimento ainda não foi assinado para esta sessão. */
  procedureConsent: ProcedureConsentForCompliance | null | undefined;

  /**
   * Data da última aplicação de toxina PRÉVIA (sessão concluída anterior
   * deste mesmo paciente), por região — mesmo formato que
   * `lastToxinDatesByRegion` já calculado ao vivo em SessaoEstagio2.tsx.
   * Opcional: quando omitido, o gate `toxinMinInterval` simplesmente não
   * aparece no resumo (não há como avaliar violação sem histórico, e não
   * fabricamos um status "cumprido" por falta de dado — melhor omitir do
   * que sugerir uma verificação que não foi feita). Presente e vazio (`{}`)
   * é diferente: significa "verificado, sem aplicação prévia" -> `met`.
   */
  priorToxinDatesByRegion?: Record<string, string> | null;
}

/**
 * Fingerprint não-criptográfico (FNV-1a de 32 bits, duas passadas com seeds
 * diferentes concatenadas em hex) do texto de consentimento aceito — só
 * para exibir uma "impressão digital" curta e estável do texto no selo de
 * conformidade (prova de integridade visual: o mesmo texto sempre gera o
 * mesmo fingerprint, qualquer edição gera um diferente), NUNCA como
 * mecanismo de segurança/verificação criptográfica. Evita expor ou repetir
 * o texto completo do TCLE (que pode ser longo) no resumo/PDF.
 *
 * Escolhido em vez de `crypto.subtle.digest` (SHA-256) por ser síncrono —
 * a função pura de resumo (`computeSessionComplianceSummary`) precisa
 * continuar síncrona e testável sem `await`/ambiente com WebCrypto (jsdom
 * tem `crypto.subtle`, mas manter isso fora de uma função pura evita
 * qualquer acoplamento com um runtime específico).
 */
export function fingerprintConsentText(text: string): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x9e3779b9;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    h1 = (h1 ^ c) >>> 0;
    h1 = Math.imul(h1, 0x01000193) >>> 0;
    h2 = (h2 ^ c) >>> 0;
    h2 = Math.imul(h2, 0x85ebca6b) >>> 0;
  }
  return h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0');
}

function skinScreeningGate(screening: SkinScreeningForCompliance | null | undefined): ComplianceGate {
  if (!screening) {
    return { key: 'skinScreening', status: 'attention', at: null, context: [] };
  }
  // A linha só existe depois que as 5 respostas ABCDE foram salvas (ver
  // SessaoTriagemPele.tsx), então "existe" já implica "completa". O que
  // ainda pode faltar é a DECISÃO do profissional quando há achado suspeito
  // (encaminhar, ou prosseguir com reconhecimento + justificativa — mesma
  // regra de `canProceedDespiteFinding`).
  const decided =
    !screening.hasSuspiciousFinding ||
    screening.referredToDermatology ||
    canProceedDespiteFinding(screening.proceedJustification ?? '', screening.proceededDespiteFinding);
  return {
    key: 'skinScreening',
    status: decided ? 'met' : 'attention',
    at: screening.updatedAt ?? null,
    context: [],
  };
}

function anamnesisGate(anamnesisCreatedAt: string | null | undefined): ComplianceGate {
  return anamnesisCreatedAt
    ? { key: 'anamnesis', status: 'met', at: anamnesisCreatedAt, context: [] }
    : { key: 'anamnesis', status: 'attention', at: null, context: [] };
}

function consentGeneralGate(
  given: boolean | null | undefined,
  at: string | null | undefined,
): ComplianceGate {
  return given
    ? { key: 'consentGeneral', status: 'met', at: at ?? null, context: [] }
    : { key: 'consentGeneral', status: 'attention', at: null, context: [] };
}

function consentProcedureGate(consent: ProcedureConsentForCompliance | null | undefined): ComplianceGate {
  if (!consent) {
    return { key: 'consentProcedure', status: 'attention', at: null, context: [] };
  }
  // O IP real (recordConsentIp/P0-3) é o que diferencia este TCLE de um
  // registro "de confiança" (o profissional digitou o nome) de um com prova
  // adicional de origem da requisição — ausência de IP (linha antiga, ou
  // falha ao extrair de todos os cabeçalhos candidatos, ver
  // `extractClientIp`) ainda conta como consentimento registrado, mas fica
  // em atenção em vez de cumprido.
  const hasRealIp = Boolean(consent.ipAddress && consent.ipAddress.trim().length > 0);
  return {
    key: 'consentProcedure',
    status: hasRealIp ? 'met' : 'attention',
    at: consent.createdAt ?? null,
    context: [],
    fingerprint: consent.consentText ? fingerprintConsentText(consent.consentText) : undefined,
  };
}

function doseThresholdGate(
  points: ApplicationPoint[],
  sessionCreatedAt: string | null | undefined,
): ComplianceGate {
  const totals = sumDoseBySubstance(points);
  const overSubstances = (Object.keys(totals) as Substance[]).filter((s) =>
    isDoseOverThreshold(s, totals[s] ?? 0),
  );
  return {
    key: 'doseThreshold',
    status: overSubstances.length === 0 ? 'met' : 'attention',
    at: sessionCreatedAt ?? null,
    context: overSubstances,
  };
}

function vascularRiskZoneGate(
  points: ApplicationPoint[],
  sessionCreatedAt: string | null | undefined,
): ComplianceGate {
  const riskRegions = Array.from(
    new Set(points.filter((p) => isVascularRiskApplication(p.region, p.substance)).map((p) => p.region)),
  );
  return {
    key: 'vascularRiskZone',
    status: riskRegions.length === 0 ? 'met' : 'attention',
    at: sessionCreatedAt ?? null,
    context: riskRegions,
  };
}

function toxinMinIntervalGate(
  points: ApplicationPoint[],
  priorToxinDatesByRegion: Record<string, string> | null | undefined,
  sessionCreatedAt: string | null | undefined,
): ComplianceGate | null {
  if (!priorToxinDatesByRegion) return null;
  const toxinRegions = Array.from(
    new Set(points.filter((p) => p.substance === 'toxina_botulinica').map((p) => p.region)),
  );
  if (toxinRegions.length === 0) return null;

  const violatingRegions = toxinRegions.filter((region) => {
    const lastDate = priorToxinDatesByRegion[region];
    if (!lastDate) return false;
    return daysSince(lastDate) < TOXIN_MIN_REINJECTION_INTERVAL_DAYS;
  });

  return {
    key: 'toxinMinInterval',
    status: violatingRegions.length === 0 ? 'met' : 'attention',
    at: sessionCreatedAt ?? null,
    context: violatingRegions,
  };
}

/**
 * Monta o resumo de conformidade clínica de UMA sessão — função pura,
 * testável sem Supabase/DOM (mesmo espírito de `buildPatientRecordExport`
 * em patientRecordExport.ts e de `hasClinicalAnalysisContent` em
 * clinicalAnalysisPdf.ts). Nunca lança: cada dado relacionado ausente
 * (null/undefined) vira `attention` no gate correspondente em vez de
 * quebrar o resumo inteiro — um prontuário incompleto é exatamente o que
 * este selo existe para tornar visível.
 */
export function computeSessionComplianceSummary(input: SessionComplianceInput): SessionComplianceSummary {
  const points = input.applicationPoints ?? [];

  const gates: ComplianceGate[] = [
    skinScreeningGate(input.skinScreening),
    anamnesisGate(input.anamnesisCreatedAt),
    consentGeneralGate(input.patientConsentGiven, input.patientLastConsentAt),
    consentProcedureGate(input.procedureConsent),
    doseThresholdGate(points, input.sessionCreatedAt),
    vascularRiskZoneGate(points, input.sessionCreatedAt),
  ];

  const toxinGate = toxinMinIntervalGate(points, input.priorToxinDatesByRegion, input.sessionCreatedAt);
  if (toxinGate) gates.push(toxinGate);

  return {
    sessionId: input.sessionId,
    generatedAt: new Date().toISOString(),
    gates,
    allMet: gates.every((g) => g.status === 'met'),
  };
}

/** Ordem fixa de exibição dos gates, reaproveitada por PDF e admin — mantém as duas telas consistentes entre si sem duplicar a lista. */
export const COMPLIANCE_GATE_ORDER: ComplianceGateKey[] = [
  'skinScreening',
  'anamnesis',
  'consentGeneral',
  'consentProcedure',
  'doseThreshold',
  'vascularRiskZone',
  'toxinMinInterval',
];
