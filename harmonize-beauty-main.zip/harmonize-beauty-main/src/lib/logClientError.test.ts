import { describe, it, expect, vi, beforeEach } from 'vitest';
import { logClientError } from './logClientError';

// O mock imita o contrato que de fato importa aqui: `insert()` devolve um
// THENABLE preguiçoso, igual ao PostgrestBuilder real — nada acontece até
// alguém chamar `then()`. Um mock que devolvesse uma Promise pronta
// esconderia exatamente o bug que estes casos existem para travar.
let thenChamado: number;
let insertRecebido: Record<string, unknown> | null;
let tabelaRecebida: string | null;
let rejeitar: boolean;

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (tabela: string) => {
      tabelaRecebida = tabela;
      return {
        insert: (payload: Record<string, unknown>) => {
          insertRecebido = payload;
          return {
            then: (aoResolver: () => void, aoRejeitar?: (e: unknown) => void) => {
              thenChamado += 1;
              if (rejeitar) aoRejeitar?.(new Error('RLS negou'));
              else aoResolver();
            },
          };
        },
      };
    },
  },
}));

describe('logClientError', () => {
  beforeEach(() => {
    thenChamado = 0;
    insertRecebido = null;
    tabelaRecebida = null;
    rejeitar = false;
  });

  it('consome o thenable, que é o que de fato dispara a requisição', () => {
    // Este é o caso central. Descartando o builder com o operador `void`,
    // `then` nunca é chamado e a gravação some em silêncio — é exatamente o
    // que src/test/fireAndForgetSupabase.test.ts proíbe no repositório
    // inteiro. (Escrever aquele padrão por extenso aqui faria aquela trava
    // acusar este arquivo, o que é bom sinal: ela lê arquivo de verdade.)
    logClientError({
      professionalId: 'pro-1',
      stage: 'export_pdf',
      errorType: 'pdf_export_failed',
      message: 'estourou',
    });

    expect(thenChamado).toBe(1);
  });

  it('grava em error_logs com os nomes de coluna da tabela', () => {
    logClientError({
      professionalId: 'pro-1',
      sessionId: 'sessao-9',
      stage: 'present',
      errorType: 'video_export_failed',
      message: 'codec ausente',
    });

    expect(tabelaRecebida).toBe('error_logs');
    expect(insertRecebido).toEqual({
      professional_id: 'pro-1',
      session_id: 'sessao-9',
      stage: 'present',
      error_type: 'video_export_failed',
      message: 'codec ausente',
    });
  });

  it('usa null quando não há sessão, em vez de omitir a coluna', () => {
    logClientError({
      professionalId: 'pro-1',
      stage: 'anamnesis',
      errorType: 'anamnesis_read_failed',
      message: 'sem rede',
    });

    expect(insertRecebido).toMatchObject({ session_id: null });
  });

  it('trunca a mensagem em 500 caracteres, para o chamador não precisar lembrar', () => {
    logClientError({
      professionalId: 'pro-1',
      stage: 'present',
      errorType: 'x',
      message: 'a'.repeat(900),
    });

    expect((insertRecebido?.message as string).length).toBe(500);
  });

  it('engole a falha de gravação, em vez de virar unhandled rejection', () => {
    rejeitar = true;

    // Falhar ao registrar uma falha não pode derrubar o fluxo que estava
    // tratando o erro original.
    expect(() =>
      logClientError({
        professionalId: 'pro-1',
        stage: 'present',
        errorType: 'x',
        message: 'y',
      }),
    ).not.toThrow();
    expect(thenChamado).toBe(1);
  });
});
