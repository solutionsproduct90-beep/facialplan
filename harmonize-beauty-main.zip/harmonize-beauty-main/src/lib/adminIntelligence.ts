import type { Substance } from '@/types/harmonize';

// Funções puras usadas por /admin/inteligencia (Central de Inteligência,
// backlog P5) — igual a adminMetrics.ts, testáveis sem montar a tela nem
// tocar Supabase. Diferença central: as três RPCs SECURITY DEFINER que
// alimentam este arquivo (ver
// supabase/migrations/20260911070000_add_admin_intelligence_rpcs.sql) já
// nunca selecionam coluna de paciente/profissional/sessão, então as linhas
// cruas que chegam aqui SÃO o dado agregável — nenhuma função abaixo recebe
// nem devolve um identificador de pessoa. `MIN_SAMPLE_SIZE` é o segundo
// cinto de segurança (o primeiro é a RPC nunca selecionar identidade): um
// grupo com poucas amostras é omitido para não virar, na prática, a
// estatística de um paciente/profissional só.
export const MIN_SAMPLE_SIZE = 5;

export type DoseBucket = 'baixa' | 'media' | 'alta';

/**
 * Linha devolvida por `admin_dose_accuracy_correlation` — já um GRUPO
 * agregado por substância+região+faixa-de-dose (a RPC agrega e aplica
 * `HAVING count(*) >= 5` inteiramente em SQL, ver
 * supabase/migrations/20260911090000_add_dose_accuracy_sql_aggregation.sql;
 * achado do QA Contínuo ciclo 7 — antes disso a RPC devolvia UMA LINHA CRUA
 * POR PONTO DE APLICAÇÃO e todo o agrupamento/corte de amostra mínima vivia
 * só em TypeScript, então chamar a RPC direto contornava a privacidade por
 * completo). Não existe mais um shape "linha crua por ponto" pra esta RPC.
 */
export type DoseAccuracyGroupRow = {
  substance: string;
  region: string;
  dose_bucket: string;
  n: number;
  average_rating: number;
};

export type DoseAccuracyGroup = {
  substance: Substance;
  region: string;
  doseBucket: DoseBucket;
  n: number;
  averageRating: number;
};

const KNOWN_SUBSTANCES: readonly string[] = ['acido_hialuronico', 'toxina_botulinica', 'bioestimulador'];
function isKnownSubstance(value: string): value is Substance {
  return KNOWN_SUBSTANCES.includes(value);
}

const KNOWN_DOSE_BUCKETS: readonly string[] = ['baixa', 'media', 'alta'];
function isKnownDoseBucket(value: string): value is DoseBucket {
  return KNOWN_DOSE_BUCKETS.includes(value);
}

/**
 * Renomeia os grupos (já agregados em SQL) pra camelCase e reaplica o corte
 * de amostra mínima do lado do cliente — segundo cinto de segurança
 * redundante com o `HAVING` da RPC, mesmo padrão de defesa em profundidade
 * já usado em `filterAdverseEventPatterns`/`filterAnamnesisFlagFrequency`.
 */
export function mapDoseAccuracyGroups(
  rows: DoseAccuracyGroupRow[],
  minSampleSize = MIN_SAMPLE_SIZE,
): DoseAccuracyGroup[] {
  return rows
    .filter((row) => isKnownSubstance(row.substance) && isKnownDoseBucket(row.dose_bucket) && row.region && row.n >= minSampleSize)
    .map((row) => ({
      substance: row.substance as Substance,
      region: row.region,
      doseBucket: row.dose_bucket as DoseBucket,
      n: row.n,
      averageRating: row.average_rating,
    }))
    .sort((a, b) => b.n - a.n);
}

/** Linha crua devolvida por `admin_adverse_event_patterns` — já agregada em SQL (COUNT por substância/marca/tipo), nenhuma linha por evento individual. */
export type AdverseEventPatternRow = {
  substance: string;
  brand_name: string;
  event_type: string;
  n: number;
};

export type AdverseEventPattern = {
  substance: string;
  brandName: string;
  eventType: string;
  n: number;
};

/**
 * Aplica o mesmo corte de amostra mínima às linhas (já agregadas em SQL) de
 * padrões de evento adverso — um par substância/marca/tipo visto só uma ou
 * duas vezes na base inteira some da tela, em vez de virar um alerta que, na
 * prática, aponta para um paciente/profissional identificável.
 */
export function filterAdverseEventPatterns(
  rows: AdverseEventPatternRow[],
  minSampleSize = MIN_SAMPLE_SIZE,
): AdverseEventPattern[] {
  return rows
    .filter((row) => row.n >= minSampleSize)
    .map((row) => ({ substance: row.substance, brandName: row.brand_name, eventType: row.event_type, n: row.n }))
    .sort((a, b) => b.n - a.n);
}

/** Linha crua devolvida por `admin_anamnesis_flag_frequency` — já agregada em SQL (COUNT por flag), nenhuma linha por paciente. */
export type AnamnesisFlagFrequencyRow = {
  flag_key: string;
  n: number;
};

export type AnamnesisFlagFrequency = {
  flagKey: string;
  n: number;
};

/** Mesmo corte de amostra mínima, para a distribuição de frequência de flags de anamnese. */
export function filterAnamnesisFlagFrequency(
  rows: AnamnesisFlagFrequencyRow[],
  minSampleSize = MIN_SAMPLE_SIZE,
): AnamnesisFlagFrequency[] {
  return rows
    .filter((row) => row.n >= minSampleSize)
    .map((row) => ({ flagKey: row.flag_key, n: row.n }))
    .sort((a, b) => b.n - a.n);
}
