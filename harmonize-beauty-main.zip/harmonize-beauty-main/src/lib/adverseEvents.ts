// Funções puras usadas pela seção "Eventos adversos" da ficha do paciente
// (farmacovigilância por lote/marca de insumo — ver comentário na migration
// 20260910200000_add_adverse_events.sql). Separadas do componente pelo
// mesmo motivo de src/lib/agenda.ts e src/lib/stock.ts: testáveis sem
// montar a tela nem tocar Supabase.

export type AdverseEventType = 'nodulo' | 'reacao_alergica' | 'oclusao_vascular' | 'outro';
export type AdverseEventSeverity = 'leve' | 'moderada' | 'grave';

export const ADVERSE_EVENT_TYPES: AdverseEventType[] = ['nodulo', 'reacao_alergica', 'oclusao_vascular', 'outro'];
export const ADVERSE_EVENT_SEVERITIES: AdverseEventSeverity[] = ['leve', 'moderada', 'grave'];

/** Ordem de gravidade crescente — usada pra destacar "grave" com mais ênfase visual, nunca pra ordenar a lista (que é sempre por `occurred_at`). */
const SEVERITY_RANK: Record<AdverseEventSeverity, number> = { leve: 0, moderada: 1, grave: 2 };

export function severityRank(severity: AdverseEventSeverity): number {
  return SEVERITY_RANK[severity];
}

/** Evento adverso já normalizado, pronto pra seção renderizar. */
export type AdverseEventForList = {
  id: string;
  patientId: string | null;
  sessionId: string | null;
  insumoId: string | null;
  insumoBrandName: string | null;
  eventType: AdverseEventType;
  severity: AdverseEventSeverity;
  description: string;
  occurredAt: string; // ISO
  createdAt: string; // ISO
};

/**
 * Normaliza linhas de `adverse_events` vindas do Supabase — incluindo o
 * join opcional `insumo:insumos(brand_name)`, que o PostgREST pode devolver
 * como objeto OU como array de 1 item dependendo da versão (mesma cautela
 * já aplicada em src/lib/agenda.ts pro join de paciente). Linha malformada
 * (sem id, tipo/gravidade fora do enum, descrição vazia ou data inválida) é
 * descartada, não quebra a lista inteira — um registro de farmacovigilância
 * malformado não deve derrubar a tela nem esconder os demais.
 */
export function normalizeAdverseEvents(raw: unknown): AdverseEventForList[] {
  if (!Array.isArray(raw)) return [];
  const out: AdverseEventForList[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.event_type !== 'string' || !ADVERSE_EVENT_TYPES.includes(r.event_type as AdverseEventType)) continue;
    if (typeof r.severity !== 'string' || !ADVERSE_EVENT_SEVERITIES.includes(r.severity as AdverseEventSeverity)) continue;
    if (typeof r.description !== 'string' || !r.description.trim()) continue;
    if (typeof r.occurred_at !== 'string' || Number.isNaN(new Date(r.occurred_at).getTime())) continue;

    const insumoRaw = r.insumo;
    const insumo = Array.isArray(insumoRaw) ? insumoRaw[0] : insumoRaw;
    const insumoBrandName =
      insumo && typeof insumo === 'object' && typeof (insumo as Record<string, unknown>).brand_name === 'string'
        ? ((insumo as Record<string, unknown>).brand_name as string)
        : null;

    out.push({
      id: r.id,
      patientId: typeof r.patient_id === 'string' ? r.patient_id : null,
      sessionId: typeof r.session_id === 'string' ? r.session_id : null,
      insumoId: typeof r.insumo_id === 'string' ? r.insumo_id : null,
      insumoBrandName,
      eventType: r.event_type as AdverseEventType,
      severity: r.severity as AdverseEventSeverity,
      description: r.description,
      occurredAt: r.occurred_at,
      createdAt: typeof r.created_at === 'string' ? r.created_at : r.occurred_at,
    });
  }
  return out;
}

/** Rascunho do formulário de registro — sempre strings (vem direto de inputs controlados). */
export type AdverseEventDraft = {
  eventType: string;
  severity: string;
  description: string;
  occurredAtDate: string; // yyyy-MM-dd
  occurredAtTime: string; // HH:mm
};

export type AdverseEventValidationError =
  | 'invalidEventType'
  | 'invalidSeverity'
  | 'invalidDescription'
  | 'invalidDate';

/**
 * Valida o rascunho antes de gravar — mesmo papel de `handleSave` em
 * AgendaTab.tsx, só que extraído como função pura pra ser testável sem
 * montar a tela nem tocar Supabase. Retorna o primeiro erro encontrado, ou
 * `null` quando o rascunho está pronto pra virar payload de insert.
 */
export function validateAdverseEventDraft(draft: AdverseEventDraft): AdverseEventValidationError | null {
  if (!ADVERSE_EVENT_TYPES.includes(draft.eventType as AdverseEventType)) return 'invalidEventType';
  if (!ADVERSE_EVENT_SEVERITIES.includes(draft.severity as AdverseEventSeverity)) return 'invalidSeverity';
  if (!draft.description.trim()) return 'invalidDescription';
  if (!draft.occurredAtDate || !draft.occurredAtTime) return 'invalidDate';
  const occurredAt = new Date(`${draft.occurredAtDate}T${draft.occurredAtTime}`);
  if (Number.isNaN(occurredAt.getTime())) return 'invalidDate';
  return null;
}

/**
 * Monta o payload de insert a partir de um rascunho já validado
 * (`validateAdverseEventDraft(draft) === null`) — combina data+hora num
 * único `occurred_at` ISO, mesma técnica de `scheduledAt` em AgendaTab.tsx.
 * `patientId`/`sessionId`/`insumoId` continuam opcionais (vira `null`
 * quando não selecionado), pois nem todo evento tem sessão ou insumo
 * identificável.
 */
export function buildAdverseEventPayload(
  draft: AdverseEventDraft,
  context: { professionalId: string; patientId: string | null; sessionId: string | null; insumoId: string | null },
) {
  const occurredAt = new Date(`${draft.occurredAtDate}T${draft.occurredAtTime}`);
  return {
    professional_id: context.professionalId,
    patient_id: context.patientId,
    session_id: context.sessionId,
    insumo_id: context.insumoId,
    event_type: draft.eventType,
    severity: draft.severity,
    description: draft.description.trim(),
    occurred_at: occurredAt.toISOString(),
  };
}
