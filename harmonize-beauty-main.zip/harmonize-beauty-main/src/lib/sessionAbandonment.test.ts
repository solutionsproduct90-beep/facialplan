import { describe, it, expect } from 'vitest';
import { isSessionAbandoned, shouldSendReengagementReminder, ABANDONED_THRESHOLD_DAYS } from './sessionAbandonment';

const NOW = new Date('2026-09-10T12:00:00Z');
const daysAgo = (n: number) => new Date(NOW.getTime() - n * 24 * 60 * 60 * 1000).toISOString();

describe('isSessionAbandoned', () => {
  it('is false for a session still well within the threshold', () => {
    expect(isSessionAbandoned({ status: 'stage2', createdAt: daysAgo(1) }, NOW)).toBe(false);
  });

  it('is false for a session created exactly at the threshold minus a bit', () => {
    expect(isSessionAbandoned({ status: 'stage1', createdAt: daysAgo(ABANDONED_THRESHOLD_DAYS - 0.1) }, NOW)).toBe(false);
  });

  it('is true once the session has aged past the threshold, for any open status', () => {
    expect(isSessionAbandoned({ status: 'stage1', createdAt: daysAgo(ABANDONED_THRESHOLD_DAYS) }, NOW)).toBe(true);
    expect(isSessionAbandoned({ status: 'stage2', createdAt: daysAgo(ABANDONED_THRESHOLD_DAYS + 10) }, NOW)).toBe(true);
    expect(isSessionAbandoned({ status: 'stage3', createdAt: daysAgo(ABANDONED_THRESHOLD_DAYS + 1) }, NOW)).toBe(true);
  });

  it('is false for a completed session no matter how old', () => {
    expect(isSessionAbandoned({ status: 'complete', createdAt: daysAgo(365) }, NOW)).toBe(false);
  });

  it('is false for a session already marked abandoned (no double-processing a manually-closed one)', () => {
    expect(isSessionAbandoned({ status: 'abandoned', createdAt: daysAgo(365) }, NOW)).toBe(false);
  });

  it('is false for a null/empty status (defensively — every real session row has one)', () => {
    expect(isSessionAbandoned({ status: null, createdAt: daysAgo(365) }, NOW)).toBe(false);
  });

  it('is false for an unparseable createdAt instead of throwing', () => {
    expect(isSessionAbandoned({ status: 'stage1', createdAt: 'not-a-date' }, NOW)).toBe(false);
  });

  it('honors a custom threshold', () => {
    expect(isSessionAbandoned({ status: 'stage1', createdAt: daysAgo(2) }, NOW, 1)).toBe(true);
    expect(isSessionAbandoned({ status: 'stage1', createdAt: daysAgo(2) }, NOW, 3)).toBe(false);
  });
});

describe('shouldSendReengagementReminder', () => {
  it('is true for an abandoned session that has never been reminded', () => {
    expect(
      shouldSendReengagementReminder({ status: 'stage2', createdAt: daysAgo(10), reminderSentAt: null }, NOW),
    ).toBe(true);
  });

  it('is false once a reminder was already sent, even if still abandoned', () => {
    expect(
      shouldSendReengagementReminder(
        { status: 'stage2', createdAt: daysAgo(10), reminderSentAt: daysAgo(1) },
        NOW,
      ),
    ).toBe(false);
  });

  it('is false for a session that is not yet abandoned', () => {
    expect(
      shouldSendReengagementReminder({ status: 'stage1', createdAt: daysAgo(1), reminderSentAt: null }, NOW),
    ).toBe(false);
  });

  it('is false for a completed session, reminded or not', () => {
    expect(
      shouldSendReengagementReminder({ status: 'complete', createdAt: daysAgo(30), reminderSentAt: null }, NOW),
    ).toBe(false);
  });
});
