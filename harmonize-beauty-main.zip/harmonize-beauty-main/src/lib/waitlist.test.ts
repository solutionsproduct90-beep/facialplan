import { describe, it, expect } from 'vitest';
import { normalizeWaitlistEntries, findWaitlistCandidatesForSlot, slotDateKey, type WaitlistEntry } from './waitlist';

describe('normalizeWaitlistEntries', () => {
  it('normalizes a row with the patient join returned as an object', () => {
    const result = normalizeWaitlistEntries([
      {
        id: 'w1',
        patient_id: 'p1',
        desired_start_date: '2026-09-14',
        desired_end_date: '2026-09-20',
        status: 'waiting',
        created_at: '2026-09-10T10:00:00.000Z',
        patient: { name: 'Maria Silva', phone: '5511999998888' },
      },
    ]);
    expect(result).toEqual([
      {
        id: 'w1',
        patientId: 'p1',
        patientName: 'Maria Silva',
        patientPhone: '5511999998888',
        desiredStartDate: '2026-09-14',
        desiredEndDate: '2026-09-20',
        status: 'waiting',
        createdAt: '2026-09-10T10:00:00.000Z',
      },
    ]);
  });

  it('normalizes the patient join returned as a 1-item array (PostgREST version quirk)', () => {
    const result = normalizeWaitlistEntries([
      {
        id: 'w1',
        patient_id: 'p1',
        desired_start_date: '2026-09-14',
        desired_end_date: '2026-09-20',
        status: 'waiting',
        created_at: '2026-09-10T10:00:00.000Z',
        patient: [{ name: 'Maria Silva', phone: '5511999998888' }],
      },
    ]);
    expect(result[0].patientName).toBe('Maria Silva');
    expect(result[0].patientPhone).toBe('5511999998888');
  });

  it('defaults status to "waiting" when missing/unknown', () => {
    const result = normalizeWaitlistEntries([
      {
        id: 'w1',
        patient_id: 'p1',
        desired_start_date: '2026-09-14',
        desired_end_date: '2026-09-20',
        status: 'bogus',
        patient: null,
      },
    ]);
    expect(result[0].status).toBe('waiting');
    expect(result[0].patientName).toBeNull();
    expect(result[0].patientPhone).toBeNull();
  });

  it('discards a row missing id, patient_id, or with malformed dates, without throwing', () => {
    const result = normalizeWaitlistEntries([
      { id: '', patient_id: 'p1', desired_start_date: '2026-09-14', desired_end_date: '2026-09-20' },
      { id: 'w2', patient_id: '', desired_start_date: '2026-09-14', desired_end_date: '2026-09-20' },
      { id: 'w3', patient_id: 'p1', desired_start_date: 123, desired_end_date: '2026-09-20' },
      null,
      'not-an-object',
    ]);
    expect(result).toEqual([]);
  });

  it('returns an empty array for non-array input', () => {
    expect(normalizeWaitlistEntries(null)).toEqual([]);
    expect(normalizeWaitlistEntries(undefined)).toEqual([]);
    expect(normalizeWaitlistEntries({})).toEqual([]);
  });
});

describe('slotDateKey', () => {
  it('extracts a local YYYY-MM-DD date key from a Date', () => {
    expect(slotDateKey(new Date(2026, 8, 20, 23, 59))).toBe('2026-09-20');
  });

  it('extracts a local YYYY-MM-DD date key from an ISO string', () => {
    expect(slotDateKey(new Date(2026, 8, 5, 9, 0).toISOString())).toBe('2026-09-05');
  });
});

describe('findWaitlistCandidatesForSlot', () => {
  function entry(overrides: Partial<WaitlistEntry>): WaitlistEntry {
    return {
      id: 'w',
      patientId: 'p',
      patientName: 'Paciente',
      patientPhone: '5511999990000',
      desiredStartDate: '2026-09-01',
      desiredEndDate: '2026-09-30',
      status: 'waiting',
      createdAt: '2026-09-01T00:00:00.000Z',
      ...overrides,
    };
  }

  it('returns entries whose desired period covers the freed slot date', () => {
    const entries = [entry({ id: 'w1', desiredStartDate: '2026-09-14', desiredEndDate: '2026-09-20' })];
    const result = findWaitlistCandidatesForSlot(entries, new Date(2026, 8, 18, 14, 30));
    expect(result.map((e) => e.id)).toEqual(['w1']);
  });

  it('excludes entries whose desired period does not cover the freed slot date', () => {
    const entries = [entry({ id: 'w1', desiredStartDate: '2026-09-21', desiredEndDate: '2026-09-30' })];
    const result = findWaitlistCandidatesForSlot(entries, new Date(2026, 8, 18));
    expect(result).toEqual([]);
  });

  it('includes a slot date exactly on the start or end boundary (inclusive range)', () => {
    const entries = [entry({ id: 'w1', desiredStartDate: '2026-09-14', desiredEndDate: '2026-09-20' })];
    expect(findWaitlistCandidatesForSlot(entries, new Date(2026, 8, 14)).map((e) => e.id)).toEqual(['w1']);
    expect(findWaitlistCandidatesForSlot(entries, new Date(2026, 8, 20)).map((e) => e.id)).toEqual(['w1']);
  });

  it('excludes entries not in "waiting" status even when the period matches', () => {
    const entries = [
      entry({ id: 'w1', status: 'offered' }),
      entry({ id: 'w2', status: 'fulfilled' }),
      entry({ id: 'w3', status: 'expired' }),
      entry({ id: 'w4', status: 'waiting' }),
    ];
    const result = findWaitlistCandidatesForSlot(entries, new Date(2026, 8, 15));
    expect(result.map((e) => e.id)).toEqual(['w4']);
  });

  it('orders matching candidates by queue arrival order (createdAt ascending) — first in, first suggested', () => {
    const entries = [
      entry({ id: 'later', createdAt: '2026-09-05T00:00:00.000Z' }),
      entry({ id: 'earliest', createdAt: '2026-09-01T00:00:00.000Z' }),
      entry({ id: 'middle', createdAt: '2026-09-03T00:00:00.000Z' }),
    ];
    const result = findWaitlistCandidatesForSlot(entries, new Date(2026, 8, 15));
    expect(result.map((e) => e.id)).toEqual(['earliest', 'middle', 'later']);
  });

  it('returns an empty array when there are no entries at all', () => {
    expect(findWaitlistCandidatesForSlot([], new Date(2026, 8, 15))).toEqual([]);
  });
});
