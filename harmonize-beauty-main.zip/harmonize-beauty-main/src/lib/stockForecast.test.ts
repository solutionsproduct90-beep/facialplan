import { describe, it, expect } from 'vitest';
import {
  FORECAST_WINDOW_DAYS,
  MIN_DOSE_HISTORY_SAMPLE_SIZE,
  doseHistoryLookbackStart,
  buildForecastSteps,
  isStepInForecastWindow,
  stepsInForecastWindow,
  extractHistoricalDoseSamples,
  buildInsumoSubstanceMap,
  nonExpiredStockBySubstance,
  buildStockForecast,
  type ForecastStepInput,
} from './stockForecast';

const NOW = new Date(2026, 8, 13); // 13/09/2026 (data "hoje" fixa para os testes)

describe('buildForecastSteps', () => {
  it('calcula a data prevista de cada etapa a partir de start_date do plano + offset_days', () => {
    const plans = [{ id: 'plan-1', startDate: '2026-09-10' }];
    const steps = [
      { planId: 'plan-1', substance: 'toxina_botulinica' as const, offsetDays: 3, status: 'pendente' as const },
    ];
    const result = buildForecastSteps(plans, steps);
    expect(result).toHaveLength(1);
    expect(result[0].substance).toBe('toxina_botulinica');
    expect(result[0].status).toBe('pendente');
    expect(result[0].expectedDate.toISOString().slice(0, 10)).toBe('2026-09-13');
  });

  it('descarta etapa cujo plano não veio na mesma busca, sem quebrar as demais', () => {
    const plans = [{ id: 'plan-1', startDate: '2026-09-10' }];
    const steps = [
      { planId: 'plan-1', substance: 'toxina_botulinica' as const, offsetDays: 0, status: 'pendente' as const },
      { planId: 'plan-orfa', substance: 'acido_hialuronico' as const, offsetDays: 0, status: 'pendente' as const },
    ];
    expect(buildForecastSteps(plans, steps)).toHaveLength(1);
  });
});

describe('isStepInForecastWindow', () => {
  it('inclui hoje (dia 0)', () => {
    expect(isStepInForecastWindow(new Date(2026, 8, 13), NOW)).toBe(true);
  });

  it('inclui o último dia da janela de 7 dias (hoje + 6)', () => {
    expect(isStepInForecastWindow(new Date(2026, 8, 19), NOW)).toBe(true);
  });

  it('exclui o dia logo após a janela (hoje + 7)', () => {
    expect(isStepInForecastWindow(new Date(2026, 8, 20), NOW, FORECAST_WINDOW_DAYS)).toBe(false);
  });

  it('exclui data passada', () => {
    expect(isStepInForecastWindow(new Date(2026, 8, 12), NOW)).toBe(false);
  });
});

describe('stepsInForecastWindow', () => {
  const steps: ForecastStepInput[] = [
    { substance: 'toxina_botulinica', status: 'pendente', expectedDate: new Date(2026, 8, 13) }, // hoje, pendente — entra
    { substance: 'toxina_botulinica', status: 'concluida', expectedDate: new Date(2026, 8, 14) }, // concluída — nunca representa necessidade futura
    { substance: 'toxina_botulinica', status: 'pulada', expectedDate: new Date(2026, 8, 15) }, // pulada — idem
    { substance: 'acido_hialuronico', status: 'pendente', expectedDate: new Date(2026, 8, 25) }, // fora da janela de 7 dias
    { substance: 'bioestimulador', status: 'pendente', expectedDate: new Date(2026, 7, 30) }, // no passado
  ];

  it('mantém só etapas pendentes dentro da janela, excluindo status concluído/pulado e datas fora da janela', () => {
    const result = stepsInForecastWindow(steps, NOW);
    expect(result).toHaveLength(1);
    expect(result[0].substance).toBe('toxina_botulinica');
  });
});

describe('extractHistoricalDoseSamples', () => {
  it('só extrai pontos de sessões com status "complete"', () => {
    const sessions = [
      { status: 'complete', stage2_overlay: [{ substance: 'toxina_botulinica', quantity: 20 }] },
      { status: 'in_progress', stage2_overlay: [{ substance: 'toxina_botulinica', quantity: 999 }] },
      { status: null, stage2_overlay: [{ substance: 'toxina_botulinica', quantity: 999 }] },
    ];
    const result = extractHistoricalDoseSamples(sessions);
    expect(result).toEqual([{ substance: 'toxina_botulinica', quantity: 20 }]);
  });

  it('ignora ponto com substância desconhecida, quantidade inválida ou <= 0', () => {
    const sessions = [
      {
        status: 'complete',
        stage2_overlay: [
          { substance: 'substancia_invalida', quantity: 5 },
          { substance: 'toxina_botulinica', quantity: 0 },
          { substance: 'toxina_botulinica', quantity: -3 },
          { substance: 'toxina_botulinica', quantity: NaN },
          { substance: 'toxina_botulinica', quantity: 15 },
        ],
      },
    ];
    expect(extractHistoricalDoseSamples(sessions)).toEqual([{ substance: 'toxina_botulinica', quantity: 15 }]);
  });

  it('devolve [] quando stage2_overlay não é um array (sessão sem pontos lançados)', () => {
    expect(extractHistoricalDoseSamples([{ status: 'complete', stage2_overlay: null }])).toEqual([]);
  });
});

describe('buildInsumoSubstanceMap', () => {
  it('mapeia só insumos cuja categoria é uma das 3 Substance', () => {
    const map = buildInsumoSubstanceMap([
      { id: 'ins-1', substance: 'toxina_botulinica' },
      { id: 'ins-2', substance: 'fios_sustentacao' },
    ]);
    expect(map.get('ins-1')).toBe('toxina_botulinica');
    expect(map.has('ins-2')).toBe(false);
  });
});

describe('nonExpiredStockBySubstance', () => {
  const insumoSubstanceById = buildInsumoSubstanceMap([{ id: 'ins-1', substance: 'toxina_botulinica' }]);

  it('soma lotes não vencidos e ignora lotes vencidos', () => {
    const batches = [
      { id: 'b1', insumoId: 'ins-1', batchNumber: 'L1', expiresOn: '2026-12-01', quantityReceived: 50, quantityRemaining: 30, receivedOn: '2026-01-01' },
      { id: 'b2', insumoId: 'ins-1', batchNumber: 'L2', expiresOn: '2026-01-01', quantityReceived: 50, quantityRemaining: 20, receivedOn: '2026-01-01' }, // vencido
    ];
    expect(nonExpiredStockBySubstance(batches, insumoSubstanceById, NOW)).toEqual({ toxina_botulinica: 30 });
  });

  it('lote sem validade cadastrada conta normalmente (ausência de validade não é "vencido")', () => {
    const batches = [
      { id: 'b1', insumoId: 'ins-1', batchNumber: 'L1', expiresOn: null, quantityReceived: 10, quantityRemaining: 10, receivedOn: '2026-01-01' },
    ];
    expect(nonExpiredStockBySubstance(batches, insumoSubstanceById, NOW)).toEqual({ toxina_botulinica: 10 });
  });

  it('ignora lote de insumo que não mapeia pra nenhuma Substance', () => {
    const batches = [
      { id: 'b1', insumoId: 'ins-desconhecido', batchNumber: 'L1', expiresOn: null, quantityReceived: 10, quantityRemaining: 10, receivedOn: '2026-01-01' },
    ];
    expect(nonExpiredStockBySubstance(batches, insumoSubstanceById, NOW)).toEqual({});
  });
});

describe('buildStockForecast', () => {
  it('opção (b): estima quantidade pela dose média real quando há amostra histórica suficiente', () => {
    const stepsInWindow: ForecastStepInput[] = [
      { substance: 'toxina_botulinica', status: 'pendente', expectedDate: NOW },
      { substance: 'toxina_botulinica', status: 'pendente', expectedDate: NOW },
    ];
    const historicalDoses = Array.from({ length: MIN_DOSE_HISTORY_SAMPLE_SIZE }, () => ({
      substance: 'toxina_botulinica' as const,
      quantity: 20,
    }));
    const result = buildStockForecast({
      stepsInWindow,
      historicalDoses,
      availableStockBySubstance: { toxina_botulinica: 100 },
    });
    expect(result).toEqual([
      {
        substance: 'toxina_botulinica',
        unit: 'unidades',
        stepsInWindow: 2,
        mode: 'estimate',
        averageDosePerStep: 20,
        estimatedQuantityNeeded: 40, // 2 etapas x 20 unidades
        sampleSize: MIN_DOSE_HISTORY_SAMPLE_SIZE,
        availableStock: 100,
        stockSufficient: true,
      },
    ]);
  });

  it('opção (a): cai para contagem simples quando a amostra histórica é insuficiente', () => {
    const stepsInWindow: ForecastStepInput[] = [
      { substance: 'acido_hialuronico', status: 'pendente', expectedDate: NOW },
      { substance: 'acido_hialuronico', status: 'pendente', expectedDate: NOW },
      { substance: 'acido_hialuronico', status: 'pendente', expectedDate: NOW },
    ];
    // só 2 amostras, abaixo de MIN_DOSE_HISTORY_SAMPLE_SIZE
    const historicalDoses = [
      { substance: 'acido_hialuronico' as const, quantity: 2 },
      { substance: 'acido_hialuronico' as const, quantity: 3 },
    ];
    const result = buildStockForecast({ stepsInWindow, historicalDoses, availableStockBySubstance: {} });
    expect(result).toEqual([
      {
        substance: 'acido_hialuronico',
        unit: 'ml',
        stepsInWindow: 3,
        mode: 'count',
        averageDosePerStep: null,
        estimatedQuantityNeeded: null,
        sampleSize: 2,
        availableStock: 0,
        stockSufficient: null,
      },
    ]);
  });

  it('estoque insuficiente: stockSufficient false quando availableStock < estimatedQuantityNeeded', () => {
    const stepsInWindow: ForecastStepInput[] = [{ substance: 'bioestimulador', status: 'pendente', expectedDate: NOW }];
    const historicalDoses = Array.from({ length: MIN_DOSE_HISTORY_SAMPLE_SIZE }, () => ({
      substance: 'bioestimulador' as const,
      quantity: 10,
    }));
    const result = buildStockForecast({
      stepsInWindow,
      historicalDoses,
      availableStockBySubstance: { bioestimulador: 5 },
    });
    expect(result[0].stockSufficient).toBe(false);
  });

  it('substância sem nenhuma etapa pendente na janela não aparece no resultado — nunca um falso "0 necessário"', () => {
    const result = buildStockForecast({ stepsInWindow: [], historicalDoses: [], availableStockBySubstance: {} });
    expect(result).toEqual([]);
  });

  it('sem etapas em nenhuma substância, o resultado inteiro é vazio (estado "sem dado suficiente" da UI)', () => {
    const stepsInWindow: ForecastStepInput[] = [];
    const historicalDoses = Array.from({ length: 10 }, () => ({ substance: 'toxina_botulinica' as const, quantity: 20 }));
    const result = buildStockForecast({ stepsInWindow, historicalDoses, availableStockBySubstance: { toxina_botulinica: 999 } });
    expect(result).toEqual([]);
  });
});

describe('doseHistoryLookbackStart', () => {
  it('devolve o dia 1 do mês N meses atrás', () => {
    const start = doseHistoryLookbackStart(12, new Date(2026, 8, 13));
    expect(start.getFullYear()).toBe(2025);
    expect(start.getMonth()).toBe(9); // outubro/2025 (12 meses incluindo o mês corrente)
    expect(start.getDate()).toBe(1);
  });
});
