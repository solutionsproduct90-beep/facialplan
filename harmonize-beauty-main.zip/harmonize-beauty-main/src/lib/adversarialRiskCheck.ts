// Segunda checagem automática de IA ("advogado do diabo") para os dois
// gatilhos de maior risco clínico do app:
//   1. Triagem ABCDE de lesão suspeita + decisão de "prosseguir mesmo
//      assim" (ver src/lib/skinScreening.ts e src/pages/SessaoTriagemPele.tsx);
//   2. Dose total de sessão acima do limiar de atenção por substância (ver
//      DOSE_ALERT_THRESHOLD/isDoseOverThreshold em src/types/harmonize.ts e
//      o resumo de dose em src/pages/SessaoEstagio2.tsx).
//
// Chama a edge function `adversarial-risk-check`, que por sua vez chama a
// Claude API com um prompt deliberadamente crítico/adversarial (ver
// supabase/functions/adversarial-risk-check/index.ts) pedindo um segundo
// parecer cético e ESPECÍFICO ao caso, para o profissional ler antes de
// confirmar. NUNCA bloqueia o fluxo — é estritamente informativo — e NUNCA
// deve virar um erro visível: `requestAdversarialRiskCheck` nunca rejeita a
// Promise; qualquer falha (rede, timeout, OPENAI_API_KEY ausente no
// servidor, resposta malformada) simplesmente resolve com
// `{ available: false }`, e o componente de UI (ver
// src/components/harmonize/AdversarialRiskCheck.tsx) não renderiza nada
// nesse caso — mesmo espírito de graceful degradation do restante da base
// (ver supabase/functions/analyze-face/index.ts).
import { supabase } from '@/integrations/supabase/client';
import type { Substance } from '@/types/harmonize';
import type { SkinScreeningCriterionKey } from '@/lib/skinScreening';

export interface DoseThresholdOverage {
  substance: Substance;
  total: number;
  unit: string;
  threshold: number;
  points: Array<{ region: string; quantity: number }>;
}

/**
 * `patientId` é obrigatório desde o gate de consentimento no servidor (squad
 * w1-3, ver supabase/functions/_shared/consentGate.ts): a edge function
 * precisa saber de QUEM é o caso clínico que ela vai mandar pra OpenAI
 * para checar se existe consentimento de uso de imagem/dados registrado
 * daquele paciente. Sem o campo, a function responde 400 e
 * `requestAdversarialRiskCheck` devolve `{ available: false }` — a segunda
 * opinião some da tela em vez de o dado do paciente sair do país sem base
 * legal.
 */
export type AdversarialRiskCheckRequest =
  | {
      type: 'skin_screening';
      patientId: string;
      skinScreening: {
        positiveCriteria: SkinScreeningCriterionKey[];
        lesionLocation: string | null;
        notes: string | null;
        justification: string;
      };
    }
  | {
      type: 'dose_threshold';
      patientId: string;
      doseThreshold: {
        overages: DoseThresholdOverage[];
        isFirstSession: boolean;
      };
    };

export interface AdversarialRiskCheckResult {
  available: boolean;
  counterpoint?: string;
}

/**
 * Builds the `dose_threshold` request straight from the data already
 * computed by the Etapa 2 screen — never recomputes which substances are
 * over threshold (that stays the single responsibility of
 * `isDoseOverThreshold`), only reshapes it for the edge function.
 */
export function buildDoseThresholdRequest(
  patientId: string,
  overThresholdSubstances: Array<[Substance, number]>,
  points: Array<{ substance: Substance; region: string; quantity: number }>,
  thresholdBySubstance: Record<Substance, number>,
  unitBySubstance: Record<Substance, string>,
  isFirstSession: boolean
): AdversarialRiskCheckRequest {
  const overages: DoseThresholdOverage[] = overThresholdSubstances.map(([substance, total]) => ({
    substance,
    total,
    unit: unitBySubstance[substance],
    threshold: thresholdBySubstance[substance],
    points: points
      .filter((p) => p.substance === substance)
      .map((p) => ({ region: p.region, quantity: p.quantity })),
  }));
  return { type: 'dose_threshold', patientId, doseThreshold: { overages, isFirstSession } };
}

/**
 * Calls the `adversarial-risk-check` edge function. Never throws and never
 * surfaces an error to the caller — any failure resolves to
 * `{ available: false }` so the UI can simply render nothing instead of an
 * error state (this is a supplementary safety hint, never a blocking gate).
 */
export async function requestAdversarialRiskCheck(
  request: AdversarialRiskCheckRequest
): Promise<AdversarialRiskCheckResult> {
  try {
    const { data, error } = await supabase.functions.invoke('adversarial-risk-check', {
      body: request,
    });
    if (error || !data) return { available: false };
    const result = data as { available?: boolean; counterpoint?: string };
    if (result.available && typeof result.counterpoint === 'string' && result.counterpoint.trim()) {
      return { available: true, counterpoint: result.counterpoint.trim() };
    }
    return { available: false };
  } catch {
    return { available: false };
  }
}
