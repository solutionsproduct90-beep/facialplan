import { describe, it, expect } from 'vitest';
import { generateQrCodeDataUrl } from './qrCode';

describe('generateQrCodeDataUrl', () => {
  it('returns a PNG data URL for a valid verification URL', async () => {
    const dataUrl = await generateQrCodeDataUrl('https://harmonize.app/present/8ce48925-2a03-4b67-b118-e17df300570a');
    expect(dataUrl).toMatch(/^data:image\/png;base64,/);
  });

  it('returns null for empty/missing input instead of throwing', async () => {
    expect(await generateQrCodeDataUrl('')).toBeNull();
    expect(await generateQrCodeDataUrl(null)).toBeNull();
    expect(await generateQrCodeDataUrl(undefined)).toBeNull();
  });

  it('encodes the given URL — different URLs produce different QR images', async () => {
    const a = await generateQrCodeDataUrl('https://harmonize.app/present/aaaaaaaa-0000-0000-0000-000000000000');
    const b = await generateQrCodeDataUrl('https://harmonize.app/present/bbbbbbbb-0000-0000-0000-000000000000');
    expect(a).not.toEqual(b);
  });
});
