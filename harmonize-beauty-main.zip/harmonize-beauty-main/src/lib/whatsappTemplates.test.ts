import { describe, it, expect } from 'vitest';
import {
  resolveWhatsAppTemplate,
  getWaitlistOfferTemplate,
  buildWaitlistOfferMessage,
} from './whatsappTemplates';

describe('resolveWhatsAppTemplate', () => {
  it('replaces a single known placeholder with its value', () => {
    expect(resolveWhatsAppTemplate('Olá {{nome_paciente}}!', { nome_paciente: 'Maria' })).toBe('Olá Maria!');
  });

  it('replaces multiple distinct placeholders', () => {
    const result = resolveWhatsAppTemplate(
      'Olá {{nome_paciente}}, aqui é {{nome_profissional}} da {{nome_clinica}}.',
      { nome_paciente: 'Maria', nome_profissional: 'Dra. Ana', nome_clinica: 'Clínica Bela Face' },
    );
    expect(result).toBe('Olá Maria, aqui é Dra. Ana da Clínica Bela Face.');
  });

  it('replaces every occurrence of the same placeholder', () => {
    const result = resolveWhatsAppTemplate('{{nome_paciente}}, {{nome_paciente}}!', { nome_paciente: 'João' });
    expect(result).toBe('João, João!');
  });

  it('tolerates extra whitespace inside the braces', () => {
    expect(resolveWhatsAppTemplate('Olá {{ nome_paciente }}!', { nome_paciente: 'Maria' })).toBe('Olá Maria!');
  });

  it('replaces a provided-but-empty/null value with an empty string', () => {
    expect(resolveWhatsAppTemplate('Olá {{nome_paciente}}!', { nome_paciente: '' })).toBe('Olá !');
    expect(resolveWhatsAppTemplate('Olá {{nome_paciente}}!', { nome_paciente: null })).toBe('Olá !');
    expect(resolveWhatsAppTemplate('Olá {{nome_paciente}}!', { nome_paciente: undefined })).toBe('Olá !');
  });

  it('leaves a placeholder untouched when its key is not provided at all (helps catch typos)', () => {
    expect(resolveWhatsAppTemplate('Olá {{nome_pacient}}!', { nome_paciente: 'Maria' })).toBe('Olá {{nome_pacient}}!');
  });

  it('leaves plain text without placeholders unchanged', () => {
    expect(resolveWhatsAppTemplate('Mensagem sem placeholder nenhum.', {})).toBe('Mensagem sem placeholder nenhum.');
  });

  it('resolves a realistic reactivation reminder template', () => {
    const body = 'Olá {{nome_paciente}}! Já faz um tempo desde sua última visita à {{nome_clinica}} para {{procedimento}}. Vamos agendar seu retorno?';
    const result = resolveWhatsAppTemplate(body, {
      nome_paciente: 'Camila',
      nome_clinica: 'Clínica Bela Face',
      procedimento: 'toxina botulínica',
    });
    expect(result).toBe(
      'Olá Camila! Já faz um tempo desde sua última visita à Clínica Bela Face para toxina botulínica. Vamos agendar seu retorno?',
    );
  });
});

describe('getWaitlistOfferTemplate', () => {
  it('returns a template with both placeholders for every supported language', () => {
    for (const language of ['pt', 'en', 'es', 'fr', 'it']) {
      const template = getWaitlistOfferTemplate(language);
      expect(template).toContain('{{nome_paciente}}');
      expect(template).toContain('{{data_horario}}');
    }
  });

  it('falls back to Portuguese for an unsupported/unknown language', () => {
    expect(getWaitlistOfferTemplate('de')).toBe(getWaitlistOfferTemplate('pt'));
  });
});

describe('buildWaitlistOfferMessage', () => {
  it('resolves the patient name and formatted date/time into the default template', () => {
    const message = buildWaitlistOfferMessage('Maria', '20/09 às 14:30', 'pt');
    expect(message).toContain('Maria');
    expect(message).toContain('20/09 às 14:30');
    expect(message).not.toContain('{{');
  });

  it('builds the message in English when given the English language code', () => {
    const message = buildWaitlistOfferMessage('Maria', 'Sep 20, 2:30 PM', 'en');
    expect(message).toBe(
      "Hi Maria! A slot just opened up in our schedule for Sep 20, 2:30 PM. Are you still interested in booking it? Reply to this message to confirm 😊",
    );
  });

  it('falls back to an empty patient name rather than leaving the placeholder literal', () => {
    const message = buildWaitlistOfferMessage(null, '20/09 às 14:30', 'pt');
    expect(message).not.toContain('{{nome_paciente}}');
  });

  it('defaults to Portuguese when no language is given', () => {
    expect(buildWaitlistOfferMessage('Maria', '20/09')).toBe(
      buildWaitlistOfferMessage('Maria', '20/09', 'pt'),
    );
  });
});
