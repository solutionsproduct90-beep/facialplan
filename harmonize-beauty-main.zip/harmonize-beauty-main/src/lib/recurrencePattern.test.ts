import { describe, it, expect } from 'vitest';
import {
  MIN_CYCLES_FOR_REGULAR_RECURRENCE,
  detectRecurrencePattern,
  detectRecurrencePatternsForSessions,
  mostRegularRecurrencePattern,
  type SessionForRecurrencePattern,
} from './recurrencePattern';

const completedSession = (createdAt: Date, substances: string[]): SessionForRecurrencePattern => ({
  status: 'complete',
  created_at: createdAt.toISOString(),
  stage2_overlay: substances.map((substance, i) => ({ id: `p${i}`, substance })),
});

describe('detectRecurrencePattern', () => {
  it('returns null when there are fewer than 2 dates — not enough to compute even one interval', () => {
    expect(detectRecurrencePattern([], 'toxina_botulinica')).toBeNull();
    expect(detectRecurrencePattern([new Date(2026, 0, 1)], 'toxina_botulinica')).toBeNull();
  });

  it('detects a regular pattern: 2+ cycles within the substance expected return window', () => {
    // Toxina botulínica: janela 4-6 meses. Retornos a cada ~150 dias (≈5 meses).
    const dates = [
      new Date(2025, 8, 1), // set/2025
      new Date(2026, 1, 1), // fev/2026 (~153 dias)
      new Date(2026, 5, 1), // jun/2026 (~120 dias)
    ];
    const pattern = detectRecurrencePattern(dates, 'toxina_botulinica');
    expect(pattern).not.toBeNull();
    expect(pattern!.substance).toBe('toxina_botulinica');
    expect(pattern!.cycleCount).toBe(2);
    expect(pattern!.isRegular).toBe(true);
    expect(pattern!.averageIntervalDays).toBeGreaterThan(100);
    expect(pattern!.averageIntervalDays).toBeLessThan(170);
  });

  it('does not flag as regular when cycleCount is below the minimum, even if the single interval fits the window', () => {
    const dates = [new Date(2026, 0, 1), new Date(2026, 4, 1)]; // 1 intervalo só
    const pattern = detectRecurrencePattern(dates, 'toxina_botulinica');
    expect(pattern).not.toBeNull();
    expect(pattern!.cycleCount).toBe(1);
    expect(pattern!.cycleCount).toBeLessThan(MIN_CYCLES_FOR_REGULAR_RECURRENCE);
    expect(pattern!.isRegular).toBe(false);
  });

  it('does not flag as regular when intervals are wildly outside the substance expected window', () => {
    // Toxina aplicada de novo depois de só 20 dias, e de novo depois de 500 —
    // nem perto da janela de 4-6 meses mesmo com folga.
    const dates = [new Date(2026, 0, 1), new Date(2026, 0, 21), new Date(2027, 5, 5)];
    const pattern = detectRecurrencePattern(dates, 'toxina_botulinica');
    expect(pattern).not.toBeNull();
    expect(pattern!.cycleCount).toBe(2);
    expect(pattern!.isRegular).toBe(false);
  });
});

describe('detectRecurrencePatternsForSessions', () => {
  it('returns one pattern per substance with 2+ completed sessions, ignoring substances seen only once', () => {
    const sessions = [
      completedSession(new Date(2025, 8, 1), ['toxina_botulinica']),
      completedSession(new Date(2026, 1, 1), ['toxina_botulinica']),
      completedSession(new Date(2026, 5, 1), ['toxina_botulinica']),
      completedSession(new Date(2026, 2, 1), ['acido_hialuronico']), // só 1x — não entra
    ];
    const patterns = detectRecurrencePatternsForSessions(sessions);
    expect(patterns).toHaveLength(1);
    expect(patterns[0].substance).toBe('toxina_botulinica');
    expect(patterns[0].isRegular).toBe(true);
  });

  it('ignores sessions that are not complete and sessions without a recognized substance', () => {
    const sessions = [
      completedSession(new Date(2025, 8, 1), ['toxina_botulinica']),
      { status: 'stage2', created_at: new Date(2026, 0, 1).toISOString(), stage2_overlay: [{ id: 'x', substance: 'toxina_botulinica' }] },
      { status: 'complete', created_at: new Date(2026, 1, 1).toISOString(), stage2_overlay: [] },
    ];
    expect(detectRecurrencePatternsForSessions(sessions)).toEqual([]);
  });

  it('never throws for a patient with no session history at all', () => {
    expect(detectRecurrencePatternsForSessions([])).toEqual([]);
    expect(detectRecurrencePatternsForSessions(null)).toEqual([]);
    expect(detectRecurrencePatternsForSessions(undefined)).toEqual([]);
  });
});

describe('mostRegularRecurrencePattern', () => {
  it('returns the substance with the most consolidated regular pattern (most cycles)', () => {
    const sessions = [
      // toxina: 3 ciclos regulares
      completedSession(new Date(2025, 0, 1), ['toxina_botulinica']),
      completedSession(new Date(2025, 4, 1), ['toxina_botulinica']),
      completedSession(new Date(2025, 8, 1), ['toxina_botulinica']),
      completedSession(new Date(2026, 0, 1), ['toxina_botulinica']),
      // ácido hialurônico: 2 ciclos regulares (janela 9-18 meses)
      completedSession(new Date(2024, 0, 1), ['acido_hialuronico']),
      completedSession(new Date(2024, 9, 1), ['acido_hialuronico']),
      completedSession(new Date(2025, 6, 1), ['acido_hialuronico']),
    ];
    const best = mostRegularRecurrencePattern(sessions);
    expect(best).not.toBeNull();
    expect(best!.substance).toBe('toxina_botulinica');
    expect(best!.cycleCount).toBe(3);
  });

  it('returns null when history is insufficient (fewer than 2 cycles) — no suggestion should be made', () => {
    const sessions = [
      completedSession(new Date(2026, 0, 1), ['toxina_botulinica']),
      completedSession(new Date(2026, 4, 1), ['toxina_botulinica']),
    ];
    expect(mostRegularRecurrencePattern(sessions)).toBeNull();
  });

  it('returns null when history is irregular, even with several sessions of the same substance', () => {
    const sessions = [
      completedSession(new Date(2026, 0, 1), ['toxina_botulinica']),
      completedSession(new Date(2026, 0, 25), ['toxina_botulinica']),
      completedSession(new Date(2027, 3, 1), ['toxina_botulinica']),
    ];
    expect(mostRegularRecurrencePattern(sessions)).toBeNull();
  });

  it('returns null for a patient without any history, never throwing', () => {
    expect(mostRegularRecurrencePattern([])).toBeNull();
    expect(mostRegularRecurrencePattern(null)).toBeNull();
    expect(mostRegularRecurrencePattern(undefined)).toBeNull();
  });
});
