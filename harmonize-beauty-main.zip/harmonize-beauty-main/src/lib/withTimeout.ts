/**
 * Executa `promise`, mas nunca espera por ela além de `ms` milissegundos:
 * se `promise` resolver ou rejeitar antes disso, devolve o valor resolvido
 * (ou `null` em caso de rejeição); se `ms` se esgotar primeiro, devolve
 * `null` sem cancelar `promise` (ela continua rodando em segundo plano,
 * apenas deixa de ser esperada).
 *
 * Pensado para reforços puramente cosméticos que não podem travar um fluxo
 * principal — hoje usado pela animação de "escaneamento" da tela de
 * carregamento da Nova Sessão (ver NovaSessao.tsx) para tentar usar a
 * posição real dos landmarks faciais (MediaPipe) sem nunca atrasar a
 * navegação além do tempo mínimo de exibição da animação.
 */
export function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T | null> {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(null);
      }
    }, ms);

    promise
      .then((value) => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(value);
        }
      })
      .catch(() => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
  });
}
