// Instala um IndexedDB fake em memória — jsdom (usado pelo resto da suíte)
// não implementa a API nativamente, e `offlineDb.ts` vira no-op silencioso
// sem ela (ver comentário no topo daquele arquivo). Importar aqui, e só
// aqui, mantém o restante da suíte (que renderiza páginas usando o hook
// sobre esta camada) livre de qualquer efeito colateral do IndexedDB real.
import "fake-indexeddb/auto";
import { describe, it, expect, beforeEach } from "vitest";
import { getDraft, putDraft, deleteDraft, __resetOfflineDbForTests } from "./offlineDb";

describe("offlineDb", () => {
  beforeEach(() => {
    __resetOfflineDbForTests();
  });

  it("retorna undefined para uma chave que nunca foi salva", async () => {
    const result = await getDraft("chave-inexistente");
    expect(result).toBeUndefined();
  });

  it("salva e depois lê o mesmo valor pela chave", async () => {
    const value = { sessionId: "s1", pendingSync: true, updatedAt: 123 };
    await putDraft("session:s1", value);
    const result = await getDraft<typeof value>("session:s1");
    expect(result).toEqual(value);
  });

  it("substitui o valor anterior ao salvar de novo na mesma chave", async () => {
    await putDraft("session:s2", { updatedAt: 1 });
    await putDraft("session:s2", { updatedAt: 2 });
    const result = await getDraft<{ updatedAt: number }>("session:s2");
    expect(result).toEqual({ updatedAt: 2 });
  });

  it("apaga uma entrada existente", async () => {
    await putDraft("session:s3", { updatedAt: 1 });
    await deleteDraft("session:s3");
    const result = await getDraft("session:s3");
    expect(result).toBeUndefined();
  });

  it("apagar uma chave inexistente não lança", async () => {
    await expect(deleteDraft("nunca-existiu")).resolves.toBeUndefined();
  });

  it("chaves diferentes não colidem entre si", async () => {
    await putDraft("session:a", { label: "a" });
    await putDraft("session:b", { label: "b" });
    expect(await getDraft("session:a")).toEqual({ label: "a" });
    expect(await getDraft("session:b")).toEqual({ label: "b" });
  });
});
