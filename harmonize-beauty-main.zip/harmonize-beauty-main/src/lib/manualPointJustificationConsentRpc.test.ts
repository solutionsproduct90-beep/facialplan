import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Verificação estática (mesmo padrão de adminIntelligenceConsentRpc.test.ts —
// não há infraestrutura de teste com Postgres real neste repositório) de que
// a migration que fecha a lacuna de consentimento de IA achada pelo QA
// Contínuo (ciclo 16) no Copiloto de Justificativa Clínica realmente aplica o
// filtro `patients.ai_improvement_consent = true` às 4 subconsultas de
// get_manual_point_justification_stats, e que nenhuma das garantias
// existentes (corte de amostra mínima, autorização de qualquer profissional
// autenticado, ausência de coluna de identidade no retorno) foi relaxada.
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260913013000_filter_manual_point_justification_stats_by_ai_consent.sql',
);
const sql = readFileSync(migrationPath, 'utf8');
const functionBodyMatch = sql.match(/AS \$\$([\s\S]*?)\$\$;/);
if (!functionBodyMatch) throw new Error('não achou o corpo da função na migration — o regex precisa ser ajustado');
const functionBody = functionBodyMatch[1];

describe('migration 20260913013000 — filtro de consentimento de IA em get_manual_point_justification_stats', () => {
  it('junta patients pelo patient_id da sessão e exige ai_improvement_consent = true na consulta de dose média (estatística primária)', () => {
    const doseQuery = functionBody.match(/INTO v_quantity_avg, v_quantity_n([\s\S]*?)\) points;/);
    expect(doseQuery).not.toBeNull();
    expect(doseQuery![1]).toMatch(/JOIN public\.patients p ON p\.id = s\.patient_id AND p\.ai_improvement_consent = true/);
  });

  it('junta patients na consulta de nota de precisão de simulação', () => {
    const accuracyQuery = functionBody.match(/INTO v_accuracy_avg, v_accuracy_n([\s\S]*?)AND pt->>'region' = p_region;/);
    expect(accuracyQuery).not.toBeNull();
    expect(accuracyQuery![1]).toMatch(/JOIN public\.patients p ON p\.id = s\.patient_id AND p\.ai_improvement_consent = true/);
  });

  it('junta patients pelo patient_id (nulável) na consulta de eventos adversos, excluindo por construção um evento sem paciente vinculado', () => {
    const adverseQuery = functionBody.match(/INTO v_adverse_n([\s\S]*?)WHERE i\.substance = p_substance;/);
    expect(adverseQuery).not.toBeNull();
    expect(adverseQuery![1]).toMatch(/JOIN public\.patients p ON p\.id = ae\.patient_id AND p\.ai_improvement_consent = true/);
  });

  it('junta patients na consulta do total de pontos (denominador da taxa de evento adverso)', () => {
    const totalQuery = functionBody.match(/INTO v_total_points_n([\s\S]*?)WHERE pt->>'substance' = p_substance;/);
    expect(totalQuery).not.toBeNull();
    expect(totalQuery![1]).toMatch(/JOIN public\.patients p ON p\.id = s\.patient_id AND p\.ai_improvement_consent = true/);
  });

  it('preserva a autorização "qualquer profissional autenticado" — não passou a exigir role de admin', () => {
    expect(functionBody).toContain('auth.uid() IS NULL');
    expect(functionBody).not.toContain("has_role(auth.uid(), 'admin')");
  });

  it('preserva os 3 cortes de amostra mínima (>= 5) independentes', () => {
    expect(functionBody).toMatch(/v_quantity_n\s*<\s*5\s*THEN\s*\n\s*RETURN;/);
    expect(functionBody).toMatch(/v_accuracy_n\s*>=\s*5/);
    expect(functionBody).toMatch(/v_total_points_n\s*>=\s*5/);
  });

  it('continua sem coluna de identidade (patient_id/professional_id/session_id) no RETURNS TABLE nem no RETURN QUERY final', () => {
    const returnsTableMatch = sql.match(/RETURNS TABLE\(([\s\S]*?)\)\s*\nLANGUAGE/);
    const returnQueryMatch = sql.match(/RETURN QUERY SELECT([\s\S]*?);\nEND;/);
    expect(returnsTableMatch).not.toBeNull();
    expect(returnQueryMatch).not.toBeNull();
    for (const forbidden of ['patient_id', 'professional_id', 'session_id', 'patient_name']) {
      expect(returnsTableMatch![1]).not.toContain(forbidden);
      expect(returnQueryMatch![1]).not.toContain(forbidden);
    }
  });

  it('usa CREATE OR REPLACE FUNCTION com a mesma assinatura de antes, preservando os GRANTs já concedidos em 20260911100000', () => {
    expect(sql).toMatch(/CREATE OR REPLACE FUNCTION public\.get_manual_point_justification_stats\(p_substance text, p_region text\)/);
    expect(sql).not.toContain('DROP FUNCTION');
    expect(sql).not.toContain('GRANT EXECUTE');
  });
});
