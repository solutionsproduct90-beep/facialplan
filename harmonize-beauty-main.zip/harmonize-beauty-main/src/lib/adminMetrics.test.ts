import { describe, it, expect } from 'vitest';
import {
  computeProfessionalMetrics,
  filterMetricsBySearch,
  summarizeProfessionalMetrics,
  buildSessionsChartData,
  type SessionForAdminMetrics,
  type InsumoRowForAdminMetrics,
  type ProfessionalProfileForMetrics,
} from './adminMetrics';
import type { ApplicationPoint } from '@/types/harmonize';

const profile = (overrides: Partial<ProfessionalProfileForMetrics> = {}): ProfessionalProfileForMetrics => ({
  id: 'pro-1',
  full_name: 'Dra. Ana',
  clinic_name: 'Clínica Bela',
  currency: 'BRL',
  labor_fee_per_session: null,
  ...overrides,
});

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'malar_direita',
  label: 'Malar Direita',
  substance: 'acido_hialuronico',
  quantity: 2,
  unit: 'ml',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

const insumoRow = (overrides: Partial<InsumoRowForAdminMetrics> = {}): InsumoRowForAdminMetrics => ({
  professional_id: 'pro-1',
  id: 'ins-1',
  substance: 'acido_hialuronico',
  brand_name: 'Juvederm Voluma',
  cost_per_unit: 400,
  price_per_unit: 1500,
  active: true,
  ...overrides,
});

const session = (overrides: Partial<SessionForAdminMetrics> = {}): SessionForAdminMetrics => ({
  professional_id: 'pro-1',
  patient_id: 'pat-1',
  status: 'stage1',
  created_at: '2026-09-01T10:00:00.000Z',
  stage2_overlay: null,
  ...overrides,
});

describe('computeProfessionalMetrics', () => {
  it('zeroes every metric for a professional with no sessions, without NaN', () => {
    const [metrics] = computeProfessionalMetrics([], [], [profile()]);
    expect(metrics).toMatchObject({
      professionalId: 'pro-1',
      sessionsCount: 0,
      closedCount: 0,
      conversionPct: 0,
      estimatedRevenue: 0,
      uniquePatientsCount: 0,
      returningPatientsCount: 0,
      returnRatePct: 0,
    });
  });

  it('counts sessions and computes conversion as closed ("complete") over total', () => {
    const sessions = [
      session({ status: 'stage1' }),
      session({ status: 'stage2' }),
      session({ status: 'complete' }),
      session({ status: 'complete' }),
    ];
    const [metrics] = computeProfessionalMetrics(sessions, [], [profile()]);
    expect(metrics.sessionsCount).toBe(4);
    expect(metrics.closedCount).toBe(2);
    expect(metrics.conversionPct).toBeCloseTo(0.5);
  });

  it('sums computeBudget totalPrice across sessions that have application points, using that professional\'s own insumos and labor fee', () => {
    const sessions = [
      session({ id: 's1', status: 'complete', stage2_overlay: [point({ quantity: 2, insumoId: 'ins-1' })] } as any),
      session({ status: 'stage1', stage2_overlay: null }),
    ];
    const [metrics] = computeProfessionalMetrics(
      sessions,
      [insumoRow()],
      [profile({ labor_fee_per_session: 100 })],
    );
    // 2 * 1500 (price_per_unit) + 100 (labor fee, since a point was priced) = 3100
    expect(metrics.estimatedRevenue).toBe(3100);
  });

  it('never mixes insumos across professionals when computing revenue', () => {
    const sessions = [session({ professional_id: 'pro-2', stage2_overlay: [point({ insumoId: 'ins-1' })] } as any)];
    const insumos = [insumoRow({ professional_id: 'pro-1' })]; // belongs to pro-1, not pro-2
    const [, metricsPro2] = computeProfessionalMetrics(
      sessions,
      insumos,
      [profile({ id: 'pro-1' }), profile({ id: 'pro-2', full_name: 'Dr. Bruno' })],
    );
    // pro-2 has a session with a point pointing at ins-1, but ins-1 isn't in pro-2's own insumos list,
    // so the point is unpriced and contributes nothing.
    expect(metricsPro2.estimatedRevenue).toBe(0);
  });

  it('counts a patient with more than one session as returning, and one session as non-returning', () => {
    const sessions = [
      session({ patient_id: 'pat-a' }),
      session({ patient_id: 'pat-a' }),
      session({ patient_id: 'pat-b' }),
    ];
    const [metrics] = computeProfessionalMetrics(sessions, [], [profile()]);
    expect(metrics.uniquePatientsCount).toBe(2);
    expect(metrics.returningPatientsCount).toBe(1);
    expect(metrics.returnRatePct).toBeCloseTo(0.5);
  });

  it('falls back to BRL when profile.currency is missing or not a supported code', () => {
    const [metrics] = computeProfessionalMetrics([], [], [profile({ currency: null })]);
    expect(metrics.currency).toBe('BRL');
    const [metrics2] = computeProfessionalMetrics([], [], [profile({ currency: 'XPTO' })]);
    expect(metrics2.currency).toBe('BRL');
  });

  it('keeps a distinct row per professional even when one has zero sessions', () => {
    const sessions = [session({ professional_id: 'pro-1' })];
    const result = computeProfessionalMetrics(
      sessions,
      [],
      [profile({ id: 'pro-1' }), profile({ id: 'pro-2', full_name: 'Dr. Bruno' })],
    );
    expect(result).toHaveLength(2);
    expect(result.find((m) => m.professionalId === 'pro-2')?.sessionsCount).toBe(0);
  });
});

describe('filterMetricsBySearch', () => {
  const metrics = computeProfessionalMetrics(
    [],
    [],
    [
      profile({ id: 'pro-1', full_name: 'Dra. Ana', clinic_name: 'Clínica Bela' }),
      profile({ id: 'pro-2', full_name: 'Dr. Bruno', clinic_name: 'Studio Derme' }),
    ],
  );

  it('returns everything for an empty/blank query', () => {
    expect(filterMetricsBySearch(metrics, '   ')).toHaveLength(2);
  });

  it('matches by professional name, case-insensitively', () => {
    expect(filterMetricsBySearch(metrics, 'ana')).toEqual([expect.objectContaining({ professionalId: 'pro-1' })]);
  });

  it('matches by clinic name too', () => {
    expect(filterMetricsBySearch(metrics, 'derme')).toEqual([expect.objectContaining({ professionalId: 'pro-2' })]);
  });

  it('returns an empty list when nothing matches', () => {
    expect(filterMetricsBySearch(metrics, 'nonexistent')).toEqual([]);
  });
});

describe('summarizeProfessionalMetrics', () => {
  it('sums counts and computes overall rates across professionals', () => {
    const metrics = computeProfessionalMetrics(
      [
        session({ professional_id: 'pro-1', status: 'complete', patient_id: 'a' }),
        session({ professional_id: 'pro-1', status: 'stage1', patient_id: 'a' }),
        session({ professional_id: 'pro-2', status: 'complete', patient_id: 'b' }),
      ],
      [],
      [profile({ id: 'pro-1' }), profile({ id: 'pro-2', currency: 'BRL' })],
    );
    const summary = summarizeProfessionalMetrics(metrics);
    expect(summary.totalSessions).toBe(3);
    expect(summary.totalClosed).toBe(2);
    expect(summary.overallConversionPct).toBeCloseTo(2 / 3);
    expect(summary.totalUniquePatients).toBe(2);
    expect(summary.totalReturning).toBe(1); // patient "a" returned to pro-1
  });

  it('reports a common currency and sums revenue when every professional in the slice shares it', () => {
    const metrics = computeProfessionalMetrics(
      [session({ professional_id: 'pro-1', stage2_overlay: [point({ insumoId: 'ins-1' })] } as any)],
      [insumoRow()],
      [profile({ id: 'pro-1', currency: 'USD' }), profile({ id: 'pro-2', currency: 'USD' })],
    );
    const summary = summarizeProfessionalMetrics(metrics);
    expect(summary.currency).toBe('USD');
    expect(summary.totalRevenue).toBe(metrics[0].estimatedRevenue + metrics[1].estimatedRevenue);
  });

  it('hides the total revenue (null) when professionals in the slice use different currencies', () => {
    const metrics = computeProfessionalMetrics(
      [],
      [],
      [profile({ id: 'pro-1', currency: 'BRL' }), profile({ id: 'pro-2', currency: 'USD' })],
    );
    const summary = summarizeProfessionalMetrics(metrics);
    expect(summary.currency).toBeNull();
    expect(summary.totalRevenue).toBeNull();
  });

  it('returns a null currency/revenue for an empty slice instead of assuming BRL', () => {
    const summary = summarizeProfessionalMetrics([]);
    expect(summary.currency).toBeNull();
    expect(summary.totalRevenue).toBeNull();
    expect(summary.totalSessions).toBe(0);
  });
});

describe('buildSessionsChartData', () => {
  it('sorts professionals by session count, descending', () => {
    const metrics = computeProfessionalMetrics(
      [
        session({ professional_id: 'pro-1' }),
        session({ professional_id: 'pro-2' }),
        session({ professional_id: 'pro-2' }),
      ],
      [],
      [profile({ id: 'pro-1', full_name: 'Dra. Ana' }), profile({ id: 'pro-2', full_name: 'Dr. Bruno' })],
    );
    expect(buildSessionsChartData(metrics)).toEqual([
      { name: 'Dr. Bruno', sessions: 2 },
      { name: 'Dra. Ana', sessions: 1 },
    ]);
  });

  it('limits the number of bars', () => {
    const profiles = Array.from({ length: 10 }, (_, i) => profile({ id: `pro-${i}`, full_name: `Pro ${i}` }));
    const metrics = computeProfessionalMetrics([], [], profiles);
    expect(buildSessionsChartData(metrics, 3)).toHaveLength(3);
  });

  it('falls back to clinic name, then a dash, when there is no professional name', () => {
    const metrics = computeProfessionalMetrics([], [], [profile({ full_name: null, clinic_name: 'Só Clínica' })]);
    expect(buildSessionsChartData(metrics)[0].name).toBe('Só Clínica');
    const metrics2 = computeProfessionalMetrics([], [], [profile({ full_name: null, clinic_name: null })]);
    expect(buildSessionsChartData(metrics2)[0].name).toBe('—');
  });
});
