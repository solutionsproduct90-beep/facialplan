import { describe, it, expect } from 'vitest';
import {
  isPatientStalled,
  buildReactivationWhatsAppLink,
  buildReturnRadarReminderWhatsAppLink,
  STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS,
} from './patientReactivation';

const NOW = new Date('2026-09-10T12:00:00Z');
const daysAgo = (n: number) => new Date(NOW.getTime() - n * 24 * 60 * 60 * 1000).toISOString();

describe('isPatientStalled', () => {
  it('is false for a patient with no session yet (new, not stalled)', () => {
    expect(isPatientStalled(null, NOW)).toBe(false);
    expect(isPatientStalled(undefined, NOW)).toBe(false);
  });

  it('is false when the last session is within the threshold', () => {
    expect(isPatientStalled(daysAgo(1), NOW)).toBe(false);
    expect(isPatientStalled(daysAgo(STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS - 0.1), NOW)).toBe(false);
  });

  it('is true once the last session has aged past the threshold', () => {
    expect(isPatientStalled(daysAgo(STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS), NOW)).toBe(true);
    expect(isPatientStalled(daysAgo(STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS + 40), NOW)).toBe(true);
  });

  it('is false for an unparseable date instead of throwing', () => {
    expect(isPatientStalled('not-a-date', NOW)).toBe(false);
  });

  it('honors a custom threshold', () => {
    expect(isPatientStalled(daysAgo(20), NOW, 14)).toBe(true);
    expect(isPatientStalled(daysAgo(20), NOW, 30)).toBe(false);
  });
});

describe('buildReactivationWhatsAppLink', () => {
  it('targets the patient phone (digits only) when one is registered', () => {
    const url = buildReactivationWhatsAppLink('+5521658924242', 'Olá!');
    expect(url).toBe('https://wa.me/5521658924242?text=Ol%C3%A1!');
  });

  it('strips non-digit formatting from the stored phone', () => {
    const url = buildReactivationWhatsAppLink('+1 (555) 123-4567', 'Oi');
    expect(url).toContain('https://wa.me/15551234567?text=');
  });

  it('falls back to the generic wa.me share link when there is no phone', () => {
    expect(buildReactivationWhatsAppLink(null, 'Oi')).toBe('https://wa.me/?text=Oi');
    expect(buildReactivationWhatsAppLink('', 'Oi')).toBe('https://wa.me/?text=Oi');
  });

  it('URL-encodes the message', () => {
    const url = buildReactivationWhatsAppLink(null, 'Olá, tudo bem? 😊');
    expect(url).toBe(`https://wa.me/?text=${encodeURIComponent('Olá, tudo bem? 😊')}`);
  });
});

describe('buildReturnRadarReminderWhatsAppLink', () => {
  const messages = {
    upcoming: 'Oi, Ana! Hora de agendar seu retorno.',
    overdue: 'Oi, Ana! Notamos que já passou o período recomendado do seu retorno.',
  };

  it('uses the "upcoming" message and targets the patient phone when the radar is not overdue yet', () => {
    const url = buildReturnRadarReminderWhatsAppLink('+5521658924242', false, messages);
    expect(url).toBe(`https://wa.me/5521658924242?text=${encodeURIComponent(messages.upcoming)}`);
  });

  it('uses the "overdue" message once the radar has passed its predicted window', () => {
    const url = buildReturnRadarReminderWhatsAppLink('+5521658924242', true, messages);
    expect(url).toBe(`https://wa.me/5521658924242?text=${encodeURIComponent(messages.overdue)}`);
  });

  it('falls back to the generic wa.me share link when there is no phone, same as buildReactivationWhatsAppLink', () => {
    expect(buildReturnRadarReminderWhatsAppLink(null, false, messages)).toBe(
      `https://wa.me/?text=${encodeURIComponent(messages.upcoming)}`
    );
    expect(buildReturnRadarReminderWhatsAppLink(undefined, true, messages)).toBe(
      `https://wa.me/?text=${encodeURIComponent(messages.overdue)}`
    );
  });
});
