/**
 * Helper genérico de retry com backoff exponencial para chamadas assíncronas
 * que podem falhar por instabilidade transitória de rede — pensado
 * principalmente para `supabase.functions.invoke(...)` (edge functions como
 * `analyze-face` e `generate-simulation`), mas funciona para qualquer
 * `Promise`.
 *
 * Não é aplicado automaticamente a nenhuma página; cada chamador decide
 * quando usar (evita reintentar operações não-idempotentes por engano).
 *
 * Exemplo de uso:
 * ```ts
 * import { retryFetch } from "@/lib/retryFetch";
 * import { supabase } from "@/integrations/supabase/client";
 *
 * const { data, error } = await retryFetch(() =>
 *   supabase.functions.invoke("analyze-face", { body: { imageUrl } })
 * );
 * ```
 *
 * Por padrão tenta 3 vezes (1 chamada inicial + 2 retentativas) com backoff
 * exponencial (500ms, 1000ms, ...) e jitter leve para evitar thundering herd.
 */

export interface RetryFetchOptions {
  /** Número total de tentativas (>= 1). Padrão: 3. */
  attempts?: number;
  /** Delay base em ms usado no backoff exponencial. Padrão: 500. */
  baseDelayMs?: number;
  /** Multiplicador aplicado ao delay a cada nova tentativa. Padrão: 2. */
  factor?: number;
  /** Delay máximo em ms entre tentativas. Padrão: 8000. */
  maxDelayMs?: number;
  /**
   * Decide se um erro específico deve ser reintentado. Por padrão, todo
   * erro é reintentado. Use para não reintentar, por exemplo, erros de
   * validação (4xx) que não vão se resolver sozinhos.
   */
  shouldRetry?: (error: unknown, attempt: number) => boolean;
  /** Chamado antes de cada nova tentativa (attempt começa em 1 para a 2ª tentativa). */
  onRetry?: (error: unknown, attempt: number, delayMs: number) => void;
}

const DEFAULT_OPTIONS: Required<Pick<RetryFetchOptions, "attempts" | "baseDelayMs" | "factor" | "maxDelayMs">> = {
  attempts: 3,
  baseDelayMs: 500,
  factor: 2,
  maxDelayMs: 8000,
};

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function computeDelay(attemptIndex: number, baseDelayMs: number, factor: number, maxDelayMs: number): number {
  const exponential = baseDelayMs * Math.pow(factor, attemptIndex);
  const capped = Math.min(exponential, maxDelayMs);
  // jitter leve (+/- 20%) para evitar que várias chamadas retentem no mesmo instante
  const jitter = capped * 0.2 * (Math.random() * 2 - 1);
  return Math.max(0, Math.round(capped + jitter));
}

/**
 * Executa `fn` e reintenta com backoff exponencial em caso de falha.
 *
 * `fn` deve retornar (ou rejeitar com) o resultado da operação. Note que
 * `supabase.functions.invoke` normalmente NÃO rejeita a promise em erros de
 * aplicação — ele resolve com `{ data, error }`. Se você quiser que erros
 * retornados nesse formato também disparem retry, lance-os dentro de `fn`,
 * por exemplo:
 * ```ts
 * await retryFetch(async () => {
 *   const { data, error } = await supabase.functions.invoke("analyze-face", { body });
 *   if (error) throw error;
 *   return data;
 * });
 * ```
 */
export async function retryFetch<T>(fn: () => Promise<T>, options: RetryFetchOptions = {}): Promise<T> {
  const { attempts, baseDelayMs, factor, maxDelayMs, shouldRetry, onRetry } = {
    ...DEFAULT_OPTIONS,
    ...options,
  };

  if (attempts < 1) {
    throw new Error("retryFetch: 'attempts' deve ser >= 1");
  }

  let lastError: unknown;

  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;

      const isLastAttempt = attempt === attempts - 1;
      const canRetry = shouldRetry ? shouldRetry(error, attempt + 1) : true;

      if (isLastAttempt || !canRetry) {
        throw error;
      }

      const delayMs = computeDelay(attempt, baseDelayMs, factor, maxDelayMs);
      onRetry?.(error, attempt + 1, delayMs);
      await sleep(delayMs);
    }
  }

  // Inalcançável (o loop sempre retorna ou lança), mas mantém o TypeScript feliz.
  throw lastError;
}
