// Catálogo curado de Procedimentos nomeados (backlog #47) — motivado pela
// análise do concorrente Full Face Academy, que organiza 17 procedimentos
// nomeados em categorias, cada um com 3 níveis fixos de intensidade
// (Suave/Médio/Alto) pré-mapeados a uma dose.
//
// Diferença deliberada em relação ao concorrente: aqui cada nível de
// intensidade mapeia para uma FAIXA numérica de referência (min–max, em ml ou
// unidades — a mesma unidade de ApplicationPoint), nunca para um score de
// "naturalidade"/"harmonia" tipo percentual. Essa é uma decisão de produto já
// tomada, não um detalhe de implementação — ver o comentário em
// `src/types/harmonize.ts` (linhas 35-42) sobre por que este app não expõe
// nenhum "Score de Harmonia" (ex. "62%"/"85%"/"91%") como métrica clínica.
//
// Cada entrada é só um PONTO DE PARTIDA sugerido para pré-preencher o
// formulário da Etapa 2 (ver src/pages/SessaoEstagio2.tsx) — o profissional
// pode sempre editar região, substância e dose livremente depois de
// selecionar um procedimento; nada aqui trava campo nem valida a edição
// manual contra a faixa do catálogo.
import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { SUBSTANCE_DEFAULT_UNIT } from '@/types/harmonize';
import type { FaceRegionKey } from '@/lib/faceRegions';
import { FACE_REGION_KEYS } from '@/lib/faceRegions';

export type IntensityLevel = 'suave' | 'medio' | 'alto';

export const INTENSITY_LEVELS: IntensityLevel[] = ['suave', 'medio', 'alto'];

export type ProcedureCategory = 'harmonizacao_facial' | 'rejuvenescimento_pele';

export const PROCEDURE_CATEGORIES: ProcedureCategory[] = ['harmonizacao_facial', 'rejuvenescimento_pele'];

/** Faixa de dose de referência (min–max, na unidade de `Substance`) para um
 * nível de intensidade — nunca um score, ver comentário de arquivo acima. */
export type DoseRange = { min: number; max: number };

export type NamedProcedure = {
  id: string;
  /** Nome em português — fonte da chave de tradução
   * `procedureCatalog.procedures.<id>.name` (ver `procedureDisplayName`
   * abaixo); serve também de `defaultValue` quando a chave ainda não foi
   * traduzida para o idioma ativo. */
  name: string;
  category: ProcedureCategory;
  substance: Substance;
  /** Uma ou mais regiões clínicas associadas (ver FaceRegionKey em
   * src/lib/faceRegions.ts) — um procedimento bilateral lista as duas
   * regiões (esquerda/direita) e a Etapa 2 deixa o profissional escolher
   * qual delas usar no ponto sendo criado/editado. */
  regions: FaceRegionKey[];
  doseRangeByLevel: Record<IntensityLevel, DoseRange>;
};

// Faixas abaixo são um ponto de partida de engenharia a partir de consenso
// básico de literatura estética (mesmo espírito de ressalva de
// DOSE_ALERT_THRESHOLD em src/types/harmonize.ts) — não validadas
// clinicamente, e sempre editáveis pelo profissional após selecionar o
// procedimento na Etapa 2.
//
// Cobertura deliberadamente NÃO exaustiva (ao contrário dos 17 itens do
// concorrente): prioriza os procedimentos faciais injetáveis mais comuns na
// prática, usando a taxonomia de região já existente — incluindo
// olheira_*/tempora_*, adicionadas anteriormente sem nenhum procedimento
// nomeado ainda as referenciando. Fora do escopo (não incluído): qualquer
// item de odontologia/estética dental do catálogo do concorrente — este app
// é só de harmonização facial injetável.
export const PROCEDURE_CATALOG: NamedProcedure[] = [
  {
    id: 'preenchimento_labial',
    name: 'Preenchimento Labial',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['labio_superior', 'labio_inferior'],
    doseRangeByLevel: {
      suave: { min: 0.5, max: 1.0 },
      medio: { min: 1.0, max: 1.5 },
      alto: { min: 1.5, max: 2.0 },
    },
  },
  {
    id: 'preenchimento_malar',
    name: 'Preenchimento Malar',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['malar_esquerda', 'malar_direita'],
    doseRangeByLevel: {
      suave: { min: 0.5, max: 1.0 },
      medio: { min: 1.0, max: 2.0 },
      alto: { min: 2.0, max: 3.0 },
    },
  },
  {
    id: 'contorno_mandibular',
    name: 'Contorno Mandibular',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['mandibula_esquerda', 'mandibula_direita'],
    doseRangeByLevel: {
      suave: { min: 1.0, max: 2.0 },
      medio: { min: 2.0, max: 3.0 },
      alto: { min: 3.0, max: 4.0 },
    },
  },
  {
    id: 'projecao_mentoniana',
    name: 'Projeção Mentoniana',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['mento'],
    doseRangeByLevel: {
      suave: { min: 0.5, max: 1.0 },
      medio: { min: 1.0, max: 1.5 },
      alto: { min: 1.5, max: 2.0 },
    },
  },
  {
    id: 'preenchimento_temporal',
    name: 'Preenchimento de Têmporas',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['tempora_esquerda', 'tempora_direita'],
    doseRangeByLevel: {
      suave: { min: 0.5, max: 1.0 },
      medio: { min: 1.0, max: 2.0 },
      alto: { min: 2.0, max: 3.0 },
    },
  },
  {
    id: 'preenchimento_olheira',
    name: 'Preenchimento de Olheira (Sulco Lacrimal)',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['olheira_esquerda', 'olheira_direita'],
    doseRangeByLevel: {
      suave: { min: 0.4, max: 0.6 },
      medio: { min: 0.6, max: 1.0 },
      alto: { min: 1.0, max: 1.4 },
    },
  },
  {
    id: 'preenchimento_sulco_nasolabial',
    name: 'Preenchimento do Sulco Nasolabial',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['sulco_nasolabial_esquerdo', 'sulco_nasolabial_direito'],
    doseRangeByLevel: {
      suave: { min: 0.5, max: 1.0 },
      medio: { min: 1.0, max: 1.5 },
      alto: { min: 1.5, max: 2.0 },
    },
  },
  {
    id: 'rinomodelacao',
    name: 'Rinomodelação',
    category: 'harmonizacao_facial',
    substance: 'acido_hialuronico',
    regions: ['dorso_nasal', 'ponta_nasal'],
    doseRangeByLevel: {
      suave: { min: 0.3, max: 0.5 },
      medio: { min: 0.5, max: 0.8 },
      alto: { min: 0.8, max: 1.0 },
    },
  },
  {
    id: 'toxina_terco_frontal',
    name: 'Toxina Botulínica — Terço Frontal',
    category: 'harmonizacao_facial',
    substance: 'toxina_botulinica',
    regions: ['terco_frontal'],
    doseRangeByLevel: {
      suave: { min: 8, max: 12 },
      medio: { min: 12, max: 20 },
      alto: { min: 20, max: 30 },
    },
  },
  {
    id: 'toxina_glabela',
    name: 'Toxina Botulínica — Glabela',
    category: 'harmonizacao_facial',
    substance: 'toxina_botulinica',
    regions: ['glabela'],
    doseRangeByLevel: {
      suave: { min: 10, max: 15 },
      medio: { min: 15, max: 20 },
      alto: { min: 20, max: 25 },
    },
  },
  {
    id: 'toxina_pes_de_galinha',
    // Não há uma região dedicada a "pés de galinha" (rugas periorbitais
    // laterais) na taxonomia atual de FaceRegionKey — reaproveita
    // tempora_esquerda/direita, a região existente anatomicamente mais
    // próxima do sítio de aplicação lateral ao olho. Decisão de escopo desta
    // tarefa: revisitar se/quando uma região periorbital dedicada for
    // adicionada (mesmo espírito de "taxonomia primeiro" já usado para
    // olheira_*/tempora_*, ver src/lib/faceRegions.ts).
    name: 'Toxina Botulínica — Pés de Galinha',
    category: 'harmonizacao_facial',
    substance: 'toxina_botulinica',
    regions: ['tempora_esquerda', 'tempora_direita'],
    doseRangeByLevel: {
      suave: { min: 4, max: 8 },
      medio: { min: 8, max: 12 },
      alto: { min: 12, max: 16 },
    },
  },
  {
    id: 'toxina_masseter',
    name: 'Toxina Botulínica — Máster/Contorno Mandibular',
    category: 'harmonizacao_facial',
    substance: 'toxina_botulinica',
    regions: ['mandibula_esquerda', 'mandibula_direita'],
    doseRangeByLevel: {
      suave: { min: 40, max: 60 },
      medio: { min: 60, max: 80 },
      alto: { min: 80, max: 100 },
    },
  },
  {
    id: 'toxina_comissura_labial',
    name: 'Toxina Botulínica — Comissura Labial',
    category: 'harmonizacao_facial',
    substance: 'toxina_botulinica',
    regions: ['comissura_labial_esquerda', 'comissura_labial_direita'],
    doseRangeByLevel: {
      suave: { min: 2, max: 4 },
      medio: { min: 4, max: 6 },
      alto: { min: 6, max: 8 },
    },
  },
  {
    id: 'bioestimulador_full_face',
    name: 'Bioestimulador de Colágeno — Full Face',
    category: 'rejuvenescimento_pele',
    substance: 'bioestimulador',
    regions: ['malar_esquerda', 'malar_direita', 'mandibula_esquerda', 'mandibula_direita', 'terco_frontal'],
    doseRangeByLevel: {
      suave: { min: 2, max: 4 },
      medio: { min: 4, max: 6 },
      alto: { min: 6, max: 8 },
    },
  },
];

export function proceduresForSubstance(substance: Substance): NamedProcedure[] {
  return PROCEDURE_CATALOG.filter((p) => p.substance === substance);
}

export function getProcedure(id: string | undefined): NamedProcedure | undefined {
  if (!id) return undefined;
  return PROCEDURE_CATALOG.find((p) => p.id === id);
}

/** Chave de tradução do nome do procedimento — usar com `t(key, { defaultValue
 * : procedure.name })`, mesmo padrão de fallback já usado em outras telas
 * (ex. `sessions.status.${status}` em SessionCard.tsx) para nunca depender
 * só da tradução estar completa nos 5 idiomas. */
export function procedureNameKey(id: string): string {
  return `procedureCatalog.procedures.${id}.name`;
}

/** Nome exibível do procedimento, já resolvido via `translate` (tipicamente
 * o `t` de `useTranslation()`) com fallback para o nome em português
 * cadastrado no catálogo. Devolve `undefined` para um `procedureId`
 * desconhecido ou ausente — chamador decide se omite a informação (ver uso
 * em SessaoEstagio3.tsx, onde um ponto sem `procedureId` simplesmente não
 * ganha a linha extra de protocolo). */
export function procedureDisplayName(
  id: string | undefined,
  translate: (key: string, options?: { defaultValue?: string }) => string,
): string | undefined {
  const procedure = getProcedure(id);
  if (!procedure) return undefined;
  return translate(procedureNameKey(procedure.id), { defaultValue: procedure.name });
}

/** Dose sugerida (ponto médio da faixa do nível escolhido) para pré-preencher
 * o formulário da Etapa 2 — arredondada ao mesmo "step" de quantidade já
 * usado ali (1 unidade para toxina, 0.1 ml para as demais substâncias). O
 * profissional pode sempre editar o valor livremente depois; isto nunca
 * trava o campo. */
export function suggestedDoseForLevel(procedure: NamedProcedure, level: IntensityLevel): number {
  const { min, max } = procedure.doseRangeByLevel[level];
  const mid = (min + max) / 2;
  const step = SUBSTANCE_DEFAULT_UNIT[procedure.substance] === 'unidades' ? 1 : 0.1;
  return Math.round(mid / step) * step;
}

// ---------------------------------------------------------------------------
// "Plano B" (orçamento reduzido) — análise competitiva do Full Face Academy,
// que mostra no mesmo laudo um "Plano A" (protocolo completo) e um "Plano B"
// (versão reduzida) lado a lado, com as mesmas condições de pagamento já
// calculadas pros dois (âncora + saída).
//
// Abordagem escolhida (a mais simples de implementar corretamente sem exigir
// nenhuma tela/estado novo antes de gerar o PDF): Plano B reaproveita os
// MESMOS pontos de aplicação do Plano A, com a dose de cada ponto vinculado a
// um procedimento nomeado (`procedureId`) reduzida ao nível "Suave" do
// catálogo via `suggestedDoseForLevel` — em vez de pedir ao profissional para
// selecionar manualmente quais pontos entram no Plano B (o que exigiria uma
// UI de seleção nova em SessaoEstagio3.tsx e persistência da escolha). Um
// ponto sem `procedureId` (manual, sugestão de IA sem procedimento vinculado,
// ou plano criado antes do catálogo — backlog #47) não tem faixa de
// referência pra reduzir e mantém sua quantidade original nos dois planos.
// ---------------------------------------------------------------------------

/**
 * Quantidade do ponto no Plano B: a dose sugerida do nível "Suave" do
 * procedimento nomeado vinculado, nunca MAIOR que a quantidade já escolhida
 * pelo profissional no Plano A (se o profissional já escolheu uma dose
 * abaixo da própria faixa "Suave", o Plano B não a aumenta — é sempre igual
 * ou mais enxuto, nunca o contrário). Pontos sem `procedureId` mantêm a
 * quantidade original.
 */
export function planBQuantity(point: Pick<ApplicationPoint, 'procedureId' | 'quantity'>): number {
  const procedure = getProcedure(point.procedureId);
  if (!procedure) return point.quantity;
  const suaveDose = suggestedDoseForLevel(procedure, 'suave');
  return Math.min(point.quantity, suaveDose);
}

/**
 * O conjunto de pontos do Plano B: os mesmos pontos do Plano A, com a
 * quantidade de cada um recalculada por `planBQuantity`. Preserva todo o
 * resto do ponto (região, substância, insumo escolhido etc.) — só a dose
 * muda, o que é suficiente para `computeBudget` (src/lib/budget.ts) recalcular
 * o orçamento reduzido a partir do mesmo insumo/preço unitário.
 */
export function reduceToPlanB(points: ApplicationPoint[]): ApplicationPoint[] {
  return points.map((point) => ({ ...point, quantity: planBQuantity(point) }));
}

/**
 * Verdadeiro só quando o Plano B calculado é de fato mais enxuto que o Plano
 * A em pelo menos um ponto. Usado para decidir se vale a pena desenhar dois
 * cartões de orçamento no PDF — evita mostrar "Plano A" e "Plano B"
 * idênticos quando nenhum ponto do plano tem procedimento nomeado vinculado
 * (ou todos já estão na dose mínima sugerida da faixa "Suave").
 */
export function hasReducedPlanB(points: ApplicationPoint[]): boolean {
  return points.some((point) => planBQuantity(point) < point.quantity);
}

/** Todo procedimento do catálogo referencia pelo menos uma região válida de
 * FACE_REGION_KEYS — validado em runtime (não só em teste) porque o
 * catálogo é dado estático editado à mão, propenso a erro de digitação num
 * slug de região ao crescer a lista. */
export function isWellFormedCatalog(catalog: NamedProcedure[] = PROCEDURE_CATALOG): boolean {
  const knownRegions = new Set<string>(FACE_REGION_KEYS);
  return catalog.every(
    (p) => p.regions.length > 0 && p.regions.every((r) => knownRegions.has(r)),
  );
}
