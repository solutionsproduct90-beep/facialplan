import { describe, it, expect } from 'vitest';
import {
  computePatientAbandonmentRisk,
  classifyPatientAbandonmentDelay,
  classifyPatientAbandonmentFeedback,
  patientAbandonmentRiskRank,
} from './patientAbandonmentRisk';
import type { ReturnRadar } from './returnRadar';

const NOW = new Date('2026-09-11T12:00:00Z');

function monthsAgo(months: number): Date {
  const d = new Date(NOW.getTime());
  d.setMonth(d.getMonth() - months);
  return d;
}

/** Constrói um ReturnRadar sintético cuja janela (windowStart..windowEnd)
 * termina `monthsOverdue` meses atrás de NOW, com a janela durando
 * `windowLengthMonths` meses — o suficiente para exercitar
 * classifyPatientAbandonmentDelay sem depender de computeReturnRadar. */
function radarOverdueBy(monthsOverdue: number, windowLengthMonths = 2): ReturnRadar {
  const windowEnd = monthsAgo(monthsOverdue);
  const windowStart = new Date(windowEnd.getTime());
  windowStart.setMonth(windowStart.getMonth() - windowLengthMonths);
  return {
    substance: 'toxina_botulinica',
    windowStart,
    windowEnd,
    isOverdue: monthsOverdue > 0,
  };
}

describe('classifyPatientAbandonmentDelay', () => {
  it('is "none" when there is no radar at all', () => {
    expect(classifyPatientAbandonmentDelay(null, NOW)).toBe('none');
    expect(classifyPatientAbandonmentDelay(undefined, NOW)).toBe('none');
  });

  it('is "none" when the radar is not overdue yet', () => {
    const radar = radarOverdueBy(-1); // windowEnd no futuro
    expect(classifyPatientAbandonmentDelay(radar, NOW)).toBe('none');
  });

  it('is "moderate" when overdue by less than the window length', () => {
    const radar = radarOverdueBy(1, 2); // 1 mês atrasado, janela de 2 meses
    expect(classifyPatientAbandonmentDelay(radar, NOW)).toBe('moderate');
  });

  it('is "severe" when overdue by 2x the window length or more', () => {
    const radar = radarOverdueBy(4, 2); // 4 meses atrasado, janela de 2 meses (exatamente 2x)
    expect(classifyPatientAbandonmentDelay(radar, NOW)).toBe('severe');

    const wayOverdue = radarOverdueBy(10, 2);
    expect(classifyPatientAbandonmentDelay(wayOverdue, NOW)).toBe('severe');
  });
});

describe('classifyPatientAbandonmentFeedback', () => {
  it('is "none" when there is no feedback yet', () => {
    expect(classifyPatientAbandonmentFeedback(null)).toBe('none');
    expect(classifyPatientAbandonmentFeedback(undefined)).toBe('none');
    expect(classifyPatientAbandonmentFeedback(NaN)).toBe('none');
  });

  it('is "detractor" for scores 0-6', () => {
    expect(classifyPatientAbandonmentFeedback(0)).toBe('detractor');
    expect(classifyPatientAbandonmentFeedback(6)).toBe('detractor');
  });

  it('is "passive" for scores 7-8', () => {
    expect(classifyPatientAbandonmentFeedback(7)).toBe('passive');
    expect(classifyPatientAbandonmentFeedback(8)).toBe('passive');
  });

  it('is "promoter" for scores 9-10', () => {
    expect(classifyPatientAbandonmentFeedback(9)).toBe('promoter');
    expect(classifyPatientAbandonmentFeedback(10)).toBe('promoter');
  });
});

describe('computePatientAbandonmentRisk', () => {
  it('is "baixo" with a sensible, non-NaN score when every signal is missing (new patient)', () => {
    const risk = computePatientAbandonmentRisk({ now: NOW });
    expect(risk.level).toBe('baixo');
    expect(Number.isNaN(risk.score)).toBe(false);
    expect(risk.score).toBeGreaterThanOrEqual(0);
    expect(risk.delay).toBe('none');
    expect(risk.feedback).toBe('none');
    expect(risk.noShowCount).toBe(0);
  });

  it('is "baixo" for moderate delay alone, with no other signal', () => {
    const risk = computePatientAbandonmentRisk({
      returnRadar: radarOverdueBy(1, 2),
      now: NOW,
    });
    expect(risk.level).toBe('baixo');
  });

  it('is "medio" for severe delay alone (no feedback, no no-show)', () => {
    const risk = computePatientAbandonmentRisk({
      returnRadar: radarOverdueBy(6, 2),
      now: NOW,
    });
    expect(risk.level).toBe('medio');
  });

  it('is "medio" for a detractor feedback alone, with no delay signal', () => {
    const risk = computePatientAbandonmentRisk({
      latestFeedbackNpsScore: 3,
      now: NOW,
    });
    expect(risk.level).toBe('medio');
  });

  it('is "baixo" for a single recent no-show alone', () => {
    const risk = computePatientAbandonmentRisk({
      recentNoShowCount: 1,
      now: NOW,
    });
    expect(risk.level).toBe('baixo');
  });

  it('is "alto" for severe delay + a detractor score + at least one no-show (the worst-case example)', () => {
    const risk = computePatientAbandonmentRisk({
      returnRadar: radarOverdueBy(6, 2),
      latestFeedbackNpsScore: 2,
      recentNoShowCount: 1,
      now: NOW,
    });
    expect(risk.level).toBe('alto');
  });

  it('is "alto" for severe delay + NO feedback at all + a no-show (absence counts like a low score here)', () => {
    const risk = computePatientAbandonmentRisk({
      returnRadar: radarOverdueBy(6, 2),
      latestFeedbackNpsScore: null,
      recentNoShowCount: 1,
      now: NOW,
    });
    expect(risk.level).toBe('alto');
  });

  it('tempers severe delay down to "medio" when the patient is actually a promoter', () => {
    const risk = computePatientAbandonmentRisk({
      returnRadar: radarOverdueBy(6, 2),
      latestFeedbackNpsScore: 10,
      now: NOW,
    });
    expect(risk.level).toBe('medio');
  });

  it('never produces NaN/undefined even with a garbage no-show count', () => {
    const risk = computePatientAbandonmentRisk({ recentNoShowCount: -5, now: NOW });
    expect(risk.noShowCount).toBe(0);
    expect(Number.isNaN(risk.score)).toBe(false);
  });

  it('caps the no-show weight so a large count does not overwhelm the other signals', () => {
    const risk = computePatientAbandonmentRisk({ recentNoShowCount: 50, now: NOW });
    const riskTwo = computePatientAbandonmentRisk({ recentNoShowCount: 2, now: NOW });
    expect(risk.score).toBe(riskTwo.score);
  });

  it('defaults `now` to the current time when omitted', () => {
    const risk = computePatientAbandonmentRisk({});
    expect(risk.level).toBe('baixo');
  });
});

describe('patientAbandonmentRiskRank', () => {
  it('orders alto > medio > baixo', () => {
    expect(patientAbandonmentRiskRank('alto')).toBeGreaterThan(patientAbandonmentRiskRank('medio'));
    expect(patientAbandonmentRiskRank('medio')).toBeGreaterThan(patientAbandonmentRiskRank('baixo'));
  });
});
