// Tabela de conversão landmark do MediaPipe → região clínica.
//
// Usada pela Etapa 2 para posicionar automaticamente, sobre a foto real do
// paciente, os pontos aceitos na Etapa 1 — a partir dos 478 pontos
// normalizados (x, y) devolvidos pelo FaceLandmarker (@mediapipe/tasks-vision,
// Face Mesh). Os índices abaixo são públicos e documentados pelo próprio
// MediaPipe (mapa de 468/478 pontos do "Face Landmark Model"); foram
// escolhidos por região anatômica e validados visualmente com o mapa oficial
// de landmarks, mas — como qualquer heurística baseada em poucos pontos por
// região — podem precisar de ajuste fino ao rodar contra fotos reais.
//
// IMPORTANTE: as chaves aqui precisam casar com os slugs de `region` que o
// prompt da edge function `analyze-face` pede à IA (ver ANALYSIS_PROMPT em
// supabase/functions/analyze-face/index.ts). Ao adicionar uma região nova,
// atualize os dois lugares.
export type FaceRegionKey =
  | 'labio_superior'
  | 'labio_inferior'
  | 'comissura_labial_esquerda'
  | 'comissura_labial_direita'
  | 'malar_esquerda'
  | 'malar_direita'
  | 'terco_frontal'
  | 'glabela'
  | 'mandibula_esquerda'
  | 'mandibula_direita'
  | 'mento'
  | 'dorso_nasal'
  | 'ponta_nasal'
  | 'sulco_nasolabial_esquerdo'
  | 'sulco_nasolabial_direito'
  // Adicionadas para dar suporte de taxonomia a um catálogo de procedimentos
  // mais amplo (ver achado do comitê: nossa lista cobria bem menos regiões
  // que concorrentes como a Full Face Academy) — nenhum procedimento nomeado
  // usa essas regiões ainda, isso fica para um squad futuro; o objetivo aqui
  // é só não deixar quem for adicioná-las tendo que re-mexer neste enum.
  | 'olheira_esquerda'
  | 'olheira_direita'
  | 'tempora_esquerda'
  | 'tempora_direita';

type RegionInfo = {
  label: string;
  /** Índices do Face Mesh (478 pontos); o primeiro é o principal, os demais servem de reserva. */
  landmarkIndices: number[];
  /** Posição normalizada (0–1) usada enquanto a detecção de landmarks não roda (ou falha). */
  fallback: { x: number; y: number };
  /**
   * Índices do Face Mesh que formam a ÁREA (não só um ponto) da região —
   * usado por `regionPolygonForRegion` abaixo para desenhar/calcular sobre a
   * região real, não um ponto fixo (ver relatório de investigação "scanner
   * real do rosto" que motivou este campo). Opcional e aditivo: uma região
   * sem `areaIndices` continua funcionando 100% como antes, via
   * `landmarkPositionForRegion` (ponto único). Duas formas de uso, ver
   * `HULL_REGIONS` logo abaixo:
   * (a) regiões COMPACTAS/blob (malar, glabela, comissura labial): a lista é
   *     um CLUSTER de índices vizinhos ao ponto de referência já curado
   *     acima — a ordem não importa, `regionPolygonForRegion` calcula o
   *     fecho convexo (`convexHull`) do cluster para achar o perímetro real;
   * (b) regiões ALONGADAS/curvas (hoje só lábio superior/inferior — sulco
   *     nasolabial e mandíbula ainda NÃO têm `areaIndices`, ver ressalva no
   *     fim do arquivo): a lista já É o contorno na ORDEM correta (seguindo
   *     a borda real da região), e aplicar fecho convexo destruiria a
   *     curvatura — por isso essas regiões ficam DE FORA de `HULL_REGIONS`.
   */
  areaIndices?: number[];
};

export const FACE_REGIONS: Record<FaceRegionKey, RegionInfo> = {
  // Contorno real do lábio (superior/inferior): borda externa (vermelhão) na
  // ordem esquerda→direita, seguida da borda interna direita→esquerda, para
  // fechar uma faixa fina ao redor do lábio — índices dos conjuntos oficiais
  // de lábio do próprio MediaPipe (mesmos usados por FACE_LANDMARKS_LIPS),
  // por isso mais confiáveis que uma curadoria manual do zero. Alongada por
  // natureza — NÃO entra em HULL_REGIONS.
  labio_superior: {
    label: 'Lábio Superior',
    landmarkIndices: [13, 0, 37, 267],
    fallback: { x: 0.50, y: 0.62 },
    areaIndices: [61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 308, 415, 310, 311, 312, 13, 82, 81, 80, 191, 78],
  },
  labio_inferior: {
    label: 'Lábio Inferior',
    landmarkIndices: [14, 17, 84, 314],
    fallback: { x: 0.50, y: 0.68 },
    areaIndices: [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 308, 324, 318, 402, 317, 14, 87, 178, 88, 95, 78],
  },
  // Comissura labial: pequeno cluster ao redor do canto da boca — compacto,
  // entra em HULL_REGIONS (a ordem dos índices abaixo não importa).
  comissura_labial_esquerda: {
    label: 'Comissura Labial Esquerda',
    landmarkIndices: [61],
    fallback: { x: 0.40, y: 0.65 },
    areaIndices: [61, 146, 185, 40],
  },
  comissura_labial_direita: {
    label: 'Comissura Labial Direita',
    landmarkIndices: [291],
    fallback: { x: 0.60, y: 0.65 },
    areaIndices: [291, 375, 409, 270],
  },
  // Malar: cluster compacto vizinho ao ponto de referência já curado (234/93
  // à esquerda, 454/323 à direita) — entra em HULL_REGIONS.
  malar_esquerda: {
    label: 'Região Malar Esquerda',
    landmarkIndices: [234, 93],
    fallback: { x: 0.25, y: 0.46 },
    areaIndices: [234, 93, 132, 58],
  },
  malar_direita: {
    label: 'Região Malar Direita',
    landmarkIndices: [454, 323],
    fallback: { x: 0.75, y: 0.46 },
    areaIndices: [454, 323, 361, 288],
  },
  terco_frontal: { label: 'Terço Frontal', landmarkIndices: [10, 108, 337], fallback: { x: 0.50, y: 0.20 } },
  // Glabela: pequeno cluster entre as sobrancelhas — compacto, entra em
  // HULL_REGIONS.
  glabela: {
    label: 'Glabela',
    landmarkIndices: [9, 8, 168],
    fallback: { x: 0.50, y: 0.34 },
    areaIndices: [8, 9, 55, 285, 168],
  },
  // PENDENTE (sem areaIndices): mandíbula é uma região alongada/curva (borda
  // da linha mandibular) — a mesma ressalva do comentário de `areaIndices`
  // acima sobre não usar fecho convexo cru para regiões alongadas se aplica
  // aqui, e curar manualmente o contorno real sem uma referência visual à
  // mão (ver comentário de arquivo) arriscaria um formato incorreto para uma
  // técnica (toxina no masseter) sensível a posição. Fica para revisão
  // futura com o mapa oficial de landmarks em mãos.
  mandibula_esquerda: { label: 'Ângulo Mandibular Esquerdo', landmarkIndices: [172, 136], fallback: { x: 0.22, y: 0.72 } },
  mandibula_direita: { label: 'Ângulo Mandibular Direito', landmarkIndices: [397, 365], fallback: { x: 0.78, y: 0.72 } },
  mento: { label: 'Mento', landmarkIndices: [152, 175], fallback: { x: 0.50, y: 0.85 } },
  // PENDENTE (sem areaIndices): dorso nasal é uma faixa estreita e alongada
  // ao longo da ponte do nariz — zona de risco vascular (ver
  // HIGH_VASCULAR_RISK_REGIONS abaixo), o que torna especialmente importante
  // NÃO desenhar uma área aproximada/errada aqui sem validação visual contra
  // o mapa oficial. Preferimos deixar pendente (ponto único, como hoje) a
  // arriscar um polígono clinicamente enganoso numa zona de risco.
  dorso_nasal: { label: 'Dorso Nasal', landmarkIndices: [6, 197], fallback: { x: 0.50, y: 0.42 } },
  ponta_nasal: { label: 'Ponta Nasal', landmarkIndices: [1, 4], fallback: { x: 0.50, y: 0.50 } },
  // PENDENTE (sem areaIndices): sulco nasolabial é uma curva alongada (da
  // asa do nariz ao canto da boca) e também zona de risco vascular — mesma
  // decisão de não arriscar um polígono sem validação visual explicada no
  // comentário de dorso_nasal acima.
  sulco_nasolabial_esquerdo: { label: 'Sulco Nasolabial Esquerdo', landmarkIndices: [206, 187], fallback: { x: 0.38, y: 0.58 } },
  sulco_nasolabial_direito: { label: 'Sulco Nasolabial Direito', landmarkIndices: [426, 411], fallback: { x: 0.62, y: 0.58 } },
  // Índices/fallbacks abaixo ainda não passaram pela mesma validação visual
  // contra o mapa oficial de landmarks que as regiões acima já tiveram —
  // mesma ressalva do cabeçalho do arquivo, reforçada aqui por serem as mais
  // recentes.
  olheira_esquerda: { label: 'Olheira Esquerda (Sulco Lacrimal)', landmarkIndices: [230, 145], fallback: { x: 0.38, y: 0.48 } },
  olheira_direita: { label: 'Olheira Direita (Sulco Lacrimal)', landmarkIndices: [450, 374], fallback: { x: 0.62, y: 0.48 } },
  tempora_esquerda: { label: 'Têmpora Esquerda', landmarkIndices: [127, 34], fallback: { x: 0.15, y: 0.32 } },
  tempora_direita: { label: 'Têmpora Direita', landmarkIndices: [356, 264], fallback: { x: 0.85, y: 0.32 } },
};

export const FACE_REGION_KEYS = Object.keys(FACE_REGIONS) as FaceRegionKey[];

// Zonas classicamente associadas, na literatura de harmonização facial, a
// maior risco de comprometimento vascular (oclusão/necrose) ao injetar
// preenchedor — por proximidade a ramos arteriais superficiais relevantes:
// artéria supratroclear/supraorbital (glabela), artéria nasal dorsal (dorso
// nasal), artéria angular (sulco nasolabial) e artérias labiais (comissura
// labial). A lista é deliberadamente curta — preferimos poucas zonas de
// consenso básico a uma lista pseudocientífica extensa.
//
// ⚠️ PONTO DE PARTIDA, NÃO VALIDADO CLINICAMENTE: esta lista (e o texto do
// alerta que a acompanha, em `sessions.stage2.vascularRisk.alert` nos
// arquivos de i18n) foi definida por este squad de engenharia a partir de
// consenso básico divulgado na literatura de estética, apenas para acionar
// um alerta EDUCATIVO na UI (não bloqueante — o profissional decide se
// prossegue). Ela NÃO substitui avaliação anatômica individual nem
// protocolo clínico, e PRECISA ser revisada e validada por um profissional
// médico habilitado antes de qualquer uso em produção real — mesmo padrão
// de ressalva já usado para as flags de segurança da anamnese (ver
// `src/types/anamnesis.ts`).
export const HIGH_VASCULAR_RISK_REGIONS: ReadonlySet<FaceRegionKey> = new Set<FaceRegionKey>([
  'glabela',
  'dorso_nasal',
  'sulco_nasolabial_esquerdo',
  'sulco_nasolabial_direito',
  'comissura_labial_esquerda',
  'comissura_labial_direita',
]);

/**
 * True se `region` é uma das zonas de risco vascular elevado acima. Aceita
 * qualquer string (ex.: `ApplicationPoint.region`, que pode vir de dados
 * antigos ou de uma IA) e devolve false para região desconhecida.
 */
export function isHighVascularRiskRegion(region: string): boolean {
  return HIGH_VASCULAR_RISK_REGIONS.has(region as FaceRegionKey);
}

/**
 * True quando um ponto de aplicação concreto (`region` + `substance`) foi de fato
 * marcado como zona de risco vascular: ácido hialurônico numa das
 * HIGH_VASCULAR_RISK_REGIONS acima — toxina botulínica e bioestimulador não têm o
 * mesmo risco de oclusão vascular imediata por injeção (ver alerta educativo em
 * SessaoEstagio2.tsx, de onde esta regra foi extraída para ser a única fonte da
 * combinação região+substância). Reaproveitada também pelo aviso de sinais de
 * emergência do checklist de pós-procedimento (`src/lib/postProcedureChecklist.ts`)
 * — nunca recalcule esta combinação em outro lugar do app (a edge function
 * send-patient-email, que não importa de src/, duplica a MESMA lista de regiões e o
 * mesmo critério por necessidade de runtime, não por escolha).
 */
export function isVascularRiskApplication(region: string, substance: string): boolean {
  return substance === 'acido_hialuronico' && isHighVascularRiskRegion(region);
}

export function regionLabel(region: string): string {
  return FACE_REGIONS[region as FaceRegionKey]?.label ?? region;
}

export function regionFallbackPosition(region: string): { x: number; y: number } {
  return FACE_REGIONS[region as FaceRegionKey]?.fallback ?? { x: 0.5, y: 0.5 };
}

/**
 * Dado o resultado do FaceLandmarker (478 pontos normalizados x,y do
 * MediaPipe) e uma região clínica, devolve a posição a usar e o índice de
 * landmark efetivamente encontrado (o primeiro da lista que a detecção
 * retornou). Devolve null se a região é desconhecida ou não há detecção.
 */
export function landmarkPositionForRegion(
  region: string,
  landmarks: { x: number; y: number }[] | undefined
): { x: number; y: number; landmarkIndex: number } | null {
  const info = FACE_REGIONS[region as FaceRegionKey];
  if (!info || !landmarks || landmarks.length === 0) return null;
  for (const idx of info.landmarkIndices) {
    const pt = landmarks[idx];
    if (pt) return { x: pt.x, y: pt.y, landmarkIndex: idx };
  }
  return null;
}

// Regiões compactas ("blob") cujo `areaIndices` é um CLUSTER de vizinhos ao
// ponto de referência, não um contorno já ordenado — para essas,
// `regionPolygonForRegion` calcula o fecho convexo do cluster para achar o
// perímetro real (mais robusto a variação de proporção entre rostos do que
// assumir uma ordem fixa). Regiões alongadas/curvas com `areaIndices` (hoje
// só lábio superior/inferior) ficam DE FORA deste conjunto: a lista já é o
// contorno na ordem correta, e aplicar fecho convexo destruiria a curvatura
// real — ver comentário de `areaIndices` em RegionInfo acima.
const HULL_REGIONS: ReadonlySet<FaceRegionKey> = new Set<FaceRegionKey>([
  'glabela',
  'malar_esquerda',
  'malar_direita',
  'comissura_labial_esquerda',
  'comissura_labial_direita',
]);

/**
 * Fecho convexo (algoritmo de Andrew/monotone chain) de um conjunto de
 * pontos 2D — implementado localmente em vez de trazer uma lib nova (fora do
 * escopo desta tarefa) só para isto. Usado por `regionPolygonForRegion` para
 * transformar um CLUSTER de landmarks vizinhos (sem ordem definida) no
 * polígono do perímetro real de uma região compacta. Devolve os pontos em
 * ordem anti-horária; com 2 pontos ou menos, devolve a entrada sem alteração
 * (não há área a fechar).
 */
function convexHull(points: { x: number; y: number }[]): { x: number; y: number }[] {
  if (points.length <= 2) return points;
  const sorted = [...points].sort((a, b) => (a.x === b.x ? a.y - b.y : a.x - b.x));
  const cross = (o: { x: number; y: number }, a: { x: number; y: number }, b: { x: number; y: number }) =>
    (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);

  const lower: { x: number; y: number }[] = [];
  for (const p of sorted) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper: { x: number; y: number }[] = [];
  for (let i = sorted.length - 1; i >= 0; i--) {
    const p = sorted[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
    upper.push(p);
  }
  lower.pop();
  upper.pop();
  return lower.concat(upper);
}

/**
 * Dado o resultado do FaceLandmarker e uma região clínica, devolve o
 * POLÍGONO real da região (não só um ponto) a partir de `areaIndices` — base
 * do efeito "scanner real do rosto" (malha/área em vez de pontos soltos) e
 * das linhas de técnica geradas por `buildTechniqueLine`
 * (src/lib/faceGeometry.ts). Devolve null quando a região não tem
 * `areaIndices` curado ainda (ver comentários "PENDENTE" acima — a região
 * continua funcionando normalmente via `landmarkPositionForRegion`, só sem
 * área desenhada) ou quando a detecção não cobre todos os índices
 * necessários (foto de ângulo ruim, região parcialmente fora do enquadramento
 * etc. — degrada para null em vez de um polígono incompleto/distorcido).
 */
export function regionPolygonForRegion(
  region: string,
  landmarks: { x: number; y: number }[] | undefined
): { x: number; y: number }[] | null {
  const info = FACE_REGIONS[region as FaceRegionKey];
  if (!info?.areaIndices || !landmarks || landmarks.length === 0) return null;

  const points: { x: number; y: number }[] = [];
  for (const idx of info.areaIndices) {
    const pt = landmarks[idx];
    if (!pt) return null;
    points.push({ x: pt.x, y: pt.y });
  }
  if (points.length < 3) return null;

  return HULL_REGIONS.has(region as FaceRegionKey) ? convexHull(points) : points;
}
