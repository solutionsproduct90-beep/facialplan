// Locale das páginas públicas institucionais/blog via prefixo de URL —
// separado do idioma do app autenticado (que é 100% client-side, via
// `i18next-browser-languagedetector`, e não tem por quê aparecer na URL:
// não existe crawler indexando o dashboard). Aqui, o idioma PRECISA estar
// na URL — é a única forma de um crawler (Google, bots de IA) saber com
// certeza em que língua aquela página existe, requisito básico pra
// `hreflang` funcionar (ver src/entry-server.tsx).
//
// pt é a língua-fonte e fica SEM prefixo (mantém as URLs já publicadas
// intactas: /blog, /blog/:slug, /recursos...). Cada locale adicional
// ganha um prefixo (/es/blog, /en/blog, /es/blog/:slug...). "es" (LATAM,
// prioridade máxima) e "en" (alcance global) hoje têm as páginas
// institucionais completas; posts de blog em inglês ainda não existem —
// getAllBlogPosts('en') volta lista vazia até serem traduzidos (sem
// fallback silencioso pra pt). fr/it entram aqui quando tiverem conteúdo.
export const PREFIXED_LOCALES = ['es', 'en'] as const;
export type PrefixedLocale = (typeof PREFIXED_LOCALES)[number];
export type SiteLocale = 'pt' | PrefixedLocale;

export function isPrefixedLocale(value: string | undefined): value is PrefixedLocale {
  return !!value && (PREFIXED_LOCALES as readonly string[]).includes(value);
}

/** Separa o prefixo de idioma de uma URL pública — "/es/blog" -> { locale: 'es', rest: '/blog' }. */
export function splitLocaleFromPath(pathname: string): { locale: SiteLocale; rest: string } {
  for (const locale of PREFIXED_LOCALES) {
    if (pathname === `/${locale}`) return { locale, rest: '/' };
    if (pathname.startsWith(`/${locale}/`)) return { locale, rest: pathname.slice(locale.length + 1) };
  }
  return { locale: 'pt', rest: pathname };
}

/** Monta o path localizado equivalente — localizedPath('/recursos', 'es') -> '/es/recursos'. */
export function localizedPath(path: string, locale: SiteLocale): string {
  if (locale === 'pt') return path;
  return path === '/' ? `/${locale}` : `/${locale}${path}`;
}
