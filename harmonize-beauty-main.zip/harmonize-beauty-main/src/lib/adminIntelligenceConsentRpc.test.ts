import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Verificação estática (mesmo padrão de manualPointJustificationRpc.test.ts —
// não há infraestrutura de teste com Postgres real neste repositório) de que
// a migration que fecha a lacuna de consentimento de IA (P7-4) realmente
// adiciona o filtro `patients.ai_improvement_consent = true` às três RPCs da
// Central de Inteligência, ANTES do GROUP BY/HAVING de cada uma — e que ela
// não relaxa nenhuma das garantias de anonimização já existentes (agregação
// em SQL, corte de amostra mínima, checagem de admin).
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260911140000_filter_admin_intelligence_rpcs_by_ai_consent.sql',
);
const sql = readFileSync(migrationPath, 'utf8');

/** Extrai o corpo de UMA função pelo nome, do "AS $$" até o "$$;" de fechamento seguinte. */
function extractFunctionBody(functionName: string): string {
  const re = new RegExp(
    `CREATE (?:OR REPLACE )?FUNCTION public\\.${functionName}\\([^)]*\\)[\\s\\S]*?AS \\$\\$([\\s\\S]*?)\\$\\$;`,
  );
  const match = sql.match(re);
  if (!match) throw new Error(`não achou a função ${functionName} na migration — regex precisa ser ajustado`);
  return match[1];
}

describe('migration 20260911140000 — filtro de consentimento de IA nas 3 RPCs da Central de Inteligência', () => {
  describe('admin_dose_accuracy_correlation', () => {
    const body = extractFunctionBody('admin_dose_accuracy_correlation');

    it('junta patients e exige ai_improvement_consent = true dentro do CTE de pontos, antes do GROUP BY', () => {
      expect(body).toMatch(/JOIN public\.patients p ON p\.id = s\.patient_id AND p\.ai_improvement_consent = true/);
      const joinIndex = body.indexOf('JOIN public.patients');
      const groupByIndex = body.lastIndexOf('GROUP BY');
      expect(joinIndex).toBeGreaterThan(-1);
      expect(groupByIndex).toBeGreaterThan(joinIndex);
    });

    it('continua exigindo has_role admin e o corte de amostra mínima (>= 5)', () => {
      expect(body).toContain("has_role(auth.uid(), 'admin')");
      expect(body).toMatch(/HAVING count\(\*\) >= 5/);
    });

    it('não seleciona nenhuma coluna de identidade (patient_id/professional_id/session_id) no retorno agregado', () => {
      const finalSelectMatch = body.match(/SELECT\s+b\.substance,[\s\S]*?HAVING count\(\*\) >= 5;/);
      expect(finalSelectMatch).not.toBeNull();
      for (const forbidden of ['patient_id', 'professional_id', 'session_id']) {
        expect(finalSelectMatch![0]).not.toContain(forbidden);
      }
    });
  });

  describe('admin_adverse_event_patterns', () => {
    const body = extractFunctionBody('admin_adverse_event_patterns');

    it('junta patients pelo patient_id (nulável) e exige ai_improvement_consent = true, excluindo por construção eventos sem paciente vinculado', () => {
      expect(body).toMatch(/JOIN public\.patients p ON p\.id = ae\.patient_id AND p\.ai_improvement_consent = true/);
      const joinIndex = body.indexOf('JOIN public.patients');
      const groupByIndex = body.lastIndexOf('GROUP BY');
      expect(joinIndex).toBeGreaterThan(-1);
      expect(groupByIndex).toBeGreaterThan(joinIndex);
    });

    it('continua exigindo has_role admin e o corte de amostra mínima (>= 5)', () => {
      expect(body).toContain("has_role(auth.uid(), 'admin')");
      expect(body).toMatch(/HAVING count\(\*\) >= 5/);
    });

    it('nunca seleciona patient_id/professional_id/session_id/description no SELECT', () => {
      const selectMatch = body.match(/SELECT i\.substance[\s\S]*?FROM/);
      expect(selectMatch).not.toBeNull();
      for (const forbidden of ['patient_id', 'professional_id', 'session_id', 'description']) {
        expect(selectMatch![0]).not.toContain(forbidden);
      }
    });
  });

  describe('admin_anamnesis_flag_frequency', () => {
    const body = extractFunctionBody('admin_anamnesis_flag_frequency');

    it('junta patients pelo patient_id (obrigatório em anamnesis) e exige ai_improvement_consent = true', () => {
      expect(body).toMatch(/JOIN public\.patients p ON p\.id = a\.patient_id AND p\.ai_improvement_consent = true/);
      const joinIndex = body.indexOf('JOIN public.patients');
      const groupByIndex = body.lastIndexOf('GROUP BY');
      expect(joinIndex).toBeGreaterThan(-1);
      expect(groupByIndex).toBeGreaterThan(joinIndex);
    });

    it('continua exigindo has_role admin e o corte de amostra mínima (>= 5)', () => {
      expect(body).toContain("has_role(auth.uid(), 'admin')");
      expect(body).toMatch(/HAVING count\(\*\) >= 5/);
    });

    it('nunca seleciona patient_id/professional_id no SELECT', () => {
      const selectMatch = body.match(/SELECT k\.flag_key[\s\S]*?FROM/);
      expect(selectMatch).not.toBeNull();
      for (const forbidden of ['patient_id', 'professional_id']) {
        expect(selectMatch![0]).not.toContain(forbidden);
      }
    });
  });

  it('as três funções usam CREATE OR REPLACE FUNCTION com a MESMA assinatura de antes, preservando os GRANTs de EXECUTE para "authenticated" já concedidos em 20260911070000/20260911090000 sem precisar reemiti-los', () => {
    expect(sql).toMatch(/CREATE OR REPLACE FUNCTION public\.admin_dose_accuracy_correlation\(\)/);
    expect(sql).toMatch(/CREATE OR REPLACE FUNCTION public\.admin_adverse_event_patterns\(\)/);
    expect(sql).toMatch(/CREATE OR REPLACE FUNCTION public\.admin_anamnesis_flag_frequency\(\)/);
    // Nenhum DROP FUNCTION nesta migration — RETURNS TABLE de nenhuma das
    // três mudou de forma, então CREATE OR REPLACE (que preserva privilégios
    // já concedidos) é suficiente, ao contrário de 20260911090000 que
    // precisou de DROP + CREATE para admin_dose_accuracy_correlation.
    expect(sql).not.toContain('DROP FUNCTION');
  });
});
