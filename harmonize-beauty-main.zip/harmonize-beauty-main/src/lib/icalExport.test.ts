import { describe, it, expect } from 'vitest';
import { buildAppointmentIcs, type IcalAppointmentInput } from './icalExport';

// Mesmo estilo de stub usado em postProcedureChecklist.test.ts: interpola
// manualmente as duas chaves usadas por este módulo em vez de exigir
// i18next carregado no ambiente de teste.
const fakeTranslate = (key: string, options?: Record<string, unknown>): unknown => {
  if (key === 'agenda.ical.summaryWithPatient') return `Consulta - ${options?.name}`;
  if (key === 'agenda.ical.summaryNoPatient') return 'Consulta agendada';
  return key;
};

const NOW = new Date(Date.UTC(2026, 8, 10, 12, 0, 0));

const APPT: IcalAppointmentInput = {
  id: 'appt-1',
  patientName: 'Maria Silva',
  note: 'Retorno de avaliação',
  scheduledAt: new Date(Date.UTC(2026, 8, 15, 14, 0, 0)).toISOString(),
  durationMinutes: 45,
};

describe('buildAppointmentIcs', () => {
  it('produces a well-formed VCALENDAR/VEVENT with all RFC 5545 required fields', () => {
    const ics = buildAppointmentIcs(APPT, fakeTranslate, NOW);
    expect(ics).toContain('BEGIN:VCALENDAR');
    expect(ics).toContain('VERSION:2.0');
    expect(ics).toContain('BEGIN:VEVENT');
    expect(ics).toContain('DTSTART:20260915T140000Z');
    expect(ics).toContain('DTEND:20260915T144500Z'); // +45min, respeitando duration_minutes
    expect(ics).toContain('SUMMARY:Consulta - Maria Silva');
    expect(ics).toContain('END:VEVENT');
    expect(ics).toContain('END:VCALENDAR');
  });

  it('uses CRLF as the line separator, as required by RFC 5545', () => {
    const ics = buildAppointmentIcs(APPT, fakeTranslate, NOW);
    expect(ics).toContain('\r\n');
    expect(ics.split('\r\n').filter((l) => l.length > 0).length).toBeGreaterThan(5);
  });

  it('includes a stable UID derived from the appointment id (reimport updates, does not duplicate)', () => {
    const ics = buildAppointmentIcs(APPT, fakeTranslate, NOW);
    expect(ics).toMatch(/UID:appointment-appt-1@harmonizebeauty\.app/);
  });

  it('includes DTSTAMP with the generation instant', () => {
    const ics = buildAppointmentIcs(APPT, fakeTranslate, NOW);
    expect(ics).toContain('DTSTAMP:20260910T120000Z');
  });

  it('falls back to the default 30-minute duration when duration_minutes is missing', () => {
    const ics = buildAppointmentIcs({ ...APPT, durationMinutes: null }, fakeTranslate, NOW);
    expect(ics).toContain('DTSTART:20260915T140000Z');
    expect(ics).toContain('DTEND:20260915T143000Z');
  });

  it('falls back to the default duration for a non-positive duration_minutes', () => {
    const ics = buildAppointmentIcs({ ...APPT, durationMinutes: 0 }, fakeTranslate, NOW);
    expect(ics).toContain('DTEND:20260915T143000Z');
  });

  it('uses the "no patient" summary when patientName is null ("retorno a definir")', () => {
    const ics = buildAppointmentIcs({ ...APPT, patientName: null }, fakeTranslate, NOW);
    expect(ics).toContain('SUMMARY:Consulta agendada');
  });

  it('includes DESCRIPTION only when there is a note', () => {
    const withNote = buildAppointmentIcs(APPT, fakeTranslate, NOW);
    expect(withNote).toContain('DESCRIPTION:Retorno de avaliação');

    const withoutNote = buildAppointmentIcs({ ...APPT, note: null }, fakeTranslate, NOW);
    expect(withoutNote).not.toContain('DESCRIPTION:');
  });

  it('escapes commas, semicolons and newlines in free text per RFC 5545 §3.3.11', () => {
    const ics = buildAppointmentIcs(
      { ...APPT, note: 'Linha 1\nRetorno; avaliação, controle' },
      fakeTranslate,
      NOW,
    );
    expect(ics).toContain('DESCRIPTION:Linha 1\\nRetorno\\; avaliação\\, controle');
  });

  it('escapes a patient name containing a comma inside SUMMARY', () => {
    const ics = buildAppointmentIcs({ ...APPT, patientName: 'Silva, Maria' }, fakeTranslate, NOW);
    expect(ics).toContain('SUMMARY:Consulta - Silva\\, Maria');
  });
});
