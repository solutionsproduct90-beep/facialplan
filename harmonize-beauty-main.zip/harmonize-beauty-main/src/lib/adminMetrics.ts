import type { ApplicationPoint } from '@/types/harmonize';
import { computeBudget, normalizeInsumos, isCurrencyCode, type CurrencyCode } from './budget';

// Funções puras usadas por /admin/metricas (visão agregada do operador do
// SaaS sobre TODOS os profissionais) — distinto de /painel (src/lib/panel.ts),
// que é o profissional olhando só pra si mesmo. Separadas do componente pelo
// mesmo motivo de budget.ts/panel.ts/agenda.ts: testáveis sem montar a tela
// nem tocar Supabase.
//
// Definição de "procedimento fechado" usada aqui: sessions.status === 'complete'
// — o mesmo valor gravado por handleComplete() em SessaoEstagio3.tsx quando o
// profissional clica em concluir o procedimento (toast
// 'sessions.stage3.sessionCompleted', depois navega pra tela de apresentação).
// Não existe um status "vendido"/"pago" separado no schema hoje (sessions só
// tem stage1/stage2/stage3/complete, ver 20260408052259_...sql) — 'complete'
// é o estágio mais próximo de "o profissional fechou esse atendimento", por
// isso vira o numerador da conversão sessão → procedimento fechado.
const CLOSED_SESSION_STATUS = 'complete';

/** Sessão reduzida ao mínimo que as métricas do admin precisam ler (de `sessions`, sem RLS por profissional — o admin lê todo mundo). */
export type SessionForAdminMetrics = {
  professional_id: string | null;
  patient_id: string | null;
  status: string | null;
  created_at: string | null;
  stage2_overlay: unknown;
};

/** Linha crua de `insumos` (join implícito por professional_id — a tabela não tem coluna própria de moeda). */
export type InsumoRowForAdminMetrics = {
  professional_id: string | null;
  [key: string]: unknown;
};

/** Fatia de `profiles` que as métricas por profissional precisam. */
export type ProfessionalProfileForMetrics = {
  id: string;
  full_name: string | null;
  clinic_name: string | null;
  currency: string | null;
  labor_fee_per_session: number | null;
};

export type ProfessionalMetrics = {
  professionalId: string;
  fullName: string | null;
  clinicName: string | null;
  currency: CurrencyCode;
  sessionsCount: number;
  closedCount: number;
  /** 0 a 1 — sessionsCount 0 retorna 0, nunca NaN. */
  conversionPct: number;
  /** Soma do orçamento (mesmo cálculo do PDF/painel, computeBudget) de cada sessão com pontos lançados — estimado, não é receita realmente recebida. */
  estimatedRevenue: number;
  uniquePatientsCount: number;
  /** Pacientes com mais de uma sessão registrada com este profissional. */
  returningPatientsCount: number;
  /** 0 a 1 — uniquePatientsCount 0 retorna 0, nunca NaN. */
  returnRatePct: number;
};

/**
 * Agrega `sessions` + `insumos` (ambos lidos sem filtro de profissional pelas
 * policies de admin) por `professional_id`, e cruza com os `profiles` da
 * lista (que define quem aparece no relatório — normalmente só role !=
 * 'admin', filtrado por quem chama). Um profissional sem nenhuma sessão
 * ainda aparece na lista, com todos os números zerados.
 */
export function computeProfessionalMetrics(
  sessions: SessionForAdminMetrics[],
  rawInsumos: InsumoRowForAdminMetrics[],
  profiles: ProfessionalProfileForMetrics[],
): ProfessionalMetrics[] {
  const insumoRowsByPro = new Map<string, InsumoRowForAdminMetrics[]>();
  for (const row of rawInsumos) {
    const pid = row?.professional_id;
    if (typeof pid !== 'string' || !pid) continue;
    if (!insumoRowsByPro.has(pid)) insumoRowsByPro.set(pid, []);
    insumoRowsByPro.get(pid)!.push(row);
  }

  const sessionsByPro = new Map<string, SessionForAdminMetrics[]>();
  for (const s of sessions) {
    if (typeof s.professional_id !== 'string' || !s.professional_id) continue;
    if (!sessionsByPro.has(s.professional_id)) sessionsByPro.set(s.professional_id, []);
    sessionsByPro.get(s.professional_id)!.push(s);
  }

  return profiles.map((profile): ProfessionalMetrics => {
    const proSessions = sessionsByPro.get(profile.id) ?? [];
    const sessionsCount = proSessions.length;
    const closedCount = proSessions.filter((s) => s.status === CLOSED_SESSION_STATUS).length;
    const conversionPct = sessionsCount > 0 ? closedCount / sessionsCount : 0;

    const insumos = normalizeInsumos(insumoRowsByPro.get(profile.id) ?? []);
    let estimatedRevenue = 0;
    for (const s of proSessions) {
      const points = Array.isArray(s.stage2_overlay) ? (s.stage2_overlay as ApplicationPoint[]) : [];
      if (points.length === 0) continue;
      estimatedRevenue += computeBudget(points, insumos, profile.labor_fee_per_session).totalPrice;
    }

    const sessionCountByPatient = new Map<string, number>();
    for (const s of proSessions) {
      if (typeof s.patient_id !== 'string' || !s.patient_id) continue;
      sessionCountByPatient.set(s.patient_id, (sessionCountByPatient.get(s.patient_id) ?? 0) + 1);
    }
    const uniquePatientsCount = sessionCountByPatient.size;
    let returningPatientsCount = 0;
    for (const count of sessionCountByPatient.values()) {
      if (count > 1) returningPatientsCount += 1;
    }
    const returnRatePct = uniquePatientsCount > 0 ? returningPatientsCount / uniquePatientsCount : 0;

    return {
      professionalId: profile.id,
      fullName: profile.full_name,
      clinicName: profile.clinic_name,
      currency: isCurrencyCode(profile.currency) ? profile.currency : 'BRL',
      sessionsCount,
      closedCount,
      conversionPct,
      estimatedRevenue,
      uniquePatientsCount,
      returningPatientsCount,
      returnRatePct,
    };
  });
}

/**
 * Filtro de busca por profissional/clínica: não existe uma entidade de
 * "clínica" separada no schema (cada profissional é uma conta independente,
 * com um `clinic_name` de texto livre opcional em `profiles`) — por isso o
 * filtro é uma busca textual sobre nome do profissional OU nome da clínica,
 * em vez de um select de uma dimensão que não existe hoje.
 */
export function filterMetricsBySearch(metrics: ProfessionalMetrics[], query: string): ProfessionalMetrics[] {
  const q = query.trim().toLowerCase();
  if (!q) return metrics;
  return metrics.filter(
    (m) => (m.fullName ?? '').toLowerCase().includes(q) || (m.clinicName ?? '').toLowerCase().includes(q),
  );
}

export type MetricsSummary = {
  totalSessions: number;
  totalClosed: number;
  overallConversionPct: number;
  totalUniquePatients: number;
  totalReturning: number;
  overallReturnRatePct: number;
  /** Soma de estimatedRevenue só quando todo mundo no recorte usa a mesma moeda — somar moedas diferentes daria um número sem sentido. */
  totalRevenue: number | null;
  /** Moeda comum do recorte, ou null quando está vazio ou misto (ver totalRevenue). */
  currency: CurrencyCode | null;
};

/** Resumo agregado de um recorte de `ProfessionalMetrics` (já filtrado pela busca, se houver). */
export function summarizeProfessionalMetrics(metrics: ProfessionalMetrics[]): MetricsSummary {
  const totalSessions = metrics.reduce((acc, m) => acc + m.sessionsCount, 0);
  const totalClosed = metrics.reduce((acc, m) => acc + m.closedCount, 0);
  const totalUniquePatients = metrics.reduce((acc, m) => acc + m.uniquePatientsCount, 0);
  const totalReturning = metrics.reduce((acc, m) => acc + m.returningPatientsCount, 0);

  const distinctCurrencies = new Set(metrics.map((m) => m.currency));
  const currency = distinctCurrencies.size === 1 ? [...distinctCurrencies][0] : null;
  const totalRevenue = currency ? metrics.reduce((acc, m) => acc + m.estimatedRevenue, 0) : null;

  return {
    totalSessions,
    totalClosed,
    overallConversionPct: totalSessions > 0 ? totalClosed / totalSessions : 0,
    totalUniquePatients,
    totalReturning,
    overallReturnRatePct: totalUniquePatients > 0 ? totalReturning / totalUniquePatients : 0,
    totalRevenue,
    currency,
  };
}

export type ProfessionalChartDatum = { name: string; sessions: number };

/**
 * Dados prontos pro gráfico de barras (sessões criadas por profissional) —
 * ordenado por sessionsCount desc e limitado a `limit` barras (padrão 8) pra
 * não estourar a largura do gráfico com muitos profissionais; o resto
 * continua visível na tabela abaixo. Métrica escolhida pro gráfico (em vez
 * de receita) por ser neutra a moeda — soma direta entre profissionais com
 * moedas diferentes.
 */
export function buildSessionsChartData(metrics: ProfessionalMetrics[], limit = 8): ProfessionalChartDatum[] {
  return [...metrics]
    .sort((a, b) => b.sessionsCount - a.sessionsCount)
    .slice(0, limit)
    .map((m) => ({ name: m.fullName || m.clinicName || '—', sessions: m.sessionsCount }));
}
