// Mesmo endpoint serverless usado por src/i18n/index.ts pra detectar o
// idioma por geolocalização (ver api/geo.ts) — aqui reaproveitado pra
// pré-selecionar o DDI no campo de telefone do paciente. Fica num módulo
// próprio (em vez de importar de i18n/index.ts) porque aquele arquivo roda
// a detecção de idioma como efeito colateral do import, e não expõe a
// busca do país como uma função reutilizável.
export async function detectVisitorCountry(): Promise<string | null> {
  try {
    const res = await fetch('/api/geo');
    if (!res.ok) return null;
    const data: { country?: string | null } = await res.json();
    return data?.country ?? null;
  } catch {
    // Sem geolocalização disponível (dev local, endpoint fora do ar) — quem
    // chamou cai de volta pro DDI padrão.
    return null;
  }
}
