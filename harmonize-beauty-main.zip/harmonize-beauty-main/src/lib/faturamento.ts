import type { ApplicationPoint, Insumo, Substance } from '@/types/harmonize';
import { SUBSTANCE_LABEL } from '@/types/harmonize';
import { computeBudget, costForPoint, priceForPoint } from './budget';
import { startOfMonth } from './panel';

// Funções puras usadas pela aba "Faturamento" do /painel
// (src/components/harmonize/panel/FaturamentoTab.tsx) — mesma separação de
// panel.ts/adminMetrics.ts: testáveis sem montar componente nem tocar
// Supabase. Diferente de panel.ts (potencial financeiro = TODA sessão do mês
// com pontos lançados, concluída ou não — ROI da assinatura é sobre o
// trabalho feito, não sobre o que já foi cobrado), esta aba mede faturamento
// no sentido mais estrito de "procedimento fechado": só sessões com
// `status === 'complete'`, a mesma convenção já usada em
// src/lib/adminMetrics.ts (repetida aqui, não importada de lá, pela mesma
// razão que panel.ts/adminMetrics.ts já não compartilham código — visão do
// profissional sobre si mesmo vs. visão do admin sobre todo mundo).
const CLOSED_SESSION_STATUS = 'complete';

/** Sessão reduzida ao mínimo que as métricas de faturamento precisam ler. */
export type SessionForBilling = {
  created_at: string | null;
  status: string | null;
  stage2_overlay: unknown;
};

function isClosed(s: SessionForBilling): boolean {
  return s.status === CLOSED_SESSION_STATUS;
}

function pointsOf(s: SessionForBilling): ApplicationPoint[] {
  return Array.isArray(s.stage2_overlay) ? (s.stage2_overlay as ApplicationPoint[]) : [];
}

/** true quando `s.created_at` cai no mês [start, start+1mês) — sessão sem data válida nunca conta. */
function isInMonth(s: SessionForBilling, start: Date): boolean {
  if (!s.created_at) return false;
  const t = new Date(s.created_at).getTime();
  if (!Number.isFinite(t)) return false;
  const end = new Date(start.getFullYear(), start.getMonth() + 1, 1);
  return t >= start.getTime() && t < end.getTime();
}

export type BillingSummary = {
  /** Sessões concluídas no mês com pelo menos um ponto de aplicação lançado. */
  sessionsCount: number;
  revenue: number; // soma de computeBudget(...).totalPrice das sessões concluídas do mês
  cost: number; // soma de computeBudget(...).totalCost
  margin: number; // revenue - cost
  marginPct: number; // 0 a 1; 0 quando revenue é 0 (nunca NaN)
  avgTicket: number; // revenue / sessionsCount; 0 quando sessionsCount é 0 (nunca NaN/Infinity)
};

const EMPTY_SUMMARY: BillingSummary = {
  sessionsCount: 0,
  revenue: 0,
  cost: 0,
  margin: 0,
  marginPct: 0,
  avgTicket: 0,
};

/**
 * Receita/custo/margem/ticket médio agregados do mês corrente, só de sessões
 * CONCLUÍDAS (`status === 'complete'`) — a métrica de "faturamento" pedida
 * pelo Produto, distinta do "potencial financeiro" de panel.ts (que soma
 * qualquer sessão com pontos, concluída ou não). Reaproveita `computeBudget`,
 * o mesmo cálculo do PDF/Etapa 3.
 */
export function computeMonthlyBillingSummary(
  sessions: SessionForBilling[],
  insumos: Insumo[] | null | undefined,
  laborFeePerSession: number | null | undefined,
  now: Date = new Date(),
): BillingSummary {
  const start = startOfMonth(now);
  let sessionsCount = 0;
  let revenue = 0;
  let cost = 0;

  for (const s of sessions) {
    if (!isClosed(s) || !isInMonth(s, start)) continue;
    const points = pointsOf(s);
    if (points.length === 0) continue;
    const budget = computeBudget(points, insumos, laborFeePerSession);
    sessionsCount += 1;
    revenue += budget.totalPrice;
    cost += budget.totalCost;
  }

  if (sessionsCount === 0) return EMPTY_SUMMARY;
  const margin = revenue - cost;
  return {
    sessionsCount,
    revenue,
    cost,
    margin,
    marginPct: revenue > 0 ? margin / revenue : 0,
    avgTicket: revenue / sessionsCount,
  };
}

export type SubstanceRanking = {
  substance: Substance;
  label: string;
  revenue: number;
  cost: number;
  margin: number;
};

/**
 * Ranking das substâncias por margem (preço - custo) somada, no mês
 * corrente, só de sessões concluídas — "substâncias mais lucrativas" pedido
 * pelo Produto. Calculado ponto a ponto (não via `computeBudget`, que soma
 * tudo junto e inclui `laborFeePerSession`): a mão de obra não é de nenhuma
 * substância específica, então fica de fora do ranking por decisão de
 * design, não omissão. Pontos sem insumo/marca escolhido (`unpriced`) não
 * entram — mesma regra de "sem preço genérico por substância" de
 * `computeBudget`. Substância sem nenhum ponto precificado no mês não
 * aparece no resultado (em vez de uma linha zerada).
 */
export function rankSubstancesByMargin(
  sessions: SessionForBilling[],
  insumos: Insumo[] | null | undefined,
  now: Date = new Date(),
): SubstanceRanking[] {
  const start = startOfMonth(now);
  const totals = new Map<Substance, { revenue: number; cost: number }>();

  for (const s of sessions) {
    if (!isClosed(s) || !isInMonth(s, start)) continue;
    for (const point of pointsOf(s)) {
      const price = priceForPoint(point, insumos);
      const cost = costForPoint(point, insumos);
      if (price == null || cost == null) continue;
      const bucket = totals.get(point.substance) ?? { revenue: 0, cost: 0 };
      bucket.revenue += price;
      bucket.cost += cost;
      totals.set(point.substance, bucket);
    }
  }

  return [...totals.entries()]
    .map(([substance, { revenue, cost }]): SubstanceRanking => ({
      substance,
      label: SUBSTANCE_LABEL[substance],
      revenue,
      cost,
      margin: revenue - cost,
    }))
    .sort((a, b) => b.margin - a.margin);
}

export type MonthlyRevenuePoint = {
  /** "YYYY-MM", chave estável independente de idioma — usada em tooltips/testes. */
  key: string;
  /** Rótulo curto pt-BR pro eixo do gráfico, ex. "mar/26" — mesma decisão de locale fixa de `formatCurrency` em budget.ts (determinístico entre ambientes, não a locale do navegador). */
  label: string;
  revenue: number;
};

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function monthLabel(d: Date): string {
  const short = new Intl.DateTimeFormat('pt-BR', { month: 'short' }).format(d).replace(/\.$/, '');
  return `${short}/${String(d.getFullYear()).slice(2)}`;
}

/**
 * Receita (só sessões concluídas) mês a mês, dos últimos `monthsCount` meses
 * (padrão 6, incluindo o mês corrente) — dados do gráfico de linha/barra da
 * aba Faturamento. Sempre retorna `monthsCount` pontos, em ordem cronológica,
 * mesmo com receita zero num mês (gráfico não "pula" meses sem faturamento).
 */
export function buildMonthlyRevenueChartData(
  sessions: SessionForBilling[],
  insumos: Insumo[] | null | undefined,
  laborFeePerSession: number | null | undefined,
  monthsCount = 6,
  now: Date = new Date(),
): MonthlyRevenuePoint[] {
  const months: { start: Date; key: string; label: string }[] = [];
  for (let i = monthsCount - 1; i >= 0; i--) {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ start, key: monthKey(start), label: monthLabel(start) });
  }

  const totals = new Map<string, number>(months.map((m) => [m.key, 0]));
  for (const s of sessions) {
    if (!isClosed(s) || !s.created_at) continue;
    const d = new Date(s.created_at);
    if (Number.isNaN(d.getTime())) continue;
    const key = monthKey(d);
    if (!totals.has(key)) continue; // fora da janela de `monthsCount` meses
    const points = pointsOf(s);
    if (points.length === 0) continue;
    const revenue = computeBudget(points, insumos, laborFeePerSession).totalPrice;
    totals.set(key, (totals.get(key) ?? 0) + revenue);
  }

  return months.map((m) => ({ key: m.key, label: m.label, revenue: totals.get(m.key) ?? 0 }));
}

/** Data mais antiga que `buildMonthlyRevenueChartData`/`rankSubstancesByMargin` no mês corrente precisam ler — usada pra limitar a busca de `sessions` no Supabase à janela relevante. */
export function billingLookbackStart(monthsCount = 6, now: Date = new Date()): Date {
  return new Date(now.getFullYear(), now.getMonth() - (monthsCount - 1), 1);
}
