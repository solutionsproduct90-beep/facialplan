/**
 * Leitura paginada de uma tabela inteira, para relatórios administrativos.
 *
 * O PostgREST impõe um teto de linhas por resposta (Settings > API >
 * Max Rows no Supabase, 1000 por padrão) e o aplica em SILÊNCIO: a query
 * devolve `error: null` com as primeiras N linhas, sem nada indicando que o
 * resultado é parcial. Um `select()` sem `.range()` sobre uma tabela que
 * cresce passa, de um dia para o outro, a responder um recorte em vez do
 * conjunto — e quem agrega essas linhas no cliente calcula sobre o recorte.
 *
 * Foi o que aconteceu em duas telas de admin:
 *
 * - `AdminDashboard.tsx` mostrava "Total de Sessões" vindo de uma contagem
 *   exata (`count: 'exact', head: true`, imune ao teto) e, logo abaixo,
 *   porcentagens por estágio calculadas sobre `allSessions.length` — o
 *   recorte. Passando de 1000 sessões, duas seções da MESMA tela passariam a
 *   discordar do total, sem aviso.
 * - `AdminMetricas.tsx` buscava `sessions`, `insumos` e `profiles` globais,
 *   sem filtro nem paginação, para calcular conversão, receita estimada e
 *   taxa de retorno POR PROFISSIONAL. Truncar aí não deixa a tela
 *   incompleta: deixa os números errados, com aparência de certos.
 *
 * `AdminAuditoria.tsx` já paginava com `.range()`; as telas adicionadas
 * depois não seguiram. Este módulo existe para que a próxima não precise
 * redescobrir o teto.
 *
 * Achado do ciclo 86 do QA Contínuo.
 */

/** Teto padrão de linhas por resposta do PostgREST (Supabase: Max Rows). */
export const SUPABASE_MAX_ROWS_PER_RESPONSE = 1000;

/**
 * Trava de segurança: um número de páginas que nenhuma tela de relatório
 * deveria alcançar. Se alcançar, é sinal de que aquela tela precisa agregar
 * no banco em vez de trazer linha a linha — e é melhor devolver o que já
 * temos do que girar para sempre.
 */
const MAX_PAGES = 100;

export type PageResult<T> = { data: T[] | null; error: unknown };

/**
 * Chama `runPage(from, to)` repetidamente, com faixas de `pageSize`, até uma
 * página voltar incompleta (o fim dos dados) ou vazia.
 *
 * Um erro em qualquer página interrompe e é relançado: metade dos dados num
 * relatório é pior do que um erro visível, porque a metade tem a mesma
 * aparência do todo — exatamente o defeito que este módulo corrige.
 */
export async function fetchAllRows<T>(
  runPage: (from: number, to: number) => PromiseLike<PageResult<T>>,
  pageSize: number = SUPABASE_MAX_ROWS_PER_RESPONSE,
): Promise<T[]> {
  const todas: T[] = [];
  for (let pagina = 0; pagina < MAX_PAGES; pagina++) {
    const from = pagina * pageSize;
    const { data, error } = await runPage(from, from + pageSize - 1);
    if (error) throw error;
    const linhas = data ?? [];
    todas.push(...linhas);
    if (linhas.length < pageSize) return todas;
  }
  return todas;
}
