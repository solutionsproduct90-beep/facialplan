import { describe, it, expect } from 'vitest';
import { normalizeInsumoStock, computeStockBalance, isLowStock } from './stock';

describe('normalizeInsumoStock', () => {
  it('normalizes a well-formed row, coercing numeric-as-string quantities', () => {
    const rows = [
      {
        id: 'ins-1',
        substance: 'acido_hialuronico',
        brand_name: 'Juvederm Voluma',
        active: true,
        quantity_on_hand: '12',
        low_stock_threshold: '3',
      },
    ];
    expect(normalizeInsumoStock(rows)).toEqual([
      {
        id: 'ins-1',
        substance: 'acido_hialuronico',
        brandName: 'Juvederm Voluma',
        active: true,
        quantityOnHand: 12,
        lowStockThreshold: 3,
      },
    ]);
  });

  it('defaults lowStockThreshold to null when unset, without inventing a limit', () => {
    const rows = [
      {
        id: 'ins-1',
        substance: 'toxina_botulinica',
        brand_name: 'Dysport',
        active: true,
        quantity_on_hand: 0,
        low_stock_threshold: null,
      },
    ];
    expect(normalizeInsumoStock(rows)[0].lowStockThreshold).toBeNull();
  });

  it('discards a row with an unknown substance or missing brand name', () => {
    const rows = [
      { id: 'ins-1', substance: 'fios_pdo', brand_name: 'X', active: true, quantity_on_hand: 1 },
      { id: 'ins-2', substance: 'bioestimulador', brand_name: '', active: true, quantity_on_hand: 1 },
      { id: 'ins-3', substance: 'bioestimulador', brand_name: 'Sculptra', active: true, quantity_on_hand: 1 },
    ];
    const result = normalizeInsumoStock(rows);
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe('ins-3');
  });

  it('returns an empty list for non-array input', () => {
    expect(normalizeInsumoStock(null)).toEqual([]);
    expect(normalizeInsumoStock(undefined)).toEqual([]);
  });
});

describe('computeStockBalance', () => {
  it('sums entrada (positive) and saída (negative) deltas into a running balance', () => {
    expect(
      computeStockBalance([{ quantityDelta: 10 }, { quantityDelta: -3 }, { quantityDelta: 5 }]),
    ).toBe(12);
  });

  it('returns 0 for no movements', () => {
    expect(computeStockBalance([])).toBe(0);
  });

  it('allows the balance to go negative (no clamping here — a business decision for the caller)', () => {
    expect(computeStockBalance([{ quantityDelta: 2 }, { quantityDelta: -5 }])).toBe(-3);
  });
});

describe('isLowStock', () => {
  it('flags at-or-below the configured threshold', () => {
    expect(isLowStock(3, 5)).toBe(true);
    expect(isLowStock(5, 5)).toBe(true);
    expect(isLowStock(6, 5)).toBe(false);
  });

  it('without a threshold, only flags zero or negative balance — never an invented limit', () => {
    expect(isLowStock(0, null)).toBe(true);
    expect(isLowStock(-2, undefined)).toBe(true);
    expect(isLowStock(1, null)).toBe(false);
  });

  it('treats a zero or negative threshold as "not configured"', () => {
    expect(isLowStock(1, 0)).toBe(false);
    expect(isLowStock(0, 0)).toBe(true); // saldo zerado ainda dispara pelo fallback, mesmo com limiar 0
  });
});
