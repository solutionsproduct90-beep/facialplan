// Funções puras do "Construtor de Protocolo Combinado Multi-Sessão" (Combo
// Plans) — desenho de um protocolo faseado desde a primeira consulta (ex.:
// toxina hoje + bioestimulador em 30 dias + skinbooster em 60 dias), onde
// cada etapa pode depois virar uma sessão real vinculada manualmente. Ver
// migration 20260911040000_add_treatment_plans.sql para o desenho de
// schema/RLS. Separadas do componente (TreatmentPlanSection.tsx) pelo mesmo
// motivo de src/lib/adverseEvents.ts: testáveis sem montar a tela nem tocar
// Supabase.

import { addDays, parseISO } from 'date-fns';
import type { Substance } from '@/types/harmonize';
import { SUBSTANCE_KEYS } from '@/types/harmonize';

export type TreatmentPlanStepStatus = 'pendente' | 'concluida' | 'pulada';

export const TREATMENT_PLAN_STEP_STATUSES: TreatmentPlanStepStatus[] = ['pendente', 'concluida', 'pulada'];

/** Plano já normalizado, pronto pra seção renderizar. */
export type TreatmentPlanForList = {
  id: string;
  patientId: string;
  name: string;
  description: string | null;
  startDate: string; // yyyy-MM-dd
  createdAt: string; // ISO
};

/** Etapa já normalizada, pronta pra seção renderizar. */
export type TreatmentPlanStepForList = {
  id: string;
  planId: string;
  substance: Substance;
  offsetDays: number;
  stepOrder: number;
  status: TreatmentPlanStepStatus;
  sessionId: string | null;
  notes: string | null;
  createdAt: string; // ISO
};

/**
 * Normaliza linhas de `treatment_plans` vindas do Supabase. Linha malformada
 * (sem id, patient_id, nome vazio ou start_date inválida) é descartada, não
 * quebra a lista inteira — mesma postura defensiva de
 * `normalizeAdverseEvents`.
 */
export function normalizeTreatmentPlans(raw: unknown): TreatmentPlanForList[] {
  if (!Array.isArray(raw)) return [];
  const out: TreatmentPlanForList[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.patient_id !== 'string' || !r.patient_id) continue;
    if (typeof r.name !== 'string' || !r.name.trim()) continue;
    if (typeof r.start_date !== 'string' || Number.isNaN(parseISO(r.start_date).getTime())) continue;
    out.push({
      id: r.id,
      patientId: r.patient_id,
      name: r.name,
      description: typeof r.description === 'string' ? r.description : null,
      startDate: r.start_date,
      createdAt: typeof r.created_at === 'string' ? r.created_at : r.start_date,
    });
  }
  return out;
}

/**
 * Normaliza linhas de `treatment_plan_steps`. Etapa com substância/status
 * fora do enum conhecido, ou offset negativo/ausente, é descartada — mesma
 * postura de `normalizeAdverseEvents`: um registro malformado não deve
 * derrubar a lista das demais etapas do plano.
 */
export function normalizeTreatmentPlanSteps(raw: unknown): TreatmentPlanStepForList[] {
  if (!Array.isArray(raw)) return [];
  const out: TreatmentPlanStepForList[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.plan_id !== 'string' || !r.plan_id) continue;
    if (typeof r.substance !== 'string' || !SUBSTANCE_KEYS.includes(r.substance as Substance)) continue;
    if (typeof r.offset_days !== 'number' || r.offset_days < 0) continue;
    if (typeof r.status !== 'string' || !TREATMENT_PLAN_STEP_STATUSES.includes(r.status as TreatmentPlanStepStatus)) continue;
    out.push({
      id: r.id,
      planId: r.plan_id,
      substance: r.substance as Substance,
      offsetDays: r.offset_days,
      stepOrder: typeof r.step_order === 'number' ? r.step_order : 0,
      status: r.status as TreatmentPlanStepStatus,
      sessionId: typeof r.session_id === 'string' ? r.session_id : null,
      notes: typeof r.notes === 'string' ? r.notes : null,
      createdAt: typeof r.created_at === 'string' ? r.created_at : '',
    });
  }
  return out;
}

/**
 * Ordem de exibição/execução das etapas: primeiro por offset (a etapa mais
 * próxima do início do plano vem primeiro), com step_order como desempate
 * estável entre etapas de mesmo offset (ex.: duas etapas ambas "dia 0").
 */
export function sortTreatmentPlanSteps<T extends { offsetDays: number; stepOrder: number }>(steps: T[]): T[] {
  return [...steps].sort((a, b) => a.offsetDays - b.offsetDays || a.stepOrder - b.stepOrder);
}

/** Próximo step_order livre ao adicionar uma nova etapa ao final da lista. */
export function nextStepOrder(steps: { stepOrder: number }[]): number {
  if (steps.length === 0) return 0;
  return Math.max(...steps.map((s) => s.stepOrder)) + 1;
}

/**
 * Data prevista de uma etapa = data de início do plano + offset em dias —
 * NUNCA uma data fixa persistida (ver comentário de cabeçalho da
 * migration): ajustar `startDate` do plano recalcula automaticamente a
 * data prevista de toda etapa ainda pendente. `startDate` aceita tanto
 * 'yyyy-MM-dd' (formato de `date` do Postgres) quanto um Date já parseado.
 */
export function computeStepExpectedDate(startDate: string | Date, offsetDays: number): Date {
  const base = typeof startDate === 'string' ? parseISO(startDate) : startDate;
  return addDays(base, offsetDays);
}

/** Rascunho do formulário "Novo plano" — sempre strings (vem de inputs controlados). */
export type TreatmentPlanDraft = {
  name: string;
  description: string;
  startDate: string; // yyyy-MM-dd
};

export type TreatmentPlanValidationError = 'invalidName' | 'invalidStartDate';

export function validateTreatmentPlanDraft(draft: TreatmentPlanDraft): TreatmentPlanValidationError | null {
  if (!draft.name.trim()) return 'invalidName';
  if (!draft.startDate || Number.isNaN(parseISO(draft.startDate).getTime())) return 'invalidStartDate';
  return null;
}

export function buildTreatmentPlanPayload(
  draft: TreatmentPlanDraft,
  context: { professionalId: string; patientId: string },
) {
  return {
    professional_id: context.professionalId,
    patient_id: context.patientId,
    name: draft.name.trim(),
    description: draft.description.trim() || null,
    start_date: draft.startDate,
  };
}

/** Rascunho do formulário "Nova etapa" — sempre strings/number de inputs controlados. */
export type TreatmentPlanStepDraft = {
  substance: string;
  offsetDays: number;
  notes: string;
};

export type TreatmentPlanStepValidationError = 'invalidSubstance' | 'invalidOffset';

export function validateTreatmentPlanStepDraft(draft: TreatmentPlanStepDraft): TreatmentPlanStepValidationError | null {
  if (!SUBSTANCE_KEYS.includes(draft.substance as Substance)) return 'invalidSubstance';
  if (!Number.isFinite(draft.offsetDays) || draft.offsetDays < 0) return 'invalidOffset';
  return null;
}

export function buildTreatmentPlanStepPayload(
  draft: TreatmentPlanStepDraft,
  context: { professionalId: string; planId: string; stepOrder: number },
) {
  return {
    professional_id: context.professionalId,
    plan_id: context.planId,
    substance: draft.substance,
    offset_days: Math.round(draft.offsetDays),
    step_order: context.stepOrder,
    notes: draft.notes.trim() || null,
  };
}

/**
 * Payload de UPDATE para vincular manualmente uma sessão real a uma etapa
 * pendente — a única forma de uma etapa virar "concluída" (ver comentário
 * de cabeçalho da migration: vínculo é sempre uma ação explícita do
 * profissional, nunca inferido por data/substância). Vincular sempre marca
 * a etapa como concluída: não faz sentido registrar a sessão que executou
 * a etapa e ainda assim tratá-la como pendente/pulada.
 */
export function buildStepSessionLinkPayload(sessionId: string) {
  return { session_id: sessionId, status: 'concluida' as TreatmentPlanStepStatus };
}

/**
 * Payload de UPDATE para desfazer o vínculo (ex.: o profissional selecionou
 * a sessão errada) — devolve a etapa para pendente, nunca para "pulada"
 * (desvincular não é o mesmo que decidir pular a etapa).
 */
export function buildStepSessionUnlinkPayload() {
  return { session_id: null, status: 'pendente' as TreatmentPlanStepStatus };
}

/** Payload de UPDATE para marcar uma etapa como pulada, sem vincular sessão nenhuma (ex.: paciente desistiu daquela fase específica do protocolo). */
export function buildStepSkipPayload() {
  return { status: 'pulada' as TreatmentPlanStepStatus, session_id: null };
}
