// Funções puras da fila de espera da Agenda (`appointment_waitlist`, ver
// 20260911130000_add_appointment_waitlist.sql). Separadas do componente
// (AgendaTab.tsx) pelo mesmo motivo de src/lib/agenda.ts: testáveis sem
// montar a tela nem tocar Supabase.

export type WaitlistStatus = 'waiting' | 'offered' | 'fulfilled' | 'expired';

const STATUSES: WaitlistStatus[] = ['waiting', 'offered', 'fulfilled', 'expired'];

/** Entrada de fila já normalizada, pronta pro que a Agenda precisa renderizar. */
export type WaitlistEntry = {
  id: string;
  patientId: string;
  patientName: string | null;
  patientPhone: string | null;
  desiredStartDate: string; // YYYY-MM-DD
  desiredEndDate: string; // YYYY-MM-DD
  status: WaitlistStatus;
  createdAt: string; // ISO
};

/**
 * Normaliza linhas de `appointment_waitlist` vindas do Supabase — incluindo
 * o join `patient:patients(name, phone)`, que o PostgREST pode devolver como
 * objeto OU como array de 1 item dependendo da versão (mesma cautela já
 * aplicada em src/lib/agenda.ts e SessaoPresent.tsx pro mesmo tipo de join).
 * Linha malformada (sem id, sem patient_id ou com datas inválidas) é
 * descartada, não quebra a lista inteira.
 */
export function normalizeWaitlistEntries(raw: unknown): WaitlistEntry[] {
  if (!Array.isArray(raw)) return [];
  const out: WaitlistEntry[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.patient_id !== 'string' || !r.patient_id) continue;
    if (typeof r.desired_start_date !== 'string' || typeof r.desired_end_date !== 'string') continue;

    const status: WaitlistStatus =
      typeof r.status === 'string' && STATUSES.includes(r.status as WaitlistStatus)
        ? (r.status as WaitlistStatus)
        : 'waiting';

    const patientRaw = r.patient;
    const patient = Array.isArray(patientRaw) ? patientRaw[0] : patientRaw;
    const patientObj = patient && typeof patient === 'object' ? (patient as Record<string, unknown>) : null;
    const patientName = patientObj && typeof patientObj.name === 'string' ? patientObj.name : null;
    const patientPhone = patientObj && typeof patientObj.phone === 'string' ? patientObj.phone : null;

    out.push({
      id: r.id,
      patientId: r.patient_id,
      patientName,
      patientPhone,
      desiredStartDate: r.desired_start_date,
      desiredEndDate: r.desired_end_date,
      status,
      createdAt: typeof r.created_at === 'string' ? r.created_at : new Date(0).toISOString(),
    });
  }
  return out;
}

/** Chave `YYYY-MM-DD` (hora LOCAL) de uma data — mesmo formato usado por
 * `desired_start_date`/`desired_end_date` (colunas `date` do Postgres,
 * sempre `YYYY-MM-DD`), pra comparar por data sem entrar em hora/timezone. */
function localDateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Data (`YYYY-MM-DD`, hora local) de um compromisso que acabou de ser
 * cancelado — aceita tanto uma string ISO (`scheduled_at`) quanto um `Date`
 * já pronto, pra o caller poder passar `appt.scheduledAt` direto.
 */
export function slotDateKey(slotDate: string | Date): string {
  const d = slotDate instanceof Date ? slotDate : new Date(slotDate);
  return localDateKey(d);
}

/**
 * Entradas da fila cujo período desejado cobre `slotDate` — a data do
 * compromisso que acabou de abrir por cancelamento — restritas a
 * `status: 'waiting'` (uma entrada já ofertada, concluída ou expirada não
 * volta a ser sugerida), em ORDEM DE CHEGADA na fila (`createdAt` mais
 * antigo primeiro): "quem entrou primeiro é sugerido primeiro", pedido
 * explícito do escopo.
 *
 * Comparação por DATA (string `YYYY-MM-DD`, comparável lexicograficamente
 * porque o formato é de largura fixa), não por hora: o pedido do paciente é
 * sempre um intervalo de dias, nunca um horário exato.
 */
export function findWaitlistCandidatesForSlot(
  entries: WaitlistEntry[],
  slotDate: string | Date,
): WaitlistEntry[] {
  const key = slotDateKey(slotDate);
  return entries
    .filter((e) => e.status === 'waiting' && e.desiredStartDate <= key && key <= e.desiredEndDate)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}

/**
 * Payload de UPDATE pra devolver uma entrada `'offered'` pra `'waiting'` —
 * achado do QA Contínuo (ciclo 24): o botão "Oferecer este horário" só
 * ABRE uma janela do WhatsApp (link `wa.me`) pro profissional clicar em
 * enviar, nunca confirma o envio de fato (popup pode ser bloqueado pelo
 * navegador, ou o profissional fecha a aba sem mandar) — mas a entrada já
 * era marcada `'offered'` incondicionalmente, e
 * uma vez `'offered'` ela nunca mais aparece em
 * `findWaitlistCandidatesForSlot` (filtra só `'waiting'`), então o paciente
 * caía da fila sem ter sido de fato contatado. Devolve pra `'waiting'`
 * (nunca deleta a entrada, preservando `createdAt` = posição de chegada).
 */
export function buildWaitlistBackToWaitingPayload() {
  return { status: 'waiting' as WaitlistStatus };
}
