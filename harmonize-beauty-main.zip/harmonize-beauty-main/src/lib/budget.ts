import type { ApplicationPoint, Insumo, InsumoCategory, Substance, ThreadType } from '@/types/harmonize';
import { INSUMO_CATEGORY_KEYS, THREAD_TYPES } from '@/types/harmonize';

/**
 * Normaliza as linhas de `insumos` vindas do Supabase (snake_case, tipos
 * fracamente garantidos pelo client — numeric pode chegar como string) para
 * o shape de `Insumo` usado pelo app. Diferente do antigo `normalizeCostConfig`
 * (que sanitizava um jsonb livre e sem schema), aqui a tabela já tem RLS e
 * colunas tipadas — a validação é só uma rede de segurança contra
 * null/undefined/erro de query ou uma linha malformada isolada, não contra
 * dado arbitrário. Uma linha inválida é descartada em vez de quebrar as
 * demais.
 */
export function normalizeInsumos(raw: unknown): Insumo[] {
  if (!Array.isArray(raw)) return [];
  const out: Insumo[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.substance !== 'string' || !INSUMO_CATEGORY_KEYS.includes(r.substance as InsumoCategory)) continue;
    if (typeof r.brand_name !== 'string' || !r.brand_name) continue;
    const costPerUnit = Number(r.cost_per_unit);
    const pricePerUnit = Number(r.price_per_unit);
    if (!Number.isFinite(costPerUnit) || !Number.isFinite(pricePerUnit)) continue;
    const insumo: Insumo = {
      id: r.id,
      substance: r.substance as InsumoCategory,
      brandName: r.brand_name,
      costPerUnit,
      pricePerUnit,
      active: r.active !== false,
    };
    // Atributos de produto só para fios de sustentação (ver Insumo.threadType
    // em src/types/harmonize.ts) — omitidos do objeto (em vez de `undefined`
    // explícito) quando ausentes/inválidos, pra não colidir com o `toEqual`
    // de testes existentes que não esperam essas chaves em insumos comuns.
    if (typeof r.thread_type === 'string' && THREAD_TYPES.includes(r.thread_type as ThreadType)) {
      insumo.threadType = r.thread_type as ThreadType;
    }
    const threadLengthMm = Number(r.thread_length_mm);
    if (r.thread_length_mm != null && Number.isFinite(threadLengthMm)) {
      insumo.threadLengthMm = threadLengthMm;
    }
    // Concentração/validade (ver Insumo.concentration/expiresOn em
    // src/types/harmonize.ts) — mesmo tratamento aditivo acima: só entram no
    // objeto quando presentes, pra não colidir com `toEqual` de testes que
    // não esperam essas chaves em insumos sem esses campos preenchidos.
    if (typeof r.concentration === 'string' && r.concentration.trim()) {
      insumo.concentration = r.concentration;
    }
    if (typeof r.expires_on === 'string' && r.expires_on) {
      insumo.expiresOn = r.expires_on;
    }
    out.push(insumo);
  }
  return out;
}

export type BudgetBreakdown = {
  totalCost: number; // custo de insumo — nunca mostrar ao paciente
  totalPrice: number; // preço a cobrar (inclui laborFeePerSession quando houver pontos precificados)
  margin: number;
  marginPct: number; // 0 a 1, NaN quando totalPrice é 0
  totalMl: number; // soma de acido_hialuronico + bioestimulador
  totalUnits: number; // soma de toxina_botulinica
  unpriced: ApplicationPoint[]; // pontos sem insumo/marca escolhido (ou cujo insumo não existe/está inativo)
};

const EMPTY_BUDGET: BudgetBreakdown = {
  totalCost: 0,
  totalPrice: 0,
  margin: 0,
  marginPct: 0,
  totalMl: 0,
  totalUnits: 0,
  unpriced: [],
};

/**
 * Calcula o orçamento para um conjunto de pontos de aplicação, a partir dos
 * insumos/marcas cadastrados pelo profissional. Cada ponto usa o preço do
 * insumo apontado por `point.insumoId` — sem insumo escolhido (ponto antigo,
 * ou substância sem nenhuma marca cadastrada ainda) o ponto cai em
 * `unpriced`; não há fallback de preço "genérico" por substância, por
 * decisão de produto. `includedIds`, quando informado, restringe o cálculo a
 * esse subconjunto — usado pelo toggle Plano A (todos) / Plano B (essencial)
 * na apresentação ao paciente.
 */
export function computeBudget(
  points: ApplicationPoint[],
  insumos: Insumo[] | null | undefined,
  laborFeePerSession: number | null | undefined,
  includedIds?: Set<string>,
): BudgetBreakdown {
  if (!insumos) return EMPTY_BUDGET;
  const included = includedIds ? points.filter((p) => includedIds.has(p.id)) : points;
  if (included.length === 0) return EMPTY_BUDGET;

  const insumoById = new Map(insumos.filter((i) => i.active).map((i) => [i.id, i]));

  let totalCost = 0;
  let totalPrice = 0;
  let totalMl = 0;
  let totalUnits = 0;
  const unpriced: ApplicationPoint[] = [];
  let pricedCount = 0;

  for (const point of included) {
    const insumo = point.insumoId ? insumoById.get(point.insumoId) : undefined;
    if (!insumo) {
      unpriced.push(point);
      continue;
    }
    pricedCount += 1;
    totalCost += point.quantity * insumo.costPerUnit;
    totalPrice += point.quantity * insumo.pricePerUnit;
    if (point.unit === 'ml') totalMl += point.quantity;
    else totalUnits += point.quantity;
  }

  if (pricedCount > 0 && laborFeePerSession) {
    totalPrice += laborFeePerSession;
  }

  const margin = totalPrice - totalCost;
  const marginPct = totalPrice > 0 ? margin / totalPrice : 0;

  return { totalCost, totalPrice, margin, marginPct, totalMl, totalUnits, unpriced };
}

/** Preço do insumo escolhido em um ponto, ou null se não houver marca ativa configurada — usado no detalhamento do PDF. */
export function priceForPoint(point: ApplicationPoint, insumos: Insumo[] | null | undefined): number | null {
  if (!insumos || !point.insumoId) return null;
  const insumo = insumos.find((i) => i.id === point.insumoId && i.active);
  return insumo ? point.quantity * insumo.pricePerUnit : null;
}

/** Custo do insumo escolhido em um ponto, ou null se não houver marca ativa configurada — mesmo formato de `priceForPoint`, usado no ranking de substâncias mais lucrativas do Painel (src/lib/faturamento.ts). */
export function costForPoint(point: ApplicationPoint, insumos: Insumo[] | null | undefined): number | null {
  if (!insumos || !point.insumoId) return null;
  const insumo = insumos.find((i) => i.id === point.insumoId && i.active);
  return insumo ? point.quantity * insumo.costPerUnit : null;
}

/**
 * Recomendador de marca por custo-benefício (backlog P2): entre as marcas
 * ativas cadastradas para uma substância, sugere a de melhor margem
 * (`pricePerUnit - costPerUnit`) — a mesma lógica de margem usada no
 * orçamento acima. Como a quantidade do ponto é a mesma independente da
 * marca escolhida, ranquear por margem por unidade equivale a ranquear pela
 * margem total do ponto. Empate em margem absoluta é desempatado pela maior
 * margem percentual (`margin / pricePerUnit`); empate total mantém a
 * primeira marca encontrada (ordem de cadastro), para um resultado
 * determinístico. É só uma sugestão de ponto de partida — a Etapa 2 sempre
 * deixa o profissional trocar livremente para qualquer outra marca
 * cadastrada da substância.
 */
export function suggestInsumo(insumos: Insumo[] | null | undefined, substance: Substance): Insumo | null {
  if (!insumos) return null;
  let best: Insumo | null = null;
  let bestMargin = -Infinity;
  let bestMarginPct = -Infinity;
  for (const insumo of insumos) {
    if (!insumo.active || insumo.substance !== substance) continue;
    const margin = insumo.pricePerUnit - insumo.costPerUnit;
    const marginPct = insumo.pricePerUnit > 0 ? margin / insumo.pricePerUnit : -Infinity;
    if (margin > bestMargin || (margin === bestMargin && marginPct > bestMarginPct)) {
      best = insumo;
      bestMargin = margin;
      bestMarginPct = marginPct;
    }
  }
  return best;
}

export type Installment = { n: number; value: number };

/**
 * Parcelamento simples sem juros — só divide o total, sem lidar com taxa de
 * cartão. `maxInstallments` vem da configuração do próprio profissional
 * (`profiles.max_installments`); sem configuração (null/undefined/0), NÃO
 * inventa um número de parcelas — retorna lista vazia, e quem consome deve
 * simplesmente não mostrar a opção de parcelamento nesse caso.
 */
export function computeInstallments(total: number, maxInstallments: number | null | undefined): Installment[] {
  if (total <= 0 || !maxInstallments || maxInstallments < 1) return [];
  return Array.from({ length: maxInstallments }, (_, i) => {
    const n = i + 1;
    return { n, value: total / n };
  });
}

/**
 * Desconto à vista — `discountPct` vem da configuração do profissional
 * (`profiles.cash_discount_pct`). Sem configuração, retorna null (não
 * assume nenhum percentual de desconto); quem consome deve tratar null como
 * "sem oferta de desconto à vista" e ocultar essa linha do orçamento.
 */
export function computeCashDiscount(total: number, discountPct: number | null | undefined): number | null {
  if (total <= 0 || discountPct === null || discountPct === undefined || discountPct <= 0) return null;
  return total * (1 - discountPct / 100);
}

// Moeda do orçamento/PDF (profiles.currency) — antes fixa em BRL mesmo com
// o app rodando em 5 idiomas. BRL segue como default para não mudar o
// comportamento de profissionais existentes (mesmo default da migração
// 20260910180000_add_profile_currency.sql).
export const SUPPORTED_CURRENCIES = ['BRL', 'USD', 'EUR', 'GBP'] as const;
export type CurrencyCode = (typeof SUPPORTED_CURRENCIES)[number];

/** Type guard de `profiles.currency` (texto livre no banco) contra `CurrencyCode` — usado por quem lê a moeda do profissional antes de repassar a `formatCurrency`. */
export function isCurrencyCode(value: unknown): value is CurrencyCode {
  return typeof value === 'string' && (SUPPORTED_CURRENCIES as readonly string[]).includes(value);
}

// Cada moeda usa uma locale fixa (não a do navegador) para o formato
// (separador de milhar/decimal, posição do símbolo) ser determinístico
// entre ambientes — mesmo motivo pelo qual o texto do consentimento em
// procedureConsent.ts é sempre gerado com i18n.getFixedT.
const CURRENCY_LOCALE: Record<CurrencyCode, string> = {
  BRL: 'pt-BR',
  USD: 'en-US',
  EUR: 'de-DE',
  GBP: 'en-GB',
};

const currencyFormatters = new Map<CurrencyCode, Intl.NumberFormat>();

function getCurrencyFormatter(currency: CurrencyCode): Intl.NumberFormat {
  let formatter = currencyFormatters.get(currency);
  if (!formatter) {
    formatter = new Intl.NumberFormat(CURRENCY_LOCALE[currency], { style: 'currency', currency });
    currencyFormatters.set(currency, formatter);
  }
  return formatter;
}

export function formatCurrency(value: number, currency: CurrencyCode = 'BRL'): string {
  return getCurrencyFormatter(currency).format(value);
}
