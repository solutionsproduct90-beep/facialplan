import { describe, it, expect } from 'vitest';
import {
  PATIENT_CONSENT_REQUIRED_CODE,
  isPatientConsentRefusal,
  readEdgeFunctionError,
} from './edgeFunctionError';

// Este helper existe por causa de um contrato do supabase-js v2 que é fácil de
// esquecer: numa resposta NÃO-2xx ele devolve `{ data: null, error }` e guarda
// a Response crua em `error.context` sem nunca ler o corpo. Quem lê só `data`
// nunca vê a mensagem que o servidor escreveu — foi exatamente o bug corrigido
// em NovaSessao/SessaoEstagio3 e, depois, no fluxo de Protocolo Nomeado da
// Etapa 2. Estes testes fixam os dois caminhos de leitura e o comportamento
// "nunca lança", para que uma regressão apareça aqui antes de virar toast
// genérico na tela do profissional.

/** Imita o `FunctionsHttpError` do supabase-js: a Response crua em `context`. */
function invokeErrorWithBody(body: unknown, status = 451) {
  return {
    message: 'Edge Function returned a non-2xx status code',
    context: new Response(JSON.stringify(body), {
      status,
      headers: { 'Content-Type': 'application/json' },
    }),
  };
}

describe('readEdgeFunctionError', () => {
  it('lê o corpo de erro de uma resposta 2xx, que vem em `data`', async () => {
    const body = await readEdgeFunctionError(null, {
      error: 'Assinatura inativa. Regularize seu pagamento para continuar.',
      code: 'subscription_inactive',
    });

    expect(body).toEqual({
      error: 'Assinatura inativa. Regularize seu pagamento para continuar.',
      code: 'subscription_inactive',
    });
  });

  it('lê o corpo de uma resposta não-2xx, que o SDK esconde em `error.context`', async () => {
    const body = await readEdgeFunctionError(
      invokeErrorWithBody({
        error: 'Consentimento do paciente não registrado.',
        code: PATIENT_CONSENT_REQUIRED_CODE,
      }),
      // O ponto do helper: em não-2xx `data` é null, então quem lê só `data`
      // não acha nada.
      null,
    );

    expect(body?.error).toBe('Consentimento do paciente não registrado.');
    expect(body?.code).toBe(PATIENT_CONSENT_REQUIRED_CODE);
  });

  it('não consome o corpo da Response original (clona antes de ler)', async () => {
    const invokeError = invokeErrorWithBody({ error: 'primeira leitura' });

    await readEdgeFunctionError(invokeError, null);
    const segundaLeitura = await invokeError.context.json();

    expect(segundaLeitura).toEqual({ error: 'primeira leitura' });
  });

  it('devolve null — sem lançar — quando o corpo não é JSON (ex.: 502 com HTML)', async () => {
    const invokeError = {
      message: 'Edge Function returned a non-2xx status code',
      context: new Response('<html>Bad Gateway</html>', { status: 502 }),
    };

    await expect(readEdgeFunctionError(invokeError, null)).resolves.toBeNull();
  });

  it('devolve null quando não há nem corpo em `data` nem `context` no erro', async () => {
    await expect(readEdgeFunctionError({ message: 'boom' }, null)).resolves.toBeNull();
    await expect(readEdgeFunctionError(null, null)).resolves.toBeNull();
  });

  it('ignora um `data` de sucesso, que não carrega campo `error`', async () => {
    const body = await readEdgeFunctionError(
      invokeErrorWithBody({ error: 'recusa real', code: 'x' }),
      { simulationUrl: 'https://example.com/sim.png' },
    );

    expect(body?.error).toBe('recusa real');
  });
});

describe('isPatientConsentRefusal', () => {
  it('reconhece a recusa por falta de consentimento pelo código estável', () => {
    expect(isPatientConsentRefusal({ code: PATIENT_CONSENT_REQUIRED_CODE })).toBe(true);
  });

  it('não confunde outra recusa (ex.: assinatura inativa) com falta de consentimento', () => {
    expect(isPatientConsentRefusal({ code: 'subscription_inactive' })).toBe(false);
    expect(isPatientConsentRefusal({ error: 'qualquer coisa' })).toBe(false);
    expect(isPatientConsentRefusal(null)).toBe(false);
  });
});
