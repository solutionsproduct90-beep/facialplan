// Formata o registro profissional (CRM, CRO, CRBM, COREN etc. — qualquer
// conselho, sem assumir uma única categoria) como "TIPO NÚMERO" pra exibir
// na tela de Apresentar (autenticada e pública), pra dar credibilidade e
// rastreabilidade ao paciente sobre quem é o responsável pelo procedimento.
//
// Só formata quando tipo E número estão preenchidos: um profissional que
// cadastrou só um dos dois no Perfil (ver src/pages/Perfil.tsx) não tem uma
// credencial verificável o bastante pra exibir — mostrar "CRM" sozinho ou um
// número solto sem o conselho que o emitiu não ajuda a credibilidade, então
// a linha inteira simplesmente some da tela nesse caso (ver uso em
// SessaoPresent.tsx) em vez de mostrar um fragmento.
//
// Usado na tela autenticada (SessaoPresent.tsx, que lê council_type/
// council_number direto de `profiles`). A versão pública
// (SessaoPresentPublico.tsx) recebe o valor já formatado da edge function
// `public-session-presentation`, que roda em Deno e não pode importar deste
// módulo — a mesma regra está duplicada lá (ver `formatProfessionalRegistration`
// em supabase/functions/public-session-presentation/index.ts); mantenha as
// duas versões em sincronia.
export function formatProfessionalRegistration(
  councilType: string | null | undefined,
  councilNumber: string | null | undefined,
): string | null {
  const type = councilType?.trim();
  const number = councilNumber?.trim();
  if (!type || !number) return null;
  return `${type} ${number}`;
}
