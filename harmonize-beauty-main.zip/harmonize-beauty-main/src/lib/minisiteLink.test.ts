import { describe, it, expect } from 'vitest';
import { isValidMinisiteSlug, buildMinisiteLink, slugify, buildAutoSlugCandidate } from './minisiteLink';

describe('isValidMinisiteSlug', () => {
  it('accepts a well-formed slug', () => {
    expect(isValidMinisiteSlug('clinica-bela-face')).toBe(true);
    expect(isValidMinisiteSlug('abc')).toBe(true);
    expect(isValidMinisiteSlug('dra-camila-2024')).toBe(true);
  });

  it('rejects missing, empty and too-short values', () => {
    expect(isValidMinisiteSlug(undefined)).toBe(false);
    expect(isValidMinisiteSlug(null)).toBe(false);
    expect(isValidMinisiteSlug('')).toBe(false);
    expect(isValidMinisiteSlug('ab')).toBe(false);
  });

  it('rejects values with uppercase, spaces or disallowed characters', () => {
    expect(isValidMinisiteSlug('Clinica-Bela')).toBe(false);
    expect(isValidMinisiteSlug('clinica bela')).toBe(false);
    expect(isValidMinisiteSlug('clinica_bela')).toBe(false);
    expect(isValidMinisiteSlug('clínica')).toBe(false);
  });

  it('rejects a slug starting or ending with a hyphen', () => {
    expect(isValidMinisiteSlug('-clinica')).toBe(false);
    expect(isValidMinisiteSlug('clinica-')).toBe(false);
  });

  it('rejects a slug longer than 60 characters', () => {
    expect(isValidMinisiteSlug('a'.repeat(61))).toBe(false);
    expect(isValidMinisiteSlug('a'.repeat(60))).toBe(true);
  });

  it('rejects an attempt to inject extra path segments or scripts', () => {
    expect(isValidMinisiteSlug('clinica/../admin')).toBe(false);
    expect(isValidMinisiteSlug('clinica"><script>')).toBe(false);
  });
});

describe('buildMinisiteLink', () => {
  it('joins origin and slug into the public minisite URL', () => {
    expect(buildMinisiteLink('https://app.harmonize.com', 'clinica-bela-face')).toBe(
      'https://app.harmonize.com/m/clinica-bela-face',
    );
  });

  it('strips a trailing slash from the origin before joining', () => {
    expect(buildMinisiteLink('https://app.harmonize.com/', 'slug-value')).toBe(
      'https://app.harmonize.com/m/slug-value',
    );
  });
});

describe('slugify', () => {
  it('lowercases, strips accents and replaces separators with hyphens', () => {
    expect(slugify('Clínica Bela Face')).toBe('clinica-bela-face');
  });

  it('collapses repeated separators and trims leading/trailing hyphens', () => {
    expect(slugify('  Dra.  Camila -- Rocha!! ')).toBe('dra-camila-rocha');
  });

  it('produces a valid slug for the resulting value whenever the input has usable characters', () => {
    const slug = slugify('Clínica Bela Face & Cia');
    expect(isValidMinisiteSlug(slug)).toBe(true);
  });

  it('returns an empty string for input with no latin alphanumeric content', () => {
    expect(slugify('!!! 😀 !!!')).toBe('');
  });

  it('pads a too-short result up to the minimum length', () => {
    const slug = slugify('A');
    expect(slug.length).toBeGreaterThanOrEqual(3);
  });

  it('truncates a result longer than 60 characters', () => {
    const slug = slugify('a'.repeat(200));
    expect(slug.length).toBeLessThanOrEqual(60);
  });
});

describe('buildAutoSlugCandidate', () => {
  it('builds a valid slug from a name hint plus a random suffix', () => {
    const candidate = buildAutoSlugCandidate('Clínica Bela Face');
    expect(isValidMinisiteSlug(candidate)).toBe(true);
    expect(candidate.startsWith('clinica-bela-face-')).toBe(true);
  });

  it('falls back to a generic base when the hint has no usable characters', () => {
    const candidate = buildAutoSlugCandidate('😀😀😀');
    expect(isValidMinisiteSlug(candidate)).toBe(true);
    expect(candidate.startsWith('profissional-')).toBe(true);
  });

  it('falls back to a generic base when no hint is provided at all', () => {
    const candidate = buildAutoSlugCandidate(null);
    expect(isValidMinisiteSlug(candidate)).toBe(true);
    expect(candidate.startsWith('profissional-')).toBe(true);
  });

  it('produces different candidates on successive calls (random suffix)', () => {
    const a = buildAutoSlugCandidate('Clínica Bela Face');
    const b = buildAutoSlugCandidate('Clínica Bela Face');
    // Extremely unlikely to collide (6-char base-36 suffix) — a collision
    // here would indicate randomSlugSuffix stopped being random.
    expect(a).not.toBe(b);
  });

  it('never exceeds 60 characters even for a very long name hint', () => {
    const candidate = buildAutoSlugCandidate('a'.repeat(200));
    expect(candidate.length).toBeLessThanOrEqual(60);
    expect(isValidMinisiteSlug(candidate)).toBe(true);
  });
});
