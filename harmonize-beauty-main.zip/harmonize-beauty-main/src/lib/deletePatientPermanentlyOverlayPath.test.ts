import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Achado de auditoria LGPD/consentimento: `delete_patient_permanently`
// coletava os storagePaths de `patient-photos` a partir de `sessions`
// (original/oblique/profile/pdf), `session_real_results` e
// `anamnesis.photo_url`, mas esquecia `sessions.overlay_image_url` — mesma
// classe de bug que 20260911110000_fix_delete_patient_permanently_anamnesis_photo.sql
// já corrigiu uma vez para `anamnesis.photo_url`.
//
// Não há infraestrutura de teste com Postgres real neste repositório (ver
// mesmo comentário em manualPointJustificationRpc.test.ts) — então, como lá,
// verificamos estaticamente no texto da própria migration que
// `overlay_image_url` entra no array de paths que a função devolve para o
// client apagar do Storage (src/lib/patientPermanentDeletion.ts).
const migrationPath = resolve(
  dirname(fileURLToPath(import.meta.url)),
  '../../supabase/migrations/20260928054244_add_overlay_image_url_to_delete_patient_permanently.sql',
);
const sql = readFileSync(migrationPath, 'utf8');

const functionBodyMatch = sql.match(/AS \$\$([\s\S]*?)\$\$;/);
if (!functionBodyMatch) throw new Error('não achou o corpo da função na migration — o regex precisa ser ajustado');
const functionBody = functionBodyMatch[1];

describe('delete_patient_permanently (migration SQL) — overlay_image_url incluído na eliminação de Storage', () => {
  it('inclui s.overlay_image_url no mesmo ARRAY[] que já coleta as demais colunas de imagem de sessions', () => {
    const arrayMatch = functionBody.match(/unnest\(ARRAY\[([\s\S]*?)\]\)/);
    expect(arrayMatch).not.toBeNull();
    const arrayContents = arrayMatch![1];
    expect(arrayContents).toContain('s.overlay_image_url');
    // Continua ao lado de todas as colunas que já eram cobertas — não é uma
    // substituição, é uma adição.
    for (const column of [
      's.original_image_url',
      's.oblique_left_image_url',
      's.oblique_right_image_url',
      's.profile_image_url',
      's.pdf_url',
    ]) {
      expect(arrayContents).toContain(column);
    }
  });

  it('mantém as outras fontes de paths (session_real_results, anamnesis) e o bucket de simulação intactos', () => {
    expect(functionBody).toMatch(/session_real_results/);
    expect(functionBody).toMatch(/FROM public\.anamnesis a/);
    expect(functionBody).toMatch(/v_sim_paths[\s\S]*simulation_url/);
  });

  it('continua SECURITY DEFINER com search_path fixo e checagem de posse por professional_id', () => {
    expect(sql).toContain('SECURITY DEFINER');
    expect(sql).toContain('SET search_path = public');
    expect(functionBody).toContain('professional_id = auth.uid()');
  });

  it('concede EXECUTE só para "authenticated", nunca para PUBLIC', () => {
    expect(sql).toMatch(/REVOKE EXECUTE ON FUNCTION public\.delete_patient_permanently\(uuid\) FROM PUBLIC/);
    expect(sql).toMatch(/GRANT EXECUTE ON FUNCTION public\.delete_patient_permanently\(uuid\) TO authenticated/);
  });
});
