import { supabase } from '@/integrations/supabase/client';

// Ações auditadas hoje (ver supabase/migrations/20260910170000_add_audit_log.sql,
// 20260910210000_audit_log_admin_view_and_patient_link.sql — que acrescenta
// 'send_anamnesis_link' — e 20260911000000_add_export_full_record_audit_action.sql
// — que acrescenta 'export_full_record' —, que juntas restringem a tabela
// audit_log a este mesmo conjunto via CHECK). Espelha o enum do banco em vez
// de aceitar qualquer string, pra pegar um typo em tempo de compilação em
// vez de uma RPC que sempre falha em runtime.
//
// As 3 últimas (patient_permanent_deletion, admin_view_session_compliance,
// admin_toggle_professional_block — ver 20260911100000_add_delete_patient_
// permanently_rpc.sql, 20260911120000_add_audit_log_to_admin_session_
// compliance.sql e 20260914090000_add_audit_log_to_admin_toggle_block.sql)
// nunca passam por logDataAccess()/log_data_access: são gravadas via INSERT
// direto dentro das próprias RPCs SECURITY DEFINER de admin. Ainda assim
// precisam constar aqui — QA Contínuo ciclo 29 apontou que faltavam no
// filtro de ação de AdminAuditoria.tsx, tornando essas 3 ações (as de maior
// severidade: exclusão permanente de paciente e bloqueio/desbloqueio de
// profissional) impossíveis de isolar na busca.
//
// As 2 últimas (hotmart_purchase_self_recovery, admin_link_hotmart_purchase —
// ver 20260917153000_add_hotmart_pending_purchases.sql) seguem a mesma regra:
// são gravadas por INSERT direto dentro das RPCs do caminho de recuperação de
// compra da Hotmart. Auditar as duas é o que impede que "liberar assinatura
// sem pagamento identificado" vire uma ação invisível — a de admin porque é
// admin agindo sobre perfil alheio, e a de autoatendimento porque é o único
// ponto do produto em que um profissional ganha acesso sem o webhook.
export type AuditAction =
  | 'view_patient_photo'
  | 'view_anamnesis'
  | 'export_pdf'
  | 'send_anamnesis_link'
  | 'export_full_record'
  | 'patient_permanent_deletion'
  | 'admin_view_session_compliance'
  | 'admin_toggle_professional_block'
  | 'hotmart_purchase_self_recovery'
  | 'admin_link_hotmart_purchase';
// 'profile' acrescentado em 20260914090000_add_audit_log_to_admin_toggle_block.sql
// para admin_toggle_professional_block (recurso é o profile do profissional, não um paciente/sessão).
export type AuditResourceType = 'patient' | 'session' | 'anamnesis' | 'profile';

/**
 * Registra um acesso a dado sensível (foto de paciente, anamnese, export de
 * PDF) no log de auditoria — gap de proteção de dados apontado por auditoria
 * de segurança anterior.
 *
 * Chama a função de banco `log_data_access` (SECURITY DEFINER): o client não
 * consegue forjar o registro (actor_id vem sempre de auth.uid() no banco, e a
 * função confere no próprio banco que quem chama é dono do recurso antes de
 * gravar) nem inserir direto na tabela (audit_log não tem policy de INSERT
 * para nenhum role de cliente).
 *
 * "Melhor esforço": roda depois que a ação sensível já foi concluída com
 * sucesso e nunca deve travar a UI — uma falha aqui (rede, RLS) só é
 * registrada no console, não vira toast nem bloqueia o fluxo do profissional.
 */
export async function logDataAccess(
  action: AuditAction,
  resourceType: AuditResourceType,
  resourceId: string,
): Promise<void> {
  try {
    const { error } = await supabase.rpc('log_data_access', {
      p_action: action,
      p_resource_type: resourceType,
      p_resource_id: resourceId,
    });
    if (error) {
      console.error('[audit] falha ao registrar acesso', { action, resourceType, error });
    }
  } catch (err) {
    console.error('[audit] falha ao registrar acesso', { action, resourceType, err });
  }
}
