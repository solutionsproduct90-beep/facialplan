// "Paciente parado": um paciente com pelo menos uma sessão registrada (de
// qualquer status — concluída ou ainda aberta) cuja mais recente já passou
// de `thresholdDays` sem nenhuma sessão nova. Alimenta o filtro de
// segmentação em Pacientes.tsx que o squad de Produto pediu pra campanhas
// de reativação.
//
// Deliberadamente NÃO reaproveita `ABANDONED_THRESHOLD_DAYS` de
// sessionAbandonment.ts: aquele limiar (5 dias) mede uma sessão individual
// ainda aberta que provavelmente foi esquecida por engano pelo profissional
// (dispara um lembrete por e-mail pra ele terminá-la) — uma janela curta,
// pensada pra uma sessão. Aqui o alvo é outro: o paciente como um todo
// sumiu da clínica, o que pede um horizonte bem mais longo. Por isso um
// limiar próprio, com um valor padrão simples e configurável na própria
// tela (cada prática tem um ritmo de retorno diferente).
export const STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS = 30;

export const STALLED_PATIENT_THRESHOLD_OPTIONS_DAYS = [14, 30, 60, 90] as const;

/**
 * true quando a última sessão do paciente (qualquer status) já passou de
 * `thresholdDays`. Um paciente sem nenhuma sessão ainda (`lastSessionAt`
 * nulo) não conta como "parado" aqui — é um paciente novo, não alguém que
 * sumiu, e cabe num filtro/segmento diferente caso o produto queira um no futuro.
 */
export function isPatientStalled(
  lastSessionAt: string | number | Date | null | undefined,
  now: Date = new Date(),
  thresholdDays: number = STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS,
): boolean {
  if (!lastSessionAt) return false;
  const last = lastSessionAt instanceof Date ? lastSessionAt : new Date(lastSessionAt);
  if (Number.isNaN(last.getTime())) return false;

  const ageMs = now.getTime() - last.getTime();
  return ageMs >= thresholdDays * 24 * 60 * 60 * 1000;
}

/**
 * Link `wa.me` pré-preenchido para reativação — mesmo padrão de
 * `https://wa.me/?text=<mensagem>` já usado em useSessionPresentLink e
 * useSendAnamnesisLink (abre o seletor de contato do WhatsApp), mas mirando
 * direto no telefone do paciente quando ele está cadastrado
 * (`https://wa.me/<DDI><número>?text=...`, dígitos apenas — é o formato que
 * o wa.me espera), já que aqui — diferente daqueles dois hooks — já se sabe
 * pra quem é a mensagem. Sem telefone cadastrado, cai no mesmo fallback
 * genérico (`https://wa.me/?text=...`) pra ainda assim deixar a mensagem
 * pronta pra colar em qualquer conversa.
 */
export function buildReactivationWhatsAppLink(phone: string | null | undefined, message: string): string {
  const digits = (phone ?? '').replace(/\D/g, '');
  const base = digits ? `https://wa.me/${digits}` : 'https://wa.me/';
  return `${base}?text=${encodeURIComponent(message)}`;
}

/**
 * Link `wa.me` pra o botão "Enviar lembrete de retorno" do Radar de Retorno
 * (`src/lib/returnRadar.ts`, ver `ReturnRadar.isOverdue`) — pedido explícito
 * do dono do produto por uma via mais proativa além do badge discreto que já
 * existe em PacienteDetalhe.tsx/Pacientes.tsx. REAPROVEITA
 * `buildReactivationWhatsAppLink` de propósito (mesmo mecanismo de link
 * `wa.me` do resto do app) em vez de duplicar a lógica de dígitos/fallback —
 * a única coisa nova aqui é escolher qual das duas mensagens usar.
 *
 * As duas mensagens (`messages.upcoming`/`messages.overdue`) chegam JÁ
 * traduzidas e interpoladas pelo chamador (tipicamente
 * `t('patients.list.returnRadar.whatsAppMessage...', { name })`) — esta
 * função não lida com i18n, só decide qual template usar conforme
 * `isOverdue`: uma mensagem mais suave ("hora de agendar o retorno") pra
 * quem ainda está dentro da janela prevista, outra mais direta ("já passou o
 * período recomendado") pra quem já está atrasado.
 */
export function buildReturnRadarReminderWhatsAppLink(
  phone: string | null | undefined,
  isOverdue: boolean,
  messages: { upcoming: string; overdue: string },
): string {
  return buildReactivationWhatsAppLink(phone, isOverdue ? messages.overdue : messages.upcoming);
}
