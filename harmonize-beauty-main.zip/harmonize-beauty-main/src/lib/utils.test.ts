import { describe, it, expect } from "vitest";
import { cn } from "./utils";

describe("cn", () => {
  it("joins multiple class strings together", () => {
    expect(cn("a", "b", "c")).toBe("a b c");
  });

  it("ignores falsy values (undefined, null, false, empty string)", () => {
    expect(cn("a", undefined, null, false, "", "b")).toBe("a b");
  });

  it("supports conditional object syntax", () => {
    expect(cn("base", { active: true, disabled: false })).toBe("base active");
  });

  it("supports arrays of class values", () => {
    expect(cn(["a", "b"], ["c"])).toBe("a b c");
  });

  it("merges conflicting tailwind classes, keeping the last one", () => {
    expect(cn("px-2", "px-4")).toBe("px-4");
    expect(cn("text-red-500", "text-blue-500")).toBe("text-blue-500");
  });

  it("keeps non-conflicting tailwind classes together", () => {
    expect(cn("px-2", "py-4", "text-sm")).toBe("px-2 py-4 text-sm");
  });

  it("returns an empty string when given nothing usable", () => {
    expect(cn()).toBe("");
    expect(cn(undefined, null, false)).toBe("");
  });

  it("allows later classes to override earlier ones even when mixed with conditions", () => {
    const isActive = true;
    expect(cn("btn", isActive && "btn-active", "px-2", "px-6")).toBe(
      "btn btn-active px-6"
    );
  });
});
