// Sugestão de assinatura/recorrência a partir do histórico de retorno do
// paciente — evolução do Radar de Retorno (src/lib/returnRadar.ts, que só
// olha a ÚLTIMA sessão concluída pra prever a PRÓXIMA janela de retorno).
// Aqui olhamos o histórico INTEIRO de sessões concluídas de uma substância:
// quando o paciente já voltou repetidas vezes num ritmo parecido com a
// janela esperada daquela substância (ex.: toxina botulínica a cada ~4-6
// meses, repetido 2+ vezes), isso é um sinal de que vale a pena o
// profissional oferecer um plano de recorrência a ELE especificamente, em
// vez de só mandar lembrete pontual toda vez que o radar acender.
//
// Escopo deliberadamente restrito à DETECÇÃO do padrão: não cria nenhuma
// infraestrutura de cobrança recorrente nova. Quando o padrão é detectado,
// a UI (ver PacienteDetalhe.tsx) aponta para o "Construtor de Protocolo
// Combinado Multi-Sessão" já existente (Combo Plans — treatment_plans/
// treatment_plan_steps, src/lib/treatmentPlans.ts,
// TreatmentPlanSection.tsx), a estrutura de "plano" mais próxima já
// presente no app — reaproveitada em vez de um conceito concorrente novo.
import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { substancesInPoints, SUBSTANCE_RETURN_WINDOW_MONTHS } from './returnRadar';

/** Mesma fatia mínima de sessão que `returnRadar.ts` (SessionForReturnRadar)
 * usa — repetida aqui em vez de importada porque este módulo lê a
 * substância de CADA sessão concluída (não só a mais recente), mas o
 * formato da linha que precisa é idêntico. */
export type SessionForRecurrencePattern = {
  status: string | null;
  created_at: string | null;
  stage2_overlay: unknown;
};

// Mesmo valor/justificativa de COMPLETED_SESSION_STATUS em returnRadar.ts:
// duplicar uma constante de 1 string é mais simples que exportar algo só
// pra isso de um módulo que não a expõe hoje.
const COMPLETED_SESSION_STATUS = 'complete';

/**
 * Nº mínimo de ciclos (intervalos entre retornos, não sessões) pra
 * considerar um histórico "regular" o bastante pra sugerir plano — pedido
 * explícito da ideia original: "repetido 2+ vezes". 2 ciclos completos
 * exige pelo menos 3 sessões concluídas daquela substância (sessão inicial
 * + 2 retornos no mesmo ritmo).
 */
export const MIN_CYCLES_FOR_REGULAR_RECURRENCE = 2;

// Aproximação "1 mês = 30 dias" — mesmo espírito de simplificação
// deliberada já registrado em SUBSTANCE_RETURN_WINDOW_MONTHS/
// DOSE_ALERT_THRESHOLD (comentário de cabeçalho de returnRadar.ts):
// ponto de partida de engenharia, não um cálculo calendário exato (que já
// existe em `addMonths` de returnRadar.ts pra outro propósito — prever UMA
// janela futura a partir de UMA data-base, não comparar vários intervalos
// já ocorridos entre si).
const DAYS_PER_MONTH = 30;

// Folga sobre a janela de retorno "oficial" da substância
// (SUBSTANCE_RETURN_WINDOW_MONTHS) pra classificar um intervalo real como
// "dentro do esperado" — sem isso, um paciente que voltou 2 semanas antes
// ou depois do que a literatura cita (variação individual normal, o mesmo
// motivo pelo qual o Radar de Retorno já usa uma janela min-max em vez de
// um número fixo) seria descartado como "irregular" por uma diferença
// pequena demais pra importar na prática.
const INTERVAL_TOLERANCE_DAYS = 45;

export type RecurrencePattern = {
  substance: Substance;
  /** true quando há ciclos suficientes (`cycleCount >= MIN_CYCLES_FOR_REGULAR_RECURRENCE`)
   * E todos os intervalos observados caem dentro da janela esperada da
   * substância (com a folga de `INTERVAL_TOLERANCE_DAYS`). */
  isRegular: boolean;
  /** Média (arredondada) dos intervalos em dias entre retornos consecutivos. */
  averageIntervalDays: number;
  /** Nº de intervalos observados (sessões da substância - 1), não de sessões. */
  cycleCount: number;
};

function daysBetween(earlier: Date, later: Date): number {
  return Math.round((later.getTime() - earlier.getTime()) / (24 * 60 * 60 * 1000));
}

/**
 * Detecta o padrão de recorrência de UMA substância a partir das datas
 * (já em ordem crescente) das sessões concluídas em que ela apareceu.
 * `null` quando há menos de 2 datas — não dá pra calcular nem um intervalo,
 * então não há nada a detectar (nem "regular" nem "irregular": faltam dados).
 */
export function detectRecurrencePattern(
  datesAscending: Date[],
  substance: Substance,
): RecurrencePattern | null {
  if (datesAscending.length < 2) return null;

  const intervals: number[] = [];
  for (let i = 1; i < datesAscending.length; i++) {
    intervals.push(daysBetween(datesAscending[i - 1], datesAscending[i]));
  }

  const cycleCount = intervals.length;
  const averageIntervalDays = Math.round(intervals.reduce((sum, d) => sum + d, 0) / cycleCount);

  const { min, max } = SUBSTANCE_RETURN_WINDOW_MONTHS[substance];
  const minDays = min * DAYS_PER_MONTH - INTERVAL_TOLERANCE_DAYS;
  const maxDays = max * DAYS_PER_MONTH + INTERVAL_TOLERANCE_DAYS;
  const allWithinExpectedWindow = intervals.every((d) => d >= minDays && d <= maxDays);

  return {
    substance,
    isRegular: cycleCount >= MIN_CYCLES_FOR_REGULAR_RECURRENCE && allWithinExpectedWindow,
    averageIntervalDays,
    cycleCount,
  };
}

/**
 * Varre o histórico INTEIRO de sessões concluídas de um paciente (qualquer
 * ordem de entrada) e detecta o padrão de recorrência de cada substância
 * distinta encontrada — uma sessão com múltiplas substâncias contribui pra
 * o padrão de cada uma. Retorna só as substâncias com pelo menos 2 sessões
 * concluídas (as demais não têm intervalo nenhum pra medir, ver
 * `detectRecurrencePattern`); lista vazia para paciente sem histórico (ou
 * sem sessão concluída, ou substância nunca repetida) — nunca lança.
 */
export function detectRecurrencePatternsForSessions<T extends SessionForRecurrencePattern>(
  sessions: T[] | null | undefined,
): RecurrencePattern[] {
  if (!Array.isArray(sessions)) return [];

  const datesBySubstance = new Map<Substance, Date[]>();
  for (const session of sessions) {
    if (session.status !== COMPLETED_SESSION_STATUS || !session.created_at) continue;
    const date = new Date(session.created_at);
    if (Number.isNaN(date.getTime())) continue;

    const points = Array.isArray(session.stage2_overlay) ? (session.stage2_overlay as ApplicationPoint[]) : [];
    for (const substance of substancesInPoints(points)) {
      const dates = datesBySubstance.get(substance) ?? [];
      dates.push(date);
      datesBySubstance.set(substance, dates);
    }
  }

  const patterns: RecurrencePattern[] = [];
  for (const [substance, dates] of datesBySubstance) {
    dates.sort((a, b) => a.getTime() - b.getTime());
    const pattern = detectRecurrencePattern(dates, substance);
    if (pattern) patterns.push(pattern);
  }
  return patterns;
}

/**
 * A substância com o padrão de recorrência mais consolidado (`isRegular`)
 * entre as detectadas — a que a UI de fato usa pra decidir se mostra a
 * sugestão discreta de plano/assinatura (ver PacienteDetalhe.tsx). Desempate
 * por `cycleCount` (mais ciclos completos = padrão mais estabelecido).
 * `null` quando nenhuma substância tem um padrão regular (histórico
 * insuficiente ou irregular demais) ou o paciente não tem histórico.
 */
export function mostRegularRecurrencePattern<T extends SessionForRecurrencePattern>(
  sessions: T[] | null | undefined,
): RecurrencePattern | null {
  const regular = detectRecurrencePatternsForSessions(sessions).filter((p) => p.isRegular);
  if (regular.length === 0) return null;
  return regular.reduce((best, candidate) => (candidate.cycleCount > best.cycleCount ? candidate : best));
}
