/**
 * Template padrão do botão "Oferecer este horário" da fila de espera da
 * Agenda (ver AgendaTab.tsx e src/lib/waitlist.ts) — mensagem `{{chave}}`
 * resolvida aqui no client antes de virar o texto do link `wa.me` manual
 * (`buildReactivationWhatsAppLink`, em patientReactivation.ts) que o
 * profissional abre e revisa antes de enviar.
 *
 * Lógica de substituição deliberadamente simples e sem dependência externa
 * (mesmo espírito do resto do projeto — ver postProcedureChecklist.ts):
 * qualquer `{{chave}}` reconhecida em `variables` é trocada pelo valor
 * (vazio quando o valor é null/undefined/string vazia); uma chave que nem
 * aparece em `variables` é deixada como está — ajuda a notar um placeholder
 * digitado errado (ex.: `{{nome_pacient}}`) em vez de apagá-lo em silêncio.
 */

const PLACEHOLDER_REGEX = /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g;

/**
 * Substitui `{{chave}}` no corpo do template pelos valores em `variables`.
 * Uma chave presente em `variables` mas com valor `null`/`undefined`/string
 * vazia é trocada por string vazia (mensagem sai "limpa", sem sinal do
 * placeholder). Uma chave que NÃO existe em `variables` é preservada como
 * `{{chave}}` no resultado — sinaliza um placeholder desconhecido/typo em
 * vez de removê-lo silenciosamente.
 */
export function resolveWhatsAppTemplate(
  body: string,
  variables: Record<string, string | null | undefined>,
): string {
  return body.replace(PLACEHOLDER_REGEX, (match, key: string) => {
    if (!(key in variables)) return match;
    const value = variables[key];
    return value ?? '';
  });
}

/**
 * Template padrão do botão "Oferecer este horário" da fila de espera da
 * Agenda (ver src/lib/waitlist.ts) — um por idioma suportado, DELIBERADAMENTE
 * fora do dicionário react-i18next (src/i18n/locales/*.json): a chave de
 * i18next TAMBÉM usa a sintaxe `{{variavel}}` pra interpolação própria, então
 * guardar este texto lá faria o `t()` tentar (e falhar, ou pior, apagar
 * silenciosamente) resolver `{{nome_paciente}}`/`{{data_horario}}` antes da
 * gente conseguir passar essas duas chaves pra `resolveWhatsAppTemplate`.
 * Mesma ideia de `buildReturnRadarReminderWhatsAppLink` em
 * patientReactivation.ts, só que aqui o texto-base já nasce aqui (não vem do
 * chamador) porque ele é sempre o mesmo, variando só por idioma.
 */
const WAITLIST_OFFER_TEMPLATE_BY_LANGUAGE: Record<string, string> = {
  pt: 'Olá {{nome_paciente}}! Um horário abriu na nossa agenda para {{data_horario}}. Você ainda tem interesse em agendar? Responda esta mensagem para confirmar 😊',
  en: "Hi {{nome_paciente}}! A slot just opened up in our schedule for {{data_horario}}. Are you still interested in booking it? Reply to this message to confirm 😊",
  es: '¡Hola {{nome_paciente}}! Se liberó un horario en nuestra agenda para {{data_horario}}. ¿Sigues interesado/a en reservarlo? Responde este mensaje para confirmar 😊',
  fr: "Bonjour {{nome_paciente}} ! Un créneau vient de se libérer dans notre agenda pour {{data_horario}}. Êtes-vous toujours intéressé(e) pour le réserver ? Répondez à ce message pour confirmer 😊",
  it: 'Ciao {{nome_paciente}}! Si è appena liberato uno slot in agenda per {{data_horario}}. Sei ancora interessato/a a prenotarlo? Rispondi a questo messaggio per confermare 😊',
};

/**
 * Template padrão pra oferecer um horário liberado por cancelamento a um
 * paciente da fila de espera, no idioma pedido (`language`, ex.:
 * `i18n.language`) — cai em português quando o idioma não tem tradução
 * própria (mesmo fallback do resto do app).
 */
export function getWaitlistOfferTemplate(language: string): string {
  return WAITLIST_OFFER_TEMPLATE_BY_LANGUAGE[language] ?? WAITLIST_OFFER_TEMPLATE_BY_LANGUAGE.pt;
}

/**
 * Monta a mensagem final de oferta de horário — resolve `{{nome_paciente}}`
 * e `{{data_horario}}` no `template` (por padrão, `getWaitlistOfferTemplate`
 * no idioma pedido) reaproveitando `resolveWhatsAppTemplate`, pronta pra
 * virar o texto do link `wa.me` (`buildReactivationWhatsAppLink`).
 * `dateTimeLabel` chega já formatado pelo chamador (ex.:
 * `format(new Date(scheduledAt), 'PPPp', { locale })`) — esta função não
 * lida com formatação de data, só com substituição de texto.
 */
export function buildWaitlistOfferMessage(
  patientName: string | null | undefined,
  dateTimeLabel: string,
  language: string = 'pt',
): string {
  return resolveWhatsAppTemplate(getWaitlistOfferTemplate(language), {
    nome_paciente: patientName ?? '',
    data_horario: dateTimeLabel,
  });
}
