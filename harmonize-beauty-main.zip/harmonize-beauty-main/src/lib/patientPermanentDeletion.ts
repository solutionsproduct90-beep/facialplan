import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';

// Eliminação real de dados (LGPD art. 18 / GDPR art. 17) — diferente do
// arquivamento (soft-delete, `patients.is_deleted`) já existente em
// EditarPaciente.tsx, que é reversível e mantém tudo no banco. Ver
// supabase/migrations/20260911100000_add_delete_patient_permanently_rpc.sql
// para a decisão de produto completa (o que cai em CASCADE vs. o que já era
// SET NULL de propósito por obrigação regulatória — farmacovigilância).

/**
 * Confere se o texto digitado pelo usuário confirma a exclusão definitiva —
 * precisa bater com o nome do paciente, sem diferenciar maiúsculas/espaços
 * nas pontas (mesma tolerância de digitação de um campo de confirmação, sem
 * abrir mão de exigir o nome certo). Função pura só para poder testar a
 * regra de confirmação sem montar a tela inteira.
 */
export function confirmationMatchesPatientName(input: string, patientName: string): boolean {
  return input.trim().toLowerCase() === patientName.trim().toLowerCase();
}

export interface PermanentDeletionStorageCleanup {
  patientPhotosPaths: string[];
  simulationResultsPaths: string[];
  /**
   * Arquivos que a RPC mandou apagar e que continuam no bucket porque o
   * Storage recusou a remoção. Vazio no caminho normal.
   *
   * Existe porque a alternativa — engolir a falha — fazia a tela declarar
   * "excluído definitivamente" enquanto fotos identificáveis do paciente
   * seguiam no bucket. Numa funcionalidade cujo propósito declarado é cumprir
   * LGPD art. 18 / GDPR art. 17, afirmar conclusão que não aconteceu é o pior
   * modo de falha possível: silencioso dos dois lados, e justamente sobre a
   * obrigação que a funcionalidade existe para cumprir.
   */
  storageCleanupFailedPaths: string[];
}

/**
 * Executa a eliminação definitiva de um paciente: chama a RPC
 * `delete_patient_permanently` (SECURITY DEFINER — apaga em cascata todo
 * dado clínico identificável e grava a trilha de auditoria na mesma
 * transação, ver migration) e, com os storagePaths que ela devolve, remove
 * os arquivos de Storage correspondentes (fotos/PDF em `patient-photos`,
 * simulação de IA em `simulation-results`).
 *
 * A remoção de Storage acontece no client, com a sessão autenticada do
 * próprio profissional — mesmo padrão já usado em
 * SessionRealResultsGallery.tsx — porque Postgres não tem acesso direto ao
 * object store por trás da Storage API.
 *
 * Uma falha nela NÃO é revertida: o hard delete no banco já é definitivo e não
 * deve ficar pendente de uma segunda chamada de rede ter sucesso. Mas ela
 * também não pode ser engolida. Até o ciclo 60 do QA Contínuo esta função
 * dizia, neste mesmo comentário, que a falha "é reportada (não escondida)" —
 * e reportava só para `console.error`, que ninguém lê: o profissional já tinha
 * visto o toast de sucesso e fechado a tela. Agora ela volta em
 * `storageCleanupFailedPaths`, para o chamador contar a verdade, e vai para
 * `error_logs`, para o operador do produto poder reprocessar.
 */
export async function deletePatientPermanently(
  patientId: string,
  /**
   * Quem pediu a exclusão. Só serve para o registro em `error_logs` quando a
   * limpeza de Storage falha — sem ele a falha continua sendo devolvida ao
   * chamador, apenas não vai para o painel de erros.
   */
  professionalId?: string,
): Promise<PermanentDeletionStorageCleanup> {
  const { data, error } = await supabase.rpc('delete_patient_permanently', {
    p_patient_id: patientId,
  });
  if (error) throw error;

  const manifest = data?.[0];
  const patientPhotosPaths = manifest?.patient_photos_paths ?? [];
  const simulationResultsPaths = manifest?.simulation_results_paths ?? [];

  // Quando o `remove()` de um bucket falha, ele falha para o lote inteiro —
  // não há resposta por arquivo. Então o que sobrou são todos os caminhos
  // daquele bucket, e é esse número que a tela precisa dizer.
  const storageCleanupFailedPaths: string[] = [];
  const cleanupErrors: string[] = [];

  if (patientPhotosPaths.length > 0) {
    const { error: photosErr } = await supabase.storage.from('patient-photos').remove(patientPhotosPaths);
    if (photosErr) {
      storageCleanupFailedPaths.push(...patientPhotosPaths);
      cleanupErrors.push(`patient-photos: ${photosErr.message}`);
    }
  }
  if (simulationResultsPaths.length > 0) {
    const { error: simErr } = await supabase.storage.from('simulation-results').remove(simulationResultsPaths);
    if (simErr) {
      storageCleanupFailedPaths.push(...simulationResultsPaths);
      cleanupErrors.push(`simulation-results: ${simErr.message}`);
    }
  }

  if (cleanupErrors.length > 0) {
    // eslint-disable-next-line no-console
    console.error('[patientPermanentDeletion] falha ao remover arquivo(s) de Storage após hard delete', cleanupErrors);

    // O console sozinho não bastava: o profissional já viu "sucesso" e fechou
    // a tela, e o operador do produto não tem como saber que ficou lixo
    // identificável no bucket. Mandar para error_logs põe a falha no
    // Admin > Log de Erros, que é onde alguém pode reprocessar a limpeza à
    // mão. Não inclui caminho de arquivo na mensagem — eles carregam id de
    // paciente, e este é o log de uma exclusão de dado pessoal.
    if (professionalId) {
      logClientError({
        professionalId,
        stage: 'lgpd_hard_delete',
        errorType: 'patient_storage_cleanup_failed',
        message: `${storageCleanupFailedPaths.length} arquivo(s) permanecem no Storage após hard delete :: ${cleanupErrors.join(' | ')}`,
      });
    }
  }

  return { patientPhotosPaths, simulationResultsPaths, storageCleanupFailedPaths };
}
