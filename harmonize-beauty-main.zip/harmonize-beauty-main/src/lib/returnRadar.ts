// Radar de Retorno / Protocolo de Manutenção por Substância — ideia do squad
// de Produto, achado mais forte do ciclo: cada substância injetável perde
// efeito num ritmo diferente, então o momento "certo" de o paciente voltar
// pra manutenção depende da(s) substância(s) da ÚLTIMA sessão CONCLUÍDA
// (status 'complete', mesma definição de "procedimento fechado" já usada em
// src/lib/adminMetrics.ts), não de uma regra fixa de "volte em N meses" igual
// pra todo mundo.
//
// Escopo desta rodada: só cálculo + exibição de uma janela prevista de
// retorno. NÃO dispara nenhum lembrete/notificação automática — isso é outra
// feature (ver supabase/functions/send-reengagement-reminders, que hoje cobre
// só reengajamento de SESSÃO ABANDONADA via src/lib/sessionAbandonment.ts,
// um conceito diferente: sessão nunca fechada, não retorno pós-procedimento).
//
// Janelas de referência (meses a partir da data da última sessão concluída) —
// mesmo espírito de ressalva já usado em PROCEDURE_CATALOG.doseRangeByLevel e
// DOSE_ALERT_THRESHOLD (src/lib/procedureCatalog.ts, src/types/harmonize.ts):
// ponto de partida de ENGENHARIA a partir de consenso geral de literatura/
// prática estética, não validado clinicamente — o profissional sempre pode e
// deve ajustar seu próprio critério de retorno por paciente.
//
// - toxina_botulinica: efeito costuma durar de 3 a 4 meses (duração média
//   citada em literatura/bula de toxina botulínica tipo A), com variação
//   individual por metabolismo/dose/região. Janela de manutenção usada aqui:
//   4-6 meses — um pouco além da duração média citada, cobrindo a prática
//   comum de reaplicar já perto do fim do efeito, antes dele esvair de todo.
// - acido_hialuronico: duração muito mais variável por produto (grau de
//   reticulação/densidade do gel) e por região (zonas de mais movimento, como
//   lábio, duram menos que zonas de pouco movimento, como malar) —
//   literatura geral cita de 6 a 18 meses conforme o caso. Janela usada aqui:
//   9-18 meses — mínimo deliberadamente mais conservador que o piso da
//   literatura (9, não 6) pra não marcar "atrasado" numa aplicação ainda
//   plenamente eficaz na maioria dos casos.
// - bioestimulador: o mais variável dos três. Estimula neocolágeno em vez de
//   preencher volume diretamente — família como ácido poli-L-lático tem
//   efeito clínico percebido tipicamente citado em 18-24+ meses após o
//   protocolo completo. Aqui modelamos só o retorno de MANUTENÇÃO pós-
//   protocolo (12-24 meses); não é escopo desta função saber se a sessão
//   concluída foi a última de uma série de aplicação (protocolo em si costuma
//   ser 2-3 sessões a cada 30-45 dias, um intervalo bem mais curto e já fora
//   do que "retorno para manutenção" quer dizer aqui).
import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { format, type Locale } from 'date-fns';

export type ReturnWindowMonths = { min: number; max: number };

export const SUBSTANCE_RETURN_WINDOW_MONTHS: Record<Substance, ReturnWindowMonths> = {
  toxina_botulinica: { min: 4, max: 6 },
  acido_hialuronico: { min: 9, max: 18 },
  bioestimulador: { min: 12, max: 24 },
};

// Mesmo valor de src/lib/adminMetrics.ts (CLOSED_SESSION_STATUS) — não
// importado de lá porque é um detalhe interno não exportado daquele módulo,
// e duplicar uma constante de 1 string é mais simples que exportar algo só
// pra isso. Ver comentário de arquivo lá para a justificativa completa.
const COMPLETED_SESSION_STATUS = 'complete';

export type ReturnRadar = {
  /** Substância que "dirige" a janela prevista — a de janela mais curta entre
   * as aplicadas na sessão (a que perde efeito primeiro), ver `drivingSubstance`. */
  substance: Substance;
  windowStart: Date;
  windowEnd: Date;
  /** `now` já passou do fim da janela prevista — paciente sem retorno registrado
   * além do que a substância costuma durar. */
  isOverdue: boolean;
};

/** Fatia de `sessions` que este módulo precisa ler — mesmo padrão de tipo
 * "reduzido ao mínimo" de SessionForAdminMetrics/SessionForList em outros
 * arquivos de src/lib. */
export type SessionForReturnRadar = {
  status: string | null;
  created_at: string | null;
  stage2_overlay: unknown;
};

function toDate(value: string | number | Date): Date {
  return value instanceof Date ? value : new Date(value);
}

function addMonths(date: Date, months: number): Date {
  const result = new Date(date.getTime());
  result.setMonth(result.getMonth() + months);
  return result;
}

/** Substâncias distintas presentes numa lista de pontos de aplicação (a
 * mesma forma solta que `sessions.stage2_overlay` guarda, ver ApplicationPoint
 * em src/types/harmonize.ts) — ordem não é garantida, um `Set` por baixo. */
export function substancesInPoints(points: ApplicationPoint[] | null | undefined): Substance[] {
  if (!Array.isArray(points)) return [];
  const found = new Set<Substance>();
  for (const point of points) {
    if (point && typeof point === 'object' && point.substance) {
      found.add(point.substance);
    }
  }
  return Array.from(found);
}

/**
 * A substância que "dirige" a janela de retorno prevista: a de janela mais
 * curta (min, com max como desempate) entre as informadas — ou seja, a que
 * perde efeito primeiro numa sessão com múltiplas substâncias combinadas
 * (ex. toxina + ácido hialurônico na mesma sessão). Decisão deliberada:
 * alertar pelo prazo mais curto é o lado seguro — um paciente "no prazo" pra
 * ácido hialurônico ainda pode estar atrasado pra manutenção da toxina.
 * `null` para lista vazia.
 */
export function drivingSubstance(substances: Substance[]): Substance | null {
  if (substances.length === 0) return null;
  return substances.reduce((soonest, candidate) => {
    const a = SUBSTANCE_RETURN_WINDOW_MONTHS[soonest];
    const b = SUBSTANCE_RETURN_WINDOW_MONTHS[candidate];
    if (b.min !== a.min) return b.min < a.min ? candidate : soonest;
    return b.max < a.max ? candidate : soonest;
  });
}

/**
 * Calcula a janela de retorno prevista a partir da data de uma sessão
 * concluída e dos pontos de aplicação dessa sessão. `null` quando não há
 * nenhuma substância reconhecida nos pontos (sessão sem `stage2_overlay`, ou
 * concluída antes dessa etapa existir) ou a data é inválida.
 */
export function computeReturnRadar(
  lastCompletedSessionDate: string | number | Date,
  points: ApplicationPoint[] | null | undefined,
  now: Date = new Date(),
): ReturnRadar | null {
  const substance = drivingSubstance(substancesInPoints(points));
  if (!substance) return null;

  const baseDate = toDate(lastCompletedSessionDate);
  if (Number.isNaN(baseDate.getTime())) return null;

  const { min, max } = SUBSTANCE_RETURN_WINDOW_MONTHS[substance];
  const windowStart = addMonths(baseDate, min);
  const windowEnd = addMonths(baseDate, max);

  return {
    substance,
    windowStart,
    windowEnd,
    isOverdue: now.getTime() > windowEnd.getTime(),
  };
}

/**
 * A sessão CONCLUÍDA mais recente de uma lista (qualquer ordem de entrada) —
 * `null` se nenhuma tiver `status === 'complete'` ou `created_at` válido.
 * Sessões em aberto (stage1/stage2/stage3) e abandonadas não contam: ainda
 * não geraram um protocolo de fato aplicado.
 */
export function lastCompletedSession<T extends SessionForReturnRadar>(
  sessions: T[] | null | undefined,
): T | null {
  if (!Array.isArray(sessions)) return null;
  let latest: T | null = null;
  let latestTime = -Infinity;
  for (const session of sessions) {
    if (session.status !== COMPLETED_SESSION_STATUS || !session.created_at) continue;
    const time = new Date(session.created_at).getTime();
    if (Number.isNaN(time)) continue;
    if (time > latestTime) {
      latestTime = time;
      latest = session;
    }
  }
  return latest;
}

/**
 * Atalho combinando `lastCompletedSession` + `computeReturnRadar` a partir de
 * uma lista de sessões de um paciente (ex. `patients.sessions` do join usado
 * em Pacientes.tsx, ou `sessions` de PacienteDetalhe.tsx) — a função que as
 * telas de fato chamam.
 */
export function returnRadarForSessions<T extends SessionForReturnRadar>(
  sessions: T[] | null | undefined,
  now: Date = new Date(),
): ReturnRadar | null {
  const last = lastCompletedSession(sessions);
  if (!last || !last.created_at) return null;
  const points = Array.isArray(last.stage2_overlay) ? (last.stage2_overlay as ApplicationPoint[]) : [];
  return computeReturnRadar(last.created_at, points, now);
}

/**
 * Rótulo "mês/ano" pronto pra exibir (ex. "out/2026"), no idioma/locale do
 * date-fns ativo — mesmo padrão de `dateFnsLocale`/`format` já usado em
 * PacienteDetalhe.tsx. Quando início e fim da janela caem em meses
 * diferentes, exibe o intervalo completo ("out/2026 – dez/2026"); no mesmo
 * mês, um único valor.
 */
export function formatReturnRadarWindow(radar: ReturnRadar, locale: Locale): string {
  const startLabel = format(radar.windowStart, 'MMM/yyyy', { locale });
  const endLabel = format(radar.windowEnd, 'MMM/yyyy', { locale });
  return startLabel === endLabel ? startLabel : `${startLabel} – ${endLabel}`;
}
