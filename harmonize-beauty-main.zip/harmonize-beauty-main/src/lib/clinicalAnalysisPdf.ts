import type { Stage1Analysis } from '@/types/harmonize';

export type ClinicalAnalysisRow = { label: string; value: string };

// Pure, jsPDF-agnostic helpers for the "Análise Clínica" section of the PDF
// built in SessaoEstagio3.tsx (patientSummary/facialAnalysis/attentionPoints
// — see src/types/harmonize.ts). Kept separate from the jsPDF drawing code
// so the "does this session have anything to show" and "how do the three
// facialAnalysis sub-fields map to labeled rows" logic can be unit-tested
// without needing jsPDF/canvas in the test environment.

/** Whether there's anything at all to render in the clinical analysis
 * section — all three source fields are optional/additive, so a session
 * with none of them should omit the section entirely rather than draw an
 * empty title. */
export function hasClinicalAnalysisContent(analysis: Stage1Analysis | null | undefined): boolean {
  if (!analysis) return false;
  return Boolean(
    analysis.patientSummary ||
    analysis.facialAnalysis ||
    analysis.facialThirds ||
    analysis.skinTexture ||
    analysis.analysisLimitations ||
    (analysis.attentionPoints && analysis.attentionPoints.length > 0)
  );
}

/** Maps facialAnalysis's three sub-fields to labeled rows, in display order
 * (shape, symmetry, proportions). Returns an empty list when facialAnalysis
 * itself is absent, so callers can loop over the result unconditionally.
 *
 * `analysis` chega ao chamador (SessaoEstagio3.tsx) via cast não validado a
 * partir de `sessions.stage1_analysis` (jsonb) — o tipo `Stage1Analysis`
 * declara shape/symmetry/proportions como `string` obrigatórias, mas isso
 * não é garantido em runtime (dado antigo, gravado por um caminho que
 * antecede a validação atual do servidor, ou editado manualmente). Sem o
 * filtro abaixo, um sub-campo ausente virava a string literal "undefined"
 * desenhada no PDF (jsPDF converte com `String(value)` em vez de lançar) —
 * cosmético, mas seria isto que apareceria no laudo entregue ao paciente. */
export function facialAnalysisRows(
  analysis: Stage1Analysis | null | undefined,
  labels: { shape: string; symmetry: string; proportions: string },
): ClinicalAnalysisRow[] {
  if (!analysis?.facialAnalysis) return [];
  const { shape, symmetry, proportions } = analysis.facialAnalysis;
  return [
    { label: labels.shape, value: shape },
    { label: labels.symmetry, value: symmetry },
    { label: labels.proportions, value: proportions },
  ].filter((row): row is ClinicalAnalysisRow => typeof row.value === 'string' && row.value.trim().length > 0);
}

/** Maps facialThirds's three sub-fields (upper/middle/lower) to labeled rows,
 * same filtering rule as facialAnalysisRows above (a session's stored JSON
 * isn't schema-validated at read time, so a missing/non-string sub-field is
 * dropped instead of rendering "undefined"). Achado do squad
 * Sessões/IA/Apresentação: o PDF final nunca incluía facialThirds, mesmo já
 * aparecendo na Etapa 1. */
export function facialThirdsRows(
  analysis: Stage1Analysis | null | undefined,
  labels: { upper: string; middle: string; lower: string },
): ClinicalAnalysisRow[] {
  if (!analysis?.facialThirds) return [];
  const { upper, middle, lower } = analysis.facialThirds;
  return [
    { label: labels.upper, value: upper },
    { label: labels.middle, value: middle },
    { label: labels.lower, value: lower },
  ].filter((row): row is ClinicalAnalysisRow => typeof row.value === 'string' && row.value.trim().length > 0);
}

/** Whether the professional configured pre/post-procedure care instructions
 * (`profiles.pre_post_care_instructions`, set in Perfil.tsx — backlog P1
 * "Orientações pré/pós-procedimento", v1 reduzida: a single free-text field
 * per professional, not per catalog procedure — that scope reduction is
 * fora de escopo nesta v1, ver comentário em SessaoEstagio3.tsx). Used to
 * decide whether to draw the "Orientações" section in the PDF
 * (SessaoEstagio3.tsx) and whether to append the text to the
 * WhatsApp/e-mail share messages — trimmed so a value that is only
 * whitespace is treated the same as absent, omitting the section/suffix
 * instead of rendering it empty. */
export function hasCareInstructionsContent(instructions: string | null | undefined): boolean {
  return Boolean(instructions && instructions.trim().length > 0);
}
