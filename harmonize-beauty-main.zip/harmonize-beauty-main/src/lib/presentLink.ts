/**
 * Helpers for the public, unauthenticated session-presentation link
 * (`/present/:token`). Kept framework-free so the token shape rules and the
 * URL format can be unit tested without mounting the pages that use them.
 */

// Matches a standard UUID (any RFC 4122 variant/version) — the format
// Postgres' gen_random_uuid() produces for `sessions.present_share_token`.
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Cheap client-side shape check for a present-link token, run before ever
 * calling the `get_session_presentation` RPC. This is NOT the security
 * boundary (the database function is, since it requires an exact match
 * against `present_share_token` AND `present_share_enabled = true`); it only
 * avoids sending obviously-malformed values (empty string, a session id
 * pasted into the wrong slot, script-injection attempts) to the backend and
 * lets the UI show the "invalid link" state immediately.
 */
export function isValidPresentToken(token: string | null | undefined): token is string {
  return typeof token === 'string' && UUID_REGEX.test(token);
}

/**
 * Builds the absolute, shareable presentation URL for a given token.
 * `origin` should be `window.location.origin` at the call site.
 */
export function buildPresentLink(origin: string, token: string): string {
  return `${origin.replace(/\/+$/, '')}/present/${token}`;
}
