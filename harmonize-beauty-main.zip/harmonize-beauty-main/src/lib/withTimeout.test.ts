import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { withTimeout } from "./withTimeout";

describe("withTimeout", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("resolves with the promise's value when it settles before the timeout", async () => {
    const promise = new Promise<string>((resolve) => setTimeout(() => resolve("real value"), 100));
    const result = withTimeout(promise, 1000);
    await vi.advanceTimersByTimeAsync(100);
    expect(await result).toBe("real value");
  });

  it("resolves with null when the timeout elapses before the promise settles", async () => {
    const promise = new Promise<string>((resolve) => setTimeout(() => resolve("too late"), 5000));
    const result = withTimeout(promise, 1000);
    await vi.advanceTimersByTimeAsync(1000);
    expect(await result).toBeNull();
  });

  it("resolves with null when the promise rejects before the timeout", async () => {
    const promise = new Promise<string>((_resolve, reject) => setTimeout(() => reject(new Error("boom")), 100));
    const result = withTimeout(promise, 1000);
    await vi.advanceTimersByTimeAsync(100);
    expect(await result).toBeNull();
  });

  it("does not resolve twice when the promise settles right around the timeout", async () => {
    const promise = new Promise<string>((resolve) => setTimeout(() => resolve("value"), 1000));
    const result = withTimeout(promise, 1000);
    await vi.advanceTimersByTimeAsync(1000);
    // Whichever wins the race, the result must be a single settled value.
    expect(await result).not.toBeUndefined();
  });
});
