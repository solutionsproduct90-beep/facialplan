// Traduz as flags de risco marcadas como `true`/`{ has: true }` em
// `anamnesis.risk_flags` para rótulos legíveis — usado tanto pelo banner de
// alerta do Prontuário (PacienteDetalhe.tsx) quanto pelo banner de
// reconhecimento de risco da Etapa 1 (SessaoEstagio1.tsx), para as duas
// telas mostrarem exatamente a mesma lista.
import {
  COMPOSITE_RISK_KEYS,
  isCompositeRiskActive,
  isRiskFlagActive,
  SIMPLE_RISK_KEYS,
  type CompositeRiskKey,
  type RiskFlags,
  type SimpleRiskKey,
} from '@/types/anamnesis';

type TFunction = (key: string) => string;

/**
 * Retorna os rótulos (já traduzidos) de toda flag de risco marcada como
 * verdadeira, na ordem em que aparecem no formulário. `t` deve ser o `t` de
 * `useTranslation()` do componente chamador — as chaves usadas vivem em
 * `anamnesis.riskLabels.*`.
 */
export function getActiveRiskLabels(flags: RiskFlags | null | undefined, t: TFunction): string[] {
  if (!flags) return [];
  const labels: string[] = [];

  for (const key of SIMPLE_RISK_KEYS as readonly SimpleRiskKey[]) {
    if (isRiskFlagActive(flags, key)) {
      labels.push(t(`anamnesis.riskLabels.${key}`));
    }
  }
  for (const key of COMPOSITE_RISK_KEYS as readonly CompositeRiskKey[]) {
    if (isCompositeRiskActive(flags, key)) {
      labels.push(t(`anamnesis.riskLabels.${key}`));
    }
  }

  return labels;
}
