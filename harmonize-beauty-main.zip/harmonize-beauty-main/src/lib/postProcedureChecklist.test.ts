import { describe, it, expect } from 'vitest';
import {
  substancesInSession,
  hasPostProcedureChecklistContent,
  postProcedureChecklistSections,
  postProcedureChecklistShareText,
  hasVascularRiskWarning,
  postProcedureEmergencyWarning,
} from './postProcedureChecklist';
import type { ApplicationPoint, Substance } from '@/types/harmonize';

function point(substance: Substance, overrides: Partial<ApplicationPoint> = {}): ApplicationPoint {
  return {
    id: `${substance}-${Math.random()}`,
    region: 'testa',
    label: 'Testa',
    substance,
    quantity: 1,
    unit: 'ml',
    x: 0.5,
    y: 0.5,
    source: 'manual',
    ...overrides,
  };
}

describe('substancesInSession', () => {
  it('is empty for no points / null / undefined', () => {
    expect(substancesInSession(null)).toEqual([]);
    expect(substancesInSession(undefined)).toEqual([]);
    expect(substancesInSession([])).toEqual([]);
  });

  it('dedupes repeated substances', () => {
    const points = [point('toxina_botulinica'), point('toxina_botulinica')];
    expect(substancesInSession(points)).toEqual(['toxina_botulinica']);
  });

  it('returns substances in the stable SUBSTANCE_KEYS order regardless of point order', () => {
    const points = [point('bioestimulador'), point('toxina_botulinica'), point('acido_hialuronico')];
    expect(substancesInSession(points)).toEqual(['acido_hialuronico', 'toxina_botulinica', 'bioestimulador']);
  });
});

describe('hasPostProcedureChecklistContent', () => {
  it('is false when there are no points and true when there is at least one', () => {
    expect(hasPostProcedureChecklistContent([])).toBe(false);
    expect(hasPostProcedureChecklistContent(null)).toBe(false);
    expect(hasPostProcedureChecklistContent([point('acido_hialuronico')])).toBe(true);
  });
});

// Mesmo estilo de stub usado para `procedureDisplayName` em
// procedureCatalog.test.ts: devolve a própria chave (ou um array derivado
// dela) em vez de exigir i18next carregado no ambiente de teste.
const fakeTranslate = (key: string, options?: Record<string, unknown>): unknown => {
  if (options?.returnObjects) return [`item-of:${key}`];
  return key;
};

describe('postProcedureChecklistSections', () => {
  it('is empty when the session has no substance', () => {
    expect(postProcedureChecklistSections([], fakeTranslate)).toEqual([]);
  });

  it('maps each used substance to a {substance, label, items} section, via the given translate function', () => {
    const sections = postProcedureChecklistSections([point('toxina_botulinica')], fakeTranslate);
    expect(sections).toEqual([
      {
        substance: 'toxina_botulinica',
        label: 'sessions.stage3.postCareChecklist.substanceLabel.toxina_botulinica',
        items: ['item-of:sessions.stage3.postCareChecklist.items.toxina_botulinica'],
      },
    ]);
  });

  it('includes one section per distinct substance used, in stable order', () => {
    const sections = postProcedureChecklistSections(
      [point('bioestimulador'), point('acido_hialuronico')],
      fakeTranslate,
    );
    expect(sections.map((s) => s.substance)).toEqual(['acido_hialuronico', 'bioestimulador']);
  });
});

describe('postProcedureChecklistShareText', () => {
  it('is an empty string when the session has no substance', () => {
    expect(postProcedureChecklistShareText([], fakeTranslate)).toBe('');
    expect(postProcedureChecklistShareText(null, fakeTranslate)).toBe('');
  });

  it('builds title + note + one bulleted block per substance', () => {
    const text = postProcedureChecklistShareText([point('acido_hialuronico')], fakeTranslate);
    expect(text).toContain('sessions.stage3.postCareChecklist.title:');
    expect(text).toContain('sessions.stage3.postCareChecklist.note');
    expect(text).toContain('SESSIONS.STAGE3.POSTCARECHECKLIST.SUBSTANCELABEL.ACIDO_HIALURONICO');
    expect(text).toContain('• item-of:sessions.stage3.postCareChecklist.items.acido_hialuronico');
  });

  it('includes a block per distinct substance used', () => {
    const text = postProcedureChecklistShareText(
      [point('toxina_botulinica'), point('bioestimulador')],
      fakeTranslate,
    );
    expect(text).toContain('SESSIONS.STAGE3.POSTCARECHECKLIST.SUBSTANCELABEL.TOXINA_BOTULINICA');
    expect(text).toContain('SESSIONS.STAGE3.POSTCARECHECKLIST.SUBSTANCELABEL.BIOESTIMULADOR');
  });
});

// Sinais de Alerta de Emergência (achado de Produto/segurança, 14/09): só
// devem aparecer quando ALGUM ponto de aplicação desta sessão foi de fato
// marcado como zona de risco vascular (ácido hialurônico numa das
// HIGH_VASCULAR_RISK_REGIONS de src/lib/faceRegions.ts) — nunca por "essa
// substância pode ter risco em geral".
describe('hasVascularRiskWarning', () => {
  it('is false with no points / null / undefined', () => {
    expect(hasVascularRiskWarning([])).toBe(false);
    expect(hasVascularRiskWarning(null)).toBe(false);
    expect(hasVascularRiskWarning(undefined)).toBe(false);
  });

  it('is false when acido_hialuronico is applied outside a high-vascular-risk region', () => {
    const points = [point('acido_hialuronico', { region: 'testa' })];
    expect(hasVascularRiskWarning(points)).toBe(false);
  });

  it('is false when a high-vascular-risk region is used with a substance other than acido_hialuronico', () => {
    const points = [point('toxina_botulinica', { region: 'glabela' })];
    expect(hasVascularRiskWarning(points)).toBe(false);
  });

  it('is true when acido_hialuronico is applied in a high-vascular-risk region marked in this session', () => {
    const points = [point('acido_hialuronico', { region: 'glabela' })];
    expect(hasVascularRiskWarning(points)).toBe(true);
  });

  it('is true when only one of several points is a vascular-risk point', () => {
    const points = [
      point('toxina_botulinica', { region: 'terco_frontal' }),
      point('acido_hialuronico', { region: 'sulco_nasolabial_direito' }),
    ];
    expect(hasVascularRiskWarning(points)).toBe(true);
  });
});

describe('postProcedureEmergencyWarning', () => {
  it('is null when the session has no vascular-risk point', () => {
    expect(postProcedureEmergencyWarning([point('acido_hialuronico', { region: 'testa' })], fakeTranslate)).toBeNull();
    expect(postProcedureEmergencyWarning([], fakeTranslate)).toBeNull();
    expect(postProcedureEmergencyWarning(null, fakeTranslate)).toBeNull();
  });

  it('returns {title, intro, signs} when the session has a vascular-risk point, via the given translate function', () => {
    const warning = postProcedureEmergencyWarning([point('acido_hialuronico', { region: 'glabela' })], fakeTranslate);
    expect(warning).toEqual({
      title: 'sessions.stage3.postCareChecklist.emergency.title',
      intro: 'sessions.stage3.postCareChecklist.emergency.intro',
      signs: ['item-of:sessions.stage3.postCareChecklist.emergency.signs'],
    });
  });
});

describe('postProcedureChecklistShareText — emergency section', () => {
  it('does NOT append the emergency block when no point is a vascular-risk point', () => {
    const text = postProcedureChecklistShareText([point('acido_hialuronico', { region: 'testa' })], fakeTranslate);
    expect(text).not.toContain('sessions.stage3.postCareChecklist.emergency.title');
  });

  it('appends the emergency block after the substance sections when a point is a vascular-risk point', () => {
    const text = postProcedureChecklistShareText([point('acido_hialuronico', { region: 'glabela' })], fakeTranslate);
    expect(text).toContain('SESSIONS.STAGE3.POSTCARECHECKLIST.EMERGENCY.TITLE');
    expect(text).toContain('sessions.stage3.postCareChecklist.emergency.intro');
    expect(text).toContain('• item-of:sessions.stage3.postCareChecklist.emergency.signs');
    // Vem depois do bloco por substância, não substitui.
    const checklistIndex = text.indexOf('ACIDO_HIALURONICO');
    const emergencyIndex = text.indexOf('EMERGENCY.TITLE');
    expect(checklistIndex).toBeGreaterThan(-1);
    expect(emergencyIndex).toBeGreaterThan(checklistIndex);
  });
});
