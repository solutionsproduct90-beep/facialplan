// Exportação completa do prontuário pelo paciente (direito de portabilidade
// de dados) — item de compliance/LGPD apontado pelo squad de Produto: até
// aqui esse direito só existia na política de privacidade, sem nenhum fluxo
// funcional que o paciente (ou o profissional em nome dele) pudesse
// efetivamente usar. Ver botão em PacienteDetalhe.tsx.
//
// Formato escolhido: JSON, não PDF. Um PDF pede layout/paginação (ver
// pdfLayout.ts) para o que aqui é essencialmente uma árvore de dados
// (paciente + anamnese + N sessões, cada uma com sua própria análise e
// pontos de aplicação) — implementar isso bem, dentro do tempo disponível,
// é bem mais arriscado do que serializar os mesmos dados que já usam um
// `Anamnesis`/`ApplicationPoint`/`Stage1Analysis` tipados. JSON também é o
// formato mais direto para portabilidade de dados em si (o paciente ou
// outro sistema pode reimportar/reprocessar), o que é o objetivo do
// direito de portabilidade — diferente do PDF do plano (SessaoEstagio3),
// que é pensado para leitura humana, não para reuso de dados.
//
// Exclusão deliberada de custo/margem: `src/lib/budget.ts` já documenta que
// `totalCost`/`margin`/`marginPct` são "visão exclusiva do profissional,
// nunca aparece (...) no PDF do paciente" — mesma regra aplicada aqui.
// `totalPrice` (o valor cobrado do paciente) é mantido, pois é informação
// sobre a própria cobrança do paciente, não um dado interno do negócio do
// profissional.
//
// Proveniência da análise (squad w1-2): cada sessão exportada carrega
// `analysisProvenance` e o arquivo traz, no topo, `analysisProvenanceWarnings`
// quando alguma delas não é uma leitura real de IA. Até então este export
// entregava a análise de DEMONSTRAÇÃO gravada pelo fallback de `analyze-face`
// exatamente com a mesma aparência de uma análise real — um prontuário
// entregue ao paciente ou a um órgão podia conter leitura inventada sem
// nenhuma ressalva. Ver src/lib/analysisProvenance.ts.

import type { Anamnesis } from '@/types/anamnesis';
import type { ApplicationPoint, Insumo, Stage1Analysis } from '@/types/harmonize';
import { computeBudget } from '@/lib/budget';
import { analysisProvenance, type AnalysisProvenance } from '@/lib/analysisProvenance';

export interface PatientForExport {
  id: string;
  name: string;
  phone: string | null;
  email?: string | null;
  birth_date: string | null;
  notes: string | null;
  consent_given: boolean | null;
  last_consent_at: string | null;
  created_at?: string | null;
}

/** Linha crua de `sessions` (mesmo shape retornado por `.select('*')`, ver PacienteDetalhe.tsx). */
export interface SessionRowForExport {
  id: string;
  status?: string | null;
  selected_procedure?: string | null;
  stage1_analysis?: unknown;
  stage2_overlay?: unknown;
  created_at?: string | null;
}

/**
 * Linha crua de `skin_screenings` (triagem ABCDE de lesão cutânea, ver
 * SessaoTriagemPele.tsx).
 */
export interface SkinScreeningRowForExport {
  id: string;
  session_id: string | null;
  asymmetry?: boolean | null;
  irregular_borders?: boolean | null;
  color_variation?: boolean | null;
  diameter_over_6mm?: boolean | null;
  recent_evolution?: boolean | null;
  has_suspicious_finding?: boolean | null;
  lesion_location?: string | null;
  notes?: string | null;
  referred_to_dermatology?: boolean | null;
  proceeded_despite_finding?: boolean | null;
  proceed_justification?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

/**
 * Linha crua de `skin_screening_revisions` — versões substituídas de uma
 * triagem (ver 20260922180000_add_skin_screening_revisions.sql).
 */
export interface SkinScreeningRevisionRowForExport extends SkinScreeningRowForExport {
  screening_id: string;
  recorded_at?: string | null;
  superseded_at?: string | null;
}

/** Linha crua de `consents` (TCLE geral/por procedimento, ver record-consent). */
export interface ConsentRowForExport {
  id: string;
  consent_type?: string | null;
  consent_text?: string | null;
  consent_version?: string | null;
  procedure_summary?: unknown;
  signer_name?: string | null;
  ip_address?: string | null;
  created_at?: string | null;
  session_id?: string | null;
}

/** Linha crua de `adverse_events` (ver AdverseEventsSection.tsx / adverseEvents.ts). */
export interface AdverseEventRowForExport {
  id: string;
  event_type?: string | null;
  severity?: string | null;
  description?: string | null;
  occurred_at?: string | null;
  created_at?: string | null;
  session_id?: string | null;
  insumo_id?: string | null;
}

export type ExportedApplicationPoint = Omit<ApplicationPoint, 'insumoId'> & {
  /** Nome da marca/insumo escolhido para o ponto, resolvido a partir de
   * `insumoId` — nunca o custo/preço unitário do insumo (ver `budget.ts`). */
  insumoBrandName: string | null;
};

export type ExportedSession = {
  id: string;
  status: string | null;
  selectedProcedure: string | null;
  createdAt: string | null;
  /** Análise da IA (Etapa 1) tal como armazenada — não contém nenhum dado
   * de custo/margem, só leitura clínica e sugestões de procedimento. */
  analysis: Stage1Analysis | null;
  /** Proveniência da análise acima: 'ai' (leitura real da IA), 'mock'
   * (análise de DEMONSTRAÇÃO, fabricada pelo fallback quando a IA estava
   * indisponível) ou 'unknown' (sessão anterior ao registro de proveniência —
   * NÃO equivale a 'ai'). Sem este campo, quem recebe o prontuário exportado
   * — o próprio paciente, outro profissional ou um órgão — não tinha como
   * distinguir análise real de conteúdo inventado. Ver
   * src/lib/analysisProvenance.ts. */
  analysisProvenance: AnalysisProvenance;
  applicationPoints: ExportedApplicationPoint[];
  /** Só o que compõe a cobrança do paciente — nunca custo/margem do
   * profissional, ver cabeçalho deste arquivo. */
  budgetSummary: {
    totalPrice: number;
    totalMl: number;
    totalUnits: number;
    currency: string;
  };
};

export type ExportedAdverseEvent = {
  id: string;
  eventType: string | null;
  severity: string | null;
  description: string | null;
  occurredAt: string | null;
  sessionId: string | null;
  insumoBrandName: string | null;
};

/**
 * TCLE (geral ou por procedimento) assinado pelo paciente. Faltava aqui pelo
 * mesmo motivo que `skinScreenings` faltava (ciclo 81): o arquivo se declara
 * "prontuário completo"/portabilidade LGPD e omitia justamente os
 * consentimentos que formalizam a relação profissional-controlador /
 * plataforma-operadora. Achado de auditoria LGPD/Pacientes.
 */
export type ExportedConsent = {
  id: string;
  consentType: string | null;
  consentText: string | null;
  consentVersion: string | null;
  procedureSummary: unknown;
  signerName: string | null;
  ipAddress: string | null;
  createdAt: string | null;
  sessionId: string | null;
};

/**
 * Triagem ABCDE de lesão cutânea, no prontuário exportado.
 *
 * Faltava aqui. O botão promete "prontuário completo" e o módulo se declara
 * como o fluxo de portabilidade de dados da LGPD, mas `skin_screenings` nunca
 * era consultada nem tinha campo onde caber — um paciente que teve uma lesão
 * suspeita encaminhada ao dermatologista recebia um arquivo que se apresenta
 * como completo e omitia justamente o dado clínico mais crítico, sem nenhuma
 * ressalva (ao contrário do aviso de análise de demonstração, que este mesmo
 * arquivo já tratava).
 *
 * `revisions` carrega as versões substituídas (ver o gatilho de
 * 20260922180000_add_skin_screening_revisions.sql): se a triagem foi refeita,
 * a decisão clínica anterior também faz parte do prontuário.
 *
 * Achado do ciclo 81 do QA Contínuo.
 */
export type ExportedSkinScreening = {
  id: string;
  sessionId: string | null;
  recordedAt: string | null;
  criteria: {
    asymmetry: boolean;
    irregularBorders: boolean;
    colorVariation: boolean;
    diameterOver6mm: boolean;
    recentEvolution: boolean;
  };
  hasSuspiciousFinding: boolean;
  lesionLocation: string | null;
  notes: string | null;
  referredToDermatology: boolean;
  proceededDespiteFinding: boolean;
  proceedJustification: string | null;
  revisions: ExportedSkinScreeningRevision[];
};

export type ExportedSkinScreeningRevision = Omit<ExportedSkinScreening, 'id' | 'revisions'> & {
  /** Quando esta versão deixou de valer. */
  supersededAt: string | null;
};

export type PatientRecordExport = {
  exportedAt: string;
  /** Avisos, em linguagem humana e já traduzidos pelo chamador, listados no
   * TOPO do arquivo quando pelo menos uma sessão do prontuário carrega análise
   * de demonstração ou sem origem registrada. O campo por sessão
   * (`analysisProvenance`) é o dado; isto aqui é o que garante que um humano
   * abrindo o JSON — possivelmente sem saber o que 'mock' significa — bata o
   * olho no aviso antes de ler qualquer análise. Ausente (`[]`) quando todas
   * as análises do prontuário são comprovadamente de IA. */
  analysisProvenanceWarnings: string[];
  patient: {
    id: string;
    name: string;
    phone: string | null;
    email: string | null;
    birthDate: string | null;
    notes: string | null;
    consentGiven: boolean;
    lastConsentAt: string | null;
    patientSince: string | null;
  };
  anamnesis: {
    filledBy: 'professional' | 'patient_link';
    createdAt: string;
    reviewedAt: string | null;
    mainComplaint: string | null;
    riskFlags: Anamnesis['risk_flags'];
    clinicalEvaluation: {
      skinType: string | null;
      skinTexture: string | null;
      oiliness: string | null;
      discromia: string[];
      vascularization: string[];
    };
  } | null;
  sessions: ExportedSession[];
  adverseEvents: ExportedAdverseEvent[];
  skinScreenings: ExportedSkinScreening[];
  consents: ExportedConsent[];
};

function isApplicationPointArray(value: unknown): value is ApplicationPoint[] {
  return Array.isArray(value);
}

function toExportedPoint(point: ApplicationPoint, insumoBrandById: Map<string, string>): ExportedApplicationPoint {
  const { insumoId, ...rest } = point;
  return {
    ...rest,
    insumoBrandName: insumoId ? insumoById(insumoBrandById, insumoId) : null,
  };
}

function toExportedScreeningCriteria(row: SkinScreeningRowForExport) {
  return {
    asymmetry: !!row.asymmetry,
    irregularBorders: !!row.irregular_borders,
    colorVariation: !!row.color_variation,
    diameterOver6mm: !!row.diameter_over_6mm,
    recentEvolution: !!row.recent_evolution,
  };
}

function insumoById(map: Map<string, string>, id: string): string | null {
  return map.get(id) ?? null;
}

/**
 * Monta o objeto exportável completo do prontuário de um paciente, a partir
 * dos dados já carregados/consultados pela tela (nenhuma chamada de rede
 * aqui — função pura, testável sem Supabase). `insumos` é usado só para
 * resolver `totalPrice`/nome de marca; seus campos de custo nunca aparecem
 * no resultado.
 */
export function buildPatientRecordExport(input: {
  patient: PatientForExport;
  anamnesis: Anamnesis | null;
  sessions: SessionRowForExport[];
  adverseEvents: AdverseEventRowForExport[];
  /** TCLEs (geral e por procedimento) do paciente. Opcional pelo mesmo
   * motivo de `skinScreenings` abaixo, mas a tela SEMPRE passa. */
  consents?: ConsentRowForExport[];
  /** Triagens ABCDE do paciente, uma por sessão triada. Opcional para não
   * quebrar chamadores antigos, mas a tela SEMPRE passa — omitir aqui é
   * justamente o defeito que o campo existe para fechar. */
  skinScreenings?: SkinScreeningRowForExport[];
  /** Versões substituídas das triagens acima, agrupadas por `screening_id`. */
  skinScreeningRevisions?: SkinScreeningRevisionRowForExport[];
  insumos: Insumo[];
  laborFeePerSession: number | null;
  currency: string;
  /** Textos já traduzidos dos avisos de proveniência (ver
   * `PatientRecordExport.analysisProvenanceWarnings`). Vêm do chamador porque
   * esta função é pura e não conhece i18n — omiti-los mantém o comportamento
   * anterior (nenhum aviso), então nenhum chamador existente quebra, mas a
   * tela do app SEMPRE os passa. */
  provenanceNotices?: { demo: string; unknown: string };
}): PatientRecordExport {
  const { patient, anamnesis, sessions, adverseEvents, consents, skinScreenings, skinScreeningRevisions, insumos, laborFeePerSession, currency, provenanceNotices } = input;

  const insumoBrandById = new Map(insumos.map((i) => [i.id, i.brandName]));

  const exportedSessions: ExportedSession[] = sessions.map((session) => {
    const rawPoints = session.stage2_overlay;
    const points = isApplicationPointArray(rawPoints) ? rawPoints : [];
    const budget = computeBudget(points, insumos, laborFeePerSession);
    const analysis = (session.stage1_analysis as Stage1Analysis | null) ?? null;

    return {
      id: session.id,
      status: session.status ?? null,
      selectedProcedure: session.selected_procedure ?? null,
      createdAt: session.created_at ?? null,
      analysis,
      // Sessão sem nenhuma análise não recebe carimbo de "origem duvidosa" —
      // não há conteúdo clínico a qualificar ali. Só sessões que de fato
      // trazem uma análise entram no cálculo dos avisos abaixo.
      analysisProvenance: analysisProvenance(analysis),
      applicationPoints: points.map((p) => toExportedPoint(p, insumoBrandById)),
      budgetSummary: {
        totalPrice: budget.totalPrice,
        totalMl: budget.totalMl,
        totalUnits: budget.totalUnits,
        currency,
      },
    };
  });

  const exportedAdverseEvents: ExportedAdverseEvent[] = adverseEvents.map((ev) => ({
    id: ev.id,
    eventType: ev.event_type ?? null,
    severity: ev.severity ?? null,
    description: ev.description ?? null,
    occurredAt: ev.occurred_at ?? null,
    sessionId: ev.session_id ?? null,
    insumoBrandName: ev.insumo_id ? insumoById(insumoBrandById, ev.insumo_id) : null,
  }));

  const exportedConsents: ExportedConsent[] = (consents ?? []).map((c) => ({
    id: c.id,
    consentType: c.consent_type ?? null,
    consentText: c.consent_text ?? null,
    consentVersion: c.consent_version ?? null,
    procedureSummary: c.procedure_summary ?? null,
    signerName: c.signer_name ?? null,
    ipAddress: c.ip_address ?? null,
    createdAt: c.created_at ?? null,
    sessionId: c.session_id ?? null,
  }));

  const revisionsByScreening = new Map<string, SkinScreeningRevisionRowForExport[]>();
  (skinScreeningRevisions ?? []).forEach((rev) => {
    const list = revisionsByScreening.get(rev.screening_id) ?? [];
    list.push(rev);
    revisionsByScreening.set(rev.screening_id, list);
  });

  const exportedSkinScreenings: ExportedSkinScreening[] = (skinScreenings ?? []).map((row) => ({
    id: row.id,
    sessionId: row.session_id ?? null,
    recordedAt: row.updated_at ?? row.created_at ?? null,
    criteria: toExportedScreeningCriteria(row),
    hasSuspiciousFinding: !!row.has_suspicious_finding,
    lesionLocation: row.lesion_location ?? null,
    notes: row.notes ?? null,
    referredToDermatology: !!row.referred_to_dermatology,
    proceededDespiteFinding: !!row.proceeded_despite_finding,
    proceedJustification: row.proceed_justification ?? null,
    revisions: (revisionsByScreening.get(row.id) ?? [])
      // Mais antiga primeiro: a ordem em que o prontuário foi sendo reescrito.
      .slice()
      .sort((a, b) => String(a.superseded_at ?? '').localeCompare(String(b.superseded_at ?? '')))
      .map((rev) => ({
        sessionId: rev.session_id ?? null,
        recordedAt: rev.recorded_at ?? null,
        supersededAt: rev.superseded_at ?? null,
        criteria: toExportedScreeningCriteria(rev),
        hasSuspiciousFinding: !!rev.has_suspicious_finding,
        lesionLocation: rev.lesion_location ?? null,
        notes: rev.notes ?? null,
        referredToDermatology: !!rev.referred_to_dermatology,
        proceededDespiteFinding: !!rev.proceeded_despite_finding,
        proceedJustification: rev.proceed_justification ?? null,
      })),
  }));

  // Um aviso por tipo de problema encontrado (nunca um por sessão): o objetivo
  // é que o topo do arquivo diga em uma frase que há análise não confiável
  // dentro, não repetir a mesma frase N vezes. A sessão específica é
  // identificável pelo `analysisProvenance` de cada item de `sessions`.
  const provenanceWarnings: string[] = [];
  if (provenanceNotices) {
    const provenances = new Set(
      exportedSessions.filter((s) => s.analysis).map((s) => s.analysisProvenance),
    );
    if (provenances.has('mock')) provenanceWarnings.push(provenanceNotices.demo);
    if (provenances.has('unknown')) provenanceWarnings.push(provenanceNotices.unknown);
  }

  return {
    exportedAt: new Date().toISOString(),
    analysisProvenanceWarnings: provenanceWarnings,
    patient: {
      id: patient.id,
      name: patient.name,
      phone: patient.phone ?? null,
      email: patient.email ?? null,
      birthDate: patient.birth_date ?? null,
      notes: patient.notes ?? null,
      consentGiven: !!patient.consent_given,
      lastConsentAt: patient.last_consent_at ?? null,
      patientSince: patient.created_at ?? null,
    },
    anamnesis: anamnesis
      ? {
          filledBy: anamnesis.filled_by,
          createdAt: anamnesis.created_at,
          reviewedAt: anamnesis.reviewed_at,
          mainComplaint: anamnesis.main_complaint,
          riskFlags: anamnesis.risk_flags,
          clinicalEvaluation: {
            skinType: anamnesis.skin_type,
            skinTexture: anamnesis.skin_texture,
            oiliness: anamnesis.oiliness,
            discromia: anamnesis.discromia ?? [],
            vascularization: anamnesis.vascularization ?? [],
          },
        }
      : null,
    sessions: exportedSessions,
    adverseEvents: exportedAdverseEvents,
    skinScreenings: exportedSkinScreenings,
    consents: exportedConsents,
  };
}

/**
 * Efeito colateral isolado (fora de `buildPatientRecordExport`, que fica
 * pura/testável sem DOM): serializa e dispara o download do JSON no
 * navegador. jsdom não implementa `URL.createObjectURL` — testes que
 * exercitam este caminho precisam polyfillar, mesmo padrão já usado em
 * NovaSessao.test.tsx para `URL.createObjectURL`.
 */
export function downloadPatientRecordExport(record: PatientRecordExport, filenameBase: string): void {
  const blob = new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filenameBase}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
