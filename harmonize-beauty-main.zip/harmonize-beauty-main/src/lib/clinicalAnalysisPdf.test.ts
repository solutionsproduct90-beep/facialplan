import { describe, it, expect } from "vitest";
import { hasClinicalAnalysisContent, facialAnalysisRows, hasCareInstructionsContent } from "./clinicalAnalysisPdf";
import type { Stage1Analysis } from "@/types/harmonize";

const LABELS = { shape: "Formato do rosto", symmetry: "Simetria", proportions: "Proporções" };

const BASE_ANALYSIS: Stage1Analysis = {
  suggestions: [],
};

describe("hasClinicalAnalysisContent", () => {
  it("is false for null/undefined analysis", () => {
    expect(hasClinicalAnalysisContent(null)).toBe(false);
    expect(hasClinicalAnalysisContent(undefined)).toBe(false);
  });

  it("is false when the analysis has only suggestions (older/degraded format)", () => {
    expect(hasClinicalAnalysisContent(BASE_ANALYSIS)).toBe(false);
  });

  it("is true when patientSummary alone is present", () => {
    expect(hasClinicalAnalysisContent({ ...BASE_ANALYSIS, patientSummary: "Resumo." })).toBe(true);
  });

  it("is true when facialAnalysis alone is present", () => {
    expect(
      hasClinicalAnalysisContent({
        ...BASE_ANALYSIS,
        facialAnalysis: { shape: "Oval", symmetry: "Simétrico", proportions: "Equilibrado" },
      }),
    ).toBe(true);
  });

  it("is true when attentionPoints has at least one entry, false for an empty array", () => {
    expect(hasClinicalAnalysisContent({ ...BASE_ANALYSIS, attentionPoints: ["Achado 1"] })).toBe(true);
    expect(hasClinicalAnalysisContent({ ...BASE_ANALYSIS, attentionPoints: [] })).toBe(false);
  });
});

describe("facialAnalysisRows", () => {
  it("returns an empty list when facialAnalysis is absent", () => {
    expect(facialAnalysisRows(BASE_ANALYSIS, LABELS)).toEqual([]);
    expect(facialAnalysisRows(null, LABELS)).toEqual([]);
  });

  it("maps shape/symmetry/proportions to labeled rows, in that order", () => {
    const analysis: Stage1Analysis = {
      ...BASE_ANALYSIS,
      facialAnalysis: { shape: "Oval", symmetry: "Leve assimetria à direita", proportions: "Terços equilibrados" },
    };

    expect(facialAnalysisRows(analysis, LABELS)).toEqual([
      { label: "Formato do rosto", value: "Oval" },
      { label: "Simetria", value: "Leve assimetria à direita" },
      { label: "Proporções", value: "Terços equilibrados" },
    ]);
  });

  it("drops a sub-field that isn't a non-empty string instead of turning it into the literal 'undefined'", () => {
    // `Stage1Analysis` chega via cast não validado a partir do banco (ver
    // SessaoEstagio3.tsx) — um registro antigo/malformado pode ter
    // facialAnalysis com um sub-campo ausente mesmo o tipo declarando as
    // três chaves como obrigatórias. jsPDF não lança nesse caso: ele
    // desenharia a string literal "undefined" no laudo em vez de omitir a
    // linha — este teste trava esse comportamento.
    const analysis = {
      ...BASE_ANALYSIS,
      facialAnalysis: { shape: "Oval", symmetry: undefined, proportions: "" },
    } as unknown as Stage1Analysis;

    expect(facialAnalysisRows(analysis, LABELS)).toEqual([{ label: "Formato do rosto", value: "Oval" }]);
  });
});

describe("hasCareInstructionsContent", () => {
  it("is false for null, undefined, and empty string", () => {
    expect(hasCareInstructionsContent(null)).toBe(false);
    expect(hasCareInstructionsContent(undefined)).toBe(false);
    expect(hasCareInstructionsContent("")).toBe(false);
  });

  it("is false for a whitespace-only string", () => {
    expect(hasCareInstructionsContent("   \n\t  ")).toBe(false);
  });

  it("is true for actual text, even with surrounding whitespace", () => {
    expect(hasCareInstructionsContent("Evite exposição solar por 48h.")).toBe(true);
    expect(hasCareInstructionsContent("  Evite sol.  ")).toBe(true);
  });
});
