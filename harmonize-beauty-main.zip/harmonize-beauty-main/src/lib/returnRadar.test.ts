import { describe, it, expect } from 'vitest';
import { ptBR } from 'date-fns/locale';
import {
  SUBSTANCE_RETURN_WINDOW_MONTHS,
  substancesInPoints,
  drivingSubstance,
  computeReturnRadar,
  lastCompletedSession,
  returnRadarForSessions,
  formatReturnRadarWindow,
} from './returnRadar';
import type { ApplicationPoint, Substance } from '@/types/harmonize';

const point = (substance: Substance, overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: `p-${substance}-${Math.random()}`,
  region: 'glabela',
  label: 'Glabela',
  substance,
  quantity: 10,
  unit: 'unidades',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

describe('substancesInPoints', () => {
  it('returns the distinct substances present in a list of points', () => {
    const points = [point('toxina_botulinica'), point('acido_hialuronico'), point('toxina_botulinica')];
    expect(substancesInPoints(points)).toEqual(['toxina_botulinica', 'acido_hialuronico']);
  });

  it('returns an empty array for null/undefined/non-array input', () => {
    expect(substancesInPoints(null)).toEqual([]);
    expect(substancesInPoints(undefined)).toEqual([]);
    expect(substancesInPoints('not-an-array' as unknown as ApplicationPoint[])).toEqual([]);
  });

  it('returns an empty array for an empty list', () => {
    expect(substancesInPoints([])).toEqual([]);
  });
});

describe('drivingSubstance', () => {
  it('is null for an empty list', () => {
    expect(drivingSubstance([])).toBeNull();
  });

  it('picks the single substance when only one is present', () => {
    expect(drivingSubstance(['acido_hialuronico'])).toBe('acido_hialuronico');
  });

  it('picks the substance with the shortest window when several are combined (safer side: alerts earliest)', () => {
    // toxina (4-6 meses) esvai muito antes de ácido hialurônico (9-18) ou
    // bioestimulador (12-24) — deve sempre vencer quando presente.
    expect(drivingSubstance(['acido_hialuronico', 'toxina_botulinica'])).toBe('toxina_botulinica');
    expect(drivingSubstance(['bioestimulador', 'toxina_botulinica', 'acido_hialuronico'])).toBe('toxina_botulinica');
    expect(drivingSubstance(['bioestimulador', 'acido_hialuronico'])).toBe('acido_hialuronico');
  });
});

describe('computeReturnRadar', () => {
  const NOW = new Date('2026-09-11T12:00:00Z');

  it('is null when there is no recognized substance in the points', () => {
    expect(computeReturnRadar('2026-01-01T00:00:00Z', [], NOW)).toBeNull();
    expect(computeReturnRadar('2026-01-01T00:00:00Z', null, NOW)).toBeNull();
  });

  it('is null for an unparseable session date', () => {
    expect(computeReturnRadar('not-a-date', [point('toxina_botulinica')], NOW)).toBeNull();
  });

  it('computes the window from the driving substance, months added to the session date', () => {
    const radar = computeReturnRadar('2026-01-10T00:00:00Z', [point('toxina_botulinica')], NOW);
    expect(radar).not.toBeNull();
    expect(radar!.substance).toBe('toxina_botulinica');
    expect(radar!.windowStart.toISOString().slice(0, 7)).toBe('2026-05'); // +4 meses
    expect(radar!.windowEnd.toISOString().slice(0, 7)).toBe('2026-07'); // +6 meses
  });

  it('flags isOverdue once now is past the end of the window', () => {
    // Sessão de toxina há 8 meses (janela: 4-6 meses) — já passou do fim.
    const overdue = computeReturnRadar('2026-01-01T00:00:00Z', [point('toxina_botulinica')], NOW);
    expect(overdue!.isOverdue).toBe(true);

    // Sessão de ácido hialurônico há 8 meses (janela: 9-18 meses) — ainda não.
    const notOverdue = computeReturnRadar('2026-01-01T00:00:00Z', [point('acido_hialuronico')], NOW);
    expect(notOverdue!.isOverdue).toBe(false);
  });

  it('uses the shortest window among multiple substances applied in the same session', () => {
    const radar = computeReturnRadar(
      '2026-01-10T00:00:00Z',
      [point('acido_hialuronico'), point('toxina_botulinica')],
      NOW,
    );
    expect(radar!.substance).toBe('toxina_botulinica');
  });
});

describe('SUBSTANCE_RETURN_WINDOW_MONTHS', () => {
  it('every window has min <= max', () => {
    for (const window of Object.values(SUBSTANCE_RETURN_WINDOW_MONTHS)) {
      expect(window.min).toBeLessThanOrEqual(window.max);
    }
  });
});

describe('lastCompletedSession', () => {
  it('is null for no sessions, or none completed', () => {
    expect(lastCompletedSession(null)).toBeNull();
    expect(lastCompletedSession([])).toBeNull();
    expect(
      lastCompletedSession([{ status: 'stage2', created_at: '2026-01-01T00:00:00Z', stage2_overlay: null }]),
    ).toBeNull();
  });

  it('picks the most recent completed session, ignoring open/abandoned ones', () => {
    const older = { status: 'complete', created_at: '2026-01-01T00:00:00Z', stage2_overlay: null };
    const newer = { status: 'complete', created_at: '2026-06-01T00:00:00Z', stage2_overlay: null };
    const openMoreRecent = { status: 'stage2', created_at: '2026-08-01T00:00:00Z', stage2_overlay: null };
    expect(lastCompletedSession([older, newer, openMoreRecent])).toBe(newer);
  });

  it('ignores a completed row with a missing/invalid created_at', () => {
    const bad = { status: 'complete', created_at: null, stage2_overlay: null };
    const good = { status: 'complete', created_at: '2026-01-01T00:00:00Z', stage2_overlay: null };
    expect(lastCompletedSession([bad, good])).toBe(good);
  });
});

describe('returnRadarForSessions', () => {
  const NOW = new Date('2026-09-11T12:00:00Z');

  it('is null when there is no completed session', () => {
    expect(returnRadarForSessions([{ status: 'stage1', created_at: '2026-01-01T00:00:00Z', stage2_overlay: null }], NOW)).toBeNull();
  });

  it('computes the radar from the most recent completed session overlay', () => {
    const radar = returnRadarForSessions(
      [
        { status: 'complete', created_at: '2026-01-01T00:00:00Z', stage2_overlay: [point('acido_hialuronico')] },
        { status: 'complete', created_at: '2026-06-01T00:00:00Z', stage2_overlay: [point('toxina_botulinica')] },
      ],
      NOW,
    );
    expect(radar!.substance).toBe('toxina_botulinica');
  });
});

describe('formatReturnRadarWindow', () => {
  it('renders a single month/year when start and end fall in the same month', () => {
    const radar = computeReturnRadar('2026-01-01T00:00:00Z', [{ ...point('toxina_botulinica') }], new Date('2026-09-11T12:00:00Z'));
    // janela real (4-6 meses) cai em meses diferentes; força um caso de mês único
    const sameMonthRadar = { ...radar!, windowEnd: radar!.windowStart };
    expect(formatReturnRadarWindow(sameMonthRadar, ptBR)).toMatch(/^[a-z]{3}\/2026$/);
  });

  it('renders a range when start and end fall in different months', () => {
    const radar = computeReturnRadar('2026-01-10T00:00:00Z', [point('toxina_botulinica')], new Date('2026-09-11T12:00:00Z'));
    expect(formatReturnRadarWindow(radar!, ptBR)).toBe('mai/2026 – jul/2026');
  });
});
