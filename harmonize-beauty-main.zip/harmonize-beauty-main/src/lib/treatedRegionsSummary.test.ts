import { describe, it, expect } from 'vitest';
import { ptBR } from 'date-fns/locale';
import {
  treatedRegionsSummary,
  formatTreatedRegionSince,
  type SessionForTreatedRegions,
} from './treatedRegionsSummary';
import type { ApplicationPoint, Substance } from '@/types/harmonize';

const point = (region: string, overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: `p-${region}-${Math.random()}`,
  region,
  label: '',
  substance: 'toxina_botulinica' as Substance,
  quantity: 10,
  unit: 'unidades',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

const session = (overrides: Partial<SessionForTreatedRegions> = {}): SessionForTreatedRegions => ({
  status: 'complete',
  created_at: '2026-01-10T00:00:00.000Z',
  stage2_overlay: [],
  ...overrides,
});

describe('treatedRegionsSummary', () => {
  it('returns an empty array for null/undefined/empty input', () => {
    expect(treatedRegionsSummary(null)).toEqual([]);
    expect(treatedRegionsSummary(undefined)).toEqual([]);
    expect(treatedRegionsSummary([])).toEqual([]);
  });

  it('ignores sessions that are not complete, or missing/invalid created_at', () => {
    const sessions = [
      session({ status: 'stage2', created_at: '2026-01-01T00:00:00.000Z', stage2_overlay: [point('glabela')] }),
      session({ status: 'complete', created_at: null, stage2_overlay: [point('glabela')] }),
      session({ status: 'complete', created_at: 'not-a-date', stage2_overlay: [point('glabela')] }),
    ];
    expect(treatedRegionsSummary(sessions)).toEqual([]);
  });

  it('ignores a session with no points, or a malformed stage2_overlay', () => {
    const sessions = [
      session({ stage2_overlay: [] }),
      session({ stage2_overlay: null }),
      session({ stage2_overlay: 'not-an-array' }),
    ];
    expect(treatedRegionsSummary(sessions)).toEqual([]);
  });

  it('summarizes a single region treated across multiple sessions', () => {
    const sessions = [
      session({ created_at: '2026-01-10T00:00:00.000Z', stage2_overlay: [point('glabela', { label: 'Glabela' })] }),
      session({ created_at: '2026-03-05T00:00:00.000Z', stage2_overlay: [point('glabela', { label: 'Glabela' })] }),
      session({ created_at: '2026-05-20T00:00:00.000Z', stage2_overlay: [point('glabela', { label: 'Glabela' })] }),
    ];

    const summary = treatedRegionsSummary(sessions);
    expect(summary).toEqual([
      {
        region: 'glabela',
        label: 'Glabela',
        firstTreatedAt: new Date('2026-01-10T00:00:00.000Z'),
        sessionCount: 3,
      },
    ]);
  });

  it('counts multiple points in the same region/session as a single session (e.g. a toxin group)', () => {
    const sessions = [
      session({
        created_at: '2026-01-10T00:00:00.000Z',
        stage2_overlay: [
          point('glabela', { label: 'Glabela', groupId: 'g1' }),
          point('glabela', { label: 'Glabela', groupId: 'g1' }),
          point('glabela', { label: 'Glabela', groupId: 'g1' }),
        ],
      }),
    ];

    const summary = treatedRegionsSummary(sessions);
    expect(summary).toHaveLength(1);
    expect(summary[0].sessionCount).toBe(1);
  });

  it('summarizes multiple regions independently, sorted chronologically by first treatment', () => {
    const sessions = [
      // Sessão mais recente primeiro na lista de entrada — a função não deve
      // depender da ordem de chegada.
      session({
        created_at: '2026-03-01T00:00:00.000Z',
        stage2_overlay: [point('malar_direita', { label: 'Região Malar Direita' })],
      }),
      session({
        created_at: '2026-01-15T00:00:00.000Z',
        stage2_overlay: [
          point('glabela', { label: 'Glabela' }),
          point('sulco_nasolabial_direito', { label: 'Sulco Nasolabial Direito' }),
        ],
      }),
      session({
        created_at: '2026-02-01T00:00:00.000Z',
        stage2_overlay: [point('glabela', { label: 'Glabela' })],
      }),
    ];

    const summary = treatedRegionsSummary(sessions);
    expect(summary.map((r) => r.region)).toEqual(['glabela', 'sulco_nasolabial_direito', 'malar_direita']);
    expect(summary.find((r) => r.region === 'glabela')).toMatchObject({
      sessionCount: 2,
      firstTreatedAt: new Date('2026-01-15T00:00:00.000Z'),
    });
    expect(summary.find((r) => r.region === 'sulco_nasolabial_direito')).toMatchObject({ sessionCount: 1 });
    expect(summary.find((r) => r.region === 'malar_direita')).toMatchObject({ sessionCount: 1 });
  });

  it('never includes a region that was never actually treated (no zero-session entries)', () => {
    const sessions = [session({ stage2_overlay: [point('glabela')] })];
    const summary = treatedRegionsSummary(sessions);
    expect(summary.every((r) => r.sessionCount > 0)).toBe(true);
    expect(summary.some((r) => r.region === 'malar_esquerda')).toBe(false);
  });

  it('falls back to regionLabel(region) when the point has no label', () => {
    const sessions = [session({ stage2_overlay: [point('malar_esquerda', { label: '' })] })];
    expect(treatedRegionsSummary(sessions)[0].label).toBe('Região Malar Esquerda');
  });
});

describe('formatTreatedRegionSince', () => {
  it('formats a date as month/year in the given locale', () => {
    expect(formatTreatedRegionSince(new Date('2026-01-10T00:00:00.000Z'), ptBR)).toMatch(/jan\/2026/i);
  });
});
