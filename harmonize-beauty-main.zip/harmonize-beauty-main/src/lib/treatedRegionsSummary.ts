// Indicador Qualitativo de Regiões Tratadas — proposto por um comitê de
// revisão como ALTERNATIVA ao "score de harmonia em percentual" (decisão de
// produto já REJEITADA por ser pseudo-precisão de IA sem lastro clínico
// mensurável — mesma justificativa de design já registrada em
// FacialStructureAnalysis/FacialThirdsAnalysis, src/types/harmonize.ts).
// Em vez de um número, mostra de forma descritiva QUAIS regiões faciais já
// foram acompanhadas ao longo da linha do tempo do paciente: desde quando e
// em quantas sessões. Deliberadamente sem nenhuma nota numérica de
// qualidade/harmonia — só data e contagem de sessões.
//
// Reaproveita a mesma fonte de dados que a Linha do Tempo Evolutiva
// (PatientEvolutionTimeline.tsx, entregue na onda P3): sessões CONCLUÍDAS do
// paciente, cujo `stage2_overlay` guarda os ApplicationPoint[] efetivamente
// aplicados (não as meras Suggestion[] do Estágio 1, que podem nunca ter
// virado aplicação de fato).
import { format, type Locale } from 'date-fns';
import type { ApplicationPoint } from '@/types/harmonize';
import { regionLabel } from '@/lib/faceRegions';

const COMPLETED_SESSION_STATUS = 'complete';

/** Fatia de `sessions` que esta função precisa ler — mesmo padrão de tipo
 * "reduzido ao mínimo" de SessionForReturnRadar em src/lib/returnRadar.ts. */
export type SessionForTreatedRegions = {
  status: string | null;
  created_at: string | null;
  stage2_overlay: unknown;
};

export type TreatedRegionSummary = {
  /** Slug da região, ex. "glabela" — ver FaceRegionKey em src/lib/faceRegions.ts. */
  region: string;
  /** Nome legível, ex. "Glabela" — de ApplicationPoint.label quando presente
   * na sessão mais antiga que tratou a região, senão de regionLabel(region). */
  label: string;
  /** Data da sessão CONCLUÍDA mais antiga que tratou esta região — "desde
   * quando" ela é acompanhada. */
  firstTreatedAt: Date;
  /** Quantas sessões CONCLUÍDAS distintas trataram esta região — não a
   * contagem de pontos: vários pontos na mesma sessão e região (ex. glabela
   * com `groupId`, várias aplicações de toxina na mesma sessão) contam como
   * 1 sessão para aquela região, não uma por ponto. */
  sessionCount: number;
};

function pointsOf(session: SessionForTreatedRegions): ApplicationPoint[] {
  return Array.isArray(session.stage2_overlay) ? (session.stage2_overlay as ApplicationPoint[]) : [];
}

/**
 * Resume, por região facial, desde quando ela é acompanhada e em quantas
 * sessões concluídas foi tratada — puramente descritivo (data + contagem),
 * sem nenhuma nota numérica de qualidade/harmonia (ver cabeçalho do
 * arquivo). Só sessões `status === 'complete'` com `created_at` válido
 * entram na conta (mesma definição de "procedimento fechado" usada em
 * `returnRadarForSessions`); uma região nunca tratada simplesmente não
 * aparece no resultado — não há entrada com `sessionCount: 0`.
 *
 * Aceita as sessões em qualquer ordem (a tela busca em ordem decrescente de
 * `created_at`; esta função não depende disso). Resultado sempre ordenado
 * da região acompanhada há mais tempo para a mais recente — mesmo sentido
 * cronológico "mais antiga primeiro" da Linha do Tempo Evolutiva.
 */
export function treatedRegionsSummary<T extends SessionForTreatedRegions>(
  sessions: T[] | null | undefined
): TreatedRegionSummary[] {
  const byRegion = new Map<string, { label: string; firstTreatedAt: Date; sessionCount: number }>();

  for (const session of sessions ?? []) {
    if (session.status !== COMPLETED_SESSION_STATUS || !session.created_at) continue;
    const time = new Date(session.created_at).getTime();
    if (Number.isNaN(time)) continue;

    // Regiões distintas tratadas NESTA sessão — dedupe antes de contar, pra
    // vários pontos na mesma região/sessão não inflarem `sessionCount`.
    const regionsInSession = new Map<string, string>();
    for (const point of pointsOf(session)) {
      if (!point || typeof point !== 'object' || !point.region) continue;
      if (!regionsInSession.has(point.region)) {
        regionsInSession.set(point.region, point.label || regionLabel(point.region));
      }
    }

    for (const [region, label] of regionsInSession) {
      const existing = byRegion.get(region);
      if (!existing) {
        byRegion.set(region, { label, firstTreatedAt: new Date(time), sessionCount: 1 });
        continue;
      }
      existing.sessionCount += 1;
      if (time < existing.firstTreatedAt.getTime()) {
        existing.firstTreatedAt = new Date(time);
        existing.label = label; // rótulo da sessão mais antiga que tratou a região
      }
    }
  }

  return Array.from(byRegion.entries())
    .map(([region, v]) => ({ region, label: v.label, firstTreatedAt: v.firstTreatedAt, sessionCount: v.sessionCount }))
    .sort((a, b) => a.firstTreatedAt.getTime() - b.firstTreatedAt.getTime());
}

/**
 * Rótulo "mês/ano" pronto pra exibir (ex. "jan/2026"), no idioma/locale do
 * date-fns ativo — mesmo padrão de `formatReturnRadarWindow` em
 * src/lib/returnRadar.ts.
 */
export function formatTreatedRegionSince(date: Date, locale: Locale): string {
  return format(date, 'MMM/yyyy', { locale });
}
