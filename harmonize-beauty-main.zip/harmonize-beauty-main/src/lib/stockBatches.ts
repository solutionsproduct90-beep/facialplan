import type { ApplicationPoint } from '@/types/harmonize';

// Rastreio por LOTE/VALIDADE do estoque de insumos (ERP completo, evolução
// do controle "mini" de src/lib/stock.ts — ver comentário de escopo em
// 20260910190100_add_insumo_stock.sql, que já apontava lote/validade e
// decremento automático como próximos passos). `insumos.quantity_on_hand`
// continua sendo o saldo agregado (mantido pelo trigger existente sobre
// `insumo_stock_movements`); esta tabela nova (`insumo_stock_batches`)
// adiciona o detalhe de QUAIS lotes compõem esse saldo, pra permitir
// consumo FEFO (first-expire-first-out) e alerta de vencimento.

/** Linha de `insumo_stock_batches`, normalizada pro shape usado pelo app. */
export type InsumoStockBatch = {
  id: string;
  insumoId: string;
  batchNumber: string;
  expiresOn: string | null; // YYYY-MM-DD, ausente quando o insumo não tem validade rastreada
  quantityReceived: number;
  quantityRemaining: number;
  receivedOn: string; // YYYY-MM-DD
};

/**
 * Normaliza linhas de `insumo_stock_batches` vindas do Supabase — mesma
 * postura defensiva de `normalizeInsumoStock` em src/lib/stock.ts: linha
 * malformada é descartada, não quebra a lista inteira.
 */
export function normalizeStockBatches(raw: unknown): InsumoStockBatch[] {
  if (!Array.isArray(raw)) return [];
  const out: InsumoStockBatch[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.insumo_id !== 'string' || !r.insumo_id) continue;
    if (typeof r.batch_number !== 'string' || !r.batch_number) continue;
    const quantityReceived = Number(r.quantity_received);
    const quantityRemaining = Number(r.quantity_remaining);
    if (!Number.isFinite(quantityReceived) || !Number.isFinite(quantityRemaining)) continue;
    if (typeof r.received_on !== 'string' || !r.received_on) continue;
    out.push({
      id: r.id,
      insumoId: r.insumo_id,
      batchNumber: r.batch_number,
      expiresOn: typeof r.expires_on === 'string' ? r.expires_on : null,
      quantityReceived,
      quantityRemaining,
      receivedOn: r.received_on,
    });
  }
  return out;
}

/**
 * Ordena lotes pela política FEFO (first-expire-first-out): validade mais
 * próxima primeiro. Lotes sem validade cadastrada (insumo sem rastreamento
 * de vencimento) vão por último, na ordem de desempate — o que faz a
 * política cair automaticamente em FIFO puro (por `receivedOn`) quando
 * nenhum lote do insumo tem validade, sem precisar de um ramo separado.
 * Desempate final por `id` para um resultado 100% determinístico mesmo com
 * timestamps idênticos. Não muta a lista recebida.
 */
export function sortBatchesFefo(batches: InsumoStockBatch[]): InsumoStockBatch[] {
  return [...batches].sort((a, b) => {
    if (a.expiresOn !== b.expiresOn) {
      if (a.expiresOn == null) return 1;
      if (b.expiresOn == null) return -1;
      return a.expiresOn < b.expiresOn ? -1 : 1;
    }
    if (a.receivedOn !== b.receivedOn) return a.receivedOn < b.receivedOn ? -1 : 1;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });
}

export type FefoConsumptionStep = { batchId: string; quantity: number };
export type FefoConsumptionPlan = {
  steps: FefoConsumptionStep[];
  /** Parte da quantidade pedida que não coube em nenhum lote com saldo — sinal para registrar a movimentação "solta" (sem lote) descrito no item 2 do escopo, nunca para travar o fluxo. */
  unmatchedQuantity: number;
};

/**
 * Monta o plano de consumo FEFO para uma quantidade de saída: percorre os
 * lotes com saldo (`quantityRemaining > 0`) na ordem de `sortBatchesFefo`,
 * tirando de cada um até esgotar a quantidade pedida ou os lotes. Espelha
 * exatamente a lógica de `public.consume_insumo_stock_fefo` (ver migration
 * 20260911040000_add_insumo_stock_batches.sql) — mantida aqui em TypeScript
 * puro só para ser testável sem banco; a decisão real de negócio acontece
 * no servidor (a mesma função SQL), não aqui.
 *
 * Nunca lança: pedir mais do que existe em lotes simplesmente devolve
 * `unmatchedQuantity > 0`, permitindo ao chamador registrar essa sobra como
 * uma movimentação sem lote em vez de bloquear a conclusão da sessão.
 */
export function computeFefoConsumption(batches: InsumoStockBatch[], quantity: number): FefoConsumptionPlan {
  if (!Number.isFinite(quantity) || quantity <= 0) return { steps: [], unmatchedQuantity: 0 };

  const ordered = sortBatchesFefo(batches.filter((b) => b.quantityRemaining > 0));
  const steps: FefoConsumptionStep[] = [];
  let remaining = quantity;

  for (const batch of ordered) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, batch.quantityRemaining);
    if (take <= 0) continue;
    steps.push({ batchId: batch.id, quantity: take });
    remaining -= take;
  }

  // Arredonda ruído de ponto flutuante (ex.: 0.1 + 0.2) antes de expor —
  // mesma preocupação de outras somas de quantidade no app (ver
  // addPointToGroup em src/lib/applicationPoints.ts).
  return { steps, unmatchedQuantity: Math.round(remaining * 100) / 100 };
}

const MS_PER_DAY = 24 * 60 * 60 * 1000;

/** Dias corridos até a validade (negativo = já vencido), ou null se o lote não tem validade cadastrada. Ambas as datas são comparadas à meia-noite local, então "vence hoje" dá 0, não uma fração de dia. */
export function daysUntilExpiry(expiresOn: string | null | undefined, now: Date = new Date()): number | null {
  if (!expiresOn) return null;
  const expiry = new Date(`${expiresOn}T00:00:00`);
  if (Number.isNaN(expiry.getTime())) return null;
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((expiry.getTime() - today.getTime()) / MS_PER_DAY);
}

/**
 * "Vencendo em breve": lote com validade cadastrada, saldo positivo, e
 * dentro da janela de alerta (30 dias por padrão, inclui já vencido — um
 * lote vencido é ainda mais urgente que um vencendo em breve, não deixa de
 * ser um alerta). Lote sem validade cadastrada nunca entra aqui — ausência
 * de validade não é tratada como "vence logo".
 */
export function isBatchExpiringSoon(batch: InsumoStockBatch, withinDays = 30, now: Date = new Date()): boolean {
  if (batch.quantityRemaining <= 0) return false;
  const days = daysUntilExpiry(batch.expiresOn, now);
  return days != null && days <= withinDays;
}

export type ExpiryDescriptor =
  | { kind: 'expired'; daysAgo: number }
  | { kind: 'today' }
  | { kind: 'upcoming'; daysLeft: number };

/**
 * Classifica um resultado de `daysUntilExpiry` em uma das 3 formas que a UI
 * precisa mostrar (vencido há N dias / vence hoje / vence em N dias) — a
 * tradução do texto exato (incluindo plural) fica a cargo de quem chama,
 * via i18next (`stock.batches.expiredDaysAgo`/`expiresToday`/`expiresInDays`
 * nos arquivos de locale), esta função só decide QUAL forma usar a partir de
 * um número de dias já calculado.
 */
export function describeExpiryDays(days: number): ExpiryDescriptor {
  if (days < 0) return { kind: 'expired', daysAgo: Math.abs(days) };
  if (days === 0) return { kind: 'today' };
  return { kind: 'upcoming', daysLeft: days };
}

/** Filtra e ordena (validade mais próxima/mais vencida primeiro) os lotes com saldo que estão vencendo em breve — o que alimenta o banner de alerta na aba Estoque. */
export function batchesExpiringSoon(batches: InsumoStockBatch[], withinDays = 30, now: Date = new Date()): InsumoStockBatch[] {
  return batches
    .filter((b) => isBatchExpiringSoon(b, withinDays, now))
    .sort((a, b) => (a.expiresOn! < b.expiresOn! ? -1 : a.expiresOn! > b.expiresOn! ? 1 : 0));
}

/** Soma o saldo de todos os lotes de um insumo — usado só como conferência independente de `insumos.quantity_on_hand` (que o trigger do banco mantém a partir de `insumo_stock_movements`), do mesmo jeito que `computeStockBalance` em src/lib/stock.ts confere o saldo a partir do histórico de movimentações. */
export function totalBatchQuantity(batches: InsumoStockBatch[]): number {
  return batches.reduce((sum, b) => sum + b.quantityRemaining, 0);
}

/**
 * Agrega a quantidade total consumida por insumo a partir dos pontos de
 * aplicação de uma sessão (`sessions.stage2_overlay`) — item 2 do escopo:
 * "quando uma sessão é concluída [...] decrementar a quantidade do(s)
 * lote(s) [...] daquele insumo/marca". Pontos sem `insumoId` (criados antes
 * da feature de marca por ponto, ou substância sem nenhuma marca cadastrada
 * — ver comentário de `ApplicationPoint.insumoId` em src/types/harmonize.ts)
 * são ignorados aqui: não há insumo pra decrementar, e isso nunca deve
 * travar a conclusão da sessão.
 */
export function aggregateConsumptionByInsumo(
  points: Pick<ApplicationPoint, 'insumoId' | 'quantity'>[],
): Map<string, number> {
  const totals = new Map<string, number>();
  for (const point of points) {
    if (!point.insumoId || !Number.isFinite(point.quantity) || point.quantity <= 0) continue;
    totals.set(point.insumoId, Math.round(((totals.get(point.insumoId) ?? 0) + point.quantity) * 100) / 100);
  }
  return totals;
}
