import { supabase } from '@/integrations/supabase/client';

/**
 * Registro de falha no cliente, gravado em `error_logs` sem bloquear a UI.
 *
 * POR QUE ESTA FUNÇÃO EXISTE, E POR QUE ELA CHAMA `.then()`:
 *
 * Oito lugares do app faziam `void supabase.from('error_logs').insert({...})`
 * para registrar uma falha sem travar o usuário. O padrão parece idiomático —
 * é o mesmo `void` que funciona com Promise nativa e com função `async` de
 * verdade. Com o builder do postgrest-js ele não funciona, e falha em
 * silêncio: NENHUM desses logs jamais chegou ao banco.
 *
 * A razão está no próprio postgrest-js (v2.116.0, `PostgrestBuilder`): a
 * classe implementa `PromiseLike`, não estende `Promise`. Montar a cadeia
 * `.from().insert()` é 100% síncrono e não dispara nada; o `fetch` só é
 * construído e chamado DENTRO do método `then()`. `void` descarta o objeto
 * sem nunca chamar `then()`, então a requisição não existe. Reproduzido
 * contra a biblioteca real com um `fetch` instrumentado: zero chamadas com
 * `void`, uma chamada com `.then()`.
 *
 * Esta classe de bug é invisível dos dois lados: o usuário não vê erro
 * nenhum, porque o app segue funcionando, e a suíte não pega, porque um mock
 * de `supabase` normalmente verifica se `.insert()` foi CHAMADO com os
 * argumentos certos — o que acontece, já que montar a cadeia é síncrono —
 * sem verificar se alguém consumiu o resultado.
 *
 * O impacto ia além dos logs perdidos: o painel AdminErros e a rotina
 * `alert-error-spike` leem essa tabela. Enquanto esses oito pontos não
 * gravavam, os dois estavam cegos para as falhas que eles deveriam reportar.
 *
 * `src/test/fireAndForgetSupabase.test.ts` impede a reintrodução do padrão.
 */
export interface ClientErrorLog {
  /** `profiles.id` de quem estava usando o app. Sem ele não há o que gravar. */
  professionalId: string;
  /** Sessão em que a falha aconteceu, quando existe uma. */
  sessionId?: string | null;
  /** Etapa do app, na mesma taxonomia já usada na tabela: 'present', 'anamnesis', 'export_pdf'… */
  stage: string;
  /** Identificador estável da falha, para agrupar no painel: 'pdf_export_failed'… */
  errorType: string;
  /** Descrição. Truncada em 500 caracteres aqui, não em cada chamador. */
  message: string;
}

/** Mesmo limite que os oito chamadores aplicavam à mão antes deste helper. */
const MAX_MESSAGE = 500;

export function logClientError({
  professionalId,
  sessionId = null,
  stage,
  errorType,
  message,
}: ClientErrorLog): void {
  supabase
    .from('error_logs')
    .insert({
      professional_id: professionalId,
      session_id: sessionId,
      stage,
      error_type: errorType,
      message: message.slice(0, MAX_MESSAGE),
    })
    // Falhar ao gravar o log de uma falha não pode virar outro erro na tela,
    // nem uma unhandled rejection no console. O segundo argumento de `then`
    // engole a rejeição; o primeiro existe só para disparar o fetch.
    .then(
      () => {},
      () => {},
    );
}
