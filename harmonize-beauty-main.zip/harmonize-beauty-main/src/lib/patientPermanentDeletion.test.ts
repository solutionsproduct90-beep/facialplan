import { describe, it, expect, vi, beforeEach } from 'vitest';
import { confirmationMatchesPatientName, deletePatientPermanently } from './patientPermanentDeletion';

const rpcMock = vi.fn();
const storageRemoveMock = vi.fn();
const storageFromMock = vi.fn((_bucket: string) => ({ remove: storageRemoveMock }));
const logClientErrorMock = vi.fn();

vi.mock('@/lib/logClientError', () => ({
  logClientError: (...args: unknown[]) => logClientErrorMock(...args),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    rpc: (...args: unknown[]) => rpcMock(...args),
    storage: { from: (bucket: string) => storageFromMock(bucket) },
  },
}));

describe('confirmationMatchesPatientName', () => {
  it('requires an exact match (case/whitespace-insensitive) of the patient full name', () => {
    expect(confirmationMatchesPatientName('Maria Silva', 'Maria Silva')).toBe(true);
    expect(confirmationMatchesPatientName('  maria silva  ', 'Maria Silva')).toBe(true);
    expect(confirmationMatchesPatientName('Maria', 'Maria Silva')).toBe(false);
    expect(confirmationMatchesPatientName('', 'Maria Silva')).toBe(false);
  });
});

describe('deletePatientPermanently', () => {
  beforeEach(() => {
    rpcMock.mockReset();
    storageRemoveMock.mockReset();
    storageFromMock.mockClear();
    logClientErrorMock.mockReset();
  });

  it('calls the SECURITY DEFINER RPC with only the patient id (ownership is checked server-side, never trusted from the client)', async () => {
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: [], simulation_results_paths: [] }],
      error: null,
    });

    await deletePatientPermanently('pat-1');

    expect(rpcMock).toHaveBeenCalledWith('delete_patient_permanently', { p_patient_id: 'pat-1' });
  });

  it('removes every returned storage path from the matching bucket after the DB-side hard delete succeeds', async () => {
    rpcMock.mockResolvedValue({
      data: [{
        patient_photos_paths: ['pro-1/session-1/frontal.jpg', 'pro-1/session-1/plano.pdf'],
        simulation_results_paths: ['pro-1/session-1/result.jpg'],
      }],
      error: null,
    });
    storageRemoveMock.mockResolvedValue({ error: null });

    const result = await deletePatientPermanently('pat-1');

    expect(storageFromMock).toHaveBeenCalledWith('patient-photos');
    expect(storageFromMock).toHaveBeenCalledWith('simulation-results');
    expect(storageRemoveMock).toHaveBeenCalledWith(['pro-1/session-1/frontal.jpg', 'pro-1/session-1/plano.pdf']);
    expect(storageRemoveMock).toHaveBeenCalledWith(['pro-1/session-1/result.jpg']);
    expect(result).toEqual({
      patientPhotosPaths: ['pro-1/session-1/frontal.jpg', 'pro-1/session-1/plano.pdf'],
      simulationResultsPaths: ['pro-1/session-1/result.jpg'],
      storageCleanupFailedPaths: [],
    });
  });

  it('skips storage.remove entirely for a patient with no files (nothing to clean up)', async () => {
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: [], simulation_results_paths: [] }],
      error: null,
    });

    await deletePatientPermanently('pat-1');

    expect(storageRemoveMock).not.toHaveBeenCalled();
  });

  it('throws the RPC error without touching Storage — covers a non-owner professional rejected by the RPC ownership check', async () => {
    rpcMock.mockResolvedValue({
      data: null,
      error: { message: 'not authorized to delete this patient' },
    });

    await expect(deletePatientPermanently('someone-elses-patient')).rejects.toEqual(
      expect.objectContaining({ message: 'not authorized to delete this patient' }),
    );
    expect(storageRemoveMock).not.toHaveBeenCalled();
  });

  it('does not throw when storage cleanup itself fails after a successful hard delete — the DB deletion already happened and is irreversible', async () => {
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: ['pro-1/x.jpg'], simulation_results_paths: [] }],
      error: null,
    });
    storageRemoveMock.mockResolvedValue({ error: { message: 'network error' } });

    await expect(deletePatientPermanently('pat-1')).resolves.toEqual({
      patientPhotosPaths: ['pro-1/x.jpg'],
      simulationResultsPaths: [],
      storageCleanupFailedPaths: ['pro-1/x.jpg'],
    });
  });

  // ── Falha de limpeza precisa ser VISÍVEL (achado do ciclo 60 do QA) ──────
  //
  // O caso acima já existia e passava com o bug presente: ele verificava que
  // a função não lança, o que estava certo, mas não verificava se alguém
  // ficava sabendo. A falha ia só para `console.error` — e o profissional já
  // tinha visto "Paciente excluído definitivamente" e fechado a tela.
  //
  // Numa funcionalidade cujo propósito é cumprir LGPD art. 18 / GDPR art. 17,
  // declarar conclusão com fotos identificáveis ainda no bucket é o pior modo
  // de falha: silencioso para o profissional E para o operador do produto,
  // exatamente sobre a obrigação que a funcionalidade existe para cumprir.
  it('devolve os caminhos que ficaram para trás, para a tela poder contar a verdade', async () => {
    rpcMock.mockResolvedValue({
      data: [{
        patient_photos_paths: ['pro-1/a.jpg', 'pro-1/b.jpg'],
        simulation_results_paths: ['pro-1/sim.jpg'],
      }],
      error: null,
    });
    // Só o bucket de fotos falha; o de simulações passa.
    storageRemoveMock
      .mockResolvedValueOnce({ error: { message: 'permission denied' } })
      .mockResolvedValueOnce({ error: null });

    const result = await deletePatientPermanently('pat-1', 'pro-1');

    // Os dois arquivos do bucket que falhou, e só eles: `remove()` falha para
    // o lote inteiro, não por arquivo.
    expect(result.storageCleanupFailedPaths).toEqual(['pro-1/a.jpg', 'pro-1/b.jpg']);
  });

  it('registra a falha em error_logs, para o operador poder reprocessar', async () => {
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: ['pro-1/x.jpg'], simulation_results_paths: [] }],
      error: null,
    });
    storageRemoveMock.mockResolvedValue({ error: { message: 'network error' } });

    await deletePatientPermanently('pat-1', 'pro-1');

    expect(logClientErrorMock).toHaveBeenCalledWith(
      expect.objectContaining({
        professionalId: 'pro-1',
        stage: 'lgpd_hard_delete',
        errorType: 'patient_storage_cleanup_failed',
      }),
    );
  });

  it('não põe caminho de arquivo na mensagem do log — eles carregam id de paciente', async () => {
    // Este é o log de uma EXCLUSÃO de dado pessoal. Registrar o caminho
    // reintroduziria, no log, parte do identificador que acabou de ser
    // apagado do banco.
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: ['pro-1/pat-1/frontal.jpg'], simulation_results_paths: [] }],
      error: null,
    });
    storageRemoveMock.mockResolvedValue({ error: { message: 'network error' } });

    await deletePatientPermanently('pat-1', 'pro-1');

    const { message } = logClientErrorMock.mock.calls[0][0] as { message: string };
    expect(message).not.toContain('pat-1/frontal.jpg');
    expect(message).toContain('1 arquivo(s)');
  });

  it('não registra nada quando a limpeza funciona', async () => {
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: ['pro-1/x.jpg'], simulation_results_paths: [] }],
      error: null,
    });
    storageRemoveMock.mockResolvedValue({ error: null });

    const result = await deletePatientPermanently('pat-1', 'pro-1');

    expect(result.storageCleanupFailedPaths).toEqual([]);
    expect(logClientErrorMock).not.toHaveBeenCalled();
  });
});
