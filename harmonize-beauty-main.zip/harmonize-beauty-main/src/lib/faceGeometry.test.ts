import { describe, it, expect } from 'vitest';
import { buildTechniqueLine } from './faceGeometry';
import type { TechniqueLinePattern } from '@/types/harmonize';

const ORIGIN = { x: 0.5, y: 0.5 };

// Polígono retangular simples ao redor da origem, usado pelos testes "com
// polígono" abaixo — não representa nenhuma região real, só um caso
// determinístico para checar que o comprimento/direção respeitam o alcance
// da região quando ela está disponível.
const SAMPLE_POLYGON = [
  { x: 0.4, y: 0.4 },
  { x: 0.6, y: 0.4 },
  { x: 0.6, y: 0.6 },
  { x: 0.4, y: 0.6 },
];

const PATTERNS: TechniqueLinePattern[] = ['linear_retrograda', 'fanning', 'reticulado', 'punctura_seriada'];

describe('buildTechniqueLine — contrato comum aos 4 padrões', () => {
  for (const pattern of PATTERNS) {
    it(`${pattern}: path sempre começa em origin, com ou sem polígono`, () => {
      const withPolygon = buildTechniqueLine(pattern, ORIGIN, 42, SAMPLE_POLYGON);
      expect(withPolygon.path[withPolygon.originIndex]).toEqual(ORIGIN);
      expect(withPolygon.originIndex).toBe(0);

      const withoutPolygon = buildTechniqueLine(pattern, ORIGIN, 42, null);
      expect(withoutPolygon.path[withoutPolygon.originIndex]).toEqual(ORIGIN);
      expect(withoutPolygon.originIndex).toBe(0);
    });

    it(`${pattern}: nunca lança exceção com um polígono degenerado (< 3 pontos) ou vazio`, () => {
      expect(() => buildTechniqueLine(pattern, ORIGIN, undefined, [])).not.toThrow();
      expect(() => buildTechniqueLine(pattern, ORIGIN, undefined, [{ x: 0.5, y: 0.5 }])).not.toThrow();
      expect(() => buildTechniqueLine(pattern, ORIGIN, undefined, null)).not.toThrow();
    });

    it(`${pattern}: preserva pattern e guarda o landmark da origem só no índice de origem`, () => {
      const line = buildTechniqueLine(pattern, ORIGIN, 77, SAMPLE_POLYGON);
      expect(line.pattern).toBe(pattern);
      expect(line.landmarkIndices?.[line.originIndex]).toBe(77);
      const othersDefined = (line.landmarkIndices ?? []).filter((_, i) => i !== line.originIndex);
      expect(othersDefined.every((v) => v === undefined)).toBe(true);
    });

    it(`${pattern}: todos os pontos do path ficam dentro de [0,1]`, () => {
      const line = buildTechniqueLine(pattern, ORIGIN, undefined, SAMPLE_POLYGON);
      for (const p of line.path) {
        expect(p.x).toBeGreaterThanOrEqual(0);
        expect(p.x).toBeLessThanOrEqual(1);
        expect(p.y).toBeGreaterThanOrEqual(0);
        expect(p.y).toBeLessThanOrEqual(1);
      }
    });
  }
});

describe('linear_retrograda', () => {
  it('produz um segmento de 2 pontos na direção do ponto mais distante do polígono', () => {
    const line = buildTechniqueLine('linear_retrograda', ORIGIN, undefined, SAMPLE_POLYGON);
    expect(line.path).toHaveLength(2);
    // O polígono é um quadrado centrado na origem — os 4 cantos estão à
    // mesma distância dela, então o ponto final deve ficar na diagonal de um
    // deles (sinais de dx/dy simétricos, magnitude não-nula).
    const [, end] = line.path;
    expect(Math.abs(end.x - ORIGIN.x)).toBeGreaterThan(0);
    expect(Math.abs(end.y - ORIGIN.y)).toBeGreaterThan(0);
  });

  it('sem polígono, usa o comprimento/direção padrão (traço curto, não deixa a origem parada)', () => {
    const line = buildTechniqueLine('linear_retrograda', ORIGIN, undefined, null);
    const [start, end] = line.path;
    expect(start).toEqual(ORIGIN);
    expect(end).not.toEqual(ORIGIN);
  });
});

describe('fanning', () => {
  it('gera de 3 a 5 raios (pontas) irradiando da origem', () => {
    const line = buildTechniqueLine('fanning', ORIGIN, undefined, SAMPLE_POLYGON);
    // path é uma polyline em zigue-zague origem→ponta→origem→ponta…, então o
    // número de "pontas" (pontos != origin) fica entre 3 e 5.
    const tips = line.path.filter((p) => p.x !== ORIGIN.x || p.y !== ORIGIN.y);
    expect(tips.length).toBeGreaterThanOrEqual(3);
    expect(tips.length).toBeLessThanOrEqual(5);
  });

  it('cada raio tem um ângulo diferente (não são todos a mesma direção)', () => {
    const line = buildTechniqueLine('fanning', ORIGIN, undefined, SAMPLE_POLYGON);
    const tips = line.path.filter((p) => p.x !== ORIGIN.x || p.y !== ORIGIN.y);
    const angles = tips.map((p) => Math.atan2(p.y - ORIGIN.y, p.x - ORIGIN.x));
    const uniqueAngles = new Set(angles.map((a) => a.toFixed(4)));
    expect(uniqueAngles.size).toBe(angles.length);
  });
});

describe('reticulado', () => {
  it('gera uma grade de segmentos em duas orientações ortogonais dentro do polígono', () => {
    const line = buildTechniqueLine('reticulado', ORIGIN, undefined, SAMPLE_POLYGON);
    expect(line.path[0]).toEqual(ORIGIN);
    expect(line.path.length).toBeGreaterThan(4); // várias linhas, não só 1 segmento
  });

  it('sem polígono, ainda gera uma grade plausível ao redor da origem (comprimento padrão)', () => {
    const line = buildTechniqueLine('reticulado', ORIGIN, undefined, null);
    expect(line.path[0]).toEqual(ORIGIN);
    expect(line.path.length).toBeGreaterThan(4);
  });
});

describe('punctura_seriada', () => {
  it('distribui pontos-guia ao longo de uma linha reta a partir da origem', () => {
    const line = buildTechniqueLine('punctura_seriada', ORIGIN, undefined, SAMPLE_POLYGON);
    expect(line.path.length).toBeGreaterThanOrEqual(3);
    expect(line.path[0]).toEqual(ORIGIN);
    // Pontos progressivamente mais distantes da origem (mesma direção).
    const distances = line.path.map((p) => Math.hypot(p.x - ORIGIN.x, p.y - ORIGIN.y));
    for (let i = 1; i < distances.length; i++) {
      expect(distances[i]).toBeGreaterThanOrEqual(distances[i - 1]);
    }
  });

  it('usa a mesma direção que linear_retrograda a partir da mesma origem/polígono', () => {
    const seriada = buildTechniqueLine('punctura_seriada', ORIGIN, undefined, SAMPLE_POLYGON);
    const retrograda = buildTechniqueLine('linear_retrograda', ORIGIN, undefined, SAMPLE_POLYGON);
    const lastGuide = seriada.path[seriada.path.length - 1];
    const retrogradaEnd = retrograda.path[1];
    expect(lastGuide.x).toBeCloseTo(retrogradaEnd.x, 5);
    expect(lastGuide.y).toBeCloseTo(retrogradaEnd.y, 5);
  });
});
