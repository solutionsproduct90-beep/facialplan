// Exportação client-side (Canvas 2D) de uma imagem PNG "antes/depois" lado a
// lado com a marca da clínica sobreposta, para a Biblioteca de Antes/Depois
// (src/pages/BibliotecaMarketing.tsx). Segue o mesmo padrão de
// src/lib/videoExport.ts: busca as imagens via `fetch` (não `<img crossorigin>`)
// para manter o canvas "origin-clean" mesmo com URLs assinadas do Supabase
// Storage de outra origem, e separa a matemática pura de layout (testável
// sem jsdom/canvas real) do desenho em si.

export const EXPORT_WIDTH = 1080;
export const EXPORT_HEIGHT = 1080;

export interface BeforeAfterExportLayout {
  width: number;
  height: number;
  halfWidth: number;
  photoAreaHeight: number;
  watermarkBarHeight: number;
  labelBarHeight: number;
}

/** Proporção da altura total reservada à barra de marca d'água no rodapé. */
const WATERMARK_BAR_RATIO = 0.09;
/** Proporção da metade da largura reservada a cada "pílula" de rótulo (Antes/Depois). */
const LABEL_BAR_RATIO = 0.08;

export function computeExportLayout(
  width: number = EXPORT_WIDTH,
  height: number = EXPORT_HEIGHT,
): BeforeAfterExportLayout {
  const watermarkBarHeight = Math.round(height * WATERMARK_BAR_RATIO);
  return {
    width,
    height,
    halfWidth: width / 2,
    photoAreaHeight: height - watermarkBarHeight,
    watermarkBarHeight,
    labelBarHeight: Math.round(height * LABEL_BAR_RATIO),
  };
}

export interface CoverRect {
  dx: number;
  dy: number;
  drawWidth: number;
  drawHeight: number;
}

/**
 * Mesma matemática de "cover" (preencher a caixa mantendo proporção, cortando
 * o excesso) usada em `drawCover` de videoExport.ts, mas devolvendo o
 * retângulo em vez de desenhar direto — pra poder ser testada isoladamente.
 */
export function computeCoverRect(
  imageWidth: number,
  imageHeight: number,
  boxX: number,
  boxY: number,
  boxWidth: number,
  boxHeight: number,
): CoverRect {
  const scale = Math.max(boxWidth / imageWidth, boxHeight / imageHeight);
  const drawWidth = imageWidth * scale;
  const drawHeight = imageHeight * scale;
  return {
    dx: boxX + (boxWidth - drawWidth) / 2,
    dy: boxY + (boxHeight - drawHeight) / 2,
    drawWidth,
    drawHeight,
  };
}

export interface ExportBeforeAfterOptions {
  beforeUrl: string;
  afterUrl: string;
  /** Nome exibido ao lado do logo na barra de marca d'água. Fallback "FacialPlan". */
  clinicName?: string | null;
  /** URL pública (ou já assinada) do logo da clínica. Falha em carregar não impede a exportação. */
  logoUrl?: string | null;
  beforeLabel?: string;
  afterLabel?: string;
}

async function loadImageBitmapFromUrl(url: string): Promise<ImageBitmap> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Não foi possível carregar a imagem para exportação (HTTP ${response.status}).`);
  }
  const blob = await response.blob();
  return createImageBitmap(blob);
}

function canvasToPngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('Falha ao gerar o arquivo PNG a partir do canvas.'));
    }, 'image/png');
  });
}

/**
 * Gera o PNG antes/depois lado a lado: metade esquerda = foto original,
 * metade direita = simulação, com rótulos "ANTES"/"DEPOIS" e uma barra de
 * marca d'água no rodapé com o logo + nome da clínica (quando cadastrados).
 * Lança um erro em vez de devolver um PNG parcial quando as fotos
 * obrigatórias (before/after) não carregam — o logo é o único elemento
 * best-effort (marca d'água ausente não é motivo pra bloquear a exportação).
 */
export async function exportBeforeAfterPng(options: ExportBeforeAfterOptions): Promise<Blob> {
  const { beforeUrl, afterUrl, clinicName, logoUrl, beforeLabel = 'ANTES', afterLabel = 'DEPOIS' } = options;
  const layout = computeExportLayout();

  const [beforeBitmap, afterBitmap, logoBitmap] = await Promise.all([
    loadImageBitmapFromUrl(beforeUrl),
    loadImageBitmapFromUrl(afterUrl),
    logoUrl ? loadImageBitmapFromUrl(logoUrl).catch(() => null) : Promise.resolve(null),
  ]);

  const canvas = document.createElement('canvas');
  canvas.width = layout.width;
  canvas.height = layout.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Contexto 2D do canvas indisponível.');

  // Fundo (evita frestas transparentes nas bordas do "cover").
  ctx.fillStyle = '#F7F6F4';
  ctx.fillRect(0, 0, layout.width, layout.height);

  const drawHalf = (bitmap: ImageBitmap, boxX: number) => {
    const rect = computeCoverRect(bitmap.width, bitmap.height, boxX, 0, layout.halfWidth, layout.photoAreaHeight);
    ctx.save();
    ctx.beginPath();
    ctx.rect(boxX, 0, layout.halfWidth, layout.photoAreaHeight);
    ctx.clip();
    ctx.drawImage(bitmap, rect.dx, rect.dy, rect.drawWidth, rect.drawHeight);
    ctx.restore();
  };
  drawHalf(beforeBitmap, 0);
  drawHalf(afterBitmap, layout.halfWidth);

  // Linha divisória central.
  ctx.fillStyle = 'rgba(255,255,255,0.9)';
  ctx.fillRect(layout.halfWidth - 2, 0, 4, layout.photoAreaHeight);

  // Rótulos "ANTES"/"DEPOIS".
  const labelFontSize = Math.round(layout.width * 0.04);
  ctx.font = `700 ${labelFontSize}px sans-serif`;
  ctx.textBaseline = 'middle';
  const labelPillWidth = layout.halfWidth * 0.4;
  const labelPillY = 16;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(16, labelPillY, labelPillWidth, layout.labelBarHeight);
  ctx.fillRect(layout.halfWidth + 16, labelPillY, labelPillWidth, layout.labelBarHeight);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(beforeLabel, 16 + 16, labelPillY + layout.labelBarHeight / 2);
  ctx.fillText(afterLabel, layout.halfWidth + 16 + 16, labelPillY + layout.labelBarHeight / 2);

  // Barra de marca d'água (rodapé).
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, layout.photoAreaHeight, layout.width, layout.watermarkBarHeight);
  let textX = 24;
  if (logoBitmap) {
    const logoSize = layout.watermarkBarHeight * 0.64;
    const logoY = layout.photoAreaHeight + (layout.watermarkBarHeight - logoSize) / 2;
    ctx.drawImage(logoBitmap, textX, logoY, logoSize, logoSize);
    textX += logoSize + 14;
  }
  ctx.fillStyle = '#1A1918';
  ctx.font = `800 ${Math.round(layout.watermarkBarHeight * 0.32)}px sans-serif`;
  ctx.textBaseline = 'middle';
  ctx.fillText(clinicName?.trim() || 'FacialPlan', textX, layout.photoAreaHeight + layout.watermarkBarHeight / 2);

  return canvasToPngBlob(canvas);
}
