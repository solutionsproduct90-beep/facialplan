// Documentos legais do FacialPlan (Termos de Uso e Política de Privacidade).
//
// O corpo dos documentos vive em src/content/legal/*.md, embutido no bundle
// em build time (`?raw`), pelo mesmo motivo do blog (ver src/lib/blog.ts):
// publicar uma revisão é editar o arquivo e dar merge, com review de código
// — não há CMS externo nem tabela no Supabase, e o texto que o usuário leu
// fica versionado no git junto do commit que o colocou no ar.
//
// POR QUE A VERSÃO É UMA CONSTANTE AQUI:
// a cada cadastro, estas duas datas são gravadas em
// terms_acceptances.terms_version / privacy_version (squad w1-4). Elas são o
// elo entre "fulano aceitou" e "fulano aceitou ISTO". Regra prática, e a
// razão de este comentário existir: **mudou o .md, sobe a data**. Editar o
// texto sem subir a versão corrompe o histórico de aceites — todo mundo que
// aceitou a versão anterior passa a constar como tendo aceitado um texto que
// nunca leu.
//
// Formato AAAA-MM-DD (data de vigência) em vez de semver: é o que faz sentido
// para leigo e para advogado, e é o formato validado tanto no cliente quanto
// na edge function record-terms-acceptance (_shared/termsAcceptance.ts).
import termosPt from '@/content/legal/termos-de-uso.pt.md?raw';
import privacidadePt from '@/content/legal/politica-de-privacidade.pt.md?raw';

export const TERMS_VERSION = '2026-09-28';
export const PRIVACY_VERSION = '2026-09-28';

/**
 * Corpo dos documentos, sempre em português.
 *
 * NÃO é traduzido junto com a interface de propósito: o valor jurídico está
 * no texto em pt-BR, redigido sobre a LGPD e o ordenamento brasileiro.
 * Publicar uma tradução automática dele criaria a dúvida de qual versão
 * prevalece — pior do que não ter tradução. As páginas exibem um aviso
 * (`legal.translationPending`) quando a interface está em outro idioma,
 * traduzido nos 5 locales.
 */
export const TERMS_BODY_PT = termosPt;
export const PRIVACY_BODY_PT = privacidadePt;

/**
 * Remove o bloco de comentário HTML do topo do .md antes de renderizar.
 *
 * Esse bloco é o bilhete para quem mantém o arquivo (lista de pendências do
 * dono, regra de versionamento) e não faz parte do documento legal.
 * `react-markdown` já ignora HTML cru por padrão, então isto é cinto e
 * suspensório — mas também garante que o texto não comece com uma linha em
 * branco gigante se algum dia um plugin de HTML for habilitado.
 */
export function stripAuthoringNotes(markdown: string): string {
  return markdown.replace(/^\s*<!--[\s\S]*?-->\s*/, '');
}
