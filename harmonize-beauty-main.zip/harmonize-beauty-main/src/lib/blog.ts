// Blog público do FacialPlan — conteúdo em arquivos Markdown versionados no
// repositório (src/content/blog/<locale>/*.md), não num CMS externo:
// publicar um artigo é escrever o arquivo e dar merge, mesmo fluxo de
// review já usado pra qualquer outra mudança no app. O Vite embute o
// conteúdo no bundle em build time via `import.meta.glob` (eager + `?raw`)
// — não há fetch em runtime nem tabela no Supabase para isto.
//
// Estrutura por locale (pt/ obrigatório — é a língua-fonte; es/ é o
// mercado prioritário de expansão hoje, LATAM; en/fr/it entram conforme
// houver conteúdo traduzido). Um slug só existe num locale quando o
// arquivo correspondente existe naquela pasta — não há fallback
// silencioso pra pt quando falta tradução: uma página em espanhol
// mostrando conteúdo em português sem avisar é pior pro visitante (e pro
// SEO/hreflang) do que simplesmente não ter aquele artigo ainda.
//
// Front matter é um YAML minimalista de propósito único (só pares
// `chave: valor` de uma linha) — não usamos a lib `gray-matter` porque ela
// depende de `js-yaml`, que por sua vez espera Buffer/Node em alguns
// caminhos; um parser de ~15 linhas cobre 100% do que os posts precisam sem
// arrastar essa dependência para o bundle do cliente.
export interface BlogPostMeta {
  slug: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  author: string;
  coverImage?: string;
  tags: string[];
}

export interface BlogPost extends BlogPostMeta {
  content: string;
}

// Precisa bater com PREFIXED_LOCALES em src/lib/siteLocale.ts (+ 'pt').
// 'en' ainda não tem nenhum post traduzido — getAllBlogPosts('en') retorna
// [] (ver loadPostsByLocale) até existir pelo menos um arquivo em
// src/content/blog/en/.
export type BlogLocale = 'pt' | 'es' | 'en';

const REQUIRED_FIELDS: Array<keyof BlogPostMeta> = ['title', 'description', 'date', 'author'];

function parseFrontmatter(raw: string): { meta: Record<string, string>; content: string } {
  const match = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/.exec(raw);
  if (!match) {
    throw new Error('Post de blog sem front matter (--- ... ---) no início do arquivo.');
  }

  const [, frontmatter, content] = match;
  const meta: Record<string, string> = {};

  for (const line of frontmatter.split('\n')) {
    if (!line.trim()) continue;
    const separatorIndex = line.indexOf(':');
    if (separatorIndex === -1) continue;
    const key = line.slice(0, separatorIndex).trim();
    let value = line.slice(separatorIndex + 1).trim();
    // Remove aspas simples/duplas envolvendo o valor inteiro, se houver.
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    meta[key] = value;
  }

  return { meta, content: content.trim() };
}

const rawPosts = import.meta.glob('/src/content/blog/*/*.md', { query: '?raw', import: 'default', eager: true }) as Record<
  string,
  string
>;

function loadPostsByLocale(): Record<BlogLocale, BlogPost[]> {
  const byLocale: Record<BlogLocale, BlogPost[]> = { pt: [], es: [], en: [] };

  for (const [path, raw] of Object.entries(rawPosts)) {
    // path: /src/content/blog/<locale>/<slug>.md
    const parts = path.split('/');
    const fileName = parts.pop()!;
    const locale = parts.pop()! as BlogLocale;
    const slug = fileName.replace(/\.md$/, '');

    if (locale !== 'pt' && locale !== 'es' && locale !== 'en') continue; // pasta desconhecida — ignora, não quebra o build

    const { meta, content } = parseFrontmatter(raw);

    const missing = REQUIRED_FIELDS.filter((field) => !meta[field]);
    if (missing.length > 0) {
      // Falha alto e cedo em vez de publicar um card de blog quebrado —
      // mesmo espírito dos outros guardrails de dado obrigatório no app.
      throw new Error(`Post "${locale}/${slug}" sem campo(s) obrigatório(s) no front matter: ${missing.join(', ')}`);
    }

    byLocale[locale].push({
      slug,
      title: meta.title,
      description: meta.description,
      date: meta.date,
      author: meta.author,
      coverImage: meta.coverImage || undefined,
      tags: meta.tags ? meta.tags.split(',').map((tag) => tag.trim()).filter(Boolean) : [],
      content,
    });
  }

  (Object.keys(byLocale) as BlogLocale[]).forEach((locale) => {
    byLocale[locale].sort((a, b) => (a.date < b.date ? 1 : -1));
  });

  return byLocale;
}

let cachedByLocale: Record<BlogLocale, BlogPost[]> | null = null;

function allByLocale(): Record<BlogLocale, BlogPost[]> {
  if (!cachedByLocale) cachedByLocale = loadPostsByLocale();
  return cachedByLocale;
}

export function getAllBlogPosts(locale: BlogLocale = 'pt'): BlogPost[] {
  return allByLocale()[locale] ?? [];
}

export function getBlogPostBySlug(slug: string, locale: BlogLocale = 'pt'): BlogPost | undefined {
  return getAllBlogPosts(locale).find((post) => post.slug === slug);
}

/** Locales (além do próprio) em que este slug também tem tradução publicada — usado pra gerar hreflang. */
export function getLocalesForSlug(slug: string): BlogLocale[] {
  const byLocale = allByLocale();
  return (Object.keys(byLocale) as BlogLocale[]).filter((locale) => byLocale[locale].some((post) => post.slug === slug));
}

/**
 * Data de publicação por extenso no idioma da página ("14 de setembro de
 * 2026"). O `T00:00:00` sem fuso força meia-noite LOCAL — `new Date('2026-09-14')`
 * seria meia-noite UTC e viraria dia 13 em qualquer fuso a oeste de Greenwich.
 */
export function formatBlogDate(iso: string, locale: string): string {
  try {
    return new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(`${iso}T00:00:00`));
  } catch {
    return iso;
  }
}

/** Minutos estimados de leitura (≈220 palavras/min, mínimo 1), contando só o texto do Markdown. */
export function readingMinutes(markdown: string): number {
  const words = markdown
    .replace(/[#>*_`[\]()|-]/g, ' ')
    .split(/\s+/)
    .filter(Boolean).length;
  return Math.max(1, Math.round(words / 220));
}

export function getAllBlogTags(locale: BlogLocale = 'pt'): string[] {
  const tags = new Set<string>();
  getAllBlogPosts(locale).forEach((post) => post.tags.forEach((tag) => tags.add(tag)));
  return Array.from(tags).sort();
}
