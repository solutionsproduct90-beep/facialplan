// Compressão/redimensionamento client-side de fotos de paciente ANTES do
// upload (achado de auditoria de performance: fotos de celular moderno
// chegam a vários MB cada, e uma sessão em NovaSessao.tsx pode ter até 4 —
// frontal + 3 ângulos extras — sem nenhuma compressão antes de
// `supabase.storage...upload()`).
//
// Estratégia: desenha a imagem num <canvas> limitando a maior dimensão a
// `maxDimension` (preservando aspect ratio) e reexporta como JPEG via
// `toBlob(..., 'image/jpeg', quality)`. Sempre best-effort — qualquer falha
// (imagem corrompida, canvas indisponível, `toBlob` não suportado) devolve o
// arquivo ORIGINAL em vez de lançar, para nunca travar o fluxo de upload por
// causa de uma otimização. Pelo mesmo motivo, se a versão comprimida não
// ficar menor que o arquivo original (já pequeno/eficiente, ex. um JPEG já
// bem comprimido), o original é mantido.
export interface CompressImageOptions {
  /** Maior dimensão (largura ou altura) permitida, em pixels, após o resize. */
  maxDimension?: number;
  /** Qualidade JPEG passada a `canvas.toBlob`, de 0 a 1. */
  quality?: number;
}

const DEFAULT_MAX_DIMENSION = 1800;
const DEFAULT_QUALITY = 0.8;

/** Carrega um File de imagem como HTMLImageElement, via object URL descartável. */
function loadImageElement(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error(`Falha ao carregar imagem "${file.name}" para compressão`));
    };
    img.src = url;
  });
}

/** Troca a extensão do nome do arquivo por `.jpg` — a saída de `toBlob('image/jpeg', ...)`
 * é sempre JPEG, então o nome tem que refletir isso (o `ext` derivado do nome do
 * arquivo em NovaSessao.tsx vira o sufixo salvo no storage). */
function renameToJpeg(originalName: string): string {
  const dot = originalName.lastIndexOf('.');
  const base = dot > 0 ? originalName.slice(0, dot) : originalName;
  return `${base}.jpg`;
}

/**
 * Redimensiona/recomprime um File de imagem antes do upload.
 *
 * - Arquivos que não são imagem (`file.type` sem prefixo `image/`) voltam
 *   inalterados.
 * - Imagens já menores que `maxDimension` no maior lado não são redimensionadas
 *   (só reencodadas como JPEG na qualidade pedida) — se isso não reduzir o
 *   tamanho, o original é devolvido.
 * - Nunca lança: qualquer erro no caminho (decodificação, canvas, toBlob)
 *   resolve com o `file` original, para não travar o upload por causa de uma
 *   otimização best-effort.
 */
export async function compressImageFile(file: File, options: CompressImageOptions = {}): Promise<File> {
  if (!file.type.startsWith('image/')) return file;

  const maxDimension = options.maxDimension ?? DEFAULT_MAX_DIMENSION;
  const quality = options.quality ?? DEFAULT_QUALITY;

  try {
    const img = await loadImageElement(file);
    const { naturalWidth: width, naturalHeight: height } = img;
    if (!width || !height) return file;

    const scale = Math.min(1, maxDimension / Math.max(width, height));
    const targetWidth = Math.max(1, Math.round(width * scale));
    const targetHeight = Math.max(1, Math.round(height * scale));

    const canvas = document.createElement('canvas');
    canvas.width = targetWidth;
    canvas.height = targetHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return file;

    // JPEG não tem canal alfa — preenche fundo branco antes de desenhar,
    // pra um PNG com transparência (ex. print de tela) não virar pixels
    // pretos no lugar do que era transparente.
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, targetWidth, targetHeight);
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

    const blob = await new Promise<Blob | null>((resolve) => {
      canvas.toBlob((b) => resolve(b), 'image/jpeg', quality);
    });
    if (!blob || blob.size >= file.size) return file;

    return new File([blob], renameToJpeg(file.name), { type: 'image/jpeg', lastModified: Date.now() });
  } catch {
    return file;
  }
}
