// ABCDE skin lesion screening — clinical decision-support logic.
//
// This is a checklist the PROFESSIONAL fills in from direct observation of
// the patient/photo. It is not, and must never become, an automated
// diagnosis: nothing here classifies a lesion as cancer or "safe". A
// positive criterion only means the finding must be surfaced and the
// professional's decision (refer vs. proceed under their own
// responsibility) must be recorded — never that the flow is blocked.
//
// Criteria wording follows the ABCDE rule as described by the American
// Academy of Dermatology / Cleveland Clinic: asymmetry, border, color,
// diameter (>6mm, used as a reference rather than an absolute threshold —
// melanomas can be smaller), and evolution (many dermatologists consider
// this the most important criterion).

export type SkinScreeningCriterionKey =
  | "asymmetry"
  | "irregularBorders"
  | "colorVariation"
  | "diameterOver6mm"
  | "recentEvolution";

export type SkinScreeningAnswer = boolean | null;

export type SkinScreeningAnswers = Record<SkinScreeningCriterionKey, SkinScreeningAnswer>;

// Letra do mnemônico ABCDE por critério — universal entre os 5 idiomas do
// app (o mnemônico não é traduzido, ver sessions.stage1.skinScreening.criteria
// em src/i18n/locales/*.json para título/descrição, que são traduzidos).
export interface SkinScreeningCriterionMeta {
  key: SkinScreeningCriterionKey;
  letter: "A" | "B" | "C" | "D" | "E";
}

export const SKIN_SCREENING_CRITERIA: SkinScreeningCriterionMeta[] = [
  { key: "asymmetry", letter: "A" },
  { key: "irregularBorders", letter: "B" },
  { key: "colorVariation", letter: "C" },
  { key: "diameterOver6mm", letter: "D" },
  { key: "recentEvolution", letter: "E" },
];

export const SKIN_SCREENING_CRITERION_KEYS: SkinScreeningCriterionKey[] =
  SKIN_SCREENING_CRITERIA.map((c) => c.key);

export const MIN_JUSTIFICATION_LENGTH = 10;

/** True once every criterion has an explicit true/false answer (no criterion left unanswered). */
export function isSkinScreeningComplete(
  answers: Partial<SkinScreeningAnswers>
): boolean {
  return SKIN_SCREENING_CRITERION_KEYS.every(
    (key) => answers[key] === true || answers[key] === false
  );
}

/** True when at least one ABCDE criterion was marked present. Never call this a diagnosis. */
export function hasSuspiciousFinding(
  answers: Partial<SkinScreeningAnswers>
): boolean {
  return SKIN_SCREENING_CRITERION_KEYS.some((key) => answers[key] === true);
}

/**
 * Gate for the "proceed anyway" path when a suspicious finding was recorded:
 * requires an explicit acknowledgement checkbox AND a non-trivial written
 * justification, so the decision to proceed is deliberate and logged.
 */
export function canProceedDespiteFinding(
  justification: string,
  acknowledged: boolean
): boolean {
  return acknowledged && justification.trim().length >= MIN_JUSTIFICATION_LENGTH;
}
