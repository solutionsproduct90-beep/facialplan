// Integração com Google Calendar/iCal — item do backlog de features
// propostas. Decisão de escopo deliberada: NÃO implementamos OAuth/API real
// do Google Calendar (isso exigiria client id/secret e um fluxo de
// consentimento que não temos como provisionar aqui) nem qualquer outra
// integração server-side. Em vez disso geramos um arquivo .ics padrão
// (iCalendar, RFC 5545) inteiramente no cliente — sem backend, sem
// credenciais — que já é importável manualmente no Google Calendar, no
// Outlook e no Apple Calendar. É a mesma decisão de escopo já registrada
// para o restante do mini sistema de agenda em
// supabase/migrations/20260910190000_add_appointments.sql ("sincronização
// com calendários externos... próximos passos naturais, não omissão").
//
// Fonte dos dados: a tabela `appointments` (aba "Agenda" do /painel, ver
// src/lib/agenda.ts) — não `sessions`, que representa um atendimento já em
// andamento/concluído, não uma marcação de agenda futura.

/** Formato mínimo de compromisso necessário para gerar um .ics — um
 * subconjunto de `AppointmentForList` (src/lib/agenda.ts), repetido aqui em
 * vez de importado para manter este módulo utilizável a partir de qualquer
 * tela que tenha esses poucos campos, sem acoplar aos tipos de normalização
 * da aba Agenda. */
export type IcalAppointmentInput = {
  id: string;
  patientName: string | null;
  note: string | null;
  scheduledAt: string; // ISO
  durationMinutes: number | null;
};

/** Mesma assinatura de `translate` já usada em postProcedureChecklistShareText
 * (src/lib/postProcedureChecklist.ts): recebe o `t` do i18next em vez de
 * importar react-i18next aqui, para este módulo continuar puro e testável
 * sem montar componentes nem inicializar o i18n. */
export type IcalTranslate = (key: string, options?: Record<string, unknown>) => unknown;

/** Duração assumida quando o compromisso não tem `duration_minutes`
 * definido — mesmo valor de referência (30 min) usado como placeholder no
 * formulário da aba Agenda (ver `placeholder="30"` em AgendaTab.tsx). */
export const DEFAULT_APPOINTMENT_DURATION_MINUTES = 30;

function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

/** Formata uma data no horário UTC exigido pelo RFC 5545 §3.3.5 para um
 * "form #2" (UTC) DATE-TIME: YYYYMMDDTHHMMSSZ. Usar UTC (em vez de um
 * horário local + VTIMEZONE) evita ter que embutir/definir um componente
 * VTIMEZONE completo só para este export mínimo — o instante representado
 * é idêntico, cada calendário exibe no fuso do dispositivo do usuário. */
function toIcsUtc(date: Date): string {
  return (
    `${date.getUTCFullYear()}${pad2(date.getUTCMonth() + 1)}${pad2(date.getUTCDate())}` +
    `T${pad2(date.getUTCHours())}${pad2(date.getUTCMinutes())}${pad2(date.getUTCSeconds())}Z`
  );
}

/** Escapa texto livre para os campos TEXT (SUMMARY/DESCRIPTION) conforme
 * RFC 5545 §3.3.11: barra invertida, ponto e vírgula, vírgula e quebra de
 * linha precisam de escape — sem isso, um nome de paciente ou nota com
 * vírgula/quebra de linha corromperia a estrutura do arquivo. */
function escapeIcsText(text: string): string {
  return text
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/\r?\n/g, '\\n');
}

/** Dobra ("folds") uma linha de conteúdo em segmentos de até 75 caracteres
 * com continuação, conforme RFC 5545 §3.1 — cada linha de continuação
 * começa com um espaço, que a especificação manda descartar na releitura.
 * Simplificação assumida: contamos caracteres UTF-16, não octetos UTF-8
 * como o RFC define; para os textos curtos (nome de paciente + nota) deste
 * export isso não chega a importar na prática, e os principais clientes
 * (Google/Outlook/Apple) toleram bem folga aqui. */
function foldIcsLine(line: string): string {
  if (line.length <= 75) return line;
  const parts: string[] = [line.slice(0, 75)];
  let rest = line.slice(75);
  while (rest.length > 0) {
    parts.push(` ${rest.slice(0, 74)}`);
    rest = rest.slice(74);
  }
  return parts.join('\r\n');
}

/**
 * Gera o conteúdo textual de um arquivo .ics (RFC 5545) com um único
 * VEVENT para o compromisso informado. Função pura — sem `Blob`/`document`
 * — para ser testável sem DOM (o disparo do download fica isolado em
 * `downloadAppointmentIcs`, mesmo padrão de `downloadPatientRecordExport`
 * em patientRecordExport.ts).
 */
export function buildAppointmentIcs(
  appointment: IcalAppointmentInput,
  translate: IcalTranslate,
  now: Date = new Date(),
): string {
  const start = new Date(appointment.scheduledAt);
  const durationMinutes =
    appointment.durationMinutes != null && appointment.durationMinutes > 0
      ? appointment.durationMinutes
      : DEFAULT_APPOINTMENT_DURATION_MINUTES;
  const end = new Date(start.getTime() + durationMinutes * 60_000);

  const summary = appointment.patientName
    ? (translate('agenda.ical.summaryWithPatient', { name: appointment.patientName }) as string)
    : (translate('agenda.ical.summaryNoPatient') as string);

  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Harmonize Beauty//Agenda//PT',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    // UID estável por compromisso — reimportar o mesmo .ics no mesmo
    // calendário atualiza o evento existente em vez de duplicá-lo.
    `UID:appointment-${appointment.id}@harmonizebeauty.app`,
    `DTSTAMP:${toIcsUtc(now)}`,
    `DTSTART:${toIcsUtc(start)}`,
    `DTEND:${toIcsUtc(end)}`,
    `SUMMARY:${escapeIcsText(summary)}`,
    ...(appointment.note ? [`DESCRIPTION:${escapeIcsText(appointment.note)}`] : []),
    'END:VEVENT',
    'END:VCALENDAR',
  ];

  return lines.map(foldIcsLine).join('\r\n') + '\r\n';
}

/**
 * Efeito colateral isolado: gera o .ics e dispara o download no navegador
 * via Blob + link temporário. jsdom não implementa `URL.createObjectURL` —
 * mesmo cuidado já documentado em `downloadPatientRecordExport`
 * (patientRecordExport.ts) para quem for testar este caminho.
 */
export function downloadAppointmentIcs(appointment: IcalAppointmentInput, translate: IcalTranslate): void {
  const ics = buildAppointmentIcs(appointment, translate);
  const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `compromisso-${appointment.id}.ics`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
