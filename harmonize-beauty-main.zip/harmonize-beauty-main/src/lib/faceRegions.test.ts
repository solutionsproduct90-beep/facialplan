import { describe, it, expect } from "vitest";
import {
  FACE_REGIONS,
  FACE_REGION_KEYS,
  HIGH_VASCULAR_RISK_REGIONS,
  landmarkPositionForRegion,
  regionLabel,
  regionFallbackPosition,
  isHighVascularRiskRegion,
  isVascularRiskApplication,
  regionPolygonForRegion,
} from "./faceRegions";

describe("regionLabel", () => {
  it("returns the human-readable label for a known region", () => {
    expect(regionLabel("labio_superior")).toBe("Lábio Superior");
    expect(regionLabel("malar_direita")).toBe("Região Malar Direita");
  });

  it("returns the raw slug unchanged for an unknown region", () => {
    expect(regionLabel("regiao_inexistente")).toBe("regiao_inexistente");
  });
});

describe("regionFallbackPosition", () => {
  it("returns the configured fallback position for a known region", () => {
    expect(regionFallbackPosition("mento")).toEqual({ x: 0.5, y: 0.85 });
  });

  it("returns the center (0.5, 0.5) for an unknown region", () => {
    expect(regionFallbackPosition("regiao_inexistente")).toEqual({ x: 0.5, y: 0.5 });
  });

  it("has a fallback position defined for every known region key", () => {
    for (const key of FACE_REGION_KEYS) {
      const pos = FACE_REGIONS[key].fallback;
      expect(pos.x).toBeGreaterThanOrEqual(0);
      expect(pos.x).toBeLessThanOrEqual(1);
      expect(pos.y).toBeGreaterThanOrEqual(0);
      expect(pos.y).toBeLessThanOrEqual(1);
    }
  });
});

describe("landmarkPositionForRegion", () => {
  it("returns null when landmarks are undefined", () => {
    expect(landmarkPositionForRegion("labio_superior", undefined)).toBeNull();
  });

  it("returns null when landmarks is an empty array", () => {
    expect(landmarkPositionForRegion("labio_superior", [])).toBeNull();
  });

  it("returns null for an unknown region even with landmarks available", () => {
    const landmarks = Array.from({ length: 478 }, (_, i) => ({ x: i / 478, y: i / 478 }));
    expect(landmarkPositionForRegion("regiao_inexistente", landmarks)).toBeNull();
  });

  it("returns the position and index of the region's primary landmark when present", () => {
    const landmarks = Array.from({ length: 478 }, () => ({ x: 0, y: 0 }));
    landmarks[13] = { x: 0.42, y: 0.61 };

    // labio_superior's first landmark index is 13.
    const result = landmarkPositionForRegion("labio_superior", landmarks);
    expect(result).toEqual({ x: 0.42, y: 0.61, landmarkIndex: 13 });
  });

  it("falls through to the next landmark index in the list when the primary one is missing", () => {
    // comissura_labial_esquerda only has a single candidate index (61) — use
    // a region with more than one to exercise the fallback chain instead.
    // malar_esquerda's indices are [234, 93].
    const landmarks: { x: number; y: number }[] = [];
    landmarks[93] = { x: 0.24, y: 0.47 };
    // index 234 intentionally left undefined (sparse array).

    const result = landmarkPositionForRegion("malar_esquerda", landmarks);
    expect(result).toEqual({ x: 0.24, y: 0.47, landmarkIndex: 93 });
  });

  it("returns null when none of the region's candidate landmark indices are present", () => {
    const landmarks: { x: number; y: number }[] = [{ x: 0.1, y: 0.1 }]; // only index 0 populated
    expect(landmarkPositionForRegion("malar_esquerda", landmarks)).toBeNull();
  });
});

// Consumido pelo alerta educativo de zona de risco vascular da Etapa 2
// (SessaoEstagio2.tsx) — só se aplica a preenchedor (ácido hialurônico), mas
// a checagem da região em si vive aqui. NOTE: HIGH_VASCULAR_RISK_REGIONS é
// um ponto de partida não validado clinicamente (ver comentário na fonte);
// estes testes cobrem o comportamento da função, não a correção médica da
// lista.
describe("isHighVascularRiskRegion", () => {
  it("flags the classically higher-risk zones (glabela, dorso nasal, sulco nasolabial, comissura labial)", () => {
    expect(isHighVascularRiskRegion("glabela")).toBe(true);
    expect(isHighVascularRiskRegion("dorso_nasal")).toBe(true);
    expect(isHighVascularRiskRegion("sulco_nasolabial_esquerdo")).toBe(true);
    expect(isHighVascularRiskRegion("sulco_nasolabial_direito")).toBe(true);
    expect(isHighVascularRiskRegion("comissura_labial_esquerda")).toBe(true);
    expect(isHighVascularRiskRegion("comissura_labial_direita")).toBe(true);
  });

  it("does not flag regions outside the high-risk set", () => {
    expect(isHighVascularRiskRegion("labio_superior")).toBe(false);
    expect(isHighVascularRiskRegion("mento")).toBe(false);
    expect(isHighVascularRiskRegion("malar_esquerda")).toBe(false);
    expect(isHighVascularRiskRegion("ponta_nasal")).toBe(false);
  });

  it("returns false for an unknown region", () => {
    expect(isHighVascularRiskRegion("regiao_inexistente")).toBe(false);
  });

  it("keeps the high-risk set as a subset of the known region keys", () => {
    for (const region of HIGH_VASCULAR_RISK_REGIONS) {
      expect(FACE_REGION_KEYS).toContain(region);
    }
  });
});

describe("isVascularRiskApplication", () => {
  it("is true only for acido_hialuronico in a high-vascular-risk region", () => {
    expect(isVascularRiskApplication("glabela", "acido_hialuronico")).toBe(true);
    expect(isVascularRiskApplication("comissura_labial_direita", "acido_hialuronico")).toBe(true);
  });

  it("is false for acido_hialuronico outside a high-vascular-risk region", () => {
    expect(isVascularRiskApplication("labio_superior", "acido_hialuronico")).toBe(false);
  });

  it("is false for toxina_botulinica or bioestimulador even in a high-vascular-risk region", () => {
    expect(isVascularRiskApplication("glabela", "toxina_botulinica")).toBe(false);
    expect(isVascularRiskApplication("glabela", "bioestimulador")).toBe(false);
  });
});

// regionPolygonForRegion (relatório de investigação "scanner real do
// rosto"): devolve a ÁREA real de uma região curada, em vez de só um ponto —
// ver comentário de `areaIndices` em RegionInfo (faceRegions.ts) para quais
// regiões já têm área curada e quais ainda são "PENDENTE" (só ponto).
describe("regionPolygonForRegion", () => {
  // Coordenadas pseudo-aleatórias (multiplicador irracional mod 1) em vez de
  // uma progressão linear simples — landmarks numa progressão linear caem
  // todos sobre a mesma reta, o que faria o fecho convexo de qualquer
  // cluster colapsar para 2 pontos (caso degenerado), mascarando bugs reais.
  const fullLandmarks = Array.from({ length: 478 }, (_, i) => ({
    x: (i * 0.6180339887) % 1,
    y: (i * 0.3819660113) % 1,
  }));

  it("returns null when landmarks are undefined", () => {
    expect(regionPolygonForRegion("glabela", undefined)).toBeNull();
  });

  it("returns null when landmarks is an empty array", () => {
    expect(regionPolygonForRegion("glabela", [])).toBeNull();
  });

  it("returns null for an unknown region even with landmarks available", () => {
    expect(regionPolygonForRegion("regiao_inexistente", fullLandmarks)).toBeNull();
  });

  it("returns null for a region that has no areaIndices curated yet (e.g. dorso_nasal)", () => {
    expect(FACE_REGIONS.dorso_nasal.areaIndices).toBeUndefined();
    expect(regionPolygonForRegion("dorso_nasal", fullLandmarks)).toBeNull();
  });

  it("returns null when the detection is missing one of the region's required indices", () => {
    const sparse: { x: number; y: number }[] = [];
    sparse[8] = { x: 0.5, y: 0.3 };
    sparse[9] = { x: 0.5, y: 0.28 };
    // glabela's areaIndices also need 55, 285 and 168 — left undefined here.
    expect(regionPolygonForRegion("glabela", sparse)).toBeNull();
  });

  it("returns a polygon with at least 3 points for a curated compact (hull) region", () => {
    const polygon = regionPolygonForRegion("glabela", fullLandmarks);
    expect(polygon).not.toBeNull();
    expect(polygon!.length).toBeGreaterThanOrEqual(3);
    for (const p of polygon!) {
      expect(p.x).toBeGreaterThanOrEqual(0);
      expect(p.x).toBeLessThanOrEqual(1);
      expect(p.y).toBeGreaterThanOrEqual(0);
      expect(p.y).toBeLessThanOrEqual(1);
    }
  });

  it("returns the ordered contour unchanged (not hulled) for an elongated curated region (lips)", () => {
    const polygon = regionPolygonForRegion("labio_superior", fullLandmarks);
    expect(polygon).not.toBeNull();
    const expectedFirstIndex = FACE_REGIONS.labio_superior.areaIndices![0];
    expect(polygon![0]).toEqual(fullLandmarks[expectedFirstIndex]);
    expect(polygon!.length).toBe(FACE_REGIONS.labio_superior.areaIndices!.length);
  });

  it("hulls a compact region's cluster into a polygon no larger than the cluster itself", () => {
    const polygon = regionPolygonForRegion("malar_esquerda", fullLandmarks);
    expect(polygon).not.toBeNull();
    expect(polygon!.length).toBeLessThanOrEqual(FACE_REGIONS.malar_esquerda.areaIndices!.length);
  });
});

// Taxonomia ampliada (achado do comitê: cobertura de região bem menor que
// concorrentes) — nenhum procedimento nomeado usa essas regiões ainda, só
// garante que os slugs existem e têm posição/label configurados para quando
// um squad futuro precisar deles.
describe("expanded region taxonomy (tear trough / temples)", () => {
  it("includes tear trough (olheira) and temple (têmpora) regions, left and right", () => {
    expect(FACE_REGION_KEYS).toEqual(
      expect.arrayContaining(["olheira_esquerda", "olheira_direita", "tempora_esquerda", "tempora_direita"]),
    );
  });

  it("does not duplicate the existing chin/forehead/jaw regions under a new name", () => {
    // 'queixo'/'testa' were suggested names for concepts already covered by
    // the existing 'mento'/'terco_frontal' (and 'mandibula_esquerda'/'direita')
    // keys — adding aliases would fragment the taxonomy instead of extending it.
    expect(FACE_REGION_KEYS).not.toContain("queixo");
    expect(FACE_REGION_KEYS).not.toContain("testa");
  });
});
