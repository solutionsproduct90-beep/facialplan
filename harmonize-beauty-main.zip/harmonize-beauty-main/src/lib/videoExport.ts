import { Muxer, ArrayBufferTarget } from 'mp4-muxer';

/**
 * Gera, 100% client-side, um vídeo vertical "antes/depois" (wipe transition)
 * pronto pra WhatsApp Status/Reels — pensado pra ser enviado ao paciente
 * junto com (ou no lugar de) o link de apresentação.
 *
 * Contexto do bug que este módulo existe pra NÃO repetir: um concorrente
 * (Full Face Academy) gera um vídeo equivalente cujo caminho WebCodecs falha
 * silenciosamente (`NotSupportedError` — a resolução 1080x1440 excede o
 * AVC level 3.0 que eles fixaram) e cai num fallback via `MediaRecorder`
 * que na verdade grava VP9, mas ainda assim salva o arquivo como `.mp4`.
 * O resultado é um `.mp4` que só *parece* H.264 — e quebra no iOS/WhatsApp.
 *
 * Duas defesas contra isso, aplicadas juntas:
 * 1. `pickSupportedH264Config` nunca fixa um único nível AVC: testa uma
 *    escada de perfis/níveis x resoluções via `VideoEncoder.isConfigSupported`
 *    (que não lança, só responde `supported: boolean`) até achar uma
 *    combinação real. Só cai pro fallback de `MediaRecorder` quando NENHUMA
 *    combinação de resolução/nível H.264 é suportada — e mesmo nesse caso
 *    exige que o `MediaRecorder` declare explicitamente um `mimeType`
 *    H.264 (nunca aceita "deu certo" para VP8/VP9 disfarçado de `.mp4`).
 * 2. Independentemente do caminho usado, `validateH264Mp4` abre o
 *    container MP4 resultante e lê o fourcc real da sample entry de vídeo
 *    (`stsd` -> `avc1`/`avc3` vs `vp09`/`vp08`/`hev1`/`av01`). Se não for
 *    H.264 de verdade, `generateBeforeAfterVideo` lança um erro em vez de
 *    devolver o blob — nunca confiamos apenas em "o encoder não lançou".
 */

// ---------------------------------------------------------------------------
// Timeline: 1.8s parado em "antes" -> 2.4s wipe -> 1.6s parado em "depois"
// -> 0.8s de respiração (leve zoom) antes do loop. Em frames @30fps isso cai
// em números inteiros exatos (54/72/48/24), o que evita acúmulo de erro de
// ponto flutuante ao decidir em qual frame cada fase termina.
// ---------------------------------------------------------------------------

export const VIDEO_WIDTH = 1080;
export const VIDEO_HEIGHT = 1440;
export const VIDEO_FPS = 30;

export type TimelinePhase = 'holdBefore' | 'wipe' | 'holdAfter' | 'breathe';

export const PHASE_FRAME_COUNTS: Record<TimelinePhase, number> = {
  holdBefore: 54, // 1.8s @ 30fps
  wipe: 72, // 2.4s @ 30fps
  holdAfter: 48, // 1.6s @ 30fps
  breathe: 24, // 0.8s @ 30fps
};

export const PHASE_ORDER: TimelinePhase[] = ['holdBefore', 'wipe', 'holdAfter', 'breathe'];

export const PHASE_DURATIONS_S: Record<TimelinePhase, number> = Object.fromEntries(
  PHASE_ORDER.map((phase) => [phase, PHASE_FRAME_COUNTS[phase] / VIDEO_FPS])
) as Record<TimelinePhase, number>;

export const TOTAL_FRAME_COUNT = PHASE_ORDER.reduce((sum, phase) => sum + PHASE_FRAME_COUNTS[phase], 0);
export const TOTAL_DURATION_S = TOTAL_FRAME_COUNT / VIDEO_FPS;

export function getTotalFrameCount(fps: number = VIDEO_FPS): number {
  return Math.round(TOTAL_DURATION_S * fps);
}

export interface TimelinePosition {
  phase: TimelinePhase;
  /** Frame decorrido dentro da fase atual (0-based). */
  frameInPhase: number;
  /** Progresso 0..1 dentro da fase atual. */
  progress: number;
}

/**
 * Posição na timeline para um frame absoluto (0-based), assumindo a escada
 * de frames por fase acima escalada pelo fps informado. `frame` fora do
 * intervalo válido é grampeado no início/fim (fica parado em "antes" antes
 * do início, e no fim da respiração depois do fim).
 */
export function getPhaseAtFrame(frame: number, fps: number = VIDEO_FPS): TimelinePosition {
  const scale = fps / VIDEO_FPS;
  let remaining = Math.max(0, frame);
  for (const phase of PHASE_ORDER) {
    const phaseFrames = Math.max(1, Math.round(PHASE_FRAME_COUNTS[phase] * scale));
    if (remaining < phaseFrames) {
      return { phase, frameInPhase: remaining, progress: remaining / phaseFrames };
    }
    remaining -= phaseFrames;
  }
  const lastPhase = PHASE_ORDER[PHASE_ORDER.length - 1];
  const lastPhaseFrames = Math.max(1, Math.round(PHASE_FRAME_COUNTS[lastPhase] * scale));
  return { phase: lastPhase, frameInPhase: lastPhaseFrames - 1, progress: 1 };
}

/** Mesma coisa que {@link getPhaseAtFrame}, mas a partir de um tempo em segundos. */
export function getPhaseAtTime(seconds: number, fps: number = VIDEO_FPS): TimelinePosition {
  return getPhaseAtFrame(Math.round(seconds * fps), fps);
}

function easeInOutCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
}

/** Posição horizontal (em pixels, 0..width) da linha de wipe para uma fase/progresso dados. */
export function getWipeX(position: TimelinePosition, width: number = VIDEO_WIDTH): number {
  if (position.phase === 'holdBefore') return 0;
  if (position.phase === 'wipe') return width * easeInOutCubic(position.progress);
  return width; // holdAfter e breathe: "depois" cobre a tela inteira
}

// ---------------------------------------------------------------------------
// Suporte a WebCodecs — nunca fixa um único nível/resolução (ver bug do
// concorrente descrito no topo do arquivo).
// ---------------------------------------------------------------------------

export function isWebCodecsSupported(): boolean {
  return typeof globalThis.VideoEncoder !== 'undefined' && typeof globalThis.VideoFrame !== 'undefined';
}

/** Perfis/níveis H.264 candidatos, do mais capaz ao mais conservador. */
const H264_CODEC_LEVELS = [
  'avc1.640034', // High @ L5.2
  'avc1.640033', // High @ L5.1
  'avc1.64002a', // High @ L4.2
  'avc1.640029', // High @ L4.1
  'avc1.640028', // High @ L4.0
  'avc1.4d4029', // Main @ L4.1
  'avc1.4d4028', // Main @ L4.0
  'avc1.42e01f', // Baseline @ L3.1
  'avc1.42e01e', // Baseline @ L3.0
];

/** Resoluções candidatas, da nativa (retrato 1080x1440) até um piso ainda nítido no WhatsApp. */
const RESOLUTION_LADDER: Array<{ width: number; height: number }> = [
  { width: VIDEO_WIDTH, height: VIDEO_HEIGHT },
  { width: 900, height: 1200 },
  { width: 720, height: 960 },
  { width: 540, height: 720 },
];

export interface H264Config {
  codec: string;
  width: number;
  height: number;
}

/**
 * Percorre a escada de resolução x nível AVC usando `isConfigSupported`
 * (que responde `{ supported }` em vez de lançar) e devolve a primeira
 * combinação que o navegador confirma suportar de verdade, ou `null` se
 * nenhuma combinação H.264 funcionar — nesse caso o chamador deve recorrer
 * ao fallback de `MediaRecorder` (ou desistir), nunca assumir que a
 * primeira tentativa "deu certo".
 */
export async function pickSupportedH264Config(
  fps: number = VIDEO_FPS,
  bitrate = 6_000_000
): Promise<H264Config | null> {
  if (!isWebCodecsSupported()) return null;
  for (const { width, height } of RESOLUTION_LADDER) {
    for (const codec of H264_CODEC_LEVELS) {
      try {
        const support = await globalThis.VideoEncoder.isConfigSupported({
          codec,
          width,
          height,
          bitrate,
          framerate: fps,
        });
        if (support?.supported) {
          return { codec, width, height };
        }
      } catch {
        // isConfigSupported não deveria lançar, mas se lançar numa combinação
        // isso não significa "nenhum H.264 é suportado" — continua a escada.
        continue;
      }
    }
  }
  return null;
}

const MEDIARECORDER_H264_MP4_TYPES = [
  'video/mp4;codecs=avc1.640028',
  'video/mp4;codecs=avc1',
  'video/mp4;codecs=h264',
  'video/mp4',
];

/**
 * Único fallback aceitável quando WebCodecs não suporta H.264 em nenhuma
 * combinação: um `MediaRecorder` que o próprio navegador confirma gravar
 * H.264 dentro de `.mp4` (`isTypeSupported`). Nunca aceita um tipo `webm`/
 * VP8/VP9 disfarçado — é exatamente essa troca que quebrou o vídeo do
 * concorrente no iOS/WhatsApp.
 */
export function pickSupportedMediaRecorderH264Type(): string | null {
  if (typeof MediaRecorder === 'undefined' || typeof MediaRecorder.isTypeSupported !== 'function') return null;
  for (const type of MEDIARECORDER_H264_MP4_TYPES) {
    try {
      if (MediaRecorder.isTypeSupported(type)) return type;
    } catch {
      continue;
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Validação do container final — a rede de segurança que pega o caso em que
// o encoder "não lançou erro" mas o resultado não é H.264 de verdade.
// ---------------------------------------------------------------------------

const H264_FOURCCS = new Set(['avc1', 'avc3']);

/**
 * `Blob.prototype.arrayBuffer` não existe em todo runtime (jsdom, notavelmente
 * — daí este ambiente de testes precisar dele funcionando de verdade). Usa
 * `FileReader`, que tem suporte universal, em vez de depender do método.
 */
function blobToArrayBuffer(blob: Blob): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as ArrayBuffer);
    reader.onerror = () => reject(reader.error ?? new Error('Falha ao ler o blob do vídeo.'));
    reader.readAsArrayBuffer(blob);
  });
}

interface Mp4Box {
  type: string;
  start: number;
  size: number;
  headerSize: number;
}

function readBoxes(view: DataView, start: number, end: number): Mp4Box[] {
  const boxes: Mp4Box[] = [];
  let offset = start;
  while (offset + 8 <= end) {
    let size = view.getUint32(offset);
    const type = String.fromCharCode(
      view.getUint8(offset + 4),
      view.getUint8(offset + 5),
      view.getUint8(offset + 6),
      view.getUint8(offset + 7)
    );
    let headerSize = 8;
    if (size === 1) {
      if (offset + 16 > end) break;
      const high = view.getUint32(offset + 8);
      const low = view.getUint32(offset + 12);
      size = high * 2 ** 32 + low;
      headerSize = 16;
    } else if (size === 0) {
      size = end - offset;
    }
    if (size < headerSize || offset + size > end) break;
    boxes.push({ type, start: offset, size, headerSize });
    offset += size;
  }
  return boxes;
}

function findBox(view: DataView, start: number, end: number, type: string): Mp4Box | null {
  return readBoxes(view, start, end).find((box) => box.type === type) ?? null;
}

function findAllBoxes(view: DataView, start: number, end: number, type: string): Mp4Box[] {
  return readBoxes(view, start, end).filter((box) => box.type === type);
}

/**
 * Lê o fourcc da sample entry de vídeo (`stsd`) do primeiro trak que tiver
 * uma `vmhd` (video media header) — ou o primeiro trak, se nenhum declarar
 * `vmhd`. Devolve `null` quando a estrutura não é reconhecida como MP4/ISO
 * BMFF válido.
 */
export function getMp4VideoCodecFourCc(buffer: ArrayBuffer): string | null {
  const view = new DataView(buffer);
  const moov = findBox(view, 0, buffer.byteLength, 'moov');
  if (!moov) return null;
  const moovContentEnd = moov.start + moov.size;
  const traks = findAllBoxes(view, moov.start + moov.headerSize, moovContentEnd, 'trak');
  if (traks.length === 0) return null;

  const videoTrak =
    traks.find((trak) => {
      const mdia = findBox(view, trak.start + trak.headerSize, trak.start + trak.size, 'mdia');
      if (!mdia) return false;
      const minf = findBox(view, mdia.start + mdia.headerSize, mdia.start + mdia.size, 'minf');
      if (!minf) return false;
      return findBox(view, minf.start + minf.headerSize, minf.start + minf.size, 'vmhd') !== null;
    }) ?? traks[0];

  const mdia = findBox(view, videoTrak.start + videoTrak.headerSize, videoTrak.start + videoTrak.size, 'mdia');
  if (!mdia) return null;
  const minf = findBox(view, mdia.start + mdia.headerSize, mdia.start + mdia.size, 'minf');
  if (!minf) return null;
  const stbl = findBox(view, minf.start + minf.headerSize, minf.start + minf.size, 'stbl');
  if (!stbl) return null;
  const stsd = findBox(view, stbl.start + stbl.headerSize, stbl.start + stbl.size, 'stsd');
  if (!stsd) return null;

  // stsd = box header (8) + version/flags (4) + entry_count (4) + entries...
  // cada entry começa com size (4) + format fourcc (4).
  const firstEntryStart = stsd.start + stsd.headerSize + 8;
  if (firstEntryStart + 8 > stsd.start + stsd.size) return null;
  return String.fromCharCode(
    view.getUint8(firstEntryStart + 4),
    view.getUint8(firstEntryStart + 5),
    view.getUint8(firstEntryStart + 6),
    view.getUint8(firstEntryStart + 7)
  );
}

export function isH264FourCc(fourCc: string | null): boolean {
  return fourCc !== null && H264_FOURCCS.has(fourCc);
}

export interface Mp4CodecValidation {
  ok: boolean;
  codec: string | null;
  reason?: string;
}

/**
 * Abre o container MP4 do blob gerado e confere o codec REAL da trilha de
 * vídeo — nunca confia em "o caminho de encoding escolhido deveria produzir
 * H.264". Rejeita explicitamente VP8/VP9/HEVC/AV1 disfarçados de `.mp4`.
 */
export async function validateH264Mp4(blob: Blob): Promise<Mp4CodecValidation> {
  const buffer = await blobToArrayBuffer(blob);
  const fourCc = getMp4VideoCodecFourCc(buffer);
  if (!fourCc) {
    return {
      ok: false,
      codec: null,
      reason: 'Não foi possível localizar a trilha de vídeo (stsd) dentro do container MP4 gerado.',
    };
  }
  if (isH264FourCc(fourCc)) {
    return { ok: true, codec: fourCc };
  }
  return {
    ok: false,
    codec: fourCc,
    reason: `O arquivo gerado está em ".mp4", mas a trilha de vídeo usa o codec "${fourCc}", não H.264 (avc1/avc3). Isso quebra a reprodução no iOS/WhatsApp.`,
  };
}

// ---------------------------------------------------------------------------
// Renderização client-side (Canvas 2D) e geração do vídeo final.
// ---------------------------------------------------------------------------

export interface GenerateVideoOptions {
  beforeUrl: string;
  afterUrl: string;
  title?: string;
  caption?: string;
  fps?: number;
  onProgress?: (fraction: number) => void;
}

export interface GenerateVideoResult {
  blob: Blob;
  codec: string;
  width: number;
  height: number;
  encodingPath: 'webcodecs' | 'mediarecorder';
}

/**
 * Carrega os dois bitmaps, fechando o que já tiver chegado se o outro
 * falhar. Sem isso, uma foto que carrega e outra que dá 404 deixa a
 * primeira ocupando memória de pixel até o coletor de lixo passar.
 */
async function loadImageBitmapPair(beforeUrl: string, afterUrl: string): Promise<[ImageBitmap, ImageBitmap]> {
  const results = await Promise.allSettled([loadImageBitmap(beforeUrl), loadImageBitmap(afterUrl)]);
  const rejected = results.find((r): r is PromiseRejectedResult => r.status === 'rejected');
  if (rejected) {
    for (const r of results) {
      if (r.status === 'fulfilled') r.value.close();
    }
    throw rejected.reason;
  }
  const [before, after] = results as PromiseFulfilledResult<ImageBitmap>[];
  return [before.value, after.value];
}

async function loadImageBitmap(url: string): Promise<ImageBitmap> {
  // Busca os bytes via fetch (não via <img crossorigin>) e cria o
  // ImageBitmap a partir do Blob local: isso mantém o canvas "origin-clean"
  // mesmo quando a URL assinada do Supabase Storage vem de outra origem,
  // sem depender de cabeçalhos CORS na resposta original.
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Não foi possível carregar a imagem para o vídeo (HTTP ${response.status}).`);
  }
  const blob = await response.blob();
  return createImageBitmap(blob);
}

function drawCover(
  ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  image: ImageBitmap,
  x: number,
  y: number,
  width: number,
  height: number
) {
  const scale = Math.max(width / image.width, height / image.height);
  const drawWidth = image.width * scale;
  const drawHeight = image.height * scale;
  const dx = x + (width - drawWidth) / 2;
  const dy = y + (height - drawHeight) / 2;
  ctx.drawImage(image, dx, dy, drawWidth, drawHeight);
}

interface DrawFrameParams {
  width: number;
  height: number;
  frame: number;
  fps: number;
  beforeBitmap: ImageBitmap;
  afterBitmap: ImageBitmap;
  title?: string;
  caption?: string;
}

function drawFrame(ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D, params: DrawFrameParams) {
  const { width, height, frame, fps, beforeBitmap, afterBitmap, title, caption } = params;
  const position = getPhaseAtFrame(frame, fps);
  const wipeX = getWipeX(position, width);

  // Leve zoom de "respiração" na fase final, pra dar vida ao loop.
  const breatheScale = position.phase === 'breathe' ? 1 + 0.015 * Math.sin(position.progress * Math.PI) : 1;

  ctx.save();
  ctx.translate(width / 2, height / 2);
  ctx.scale(breatheScale, breatheScale);
  ctx.translate(-width / 2, -height / 2);

  drawCover(ctx, beforeBitmap, 0, 0, width, height);
  if (wipeX > 0) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, wipeX, height);
    ctx.clip();
    drawCover(ctx, afterBitmap, 0, 0, width, height);
    ctx.restore();
    if (position.phase === 'wipe') {
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.fillRect(Math.max(0, wipeX - 2), 0, 4, height);
    }
  }
  ctx.restore();

  const labelKey = position.phase === 'holdBefore' || position.phase === 'wipe' ? 'ANTES' : 'DEPOIS';
  ctx.font = `700 ${Math.round(width * 0.04)}px sans-serif`;
  ctx.textBaseline = 'top';
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.fillRect(0, height * 0.03, width * 0.32, height * 0.06);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(labelKey, width * 0.05, height * 0.045);

  if (title) {
    ctx.font = `800 ${Math.round(width * 0.055)}px sans-serif`;
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(0, height * 0.85, width, height * 0.08);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(title, width * 0.05, height * 0.865);
  }
  if (caption) {
    ctx.font = `500 ${Math.round(width * 0.032)}px sans-serif`;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(caption, width * 0.05, height * 0.925);
  }
}

async function yieldToBrowser(): Promise<void> {
  await new Promise<void>((resolve) => setTimeout(resolve, 0));
}

interface EncodeParams {
  fps: number;
  title?: string;
  caption?: string;
  beforeBitmap: ImageBitmap;
  afterBitmap: ImageBitmap;
  onProgress?: (fraction: number) => void;
}

async function encodeWithWebCodecs(
  params: EncodeParams & { config: H264Config }
): Promise<{ blob: Blob; width: number; height: number }> {
  const { fps, title, caption, beforeBitmap, afterBitmap, onProgress, config } = params;
  const { width, height, codec } = config;

  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Contexto 2D do canvas indisponível.');

  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    video: { codec: 'avc', width, height, frameRate: fps },
    fastStart: 'in-memory',
  });

  const encoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (err) => {
      throw err;
    },
  });
  encoder.configure({ codec, width, height, bitrate: 6_000_000, framerate: fps });

  const totalFrames = getTotalFrameCount(fps);
  const frameDurationUs = Math.round(1_000_000 / fps);
  const keyFrameEveryNFrames = fps * 2;

  for (let frame = 0; frame < totalFrames; frame++) {
    drawFrame(ctx, { width, height, frame, fps, beforeBitmap, afterBitmap, title, caption });
    const timestamp = frame * frameDurationUs;
    const videoFrame = new VideoFrame(canvas, { timestamp, duration: frameDurationUs });
    encoder.encode(videoFrame, { keyFrame: frame % keyFrameEveryNFrames === 0 });
    videoFrame.close();
    onProgress?.((frame + 1) / totalFrames);
    if (frame % 8 === 0) await yieldToBrowser();
  }

  await encoder.flush();
  encoder.close();
  muxer.finalize();

  return { blob: new Blob([target.buffer], { type: 'video/mp4' }), width, height };
}

async function encodeWithMediaRecorder(
  params: EncodeParams & { mimeType: string }
): Promise<{ blob: Blob; width: number; height: number }> {
  const { fps, title, caption, beforeBitmap, afterBitmap, onProgress, mimeType } = params;
  const width = VIDEO_WIDTH;
  const height = VIDEO_HEIGHT;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Contexto 2D do canvas indisponível.');

  const stream = canvas.captureStream(fps);
  const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 6_000_000 });
  const chunks: Blob[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size > 0) chunks.push(event.data);
  };

  const finished = new Promise<Blob>((resolve, reject) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: 'video/mp4' }));
    recorder.onerror = (event) => reject(event);
  });

  const totalFrames = getTotalFrameCount(fps);
  const frameIntervalMs = 1000 / fps;

  recorder.start();
  for (let frame = 0; frame < totalFrames; frame++) {
    drawFrame(ctx, { width, height, frame, fps, beforeBitmap, afterBitmap, title, caption });
    onProgress?.((frame + 1) / totalFrames);
    await new Promise((resolve) => setTimeout(resolve, frameIntervalMs));
  }
  recorder.stop();

  return { blob: await finished, width, height };
}

/**
 * Gera o vídeo antes/depois. Lança um erro (em vez de devolver um arquivo
 * incorreto) quando nenhum caminho de codificação H.264 real está disponível
 * no navegador, ou quando a validação pós-encode encontra um codec diferente
 * de H.264 dentro do `.mp4` produzido.
 */
export async function generateBeforeAfterVideo(options: GenerateVideoOptions): Promise<GenerateVideoResult> {
  const fps = options.fps ?? VIDEO_FPS;
  const [beforeBitmap, afterBitmap] = await loadImageBitmapPair(options.beforeUrl, options.afterUrl);

  // O `finally` abaixo é obrigatório, não higiene opcional. Cada bitmap
  // guarda a foto já decodificada (foto de celular costuma passar de
  // 3000x4000, dezenas de MB por imagem, possivelmente na GPU) e só o
  // `close()` devolve isso antes do coletor de lixo. A tela de apresentação
  // tem um botão "Regenerar" que chama esta função de novo sem recarregar a
  // página: sem fechar, cada clique empilha mais um par. Geração de vídeo já
  // é das operações mais pesadas de memória num navegador, e o alvo desta
  // feature é justamente o celular — onde o Safari do iOS mata a aba por
  // excesso de memória em vez de degradar.
  //
  // Vale também para o caminho de erro: quando nenhum encoder H.264 existe,
  // ou a validação pós-encode rejeita o arquivo, os bitmaps têm que sair do
  // mesmo jeito.
  //
  // Achado do ciclo 70 do QA Contínuo.
  try {
    const encodeParams: EncodeParams = {
      fps,
      title: options.title,
      caption: options.caption,
      beforeBitmap,
      afterBitmap,
      onProgress: options.onProgress,
    };

    const webCodecsConfig = await pickSupportedH264Config(fps);
    let encoded: { blob: Blob; width: number; height: number };
    let encodingPath: GenerateVideoResult['encodingPath'];

    if (webCodecsConfig) {
      encoded = await encodeWithWebCodecs({ ...encodeParams, config: webCodecsConfig });
      encodingPath = 'webcodecs';
    } else {
      const mediaRecorderType = pickSupportedMediaRecorderH264Type();
      if (!mediaRecorderType) {
        throw new Error(
          'Este navegador não oferece nenhum caminho de codificação H.264 real (nem WebCodecs, nem MediaRecorder). ' +
            'Para não gerar um ".mp4" com um codec incompatível, a geração do vídeo foi cancelada.'
        );
      }
      encoded = await encodeWithMediaRecorder({ ...encodeParams, mimeType: mediaRecorderType });
      encodingPath = 'mediarecorder';
    }

    const validation = await validateH264Mp4(encoded.blob);
    if (!validation.ok) {
      throw new Error(
        validation.reason ?? 'O vídeo gerado não está em H.264 real; o download foi cancelado para evitar quebra no WhatsApp/iOS.'
      );
    }

    return {
      blob: encoded.blob,
      codec: validation.codec as string,
      width: encoded.width,
      height: encoded.height,
      encodingPath,
    };
  } finally {
    beforeBitmap.close();
    afterBitmap.close();
  }
}
