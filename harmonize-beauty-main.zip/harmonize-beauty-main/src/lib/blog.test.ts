import { describe, it, expect } from 'vitest';
import { getAllBlogPosts, getBlogPostBySlug, getAllBlogTags, formatBlogDate, readingMinutes } from './blog';

describe('blog', () => {
  it('carrega os posts semente do repositório (src/content/blog)', () => {
    const posts = getAllBlogPosts();
    expect(posts.length).toBeGreaterThanOrEqual(3);
  });

  it('ordena os posts do mais recente para o mais antigo', () => {
    const posts = getAllBlogPosts();
    for (let i = 1; i < posts.length; i++) {
      expect(posts[i - 1].date >= posts[i].date).toBe(true);
    }
  });

  it('cada post tem os campos obrigatórios preenchidos', () => {
    for (const post of getAllBlogPosts()) {
      expect(post.slug).toBeTruthy();
      expect(post.title).toBeTruthy();
      expect(post.description).toBeTruthy();
      expect(post.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(post.author).toBeTruthy();
      expect(post.content.length).toBeGreaterThan(0);
    }
  });

  it('busca um post existente pelo slug', () => {
    const [first] = getAllBlogPosts();
    expect(getBlogPostBySlug(first.slug)?.title).toBe(first.title);
  });

  it('retorna undefined para um slug que não existe', () => {
    expect(getBlogPostBySlug('este-slug-nao-existe')).toBeUndefined();
  });

  it('formata a data no dia certo, sem escorregar pro dia anterior por causa de fuso', () => {
    expect(formatBlogDate('2026-09-14', 'pt')).toContain('14');
    expect(formatBlogDate('2026-09-14', 'pt')).toContain('setembro');
    expect(formatBlogDate('2026-09-14', 'es')).toContain('septiembre');
  });

  it('estima o tempo de leitura em minutos, com mínimo de 1', () => {
    expect(readingMinutes('')).toBe(1);
    expect(readingMinutes('palavra '.repeat(440))).toBe(2);
    expect(readingMinutes('## Título\n\n- item **forte**')).toBe(1);
  });

  it('agrega as tags de todos os posts sem duplicatas', () => {
    const tags = getAllBlogTags();
    expect(new Set(tags).size).toBe(tags.length);
  });
});
