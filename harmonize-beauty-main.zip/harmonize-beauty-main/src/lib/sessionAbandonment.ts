// Definição de "sessão abandonada" para o lembrete de reengajamento por
// e-mail (supabase/functions/send-reengagement-reminders): uma sessão que o
// profissional começou (Estágio 1/2/3) mas nunca fechou (`status` chega a
// 'complete' só em SessaoEstagio3.tsx > handleComplete) nem foi marcada
// manualmente como 'abandoned' (badge existente em SessionCard.tsx/
// PacienteDetalhe.tsx, sem fluxo automático que a defina hoje), e que já
// passou tempo suficiente sem avançar para não ser só "sessão de ontem que o
// profissional ainda vai terminar hoje".
//
// Mantida aqui (não em supabase/functions/_shared) para ficar testável com
// Vitest sem depender do runtime Deno; a function do servidor porta a mesma
// regra localmente (comentário lá aponta pra cá) já que edge functions deste
// projeto não importam de src/.
export const ABANDONED_THRESHOLD_DAYS = 5;

// Únicos dois status "fechados" hoje no app — ver Home.tsx/Sessoes.tsx
// (`.not('status', 'in', '("complete","abandoned")')`) e SessionCard.tsx
// (`isActive = !['complete', 'abandoned'].includes(status)`).
const CLOSED_STATUSES = new Set(['complete', 'abandoned']);

export type SessionAbandonmentInput = {
  status: string | null;
  createdAt: string | number | Date;
  /** `sessions.reminder_sent_at` — null quando nenhum lembrete foi enviado ainda. */
  reminderSentAt?: string | number | Date | null;
};

function toDate(value: string | number | Date): Date {
  return value instanceof Date ? value : new Date(value);
}

/**
 * true quando a sessão está aberta (não concluída, não marcada como
 * abandonada) e já foi criada há `thresholdDays` dias ou mais — sem
 * considerar se um lembrete já foi enviado (ver `shouldSendReengagementReminder`
 * para essa checagem combinada, que é a usada de fato antes de disparar um
 * e-mail).
 */
export function isSessionAbandoned(
  session: SessionAbandonmentInput,
  now: Date = new Date(),
  thresholdDays: number = ABANDONED_THRESHOLD_DAYS,
): boolean {
  if (!session.status || CLOSED_STATUSES.has(session.status)) return false;

  const created = toDate(session.createdAt);
  if (Number.isNaN(created.getTime())) return false;

  const ageMs = now.getTime() - created.getTime();
  return ageMs >= thresholdDays * 24 * 60 * 60 * 1000;
}

/**
 * true quando a sessão está abandonada (ver `isSessionAbandoned`) E ainda não
 * recebeu um lembrete (`reminderSentAt` nulo) — a checagem que
 * send-reengagement-reminders usa pra decidir se dispara o e-mail. Uma
 * sessão com lembrete já enviado nunca é reprocessada, mesmo que ainda
 * esteja aberta.
 */
export function shouldSendReengagementReminder(
  session: SessionAbandonmentInput,
  now: Date = new Date(),
  thresholdDays: number = ABANDONED_THRESHOLD_DAYS,
): boolean {
  if (session.reminderSentAt) return false;
  return isSessionAbandoned(session, now, thresholdDays);
}
