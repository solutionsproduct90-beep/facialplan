import { describe, it, expect } from 'vitest';
import { buildPatientRecordExport, type PatientForExport, type SessionRowForExport } from './patientRecordExport';
import type { Anamnesis } from '@/types/anamnesis';
import type { ApplicationPoint, Insumo } from '@/types/harmonize';

const PATIENT: PatientForExport = {
  id: 'pat-1',
  name: 'Maria Silva',
  phone: '11999999999',
  email: 'maria@example.com',
  birth_date: '1990-01-01',
  notes: 'Prefere retorno pela manhã',
  consent_given: true,
  last_consent_at: '2026-01-01T00:00:00.000Z',
  created_at: '2025-12-01T00:00:00.000Z',
};

const ANAMNESIS: Anamnesis = {
  id: 'an-1',
  patient_id: 'pat-1',
  professional_id: 'pro-1',
  main_complaint: 'Rugas na testa',
  skin_type: 'oily',
  skin_texture: 'thin',
  oiliness: 'high',
  discromia: ['melasma'],
  vascularization: [],
  risk_flags: { diabetes: true, allergy: { has: true, which: 'Dipirona' } },
  photo_url: null,
  filled_by: 'patient_link',
  reviewed_at: null,
  created_at: '2026-01-10T00:00:00.000Z',
  updated_at: '2026-01-10T00:00:00.000Z',
};

const INSUMO: Insumo = {
  id: 'ins-1',
  substance: 'acido_hialuronico',
  brandName: 'Marca Premium',
  costPerUnit: 100, // nunca deve aparecer no export
  pricePerUnit: 300,
  active: true,
};

const POINT: ApplicationPoint = {
  id: 'pt-1',
  region: 'labio_superior',
  label: 'Lábio Superior',
  substance: 'acido_hialuronico',
  quantity: 1,
  unit: 'ml',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  insumoId: 'ins-1',
};

const SESSION: SessionRowForExport = {
  id: 'ses-1',
  status: 'complete',
  selected_procedure: 'Preenchimento labial',
  created_at: '2026-02-01T00:00:00.000Z',
  stage1_analysis: { suggestions: [], overallNotes: 'Sem intercorrências' },
  stage2_overlay: [POINT],
};

describe('buildPatientRecordExport', () => {
  it('includes patient, anamnesis, sessions and adverse events', () => {
    const record = buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: ANAMNESIS,
      sessions: [SESSION],
      adverseEvents: [
        {
          id: 'ae-1',
          event_type: 'nodulo',
          severity: 'leve',
          description: 'Pequeno nódulo, resolvido em 3 dias',
          occurred_at: '2026-02-05T00:00:00.000Z',
          session_id: 'ses-1',
          insumo_id: 'ins-1',
        },
      ],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
    });

    expect(record.patient).toMatchObject({ id: 'pat-1', name: 'Maria Silva', email: 'maria@example.com' });
    expect(record.anamnesis).toMatchObject({
      mainComplaint: 'Rugas na testa',
      clinicalEvaluation: { skinType: 'oily' },
    });
    expect(record.sessions).toHaveLength(1);
    expect(record.sessions[0].selectedProcedure).toBe('Preenchimento labial');
    expect(record.adverseEvents).toHaveLength(1);
    expect(record.adverseEvents[0].insumoBrandName).toBe('Marca Premium');
  });

  it('resolves application points to a brand name instead of the raw insumo id', () => {
    const record = buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: null,
      sessions: [SESSION],
      adverseEvents: [],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
    });

    const point = record.sessions[0].applicationPoints[0];
    expect(point.insumoBrandName).toBe('Marca Premium');
    expect(point).not.toHaveProperty('insumoId');
  });

  it('never leaks professional-only cost/margin fields — only the patient-facing price', () => {
    const record = buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: null,
      sessions: [SESSION],
      adverseEvents: [],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
    });

    const serialized = JSON.stringify(record);
    // totalCost/margin/marginPct nunca devem aparecer em lugar nenhum do
    // export — nem os nomes de chave nem o valor de custo do insumo (100).
    expect(serialized).not.toMatch(/totalCost|margin|marginPct/i);
    expect(record.sessions[0].budgetSummary).toEqual({
      totalPrice: 300,
      totalMl: 1,
      totalUnits: 0,
      currency: 'BRL',
    });
  });

  it('handles a patient with no anamnesis, no sessions and no adverse events yet', () => {
    const record = buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: null,
      sessions: [],
      adverseEvents: [],
      insumos: [],
      laborFeePerSession: null,
      currency: 'BRL',
    });

    expect(record.anamnesis).toBeNull();
    expect(record.sessions).toEqual([]);
    expect(record.adverseEvents).toEqual([]);
  });

  it('tolerates a session whose stage2_overlay is not an array (legacy/malformed row)', () => {
    const record = buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: null,
      sessions: [{ ...SESSION, stage2_overlay: null }],
      adverseEvents: [],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
    });

    expect(record.sessions[0].applicationPoints).toEqual([]);
    expect(record.sessions[0].budgetSummary.totalPrice).toBe(0);
  });
});

// Regressão do achado "análise clínica fabricada sem marcador de
// proveniência": a exportação de prontuário (direito de portabilidade — o
// arquivo pode ir parar nas mãos do paciente, de outro profissional ou de um
// órgão) entregava a análise de DEMONSTRAÇÃO gravada pelo fallback de
// analyze-face com exatamente a mesma aparência de uma leitura real de IA.
describe('buildPatientRecordExport — carimbo de proveniência da análise', () => {
  const NOTICES = { demo: 'AVISO DEMO', unknown: 'AVISO ORIGEM DESCONHECIDA' };

  const exportWith = (stage1Analysis: unknown) =>
    buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: null,
      sessions: [{ ...SESSION, stage1_analysis: stage1Analysis }],
      adverseEvents: [],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
      provenanceNotices: NOTICES,
    });

  it('carimba a sessão cuja análise é de demonstração e avisa no topo do arquivo', () => {
    const record = exportWith({ suggestions: [], source: 'mock' });

    expect(record.sessions[0].analysisProvenance).toBe('mock');
    expect(record.analysisProvenanceWarnings).toEqual([NOTICES.demo]);
    // O aviso tem que estar no JSON de fato entregue, não só no objeto em
    // memória — é o arquivo que chega ao paciente/órgão.
    expect(JSON.stringify(record)).toContain(NOTICES.demo);
  });

  it('não carimba nada quando a análise é uma leitura real da IA', () => {
    const record = exportWith({ suggestions: [], source: 'ai' });

    expect(record.sessions[0].analysisProvenance).toBe('ai');
    expect(record.analysisProvenanceWarnings).toEqual([]);
  });

  it("marca como 'unknown' (nunca 'ai') uma sessão antiga, sem marcador de origem", () => {
    const record = exportWith({ suggestions: [], overallNotes: 'Sem intercorrências' });

    expect(record.sessions[0].analysisProvenance).toBe('unknown');
    expect(record.analysisProvenanceWarnings).toEqual([NOTICES.unknown]);
  });

  it('não avisa por uma sessão sem análise nenhuma — não há conteúdo clínico a qualificar', () => {
    const record = exportWith(null);

    expect(record.sessions[0].analysis).toBeNull();
    expect(record.analysisProvenanceWarnings).toEqual([]);
  });

  it('lista cada aviso uma única vez, mesmo com várias sessões do mesmo tipo', () => {
    const record = buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: null,
      sessions: [
        { ...SESSION, id: 's-a', stage1_analysis: { suggestions: [], source: 'mock' } },
        { ...SESSION, id: 's-b', stage1_analysis: { suggestions: [], source: 'mock' } },
        { ...SESSION, id: 's-c', stage1_analysis: { suggestions: [] } },
      ],
      adverseEvents: [],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
      provenanceNotices: NOTICES,
    });

    expect(record.analysisProvenanceWarnings).toEqual([NOTICES.demo, NOTICES.unknown]);
  });
});

// ── Regressão do ciclo 81 do QA Contínuo ────────────────────────────────
//
// A triagem ABCDE de lesão cutânea (`skin_screenings`) nunca era consultada
// nem tinha campo neste tipo. O botão promete "prontuário completo" e o
// módulo se declara como o fluxo de portabilidade da LGPD, mas um paciente
// que teve lesão suspeita encaminhada ao dermatologista recebia um arquivo
// que se apresentava como completo e omitia exatamente isso — em silêncio,
// ao contrário do aviso de análise de demonstração que este mesmo arquivo já
// trazia.
describe('buildPatientRecordExport — triagem de lesão cutânea', () => {
  const TRIAGEM = {
    id: 'scr-1',
    session_id: 'ses-1',
    asymmetry: true,
    irregular_borders: false,
    color_variation: true,
    diameter_over_6mm: false,
    recent_evolution: true,
    has_suspicious_finding: true,
    lesion_location: 'Têmpora direita',
    notes: 'Paciente relata mudança recente de cor.',
    referred_to_dermatology: true,
    proceeded_despite_finding: false,
    proceed_justification: null,
    created_at: '2026-02-01T10:00:00.000Z',
    updated_at: '2026-02-01T10:30:00.000Z',
  };

  const base = (extra: Record<string, unknown> = {}) =>
    buildPatientRecordExport({
      patient: PATIENT,
      anamnesis: ANAMNESIS,
      sessions: [SESSION],
      adverseEvents: [],
      insumos: [INSUMO],
      laborFeePerSession: null,
      currency: 'BRL',
      ...extra,
    });

  it('inclui o achado suspeito e o encaminhamento ao dermatologista', () => {
    const record = base({ skinScreenings: [TRIAGEM] });

    expect(record.skinScreenings).toHaveLength(1);
    const [triagem] = record.skinScreenings;
    expect(triagem.hasSuspiciousFinding).toBe(true);
    expect(triagem.referredToDermatology).toBe(true);
    expect(triagem.lesionLocation).toBe('Têmpora direita');
    expect(triagem.criteria).toEqual({
      asymmetry: true,
      irregularBorders: false,
      colorVariation: true,
      diameterOver6mm: false,
      recentEvolution: true,
    });
  });

  it('o arquivo baixado carrega o dado, não só o objeto em memória', () => {
    // O que o paciente recebe é o JSON serializado. Era exatamente aí que o
    // dado não aparecia.
    const serializado = JSON.stringify(base({ skinScreenings: [TRIAGEM] }));

    expect(serializado).toContain('referredToDermatology');
    expect(serializado).toContain('Têmpora direita');
  });

  it('inclui as versões substituídas da triagem, da mais antiga para a mais nova', () => {
    // Refazer a triagem substitui a linha (ver o gatilho de
    // 20260922180000_add_skin_screening_revisions.sql). A decisão clínica
    // anterior também é prontuário.
    const record = base({
      skinScreenings: [TRIAGEM],
      skinScreeningRevisions: [
        { ...TRIAGEM, screening_id: 'scr-1', id: 'rev-2', recorded_at: '2026-02-01T10:10:00.000Z', superseded_at: '2026-02-01T10:20:00.000Z' },
        { ...TRIAGEM, screening_id: 'scr-1', id: 'rev-1', referred_to_dermatology: false, recorded_at: '2026-02-01T10:00:00.000Z', superseded_at: '2026-02-01T10:05:00.000Z' },
      ],
    });

    const revisoes = record.skinScreenings[0].revisions;
    expect(revisoes).toHaveLength(2);
    expect(revisoes[0].supersededAt).toBe('2026-02-01T10:05:00.000Z');
    expect(revisoes[0].referredToDermatology).toBe(false);
    expect(revisoes[1].supersededAt).toBe('2026-02-01T10:20:00.000Z');
  });

  it('paciente sem triagem nenhuma exporta lista vazia, não campo ausente', () => {
    // Campo ausente e campo vazio dizem coisas diferentes para quem lê o
    // arquivo: um sugere que o export não cobre isso, o outro afirma que não
    // houve triagem.
    const record = base();

    expect(record.skinScreenings).toEqual([]);
    expect(Object.keys(record)).toContain('skinScreenings');
  });
});
