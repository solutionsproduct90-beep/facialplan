// Funções puras usadas pela aba "Agenda" do /painel (mini sistema de
// agendamento, não um Calendly/Google Calendar completo — ver comentário na
// migration 20260910190000_add_appointments.sql). Separadas do componente
// pelo mesmo motivo de src/lib/panel.ts: testáveis sem montar a tela nem
// tocar Supabase.

export type AppointmentStatus = 'agendado' | 'concluido' | 'cancelado';

const STATUSES: AppointmentStatus[] = ['agendado', 'concluido', 'cancelado'];

/** Compromisso já normalizado, pronto pro que a aba Agenda precisa renderizar. */
export type AppointmentForList = {
  id: string;
  patientId: string | null;
  patientName: string | null;
  note: string | null;
  scheduledAt: string; // ISO
  durationMinutes: number | null;
  status: AppointmentStatus;
};

/**
 * Normaliza linhas de `appointments` vindas do Supabase — incluindo o join
 * opcional `patient:patients(name)`, que o PostgREST pode devolver como
 * objeto OU como array de 1 item dependendo da versão (mesma cautela já
 * aplicada em SessaoPresent.tsx pro mesmo tipo de join). Linha malformada
 * (sem id ou com scheduled_at inválido) é descartada, não quebra a lista
 * inteira.
 */
export function normalizeAppointments(raw: unknown): AppointmentForList[] {
  if (!Array.isArray(raw)) return [];
  const out: AppointmentForList[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    if (typeof r.id !== 'string' || !r.id) continue;
    if (typeof r.scheduled_at !== 'string' || Number.isNaN(new Date(r.scheduled_at).getTime())) continue;

    const status: AppointmentStatus =
      typeof r.status === 'string' && STATUSES.includes(r.status as AppointmentStatus)
        ? (r.status as AppointmentStatus)
        : 'agendado';

    const patientRaw = r.patient;
    const patient = Array.isArray(patientRaw) ? patientRaw[0] : patientRaw;
    const patientName =
      patient && typeof patient === 'object' && typeof (patient as Record<string, unknown>).name === 'string'
        ? ((patient as Record<string, unknown>).name as string)
        : null;

    const durationMinutes = Number(r.duration_minutes);

    out.push({
      id: r.id,
      patientId: typeof r.patient_id === 'string' ? r.patient_id : null,
      patientName,
      note: typeof r.note === 'string' ? r.note : null,
      scheduledAt: r.scheduled_at,
      durationMinutes: Number.isFinite(durationMinutes) ? durationMinutes : null,
      status,
    });
  }
  return out;
}

/** Meia-noite (hora local) do dia informado — chave de agrupamento por dia. */
function dateKeyFromDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function dateKeyOf(iso: string): string {
  return dateKeyFromDate(new Date(iso));
}

export type AppointmentDayGroup = {
  dateKey: string; // YYYY-MM-DD, hora local
  items: AppointmentForList[];
};

/**
 * Agrupa por dia (chave local YYYY-MM-DD) e ordena cronologicamente — tanto
 * os grupos entre si quanto os compromissos dentro de cada grupo — pra
 * virar a lista "próximos compromissos agrupados por dia, ordenados por
 * data/hora" pedida. Sem filtro de passado/futuro aqui de propósito: um
 * compromisso atrasado que ainda está "agendado" continua aparecendo (no
 * topo) até o profissional marcá-lo como concluído/cancelado ou remarcar —
 * mais parecido com uma lista de tarefas do que com um calendário que some
 * o que passou.
 */
export function groupAppointmentsByDay(appointments: AppointmentForList[]): AppointmentDayGroup[] {
  const sorted = [...appointments].sort(
    (a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime(),
  );
  const order: string[] = [];
  const byDay = new Map<string, AppointmentForList[]>();
  for (const appt of sorted) {
    const key = dateKeyOf(appt.scheduledAt);
    if (!byDay.has(key)) {
      byDay.set(key, []);
      order.push(key);
    }
    byDay.get(key)!.push(appt);
  }
  return order.map((dateKey) => ({ dateKey, items: byDay.get(dateKey) ?? [] }));
}

/**
 * Próximos compromissos ainda `agendado`, ordenados por data/hora, limitados
 * a `limit` itens — usado pelo widget compacto de agenda na aba "Visão
 * Geral" do Painel (AgendaOverviewWidget.tsx), que mostra só um vislumbre em
 * vez da lista completa (essa fica na aba "Agenda", via `groupAppointmentsByDay`
 * acima). Um compromisso atrasado que ainda está `agendado` continua
 * aparecendo (mesmo critério de `groupAppointmentsByDay`) — o profissional
 * só o tira da lista marcando concluído/cancelado.
 */
export function upcomingAppointments(
  appointments: AppointmentForList[],
  { limit = 4 }: { limit?: number } = {},
): AppointmentForList[] {
  return [...appointments]
    .filter((appt) => appt.status === 'agendado')
    .sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime())
    .slice(0, limit);
}

export type DayHeadingKind = 'today' | 'tomorrow' | 'other';

/**
 * Classifica uma chave de dia (YYYY-MM-DD) como hoje/amanhã/outro, pra a UI
 * escolher entre "Hoje"/"Amanhã" (t('agenda.day.today'/'tomorrow')) ou uma
 * data formatada por extenso (date-fns) pro resto — mantido como função
 * pura testável sem precisar do dicionário de i18n nem montar o componente.
 */
export function dayHeadingKind(dateKey: string, now: Date = new Date()): DayHeadingKind {
  if (dateKey === dateKeyFromDate(now)) return 'today';
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  if (dateKey === dateKeyFromDate(tomorrow)) return 'tomorrow';
  return 'other';
}
