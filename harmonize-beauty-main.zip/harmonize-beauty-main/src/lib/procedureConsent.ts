// Builds the procedure-specific TCLE (Termo de Consentimento Livre e
// Esclarecido) shown at the end of Estágio 2, once the plan — the
// ApplicationPoint[] overlay (substances, quantities, regions) — is defined.
// See ProcedureConsentModal.tsx for the on-screen (translated) rendering and
// SessaoEstagio2.tsx for where this is wired in.
import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { SUBSTANCE_LABEL, SUBSTANCE_DEFAULT_UNIT } from '@/types/harmonize';
import { regionLabel } from '@/lib/faceRegions';
import i18n from '@/i18n';

export interface ProcedureConsentSummary {
  /** Substances present in the plan, in first-seen order. */
  substances: Substance[];
  /** Total quantity per substance, in that substance's default unit. */
  totalsBySubstance: Partial<Record<Substance, number>>;
  pointCount: number;
  regionLabels: string[];
}

export function summarizeApplicationPoints(points: ApplicationPoint[]): ProcedureConsentSummary {
  const substances: Substance[] = [];
  const totalsBySubstance: Partial<Record<Substance, number>> = {};
  const regionLabels: string[] = [];

  for (const p of points) {
    if (!substances.includes(p.substance)) substances.push(p.substance);
    totalsBySubstance[p.substance] = (totalsBySubstance[p.substance] ?? 0) + p.quantity;
    regionLabels.push(p.label || regionLabel(p.region));
  }

  return { substances, totalsBySubstance, pointCount: points.length, regionLabels };
}

/** Rounds to 2 decimals, avoiding float-sum artifacts (e.g. 0.3 + 0.3 -> "0.6", not "0.6000000000000001"). */
function formatQuantity(n: number): string {
  return String(Math.round(n * 100) / 100);
}

/**
 * Builds the text actually PERSISTED as consents.consent_text — always in
 * Portuguese, regardless of the professional's current UI language. Same
 * fixed-language convention already established for the pre-existing
 * CONSENT_TEXT constant in PacienteDetalhe.tsx (see the code comment on
 * ConsentModal.tsx: the record saved to the DB is a legal record and
 * shouldn't change with the interface language).
 *
 * Sourced from the same `consent.procedure.*` i18n keys the on-screen modal
 * renders (via `i18n.getFixedT('pt')`, pinned to Portuguese regardless of
 * the active language) so the risk copy has a single place to edit instead
 * of two copies that could drift apart.
 */
export function buildProcedureConsentText(summary: ProcedureConsentSummary): string {
  const t = i18n.getFixedT('pt');
  const lines: string[] = [t('consent.procedure.heading'), ''];

  for (const s of summary.substances) {
    lines.push(
      `- ${t('consent.procedure.substanceLine', {
        substance: SUBSTANCE_LABEL[s],
        quantity: formatQuantity(summary.totalsBySubstance[s] ?? 0),
        unit: SUBSTANCE_DEFAULT_UNIT[s],
      })}`
    );
  }
  lines.push(t('consent.procedure.pointsPlanned', { count: summary.pointCount }));
  lines.push('', t('consent.procedure.risksIntro'), '');

  for (const s of summary.substances) {
    const risks = t(`consent.procedure.risks.${s}`, { returnObjects: true }) as string[];
    for (const risk of risks) lines.push(`• ${risk}`);
  }

  lines.push('', t('consent.procedure.generalNotesIntro'));
  const notes = t('consent.procedure.generalNotes', { returnObjects: true }) as string[];
  for (const note of notes) lines.push(`• ${note}`);

  lines.push('', t('consent.procedure.closing'));
  return lines.join('\n');
}
