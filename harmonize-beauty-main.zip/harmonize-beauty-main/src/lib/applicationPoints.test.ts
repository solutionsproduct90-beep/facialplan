import { describe, it, expect } from 'vitest';
import {
  supportsMultiPoint,
  groupKeyOf,
  groupApplicationPoints,
  addPointToGroup,
  removePointFromGroup,
} from './applicationPoints';
import type { ApplicationPoint } from '@/types/harmonize';

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'glabela',
  label: 'Glabela',
  substance: 'toxina_botulinica',
  quantity: 8,
  unit: 'unidades',
  x: 0.5,
  y: 0.34,
  source: 'ai',
  ...overrides,
});

describe('supportsMultiPoint', () => {
  it('only allows splitting toxina_botulinica into multiple points', () => {
    expect(supportsMultiPoint('toxina_botulinica')).toBe(true);
    expect(supportsMultiPoint('acido_hialuronico')).toBe(false);
    expect(supportsMultiPoint('bioestimulador')).toBe(false);
  });
});

describe('groupKeyOf / groupApplicationPoints', () => {
  it('treats a point with no groupId as its own group of one (old/single-point model)', () => {
    const p = point({ id: 'a' });
    expect(groupKeyOf(p)).toBe('a');
    expect(groupApplicationPoints([p])).toEqual([{ key: 'a', points: [p] }]);
  });

  it('groups points sharing a groupId together, preserving first-seen order', () => {
    const points = [
      point({ id: 'a', groupId: 'g1' }),
      point({ id: 'b', region: 'terco_frontal', groupId: 'g2' }),
      point({ id: 'c', groupId: 'g1' }),
    ];
    const groups = groupApplicationPoints(points);
    expect(groups.map((g) => g.key)).toEqual(['g1', 'g2']);
    expect(groups[0].points.map((p) => p.id)).toEqual(['a', 'c']);
    expect(groups[1].points.map((p) => p.id)).toEqual(['b']);
  });
});

describe('addPointToGroup (item 2: multi-point toxin regions)', () => {
  it('splits a single ungrouped point into two, tagging both with a shared groupId and preserving the total dose', () => {
    const points = [point({ id: 'glabela_1', quantity: 8 })];
    const result = addPointToGroup(points, 'glabela_1', 'glabela_2');

    expect(result).toHaveLength(2);
    const [first, second] = result;
    expect(first.groupId).toBe('glabela_1');
    expect(second.groupId).toBe('glabela_1');
    expect(second.id).toBe('glabela_2');
    // Total dose for the region is conserved (8U), split evenly — adding a
    // discretization point must not silently increase the region's dose.
    expect(first.quantity + second.quantity).toBeCloseTo(8);
    expect(first.quantity).toBeCloseTo(4);
    expect(second.quantity).toBeCloseTo(4);
  });

  it('supports growing a region to several points (glabela 3-5, frontal 4-6 clinically) while conserving total dose', () => {
    let points = [point({ id: 'p1', quantity: 12 })];
    points = addPointToGroup(points, 'p1', 'p2');
    points = addPointToGroup(points, 'p1', 'p3');
    points = addPointToGroup(points, 'p1', 'p4');

    const group = points.filter((p) => groupKeyOf(p) === 'p1');
    expect(group).toHaveLength(4);
    expect(group.reduce((sum, p) => sum + p.quantity, 0)).toBeCloseTo(12);
    expect(group.every((p) => p.quantity === 3)).toBe(true);
  });

  it('positions the new point near, but not exactly on top of, the point it split from', () => {
    const points = [point({ id: 'p1', x: 0.5, y: 0.34 })];
    const [, newPoint] = addPointToGroup(points, 'p1', 'p2');
    expect(newPoint.x === 0.5 && newPoint.y === 0.34).toBe(false);
    expect(newPoint.x).toBeGreaterThanOrEqual(0);
    expect(newPoint.x).toBeLessThanOrEqual(1);
    expect(newPoint.y).toBeGreaterThanOrEqual(0);
    expect(newPoint.y).toBeLessThanOrEqual(1);
  });

  it('is a no-op when the target group key does not exist', () => {
    const points = [point({ id: 'p1' })];
    expect(addPointToGroup(points, 'missing-group', 'p2')).toBe(points);
  });

  // Padrão visual de aplicação "punctura seriada" (ver TechniqueLine em
  // src/types/harmonize.ts): desdobrar o grupo distribui os novos pontos ao
  // longo do path da própria linha, não pelo offset diagonal genérico.
  it('positions a new point along the punctura_seriada line path instead of the generic diagonal offset', () => {
    const points = [
      point({
        id: 'p1',
        quantity: 8,
        line: {
          pattern: 'punctura_seriada',
          path: [
            { x: 0.5, y: 0.34 },
            { x: 0.52, y: 0.36 },
            { x: 0.54, y: 0.38 },
            { x: 0.56, y: 0.4 },
          ],
          originIndex: 0,
        },
      }),
    ];
    const result = addPointToGroup(points, 'p1', 'p2');
    const [, newPoint] = result;
    // groupPts.length was 1 at split time — path[1 % 4] = { x: 0.52, y: 0.36 }.
    expect(newPoint.x).toBeCloseTo(0.52);
    expect(newPoint.y).toBeCloseTo(0.36);
    // O ponto novo não herda a linha do template — é seu próprio ponto de punção.
    expect(newPoint.line).toBeUndefined();
  });

  it('falls back to the generic diagonal offset for any other line pattern (or no line at all)', () => {
    const points = [
      point({
        id: 'p1',
        x: 0.5,
        y: 0.34,
        line: { pattern: 'fanning', path: [{ x: 0.5, y: 0.34 }], originIndex: 0 },
      }),
    ];
    const [, newPoint] = addPointToGroup(points, 'p1', 'p2');
    expect(newPoint.x === 0.5 && newPoint.y === 0.34).toBe(false);
    expect(newPoint.line).toBeUndefined();
  });
});

describe('removePointFromGroup', () => {
  it('removes one point from a group and redistributes the remaining total evenly', () => {
    const points = [
      point({ id: 'a', groupId: 'g1', quantity: 3 }),
      point({ id: 'b', groupId: 'g1', quantity: 5 }),
    ];
    const result = removePointFromGroup(points, 'g1', 'a');
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe('b');
    // Remaining point absorbs the full group total (8), not just its own share.
    expect(result[0].quantity).toBeCloseTo(8);
  });

  it('never removes the last remaining point of a group', () => {
    const points = [point({ id: 'a', groupId: 'g1', quantity: 8 })];
    const result = removePointFromGroup(points, 'g1', 'a');
    expect(result).toEqual(points);
  });

  it('leaves other groups untouched', () => {
    const points = [
      point({ id: 'a', groupId: 'g1', quantity: 4 }),
      point({ id: 'b', groupId: 'g1', quantity: 4 }),
      point({ id: 'c', groupId: 'g2', region: 'terco_frontal', quantity: 6 }),
    ];
    const result = removePointFromGroup(points, 'g1', 'a');
    const untouched = result.find((p) => p.id === 'c')!;
    expect(untouched.quantity).toBe(6);
  });
});
