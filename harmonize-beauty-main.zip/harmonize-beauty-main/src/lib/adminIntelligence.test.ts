import { describe, it, expect } from 'vitest';
import {
  mapDoseAccuracyGroups,
  filterAdverseEventPatterns,
  filterAnamnesisFlagFrequency,
  MIN_SAMPLE_SIZE,
  type DoseAccuracyGroupRow,
  type AdverseEventPatternRow,
  type AnamnesisFlagFrequencyRow,
} from './adminIntelligence';

// Chaves que NUNCA podem aparecer em nenhuma forma agregada devolvida por
// este arquivo — dado individualizável (paciente, profissional, sessão ou
// PII direta) não tem lugar num shape que alimenta uma tela agregada de
// admin. Checado explicitamente em cada describe abaixo.
const FORBIDDEN_KEYS = ['patient', 'patient_id', 'patientId', 'name', 'phone', 'professional_id', 'professionalId', 'session_id', 'sessionId'];

function assertNoForbiddenKeys(obj: object) {
  for (const key of Object.keys(obj)) {
    expect(FORBIDDEN_KEYS).not.toContain(key);
  }
}

describe('mapDoseAccuracyGroups', () => {
  // A RPC (admin_dose_accuracy_correlation) já agrega e aplica
  // HAVING count(*) >= 5 inteiramente em SQL desde
  // 20260911090000_add_dose_accuracy_sql_aggregation.sql — este arquivo
  // renomeia pra camelCase e reaplica o corte como segunda camada,
  // não recebe mais linha crua por ponto de aplicação.
  const group = (overrides: Partial<DoseAccuracyGroupRow> = {}): DoseAccuracyGroupRow => ({
    substance: 'acido_hialuronico',
    region: 'labio_superior',
    dose_bucket: 'baixa',
    n: 8,
    average_rating: 4,
    ...overrides,
  });

  it('renomeia os campos pra camelCase', () => {
    const [mapped] = mapDoseAccuracyGroups([group({ n: 8, average_rating: 4.2 })], 5);
    expect(mapped).toEqual({
      substance: 'acido_hialuronico',
      region: 'labio_superior',
      doseBucket: 'baixa',
      n: 8,
      averageRating: 4.2,
    });
  });

  it('mantém múltiplos grupos e ordena por n decrescente', () => {
    const rows = [group({ region: 'labio_superior', n: 6 }), group({ region: 'malar_direita', n: 20 })];
    expect(mapDoseAccuracyGroups(rows, 5).map((g) => g.region)).toEqual(['malar_direita', 'labio_superior']);
  });

  it('omite um grupo com n abaixo do mínimo (segunda camada, além do HAVING da RPC)', () => {
    expect(mapDoseAccuracyGroups([group({ n: 3 })], 5)).toEqual([]);
  });

  it('mantém um grupo exatamente no mínimo de amostra', () => {
    expect(mapDoseAccuracyGroups([group({ n: MIN_SAMPLE_SIZE })], MIN_SAMPLE_SIZE)).toHaveLength(1);
  });

  it('ignora linhas com substância desconhecida, faixa de dose desconhecida ou região vazia, sem quebrar', () => {
    const rows = [
      group({ substance: 'algo_novo_nao_mapeado' }),
      group({ dose_bucket: 'desconhecido' }),
      group({ region: '' }),
    ];
    expect(mapDoseAccuracyGroups(rows, 1)).toEqual([]);
  });

  it('nunca inclui campo de paciente/profissional/sessão no shape de retorno', () => {
    const [mapped] = mapDoseAccuracyGroups([group()], 5);
    assertNoForbiddenKeys(mapped);
  });
});

describe('filterAdverseEventPatterns', () => {
  const row = (overrides: Partial<AdverseEventPatternRow> = {}): AdverseEventPatternRow => ({
    substance: 'acido_hialuronico',
    brand_name: 'Juvederm Voluma',
    event_type: 'nodulo',
    n: 8,
    ...overrides,
  });

  it('mantém um grupo com amostra acima do mínimo, renomeando os campos para camelCase', () => {
    const [pattern] = filterAdverseEventPatterns([row({ n: 8 })], 5);
    expect(pattern).toEqual({ substance: 'acido_hialuronico', brandName: 'Juvederm Voluma', eventType: 'nodulo', n: 8 });
  });

  it('omite um grupo com n abaixo do mínimo', () => {
    expect(filterAdverseEventPatterns([row({ n: 3 })], 5)).toEqual([]);
  });

  it('mantém múltiplos grupos e ordena por n decrescente', () => {
    const rows = [row({ brand_name: 'Marca A', n: 6 }), row({ brand_name: 'Marca B', n: 20 })];
    expect(filterAdverseEventPatterns(rows, 5).map((p) => p.brandName)).toEqual(['Marca B', 'Marca A']);
  });

  it('nunca inclui campo de paciente/profissional/sessão no shape de retorno', () => {
    const [pattern] = filterAdverseEventPatterns([row({ n: 5 })], 5);
    assertNoForbiddenKeys(pattern);
  });
});

describe('filterAnamnesisFlagFrequency', () => {
  const row = (overrides: Partial<AnamnesisFlagFrequencyRow> = {}): AnamnesisFlagFrequencyRow => ({
    flag_key: 'pregnant',
    n: 12,
    ...overrides,
  });

  it('mantém uma flag com amostra acima do mínimo, renomeando o campo para camelCase', () => {
    expect(filterAnamnesisFlagFrequency([row({ n: 12 })], 5)).toEqual([{ flagKey: 'pregnant', n: 12 }]);
  });

  it('omite uma flag com n abaixo do mínimo', () => {
    expect(filterAnamnesisFlagFrequency([row({ n: 2 })], 5)).toEqual([]);
  });

  it('mantém múltiplas flags e ordena por n decrescente', () => {
    const rows = [row({ flag_key: 'cardiac', n: 7 }), row({ flag_key: 'diabetes', n: 30 })];
    expect(filterAnamnesisFlagFrequency(rows, 5).map((f) => f.flagKey)).toEqual(['diabetes', 'cardiac']);
  });

  it('nunca inclui campo de paciente/profissional/sessão no shape de retorno', () => {
    const [freq] = filterAnamnesisFlagFrequency([row({ n: 5 })], 5);
    assertNoForbiddenKeys(freq);
  });
});
