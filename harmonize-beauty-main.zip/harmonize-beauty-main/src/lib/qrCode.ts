import QRCode from 'qrcode';

/**
 * Gera o QR code de verificação embutido no PDF do paciente — item da
 * análise competitiva do Full Face Academy ("cada laudo carrega um QR code
 * apontando pra uma URL de verificação, confirmando que o documento foi
 * gerado de fato pela plataforma").
 *
 * Decisão de escopo: em vez de uma edge function nova de consulta pública
 * (maior escopo do que cabe neste squad), o QR aponta para o link público de
 * apresentação JÁ EXISTENTE da sessão (`/present/:token` — ver
 * `useSessionPresentLink.ts` e `presentLink.ts`). O token só existe se a
 * sessão foi de fato gerada pela plataforma — a linha em
 * `session_present_links` só é criada pelo insert autenticado do
 * profissional dono da sessão — o que já cumpre o papel de "confirma que o
 * documento veio da plataforma" sem precisar de nenhuma tabela/endpoint
 * novo. Uma verificação mais estrita e dedicada ao PDF em si (ex.: hash do
 * arquivo, endpoint que não expõe fotos do paciente) fica como evolução
 * futura caso o produto queira uma camada anti-fraude mais forte que não
 * reaproveite o link de apresentação ao paciente.
 *
 * Retorna `null` (em vez de lançar) quando a geração falha — mesmo padrão
 * defensivo de `fetchImageAsDataUrl` em SessaoEstagio3.tsx: o PDF é desenhado
 * sem o QR em vez de quebrar a exportação inteira.
 */
export async function generateQrCodeDataUrl(url: string | null | undefined): Promise<string | null> {
  if (!url) return null;
  try {
    return await QRCode.toDataURL(url, {
      margin: 1,
      width: 256,
      color: { dark: '#1A1918', light: '#FFFFFF' },
    });
  } catch {
    return null;
  }
}
