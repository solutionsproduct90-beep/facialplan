/**
 * Camada fina de persistência local via IndexedDB, própria para o rascunho
 * offline de sessão (ver src/hooks/useOfflineSessionDraft.ts — fatia
 * "Modo offline-first (PWA) completo pra sala de procedimento"). IndexedDB
 * nativo em vez de uma lib externa (ex. `idb`): o uso aqui é só um
 * key-value store com um único object store, sem cursores/índices — não
 * vale o peso extra no bundle de uma lib inteira de wrappers para isso.
 *
 * Feature-detecta `indexedDB` em vez de assumir que existe: navegação
 * privada em alguns browsers desativa/lança em IndexedDB, e o ambiente de
 * teste (jsdom, usado por todo o resto da suíte) não implementa a API a
 * menos que `fake-indexeddb` seja importado explicitamente num arquivo de
 * teste (ver offlineDb.test.ts) — sem essa checagem, qualquer página que
 * use o hook quebraria em todo teste existente que a renderiza. Quando
 * indisponível, todas as funções abaixo viram no-ops (get resolve
 * `undefined`, put/delete resolvem sem persistir nada) — o rascunho local
 * simplesmente não existe nessa sessão de navegador, sem travar o app (é só
 * uma rede de segurança, nunca a fonte da verdade dos dados clínicos).
 */

const DB_NAME = 'harmonize-offline';
const DB_VERSION = 1;
const STORE_NAME = 'session_drafts';

const hasIndexedDb = () =>
  typeof indexedDB !== 'undefined' && indexedDB !== null;

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  return dbPromise;
}

/** Lê uma entrada pela chave; `undefined` se não existir ou se IndexedDB
 * estiver indisponível (ver comentário no topo do arquivo). Nunca lança —
 * uma falha de leitura vira `undefined` (com log), pra nunca travar a tela
 * que só está tentando recuperar um rascunho opcional. */
export async function getDraft<T>(key: string): Promise<T | undefined> {
  if (!hasIndexedDb()) return undefined;
  try {
    const db = await openDb();
    return await new Promise<T | undefined>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(key);
      req.onsuccess = () => resolve(req.result as T | undefined);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('[offlineDb] Falha ao ler rascunho local:', err);
    return undefined;
  }
}

/** Substitui (ou cria) a entrada inteira pela chave. Nunca lança — uma
 * falha de escrita só é logada, pra nunca travar o fluxo principal do app
 * por causa do backup local opcional. */
export async function putDraft<T>(key: string, value: T): Promise<void> {
  if (!hasIndexedDb()) return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('[offlineDb] Falha ao salvar rascunho local:', err);
  }
}

/** Remove a entrada pela chave (no-op silencioso se não existir). */
export async function deleteDraft(key: string): Promise<void> {
  if (!hasIndexedDb()) return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('[offlineDb] Falha ao apagar rascunho local:', err);
  }
}

/** Só para testes: descarta a conexão em memória com o banco. Necessário
 * porque `fake-indexeddb` é reinstalado por teste (ver offlineDb.test.ts),
 * mas o `dbPromise` cacheado neste módulo sobrevive entre `it()`s do mesmo
 * arquivo — sem resetar, uma conexão aberta contra um banco fake antigo
 * ficaria presa em memória. */
export function __resetOfflineDbForTests() {
  dbPromise = null;
}
