// Geração das linhas de técnica de aplicação (Etapa 2, ver TechniqueLine em
// src/types/harmonize.ts) a partir de um ponto de origem (a punção real) e,
// quando disponível, do polígono real da região (src/lib/faceRegions.ts,
// `regionPolygonForRegion`) — parte do efeito "scanner real do rosto" pedido
// pelo dono do produto: em vez de só um ponto solto, o profissional vê a
// direção/alcance plausível da técnica escolhida sobre a foto.
//
// Funções PURAS e sem I/O (mesmo padrão de faceRegions.ts) — nunca lançam
// exceção: quando `regionPolygon` é null (região ainda sem `areaIndices`
// curado, ou detecção incompleta), cada função degrada para uma
// direção/comprimento padrão razoável em vez de falhar. Isso é deliberado:
// o padrão visual de aplicação é sempre oferecido na Etapa 2, mesmo para
// regiões cujo polígono ainda não foi curado (ver comentários "PENDENTE" em
// faceRegions.ts) — só o alcance fica menos preciso, nunca quebra a UI.
import type { TechniqueLine, TechniqueLinePattern } from '@/types/harmonize';

type Point = { x: number; y: number };

const clamp01 = (v: number): number => Math.min(1, Math.max(0, v));

const clampPoint = (p: Point): Point => ({ x: clamp01(p.x), y: clamp01(p.y) });

// Comprimento/direção padrão quando não há polígono de região disponível —
// arbitrário mas plausível (5% da largura/altura normalizada da foto é um
// traço curto e discreto, na escala dos próprios marcadores de ponto).
// Direção "para cima" (dy negativo) é só um ponto de partida neutro; o que
// importa é nunca lançar exceção, não a precisão anatômica desse fallback.
const DEFAULT_SEGMENT_LENGTH = 0.05;
const DEFAULT_DIRECTION = { dx: 0, dy: -1 };

/** Ponto do polígono mais distante da origem, e essa distância — usado como
 * proxy simples de "até onde a região se estende a partir daqui", sem exigir
 * um cálculo de eixo principal (PCA) mais caro para um polígono pequeno. */
function farthestPolygonPoint(origin: Point, polygon: Point[]): { point: Point; distance: number } {
  let best = polygon[0];
  let bestDistSq = -1;
  for (const p of polygon) {
    const distSq = (p.x - origin.x) ** 2 + (p.y - origin.y) ** 2;
    if (distSq > bestDistSq) {
      bestDistSq = distSq;
      best = p;
    }
  }
  return { point: best, distance: Math.sqrt(bestDistSq) };
}

/** Direção (vetor unitário) e comprimento do traço principal de uma técnica,
 * a partir da origem: aponta para o ponto do polígono mais distante e usa
 * 85% dessa distância (para o traço ficar visivelmente DENTRO da região, não
 * tocando exatamente a borda). Sem polígono (ou polígono degenerado —
 * distância ~0), cai no padrão fixo documentado acima. */
function mainDirectionAndLength(origin: Point, regionPolygon: Point[] | null): { dx: number; dy: number; length: number } {
  if (!regionPolygon || regionPolygon.length < 3) {
    return { dx: DEFAULT_DIRECTION.dx, dy: DEFAULT_DIRECTION.dy, length: DEFAULT_SEGMENT_LENGTH };
  }
  const { point, distance } = farthestPolygonPoint(origin, regionPolygon);
  if (!Number.isFinite(distance) || distance < 1e-6) {
    return { dx: DEFAULT_DIRECTION.dx, dy: DEFAULT_DIRECTION.dy, length: DEFAULT_SEGMENT_LENGTH };
  }
  return { dx: (point.x - origin.x) / distance, dy: (point.y - origin.y) / distance, length: distance * 0.85 };
}

/** Metade da largura/altura da caixa delimitadora do polígono — usado pelo
 * reticulado para saber o quanto se espalhar a partir da origem em cada
 * direção. Sem polígono, usa o mesmo comprimento padrão dos outros padrões. */
function polygonHalfExtents(regionPolygon: Point[] | null): { hx: number; hy: number } {
  if (!regionPolygon || regionPolygon.length === 0) {
    return { hx: DEFAULT_SEGMENT_LENGTH, hy: DEFAULT_SEGMENT_LENGTH };
  }
  const xs = regionPolygon.map((p) => p.x);
  const ys = regionPolygon.map((p) => p.y);
  const hx = Math.max((Math.max(...xs) - Math.min(...xs)) / 2, 0.01);
  const hy = Math.max((Math.max(...ys) - Math.min(...ys)) / 2, 0.01);
  return { hx, hy };
}

/** Um segmento reto a partir da origem, na direção do "alcance" da região —
 * técnica linear/retrógrada: a agulha entra num ponto e o produto é
 * depositado ao longo de uma linha reta conforme ela é retirada. */
function buildLinearRetrogradaPath(origin: Point, regionPolygon: Point[] | null): Point[] {
  const { dx, dy, length } = mainDirectionAndLength(origin, regionPolygon);
  const end = clampPoint({ x: origin.x + dx * length, y: origin.y + dy * length });
  return [origin, end];
}

/** 4 raios irradiando da origem num arco de 45° (meio-termo do intervalo
 * 30–60° pedido) — técnica em leque: várias passadas a partir de um único
 * ponto de punção. Representado como UMA polyline em zigue-zague
 * (origem→ponta→origem→ponta…) para caber no formato `path: Point[]` de
 * TechniqueLine sem precisar de múltiplos segmentos independentes. */
function buildFanningPath(origin: Point, regionPolygon: Point[] | null): Point[] {
  const { dx, dy, length } = mainDirectionAndLength(origin, regionPolygon);
  const baseAngle = Math.atan2(dy, dx);
  const rayCount = 4; // dentro do intervalo pedido de 3 a 5
  const arc = (45 * Math.PI) / 180;

  const path: Point[] = [origin];
  for (let i = 0; i < rayCount; i++) {
    const t = i / (rayCount - 1) - 0.5; // -0.5 .. 0.5
    const angle = baseAngle + t * arc;
    const tip = clampPoint({ x: origin.x + Math.cos(angle) * length, y: origin.y + Math.sin(angle) * length });
    path.push(tip, origin);
  }
  path.pop(); // remove a última volta redundante à origem
  return path;
}

/** Grade de segmentos paralelos em duas orientações ortogonais (3 linhas
 * horizontais + 3 verticais) dentro da caixa delimitadora da região —
 * técnica reticulada/em grade. Também representada como uma única polyline
 * em zigue-zague, sempre começando na origem. */
function buildReticuladoPath(origin: Point, regionPolygon: Point[] | null): Point[] {
  const { hx, hy } = polygonHalfExtents(regionPolygon);
  const rows = 3;

  const path: Point[] = [origin];
  for (let i = 0; i < rows; i++) {
    const y = origin.y - hy + (i / (rows - 1)) * (2 * hy);
    const [x1, x2] = i % 2 === 0 ? [origin.x - hx, origin.x + hx] : [origin.x + hx, origin.x - hx];
    path.push(clampPoint({ x: x1, y }), clampPoint({ x: x2, y }));
  }
  for (let i = 0; i < rows; i++) {
    const x = origin.x - hx + (i / (rows - 1)) * (2 * hx);
    const [y1, y2] = i % 2 === 0 ? [origin.y - hy, origin.y + hy] : [origin.y + hy, origin.y - hy];
    path.push(clampPoint({ x, y: y1 }), clampPoint({ x, y: y2 }));
  }
  return path;
}

/** Pontos-guia distribuídos ao longo da mesma direção/alcance usada pela
 * técnica linear/retrógrada — punctura seriada: várias micropunções
 * discretas ao longo de uma linha, em vez de um único ponto ou um traço
 * contínuo. */
function buildPuncturaSeriadaPath(origin: Point, regionPolygon: Point[] | null): Point[] {
  const { dx, dy, length } = mainDirectionAndLength(origin, regionPolygon);
  const guideCount = 4;
  const path: Point[] = [];
  for (let i = 0; i < guideCount; i++) {
    const t = i / (guideCount - 1);
    path.push(clampPoint({ x: origin.x + dx * length * t, y: origin.y + dy * length * t }));
  }
  return path;
}

/**
 * Gera a linha de técnica de um ponto de aplicação. `origin` é sempre
 * `path[0]` no resultado (originIndex = 0 em todos os padrões) — a punção
 * real nunca deixa de ser o primeiro ponto da polyline, para que o
 * profissional sempre identifique de onde a técnica parte.
 *
 * Nunca lança exceção: qualquer situação inesperada (polígono degenerado,
 * coordenadas fora do normal) cai no `try/catch` abaixo e devolve uma linha
 * mínima só com a origem, em vez de quebrar a tela.
 */
export function buildTechniqueLine(
  pattern: TechniqueLinePattern,
  origin: { x: number; y: number },
  originLandmarkIndex: number | undefined,
  regionPolygon: { x: number; y: number }[] | null
): TechniqueLine {
  try {
    let path: Point[];
    switch (pattern) {
      case 'linear_retrograda':
        path = buildLinearRetrogradaPath(origin, regionPolygon);
        break;
      case 'fanning':
        path = buildFanningPath(origin, regionPolygon);
        break;
      case 'reticulado':
        path = buildReticuladoPath(origin, regionPolygon);
        break;
      case 'punctura_seriada':
        path = buildPuncturaSeriadaPath(origin, regionPolygon);
        break;
      default:
        path = [origin];
    }
    return {
      pattern,
      path,
      originIndex: 0,
      // Só a origem tem de fato um landmark associado — os demais pontos são
      // guias geométricos puros (ver comentário de `landmarkIndices` em
      // TechniqueLine, src/types/harmonize.ts).
      landmarkIndices: path.map((_, i) => (i === 0 ? originLandmarkIndex : undefined)),
    };
  } catch {
    return { pattern, path: [origin], originIndex: 0, landmarkIndices: [originLandmarkIndex] };
  }
}
