import type { ApplicationPoint, Insumo } from '@/types/harmonize';
import { computeBudget } from './budget';
import { returnRadarForSessions, type SessionForReturnRadar } from './returnRadar';

// Funções puras usadas pelo /painel (src/pages/Painel.tsx) — separadas do
// componente pra poderem ser testadas sem montar a página nem tocar
// Supabase. Nenhuma aqui inventa "score de harmonia"/naturalidade (decisão
// de produto, ver comentário em src/types/harmonize.ts linhas 35-42): só
// contagem de sessões, R$ de orçamento e dias de uso — métricas reais.

export type GoalPeriod = 'weekly' | 'monthly';

/** Sessão reduzida ao mínimo que as métricas do Painel precisam ler. */
export type SessionForMetrics = {
  created_at: string | null;
  stage2_overlay: unknown;
};

function toDateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Meia-noite (hora local) do dia informado — usado como base pra somas por período. */
function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

/**
 * Início da semana corrente (segunda-feira, hora local) — semana "de
 * trabalho" em vez de domingo-a-sábado, mais próxima de como um profissional
 * pensa a própria agenda.
 */
export function startOfWeek(date: Date): Date {
  const d = startOfDay(date);
  const dayIndex = d.getDay(); // 0 = domingo ... 6 = sábado
  const diffToMonday = (dayIndex + 6) % 7; // domingo -> 6, segunda -> 0, terça -> 1...
  d.setDate(d.getDate() - diffToMonday);
  return d;
}

/** Início do mês corrente (hora local). */
export function startOfMonth(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

/** Fim da semana corrente (domingo à meia-noite, hora local) — contraparte de
 * `startOfWeek` acima, mesma semana "de trabalho" segunda-a-domingo. */
function endOfWeek(date: Date): Date {
  const start = startOfWeek(date);
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  return end;
}

/**
 * Conta sessões criadas dentro do período corrente (semana ou mês, conforme
 * a meta configurada) — base tanto do card de meta quanto do denominador
 * "sessões esta semana/mês" mostrado ao profissional.
 */
export function countSessionsInPeriod(
  sessions: Pick<SessionForMetrics, 'created_at'>[],
  period: GoalPeriod,
  now: Date = new Date(),
): number {
  const start = period === 'weekly' ? startOfWeek(now) : startOfMonth(now);
  return sessions.filter((s) => {
    if (!s.created_at) return false;
    const t = new Date(s.created_at).getTime();
    return Number.isFinite(t) && t >= start.getTime();
  }).length;
}

export type GoalProgress = {
  current: number;
  target: number;
  pct: number; // 0 a 1
  achieved: boolean;
};

/**
 * Progresso da meta configurada pelo profissional. `target` ausente/inválido
 * (nenhuma meta configurada ainda) retorna `null` — quem consome deve
 * mostrar um estado de "configurar meta", nunca um alvo inventado.
 */
export function computeGoalProgress(current: number, target: number | null | undefined): GoalProgress | null {
  if (!target || target <= 0) return null;
  const pct = Math.min(1, current / target);
  return { current, target, pct, achieved: current >= target };
}

/**
 * Potencial financeiro do mês corrente: soma o orçamento (`computeBudget`,
 * mesmo cálculo usado no PDF do Estágio 3) de cada sessão criada no mês que
 * já tem pontos de aplicação lançados. Sessão sem `stage2_overlay` (ainda no
 * Estágio 1, ou nunca chegou lá) não entra na soma — não há orçamento a
 * somar. Reaproveita `insumos`/`laborFeePerSession` do profissional, os
 * mesmos usados na Etapa 3.
 */
export function computeMonthlyPotential(
  sessions: SessionForMetrics[],
  insumos: Insumo[] | null | undefined,
  laborFeePerSession: number | null | undefined,
  now: Date = new Date(),
): number {
  const start = startOfMonth(now);
  const end = new Date(start.getFullYear(), start.getMonth() + 1, 1);
  let total = 0;
  for (const s of sessions) {
    if (!s.created_at) continue;
    const t = new Date(s.created_at).getTime();
    if (!Number.isFinite(t) || t < start.getTime() || t >= end.getTime()) continue;
    const points = Array.isArray(s.stage2_overlay) ? (s.stage2_overlay as ApplicationPoint[]) : [];
    if (points.length === 0) continue;
    total += computeBudget(points, insumos, laborFeePerSession).totalPrice;
  }
  return total;
}

export type SubscriptionRoi = {
  hasData: boolean; // false quando o profissional ainda não configurou o valor da mensalidade
  multiple: number; // "já pagou Nx a assinatura" — 0 quando hasData é false
};

/**
 * ROI da assinatura: potencial financeiro do mês ÷ valor da mensalidade
 * configurado pelo profissional (não existe no schema hoje — não vem do
 * webhook da Hotmart, que só grava status/subscriber_code). Sem valor
 * configurado (null/undefined/0), não há divisão possível: `hasData: false`,
 * e quem consome deve pedir pra configurar em vez de mostrar "0x" ou um
 * valor de mercado assumido.
 */
export function computeSubscriptionRoi(
  monthlyPotential: number,
  subscriptionMonthlyValue: number | null | undefined,
): SubscriptionRoi {
  if (!subscriptionMonthlyValue || subscriptionMonthlyValue <= 0) {
    return { hasData: false, multiple: 0 };
  }
  return { hasData: true, multiple: monthlyPotential / subscriptionMonthlyValue };
}

/** Formata o multiplicador do ROI pra exibição: "30" em vez de "30.0", "2.3" quando não é inteiro. */
export function formatRoiMultiple(multiple: number): string {
  if (!Number.isFinite(multiple)) return '0';
  return (Math.round(multiple * 10) / 10).toFixed(1).replace(/\.0$/, '');
}

export type SimulationAccuracyRatingForMetrics = {
  rating: number; // 1 a 5, Likert — ver session_simulation_accuracy_ratings
};

export type SimulationAccuracyStats = {
  average: number; // 1 a 5
  count: number;
  goodMatchPercentage: number; // 0 a 100: % de notas 4 ou 5 ("correspondeu bem"/"muito bem")
};

/**
 * Agrega o Índice de Precisão da Simulação por profissional — média simples
 * da escala Likert (1-5) e o percentual de sessões avaliadas em que a
 * simulação "correspondeu bem" (nota 4 ou 5) ao resultado real. Cada nota já
 * é a AUTOAVALIAÇÃO SUBJETIVA do próprio profissional (ver migration
 * 20260911030000_add_session_simulation_accuracy_ratings.sql): esta função
 * só soma/divide o que foi digitado, nunca calcula uma nota sozinha — mesmo
 * cuidado de "nenhum score de harmonia/precisão inventado" do resto deste
 * arquivo (comentário no topo). Sem avaliações ainda, retorna `null`: quem
 * consome deve mostrar um estado vazio, nunca uma média/percentual
 * inventados (ex. 0%).
 */
export function computeSimulationAccuracyStats(
  ratings: SimulationAccuracyRatingForMetrics[],
): SimulationAccuracyStats | null {
  if (!ratings || ratings.length === 0) return null;
  const sum = ratings.reduce((acc, r) => acc + r.rating, 0);
  const goodMatches = ratings.filter((r) => r.rating >= 4).length;
  return {
    average: sum / ratings.length,
    count: ratings.length,
    goodMatchPercentage: (goodMatches / ratings.length) * 100,
  };
}

export type ConversionBenchmarkBucket = 'top_third' | 'middle_third' | 'bottom_third';

/** Linha crua devolvida por `get_professional_conversion_benchmark` (RPC SECURITY DEFINER, ver supabase/migrations/20260914100000_...). */
export type ConversionBenchmarkRow = { conversion_bucket: string | null };

/**
 * Extrai o bucket de posição relativa da RPC de benchmark de conversão pro
 * card "Comparativo de conversão" do Painel. Zero linhas (RPC não achou
 * grupo de comparação com pelo menos 5 pares da mesma especialidade, com
 * dado suficiente e consentido — ver a migration) ou um valor fora do enum
 * esperado (defesa contra retorno inesperado/erro de rede tratado como
 * ausência de dado) devolvem `null`: quem consome deve OMITIR o card
 * inteiro, nunca mostrar um placeholder de "sem dados" — mesmo cuidado do
 * resto deste arquivo de "nenhuma métrica inventada quando falta dado
 * real". Nunca revela quantos pares existem no grupo nem a taxa exata de
 * ninguém — só o terço em que o profissional caiu.
 */
export function getConversionBenchmarkBucket(
  rows: ConversionBenchmarkRow[] | null | undefined,
): ConversionBenchmarkBucket | null {
  const bucket = rows?.[0]?.conversion_bucket;
  if (bucket === 'top_third' || bucket === 'middle_third' || bucket === 'bottom_third') return bucket;
  return null;
}

export type ReturnRadarAlertCounts = {
  dueThisWeek: number;
  overdue: number;
};

/**
 * Alerta agregado do Radar de Retorno (`src/lib/returnRadar.ts`) pro card do
 * Painel — pedido explícito do dono do produto por uma via mais proativa que
 * o badge discreto já existente em Pacientes.tsx/PacienteDetalhe.tsx: ao
 * abrir o app, quantos pacientes já estão dentro (ou entrando nesta semana)
 * da janela prevista de retorno, versus quantos já passaram dela por
 * completo. Resumo NUMÉRICO só — a lista de nomes por trás de cada contador
 * já existe em Pacientes.tsx (badge + botão de lembrete por paciente); aqui
 * é só "olha, tem gente esperando contato".
 *
 * `dueThisWeek` conta radar ativo E AINDA NÃO atrasado cuja janela já abriu
 * (início da janela até o fim desta semana) — ou seja, "já dá pra agendar o
 * retorno" agora ou o mais tardar até domingo. Não é um recorte estrito de
 * "a janela começa exatamente nesta semana": como cada janela dura meses
 * (ver SUBSTANCE_RETURN_WINDOW_MONTHS em returnRadar.ts), o que importa pro
 * profissional é "já posso agendar", e isso continua verdadeiro contanto que
 * o paciente ainda não tenha virado `isOverdue`. `overdue` conta os que já
 * passaram do fim da janela sem retorno registrado (mesma flag
 * `ReturnRadar.isOverdue`) — os dois contadores são mutuamente exclusivos
 * por paciente (um radar cai em um dos dois, nunca nos dois).
 *
 * `patients` é a mesma forma de join usada em Pacientes.tsx
 * (`patients(*, sessions(...))`), reduzida ao mínimo que
 * `returnRadarForSessions` precisa ler por paciente — não dá pra reaproveitar
 * `sessionsData` que o Painel já busca pra ROI/meta/streak porque aquele veio
 * sem separação por paciente e com janela de só 90 dias (o Radar de Retorno
 * precisa da ÚLTIMA sessão concluída de CADA paciente, que pode ter meses).
 */
export function aggregateReturnRadarAlerts<T extends SessionForReturnRadar>(
  patients: { sessions: T[] | null | undefined }[] | null | undefined,
  now: Date = new Date(),
): ReturnRadarAlertCounts {
  const counts: ReturnRadarAlertCounts = { dueThisWeek: 0, overdue: 0 };
  if (!Array.isArray(patients)) return counts;

  const weekEnd = endOfWeek(now);
  for (const patient of patients) {
    const radar = returnRadarForSessions(patient.sessions, now);
    if (!radar) continue;
    if (radar.isOverdue) {
      counts.overdue += 1;
    } else if (radar.windowStart.getTime() <= weekEnd.getTime()) {
      counts.dueThisWeek += 1;
    }
  }
  return counts;
}

/**
 * Sequência de dias consecutivos com pelo menos uma sessão criada, contando
 * a partir de hoje. Tolerante ao dia corrente ainda não ter atividade — o
 * dia não acabou, então "hoje sem sessão ainda" não zera a sequência de
 * ontem pra trás (mesmo espírito de streak de apps de hábito): só quebra de
 * fato quando ONTEM também não teve sessão.
 */
export function computeActiveDayStreak(
  activityDates: (string | null | undefined)[],
  now: Date = new Date(),
): number {
  const days = new Set<string>();
  for (const raw of activityDates) {
    if (!raw) continue;
    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) continue;
    days.add(toDateKey(d));
  }

  const cursor = startOfDay(now);
  if (!days.has(toDateKey(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
  }

  let streak = 0;
  while (days.has(toDateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
