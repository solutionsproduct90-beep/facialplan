import { describe, it, expect } from "vitest";
import {
  parsePhoneForEdit,
  composePhone,
  dialCodeForCountry,
  DEFAULT_DIAL_CODE,
  OTHER_DIAL_CODE,
} from "./phone";

describe("phone — DDI (código do país) do telefone do paciente", () => {
  describe("dialCodeForCountry", () => {
    it("maps each of the app's 5 markets to their DDI", () => {
      expect(dialCodeForCountry("BR")).toBe("+55");
      expect(dialCodeForCountry("US")).toBe("+1");
      expect(dialCodeForCountry("ES")).toBe("+34");
      expect(dialCodeForCountry("FR")).toBe("+33");
      expect(dialCodeForCountry("IT")).toBe("+39");
    });

    it("falls back to the default (Brazil) DDI for a country outside the 5 markets, or when unknown", () => {
      expect(dialCodeForCountry("PT")).toBe(DEFAULT_DIAL_CODE);
      expect(dialCodeForCountry(null)).toBe(DEFAULT_DIAL_CODE);
      expect(dialCodeForCountry(undefined)).toBe(DEFAULT_DIAL_CODE);
    });
  });

  describe("composePhone", () => {
    it("joins a known DDI with the local number, stripping any non-digit formatting", () => {
      expect(composePhone("+55", "", "(21) 65892-4242")).toBe("+5521658924242");
      expect(composePhone("+1", "", "212-555-0100")).toBe("+12125550100");
    });

    it("returns null when the local number is empty — phone stays optional", () => {
      expect(composePhone("+55", "", "")).toBeNull();
      expect(composePhone("+55", "", "   ")).toBeNull();
    });

    it("uses the free-typed custom DDI (with digits only, '+' re-added) when OTHER is selected", () => {
      expect(composePhone(OTHER_DIAL_CODE, "+351911222333", "")).toBe("+351911222333");
      expect(composePhone(OTHER_DIAL_CODE, "351 911 222 333", "")).toBe("+351911222333");
    });

    it("returns null for OTHER with no digits typed", () => {
      expect(composePhone(OTHER_DIAL_CODE, "", "")).toBeNull();
      expect(composePhone(OTHER_DIAL_CODE, "+", "")).toBeNull();
    });
  });

  describe("parsePhoneForEdit", () => {
    it("splits a phone already stored with a known DDI into dial + local", () => {
      expect(parsePhoneForEdit("+5521658924242")).toEqual({
        dial: "+55",
        customDial: "",
        local: "21658924242",
      });
    });

    it("picks the longest matching known DDI so +1 doesn't shadow +39/+34/+33", () => {
      expect(parsePhoneForEdit("+390612345678")).toEqual({
        dial: "+39",
        customDial: "",
        local: "0612345678",
      });
    });

    it("treats legacy phones stored without a leading '+' as local-only, defaulting the DDI", () => {
      expect(parsePhoneForEdit("21658924242")).toEqual({
        dial: DEFAULT_DIAL_CODE,
        customDial: "",
        local: "21658924242",
      });
    });

    it("keeps an unrecognized '+' DDI fully editable as a free-typed custom code", () => {
      expect(parsePhoneForEdit("+351911222333")).toEqual({
        dial: OTHER_DIAL_CODE,
        customDial: "+351911222333",
        local: "",
      });
    });

    it("returns an empty, default-DDI shape for an empty/null stored phone", () => {
      expect(parsePhoneForEdit(null)).toEqual({ dial: DEFAULT_DIAL_CODE, customDial: "", local: "" });
      expect(parsePhoneForEdit("")).toEqual({ dial: DEFAULT_DIAL_CODE, customDial: "", local: "" });
    });

    it("round-trips through composePhone back to the same stored value", () => {
      const stored = "+5521658924242";
      const parsed = parsePhoneForEdit(stored);
      expect(composePhone(parsed.dial, parsed.customDial, parsed.local)).toBe(stored);
    });
  });
});
