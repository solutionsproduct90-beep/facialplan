/**
 * Helpers for the public, unauthenticated patient-feedback/NPS link
 * (`/feedback/:token`). Kept framework-free so the token shape rules and the
 * URL format can be unit tested without mounting the pages that use them —
 * mirrors presentLink.ts, which does the same for `/present/:token`.
 */

// Matches a standard UUID (any RFC 4122 variant/version) — the format
// Postgres' gen_random_uuid() produces for `patient_feedback_links.token`.
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Cheap client-side shape check for a feedback-link token, run before ever
 * calling the public-patient-feedback edge function. This is NOT the
 * security boundary (the edge function is, since it requires an exact match
 * against `patient_feedback_links.token` via the service role key); it only
 * avoids sending obviously-malformed values to the backend and lets the UI
 * show the "invalid link" state immediately.
 */
export function isValidFeedbackToken(token: string | null | undefined): token is string {
  return typeof token === 'string' && UUID_REGEX.test(token);
}

/**
 * Builds the absolute, shareable feedback URL for a given token.
 * `origin` should be `window.location.origin` at the call site.
 */
export function buildFeedbackLink(origin: string, token: string): string {
  return `${origin.replace(/\/+$/, '')}/feedback/${token}`;
}
