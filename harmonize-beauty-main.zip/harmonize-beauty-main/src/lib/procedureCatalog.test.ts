import { describe, it, expect } from 'vitest';
import {
  PROCEDURE_CATALOG,
  PROCEDURE_CATEGORIES,
  INTENSITY_LEVELS,
  proceduresForSubstance,
  getProcedure,
  procedureNameKey,
  procedureDisplayName,
  suggestedDoseForLevel,
  isWellFormedCatalog,
  planBQuantity,
  reduceToPlanB,
  hasReducedPlanB,
} from './procedureCatalog';
import { FACE_REGION_KEYS } from '@/lib/faceRegions';
import type { ApplicationPoint } from '@/types/harmonize';

const point = (overrides: Partial<ApplicationPoint> = {}): ApplicationPoint => ({
  id: 'p1',
  region: 'labio_superior',
  label: 'Lábio Superior',
  substance: 'acido_hialuronico',
  quantity: 2,
  unit: 'ml',
  x: 0.5,
  y: 0.5,
  source: 'manual',
  ...overrides,
});

describe('PROCEDURE_CATALOG — well-formedness', () => {
  it('is non-empty', () => {
    expect(PROCEDURE_CATALOG.length).toBeGreaterThan(0);
  });

  it('every procedure references at least one valid FaceRegionKey', () => {
    for (const procedure of PROCEDURE_CATALOG) {
      expect(procedure.regions.length).toBeGreaterThan(0);
      for (const region of procedure.regions) {
        expect(FACE_REGION_KEYS).toContain(region);
      }
    }
  });

  it('has unique ids', () => {
    const ids = PROCEDURE_CATALOG.map((p) => p.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('every category used is one of the declared PROCEDURE_CATEGORIES', () => {
    for (const procedure of PROCEDURE_CATALOG) {
      expect(PROCEDURE_CATEGORIES).toContain(procedure.category);
    }
  });

  it('does not include any dental/odontology category — out of scope for this injectables app', () => {
    const categories = new Set(PROCEDURE_CATALOG.map((p) => p.category));
    for (const category of categories) {
      expect(category.toLowerCase()).not.toMatch(/dental|odont/);
    }
  });

  it('defines a suave/medio/alto dose range for every procedure, each with min <= max', () => {
    for (const procedure of PROCEDURE_CATALOG) {
      for (const level of INTENSITY_LEVELS) {
        const range = procedure.doseRangeByLevel[level];
        expect(range).toBeDefined();
        expect(range.min).toBeGreaterThan(0);
        expect(range.min).toBeLessThanOrEqual(range.max);
      }
    }
  });

  it('escalates dose ranges from suave to alto (no level typically doses lower than a gentler one)', () => {
    for (const procedure of PROCEDURE_CATALOG) {
      const { suave, medio, alto } = procedure.doseRangeByLevel;
      expect(suave.min).toBeLessThanOrEqual(medio.min);
      expect(medio.min).toBeLessThanOrEqual(alto.min);
    }
  });

  it('is reported well-formed by isWellFormedCatalog()', () => {
    expect(isWellFormedCatalog()).toBe(true);
  });

  it('flags a catalog with an unknown region slug as not well-formed', () => {
    const broken = [
      {
        ...PROCEDURE_CATALOG[0],
        regions: ['regiao_inexistente' as never],
      },
    ];
    expect(isWellFormedCatalog(broken)).toBe(false);
  });
});

describe('proceduresForSubstance', () => {
  it('only returns procedures matching the given substance', () => {
    for (const procedure of proceduresForSubstance('toxina_botulinica')) {
      expect(procedure.substance).toBe('toxina_botulinica');
    }
  });

  it('covers all three substances with at least one procedure each', () => {
    expect(proceduresForSubstance('acido_hialuronico').length).toBeGreaterThan(0);
    expect(proceduresForSubstance('toxina_botulinica').length).toBeGreaterThan(0);
    expect(proceduresForSubstance('bioestimulador').length).toBeGreaterThan(0);
  });
});

describe('getProcedure', () => {
  it('finds a procedure by id', () => {
    expect(getProcedure('preenchimento_labial')?.name).toBe('Preenchimento Labial');
  });

  it('returns undefined for an unknown or missing id', () => {
    expect(getProcedure('nao_existe')).toBeUndefined();
    expect(getProcedure(undefined)).toBeUndefined();
  });
});

describe('procedureNameKey / procedureDisplayName', () => {
  it('builds a stable i18n key namespaced under procedureCatalog.procedures', () => {
    expect(procedureNameKey('preenchimento_labial')).toBe('procedureCatalog.procedures.preenchimento_labial.name');
  });

  it('resolves the display name via the given translate function, passing the pt name as defaultValue', () => {
    const translate = (key: string, options?: { defaultValue?: string }) => options?.defaultValue ?? key;
    expect(procedureDisplayName('preenchimento_labial', translate)).toBe('Preenchimento Labial');
  });

  it('lets the translate function override the fallback (simulating a loaded locale)', () => {
    const translate = () => 'Lip Filler';
    expect(procedureDisplayName('preenchimento_labial', translate)).toBe('Lip Filler');
  });

  it('returns undefined for an unknown or missing procedureId, so callers can omit the label entirely', () => {
    const translate = (key: string, options?: { defaultValue?: string }) => options?.defaultValue ?? key;
    expect(procedureDisplayName('nao_existe', translate)).toBeUndefined();
    expect(procedureDisplayName(undefined, translate)).toBeUndefined();
  });
});

describe('suggestedDoseForLevel', () => {
  it('returns the midpoint of the range for an HA (ml) procedure, rounded to 0.1', () => {
    const procedure = getProcedure('preenchimento_labial')!;
    // suave: 0.5–1.0 -> midpoint 0.75, rounded to nearest 0.1 -> 0.8 (or 0.7,
    // both acceptable roundings — assert the numeric behavior precisely).
    expect(suggestedDoseForLevel(procedure, 'suave')).toBeCloseTo(0.8, 5);
    expect(suggestedDoseForLevel(procedure, 'medio')).toBeCloseTo(1.3, 5);
    expect(suggestedDoseForLevel(procedure, 'alto')).toBeCloseTo(1.8, 5);
  });

  it('returns the midpoint rounded to a whole unit for a toxin (unidades) procedure', () => {
    const procedure = getProcedure('toxina_glabela')!;
    expect(suggestedDoseForLevel(procedure, 'suave')).toBe(13); // (10+15)/2 = 12.5 -> rounds to 13
    expect(suggestedDoseForLevel(procedure, 'medio')).toBe(18); // (15+20)/2 = 17.5 -> rounds to 18
    expect(suggestedDoseForLevel(procedure, 'alto')).toBe(23); // (20+25)/2 = 22.5 -> rounds to 23
  });

  it('never returns a value that is itself a percentage-like harmony score — always a plain dose number in the substance unit', () => {
    for (const procedure of PROCEDURE_CATALOG) {
      for (const level of INTENSITY_LEVELS) {
        const dose = suggestedDoseForLevel(procedure, level);
        expect(dose).toBeGreaterThan(0);
        expect(Number.isFinite(dose)).toBe(true);
      }
    }
  });
});

describe('planBQuantity / reduceToPlanB / hasReducedPlanB', () => {
  it('reduces a point above the "suave" range down to the suave suggested dose', () => {
    // preenchimento_labial suave: 0.5–1.0 -> suggested dose 0.8 (see suggestedDoseForLevel tests above)
    const p = point({ procedureId: 'preenchimento_labial', quantity: 2 });
    expect(planBQuantity(p)).toBeCloseTo(0.8, 5);
  });

  it('never increases the dose — a point already below the suave suggestion keeps its own (lower) quantity', () => {
    const p = point({ procedureId: 'preenchimento_labial', quantity: 0.3 });
    expect(planBQuantity(p)).toBe(0.3);
  });

  it('leaves a point without a linked named procedure unchanged (no reference range to reduce from)', () => {
    const p = point({ procedureId: undefined, quantity: 2 });
    expect(planBQuantity(p)).toBe(2);
  });

  it('leaves a point with an unknown procedureId unchanged, same as no procedureId', () => {
    const p = point({ procedureId: 'nao_existe', quantity: 2 });
    expect(planBQuantity(p)).toBe(2);
  });

  it('reduceToPlanB keeps every other field of the point untouched, only the quantity changes', () => {
    const p = point({ id: 'p9', procedureId: 'preenchimento_labial', quantity: 2, insumoId: 'ins-1' });
    const [reduced] = reduceToPlanB([p]);
    expect(reduced).toEqual({ ...p, quantity: 0.8 });
  });

  it('hasReducedPlanB is true when at least one point actually shrinks', () => {
    const points = [
      point({ id: 'p1', procedureId: 'preenchimento_labial', quantity: 2 }),
      point({ id: 'p2', procedureId: undefined, quantity: 1 }),
    ];
    expect(hasReducedPlanB(points)).toBe(true);
  });

  it('hasReducedPlanB is false when no point in the plan has a linked named procedure', () => {
    const points = [
      point({ id: 'p1', procedureId: undefined, quantity: 2 }),
      point({ id: 'p2', procedureId: undefined, quantity: 1 }),
    ];
    expect(hasReducedPlanB(points)).toBe(false);
  });

  it('hasReducedPlanB is false when every linked point is already at/below its suave suggestion', () => {
    const points = [point({ id: 'p1', procedureId: 'preenchimento_labial', quantity: 0.3 })];
    expect(hasReducedPlanB(points)).toBe(false);
  });
});
