import { describe, it, expect } from 'vitest';
import {
  PRIVACY_BODY_PT,
  PRIVACY_VERSION,
  TERMS_BODY_PT,
  TERMS_VERSION,
  stripAuthoringNotes,
} from './legalDocs';

// Estes testes não julgam a redação jurídica — julgam o que o squad w1-4 se
// comprometeu a entregar e o que quebra silenciosamente com o tempo: o
// formato da versão (é ele que vai para terms_acceptances), a presença dos
// temas obrigatórios para um produto que trata dado de saúde de terceiros, e
// a lista de subprocessadores, que precisa acompanhar as integrações reais
// do código.

describe('legalDocs — versionamento', () => {
  it('as versões estão no formato AAAA-MM-DD aceito pela edge function', () => {
    expect(TERMS_VERSION).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(PRIVACY_VERSION).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  it('o corpo de cada documento declara a mesma versão que a constante', () => {
    expect(TERMS_BODY_PT).toContain(TERMS_VERSION);
    expect(PRIVACY_BODY_PT).toContain(PRIVACY_VERSION);
  });

  it('stripAuthoringNotes remove o bloco de notas do topo e preserva o documento', () => {
    const cleanedTerms = stripAuthoringNotes(TERMS_BODY_PT);
    expect(cleanedTerms).not.toContain('PENDÊNCIAS QUE SÓ O DONO');
    expect(cleanedTerms.startsWith('# Termos de Uso do FacialPlan')).toBe(true);

    const cleanedPrivacy = stripAuthoringNotes(PRIVACY_BODY_PT);
    expect(cleanedPrivacy.startsWith('# Política de Privacidade do FacialPlan')).toBe(true);
  });
});

describe('legalDocs — conteúdo obrigatório', () => {
  it('os Termos definem o profissional como controlador e o FacialPlan como operador', () => {
    expect(TERMS_BODY_PT).toContain('CONTROLADOR');
    expect(TERMS_BODY_PT).toContain('OPERADOR');
  });

  it('a Política cobre os temas exigidos pela LGPD para este produto', () => {
    for (const tema of [
      'fotografia', // dado biométrico
      'saúde', // dado sensível
      'Transferência internacional',
      'Encarregado',
      'Direitos do titular',
      'Por quanto tempo guardamos',
    ]) {
      expect(PRIVACY_BODY_PT.toLowerCase()).toContain(tema.toLowerCase());
    }
  });

  it('a Política lista todos os subprocessadores que o código realmente usa', () => {
    // Se uma integração entrar ou sair de supabase/functions/, esta lista tem
    // que mudar junto — é justamente o que este teste força a lembrar.
    // Anthropic -> OpenAI: atualizado junto com a migração de provedor de IA
    // das edge functions (analyze-face/adversarial-risk-check/read-insumo-label).
    for (const provedor of ['Supabase', 'OpenAI', 'Google', 'Hotmart', 'Resend']) {
      expect(PRIVACY_BODY_PT).toContain(provedor);
    }
  });

  it('a Política não cita subprocessador de integração já removida do código', () => {
    // Evolution API (WhatsApp) foi removida do produto — a Política não pode
    // seguir declarando um compartilhamento de dado que não existe mais.
    expect(PRIVACY_BODY_PT).not.toContain('Evolution API');
  });

  it('os dados do controlador foram preenchidos com os dados reais fornecidos pelo dono do produto, nunca inventados', () => {
    // Preenchido em 2026-09-28 com os dados reais informados pelo dono do
    // produto (razão social, CNPJ, endereço, foro, e-mail do encarregado) —
    // ver o cabeçalho de cada arquivo .md para a data e o que ainda falta
    // (confirmação de DPA com subprocessadores, região de hospedagem).
    for (const dado of ['VENDRE DIGITAL', '51.755.399/0001-51']) {
      expect(TERMS_BODY_PT).toContain(dado);
      expect(PRIVACY_BODY_PT).toContain(dado);
    }
    expect(TERMS_BODY_PT).toContain('Volta Redonda');
    expect(PRIVACY_BODY_PT).toContain('privacidade@facialplan.com.br');

    // Nenhum dos 5 campos que dependiam de dado real do dono do produto pode
    // sobrar como placeholder — só os itens genuinamente ainda pendentes
    // (DPA/contrato de operador, região de hospedagem) continuam com
    // "PENDENTE" no corpo do documento.
    expect(TERMS_BODY_PT).not.toContain('[PENDENTE — CNPJ]');
    expect(TERMS_BODY_PT).not.toContain('[PENDENTE — razão social completa]');
    expect(PRIVACY_BODY_PT).not.toContain('[PENDENTE — e-mail do encarregado]');
  });
});
