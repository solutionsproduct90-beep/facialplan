import { renderToString } from 'react-dom/server';
import { StaticRouter } from 'react-router-dom/server';
import { Routes, Route } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import i18next from 'i18next';

import ptResources from './i18n/locales/pt.json';
import esResources from './i18n/locales/es.json';
import enResources from './i18n/locales/en.json';
import Recursos from './pages/site/Recursos';
import Precos from './pages/site/Precos';
import Sobre from './pages/site/Sobre';
import Blog from './pages/site/Blog';
import BlogPost from './pages/site/BlogPost';
import Termos from './pages/Termos';
import Privacidade from './pages/Privacidade';
import { getAllBlogPosts, getBlogPostBySlug, getLocalesForSlug, type BlogLocale } from './lib/blog';
import { PREFIXED_LOCALES, splitLocaleFromPath, localizedPath, type SiteLocale } from './lib/siteLocale';

// Instância de i18next SEPARADA da usada pelo app no navegador (src/i18n/
// index.ts): aquela usa `i18next-browser-languagedetector`, que lê
// `navigator`/`localStorage` — inexistentes aqui em Node. Pré-renderização
// gera cada rota no idioma que a própria URL declara (pt sem prefixo, /es
// com prefixo — ver src/lib/siteLocale.ts), nunca no idioma detectado do
// visitante: é o único jeito de um crawler saber com certeza em que
// língua aquela página existe.
const ssrI18n = i18next.createInstance();
await ssrI18n.init({
  lng: 'pt',
  fallbackLng: 'pt',
  resources: {
    pt: { translation: ptResources },
    es: { translation: esResources },
    en: { translation: enResources },
  },
  interpolation: { escapeValue: false },
});

export interface PrerenderAlternate {
  locale: SiteLocale;
  href: string;
}

/** Ingredientes pra JSON-LD — schema.org final (com URLs absolutas) é montado em scripts/prerender.mjs, que é quem conhece SITE_URL. */
export type PrerenderStructuredData =
  | { type: 'organization' }
  | { type: 'article'; title: string; description: string; datePublished: string; author: string; image?: string; tags: string[] };

export interface PrerenderResult {
  html: string;
  title: string;
  description: string;
  locale: SiteLocale;
  /** Versões deste mesmo conteúdo em outros idiomas — vira <link rel="alternate" hreflang>. */
  alternates: PrerenderAlternate[];
  structuredData?: PrerenderStructuredData;
}

type RouteMatch = {
  routePath: string;
  Component: React.ComponentType;
  meta: () => { title: string; description: string };
  alternateRestPaths: () => Array<{ locale: SiteLocale; rest: string }>;
  structuredData: () => PrerenderStructuredData | undefined;
};

function resolveRoute(rest: string, locale: SiteLocale): RouteMatch | null {
  if (rest === '/recursos') {
    return {
      routePath: '/recursos',
      Component: Recursos,
      meta: () => ({
        title: `${ssrI18n.t('site.features.heading')} — FacialPlan`,
        description: ssrI18n.t('site.features.subtitle'),
      }),
      // Páginas institucionais têm string traduzida pra todo locale com
      // rota registrada — sempre disponíveis em pt + todos os prefixados.
      alternateRestPaths: () => [{ locale: 'pt', rest: '/recursos' }, ...PREFIXED_LOCALES.map((l) => ({ locale: l as SiteLocale, rest: '/recursos' }))],
      structuredData: () => ({ type: 'organization' }),
    };
  }
  if (rest === '/precos') {
    return {
      routePath: '/precos',
      Component: Precos,
      meta: () => ({
        title: `${ssrI18n.t('site.pricing.heading')} — FacialPlan`,
        description: ssrI18n.t('site.pricing.subtitle'),
      }),
      alternateRestPaths: () => [{ locale: 'pt', rest: '/precos' }, ...PREFIXED_LOCALES.map((l) => ({ locale: l as SiteLocale, rest: '/precos' }))],
      structuredData: () => ({ type: 'organization' }),
    };
  }
  if (rest === '/sobre') {
    return {
      routePath: '/sobre',
      Component: Sobre,
      meta: () => ({
        title: ssrI18n.t('site.about.heading'),
        description: ssrI18n.t('site.about.missionBody'),
      }),
      alternateRestPaths: () => [{ locale: 'pt', rest: '/sobre' }, ...PREFIXED_LOCALES.map((l) => ({ locale: l as SiteLocale, rest: '/sobre' }))],
      structuredData: () => ({ type: 'organization' }),
    };
  }
  // Documentos legais. Entram na pré-renderização por dois motivos práticos:
  // (1) é a página que alguém abre num link do rodapé ou do checkbox de
  // cadastro pra decidir se confia no produto, e ela chegar já renderizada
  // muda a primeira impressão; (2) ferramenta de due diligence e crawler de
  // preview costumam ler só o HTML estático — uma política de privacidade que
  // só existe depois do JS rodar, na prática, não existe pra eles.
  //
  // Só em pt, sem alternates: o corpo é publicado apenas em português, que é
  // o idioma em que ele tem validade jurídica (ver TERMS_BODY_PT em
  // src/lib/legalDocs.ts). Por isso também não há rota /:lang/termos em
  // App.tsx — apontar hreflang pra uma URL que serviria o mesmo texto em
  // português seria mentir pro crawler.
  // `locale === 'pt'` é a trava que impede /es/termos e /en/privacidade de
  // renderizarem: `splitLocaleFromPath` devolve o mesmo `rest` pros três, e
  // sem esta checagem a pré-renderização geraria um arquivo com o documento
  // em português sob uma URL que se anuncia como espanhol.
  if (rest === '/termos' && locale === 'pt') {
    return {
      routePath: '/termos',
      Component: Termos,
      meta: () => ({
        title: `${ssrI18n.t('legal.terms.title')} — FacialPlan`,
        description: ssrI18n.t('legal.terms.description'),
      }),
      alternateRestPaths: () => [{ locale: 'pt', rest: '/termos' }],
      structuredData: () => undefined,
    };
  }
  if (rest === '/privacidade' && locale === 'pt') {
    return {
      routePath: '/privacidade',
      Component: Privacidade,
      meta: () => ({
        title: `${ssrI18n.t('legal.privacy.title')} — FacialPlan`,
        description: ssrI18n.t('legal.privacy.description'),
      }),
      alternateRestPaths: () => [{ locale: 'pt', rest: '/privacidade' }],
      structuredData: () => undefined,
    };
  }
  if (rest === '/blog') {
    return {
      routePath: '/blog',
      Component: Blog,
      meta: () => ({
        title: `${ssrI18n.t('site.blog.heading')} — FacialPlan`,
        description: ssrI18n.t('site.blog.subtitle'),
      }),
      alternateRestPaths: () => [{ locale: 'pt', rest: '/blog' }, ...PREFIXED_LOCALES.map((l) => ({ locale: l as SiteLocale, rest: '/blog' }))],
      structuredData: () => ({ type: 'organization' }),
    };
  }
  if (rest.startsWith('/blog/')) {
    const slug = rest.slice('/blog/'.length);
    return {
      routePath: '/blog/:slug',
      Component: BlogPost,
      meta: () => {
        const post = getBlogPostBySlug(slug, locale as BlogLocale);
        return post
          ? { title: `${post.title} — FacialPlan`, description: post.description }
          : { title: ssrI18n.t('site.blog.notFoundTitle'), description: ssrI18n.t('site.blog.notFoundBody') };
      },
      // Um post só existe nos locales em que foi de fato traduzido — nunca
      // aponta hreflang pra uma URL que ia renderizar "artigo não encontrado".
      alternateRestPaths: () => getLocalesForSlug(slug).map((l) => ({ locale: l as SiteLocale, rest: `/blog/${slug}` })),
      structuredData: () => {
        const post = getBlogPostBySlug(slug, locale as BlogLocale);
        if (!post) return undefined;
        return {
          type: 'article',
          title: post.title,
          description: post.description,
          datePublished: post.date,
          author: post.author,
          image: post.coverImage,
          tags: post.tags,
        };
      },
    };
  }
  return null;
}

export async function render(url: string): Promise<PrerenderResult> {
  const { locale, rest } = splitLocaleFromPath(url);
  const route = resolveRoute(rest, locale);
  if (!route) {
    throw new Error(`entry-server: sem rota estática registrada para "${url}"`);
  }

  if (ssrI18n.language !== locale) {
    await ssrI18n.changeLanguage(locale);
  }

  const { routePath, Component, meta, alternateRestPaths, structuredData } = route;
  const fullRoutePath = locale === 'pt' ? routePath : `/:lang${routePath}`;

  // Precisa de <Routes>/<Route> mesmo pra uma única rota: é dali que
  // `useParams()` (usado por BlogPost.tsx/useSiteLocale pra ler
  // `:lang`/`:slug`) extrai os parâmetros — `StaticRouter` sozinho só
  // define a location, não faz nenhum casamento de rota.
  const html = renderToString(
    <I18nextProvider i18n={ssrI18n}>
      <StaticRouter location={url}>
        <Routes>
          <Route path={fullRoutePath} element={<Component />} />
        </Routes>
      </StaticRouter>
    </I18nextProvider>
  );

  const alternates: PrerenderAlternate[] = alternateRestPaths()
    .filter((alt) => alt.locale !== locale)
    .map((alt) => ({ locale: alt.locale, href: localizedPath(alt.rest, alt.locale) }));

  return { html, locale, alternates, structuredData: structuredData(), ...meta() };
}

// Rotas estáticas geradas em build (ver scripts/prerender.mjs). "/" fica de
// fora de propósito: seu conteúdo depende de sessão (RootRoute.tsx mostra
// landing pra visitante ou dashboard pra quem já está logado) — pré-
// renderizar a landing ali geraria um flash de conteúdo institucional pra
// usuário autenticado antes do React assumir. As páginas abaixo não têm
// nenhuma variação por sessão, então pré-renderizar é seguro.
export function listStaticRoutes(): string[] {
  const routes: string[] = [];

  const institutional = ['/recursos', '/precos', '/sobre', '/blog'];

  // pt — língua-fonte, sem prefixo, sempre com todos os posts.
  routes.push(...institutional);
  // Documentos legais: só pt, e fora de `institutional` de propósito — não
  // existe variante /es ou /en deles (ver resolveRoute).
  routes.push('/termos', '/privacidade');
  routes.push(...getAllBlogPosts('pt').map((post) => `/blog/${post.slug}`));

  // Locales com prefixo (es, en). Institucionais sempre (string já
  // traduzida); posts só os que já têm arquivo <locale>/ traduzido — hoje
  // só es tem posts, en fica só com as institucionais até ter conteúdo.
  for (const locale of PREFIXED_LOCALES) {
    routes.push(...institutional.map((path) => `/${locale}${path}`));
    routes.push(...getAllBlogPosts(locale as BlogLocale).map((post) => `/${locale}/blog/${post.slug}`));
  }

  return routes;
}
