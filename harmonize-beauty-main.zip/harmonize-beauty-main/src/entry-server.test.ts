import { describe, it, expect } from 'vitest';
import { render, listStaticRoutes } from './entry-server';
import { getAllBlogPosts, getLocalesForSlug } from './lib/blog';

// Guarda de regressão do bug encontrado ao ligar a pré-renderização
// (scripts/prerender.mjs): `StaticRouter` sozinho não faz casamento de
// rota — sem envolver o componente num `<Routes><Route path="/blog/:slug">`,
// `useParams()` dentro de BlogPost.tsx nunca recebia o slug, e todo artigo
// pré-renderizava como "não encontrado" mesmo existindo.
describe('entry-server (pré-renderização estática)', () => {
  it('lista as rotas institucionais e um item por post do blog em pt, sem incluir "/"', () => {
    const routes = listStaticRoutes();
    expect(routes).toContain('/recursos');
    expect(routes).toContain('/precos');
    expect(routes).toContain('/sobre');
    expect(routes).toContain('/blog');
    expect(routes).not.toContain('/');

    for (const post of getAllBlogPosts('pt')) {
      expect(routes).toContain(`/blog/${post.slug}`);
    }
  });

  it('inclui os documentos legais em pt e NÃO cria variante por idioma deles', () => {
    // Termos/Política são publicados só em português (é o idioma em que têm
    // validade jurídica — ver src/lib/legalDocs.ts), então não existe rota
    // /es/termos nem /en/privacidade para pré-renderizar.
    const routes = listStaticRoutes();
    expect(routes).toContain('/termos');
    expect(routes).toContain('/privacidade');
    expect(routes.filter((r) => r.endsWith('/termos') || r.endsWith('/privacidade'))).toEqual([
      '/termos',
      '/privacidade',
    ]);
  });

  it('pré-renderiza os documentos legais com o conteúdo real e sem hreflang', async () => {
    const termos = await render('/termos');
    expect(termos.locale).toBe('pt');
    expect(termos.title).toContain('Termos de Uso');
    expect(termos.description.length).toBeGreaterThan(0);
    expect(termos.html).toContain('CONTROLADOR');
    expect(termos.alternates).toEqual([]);

    const privacidade = await render('/privacidade');
    // Subprocessador de IA listado na política (era Anthropic até a migração
    // pra OpenAI — ver o commit que atualizou a política, #7).
    expect(privacidade.html).toContain('OpenAI');
    expect(privacidade.alternates).toEqual([]);
  });

  it('não existe rota estática com prefixo de idioma para os documentos legais', async () => {
    await expect(render('/es/termos')).rejects.toThrow();
    await expect(render('/en/privacidade')).rejects.toThrow();
  });

  it('inclui as variantes /es das páginas institucionais e dos posts já traduzidos', () => {
    const routes = listStaticRoutes();
    expect(routes).toContain('/es/recursos');
    expect(routes).toContain('/es/precos');
    expect(routes).toContain('/es/sobre');
    expect(routes).toContain('/es/blog');

    for (const post of getAllBlogPosts('es')) {
      expect(routes).toContain(`/es/blog/${post.slug}`);
    }
  });

  it('inclui as institucionais em /en, sem nenhum post (ainda sem tradução pro inglês)', () => {
    const routes = listStaticRoutes();
    expect(routes).toContain('/en/recursos');
    expect(routes).toContain('/en/precos');
    expect(routes).toContain('/en/sobre');
    expect(routes).toContain('/en/blog');
    expect(getAllBlogPosts('en')).toEqual([]);
    expect(routes.filter((r) => r.startsWith('/en/blog/'))).toEqual([]);
  });

  it('renderiza o conteúdo real do artigo em pt (não a tela de "não encontrado") pra um slug existente', async () => {
    const [post] = getAllBlogPosts('pt');
    const result = await render(`/blog/${post.slug}`);

    expect(result.locale).toBe('pt');
    expect(result.title).toBe(`${post.title} — FacialPlan`);
    expect(result.description).toBe(post.description);
    expect(result.html).not.toContain('Artigo não encontrado');
    expect(result.html).toContain(post.title);
  });

  it('renderiza o conteúdo real do artigo em /es pra um slug já traduzido', async () => {
    const [post] = getAllBlogPosts('es');
    const result = await render(`/es/blog/${post.slug}`);

    expect(result.locale).toBe('es');
    expect(result.title).toBe(`${post.title} — FacialPlan`);
    expect(result.html).toContain(post.title);
  });

  it('renderiza a tela de "não encontrado" pra um slug inexistente, sem lançar', async () => {
    const result = await render('/blog/este-slug-nao-existe');
    expect(result.html).toContain('Artigo não encontrado');
  });

  it('renderiza as páginas institucionais (pt, /es e /en) com título e descrição não vazios', async () => {
    for (const route of [
      '/recursos', '/precos', '/sobre', '/blog',
      '/es/recursos', '/es/precos', '/es/sobre', '/es/blog',
      '/en/recursos', '/en/precos', '/en/sobre', '/en/blog',
    ]) {
      const result = await render(route);
      expect(result.title.length).toBeGreaterThan(0);
      expect(result.description.length).toBeGreaterThan(0);
      expect(result.html.length).toBeGreaterThan(0);
    }
  });

  it('gera hreflang recíproco entre pt e es pras páginas institucionais', async () => {
    const pt = await render('/precos');
    expect(pt.alternates).toContainEqual({ locale: 'es', href: '/es/precos' });

    const es = await render('/es/precos');
    expect(es.alternates).toContainEqual({ locale: 'pt', href: '/precos' });
  });

  it('só gera hreflang de post do blog pros locales onde ele realmente existe', async () => {
    const [ptOnlyPost] = getAllBlogPosts('pt').filter((post) => getLocalesForSlug(post.slug).length === 1);
    if (ptOnlyPost) {
      const result = await render(`/blog/${ptOnlyPost.slug}`);
      expect(result.alternates).toEqual([]);
    }
  });

  it('lança um erro claro pra uma rota sem casamento estático (nunca gera um arquivo vazio silenciosamente)', async () => {
    await expect(render('/rota-que-nao-existe')).rejects.toThrow();
  });

  it('lança pra um prefixo de idioma que não existe', async () => {
    await expect(render('/fr/recursos')).rejects.toThrow();
  });
});
