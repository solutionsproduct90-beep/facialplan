import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import NovoPaciente from "./NovoPaciente";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const insertSpy = vi.fn();
const navigateMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("sonner", () => ({
  toast: {
    success: () => {},
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

type ReferralCandidate = { id: string; name: string; referral_code: string };

/**
 * Suporta as duas formas que `patients` é consultada em NovoPaciente.tsx:
 * `.insert(payload).select().single()` (handleSave) e um `.select(...)`
 * encadeável (busca do "Indicado por" e resolução de código colado) que
 * resolve para `searchResults` normalmente, ou `codeMatch` quando
 * `.maybeSingle()` é chamado na cadeia.
 */
function createPatientsInsertBuilder(
  options: { searchResults?: ReferralCandidate[]; codeMatch?: ReferralCandidate | null } = {}
) {
  const { searchResults = [], codeMatch = null } = options;
  return {
    insert: (payload: unknown) => {
      insertSpy(payload);
      return {
        select: () => ({
          single: () => Promise.resolve({ data: { id: "new-pat-1" }, error: null }),
        }),
      };
    },
    select: () => {
      let isMaybeSingle = false;
      const chain: any = {
        eq: () => chain,
        or: () => chain,
        order: () => chain,
        limit: () => chain,
        maybeSingle: () => {
          isMaybeSingle = true;
          return chain;
        },
        then: (onFulfilled: (v: unknown) => unknown) =>
          Promise.resolve(isMaybeSingle ? { data: codeMatch } : { data: searchResults }).then(onFulfilled),
      };
      return chain;
    },
  };
}

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
  },
}));

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/pacientes/novo"]}>
      <Routes>
        <Route path="/pacientes/novo" element={<NovoPaciente />} />
      </Routes>
    </MemoryRouter>
  );

describe("NovoPaciente — telefone com DDI e e-mail opcional", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    insertSpy.mockReset();
    navigateMock.mockReset();
    toastErrorMock.mockReset();
    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createPatientsInsertBuilder();
      throw new Error(`unexpected table in test: ${table}`);
    });
    // Sandbox/CI não tem acesso ao endpoint /api/geo (nem à rede real) — o
    // componente já trata isso como "sem geolocalização" via catch, mas
    // simulamos explicitamente pra não depender de timeouts de rede reais.
    vi.spyOn(global, "fetch").mockRejectedValue(new Error("network disabled in test"));
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("defaults the DDI selector to Brazil (+55) when geolocation is unavailable", async () => {
    renderPage();
    expect(await screen.findByText("+55 Brasil")).toBeInTheDocument();
  });

  it("saves the phone combining the selected DDI with the local number", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.change(screen.getByPlaceholderText("21658924242"), { target: { value: "21 65892-4242" } });

    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as { phone: string | null; email: string | null };
    expect(payload.phone).toBe("+5521658924242");
    expect(payload.email).toBeNull();
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/pacientes/new-pat-1"));
  });

  it("lets the professional switch the DDI away from the default", async () => {
    renderPage();

    // Abre o BottomSheet de DDI e escolhe "Estados Unidos" — o gatilho deve
    // refletir a nova escolha assim que o sheet fecha.
    const dialTrigger = await screen.findByRole("button", { name: "+55 Brasil" });
    fireEvent.click(dialTrigger);
    fireEvent.click(await screen.findByText("+1 Estados Unidos"));

    await waitFor(() =>
      expect(screen.getByRole("button", { name: "+1 Estados Unidos" })).toBeInTheDocument()
    );
  });

  it("saves a trimmed, valid email alongside the patient", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.change(screen.getByPlaceholderText("paciente@exemplo.com"), {
      target: { value: "  maria@exemplo.com  " },
    });

    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as { email: string | null };
    expect(payload.email).toBe("maria@exemplo.com");
  });

  it("blocks saving with an invalid email and never calls insert", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.change(screen.getByPlaceholderText("paciente@exemplo.com"), {
      target: { value: "email-invalido" },
    });

    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("E-mail inválido"));
    expect(insertSpy).not.toHaveBeenCalled();
  });

  it("leaves phone null when neither DDI number nor email are filled in", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Sem Contato" } });
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as { phone: string | null; email: string | null };
    expect(payload.phone).toBeNull();
    expect(payload.email).toBeNull();
  });

  it("leaves referred_by_patient_id null when 'Indicado por' is left empty", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as { referred_by_patient_id: string | null };
    expect(payload.referred_by_patient_id).toBeNull();
  });

  it("selects a patient from the referred-by search dropdown and saves its id", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "patients")
        return createPatientsInsertBuilder({
          searchResults: [{ id: "existing-1", name: "João Souza", referral_code: "ABCD1234" }],
        });
      throw new Error(`unexpected table in test: ${table}`);
    });

    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.change(screen.getByPlaceholderText("Buscar paciente ou colar código de indicação"), {
      target: { value: "João" },
    });

    fireEvent.click(await screen.findByText("João Souza"));
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as { referred_by_patient_id: string | null };
    expect(payload.referred_by_patient_id).toBe("existing-1");
  });

  it("resolves a pasted referral code (without picking from the dropdown) to the matching patient", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "patients")
        return createPatientsInsertBuilder({
          codeMatch: { id: "existing-2", name: "Ana Costa", referral_code: "ZZ99YY88" },
        });
      throw new Error(`unexpected table in test: ${table}`);
    });

    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Novo Paciente" } });
    fireEvent.change(screen.getByPlaceholderText("Buscar paciente ou colar código de indicação"), {
      target: { value: "zz99yy88" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as { referred_by_patient_id: string | null };
    expect(payload.referred_by_patient_id).toBe("existing-2");
  });

  it("saves ai_improvement_consent as false with no timestamp when the opt-in checkbox is left unchecked (default, safe for all existing/new patients)", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as {
      ai_improvement_consent: boolean;
      ai_improvement_consent_at: string | null;
    };
    expect(payload.ai_improvement_consent).toBe(false);
    expect(payload.ai_improvement_consent_at).toBeNull();
  });

  it("saves ai_improvement_consent as true with a fresh timestamp when the opt-in checkbox is checked — separate from marketing_consent", async () => {
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Maria Silva" } });
    fireEvent.click(screen.getByRole("checkbox", { name: /melhorar as sugestões de IA/i }));
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    const payload = insertSpy.mock.calls[0][0] as {
      ai_improvement_consent: boolean;
      ai_improvement_consent_at: string | null;
      marketing_consent: boolean;
    };
    expect(payload.ai_improvement_consent).toBe(true);
    expect(typeof payload.ai_improvement_consent_at).toBe("string");
    expect(payload.marketing_consent).toBe(false);
  });

  it("blocks saving and warns when the pasted referral code matches no patient", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createPatientsInsertBuilder({ codeMatch: null });
      throw new Error(`unexpected table in test: ${table}`);
    });

    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Nome do paciente"), { target: { value: "Novo Paciente" } });
    fireEvent.change(screen.getByPlaceholderText("Buscar paciente ou colar código de indicação"), {
      target: { value: "CODIGOINVALIDO" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Salvar paciente" }));

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("Código de indicação não encontrado"));
    expect(insertSpy).not.toHaveBeenCalled();
  });
});
