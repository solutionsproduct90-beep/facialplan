import React from 'react';
import { useTranslation } from 'react-i18next';
import PageTransition from '@/components/harmonize/PageTransition';
import AppLayout from '@/components/harmonize/AppLayout';
import AgendaTab from '@/components/harmonize/panel/AgendaTab';

/**
 * Tela própria de Agenda (`/agenda`) — entrada direta pela nav principal pro
 * mini sistema de agendamento que já existia como aba dentro de `/painel`
 * (ver src/components/harmonize/panel/AgendaTab.tsx e o comentário na
 * migration 20260910190000_add_appointments.sql sobre o escopo da V1: lista
 * cronológica agrupada por dia, sem grade de calendário mensal nem
 * sincronização externa).
 *
 * Reaproveita o MESMO componente `<AgendaTab />` usado na aba do Painel —
 * mesma tabela `appointments`, mesma lógica de agrupamento/CRUD, mesmos
 * testes (AgendaTab.test.tsx, lib/agenda.test.ts) — em vez de duplicar
 * markup/consultas Supabase. A aba dentro de `/painel` continua existindo
 * (não foi removida): esta tela só dá um atalho direto de agenda pela nav
 * principal, sem precisar entrar em Painel e trocar de aba.
 *
 * Lembrete automático 24h antes do compromisso (push/e-mail): FORA de
 * escopo aqui — precisa de uma function agendada (pg_cron/edge function) que
 * rode periodicamente e dispare a notificação, o que é trabalho de uma
 * squad própria de notificações, não desta tela. Próximo passo natural,
 * registrado aqui e na migration da tabela.
 */
const Agenda: React.FC = () => {
  const { t } = useTranslation();

  return (
    <PageTransition>
      <AppLayout title={t('agenda.title')}>
        <AgendaTab />
      </AppLayout>
    </PageTransition>
  );
};

export default Agenda;
