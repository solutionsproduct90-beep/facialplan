import React, { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import AnamnesisRiskFields from '@/components/harmonize/AnamnesisRiskFields';
import AnamnesisSkinFields, { type AnamnesisSkinValues } from '@/components/harmonize/AnamnesisSkinFields';
import { ALL_QUESTION_KEYS, EMPTY_RISK_FLAGS, type RiskFlags } from '@/types/anamnesis';
import { Camera, Sun, User, Scissors, Meh } from 'lucide-react';

// Página pública (fora do ProtectedRoute — ver rota /anamnese/:token em
// App.tsx). O paciente nunca é um usuário autenticado do Supabase: a
// "sessão" dele é só o token na URL, validado pela edge function pública
// `public-anamnesis` (supabase/functions/public-anamnesis/index.ts), que
// usa a service role key — por isso toda leitura/gravação aqui passa por
// fetch simples para essa função, nunca pelo client `supabase` autenticado.
const FUNCTIONS_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/public-anamnesis`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;
const MAX_PHOTO_BYTES = 10 * 1024 * 1024;

type TokenState = 'loading' | 'valid' | 'not_found' | 'expired' | 'used' | 'error';

type SubmitState = 'idle' | 'submitting' | 'success' | 'error';

async function fetchFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

const PublicShell: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="min-h-screen bg-h-bg flex items-start justify-center pt-10 pb-16">
    <div className="w-full max-w-[430px] px-6">
      <div className="flex items-center justify-center gap-2.5 mb-8">
        <LogoMark size={32} />
        <span style={{ fontSize: 18, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>FacialPlan</span>
      </div>
      {children}
    </div>
  </div>
);

const StatusScreen: React.FC<{ title: string; body: string }> = ({ title, body }) => (
  <PublicShell>
    <div className="bg-h-white rounded-r shadow-h-sm p-6 text-center flex flex-col items-center gap-2">
      <h1 style={{ fontSize: 19, fontWeight: 800, color: '#1A1918' }}>{title}</h1>
      <p className="text-[14px] text-h-text-2 leading-relaxed">{body}</p>
    </div>
  </PublicShell>
);

const AnamneseCompartilhada: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const { t } = useTranslation();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [tokenState, setTokenState] = useState<TokenState>('loading');
  const [patientFirstName, setPatientFirstName] = useState<string | null>(null);
  const [disabledQuestions, setDisabledQuestions] = useState<string[]>([]);
  const [submitState, setSubmitState] = useState<SubmitState>('idle');
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [consentChecked, setConsentChecked] = useState(false);

  const [mainComplaint, setMainComplaint] = useState('');
  const [riskFlags, setRiskFlags] = useState<RiskFlags>(EMPTY_RISK_FLAGS);
  const [skin, setSkin] = useState<AnamnesisSkinValues>({
    skinType: '',
    skinTexture: '',
    oiliness: '',
    discromia: [],
    vascularization: [],
  });
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      setTokenState('not_found');
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${FUNCTIONS_URL}?token=${encodeURIComponent(token)}`, {
          headers: { apikey: ANON_KEY, Authorization: `Bearer ${ANON_KEY}` },
        });
        const data = await res.json();
        if (cancelled) return;
        if (data?.valid) {
          setPatientFirstName(data.patientFirstName ?? null);
          setDisabledQuestions(Array.isArray(data.disabledQuestions) ? data.disabledQuestions : []);
          setTokenState('valid');
        } else {
          setTokenState((data?.reason as TokenState) ?? 'not_found');
        }
      } catch {
        if (!cancelled) setTokenState('error');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_PHOTO_BYTES) {
      toast.error(t('anamnesis.public.errorPhotoTooLarge'));
      return;
    }
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const enabledKeys = React.useMemo(
    () => new Set(ALL_QUESTION_KEYS.filter((key) => !disabledQuestions.includes(key))),
    [disabledQuestions],
  );

  const handleSubmit = async () => {
    if (!token || !consentChecked) return;
    setSubmitState('submitting');
    setSubmitError(null);
    try {
      const photoBase64 = photoFile ? await fetchFileAsBase64(photoFile) : undefined;
      const res = await fetch(FUNCTIONS_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: ANON_KEY,
          Authorization: `Bearer ${ANON_KEY}`,
        },
        body: JSON.stringify({
          token,
          mainComplaint,
          skinType: skin.skinType || undefined,
          skinTexture: skin.skinTexture || undefined,
          oiliness: skin.oiliness || undefined,
          discromia: skin.discromia,
          vascularization: skin.vascularization,
          riskFlags,
          photoBase64,
          photoMimeType: photoFile?.type,
          consentDataProcessing: consentChecked,
        }),
      });

      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.success) {
        throw new Error('submit_failed');
      }
      setSubmitState('success');
    } catch {
      setSubmitState('error');
      setSubmitError(t('anamnesis.public.errorGeneric'));
    }
  };

  if (tokenState === 'loading') {
    return (
      <PublicShell>
        <p className="text-center text-[14px] text-h-text-3">{t('anamnesis.public.validating')}</p>
      </PublicShell>
    );
  }

  if (tokenState === 'not_found' || tokenState === 'error') {
    return <StatusScreen title={t('anamnesis.public.invalidTitle')} body={t('anamnesis.public.invalidBody')} />;
  }
  if (tokenState === 'expired') {
    return <StatusScreen title={t('anamnesis.public.expiredTitle')} body={t('anamnesis.public.expiredBody')} />;
  }
  if (tokenState === 'used') {
    return <StatusScreen title={t('anamnesis.public.usedTitle')} body={t('anamnesis.public.usedBody')} />;
  }

  if (submitState === 'success') {
    return <StatusScreen title={t('anamnesis.public.successTitle')} body={t('anamnesis.public.successBody')} />;
  }

  return (
    <PublicShell>
      <div className="flex flex-col gap-5">
        <div className="text-center">
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
            {patientFirstName ? t('anamnesis.public.greeting', { name: patientFirstName }) : t('anamnesis.form.title')}
          </h1>
          <p className="text-[13px] text-h-text-2 mt-1">{t('anamnesis.public.intro')}</p>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[13px] font-semibold text-h-text-2">{t('anamnesis.form.mainComplaintLabel')}</label>
          <textarea
            value={mainComplaint}
            onChange={(e) => setMainComplaint(e.target.value)}
            placeholder={t('anamnesis.form.mainComplaintPlaceholder')}
            rows={3}
            className="w-full rounded-[12px] p-3 text-[14px] bg-h-white border border-black/10 outline-none"
          />
        </div>

        <div>
          <p className="text-[14px] font-bold text-h-text mb-2">{t('anamnesis.form.riskSectionTitle')}</p>
          <AnamnesisRiskFields value={riskFlags} onChange={setRiskFlags} enabledKeys={enabledKeys} />
        </div>

        <div>
          <p className="text-[14px] font-bold text-h-text mb-2">{t('anamnesis.form.skinSectionTitle')}</p>
          <AnamnesisSkinFields {...skin} onChange={(patch) => setSkin((prev) => ({ ...prev, ...patch }))} />
        </div>

        {/* Foto */}
        <div>
          <p className="text-[14px] font-bold text-h-text mb-2">{t('anamnesis.public.photoSectionTitle')}</p>
          <div className="bg-h-white rounded-r-sm shadow-h-sm p-4 mb-3">
            <p className="text-[12px] font-semibold text-h-text-2 mb-2">{t('anamnesis.public.photoInstructionsTitle')}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: <User size={16} />, label: t('anamnesis.public.photoInstructions.front') },
                { icon: <Meh size={16} />, label: t('anamnesis.public.photoInstructions.noMakeup') },
                { icon: <Sun size={16} />, label: t('anamnesis.public.photoInstructions.lighting') },
                { icon: <Scissors size={16} />, label: t('anamnesis.public.photoInstructions.hair') },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-h-g-mid flex-shrink-0">{item.icon}</span>
                  <span className="text-[11px] text-h-text-2 leading-snug">{item.label}</span>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-h-text-3 italic mt-3">{t('anamnesis.public.photoExample')}</p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={handleFileChange}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full aspect-[3/4] rounded-r border-2 border-dashed border-h-surface-3 flex flex-col items-center justify-center gap-2 overflow-hidden transition-all active:scale-[0.99]"
            style={photoPreview ? { border: 'none' } : {}}
          >
            {photoPreview ? (
              <img src={photoPreview} alt={t('anamnesis.public.photoSectionTitle')} className="w-full h-full object-cover rounded-r" />
            ) : (
              <>
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(168,85,181,0.08)' }}>
                  <Camera size={22} className="text-h-g-mid" />
                </div>
                <p className="text-[13px] font-bold text-h-text">{t('anamnesis.public.uploadPhoto')}</p>
                <p className="text-[11px] text-h-text-3">{t('anamnesis.public.uploadPhotoHint')}</p>
              </>
            )}
          </button>
          <p className="text-[11px] text-h-text-3 mt-1.5">{t('anamnesis.public.photoOptional')}</p>
        </div>

        {/* Consentimento geral de uso de dados/fotos — obrigatório para
            enviar. Linguagem neutra de proteção de dados (sem citar LGPD ou
            qualquer lei específica de um único país — o app roda em 5
            mercados). Consentimento específico de procedimento é um item
            futuro separado, fora de escopo aqui. */}
        <label className="flex items-start gap-3 cursor-pointer bg-h-white rounded-r-sm shadow-h-sm p-3">
          <input
            type="checkbox"
            checked={consentChecked}
            onChange={(e) => setConsentChecked(e.target.checked)}
            style={{ marginTop: 2, width: 20, height: 20, flexShrink: 0 }}
          />
          <span className="text-[12px] text-h-text-2 leading-snug">{t('anamnesis.public.consentLabel')}</span>
        </label>

        {submitState === 'error' && submitError && (
          <p className="text-[13px] text-center" style={{ color: '#E05050' }}>{submitError}</p>
        )}

        <GradientButton onClick={handleSubmit} disabled={submitState === 'submitting' || !consentChecked}>
          {submitState === 'submitting' ? t('anamnesis.public.submitting') : t('anamnesis.public.submit')}
        </GradientButton>
      </div>
    </PublicShell>
  );
};

export default AnamneseCompartilhada;
