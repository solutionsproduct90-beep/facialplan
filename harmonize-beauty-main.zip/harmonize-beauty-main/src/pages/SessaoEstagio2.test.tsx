import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, within, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import SessaoEstagio2 from "./SessaoEstagio2";
import { createQueryBuilder } from "@/test/supabaseMock";
import { __resetFaceLandmarkerForTests } from "@/lib/faceLandmarker";
import type { ApplicationPoint } from "@/types/harmonize";
import { getProcedure, suggestedDoseForLevel } from "@/lib/procedureCatalog";
import i18n from "@/i18n";
import { FilesetResolver, FaceLandmarker } from "@mediapipe/tasks-vision";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const sessionsUpdateSpy = vi.fn();
// Usado só pelos testes de Protocolos Nomeados abaixo (generate-simulation) —
// as demais describes deste arquivo nunca chamam supabase.functions.invoke.
const functionsInvokeSpy = vi.fn();
// Overridable per-test (see "aviso de detecção facial malsucedida" below) —
// default keeps every other test's photo unset (no original_image_url means
// this is never even called), same as before.
const createSignedUrlMock = vi.fn(async () => ({ data: { signedUrl: null as string | null } }));

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

// O <Toaster/> do sonner não é montado nestes testes, então o texto do toast
// não chega ao DOM. Mockar é a única forma de afirmar QUAL mensagem o
// profissional vê — e isso importa: o fluxo de Protocolo Nomeado engolia a
// recusa do servidor (consentimento/assinatura) num texto genérico.
const toastErrorMock = vi.fn();
vi.mock("sonner", () => ({
  toast: {
    error: (...args: unknown[]) => toastErrorMock(...args),
    success: vi.fn(),
    info: vi.fn(),
    warning: vi.fn(),
  },
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

// Copiloto de Justificativa Clínica (backlog P6, ver ManualPointJustificationCopilot
// em SessaoEstagio2.tsx): chama supabase.rpc('get_manual_point_justification_stats', ...)
// sempre que o form de novo/edição de ponto manual monta. Nenhum teste deste
// arquivo cobre o copiloto em si (ver src/lib/manualPointJustification.test.ts
// para a lógica pura) — aqui só precisa não quebrar os testes existentes do
// resto da tela, então resolve sempre com "sem amostra suficiente" (nenhuma
// linha), o mesmo estado normal de uma base nova.
const rpcMock = vi.fn(async (..._args: unknown[]) => ({ data: [] as unknown[], error: null as { message: string } | null }));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: { from: () => ({ createSignedUrl: () => createSignedUrlMock() }) },
    functions: { invoke: (...args: unknown[]) => functionsInvokeSpy(...args) },
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

// The page dynamically imports @mediapipe/tasks-vision only after the patient
// photo's onLoad fires. Most tests here don't load a real photo (no
// original_image_url), so the landmarker is never invoked and this mock is
// mostly a safety net against an accidental real import; the "aviso de
// detecção facial malsucedida" describe block below overrides these to
// exercise the actual detection-failure path.
vi.mock("@mediapipe/tasks-vision", () => ({
  FilesetResolver: { forVisionTasks: vi.fn() },
  // Os conjuntos de conexões (FACE_LANDMARKS_*) são consumidos por
  // loadFaceMeshConnections (src/lib/faceLandmarker.ts) para desenhar a
  // malha de fundo da Etapa 2 — vazios aqui (nenhum teste deste arquivo
  // precisa da malha DESENHADA de verdade, só que ela não quebre a tela),
  // mas presentes como arrays reais para casar com o formato real da lib.
  FaceLandmarker: {
    createFromOptions: vi.fn(),
    FACE_LANDMARKS_FACE_OVAL: [],
    FACE_LANDMARKS_LIPS: [],
    FACE_LANDMARKS_LEFT_EYE: [],
    FACE_LANDMARKS_RIGHT_EYE: [],
    FACE_LANDMARKS_LEFT_EYEBROW: [],
    FACE_LANDMARKS_RIGHT_EYEBROW: [],
  },
}));

// jsdom doesn't implement the Pointer Events capture API; the drag handler
// calls `.setPointerCapture()` unconditionally on pointer-down.
if (!HTMLElement.prototype.setPointerCapture) {
  HTMLElement.prototype.setPointerCapture = () => {};
}

// jsdom also has no PointerEvent constructor, so @testing-library/dom's
// fireEvent.pointer*() falls back to a plain `Event` that carries none of
// the clientX/clientY coordinates the drag handler reads. A tiny
// MouseEvent-based polyfill (jsdom's MouseEvent does support clientX/Y) is
// enough to make coordinates flow through for these tests.
if (typeof (globalThis as { PointerEvent?: unknown }).PointerEvent === "undefined") {
  class PointerEventPolyfill extends MouseEvent {
    pointerId: number;
    constructor(type: string, params: MouseEventInit & { pointerId?: number } = {}) {
      super(type, params);
      this.pointerId = params.pointerId ?? 0;
    }
  }
  (globalThis as { PointerEvent?: unknown }).PointerEvent = PointerEventPolyfill;
}

const INITIAL_POINTS: ApplicationPoint[] = [
  {
    id: "labio_superior_ha",
    region: "labio_superior",
    label: "Lábio Superior",
    substance: "acido_hialuronico",
    quantity: 0.5,
    unit: "ml",
    x: 0.5,
    y: 0.62,
    confidence: 82,
    source: "ai",
  },
];

function createSessionsBuilder(
  initialPoints: ApplicationPoint[],
  otherSessionsCount = 0,
  originalImageUrl: string | null = null,
  // Sessões CONCLUÍDAS anteriores desta paciente (ver query de
  // lastToxinDatesByRegion em SessaoEstagio2.tsx) — cada entrada é o shape
  // cru retornado pelo Supabase para essa query específica.
  pastCompletedSessions: { created_at: string; stage2_overlay: ApplicationPoint[] }[] = [],
) {
  const selectResolution = {
    data: { patient_id: "pat-1", original_image_url: originalImageUrl, stage2_overlay: initialPoints },
  };
  // The load effect issues three different `.from('sessions').select(...)`
  // queries: the main row fetch, a `{ count: 'exact', head: true }`
  // count-only query (used for the "is this the patient's first session?"
  // dose-alert emphasis), and a `created_at, stage2_overlay` history fetch
  // (used for the min-interval-between-applications alert). All three share
  // this one builder, so `.select()` remembers which shape was requested to
  // resolve the right one.
  let queryKind: "row" | "count" | "history" = "row";
  const builder = {
    select: (fields?: string, opts?: { head?: boolean }) => {
      if (opts?.head === true) queryKind = "count";
      else if (fields?.includes("created_at")) queryKind = "history";
      else queryKind = "row";
      return builder;
    },
    eq: () => builder,
    neq: () => builder,
    single: () => builder,
    update: (payload: unknown) => {
      sessionsUpdateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
    then: (onFulfilled: (v: unknown) => unknown) => {
      const resolution =
        queryKind === "count"
          ? { count: otherSessionsCount, data: null }
          : queryKind === "history"
          ? { data: pastCompletedSessions }
          : selectResolution;
      return Promise.resolve(resolution).then(onFulfilled);
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/sessoes/s1/estagio-2"]}>
      <Routes>
        <Route path="/sessoes/:id/estagio-2" element={<SessaoEstagio2 />} />
      </Routes>
    </MemoryRouter>
  );

describe("SessaoEstagio2 — CRUD de pontos de aplicação", () => {
  beforeEach(async () => {
    // Trava o idioma da UI em português (padrão/fallback do app) pra que as
    // asserções em texto renderizado sejam determinísticas.
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(INITIAL_POINTS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () => waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

  it("loads the persisted stage2_overlay points into the list", async () => {
    renderPage();
    await waitForLoaded();

    expect(screen.getByText("Lábio Superior")).toBeInTheDocument();
    expect(screen.getByText(/Ácido Hialurônico · 0.5 ml · IA 82%/)).toBeInTheDocument();
  });

  it("adding a point persists it with the region/substance/quantity chosen in the sheet", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));

    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    const substanceBtn = within(sheet).getByRole("button", { name: "Toxina Botulínica" });
    fireEvent.click(substanceBtn);

    const confirmBtn = within(sheet).getByRole("button", { name: "Adicionar ponto" });
    fireEvent.click(confirmBtn);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay).toHaveLength(2);

    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.substance).toBe("toxina_botulinica");
    expect(added.unit).toBe("unidades");
    expect(added.quantity).toBe(1);
    expect(added.region).toBe("labio_superior"); // first FACE_REGION_KEYS entry, the sheet default

    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());
  });

  it("editing an existing point's substance updates its unit and persists the change", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: "Bioestimulador" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].substance).toBe("bioestimulador");
    expect(payload.stage2_overlay[0].unit).toBe("ml");
  });

  it("removing the selected point deletes it from the list and persists the shorter overlay", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: /Remover/ }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay).toHaveLength(0);

    await waitFor(() => expect(screen.getByText("Nenhum ponto ainda — adicione um acima.")).toBeInTheDocument());
  });

  it("dragging a point's dot updates its normalized x/y and persists on release", async () => {
    const { container } = renderPage();
    await waitForLoaded();

    const dot = container.querySelector(".cursor-grab") as HTMLElement;
    const photoContainer = dot.parentElement as HTMLElement;
    vi.spyOn(photoContainer, "getBoundingClientRect").mockReturnValue({
      left: 0, top: 0, width: 400, height: 300, right: 400, bottom: 300, x: 0, y: 0, toJSON: () => {},
    } as DOMRect);

    fireEvent.pointerDown(dot, { pointerId: 1, clientX: 200, clientY: 186 });
    fireEvent.pointerMove(photoContainer, { pointerId: 1, clientX: 100, clientY: 60 });
    fireEvent.pointerUp(photoContainer, { pointerId: 1, clientX: 100, clientY: 60 });

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].x).toBeCloseTo(0.25);
    expect(payload.stage2_overlay[0].y).toBeCloseTo(0.2);
  });

  it("a pointer-down/up on a dot with no movement selects it instead of moving it", async () => {
    const { container } = renderPage();
    await waitForLoaded();

    const dot = container.querySelector(".cursor-grab") as HTMLElement;
    const photoContainer = dot.parentElement as HTMLElement;

    fireEvent.pointerDown(dot, { pointerId: 1, clientX: 10, clientY: 10 });
    fireEvent.pointerUp(photoContainer, { pointerId: 1, clientX: 10, clientY: 10 });

    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
    expect(await screen.findByText("Editar Ponto")).toBeInTheDocument();
  });
});

// Alerta educativo de zona de risco vascular — cobre o achado do comitê de
// que a Etapa 2 não sinalizava nenhum risco de oclusão/necrose por
// preenchedor em zonas clássicas (glabela, dorso nasal, sulco nasolabial,
// comissura labial). Ver HIGH_VASCULAR_RISK_REGIONS em
// `src/lib/faceRegions.ts` — lista não validada clinicamente, ponto de
// partida para revisão médica.
describe("SessaoEstagio2 — alerta de risco vascular", () => {
  const VASCULAR_RISK_ALERT_TEXT =
    "Zona classicamente associada a maior risco vascular ao injetar preenchedor. Confirme técnica (agulha vs. cânula), aspiração e profundidade antes de prosseguir.";

  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
  });

  const renderWithPoints = (points: ApplicationPoint[]) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(points);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    return renderPage();
  };

  it("shows a vascular-risk badge next to a filler point placed in a high-risk region (glabela)", async () => {
    renderWithPoints([
      {
        id: "glabela_ha",
        region: "glabela",
        label: "Glabela",
        substance: "acido_hialuronico",
        quantity: 0.3,
        unit: "ml",
        x: 0.5,
        y: 0.34,
        source: "manual",
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    expect(screen.getByTitle(VASCULAR_RISK_ALERT_TEXT)).toBeInTheDocument();
  });

  it("does not show a vascular-risk badge for the same high-risk region when the substance is not filler", async () => {
    renderWithPoints([
      {
        id: "glabela_toxina",
        region: "glabela",
        label: "Glabela",
        substance: "toxina_botulinica",
        quantity: 2,
        unit: "unidades",
        x: 0.5,
        y: 0.34,
        source: "manual",
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    expect(screen.queryByTitle(VASCULAR_RISK_ALERT_TEXT)).not.toBeInTheDocument();
  });

  it("does not show a vascular-risk badge for a filler point outside the high-risk regions", async () => {
    renderWithPoints([
      {
        id: "mento_ha",
        region: "mento",
        label: "Mento",
        substance: "acido_hialuronico",
        quantity: 0.5,
        unit: "ml",
        x: 0.5,
        y: 0.85,
        source: "manual",
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    expect(screen.queryByTitle(VASCULAR_RISK_ALERT_TEXT)).not.toBeInTheDocument();
  });

  it("shows the inline vascular-risk warning in the edit sheet for a high-risk filler point", async () => {
    renderWithPoints([
      {
        id: "glabela_ha",
        region: "glabela",
        label: "Glabela",
        substance: "acido_hialuronico",
        quantity: 0.3,
        unit: "ml",
        x: 0.5,
        y: 0.34,
        source: "manual",
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Glabela"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    expect(within(sheet).getByText(VASCULAR_RISK_ALERT_TEXT)).toBeInTheDocument();
  });

  it("hides the inline warning once the substance is switched away from filler, and shows it again when switched back", async () => {
    renderWithPoints([
      {
        id: "glabela_ha",
        region: "glabela",
        label: "Glabela",
        substance: "acido_hialuronico",
        quantity: 0.3,
        unit: "ml",
        x: 0.5,
        y: 0.34,
        source: "manual",
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Glabela"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;
    expect(within(sheet).getByText(VASCULAR_RISK_ALERT_TEXT)).toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));
    expect(within(sheet).queryByText(VASCULAR_RISK_ALERT_TEXT)).not.toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Ácido Hialurônico" }));
    expect(within(sheet).getByText(VASCULAR_RISK_ALERT_TEXT)).toBeInTheDocument();
  });
});

// Alerta de Intervalo Mínimo entre Aplicações (ideia do squad de Produto):
// avisa, sem nunca bloquear, quando a região escolhida pra um ponto de
// toxina botulínica já recebeu toxina há menos de
// TOXIN_MIN_REINJECTION_INTERVAL_DAYS numa sessão CONCLUÍDA anterior desta
// mesma paciente. Ver TOXIN_MIN_REINJECTION_INTERVAL_DAYS/daysSince em
// src/types/harmonize.ts.
describe("SessaoEstagio2 — alerta de intervalo mínimo entre aplicações", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
  });

  const renderWithHistory = (
    points: ApplicationPoint[],
    pastCompletedSessions: { created_at: string; stage2_overlay: ApplicationPoint[] }[],
  ) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(points, 0, null, pastCompletedSessions);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    return renderPage();
  };

  const daysAgoIso = (days: number) => new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

  // O sheet de "Novo Ponto" abre sempre com a região default (primeira
  // entrada de FACE_REGION_KEYS, "labio_superior" — mesma convenção já usada
  // pelos outros testes deste arquivo) — o histórico é semeado para essa
  // mesma região, evitando ter que interagir com o seletor de região
  // (SheetSelect, que renderiza suas opções num Drawer.Portal separado).
  it("shows the inline warning when a new toxin point's default region received toxin under 90 days ago in a completed session", async () => {
    renderWithHistory(
      [],
      [
        {
          created_at: daysAgoIso(30),
          stage2_overlay: [
            { id: "old", region: "labio_superior", label: "Lábio Superior", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
          ],
        },
      ],
    );
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));

    expect(
      within(sheet).getByText(/Esta região recebeu toxina botulínica há 30 dias/),
    ).toBeInTheDocument();
  });

  it("does not show the warning once the interval is 90 days or more", async () => {
    renderWithHistory(
      [],
      [
        {
          created_at: daysAgoIso(120),
          stage2_overlay: [
            { id: "old", region: "labio_superior", label: "Lábio Superior", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
          ],
        },
      ],
    );
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));

    expect(within(sheet).queryByText(/Esta região recebeu toxina botulínica/)).not.toBeInTheDocument();
  });

  it("does not show the warning for a filler point in a region with prior toxin history", async () => {
    renderWithHistory(
      [
        { id: "ha", region: "glabela", label: "Glabela", substance: "acido_hialuronico", quantity: 0.3, unit: "ml", x: 0.5, y: 0.34, source: "manual" },
      ],
      [
        {
          created_at: daysAgoIso(30),
          stage2_overlay: [
            { id: "old", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
          ],
        },
      ],
    );
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Glabela"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    expect(within(sheet).queryByText(/Esta região recebeu toxina botulínica/)).not.toBeInTheDocument();
  });

  it("shows the warning in the edit sheet for an existing toxin point in a recently-treated region", async () => {
    renderWithHistory(
      [
        { id: "tox", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
      ],
      [
        {
          created_at: daysAgoIso(45),
          stage2_overlay: [
            { id: "old", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
          ],
        },
      ],
    );
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Glabela"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    expect(within(sheet).getByText(/Esta região recebeu toxina botulínica há 45 dias/)).toBeInTheDocument();
    // Non-blocking: the "Concluído" done button stays enabled.
    expect(within(sheet).getByRole("button", { name: "Concluído" })).not.toBeDisabled();
  });

  it("never blocks adding the point even when the warning is showing", async () => {
    renderWithHistory(
      [],
      [
        {
          created_at: daysAgoIso(10),
          stage2_overlay: [
            { id: "old", region: "labio_superior", label: "Lábio Superior", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
          ],
        },
      ],
    );
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));
    expect(within(sheet).getByText(/Esta região recebeu toxina botulínica/)).toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay.some((p) => p.region === "labio_superior" && p.substance === "toxina_botulinica")).toBe(true);
  });
});

// Item 3 do backlog P0: nada somava toxina/AH/bioestimulador entre os pontos
// aceitos de uma sessão, nem alertava se o total parecesse excessivo. Ver
// DOSE_ALERT_THRESHOLD em src/types/harmonize.ts para a referência usada.
describe("SessaoEstagio2 — dose total e alerta de referência", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    functionsInvokeSpy.mockReset();
  });

  const renderWithOverlay = (points: ApplicationPoint[], otherSessionsCount = 0) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(points, otherSessionsCount);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    return renderPage();
  };

  it("shows the per-substance dose total across all accepted points", async () => {
    renderWithOverlay([
      { id: "a", region: "glabela", label: "Glabela A", substance: "toxina_botulinica", quantity: 5, unit: "unidades", x: 0.5, y: 0.34, source: "ai" },
      { id: "b", region: "glabela", label: "Glabela B", substance: "toxina_botulinica", quantity: 5, unit: "unidades", x: 0.5, y: 0.3, source: "ai" },
      { id: "c", region: "labio_superior", label: "Lábio Superior", substance: "acido_hialuronico", quantity: 0.5, unit: "ml", x: 0.5, y: 0.62, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("3 pts")).toBeInTheDocument());

    expect(screen.getByText("Dose total da sessão")).toBeInTheDocument();
    expect(screen.getByText("10 unidades")).toBeInTheDocument();
    expect(screen.getByText("0.5 ml")).toBeInTheDocument();
  });

  it("shows a non-blocking attention alert when a substance total exceeds the reference threshold", async () => {
    renderWithOverlay([
      { id: "a", region: "mandibula_esquerda", label: "Masseter Esq", substance: "toxina_botulinica", quantity: 60, unit: "unidades", x: 0.22, y: 0.72, source: "manual" },
      { id: "b", region: "mandibula_direita", label: "Masseter Dir", substance: "toxina_botulinica", quantity: 60, unit: "unidades", x: 0.78, y: 0.72, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());

    expect(screen.getByText(/acima da referência de atenção/)).toBeInTheDocument();
    expect(screen.getByText(/não um limite regulatório/)).toBeInTheDocument();
    // Non-blocking: the primary action stays enabled even over threshold.
    expect(screen.getByRole("button", { name: "Gerar Simulação →" })).not.toBeDisabled();
  });

  it("does not show the attention alert when totals stay within the reference range", async () => {
    renderWithOverlay([
      { id: "a", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 4, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    expect(screen.queryByText(/acima da referência de atenção/)).not.toBeInTheDocument();
  });

  it("adds emphasis noting it's the patient's first session only when there is no prior session", async () => {
    const overlay: ApplicationPoint[] = [
      { id: "a", region: "mandibula_esquerda", label: "Masseter Esq", substance: "toxina_botulinica", quantity: 60, unit: "unidades", x: 0.22, y: 0.72, source: "manual" },
      { id: "b", region: "mandibula_direita", label: "Masseter Dir", substance: "toxina_botulinica", quantity: 60, unit: "unidades", x: 0.78, y: 0.72, source: "manual" },
    ];

    const { unmount } = renderWithOverlay(overlay, 0);
    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());
    expect(screen.getByText(/primeira sessão da paciente/)).toBeInTheDocument();
    unmount();

    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    renderWithOverlay(overlay, 3);
    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());
    expect(screen.queryByText(/primeira sessão da paciente/)).not.toBeInTheDocument();
  });

  // Segunda Checagem Automática de IA ("advogado do diabo" — item P7-3):
  // ao abrir a sheet de consentimento do procedimento com uma dose acima do
  // limiar, mostra o contraponto crítico da IA antes da confirmação final —
  // sem nunca desabilitar o botão de confirmar por causa dela.
  it("shows the AI's adversarial counterpoint in the procedure consent sheet when a dose is over threshold, never blocking confirmation", async () => {
    let resolveInvoke: (value: unknown) => void = () => {};
    functionsInvokeSpy.mockImplementation(() => new Promise((resolve) => { resolveInvoke = resolve; }));

    renderWithOverlay([
      { id: "a", region: "mandibula_esquerda", label: "Masseter Esq", substance: "toxina_botulinica", quantity: 60, unit: "unidades", x: 0.22, y: 0.72, source: "manual" },
      { id: "b", region: "mandibula_direita", label: "Masseter Dir", substance: "toxina_botulinica", quantity: 60, unit: "unidades", x: 0.78, y: 0.72, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: "Gerar Simulação →" }));

    const nameInput = await screen.findByTestId("procedure-consent-name-input");
    fireEvent.change(nameInput, { target: { value: "Maria Silva" } });
    fireEvent.click(screen.getByTestId("procedure-consent-checkbox"));

    const confirmBtn = screen.getByTestId("procedure-consent-confirm");
    expect(confirmBtn).toBeEnabled();

    expect(await screen.findByText(/Consultando uma segunda opinião crítica da IA/)).toBeInTheDocument();
    expect(confirmBtn).toBeEnabled(); // still never blocked while the AI check loads

    resolveInvoke({
      data: { available: true, counterpoint: "Risco concreto: dose de toxina acima do teto de face inteira." },
      error: null,
    });

    await waitFor(() =>
      expect(
        screen.getByText("Risco concreto: dose de toxina acima do teto de face inteira.")
      ).toBeInTheDocument()
    );
    expect(confirmBtn).toBeEnabled();
  });
});

// Item 2 do backlog P0: uma sugestão/região de toxina virava sempre exatamente
// 1 ApplicationPoint, mesmo quando clinicamente a região pede vários pontos
// discretos (glabela 3-5, terço frontal 4-6). Ver src/lib/applicationPoints.ts.
describe("SessaoEstagio2 — múltiplos pontos por região (toxina)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
  });

  const renderWithPoints = (points: ApplicationPoint[]) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(points);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    return renderPage();
  };

  it("offers a control to split a toxin region into another point, but not for HA/bioestimulador points", async () => {
    renderWithPoints([
      { id: "tox", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "ai" },
      { id: "ha", region: "labio_superior", label: "Lábio Superior", substance: "acido_hialuronico", quantity: 0.5, unit: "ml", x: 0.5, y: 0.62, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());

    // Only one split control — for the toxin point's region, not the HA one.
    expect(screen.getAllByRole("button", { name: /Mais um ponto nesta região/ })).toHaveLength(1);
  });

  it("splitting a region adds a discrete point and redistributes the group's total dose evenly", async () => {
    renderWithPoints([
      { id: "glabela_1", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 8, unit: "unidades", x: 0.5, y: 0.34, source: "ai" },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: /Mais um ponto nesta região/ }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay).toHaveLength(2);
    expect(payload.stage2_overlay.every((p) => p.groupId === "glabela_1")).toBe(true);
    expect(payload.stage2_overlay[0].quantity).toBe(4);
    expect(payload.stage2_overlay[1].quantity).toBe(4);

    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());
    expect(screen.getByText(/1\/2/)).toBeInTheDocument();
    expect(screen.getByText(/2\/2/)).toBeInTheDocument();
  });

  it("removing a point from a split group redistributes the remaining dose and stops offering removal at 1 point", async () => {
    renderWithPoints([
      { id: "a", region: "glabela", label: "Glabela 1", substance: "toxina_botulinica", quantity: 3, unit: "unidades", x: 0.48, y: 0.34, source: "ai", groupId: "g1" },
      { id: "b", region: "glabela", label: "Glabela 2", substance: "toxina_botulinica", quantity: 5, unit: "unidades", x: 0.52, y: 0.34, source: "ai", groupId: "g1" },
    ]);
    await waitFor(() => expect(screen.getByText("2 pts")).toBeInTheDocument());

    // Both points in this 2-point group offer removal; remove either one.
    fireEvent.click(screen.getAllByRole("button", { name: "Remover este ponto" })[0]);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay).toHaveLength(1);
    expect(payload.stage2_overlay[0].quantity).toBe(8);

    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());
    expect(screen.queryByRole("button", { name: "Remover este ponto" })).not.toBeInTheDocument();
  });
});

// Item 1 do backlog P0: faltava registrar técnica de aplicação, profundidade
// e dispositivo (agulha vs. cânula) por ponto.
describe("SessaoEstagio2 — técnica, profundidade e dispositivo", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(INITIAL_POINTS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () => waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

  it("applies sensible technique/depth/device defaults for the substance chosen on a new manual point", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));
    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.technique).toBe("intramuscular");
    expect(added.depth).toBe("intramuscular");
    expect(added.device).toBe("agulha");
  });

  it("edits and persists an existing point's technique", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    // The seeded HA point has no explicit technique, so the field shows
    // acido_hialuronico's sensible default ("Bolus") until edited.
    fireEvent.click(within(sheet).getByRole("button", { name: "Bolus" }));
    fireEvent.click(await screen.findByRole("button", { name: "Intramuscular" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].technique).toBe("intramuscular");
  });

  it("edits and persists an existing point's device", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    // acido_hialuronico defaults to "Cânula" — switch to "Agulha".
    fireEvent.click(within(sheet).getByRole("button", { name: "Agulha" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].device).toBe("agulha");
  });

  it("resets technique/depth/device to the new substance's defaults when the substance is switched", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].technique).toBe("intramuscular");
    expect(payload.stage2_overlay[0].depth).toBe("intramuscular");
    expect(payload.stage2_overlay[0].device).toBe("agulha");
  });
});

// Backlog #47: Catálogo de Procedimentos nomeados (ver src/lib/procedureCatalog.ts)
// — seletor opcional na Etapa 2 que, quando usado, pré-preenche região e dose
// sugeridas para o nível de intensidade escolhido, mas nunca trava esses
// campos nem exige selecionar um procedimento para criar/editar um ponto.
describe("SessaoEstagio2 — seletor de Procedimento (catálogo, backlog #47)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(INITIAL_POINTS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () => waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());
  const openNewPointSheet = async () => {
    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    return heading.closest('[style*="flex-direction: column"]') as HTMLElement;
  };

  it("renders the optional procedure selector defaulting to 'no procedure', not blocking the existing manual-point flow", async () => {
    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    expect(within(sheet).getByText("Procedimento (opcional)")).toBeInTheDocument();
    const select = within(sheet).getByRole("combobox") as HTMLSelectElement;
    expect(select.value).toBe("");
    expect(within(sheet).getByRole("option", { name: "Nenhum procedimento" })).toBeInTheDocument();

    // No procedure selected — the pre-existing "add a fully manual point"
    // flow (already covered above) must keep working unchanged.
    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.procedureId).toBeUndefined();
  });

  it("filters the procedure options by the currently selected substance", async () => {
    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    // Default substance is acido_hialuronico — an HA-only procedure should
    // be offered, a toxin-only one should not.
    expect(within(sheet).getByRole("option", { name: "Preenchimento Malar" })).toBeInTheDocument();
    expect(within(sheet).queryByRole("option", { name: "Toxina Botulínica — Glabela" })).not.toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));
    expect(within(sheet).getByRole("option", { name: "Toxina Botulínica — Glabela" })).toBeInTheDocument();
    expect(within(sheet).queryByRole("option", { name: "Preenchimento Malar" })).not.toBeInTheDocument();
  });

  it("selecting a procedure pre-fills region and the suggested dose for the default (médio) intensity, without locking either field", async () => {
    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    const procedure = getProcedure("preenchimento_malar")!;
    const select = within(sheet).getByRole("combobox") as HTMLSelectElement;
    fireEvent.change(select, { target: { value: "preenchimento_malar" } });

    // Region pre-filled to the procedure's first region (malar_esquerda) —
    // the default draft region (labio_superior) wasn't one of its regions.
    expect(within(sheet).getByText("Região Malar Esquerda")).toBeInTheDocument();
    // Dose pre-filled to the médio-level suggested dose.
    const suggestedMedio = suggestedDoseForLevel(procedure, "medio");
    expect(within(sheet).getByText(`${suggestedMedio} ml`)).toBeInTheDocument();

    // Still freely editable afterwards — the quantity +/- stepper (already
    // covered elsewhere) is not disabled by having a procedure selected.
    const stepper = within(sheet).getByText(`${suggestedMedio} ml`).parentElement as HTMLElement;
    const incrementBtn = within(stepper).getAllByRole("button")[1];
    fireEvent.click(incrementBtn);
    expect(within(sheet).getByText(`${Math.round((suggestedMedio + 0.1) * 100) / 100} ml`)).toBeInTheDocument();
  });

  it("changing the suggested intensity level updates the pre-filled dose", async () => {
    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    const procedure = getProcedure("preenchimento_malar")!;
    const select = within(sheet).getByRole("combobox") as HTMLSelectElement;
    fireEvent.change(select, { target: { value: "preenchimento_malar" } });

    fireEvent.click(within(sheet).getByRole("button", { name: "Alto" }));
    const suggestedAlto = suggestedDoseForLevel(procedure, "alto");
    expect(within(sheet).getByText(`${suggestedAlto} ml`)).toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Suave" }));
    const suggestedSuave = suggestedDoseForLevel(procedure, "suave");
    expect(within(sheet).getByText(`${suggestedSuave} ml`)).toBeInTheDocument();
  });

  it("persists the chosen procedureId, region and suggested dose on the created point", async () => {
    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    const procedure = getProcedure("preenchimento_malar")!;
    fireEvent.change(within(sheet).getByRole("combobox"), { target: { value: "preenchimento_malar" } });
    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.procedureId).toBe("preenchimento_malar");
    expect(added.region).toBe("malar_esquerda");
    expect(added.quantity).toBe(suggestedDoseForLevel(procedure, "medio"));
  });

  it("clears the selected procedure when the substance is switched away from it", async () => {
    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    const select = within(sheet).getByRole("combobox") as HTMLSelectElement;
    fireEvent.change(select, { target: { value: "preenchimento_malar" } });
    expect(select.value).toBe("preenchimento_malar");

    fireEvent.click(within(sheet).getByRole("button", { name: "Toxina Botulínica" }));
    expect(select.value).toBe("");
    expect(within(sheet).queryByText("Intensidade sugerida")).not.toBeInTheDocument();
  });

  it("offers the same optional procedure selector when editing an existing point, pre-filled from its procedureId", async () => {
    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    // The seeded HA point has no procedureId — selector starts at "none".
    const select = within(sheet).getByRole("combobox") as HTMLSelectElement;
    expect(select.value).toBe("");

    fireEvent.change(select, { target: { value: "preenchimento_labial" } });
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].procedureId).toBe("preenchimento_labial");
  });
});

// Sugestão Complementar de Procedimento (Produto & Features, ciclo 14/09,
// squad P9-4, ver ComplementaryProcedureInsight em SessaoEstagio2.tsx) —
// insight passivo mostrado quando um Procedimento nomeado é selecionado,
// alimentado por get_complementary_procedure_insight (RPC SECURITY DEFINER,
// ver src/lib/complementaryProcedureInsight.test.ts para a lógica pura e
// src/lib/complementaryProcedureInsightRpc.test.ts para as garantias de
// segurança/privacidade da migration).
describe("SessaoEstagio2 — Sugestão Complementar de Procedimento", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    rpcMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(INITIAL_POINTS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () => waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());
  const openNewPointSheet = async () => {
    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    return heading.closest('[style*="flex-direction: column"]') as HTMLElement;
  };

  it("shows the discreet insight when the RPC returns a complementary procedure for the just-selected one", async () => {
    rpcMock.mockImplementation(async (name: string) => {
      if (name === "get_complementary_procedure_insight") {
        return { data: [{ complementary_procedure_key: "projecao_mentoniana" }], error: null };
      }
      return { data: [], error: null };
    });

    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    fireEvent.change(within(sheet).getByRole("combobox"), { target: { value: "preenchimento_malar" } });

    expect(
      await within(sheet).findByText("Pacientes com Preenchimento Malar combinam com frequência com Projeção Mentoniana."),
    ).toBeInTheDocument();
  });

  it("calls the RPC with the exact key of the procedure just selected", async () => {
    rpcMock.mockImplementation(async (name: string) => {
      if (name === "get_complementary_procedure_insight") {
        return { data: [{ complementary_procedure_key: "projecao_mentoniana" }], error: null };
      }
      return { data: [], error: null };
    });

    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    fireEvent.change(within(sheet).getByRole("combobox"), { target: { value: "preenchimento_malar" } });

    await waitFor(() =>
      expect(rpcMock).toHaveBeenCalledWith("get_complementary_procedure_insight", { p_procedure_key: "preenchimento_malar" }),
    );
  });

  it("shows nothing — no placeholder, no empty state — when the RPC returns no row (insufficient sample)", async () => {
    rpcMock.mockImplementation(async (name: string) => {
      if (name === "get_complementary_procedure_insight") return { data: [], error: null };
      return { data: [], error: null };
    });

    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    fireEvent.change(within(sheet).getByRole("combobox"), { target: { value: "preenchimento_malar" } });

    await waitFor(() => expect(rpcMock).toHaveBeenCalledWith("get_complementary_procedure_insight", { p_procedure_key: "preenchimento_malar" }));
    expect(within(sheet).queryByText(/combinam com frequência/)).not.toBeInTheDocument();
  });

  it("never shows an insight before any procedure is selected", async () => {
    rpcMock.mockImplementation(async (name: string) => {
      if (name === "get_complementary_procedure_insight") {
        return { data: [{ complementary_procedure_key: "projecao_mentoniana" }], error: null };
      }
      return { data: [], error: null };
    });

    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    expect(rpcMock).not.toHaveBeenCalledWith("get_complementary_procedure_insight", expect.anything());
    expect(within(sheet).queryByText(/combinam com frequência/)).not.toBeInTheDocument();
  });

  it("a failure in this RPC never breaks the rest of Stage 2 — the point can still be added normally", async () => {
    rpcMock.mockImplementation(async (name: string) => {
      if (name === "get_complementary_procedure_insight") {
        return { data: null, error: { message: "network error" } };
      }
      return { data: [], error: null };
    });

    renderPage();
    await waitForLoaded();
    const sheet = await openNewPointSheet();

    fireEvent.change(within(sheet).getByRole("combobox"), { target: { value: "preenchimento_malar" } });
    await waitFor(() => expect(rpcMock).toHaveBeenCalledWith("get_complementary_procedure_insight", { p_procedure_key: "preenchimento_malar" }));

    expect(within(sheet).queryByText(/combinam com frequência/)).not.toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.procedureId).toBe("preenchimento_malar");
  });
});

// Copiloto de Justificativa Clínica (backlog P6) — rascunho estruturado
// oferecido ao criar/editar um ponto MANUAL, alimentado por
// get_manual_point_justification_stats (ver ManualPointJustificationCopilot
// em SessaoEstagio2.tsx e src/lib/manualPointJustification.test.ts para a
// lógica pura de composição do texto).
describe("SessaoEstagio2 — Copiloto de Justificativa Clínica", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    rpcMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(INITIAL_POINTS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () => waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

  it("shows an editable draft justification, pre-filled from the RPC's aggregated stats, when adding a new (manual) point", async () => {
    rpcMock.mockResolvedValue({
      data: [
        {
          avg_quantity: 0.8,
          quantity_sample_size: 12,
          avg_accuracy_rating: 4.2,
          accuracy_sample_size: 9,
          adverse_event_rate: null,
          adverse_event_sample_size: 0,
        },
      ],
      error: null,
    });

    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    expect(await within(sheet).findByText("Rascunho sugerido pela Central de Inteligência")).toBeInTheDocument();
    // O texto nunca fala do paciente atual — só do padrão agregado da base.
    expect(within(sheet).getByText(/nunca um dado sobre esta paciente/)).toBeInTheDocument();

    const technicalNote = within(sheet).getByLabelText("Nota técnica") as HTMLTextAreaElement;
    expect(technicalNote.value).toContain("0.8 ml");
    expect(technicalNote.value).toContain("4.2/5");

    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.justification?.technicalNote).toContain("0.8 ml");
  });

  it("shows no suggestion at all — no error, no alarming state — when the RPC has no row for the combination (small/new database)", async () => {
    rpcMock.mockResolvedValue({ data: [], error: null });

    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    await waitFor(() => expect(rpcMock).toHaveBeenCalled());
    expect(within(sheet).queryByText("Rascunho sugerido pela Central de Inteligência")).not.toBeInTheDocument();

    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto" }));
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.justification).toBeUndefined();
  });

  it("never offers the copilot when editing a point whose source is 'ai' — the AI's own justification is never replaced by an aggregated draft", async () => {
    rpcMock.mockResolvedValue({
      data: [{ avg_quantity: 0.8, quantity_sample_size: 12, avg_accuracy_rating: null, accuracy_sample_size: 0, adverse_event_rate: null, adverse_event_sample_size: 0 }],
      error: null,
    });

    renderPage();
    await waitForLoaded();

    fireEvent.click(screen.getByText("Lábio Superior")); // INITIAL_POINTS[0].source === "ai"
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    expect(within(sheet).queryByText("Rascunho sugerido pela Central de Inteligência")).not.toBeInTheDocument();
  });
});

// Graceful degradation quando o MediaPipe não encontra nenhum landmark facial
// (foto de ângulo ruim, mal iluminada, rosto parcialmente coberto, etc.) —
// item P2 "Validação da IA/MediaPipe com casos adversos". O FaceLandmarker
// não expõe um score de confiança por rosto (só um resultado binário: achou
// ou não, ver handleImgLoad em SessaoEstagio2.tsx), então o que dá pra
// garantir é que, quando não achar nada, os pontos ficam nas posições
// genéricas de fallback (não ajustadas ao rosto real) e um aviso que
// PERSISTE na tela — não só um toast transitório — deixa claro que é preciso
// conferir/reposicionar manualmente antes de prosseguir.
describe("SessaoEstagio2 — aviso de detecção facial malsucedida", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    createSignedUrlMock.mockReset();
    __resetFaceLandmarkerForTests();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(INITIAL_POINTS, 0, "patients/pat-1/foto.jpg");
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    createSignedUrlMock.mockResolvedValue({ data: { signedUrl: "https://example.com/foto.jpg" } });
  });

  const DETECTION_WARNING_TEXT =
    /Não foi possível detectar todos os pontos faciais com precisão nesta foto/;

  it("shows a persistent banner (not just a toast) when the model finds no face landmarks", async () => {
    vi.mocked(FilesetResolver.forVisionTasks).mockResolvedValue({} as never);
    vi.mocked(FaceLandmarker.createFromOptions).mockResolvedValue({
      detect: () => ({ faceLandmarks: [] }),
    } as never);

    renderPage();
    const img = await screen.findByAltText("Foto do paciente");
    fireEvent.load(img);

    expect(await screen.findByText(DETECTION_WARNING_TEXT)).toBeInTheDocument();
    // Os pontos seguem visíveis/editáveis manualmente — a falha de detecção
    // nunca deve travar a Etapa 2.
    expect(screen.getByText("Lábio Superior")).toBeInTheDocument();
  });

  it("also shows the banner when the landmarker itself fails (e.g. WASM/model couldn't load)", async () => {
    vi.mocked(FilesetResolver.forVisionTasks).mockRejectedValue(new Error("wasm load failed"));

    renderPage();
    const img = await screen.findByAltText("Foto do paciente");
    fireEvent.load(img);

    expect(await screen.findByText(DETECTION_WARNING_TEXT)).toBeInTheDocument();
  });

  it("does not show the banner when landmarks are found normally", async () => {
    vi.mocked(FilesetResolver.forVisionTasks).mockResolvedValue({} as never);
    vi.mocked(FaceLandmarker.createFromOptions).mockResolvedValue({
      detect: () => ({ faceLandmarks: [[{ x: 0.5, y: 0.5, z: 0 }]] }),
    } as never);

    renderPage();
    const img = await screen.findByAltText("Foto do paciente");
    fireEvent.load(img);

    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());
    expect(screen.queryByText(DETECTION_WARNING_TEXT)).not.toBeInTheDocument();
  });
});

// Protocolos Nomeados (comitê técnico simulado, ver src/lib/namedProtocols.ts)
// — entrada alternativa à montagem manual de pontos: escolher um dos 6
// protocolos aplica todos os pontos dele de uma vez e dispara a mesma
// simulação (generate-simulation) já usada na Etapa 3, ANTES de expor a
// dosagem exata de cada ponto para edição.
describe("SessaoEstagio2 — seletor de Protocolo nomeado (comitê)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    toastErrorMock.mockReset();
    functionsInvokeSpy.mockReset();
    functionsInvokeSpy.mockResolvedValue({
      data: { simulationUrl: "https://example.com/sim.png", originalUrl: "https://example.com/orig.png" },
      error: null,
    });
  });

  const renderWithPoints = (points: ApplicationPoint[]) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(points);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    return renderPage();
  };

  const openProtocolPicker = async () => {
    fireEvent.click(screen.getByRole("button", { name: /Usar um Protocolo/ }));
    const heading = await screen.findByText("Protocolos Nomeados");
    return heading.closest('[style*="flex-direction: column"]') as HTMLElement;
  };

  // A sheet do picker (lista dos 6 protocolos) e a de confirmação de UM
  // protocolo compartilham o mesmo texto de nome de protocolo (o card na
  // lista e o título da confirmação) — por isso a sheet de confirmação é
  // localizada pelo seu botão de confirmar, que só existe nela, em vez de
  // pelo nome do protocolo (ambíguo entre as duas sheets).
  const getConfirmationSheet = async () => {
    const confirmBtn = await screen.findByRole("button", { name: "Aplicar protocolo e gerar simulação" });
    return confirmBtn.closest('[style*="flex-direction: column"]') as HTMLElement;
  };

  // Neste ambiente de teste (jsdom), uma BottomSheet (vaul) fechada some
  // visualmente mas seu conteúdo pode continuar montado (via Portal, direto
  // em document.body, fora da árvore da página) — o Radix também mantém o
  // resto da página marcado aria-hidden enquanto isso. Duas consequências
  // usadas abaixo: (1) uma query por *role* (que respeita aria-hidden)
  // precisa de `{ hidden: true }` para achar elementos da página principal
  // depois de qualquer sheet já ter sido aberta; (2) uma query por *texto*
  // precisa ficar restrita à raiz real da página (não ao `screen` global)
  // pra não colidir com o mesmo texto ainda presente numa sheet fechada
  // portalada para fora dessa raiz.
  const appRoot = () => screen.getByText("Pontos de Aplicação").closest(".min-h-screen") as HTMLElement;

  it("lists all 6 named protocols with name and short description, not applying any point yet", async () => {
    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const sheet = await openProtocolPicker();

    for (const name of ["Boca Russa", "Botox Baby", "Fox Eyes", "Contorno em V", "Facelift Líquido", "Olhar Descansado"]) {
      expect(within(sheet).getByText(name)).toBeInTheDocument();
    }
    expect(within(sheet).getByText(/prioriza altura e formato de coração/)).toBeInTheDocument();
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
  });

  it("opens a confirmation screen with the fixed committee disclaimer and the protocol's contraindications before applying anything", async () => {
    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    expect(within(previewSheet).getByText(/Esta é uma sugestão de protocolo de mercado, não validação clínica real/)).toBeInTheDocument();
    expect(within(previewSheet).getByText(/histórico de herpes labial recorrente/i)).toBeInTheDocument();
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
  });

  it("proactively warns that Facelift Líquido exceeds the dose attention threshold by design, before applying any point", async () => {
    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Facelift Líquido"));

    const previewSheet = await getConfirmationSheet();
    expect(within(previewSheet).getByText(/acima da referência de atenção de 6 ml/)).toBeInTheDocument();
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
  });

  it("does not warn for a protocol whose own dose sum stays within the attention threshold and has nothing to combine with", async () => {
    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    expect(within(previewSheet).queryByText(/acima da referência de atenção/)).not.toBeInTheDocument();
    expect(within(previewSheet).queryByText(/Esta sessão já tem/)).not.toBeInTheDocument();
  });

  // Interação entre protocolos: adicionar um SEGUNDO protocolo de toxina
  // na mesma sessão mostra a soma projetada de toxina total PROATIVAMENTE,
  // antes de aplicar os pontos — sem esperar o alerta padrão que só aparece
  // depois que os pontos já estão inseridos.
  it("proactively shows the projected combined toxin total when a second toxin-bearing protocol is chosen", async () => {
    renderWithPoints([
      { id: "existing-toxin", region: "glabela", label: "Glabela", substance: "toxina_botulinica", quantity: 20, unit: "unidades", x: 0.5, y: 0.34, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Botox Baby"));

    const previewSheet = await getConfirmationSheet();
    // Botox Baby soma 26-40 U por si só; somado aos 20 U já aplicados,
    // a projeção é 46-60 U — abaixo do limiar de 100, então é uma
    // informação neutra, não um alerta de excesso.
    expect(within(previewSheet).getByText(/Esta sessão já tem 20 unidades de Toxina Botulínica/)).toBeInTheDocument();
    expect(within(previewSheet).getByText(/46–60 unidades/)).toBeInTheDocument();
    expect(within(previewSheet).queryByText(/acima da referência de atenção/)).not.toBeInTheDocument();
  });

  it("cancelling the confirmation screen applies nothing", async () => {
    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    fireEvent.click(within(previewSheet).getByRole("button", { name: "Cancelar" }));

    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
    expect(functionsInvokeSpy).not.toHaveBeenCalled();
    expect(screen.getByText("0 pt")).toBeInTheDocument();
  });

  // Fluxo completo: confirmar → simular → revelar. Os pontos/dose ficam
  // ocultos enquanto a simulação está sendo gerada, e só ficam
  // visíveis/editáveis depois que o profissional clica em "revelar" — nunca
  // antes de ver o resultado simulado.
  it("applies the protocol's points, hides the dose/point list while simulating, then reveals them as normal editable points", async () => {
    let resolveInvoke: (value: unknown) => void = () => {};
    functionsInvokeSpy.mockImplementation(
      () => new Promise((resolve) => { resolveInvoke = resolve; }),
    );

    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    fireEvent.click(within(previewSheet).getByRole("button", { name: "Aplicar protocolo e gerar simulação" }));

    // Pontos já persistidos no stage2_overlay, ambos marcados com o
    // protocolId — mesma estrutura de sempre, editável depois.
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay).toHaveLength(2);
    expect(payload.stage2_overlay.every((p) => p.protocolId === "boca_russa")).toBe(true);
    expect(functionsInvokeSpy).toHaveBeenCalledWith(
      "generate-simulation",
      expect.objectContaining({ body: expect.objectContaining({ sessionId: "s1", patientId: "pat-1" }) }),
    );

    // Ainda gerando: a dose/pontos exatos ficam ocultos, e o botão de
    // avançar fica desabilitado (não é possível pular a revelação). Texto
    // (não `getByRole`) e sem escopo de root ainda importam aqui — ver
    // comentário de `appRoot` acima.
    expect(screen.queryByText("Dose total da sessão")).not.toBeInTheDocument();
    expect(screen.getByText("Gerar Simulação →").closest("button")).toBeDisabled();

    resolveInvoke({
      data: { simulationUrl: "https://example.com/sim.png", originalUrl: "https://example.com/orig.png" },
      error: null,
    });

    const revealBtn = (await screen.findByText("Ver pontos e dose do protocolo")).closest("button") as HTMLButtonElement;
    fireEvent.click(revealBtn);

    // Revelado: pontos/dose voltam a aparecer, livremente editáveis, com o
    // aviso fixo do comitê e o selo de origem do protocolo em cada ponto.
    // Escopado à raiz real da página (ver `appRoot`) — a sheet de
    // confirmação já fechada pode continuar portalada fora dela, com o
    // mesmo texto de aviso do comitê, o que faria `screen.getByText`
    // (global) encontrar 2 ocorrências em vez de 1.
    await screen.findByText("Lábio Inferior");
    const root = appRoot();
    expect(within(root).getByText(/Esta é uma sugestão de protocolo de mercado, não validação clínica real/)).toBeInTheDocument();
    expect(within(root).getAllByText("Protocolo: Boca Russa").length).toBe(2);
    expect(within(root).getByRole("button", { name: "Gerar Simulação →", hidden: true })).not.toBeDisabled();
  });

  it("still lets the professional review the protocol's points when the simulation fails to generate", async () => {
    functionsInvokeSpy.mockResolvedValue({ data: null, error: { message: "boom" } });

    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    fireEvent.click(within(previewSheet).getByRole("button", { name: "Aplicar protocolo e gerar simulação" }));

    const viewAnywayBtn = (await screen.findByText("Ver pontos e dose mesmo assim")).closest("button") as HTMLButtonElement;
    fireEvent.click(viewAnywayBtn);

    expect(await screen.findByText("Lábio Inferior")).toBeInTheDocument();
  });

  // Regressão (QA contínuo, ciclo 43): este caminho lia só `data` para extrair
  // a mensagem de erro. Em qualquer resposta não-2xx o supabase-js devolve
  // `data: null` e guarda o corpo em `error.context`, então a recusa de
  // consentimento (451) e a de assinatura (402) viravam sempre o mesmo toast
  // genérico — sem dizer ao profissional o que ele precisa fazer. Ver
  // src/lib/edgeFunctionError.ts.
  function refusalInvokeResult(body: unknown, status: number) {
    return {
      data: null,
      error: {
        message: "Edge Function returned a non-2xx status code",
        context: new Response(JSON.stringify(body), {
          status,
          headers: { "Content-Type": "application/json" },
        }),
      },
    };
  }

  it("shows the server's consent refusal message, not the generic failure toast", async () => {
    functionsInvokeSpy.mockResolvedValue(
      refusalInvokeResult(
        {
          error: "Consentimento do paciente não registrado. Colha o termo na ficha do paciente.",
          code: "patient_consent_required",
        },
        451,
      ),
    );

    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    fireEvent.click(within(previewSheet).getByRole("button", { name: "Aplicar protocolo e gerar simulação" }));

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith(
        "Consentimento do paciente não registrado. Colha o termo na ficha do paciente.",
      ),
    );
    // A tela continua deixando revisar os pontos, como antes.
    expect(await screen.findByText("Ver pontos e dose mesmo assim")).toBeInTheDocument();
  });

  it("shows the server's subscription refusal message, not the generic failure toast", async () => {
    functionsInvokeSpy.mockResolvedValue(
      refusalInvokeResult({ error: "Assinatura inativa. Regularize seu pagamento para continuar." }, 402),
    );

    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    fireEvent.click(within(previewSheet).getByRole("button", { name: "Aplicar protocolo e gerar simulação" }));

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith("Assinatura inativa. Regularize seu pagamento para continuar."),
    );
  });

  it("falls back to the translated generic toast when the failure carries no server message", async () => {
    functionsInvokeSpy.mockResolvedValue({ data: null, error: { message: "boom" } });

    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());
    const pickerSheet = await openProtocolPicker();
    fireEvent.click(within(pickerSheet).getByText("Boca Russa"));

    const previewSheet = await getConfirmationSheet();
    fireEvent.click(within(previewSheet).getByRole("button", { name: "Aplicar protocolo e gerar simulação" }));

    // Sem corpo legível, cai no `error.message` do SDK — ainda melhor que
    // nenhum texto, e o teste fixa que o catch não descarta mais a mensagem.
    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("boom"));
  });
});

// Linhas de técnica de aplicação (relatório de investigação "scanner real do
// rosto" — ver TechniqueLine em src/types/harmonize.ts e
// src/lib/faceGeometry.ts): renderização da polyline sobre a foto e o novo
// seletor de "padrão visual de aplicação", separado do seletor de `technique`
// clínica já existente. Totalmente opcional/retrocompatível — um ponto sem
// `line` (toda sessão antiga) continua renderizando exatamente como antes.
describe("SessaoEstagio2 — linhas de técnica de aplicação (padrão visual)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
  });

  const renderWithPoints = (points: ApplicationPoint[]) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(points);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
    return renderPage();
  };

  it("a point without `line` renders no technique-line SVG group — same as before this feature", async () => {
    const { container } = renderWithPoints([
      { id: "ha", region: "labio_superior", label: "Lábio Superior", substance: "acido_hialuronico", quantity: 0.5, unit: "ml", x: 0.5, y: 0.62, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    expect(container.querySelector('[data-testid="technique-line-ha"]')).not.toBeInTheDocument();
  });

  it("a point with `line` renders its polyline over the photo", async () => {
    const { container } = renderWithPoints([
      {
        id: "tox",
        region: "glabela",
        label: "Glabela",
        substance: "toxina_botulinica",
        quantity: 8,
        unit: "unidades",
        x: 0.5,
        y: 0.34,
        source: "manual",
        line: {
          pattern: "linear_retrograda",
          path: [
            { x: 0.5, y: 0.34 },
            { x: 0.5, y: 0.29 },
          ],
          originIndex: 0,
        },
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    const lineGroup = container.querySelector('[data-testid="technique-line-tox"]');
    expect(lineGroup).toBeInTheDocument();
    const polyline = lineGroup?.querySelector("polyline");
    expect(polyline).toBeInTheDocument();
    const coords = (polyline?.getAttribute("points") ?? "").split(" ").map((pair) => pair.split(",").map(Number));
    expect(coords).toHaveLength(2);
    expect(coords[0]).toEqual([50, 34]);
    expect(coords[1][0]).toBeCloseTo(50);
    expect(coords[1][1]).toBeCloseTo(29);
  });

  it("choosing a visual pattern in the edit sheet sets point.line, computed from the point's current position", async () => {
    renderWithPoints([
      { id: "ha", region: "labio_superior", label: "Lábio Superior", substance: "acido_hialuronico", quantity: 0.5, unit: "ml", x: 0.5, y: 0.62, source: "manual" },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Lábio Superior"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    // Trigger starts showing "Nenhum" — the point has no line yet.
    fireEvent.click(within(sheet).getByRole("button", { name: /Nenhum \(ponto simples\)/ }));
    fireEvent.click(await screen.findByRole("button", { name: "Linear/Retrógrada" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const updated = payload.stage2_overlay[0];
    expect(updated.line?.pattern).toBe("linear_retrograda");
    // path[originIndex] sempre coincide com a posição atual do ponto.
    expect(updated.line?.path[updated.line.originIndex]).toEqual({ x: 0.5, y: 0.62 });
  });

  it("choosing 'Nenhum' removes an existing line from the point", async () => {
    renderWithPoints([
      {
        id: "tox",
        region: "glabela",
        label: "Glabela",
        substance: "toxina_botulinica",
        quantity: 8,
        unit: "unidades",
        x: 0.5,
        y: 0.34,
        source: "manual",
        line: { pattern: "fanning", path: [{ x: 0.5, y: 0.34 }], originIndex: 0 },
      },
    ]);
    await waitFor(() => expect(screen.getByText("1 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByText("Glabela"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    // Trigger starts showing the already-active "Leque (Fanning)" pattern.
    fireEvent.click(within(sheet).getByRole("button", { name: "Leque (Fanning)" }));
    fireEvent.click(await screen.findByRole("button", { name: /Nenhum \(ponto simples\)/ }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    expect(payload.stage2_overlay[0].line).toBeUndefined();
  });

  it("choosing a visual pattern on a brand-new manual point persists the computed line", async () => {
    renderWithPoints([]);
    await waitFor(() => expect(screen.getByText("0 pt")).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: /Adicionar ponto/ }));
    const heading = await screen.findByText("Novo Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByRole("button", { name: /Nenhum \(ponto simples\)/ }));
    fireEvent.click(await screen.findByRole("button", { name: "Punctura Seriada" }));

    // O sheet aninhado do seletor de padrão (vaul/Radix) deixa o "Novo Ponto"
    // marcado aria-hidden por um instante ao fechar — mesma ressalva já usada
    // alhures neste arquivo para sheets aninhadas (ver comentário de
    // `appRoot` na describe de Protocolos Nomeados); `hidden: true` ignora
    // esse aria-hidden transitório.
    fireEvent.click(within(sheet).getByRole("button", { name: "Adicionar ponto", hidden: true }));
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const added = payload.stage2_overlay.find((p) => p.source === "manual")!;
    expect(added.line?.pattern).toBe("punctura_seriada");
  });

  // Achado da investigação desta tarefa: trocar a REGIÃO de um ponto que já
  // tem uma linha de técnica ativa não recalculava `line` — o traço ficava
  // preso ao polígono da região ANTERIOR (aqui, glabela, que tem
  // `areaIndices`), só que passava a ser exibido como se fosse da região
  // NOVA (mandíbula, ainda "PENDENTE" sem `areaIndices` em faceRegions.ts).
  // Landmarks reais (via mock do FaceLandmarker) são necessários aqui porque
  // `regionPolygonForRegion` só devolve um polígono de verdade com detecção —
  // sem isso o teste não distinguiria os dois polígonos.
  it("changing a point's region recomputes its technique line from the NEW region's polygon", async () => {
    __resetFaceLandmarkerForTests();
    const landmarksWithGlabelaPolygon = Array.from({ length: 478 }, () => ({ x: 0.5, y: 0.5 }));
    // Cluster de `glabela` (areaIndices em src/lib/faceRegions.ts): o ponto
    // mais distante da origem (0.5, 0.34) é o índice 9, a 0.10 de distância.
    landmarksWithGlabelaPolygon[8] = { x: 0.50, y: 0.32 };
    landmarksWithGlabelaPolygon[9] = { x: 0.50, y: 0.24 };
    landmarksWithGlabelaPolygon[55] = { x: 0.46, y: 0.33 };
    landmarksWithGlabelaPolygon[285] = { x: 0.54, y: 0.33 };
    landmarksWithGlabelaPolygon[168] = { x: 0.50, y: 0.35 };
    vi.mocked(FilesetResolver.forVisionTasks).mockResolvedValue({} as never);
    vi.mocked(FaceLandmarker.createFromOptions).mockResolvedValue({
      detect: () => ({ faceLandmarks: [landmarksWithGlabelaPolygon] }),
    } as never);
    createSignedUrlMock.mockResolvedValue({ data: { signedUrl: "https://example.com/foto.jpg" } });

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") {
        return createSessionsBuilder(
          [
            {
              id: "tox",
              region: "glabela",
              label: "Glabela",
              substance: "toxina_botulinica",
              quantity: 8,
              unit: "unidades",
              x: 0.5,
              y: 0.34,
              source: "manual",
              line: { pattern: "linear_retrograda", path: [{ x: 0.5, y: 0.34 }, { x: 0.5, y: 0.255 }], originIndex: 0 },
            },
          ],
          0,
          "patients/pat-1/foto.jpg",
        );
      }
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });

    renderPage();
    const img = await screen.findByAltText("Foto do paciente");
    fireEvent.load(img);
    // Espera a detecção terminar (o badge some de "Detectando rosto…") antes
    // de interagir — landmarks precisa estar populado para o teste fazer
    // sentido.
    await screen.findByText("1 ponto");

    fireEvent.click(screen.getByText("Glabela"));
    const heading = await screen.findByText("Editar Ponto");
    const sheet = heading.closest('[style*="flex-direction: column"]') as HTMLElement;

    fireEvent.click(within(sheet).getByText("Glabela"));
    fireEvent.click(await screen.findByRole("button", { name: "Ângulo Mandibular Esquerdo" }));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls.at(-1)![0] as { stage2_overlay: ApplicationPoint[] };
    const updated = payload.stage2_overlay.find((p) => p.id === "tox")!;
    expect(updated.region).toBe("mandibula_esquerda");
    // A posição do ponto não muda ao trocar a região — só o alcance da linha.
    expect(updated.line?.path[0]).toEqual({ x: 0.5, y: 0.34 });
    // `mandibula_esquerda` ainda não tem `areaIndices` (ver "PENDENTE" em
    // faceRegions.ts) — sem o fix, este valor continuaria 0.255 (o alcance
    // calculado sobre o polígono de glabela, a região ANTERIOR).
    expect(updated.line?.path[1]?.y).toBeCloseTo(0.29);
  });
});
