import React from 'react';
import LegalDocumentPage from '@/components/site/LegalDocumentPage';
import { TERMS_BODY_PT, TERMS_VERSION } from '@/lib/legalDocs';

// Rota pública /termos. O conteúdo real vive em
// src/content/legal/termos-de-uso.pt.md (ver src/lib/legalDocs.ts para o
// porquê de ser Markdown versionado no repo, e para a regra de subir a
// versão a cada edição).
const Termos: React.FC = () => (
  <LegalDocumentPage
    titleKey="legal.terms.title"
    descriptionKey="legal.terms.description"
    version={TERMS_VERSION}
    body={TERMS_BODY_PT}
  />
);

export default Termos;
