import React, { useState, useEffect, useMemo } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import TopBar from '@/components/harmonize/TopBar';
import StageDots from '@/components/harmonize/StageDots';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertTriangle, ShieldAlert } from 'lucide-react';
import { toast } from 'sonner';
import {
  SKIN_SCREENING_CRITERIA,
  SKIN_SCREENING_CRITERION_KEYS,
  isSkinScreeningComplete,
  hasSuspiciousFinding,
  canProceedDespiteFinding,
  type SkinScreeningAnswers,
  type SkinScreeningCriterionKey,
} from '@/lib/skinScreening';
import AdversarialRiskCheck from '@/components/harmonize/AdversarialRiskCheck';
import type { AdversarialRiskCheckRequest } from '@/lib/adversarialRiskCheck';

const EMPTY_ANSWERS: SkinScreeningAnswers = {
  asymmetry: null,
  irregularBorders: null,
  colorVariation: null,
  diameterOver6mm: null,
  recentEvolution: null,
};

const SessaoTriagemPele: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t, i18n } = useTranslation();

  const [patientId, setPatientId] = useState<string | null>(null);
  const [patientName, setPatientName] = useState('');
  // Já preenchido pelo handleProceed do Estágio 1 (label do ponto único ou
  // resumo "N pontos planejados") antes de navegar pra cá — não precisamos
  // reconstruir a partir de stage1_analysis/stage2_overlay, só ler de volta.
  const [procedureName, setProcedureName] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  /**
   * A triagem já salva para esta sessão, quando existe.
   *
   * A tela montava sempre com `EMPTY_ANSWERS`, sem nunca ler
   * `skin_screenings`. Como a tabela tem uma linha por sessão
   * (`session_id UNIQUE`) e o save usa `upsert(..., { onConflict:
   * 'session_id' })`, que substitui a linha inteira, refazer a triagem da
   * mesma sessão apagava o registro anterior.
   *
   * Isso não era hipotético: "Encaminhar e não prosseguir" não avança
   * `sessions.status`, de propósito, então a sessão continua em `stage1` e a
   * lista do paciente leva de volta para a Etapa 1 — e daí de novo para esta
   * tela, em branco. Quem não lembrasse do achado (ou fosse outro
   * profissional, já que a tela não mostrava nada) marcaria tudo como "não
   * observado" e apagaria o registro de que havia uma lesão sugestiva de
   * melanoma e de que o paciente tinha sido encaminhado.
   *
   * A migração original da tabela (20260910073606) não criou política de
   * DELETE exatamente para esse registro não poder ser apagado; o UPDATE
   * derrubava a garantia por outro caminho. O gatilho de
   * 20260922180000_add_skin_screening_revisions.sql guarda a versão anterior,
   * e a tela passa a mostrar o que já existe em vez de fingir folha em
   * branco.
   *
   * Achado do ciclo 73 do QA Contínuo.
   */
  const [previousScreening, setPreviousScreening] = useState<{
    recordedAt: string;
    hasSuspiciousFinding: boolean;
    referredToDermatology: boolean;
    proceededDespiteFinding: boolean;
  } | null>(null);

  const [answers, setAnswers] = useState<SkinScreeningAnswers>(EMPTY_ANSWERS);
  const [lesionLocation, setLesionLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [acknowledged, setAcknowledged] = useState(false);
  const [justification, setJustification] = useState('');

  useEffect(() => {
    if (!id || !user) return;
    const load = async () => {
      const { data: session } = await supabase
        .from('sessions')
        .select('patient_id, selected_procedure')
        .eq('id', id)
        .single();
      if (session) {
        setPatientId(session.patient_id);
        setProcedureName(session.selected_procedure || '');
        const { data: patient } = await supabase
          .from('patients')
          .select('name')
          .eq('id', session.patient_id)
          .single();
        if (patient) setPatientName(patient.name);
      }

      const { data: existing } = await supabase
        .from('skin_screenings')
        .select(
          'asymmetry, irregular_borders, color_variation, diameter_over_6mm, recent_evolution, lesion_location, notes, has_suspicious_finding, referred_to_dermatology, proceeded_despite_finding, updated_at'
        )
        .eq('session_id', id)
        .maybeSingle();
      if (existing) {
        setAnswers({
          asymmetry: existing.asymmetry,
          irregularBorders: existing.irregular_borders,
          colorVariation: existing.color_variation,
          diameterOver6mm: existing.diameter_over_6mm,
          recentEvolution: existing.recent_evolution,
        });
        setLesionLocation(existing.lesion_location ?? '');
        setNotes(existing.notes ?? '');
        setPreviousScreening({
          recordedAt: existing.updated_at,
          hasSuspiciousFinding: existing.has_suspicious_finding,
          referredToDermatology: existing.referred_to_dermatology,
          proceededDespiteFinding: existing.proceeded_despite_finding,
        });
      }

      setLoading(false);
    };
    load();
  }, [id, user]);

  const complete = isSkinScreeningComplete(answers);
  const suspicious = hasSuspiciousFinding(answers);
  const canProceedAnyway = canProceedDespiteFinding(justification, acknowledged);

  // Segunda checagem automática de IA ("advogado do diabo" — ver
  // src/lib/adversarialRiskCheck.ts): dispara quando o profissional está a
  // ponto de poder confirmar "prosseguir mesmo assim" (mesma condição do
  // botão abaixo), nunca antes disso — evita chamar a IA a cada tecla
  // digitada na justificativa (ver comentário em AdversarialRiskCheck.tsx).
  const adversarialRequest: AdversarialRiskCheckRequest | null = useMemo(() => {
    if (!suspicious) return null;
    // Sem `patientId` a edge function não consegue checar o consentimento do
    // paciente (gate do squad w1-3, ver
    // supabase/functions/_shared/consentGate.ts) e recusaria a chamada — não
    // adianta disparar. Enquanto a sessão ainda está carregando, a segunda
    // opinião simplesmente não aparece, o que já é o comportamento desta
    // tela para qualquer indisponibilidade.
    if (!patientId) return null;
    return {
      type: 'skin_screening',
      patientId,
      skinScreening: {
        positiveCriteria: SKIN_SCREENING_CRITERION_KEYS.filter((key) => answers[key] === true),
        lesionLocation: lesionLocation.trim() || null,
        notes: notes.trim() || null,
        justification: justification.trim(),
      },
    };
  }, [suspicious, patientId, answers, lesionLocation, notes, justification]);

  const setAnswer = (key: SkinScreeningCriterionKey, value: boolean) => {
    setAnswers((prev) => ({ ...prev, [key]: value }));
    // Responder "Não observado" a um critério que tinha gerado achado
    // suspeito invalida um reconhecimento já dado pra esse achado antigo —
    // o profissional precisa confirmar de novo se o quadro mudar.
    setAcknowledged(false);
  };

  const saveScreening = async (opts: {
    referredToDermatology: boolean;
    proceededDespiteFinding: boolean;
  }) => {
    if (!id || !user || !patientId) return false;
    setSaving(true);
    const { error } = await supabase.from('skin_screenings').upsert(
      {
        session_id: id,
        patient_id: patientId,
        professional_id: user.id,
        asymmetry: !!answers.asymmetry,
        irregular_borders: !!answers.irregularBorders,
        color_variation: !!answers.colorVariation,
        diameter_over_6mm: !!answers.diameterOver6mm,
        recent_evolution: !!answers.recentEvolution,
        has_suspicious_finding: suspicious,
        lesion_location: lesionLocation.trim() || null,
        notes: notes.trim() || null,
        referred_to_dermatology: opts.referredToDermatology,
        proceeded_despite_finding: opts.proceededDespiteFinding,
        proceed_justification: opts.proceededDespiteFinding ? justification.trim() : null,
      },
      { onConflict: 'session_id' }
    );
    setSaving(false);
    if (error) {
      toast.error(t('sessions.stage1.skinScreening.saveErrorToast'));
      return false;
    }
    return true;
  };

  const handleContinueNoFindings = async () => {
    const ok = await saveScreening({ referredToDermatology: false, proceededDespiteFinding: false });
    if (!ok || !id) return;
    await supabase.from('sessions').update({ status: 'stage2' }).eq('id', id);
    navigate(`/sessoes/${id}/estagio-2`);
  };

  const handleReferNotProceed = async () => {
    const ok = await saveScreening({ referredToDermatology: true, proceededDespiteFinding: false });
    if (!ok) return;
    toast.success(t('sessions.stage1.skinScreening.referredToast'));
    navigate('/sessoes');
  };

  const handleProceedDespiteFinding = async () => {
    if (!canProceedAnyway || !id) return;
    const ok = await saveScreening({ referredToDermatology: false, proceededDespiteFinding: true });
    if (!ok) return;
    await supabase.from('sessions').update({ status: 'stage2' }).eq('id', id);
    navigate(`/sessoes/${id}/estagio-2`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-h-bg">
        <TopBar title={t('sessions.stage1.skinScreening.title')} showBack />
        <div className="pt-[56px] p-5 flex flex-col gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-h-white rounded-r shadow-h-sm h-[90px] animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-h-bg pb-32">
        <TopBar
          title={t('sessions.stage1.skinScreening.title')}
          showBack
          onBack={() => navigate(`/sessoes/${id}/estagio-1`)}
          rightAction={
            patientName ? <HarmonizeBadge variant="grad">{patientName.split(' ')[0]}</HarmonizeBadge> : undefined
          }
        />
        <div className="pt-[56px] max-w-[430px] md:max-w-[560px] mx-auto w-full">
          <div className="px-5 py-4 flex justify-center">
            <StageDots currentStage={1} activeColor="#BF5F82" />
          </div>

          <div className="px-5 flex flex-col gap-4">
            {/* Explainer */}
            <div className="bg-h-white rounded-r shadow-h-sm p-5">
              <p className="text-[15px] font-bold text-h-text mb-1">
                {t('sessions.stage1.skinScreening.explainerTitle')}
              </p>
              <p className="text-[12px] text-h-text-2 leading-relaxed">
                {t('sessions.stage1.skinScreening.explainerBody', {
                  procedure: procedureName || t('sessions.stage1.skinScreening.genericProcedure'),
                })}
              </p>
            </div>

            {/* Triagem anterior desta sessão. Fica antes dos critérios de
                propósito: é a informação que impede alguém de refazer a
                triagem sem saber que já houve um achado. */}
            {previousScreening && (
              <div
                className="rounded-r p-5 flex gap-3"
                style={{
                  background: previousScreening.hasSuspiciousFinding ? '#FDF0F0' : '#F4F1EC',
                  border: `1px solid ${previousScreening.hasSuspiciousFinding ? '#E05050' : '#DAD5CE'}`,
                }}
              >
                <ShieldAlert
                  size={18}
                  style={{ color: previousScreening.hasSuspiciousFinding ? '#E05050' : '#8A857E' }}
                  className="shrink-0 mt-[2px]"
                />
                <div className="flex flex-col gap-1">
                  <p className="text-[13px] font-bold text-h-text">
                    {t('sessions.stage1.skinScreening.previousTitle')}
                  </p>
                  <p className="text-[12px] text-h-text-2 leading-relaxed">
                    {t(
                      previousScreening.referredToDermatology
                        ? 'sessions.stage1.skinScreening.previousReferred'
                        : previousScreening.proceededDespiteFinding
                          ? 'sessions.stage1.skinScreening.previousProceeded'
                          : 'sessions.stage1.skinScreening.previousNoFindings',
                      { date: new Date(previousScreening.recordedAt).toLocaleDateString(i18n.language) }
                    )}
                  </p>
                  <p className="text-[12px] text-h-text-3 leading-relaxed">
                    {t('sessions.stage1.skinScreening.previousOverwriteWarning')}
                  </p>
                </div>
              </div>
            )}

            {/* Criteria list */}
            <div className="bg-h-white rounded-r shadow-h-sm p-1">
              {SKIN_SCREENING_CRITERIA.map((c, i) => {
                const value = answers[c.key];
                const title = t(`sessions.stage1.skinScreening.criteria.${c.key}.title`);
                const description = t(`sessions.stage1.skinScreening.criteria.${c.key}.description`);
                return (
                  <div
                    key={c.key}
                    className="p-4 flex flex-col gap-2"
                    style={i > 0 ? { borderTop: '0.5px solid rgba(0,0,0,0.06)' } : {}}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-[12px] font-extrabold flex-shrink-0"
                        style={{ background: 'rgba(168,85,181,0.10)', color: '#A855B5' }}
                      >
                        {c.letter}
                      </div>
                      <div className="flex-1">
                        <p className="text-[13px] font-bold text-h-text">{title}</p>
                        <p className="text-[11px] text-h-text-3 leading-snug mt-0.5">{description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pl-10" role="radiogroup" aria-label={title}>
                      <button
                        type="button"
                        role="radio"
                        aria-checked={value === false}
                        onClick={() => setAnswer(c.key, false)}
                        className="px-4 py-1.5 rounded-full text-[12px] font-bold transition-all min-h-[32px]"
                        style={
                          value === false
                            ? { background: 'rgba(45,184,122,0.10)', color: '#2DB87A' }
                            : { background: '#F5F4F2', color: '#AAA8A5' }
                        }
                      >
                        {t('sessions.stage1.skinScreening.answerNotPresent')}
                      </button>
                      <button
                        type="button"
                        role="radio"
                        aria-checked={value === true}
                        onClick={() => setAnswer(c.key, true)}
                        className="px-4 py-1.5 rounded-full text-[12px] font-bold transition-all min-h-[32px]"
                        style={
                          value === true
                            ? { background: 'rgba(224,80,80,0.10)', color: '#E05050' }
                            : { background: '#F5F4F2', color: '#AAA8A5' }
                        }
                      >
                        {t('sessions.stage1.skinScreening.answerPresent')}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Optional context fields */}
            <div className="bg-h-white rounded-r shadow-h-sm p-4 flex flex-col gap-3">
              <div>
                <label className="text-[12px] font-semibold text-h-text-2 mb-1 block">
                  {t('sessions.stage1.skinScreening.lesionLocationLabel')}
                </label>
                <input
                  type="text"
                  value={lesionLocation}
                  onChange={(e) => setLesionLocation(e.target.value)}
                  placeholder={t('sessions.stage1.skinScreening.lesionLocationPlaceholder')}
                  className="w-full bg-h-surface rounded-sm px-3 py-2 text-[13px] text-h-text outline-none placeholder:text-h-text-3"
                />
              </div>
              <div>
                <label className="text-[12px] font-semibold text-h-text-2 mb-1 block">
                  {t('sessions.stage1.skinScreening.notesLabel')}
                </label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={t('sessions.stage1.skinScreening.notesPlaceholder')}
                  className="text-[13px] bg-h-surface border-none"
                />
              </div>
            </div>

            {!complete && (
              <div className="flex items-center gap-2 px-1">
                <AlertTriangle size={14} className="text-h-text-3 flex-shrink-0" />
                <p className="text-[11px] text-h-text-3">
                  {t('sessions.stage1.skinScreening.incompleteHint')}
                </p>
              </div>
            )}

            {complete && !suspicious && (
              <div
                className="rounded-r p-4"
                style={{ background: 'rgba(45,184,122,0.08)', border: '1px solid rgba(45,184,122,0.25)' }}
              >
                <p className="text-[12px] font-semibold text-h-text leading-relaxed">
                  {t('sessions.stage1.skinScreening.noFindingsMessage')}
                </p>
              </div>
            )}

            {complete && suspicious && (
              <div
                className="rounded-r p-4 flex flex-col gap-3"
                style={{ background: 'rgba(224,80,80,0.06)', border: '1px solid rgba(224,80,80,0.30)' }}
              >
                <div className="flex items-start gap-2">
                  <ShieldAlert size={18} className="flex-shrink-0" style={{ color: '#E05050' }} />
                  <div>
                    <p className="text-[13px] font-bold" style={{ color: '#E05050' }}>
                      {t('sessions.stage1.skinScreening.suspiciousTitle')}
                    </p>
                    <p className="text-[12px] text-h-text-2 leading-relaxed mt-1">
                      {t('sessions.stage1.skinScreening.suspiciousBody')}
                    </p>
                  </div>
                </div>

                <SecondaryButton onClick={handleReferNotProceed} disabled={saving}>
                  {t('sessions.stage1.skinScreening.referButton')}
                </SecondaryButton>

                <div className="pt-2" style={{ borderTop: '0.5px solid rgba(224,80,80,0.20)' }}>
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <Checkbox
                      checked={acknowledged}
                      onCheckedChange={(v) => setAcknowledged(v === true)}
                      className="mt-0.5"
                    />
                    <span className="text-[11px] text-h-text-2 leading-snug">
                      {t('sessions.stage1.skinScreening.acknowledgeLabel')}
                    </span>
                  </label>
                  <Textarea
                    value={justification}
                    onChange={(e) => setJustification(e.target.value)}
                    placeholder={t('sessions.stage1.skinScreening.justificationPlaceholder')}
                    className="text-[13px] bg-h-white border-none mt-2"
                    disabled={!acknowledged}
                  />
                  <div className="mt-2">
                    <AdversarialRiskCheck active={canProceedAnyway} request={adversarialRequest} />
                  </div>
                  <div className="mt-2">
                    <GradientButton onClick={handleProceedDespiteFinding} disabled={!canProceedAnyway || saving}>
                      {t('sessions.stage1.skinScreening.proceedAnywayButton')}
                    </GradientButton>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {complete && !suspicious && (
          <div className="fixed bottom-0 left-0 right-0 p-5 bg-h-bg" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
            <div className="max-w-[430px] md:max-w-[560px] mx-auto">
              <GradientButton onClick={handleContinueNoFindings} disabled={saving}>
                {t('sessions.stage1.skinScreening.continueButton')}
              </GradientButton>
            </div>
          </div>
        )}
      </div>
    </PageTransition>
  );
};

export default SessaoTriagemPele;
