import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

/**
 * Regressão do ciclo 71 do QA Contínuo.
 *
 * `/reset-password` decidia entre "digite a nova senha" e "link inválido"
 * lendo `window.location.hash` dentro de um efeito. O supabase-js apaga esse
 * hash sozinho, mas só depois de validar o token contra `/auth/v1/user` —
 * ou seja, depois de uma ida à rede. Quem ganhava a corrida decidia a tela:
 * em rede rápida o hash já tinha sumido quando o componente montava e o
 * profissional via "link inválido" para um link válido, nunca usado, dentro
 * da validade. O desfecho CORRETO dependia da rede estar lenta.
 *
 * Isso acontece no único caminho que um profissional tem para recuperar a
 * própria conta, e a mensagem errada é indistinguível de um link realmente
 * expirado — pedir outro link não ajuda, porque o novo corre a mesma
 * corrida.
 */

const onAuthStateChange = vi.fn(() => ({
  data: { subscription: { unsubscribe: vi.fn() } },
}));
const getSession = vi.fn(async () => ({ data: { session: null }, error: null }));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    auth: {
      onAuthStateChange: (...args: unknown[]) => onAuthStateChange(...(args as [])),
      getSession: () => getSession(),
      updateUser: vi.fn(),
    },
  },
}));

vi.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));

vi.mock('sonner', () => ({ toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() } }));

const RECOVERY_HASH = '#access_token=abc123&expires_in=3600&refresh_token=r1&token_type=bearer&type=recovery';

/** Importa a tela com o hash que o app tinha no carregamento. */
async function renderComHashInicial(hashNoBoot: string, hashAgora: string) {
  window.location.hash = hashNoBoot;
  vi.resetModules();
  // A captura acontece na avaliação do módulo, como no boot real.
  await import('@/lib/initialUrlHash');
  window.location.hash = hashAgora;
  const { default: ResetPassword } = await import('./ResetPassword');
  return render(
    <MemoryRouter>
      <ResetPassword />
    </MemoryRouter>
  );
}

describe('ResetPassword', () => {
  beforeEach(() => {
    onAuthStateChange.mockClear();
    getSession.mockClear();
  });

  afterEach(() => {
    window.location.hash = '';
  });

  it('abre o formulário mesmo quando o supabase-js já apagou o hash', async () => {
    // O caso do bug: hash de recuperação no boot, hash já limpo quando a
    // tela monta (rede rápida).
    await renderComHashInicial(RECOVERY_HASH, '');

    await waitFor(() =>
      expect(screen.getByText('auth.resetPassword.title')).toBeInTheDocument()
    );
    expect(screen.queryByText('auth.resetPassword.linkInvalid.title')).not.toBeInTheDocument();
  });

  it('abre o formulário quando o hash ainda está na URL', async () => {
    // Rede lenta: o comportamento que já funcionava continua funcionando.
    await renderComHashInicial(RECOVERY_HASH, RECOVERY_HASH);

    await waitFor(() =>
      expect(screen.getByText('auth.resetPassword.title')).toBeInTheDocument()
    );
  });

  it('diz que o link é inválido quando o Supabase devolve erro no hash', async () => {
    // Link expirado ou já usado: decisão imediata, sem esperar rede.
    await renderComHashInicial('#error=access_denied&error_code=otp_expired', '');

    await waitFor(() =>
      expect(screen.getByText('auth.resetPassword.linkInvalid.title')).toBeInTheDocument()
    );
  });

  it('diz que o link é inválido quando a página é aberta sem link nenhum', async () => {
    await renderComHashInicial('', '');

    await waitFor(() =>
      expect(screen.getByText('auth.resetPassword.linkInvalid.title')).toBeInTheDocument()
    );
  });

  it('abre o formulário quando o evento PASSWORD_RECOVERY chega sem hash', async () => {
    // O supabase-js consumiu o link antes desta tela montar e emitiu o
    // evento: é sinal de recuperação tão bom quanto o hash.
    let emitir: ((event: string) => void) | null = null;
    onAuthStateChange.mockImplementationOnce(((cb: (event: string) => void) => {
      emitir = cb;
      return { data: { subscription: { unsubscribe: vi.fn() } } };
    }) as never);
    // Segura o getSession para o evento chegar primeiro, como na ordem real
    // (o evento é emitido durante a inicialização, que getSession espera).
    getSession.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          setTimeout(() => resolve({ data: { session: null }, error: null }), 0);
        }) as ReturnType<typeof getSession>
    );

    await renderComHashInicial('', '');
    emitir?.('PASSWORD_RECOVERY');

    await waitFor(() =>
      expect(screen.getByText('auth.resetPassword.title')).toBeInTheDocument()
    );
  });
});

// ── Regressão do ciclo 72 do QA Contínuo ────────────────────────────────
//
// Em produção o valor vem do script inline do index.html, não de um módulo
// avaliado no boot. Este caso reproduz esse formato: o global preenchido, a
// URL já sem o hash (o supabase-js apagou), e a tela tem que abrir o
// formulário mesmo assim.
describe('ResetPassword — captura vinda do index.html', () => {
  afterEach(() => {
    delete (window as { __facialplanInitialHash?: string }).__facialplanInitialHash;
    window.location.hash = '';
  });

  it('usa o hash guardado pelo script inline quando a URL já foi limpa', async () => {
    window.location.hash = '';
    (window as { __facialplanInitialHash?: string }).__facialplanInitialHash = RECOVERY_HASH;
    vi.resetModules();
    await import('@/lib/initialUrlHash');
    const { default: ResetPassword } = await import('./ResetPassword');

    render(
      <MemoryRouter>
        <ResetPassword />
      </MemoryRouter>
    );

    await waitFor(() =>
      expect(screen.getByText('auth.resetPassword.title')).toBeInTheDocument()
    );
  });
});
