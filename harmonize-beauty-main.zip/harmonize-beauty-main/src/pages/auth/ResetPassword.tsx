import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { translateAuthError } from '@/lib/authErrorMessage';
import { INITIAL_URL_HASH, isAuthErrorHash, isRecoveryHash } from '@/lib/initialUrlHash';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import AuthInput from '@/components/harmonize/AuthInput';
import { toast } from 'sonner';

const ResetPassword: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);
  const [linkInvalid, setLinkInvalid] = useState(false);

  useEffect(() => {
    // O hash é lido do instante do carregamento do app (INITIAL_URL_HASH),
    // com o valor atual como reforço. O supabase-js apaga
    // `window.location.hash` assim que termina de validar o token contra
    // `/auth/v1/user`, então ler só o valor atual aqui é disputar uma
    // corrida com ele — e perder essa corrida significa dizer "link
    // inválido" para um link válido, no único fluxo que um profissional tem
    // para recuperar a própria conta. Ver src/lib/initialUrlHash.ts.
    const hash = window.location.hash || INITIAL_URL_HASH;

    // Só o hash de recuperação válido (#access_token=...&type=recovery)
    // deixa a tela pronta pra digitar a nova senha.
    if (isRecoveryHash(hash)) {
      setReady(true);
      return;
    }
    // Link expirado ou já usado: o Supabase manda #error=access_denied&...
    // Decisão imediata, sem esperar nada.
    if (isAuthErrorHash(hash)) {
      setLinkInvalid(true);
      return;
    }

    // Sem hash nenhum. Ainda assim não decidimos na hora: se o evento de
    // recuperação chegar (o supabase-js consumiu o link antes desta tela
    // montar), a tela abre o formulário. `getSession()` só resolve depois
    // que a inicialização do client termina, então é o ponto certo para
    // concluir "não há recuperação nenhuma aqui" — em vez de concluir isso
    // enquanto o token ainda está sendo validado.
    let cancelled = false;
    let recuperacaoVista = false;
    const { data: authSub } = supabase.auth.onAuthStateChange((event) => {
      if (cancelled) return;
      if (event === 'PASSWORD_RECOVERY') {
        recuperacaoVista = true;
        setReady(true);
      }
    });
    void supabase.auth.getSession().then(() => {
      // Uma sessão comum não vale: quem abriu /reset-password logado, sem
      // link de recuperação, continua vendo "link inválido" como antes.
      // Trocar a senha nesse caso seria outra decisão de produto.
      if (!cancelled && !recuperacaoVista) setLinkInvalid(true);
    });

    return () => {
      cancelled = true;
      authSub.subscription.unsubscribe();
    };
  }, []);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return; // evita disparo duplicado em duplo clique/duplo submit
    if (password.length < 6) { toast.error(t('auth.resetPassword.errors.tooShort')); return; }
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      toast.success(t('auth.resetPassword.success'));
      navigate('/inicio');
    } catch (err: any) {
      toast.error(translateAuthError(err, t, 'auth.resetPassword.errors.generic'));
    } finally {
      setLoading(false);
    }
  };

  if (linkInvalid) {
    return (
      <div className="min-h-screen bg-h-bg flex items-center justify-center">
        <div className="w-full max-w-[430px] px-6 flex flex-col items-center text-center gap-3">
          <LogoMark size={48} />
          <h1 className="text-[20px] font-extrabold text-h-text mt-2">{t('auth.resetPassword.linkInvalid.title')}</h1>
          <p className="text-h-text-2 text-[14px]">
            {t('auth.resetPassword.linkInvalid.message')}
          </p>
          <Link to="/auth/reset-senha" className="text-h-g-start font-semibold text-[14px] mt-2">
            {t('auth.resetPassword.linkInvalid.cta')}
          </Link>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="min-h-screen bg-h-bg flex items-center justify-center">
        <p className="text-h-text-2">{t('auth.resetPassword.loading')}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-16">
      <div className="w-full max-w-[430px] px-6">
        <div className="flex flex-col items-center mb-8">
          <LogoMark size={64} />
          <h1 className="text-[28px] font-extrabold text-h-text mt-3">{t('auth.resetPassword.title')}</h1>
        </div>
        <form onSubmit={handleUpdate} className="flex flex-col gap-4">
          <AuthInput label={t('auth.resetPassword.newPasswordLabel')} type="password" placeholder={t('auth.resetPassword.newPasswordPlaceholder')} value={password} onChange={(e) => setPassword(e.target.value)} />
          <GradientButton type="submit" disabled={loading}>
            {loading ? t('auth.resetPassword.submitting') : t('auth.resetPassword.submit')}
          </GradientButton>
        </form>
      </div>
    </div>
  );
};

export default ResetPassword;
