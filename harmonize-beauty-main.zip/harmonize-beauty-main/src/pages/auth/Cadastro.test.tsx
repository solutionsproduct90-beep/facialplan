import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import Cadastro from "./Cadastro";
import i18n from "@/i18n";
import { PRIVACY_VERSION, TERMS_VERSION } from "@/lib/legalDocs";

// Guardas do achado bloqueador do squad w1-4: o cadastro criava conta sem
// nenhum registro de aceite dos Termos de Uso / Política de Privacidade.
// Num produto que processa foto de rosto e dado de saúde dos PACIENTES do
// assinante, é o aceite que estabelece o profissional como controlador e o
// FacialPlan como operador — sem ele não há base contratual nenhuma.

const signUpSpy = vi.fn();
const invokeSpy = vi.fn();
const navigateMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({ user: null, loading: false }),
}));

vi.mock("sonner", () => ({
  toast: {
    success: () => {},
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

// AuthSelect abre um BottomSheet (vaul/Radix Dialog), que marca o resto do
// documento como aria-hidden enquanto está aberto e não termina a animação
// de fechamento no jsdom — ou seja, depois de escolher a especialidade o
// checkbox e o botão de enviar ficam inalcançáveis pelas queries por role.
// Aqui ele vira um <select> nativo: o alvo destes testes é a trava de
// aceite, não o componente de seleção (que tem cobertura própria).
vi.mock("@/components/harmonize/AuthSelect", () => ({
  default: ({
    label,
    options,
    value,
    onChange,
  }: {
    label: string;
    options: { value: string; label: string }[];
    value: string;
    onChange: (val: string) => void;
  }) => (
    <select aria-label={label} value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">—</option>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  ),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      signUp: (...args: unknown[]) => signUpSpy(...args),
    },
    functions: {
      invoke: (...args: unknown[]) => invokeSpy(...args),
    },
  },
}));

function fillRequiredFields() {
  fireEvent.change(screen.getByPlaceholderText(i18n.t("auth.cadastro.fullNamePlaceholder")), {
    target: { value: "Dra. Ana Souza" },
  });
  fireEvent.change(screen.getByPlaceholderText(i18n.t("auth.cadastro.emailPlaceholder")), {
    target: { value: "ana@clinica.com" },
  });
  fireEvent.change(screen.getByPlaceholderText(i18n.t("auth.cadastro.passwordPlaceholder")), {
    target: { value: "senha123" },
  });
  fireEvent.change(screen.getByRole("combobox"), { target: { value: "Médico" } });
}

function renderCadastro() {
  return render(
    <MemoryRouter initialEntries={["/auth/cadastro"]}>
      <Cadastro />
    </MemoryRouter>
  );
}

describe("Cadastro — aceite de Termos de Uso e Política de Privacidade", () => {
  beforeEach(async () => {
    vi.clearAllMocks();
    await i18n.changeLanguage("pt");
    signUpSpy.mockResolvedValue({ data: { user: { id: "u1", identities: [{ id: "i1" }] } }, error: null });
    invokeSpy.mockResolvedValue({ data: { ok: true }, error: null });
  });

  it("o checkbox de aceite nunca vem pré-marcado", () => {
    renderCadastro();
    expect(screen.getByRole("checkbox")).not.toBeChecked();
  });

  it("bloqueia o cadastro quando o aceite não foi marcado (nenhuma conta é criada)", async () => {
    renderCadastro();
    fillRequiredFields();

    fireEvent.click(screen.getByRole("button", { name: i18n.t("auth.cadastro.submit") }));

    await waitFor(() => {
      expect(toastErrorMock).toHaveBeenCalledWith(i18n.t("auth.cadastro.errors.termsRequired"));
    });
    expect(signUpSpy).not.toHaveBeenCalled();
    expect(navigateMock).not.toHaveBeenCalled();
    // Mensagem visível ao lado do checkbox, não só o toast que some.
    expect(screen.getByRole("alert")).toHaveTextContent(i18n.t("auth.cadastro.errors.termsRequired"));
  });

  it("com o aceite marcado, envia a versão dos dois documentos no signUp", async () => {
    renderCadastro();
    fillRequiredFields();
    fireEvent.click(screen.getByRole("checkbox"));

    fireEvent.click(screen.getByRole("button", { name: i18n.t("auth.cadastro.submit") }));

    await waitFor(() => expect(signUpSpy).toHaveBeenCalledTimes(1));
    const payload = signUpSpy.mock.calls[0][0] as {
      options: { data: Record<string, string> };
    };
    expect(payload.options.data.terms_version).toBe(TERMS_VERSION);
    expect(payload.options.data.privacy_version).toBe(PRIVACY_VERSION);
    // O token liga esta conta à linha que a edge function já gravou com o IP
    // real — sem ele o aceite existiria, mas sem evidência de origem.
    expect(payload.options.data.terms_claim_token).toBeTruthy();
    expect(navigateMock).toHaveBeenCalledWith("/auth/verificar", { state: { email: "ana@clinica.com" } });
  });

  it("registra o aceite no servidor (com IP real) ANTES de criar a conta", async () => {
    const order: string[] = [];
    invokeSpy.mockImplementation((name: string) => {
      order.push(`invoke:${name}`);
      return Promise.resolve({ data: { ok: true }, error: null });
    });
    signUpSpy.mockImplementation(() => {
      order.push("signUp");
      return Promise.resolve({ data: { user: { id: "u1", identities: [{ id: "i1" }] } }, error: null });
    });

    renderCadastro();
    fillRequiredFields();
    fireEvent.click(screen.getByRole("checkbox"));
    fireEvent.click(screen.getByRole("button", { name: i18n.t("auth.cadastro.submit") }));

    await waitFor(() => expect(signUpSpy).toHaveBeenCalled());
    expect(order).toEqual(["invoke:record-terms-acceptance", "signUp"]);
  });

  it("regressão: falha da edge function de aceite não pode impedir o cadastro", async () => {
    invokeSpy.mockResolvedValue({ data: null, error: { message: "boom" } });

    renderCadastro();
    fillRequiredFields();
    fireEvent.click(screen.getByRole("checkbox"));
    fireEvent.click(screen.getByRole("button", { name: i18n.t("auth.cadastro.submit") }));

    await waitFor(() => expect(signUpSpy).toHaveBeenCalledTimes(1));
    const payload = signUpSpy.mock.calls[0][0] as { options: { data: Record<string, string> } };
    // Sem token (a linha com IP não existe), mas COM as versões: é o que
    // permite ao trigger handle_new_user gravar o aceite no fallback
    // `cadastro_sem_ip` em vez de não gravar nada.
    expect(payload.options.data.terms_claim_token).toBeUndefined();
    expect(payload.options.data.terms_version).toBe(TERMS_VERSION);
    expect(payload.options.data.privacy_version).toBe(PRIVACY_VERSION);
  });
});
