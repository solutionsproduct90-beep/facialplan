import React, { useEffect, useRef, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useLocation, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import LogoMark from '@/components/harmonize/LogoMark';
import { Mail } from 'lucide-react';
import GhostButton from '@/components/harmonize/GhostButton';
import { supabase } from '@/integrations/supabase/client';
import { translateAuthError } from '@/lib/authErrorMessage';
import { toast } from 'sonner';

// Mesmo intervalo mínimo que o Supabase Auth já aplica no reenvio de e-mail
// de confirmação — o cooldown aqui é só uma trava visual pra não deixar a
// pessoa martelar o botão e esbarrar direto no rate-limit do servidor.
const RESEND_COOLDOWN_SECONDS = 60;

const Verificar: React.FC = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const email = (location.state as any)?.email as string | undefined;
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const startCooldown = () => {
    setCooldown(RESEND_COOLDOWN_SECONDS);
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setCooldown((prev) => {
        if (prev <= 1) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleResend = async () => {
    if (resending || cooldown > 0) return; // evita spam de clique/duplo clique
    if (!email) {
      // Chegou nesta tela sem vir do cadastro (ex: recarregou a página
      // direto) — não temos o e-mail para reenviar, então manda a pessoa
      // de volta para o cadastro em vez de chamar a API sem endereço.
      toast.error(t('auth.verificar.errors.missingEmail'));
      return;
    }
    setResending(true);
    try {
      const { error } = await supabase.auth.resend({ type: 'signup', email });
      if (error) throw error;
      toast.success(t('auth.verificar.success'));
    } catch (err: any) {
      toast.error(translateAuthError(err, t, 'auth.verificar.errors.generic'));
    } finally {
      setResending(false);
      // Cooldown roda mesmo quando o pedido falhou (ex.: já bateu no rate
      // limit do servidor) — não faz sentido liberar o botão na hora e
      // deixar a pessoa martelar de novo.
      startCooldown();
    }
  };

  return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-16">
      <div className="w-full max-w-[430px] px-6">
        <div className="flex flex-col items-center mb-6">
          <div className="flex items-center gap-2 mb-4">
            <LogoMark size={32} />
            <span className="text-[18px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>FacialPlan</span>
          </div>
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
            style={{ backgroundColor: 'rgba(168,85,181,0.08)' }}
          >
            <Mail size={28} style={{ color: '#A855B5' }} />
          </div>
          <h1 className="text-[24px] font-extrabold text-h-text mb-2" style={{ letterSpacing: '-0.02em' }}>
            {t('auth.verificar.title')}
          </h1>
          <p className="text-[15px] text-h-text-2 text-center">
            {t('auth.verificar.sentTo')}<br />
            <strong className="text-h-text">{email || t('auth.verificar.fallbackEmail')}</strong>
          </p>
        </div>
        <GhostButton onClick={handleResend} disabled={resending || cooldown > 0}>
          {resending
            ? t('auth.verificar.resending')
            : cooldown > 0
              ? t('auth.verificar.resendCooldown', { seconds: cooldown })
              : t('auth.verificar.resend')}
        </GhostButton>
        <Link to="/auth/login" className="block text-[14px] text-h-text-2 mt-4 text-center">
          ← {t('auth.verificar.backToLogin')}
        </Link>
      </div>
    </div>
    </PageTransition>
  );
};

export default Verificar;
