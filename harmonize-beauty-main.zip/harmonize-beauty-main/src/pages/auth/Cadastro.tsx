import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { translateAuthError } from '@/lib/authErrorMessage';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import AuthInput from '@/components/harmonize/AuthInput';
import AuthSelect from '@/components/harmonize/AuthSelect';
import { buildTermsAcceptanceMetadata, recordTermsAcceptance } from '@/lib/termsAcceptance';
import { toast } from 'sonner';

const Cadastro: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, loading: authLoading } = useAuth();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [loading, setLoading] = useState(false);
  // Aceite dos Termos de Uso e da Política de Privacidade (squad w1-4).
  // Começa SEMPRE desmarcado: aceite pré-marcado não é aceite — é presunção,
  // e num produto que processa foto de rosto e dado de saúde de terceiros
  // (os pacientes do profissional) a validade desse aceite é justamente o
  // que define quem é controlador e quem é operador.
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  // Erro inline em vez de só o toast: o toast some e some longe do checkbox,
  // e a pessoa que errou aqui precisa enxergar ONDE errou.
  const [termsError, setTermsError] = useState(false);

  // Mesma lógica do Login: quem já está autenticado não deve ver o
  // formulário de cadastro (ex.: voltou pelo histórico do navegador depois
  // de já estar logado).
  useEffect(() => {
    if (!authLoading && user) {
      navigate('/inicio', { replace: true });
    }
  }, [authLoading, user, navigate]);

  // Specialty values stay in Portuguese (stored as-is in the database);
  // only the label shown to the user is translated.
  const specialties = [
    { value: 'Médico', label: t('auth.cadastro.specialties.doctor') },
    { value: 'Dentista', label: t('auth.cadastro.specialties.dentist') },
    { value: 'Biomédico', label: t('auth.cadastro.specialties.biomedical') },
    { value: 'Enfermeiro', label: t('auth.cadastro.specialties.nurse') },
  ];

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return; // evita disparo duplicado em duplo clique/duplo submit
    if (!fullName || !email || !password || !specialty) {
      toast.error(t('auth.cadastro.errors.fillAllFields'));
      return;
    }
    // Trava de aceite. Fica DEPOIS da validação de campos vazios de
    // propósito: quem chegou aqui com o formulário em branco recebe primeiro
    // a mensagem genérica, e não uma cobrança de aceite que soa arbitrária.
    if (!acceptedTerms) {
      setTermsError(true);
      toast.error(t('auth.cadastro.errors.termsRequired'));
      return;
    }
    setLoading(true);
    try {
      // Registra o aceite no servidor ANTES de criar a conta — é a única
      // janela em que dá para carimbar o IP real (ver src/lib/termsAcceptance
      // .ts). Devolve null se a edge function falhar, e nesse caso o cadastro
      // segue mesmo assim: o trigger handle_new_user grava o aceite sem IP.
      const claimToken = await recordTermsAcceptance();

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            specialty,
            ...buildTermsAcceptanceMetadata(claimToken),
          },
          emailRedirectTo: window.location.origin,
        },
      });
      if (error) throw error;
      // Quando o e-mail já pertence a uma conta confirmada, o Supabase Auth
      // não retorna erro (evita permitir descobrir contas existentes por
      // tentativa e erro) — em vez disso devolve um "usuário" cujo array
      // `identities` vem vazio. Sem esse check, a tela seguia direto para
      // "verifique seu e-mail" como se um link novo tivesse sido enviado,
      // e a pessoa nunca recebia e-mail nenhum.
      if (data.user && data.user.identities && data.user.identities.length === 0) {
        toast.error(t('auth.cadastro.errors.emailInUse'));
        return;
      }
      navigate('/auth/verificar', { state: { email } });
    } catch (err: any) {
      toast.error(translateAuthError(err, t, 'auth.cadastro.errors.generic'));
    } finally {
      setLoading(false);
    }
  };

  // Evita um flash do formulário de cadastro no frame em que `user` já veio
  // preenchido mas o `navigate('/inicio')` do efeito acima ainda não comitou.
  if (user) {
    return null;
  }

  return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-12">
      <div className="w-full max-w-[430px] px-6">
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-2.5 mb-3">
            <LogoMark size={36} />
            <span style={{ fontSize: 20, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
              FacialPlan
            </span>
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.025em' }}>
            {t('auth.cadastro.title')}
          </h1>
          <p style={{ fontSize: 14, fontWeight: 400, color: '#AAA8A5', marginTop: 4 }}>
            {t('auth.cadastro.subtitle')}
          </p>
        </div>

        <form onSubmit={handleSignUp} className="flex flex-col gap-4">
          <AuthInput label={t('auth.cadastro.fullNameLabel')} placeholder={t('auth.cadastro.fullNamePlaceholder')} value={fullName} onChange={(e) => setFullName(e.target.value)} />
          <AuthInput label={t('auth.cadastro.emailLabel')} type="email" placeholder={t('auth.cadastro.emailPlaceholder')} value={email} onChange={(e) => setEmail(e.target.value)} />
          <AuthInput label={t('auth.cadastro.passwordLabel')} type="password" placeholder={t('auth.cadastro.passwordPlaceholder')} value={password} onChange={(e) => setPassword(e.target.value)} />
          <AuthSelect label={t('auth.cadastro.specialtyLabel')} options={specialties} value={specialty} onChange={(val) => setSpecialty(val)} />

          {/* Aceite obrigatório dos documentos legais. Os links abrem em aba
              nova (target="_blank") em vez de navegar: sair da tela levaria
              embora o formulário já preenchido, e o caminho de volta seria
              recomeçar o cadastro — motivo clássico de abandono. */}
          <div>
            <label
              className={`flex items-start gap-2.5 rounded-r-sm px-4 py-3 bg-h-white border cursor-pointer ${
                termsError ? 'border-h-red' : 'border-h-surface-3/40'
              }`}
            >
              <input
                type="checkbox"
                checked={acceptedTerms}
                onChange={(e) => {
                  setAcceptedTerms(e.target.checked);
                  if (e.target.checked) setTermsError(false);
                }}
                aria-invalid={termsError}
                aria-describedby={termsError ? 'terms-error' : undefined}
                className="mt-0.5 w-[18px] h-[18px] flex-shrink-0 accent-h-g-start"
              />
              <span className="text-[13px] text-h-text-2 leading-snug">
                {t('auth.cadastro.terms.prefix')}{' '}
                <Link to="/termos" target="_blank" rel="noopener noreferrer" className="text-h-g-start font-semibold underline">
                  {t('auth.cadastro.terms.termsLink')}
                </Link>{' '}
                {t('auth.cadastro.terms.middle')}{' '}
                <Link to="/privacidade" target="_blank" rel="noopener noreferrer" className="text-h-g-start font-semibold underline">
                  {t('auth.cadastro.terms.privacyLink')}
                </Link>{' '}
                {t('auth.cadastro.terms.suffix')}
              </span>
            </label>
            {termsError && (
              <p id="terms-error" role="alert" className="text-[12px] text-h-red mt-1.5 px-1">
                {t('auth.cadastro.errors.termsRequired')}
              </p>
            )}
          </div>

          <div className="mt-2">
            <GradientButton type="submit" disabled={loading}>
              {loading ? t('auth.cadastro.submitting') : t('auth.cadastro.submit')}
            </GradientButton>
          </div>
        </form>

        <p className="text-center text-[14px] text-h-text-2 mt-6">
          {t('auth.cadastro.hasAccount')}{' '}
          <Link to="/auth/login" className="text-h-g-start font-semibold">{t('auth.cadastro.login')}</Link>
        </p>
      </div>
    </div>
    </PageTransition>
  );
};

export default Cadastro;
