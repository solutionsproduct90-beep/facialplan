import React, { useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { translateAuthError } from '@/lib/authErrorMessage';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import AuthInput from '@/components/harmonize/AuthInput';
import { toast } from 'sonner';
import { CheckCircle } from 'lucide-react';

const ResetSenha: React.FC = () => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return; // evita disparo duplicado em duplo clique/duplo submit
    if (!email) { toast.error(t('auth.resetSenha.errors.fillEmail')); return; }
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      setSent(true);
    } catch (err: any) {
      // O Supabase também aplica rate-limit aqui (não só no reenvio de
      // confirmação de e-mail) — sem tradução, um segundo pedido rápido
      // mostrava "For security purposes, you can only request this after
      // N seconds." cru em inglês.
      toast.error(translateAuthError(err, t, 'auth.resetSenha.errors.generic'));
    } finally {
      setLoading(false);
    }
  };

    return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-16">
      <div className="w-full max-w-[430px] px-6">
        <div className="flex flex-col items-center mb-8">
          <LogoMark size={64} />
          <h1 className="text-[28px] font-extrabold text-h-text mt-3">{t('auth.resetSenha.title')}</h1>
        </div>

        {sent ? (
          <div className="flex flex-col items-center gap-3 text-center">
            <CheckCircle size={48} className="text-h-green" />
            <p className="text-[15px] text-h-text-2">
              {t('auth.resetSenha.sentMessage')} <strong className="text-h-text">{email}</strong>
            </p>
            <Link to="/auth/login" className="text-h-g-start font-semibold text-[14px] mt-4">
              {t('auth.resetSenha.backToLogin')}
            </Link>
          </div>
        ) : (
          <form onSubmit={handleReset} className="flex flex-col gap-4">
            <AuthInput label={t('auth.resetSenha.emailLabel')} type="email" placeholder={t('auth.resetSenha.emailPlaceholder')} value={email} onChange={(e) => setEmail(e.target.value)} />
            <GradientButton type="submit" disabled={loading}>
              {loading ? t('auth.resetSenha.submitting') : t('auth.resetSenha.submit')}
            </GradientButton>
            <Link to="/auth/login" className="text-center text-[14px] text-h-text-2">
              ← {t('auth.resetSenha.backToLogin')}
            </Link>
          </form>
        )}
      </div>
    </div>
    </PageTransition>
  );
};

export default ResetSenha;
