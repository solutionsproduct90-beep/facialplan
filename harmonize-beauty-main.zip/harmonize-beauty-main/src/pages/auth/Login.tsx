import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { translateAuthError } from '@/lib/authErrorMessage';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import AuthInput from '@/components/harmonize/AuthInput';
import { toast } from 'sonner';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, loading: authLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  // Quem já está autenticado (ex.: voltou pelo histórico do navegador, ou
  // ainda carrega uma sessão de recuperação de senha em andamento) não deve
  // ver o formulário de login — manda direto pra Home, que decide o resto
  // (bloqueado/inadimplente) via ProtectedRoute. Sem isso a pessoa logada
  // conseguia reenviar o form e disparar um signIn redundante.
  useEffect(() => {
    if (!authLoading && user) {
      navigate('/inicio', { replace: true });
    }
  }, [authLoading, user, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return; // evita disparo duplicado em duplo clique/duplo submit
    if (!email || !password) {
      toast.error(t('auth.login.errors.fillAllFields'));
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      navigate('/inicio');
    } catch (err: any) {
      toast.error(translateAuthError(err, t, 'auth.login.errors.generic'));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    });
    if (error) toast.error(translateAuthError(error, t, 'auth.login.errors.generic'));
  };

  // Evita um flash do formulário de login no frame em que `user` já veio
  // preenchido mas o `navigate('/inicio')` do efeito acima ainda não comitou.
  if (user) {
    return null;
  }

  return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-12">
      <div className="w-full max-w-[430px] px-6">
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-2.5 mb-3">
            <LogoMark size={36} />
            <span style={{ fontSize: 20, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
              FacialPlan
            </span>
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.025em' }}>
            {t('auth.login.title')}
          </h1>
          <p style={{ fontSize: 14, fontWeight: 400, color: '#AAA8A5', marginTop: 4 }}>
            {t('auth.login.subtitle')}
          </p>
        </div>

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <AuthInput label={t('auth.login.emailLabel')} type="email" placeholder={t('auth.login.emailPlaceholder')} value={email} onChange={(e) => setEmail(e.target.value)} />
          <AuthInput label={t('auth.login.passwordLabel')} type="password" placeholder={t('auth.login.passwordPlaceholder')} value={password} onChange={(e) => setPassword(e.target.value)} />

          <div className="flex justify-end">
            <Link to="/auth/reset-senha" className="text-[13px] text-h-g-start font-semibold">
              {t('auth.login.forgotPassword')}
            </Link>
          </div>

          <GradientButton type="submit" disabled={loading}>
            {loading ? t('auth.login.submitting') : t('auth.login.submit')}
          </GradientButton>
        </form>

        <div className="mt-4">
          <SecondaryButton onClick={handleGoogleLogin}>
            {t('auth.login.googleLogin')}
          </SecondaryButton>
        </div>

        <p className="text-center text-[14px] text-h-text-2 mt-6">
          {t('auth.login.noAccount')}{' '}
          <Link to="/auth/cadastro" className="text-h-g-start font-semibold">{t('auth.login.createAccount')}</Link>
        </p>
      </div>
    </div>
    </PageTransition>
  );
};

export default Login;
