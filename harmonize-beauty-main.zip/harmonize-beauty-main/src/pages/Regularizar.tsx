import React from 'react';
import { AlertTriangle, LogOut } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import GradientButton from '@/components/harmonize/GradientButton';
import GhostButton from '@/components/harmonize/GhostButton';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import RecuperarCompraHotmart from '@/components/harmonize/RecuperarCompraHotmart';

// Área de assinantes da Hotmart — o mesmo portal usado em Conta.tsx para
// gerenciar/cancelar a assinatura também é onde o profissional regulariza
// um pagamento em atraso. Configure VITE_HOTMART_MEMBER_PORTAL_URL no .env
// assim que o produto for criado.
const HOTMART_MEMBER_PORTAL_URL = import.meta.env.VITE_HOTMART_MEMBER_PORTAL_URL as string | undefined;

// Tela de destino quando subscription_status é 'past_due' | 'canceled' | 'refunded'
// (ProtectedRoute redireciona pra cá). Tem duas saídas: regularizar o
// pagamento no portal da Hotmart (ou suporte, se ainda não configurado) e
// deslogar — sem o logout o usuário ficava preso aqui.
const Regularizar: React.FC = () => {
  const { t } = useTranslation();
  const { signOut } = useAuth();

  const handleUpdatePayment = () => {
    if (HOTMART_MEMBER_PORTAL_URL) {
      window.open(HOTMART_MEMBER_PORTAL_URL, '_blank', 'noopener,noreferrer');
    } else {
      toast.info(t('account.pastDue.updatePaymentToast'));
    }
  };

  return (
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-20">
      <div className="w-full max-w-[430px] px-6">
        <div className="flex justify-center mb-5">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(217,119,6,0.08)' }}
          >
            <AlertTriangle size={26} style={{ color: '#D97706' }} />
          </div>
        </div>

        <div className="text-center mb-6">
          <h1 className="text-[24px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>
            {t('account.pastDue.title')}
          </h1>
          <p className="text-[14px] text-h-text-2 mt-2 leading-relaxed">
            {t('account.pastDue.message')}
          </p>
        </div>

        <div className="mb-3">
          <GradientButton onClick={handleUpdatePayment}>
            {t('account.pastDue.updatePayment')}
          </GradientButton>
        </div>

        <div className="mb-4">
          <GhostButton onClick={signOut}>
            <span className="flex items-center justify-center gap-2">
              <LogOut size={16} />
              {t('common.signOut')}
            </span>
          </GhostButton>
        </div>

        {/* Mesmo bloco de /assinar: aqui atende sobretudo quem regularizou o
            pagamento na Hotmart mas cujo postback de reativação se perdeu —
            continua vendo esta tela mesmo estando em dia. */}
        <RecuperarCompraHotmart />

        <a
          href="mailto:suporte@harmonize.app"
          className="block text-center"
          style={{ fontSize: 13, color: '#AAA8A5', textDecoration: 'none' }}
        >
          {t('account.pastDue.contactSupport')}
        </a>
      </div>
    </div>
  );
};

export default Regularizar;
