import React, { useState, useEffect } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import HeaderSaveButton from '@/components/harmonize/HeaderSaveButton';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { SUPPORTED_CURRENCIES, formatCurrency, type CurrencyCode } from '@/lib/budget';

/**
 * Precificação e condições de pagamento — taxa de mão de obra/sessão,
 * máximo de parcelas sem juros e desconto à vista. Antes vivia dentro de
 * Perfil.tsx; agora é sua própria tela (`/perfil/pagamento`), tudo gravado
 * em `profiles`.
 */
const PerfilPagamento: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [laborFeePerSession, setLaborFeePerSession] = useState<number | undefined>(undefined);
  const [maxInstallments, setMaxInstallments] = useState<number | undefined>(undefined);
  const [cashDiscountPct, setCashDiscountPct] = useState<number | undefined>(undefined);
  const [currency, setCurrency] = useState<CurrencyCode>('BRL');

  useEffect(() => {
    if (!user) return;
    supabase
      .from('profiles')
      .select('labor_fee_per_session, max_installments, cash_discount_pct, currency')
      .eq('id', user.id)
      .single()
      .then(({ data, error }) => {
        // Mesma correção de Perfil.tsx: erro de fetch não pode virar "campos
        // em branco" sem avisar o profissional.
        if (error) {
          toast.error(t('profile.loadError'));
        } else if (data) {
          setLaborFeePerSession(data.labor_fee_per_session ?? undefined);
          setMaxInstallments(data.max_installments ?? undefined);
          setCashDiscountPct(data.cash_discount_pct ?? undefined);
          setCurrency((data.currency as CurrencyCode) ?? 'BRL');
        }
        setLoading(false);
      });
  }, [user?.id, t]);

  const handleSave = async () => {
    if (!user) return;
    // Achado de QA: os campos abaixo não vivem dentro de um <form>, então o
    // `min`/`max` do HTML5 nos <input type="number"> nunca é checado (só
    // dispara em submit) — dava pra digitar 999 parcelas ou -50% de
    // desconto e salvar sem nenhum aviso. Valida a faixa aqui antes de
    // gravar, com a mesma regra dos CHECKs no banco (ver migração
    // 20260910160000_add_installment_and_discount_config.sql).
    if (laborFeePerSession !== undefined && laborFeePerSession < 0) {
      toast.error(t('profile.payment.laborFeeInvalid'));
      return;
    }
    if (
      maxInstallments !== undefined &&
      (!Number.isInteger(maxInstallments) || maxInstallments < 1 || maxInstallments > 24)
    ) {
      toast.error(t('profile.payment.maxInstallmentsInvalid'));
      return;
    }
    // O CHECK de cash_discount_pct no banco exige > 0 (não >= 0): "desconto
    // de 0%" é modelado como null/desativado, não como zero.
    if (cashDiscountPct !== undefined && (cashDiscountPct <= 0 || cashDiscountPct > 100)) {
      toast.error(t('profile.payment.cashDiscountInvalid'));
      return;
    }
    setSaving(true);
    try {
      // upsert + select, mesma correção do bug "não salva" de Perfil.tsx:
      // um UPDATE que não casa nenhuma linha reporta sucesso sem gravar
      // nada. Ver Perfil.tsx para o detalhe completo.
      const { data, error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          labor_fee_per_session: laborFeePerSession ?? null,
          max_installments: maxInstallments ?? null,
          cash_discount_pct: cashDiscountPct ?? null,
          currency,
        }, { onConflict: 'id' })
        .select('id')
        .single();
      if (error) throw error;
      if (!data) throw new Error(t('profile.saveError'));
      toast.success(t('profile.saved'));
    } catch (err: any) {
      toast.error(err.message || t('profile.saveError'));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AppLayout title={t('profile.payment.title')} showBack onBack={() => navigate('/perfil')}>
        <div className="flex flex-col gap-3">
          <SkeletonCard lines={3} />
        </div>
      </AppLayout>
    );
  }

  return (
    <PageTransition>
    <AppLayout
      title={t('profile.payment.title')}
      showBack
      onBack={() => navigate('/perfil')}
      rightAction={<HeaderSaveButton onClick={handleSave} saving={saving} />}
    >
      <div className="flex flex-col gap-4">
        <HCard>
          <p className="text-[11px] text-h-text-3 mb-3">{t('profile.payment.subtitle')}</p>
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-[13px] text-h-text-2 flex-1">{t('profile.payment.currency')}</p>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="w-[100px] h-[40px] min-h-[44px] rounded-r-sm px-3 text-[13px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              >
                {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="flex items-center justify-between gap-3 pt-2 border-t border-h-surface">
              <p className="text-[13px] text-h-text-2 flex-1">{t('profile.insumos.laborFee')}</p>
              <input
                type="number"
                min={0}
                step="0.01"
                inputMode="decimal"
                value={laborFeePerSession ?? ''}
                onChange={(e) => setLaborFeePerSession(e.target.value === '' ? undefined : Number(e.target.value))}
                placeholder={formatCurrency(0, currency)}
                className="w-[120px] h-[40px] min-h-[44px] rounded-r-sm px-3 text-[13px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none text-right placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
            <div className="flex items-center justify-between gap-3 pt-2 border-t border-h-surface">
              <p className="text-[13px] text-h-text-2 flex-1">{t('profile.payment.maxInstallments')}</p>
              <input
                type="number"
                min={1}
                max={24}
                step="1"
                inputMode="numeric"
                value={maxInstallments ?? ''}
                onChange={(e) => setMaxInstallments(e.target.value === '' ? undefined : Number(e.target.value))}
                placeholder={t('profile.payment.maxInstallmentsPlaceholder')}
                className="w-[80px] h-[40px] min-h-[44px] rounded-r-sm px-3 text-[13px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none text-right placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <p className="text-[13px] text-h-text-2 flex-1">{t('profile.payment.cashDiscount')}</p>
              <input
                type="number"
                min={0}
                max={100}
                step="0.1"
                inputMode="decimal"
                value={cashDiscountPct ?? ''}
                onChange={(e) => setCashDiscountPct(e.target.value === '' ? undefined : Number(e.target.value))}
                placeholder="0%"
                className="w-[80px] h-[40px] min-h-[44px] rounded-r-sm px-3 text-[13px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none text-right placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
          </div>
        </HCard>
      </div>
    </AppLayout>
    </PageTransition>
  );
};

export default PerfilPagamento;
