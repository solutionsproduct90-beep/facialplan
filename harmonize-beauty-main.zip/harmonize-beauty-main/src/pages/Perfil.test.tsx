import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import Perfil from "./Perfil";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const storageFromMock = vi.fn();
const navigateMock = vi.fn();
const upsertSpy = vi.fn();
const toastSuccessMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: { from: (...args: unknown[]) => storageFromMock(...args) },
  },
}));

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

const PROFILE = {
  full_name: "Ana Souza",
  clinic_name: "Clínica Bela Face",
  specialty: "Médico",
  council_type: "CRM",
  council_number: "12345",
  phone: "11999999999",
  logo_url: null,
  pre_post_care_instructions: "Evite exposição solar por 48h.",
};

/**
 * Builder mínimo pra `profiles`: suporta tanto o GET inicial
 * (`.select().eq().single()`) quanto o SAVE (`.upsert().select().single()`)
 * usados por Perfil.tsx, mirando exatamente a correção do bug "não salva":
 * um UPDATE sem `.select()` de volta não dava pra distinguir "salvou" de
 * "não achou a linha" — o upsert().select().single() daqui simula as duas
 * respostas possíveis.
 */
function createProfilesBuilder(
  getResponse: { data: unknown; error: unknown },
  upsertResponse: { data: unknown; error: unknown }
) {
  let mode: "select" | "upsert" = "select";
  const builder = {
    select: () => builder,
    eq: () => builder,
    upsert: (payload: unknown, opts: unknown) => {
      mode = "upsert";
      upsertSpy(payload, opts);
      return builder;
    },
    single: () => Promise.resolve(mode === "upsert" ? upsertResponse : getResponse),
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/perfil"]}>
      <Routes>
        <Route path="/perfil" element={<Perfil />} />
      </Routes>
    </MemoryRouter>
  );

describe("Perfil (hub)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, signOut: vi.fn() });
    fromMock.mockReset();
    storageFromMock.mockReset();
    navigateMock.mockReset();
    upsertSpy.mockReset();
    toastSuccessMock.mockReset();
    toastErrorMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: PROFILE, error: null },
          { data: { id: "pro-1" }, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });
  });

  it("loads the professional's saved identity fields", async () => {
    renderPage();
    expect(await screen.findByDisplayValue("Ana Souza")).toBeInTheDocument();
    expect(screen.getByDisplayValue("Clínica Bela Face")).toBeInTheDocument();
  });

  // Backlog P1 "Orientações pré/pós-procedimento" (v1 reduzida): um único
  // texto livre por profissional (profiles.pre_post_care_instructions),
  // anexado depois ao PDF e às mensagens de WhatsApp/e-mail em
  // SessaoEstagio3.tsx — não por procedimento específico do catálogo.
  it("loads the professional's configured pre/post-procedure care instructions into the textarea", async () => {
    renderPage();
    expect(await screen.findByDisplayValue("Evite exposição solar por 48h.")).toBeInTheDocument();
  });

  it("includes the edited care instructions text in the upsert payload on save", async () => {
    renderPage();
    const textarea = await screen.findByDisplayValue("Evite exposição solar por 48h.");
    fireEvent.change(textarea, { target: { value: "Não se exponha ao sol por 72h e evite maquiagem por 24h." } });

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
    const [payload] = upsertSpy.mock.calls[0];
    expect(payload).toMatchObject({
      pre_post_care_instructions: "Não se exponha ao sol por 72h e evite maquiagem por 24h.",
    });
  });

  it("saves null (not an empty string) when the care instructions field is cleared", async () => {
    renderPage();
    const textarea = await screen.findByDisplayValue("Evite exposição solar por 48h.");
    fireEvent.change(textarea, { target: { value: "   " } });

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
    const [payload] = upsertSpy.mock.calls[0];
    expect(payload).toMatchObject({ pre_post_care_instructions: null });
  });

  it("shows an error toast instead of silently blanking the form when the fetch fails", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: null, error: { message: "network error" } },
          { data: null, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    // Regressão do bug "não salva, fica em branco no login": antes o erro
    // do fetch inicial era engolido em silêncio e a tela só mostrava campos
    // vazios, indistinguível de "meus dados sumiram". Hoje a busca passa por
    // `retryFetch` (backoff ~500ms/1000ms) antes de desistir — timeout maior
    // que o padrão do waitFor pra dar tempo das retentativas acontecerem.
    await waitFor(
      () => expect(toastErrorMock).toHaveBeenCalledWith("Não foi possível carregar seu perfil. Tente novamente."),
      { timeout: 5000 }
    );
  });

  it("renders navigation cards to insumos and pagamento, plus the existing assinatura link", async () => {
    renderPage();
    await screen.findByDisplayValue("Ana Souza");

    expect(screen.getByText("Insumos e marcas")).toBeInTheDocument();
    expect(screen.getByText("Condições de pagamento")).toBeInTheDocument();
    expect(screen.getByText("Assinatura")).toBeInTheDocument();
  });

  it("navigates to /perfil/insumos and /perfil/pagamento when their cards are tapped", async () => {
    renderPage();
    await screen.findByDisplayValue("Ana Souza");

    fireEvent.click(screen.getByText("Insumos e marcas"));
    expect(navigateMock).toHaveBeenCalledWith("/perfil/insumos");

    fireEvent.click(screen.getByText("Condições de pagamento"));
    expect(navigateMock).toHaveBeenCalledWith("/perfil/pagamento");
  });

  it("renders the header Salvar as a solid pill instead of the old plain text link", async () => {
    renderPage();
    await screen.findByDisplayValue("Ana Souza");
    expect(screen.getByRole("button", { name: "Salvar" })).toHaveClass("bg-gradient-brand");
  });

  it("upserts identity fields on save and confirms a row actually came back", async () => {
    renderPage();
    await screen.findByDisplayValue("Ana Souza");

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
    const [payload, opts] = upsertSpy.mock.calls[0];
    expect(payload).toMatchObject({ id: "pro-1", full_name: "Ana Souza" });
    expect(opts).toEqual({ onConflict: "id" });

    await waitFor(() => expect(toastSuccessMock).toHaveBeenCalledWith("Perfil salvo!"));
  });

  it("surfaces a save error instead of a false 'saved' toast when the write reports no affected row", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: PROFILE, error: null },
          // Simula o cenário que o `update()` puro escondia: nenhum erro,
          // mas nenhuma linha voltou (RLS/linha inexistente) — o app não
          // pode reportar sucesso aqui.
          { data: null, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    await screen.findByDisplayValue("Ana Souza");

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("Erro ao salvar"));
    expect(toastSuccessMock).not.toHaveBeenCalled();
  });
});
