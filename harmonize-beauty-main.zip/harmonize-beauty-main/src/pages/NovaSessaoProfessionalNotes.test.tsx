import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import NovaSessao from "./NovaSessao";
import { createQueryBuilder } from "@/test/supabaseMock";
import i18n from "@/i18n";

// Cobre o backlog P1 "Observações clínicas em texto livre do profissional
// no prompt da IA": um campo de textarea opcional na Etapa "Nova Sessão",
// ANTES de disparar a análise (ver handleAnalyze em NovaSessao.tsx), que
// quando preenchido viaja (trimado) como `professionalNotes` no body
// enviado à edge function `analyze-face` — e quando deixado vazio não muda
// nada no comportamento existente (campo aditivo/opcional).
const useAuthMock = vi.fn();
const fromMock = vi.fn();
const invokeMock = vi.fn();
const uploadMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: {
      from: () => ({
        upload: (...args: unknown[]) => uploadMock(...args),
      }),
    },
    functions: {
      invoke: (...args: unknown[]) => invokeMock(...args),
    },
  },
}));

// jsdom doesn't implement createObjectURL — NovaSessao calls it right after
// setting the selected file (photo preview), unrelated to what these tests
// check, so it's stubbed rather than asserted on.
if (typeof URL.createObjectURL !== "function") {
  URL.createObjectURL = vi.fn(() => "blob:mock-preview");
}

const PATIENT = { id: "pat-1", name: "Maria Silva", consent_given: true, phone: null };

function createSessionsInsertBuilder() {
  return {
    insert: (_payload: unknown) => ({
      select: () => ({
        single: async () => ({ data: { id: "sess-1" }, error: null }),
      }),
    }),
  };
}

const renderPage = () =>
  render(
    <MemoryRouter
      initialEntries={[
        {
          pathname: "/sessoes/novo",
          state: { preselectedPatientId: PATIENT.id, preselectedPatientName: PATIENT.name },
        },
      ]}
    >
      <Routes>
        <Route path="/sessoes/novo" element={<NovaSessao />} />
        <Route path="/sessoes/:id/estagio-1" element={<div>Estágio 1 mock</div>} />
      </Routes>
    </MemoryRouter>
  );

function makePhotoFile() {
  return new File(["conteudo-pequeno-de-teste"], "foto.jpg", { type: "image/jpeg" });
}

describe("NovaSessao — observações clínicas opcionais do profissional", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    invokeMock.mockReset();
    uploadMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsInsertBuilder();
      if (table === "patients") {
        return createQueryBuilder(
          { data: [PATIENT] as unknown },
          { data: PATIENT as unknown }
        );
      }
      return createQueryBuilder();
    });
    uploadMock.mockResolvedValue({ error: null });
    invokeMock.mockResolvedValue({ data: { suggestions: [], source: "ai" }, error: null });
  });

  const waitForUploadStep = () =>
    waitFor(() => expect(screen.getByLabelText("Observações clínicas (opcional)")).toBeInTheDocument());

  it("renders the field with a clear optional label and placeholder", async () => {
    renderPage();
    await waitForUploadStep();

    const textarea = screen.getByLabelText("Observações clínicas (opcional)") as HTMLTextAreaElement;
    expect(textarea).toBeInTheDocument();
    expect(textarea).toHaveAttribute(
      "placeholder",
      "Ex: paciente já fez toxina há 3 meses, quer reforçar só a região frontal..."
    );
    expect(textarea.value).toBe("");
  });

  it("proceeds with the analysis and omits professionalNotes from the request body when left empty", async () => {
    renderPage();
    await waitForUploadStep();

    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(fileInput, { target: { files: [makePhotoFile()] } });

    const analyzeBtn = await screen.findByRole("button", { name: "Analisar foto →" });
    fireEvent.click(analyzeBtn);

    await waitFor(() => expect(invokeMock).toHaveBeenCalledTimes(1));
    const [fnName, options] = invokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(fnName).toBe("analyze-face");
    expect(options.body).toEqual({
      sessionId: "sess-1",
      patientId: "pat-1",
      storagePath: "pro-1/sess-1.jpg",
    });
    expect(options.body).not.toHaveProperty("professionalNotes");
  });

  it("sends the trimmed clinical notes as professionalNotes when the professional fills the field", async () => {
    renderPage();
    await waitForUploadStep();

    const textarea = screen.getByLabelText("Observações clínicas (opcional)");
    fireEvent.change(textarea, {
      target: { value: "  paciente já fez toxina há 3 meses, reforçar só a região frontal  " },
    });

    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(fileInput, { target: { files: [makePhotoFile()] } });

    const analyzeBtn = await screen.findByRole("button", { name: "Analisar foto →" });
    fireEvent.click(analyzeBtn);

    await waitFor(() => expect(invokeMock).toHaveBeenCalledTimes(1));
    const [, options] = invokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(options.body.professionalNotes).toBe(
      "paciente já fez toxina há 3 meses, reforçar só a região frontal"
    );
  });

  it("does not send a whitespace-only notes field as professionalNotes", async () => {
    renderPage();
    await waitForUploadStep();

    const textarea = screen.getByLabelText("Observações clínicas (opcional)");
    fireEvent.change(textarea, { target: { value: "    " } });

    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(fileInput, { target: { files: [makePhotoFile()] } });

    const analyzeBtn = await screen.findByRole("button", { name: "Analisar foto →" });
    fireEvent.click(analyzeBtn);

    await waitFor(() => expect(invokeMock).toHaveBeenCalledTimes(1));
    const [, options] = invokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(options.body).not.toHaveProperty("professionalNotes");
  });
});
