import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Agenda from './Agenda';
import i18n from '@/i18n';
import { createRangeSlicer } from '@/test/supabaseMock';

// Tela própria de Agenda (`/agenda`) — reaproveita `<AgendaTab />` (a mesma
// aba já usada em `/painel`), então este arquivo cobre a integração da
// rota/página com esse componente: título correto, listagem, criação de
// compromisso e o filtro por profissional na consulta ao Supabase. A lógica
// pura (agrupamento por dia, normalização) já é coberta em
// src/lib/agenda.test.ts, e o CRUD completo (editar/concluir/cancelar/
// excluir) em src/components/harmonize/panel/AgendaTab.test.tsx — não
// duplicados aqui.

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const insertSpy = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/**
 * Builder pra `appointments` que, diferente do mock genérico usado em
 * AgendaTab.test.tsx, GRAVA os argumentos de `.eq(...)` — é o que permite
 * este arquivo verificar que a listagem é filtrada por
 * `professional_id = auth.uid()` (o equivalente, em teste de unidade da
 * lógica do app, à RLS que o banco aplica de verdade).
 */
function createAppointmentsBuilder(rows: unknown[], eqSpy: ReturnType<typeof vi.fn>) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: (...args: unknown[]) => {
      eqSpy(...args);
      return builder;
    },
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
    insert: (payload: Record<string, unknown>) => {
      insertSpy(payload);
      return Promise.resolve({ error: null });
    },
  };
  return builder;
}

function createPatientsBuilder(rows: unknown[]) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
  };
  return builder;
}

const renderPage = () =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <MemoryRouter initialEntries={['/agenda']}>
        <Routes>
          <Route path="/agenda" element={<Agenda />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );

describe('Agenda page', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' } });
    fromMock.mockReset();
    insertSpy.mockReset();
  });

  it('renders the page title and the appointments list from AgendaTab', async () => {
    const eqSpy = vi.fn();
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') {
        return createAppointmentsBuilder(
          [
            {
              id: 'a1',
              patient_id: null,
              note: 'Retorno de avaliação',
              scheduled_at: new Date(2026, 8, 20, 14, 30).toISOString(),
              duration_minutes: 30,
              status: 'agendado',
              patient: null,
            },
          ],
          eqSpy,
        );
      }
      if (table === 'patients') return createPatientsBuilder([]);
      if (table === 'appointment_waitlist') return createPatientsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    // Título da AppLayout (agenda.title) e conteúdo da lista aparecem juntos.
    expect(await screen.findAllByText('Agenda')).not.toHaveLength(0);
    expect(await screen.findByText('14:30')).toBeInTheDocument();
    expect(screen.getByText('Retorno de avaliação')).toBeInTheDocument();
  });

  it('scopes the appointments query to the signed-in professional (professional_id = auth.uid())', async () => {
    const eqSpy = vi.fn();
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') return createAppointmentsBuilder([], eqSpy);
      if (table === 'patients') return createPatientsBuilder([]);
      if (table === 'appointment_waitlist') return createPatientsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    await screen.findByText('Nenhum compromisso agendado ainda.');
    expect(eqSpy).toHaveBeenCalledWith('professional_id', 'pro-1');
  });

  it('creates a new appointment scoped to the current professional', async () => {
    const eqSpy = vi.fn();
    fromMock.mockImplementation((table: string) => {
      if (table === 'appointments') return createAppointmentsBuilder([], eqSpy);
      if (table === 'patients') return createPatientsBuilder([{ id: 'p1', name: 'Maria Silva' }]);
      if (table === 'appointment_waitlist') return createPatientsBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    await screen.findByText('Nenhum compromisso agendado ainda.');

    fireEvent.click(screen.getByTestId('agenda-add-new'));
    fireEvent.change(screen.getByLabelText('Data'), { target: { value: '2026-09-25' } });
    fireEvent.change(screen.getByLabelText('Hora'), { target: { value: '10:00' } });
    fireEvent.change(screen.getByLabelText('Paciente (opcional)'), { target: { value: 'p1' } });
    fireEvent.click(screen.getByText('Salvar'));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({ professional_id: 'pro-1', patient_id: 'p1' });
  });
});
