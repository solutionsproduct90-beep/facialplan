import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import PerfilInsumos from "./PerfilInsumos";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const insertSpy = vi.fn();
const toastSuccessMock = vi.fn();
const toastErrorMock = vi.fn();
const toastMessageMock = vi.fn();
// Mock de supabase.functions.invoke('read-insumo-label', ...) — cada teste
// que exercita a leitura por IA sobrescreve a resolução via
// functionsInvokeMock.mockResolvedValueOnce(...).
const functionsInvokeMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    functions: { invoke: (...args: unknown[]) => functionsInvokeMock(...args) },
  },
}));

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
    message: (...args: unknown[]) => toastMessageMock(...args),
  },
}));

const INSUMOS = [
  { id: "ins-1", substance: "acido_hialuronico", brand_name: "Juvederm Voluma", cost_per_unit: 100, price_per_unit: 250, active: true },
];

/** Builder pra `insumos`: lista (`select().eq().order().order()`) e insert. */
function createInsumosBuilder(listResponse: { data: unknown; error: unknown }) {
  const builder = {
    select: () => builder,
    eq: () => builder,
    order: () => builder,
    insert: (payload: Record<string, unknown>) => {
      insertSpy(payload);
      return {
        select: () => ({
          single: () => Promise.resolve({ data: { id: "ins-new", ...payload }, error: null }),
        }),
      };
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve(listResponse).then(onFulfilled),
  };
  return builder;
}

/** Builder pra `profiles`: só o `select('currency').eq().single()` usado aqui pra formatar custo/preço. */
function createProfileBuilder(currency: string | null = "BRL") {
  const builder = {
    select: () => builder,
    eq: () => builder,
    single: () => Promise.resolve({ data: { currency }, error: null }),
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/perfil/insumos"]}>
      <Routes>
        <Route path="/perfil/insumos" element={<PerfilInsumos />} />
      </Routes>
    </MemoryRouter>
  );

describe("PerfilInsumos", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" } });
    fromMock.mockReset();
    navigateMock.mockReset();
    insertSpy.mockReset();
    toastSuccessMock.mockReset();
    toastErrorMock.mockReset();
    toastMessageMock.mockReset();
    functionsInvokeMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "insumos") return createInsumosBuilder({ data: INSUMOS, error: null });
      if (table === "profiles") return createProfileBuilder();
      throw new Error(`unexpected table ${table}`);
    });
  });

  it("lists the professional's own insumos by substance, without the identity/payment fields", async () => {
    renderPage();
    expect(await screen.findByText("Juvederm Voluma")).toBeInTheDocument();
    // Campos que agora vivem só no hub/PerfilPagamento não devem reaparecer aqui.
    expect(screen.queryByPlaceholderText("Seu nome")).not.toBeInTheDocument();
    expect(screen.queryByText("Máximo de parcelas sem juros")).not.toBeInTheDocument();
  });

  it("shows an error toast instead of a silent empty state when the list fetch fails", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "insumos") return createInsumosBuilder({ data: null, error: { message: "boom" } });
      if (table === "profiles") return createProfileBuilder();
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith("Não foi possível carregar seu perfil. Tente novamente.")
    );
  });

  it("opens the add-brand sheet and creates a new insumo tied to the professional", async () => {
    renderPage();
    await screen.findByText("Juvederm Voluma");

    fireEvent.click(screen.getAllByText("Adicionar marca")[0]);
    fireEvent.change(screen.getByPlaceholderText("Ex: Juvederm Voluma"), { target: { value: "Dysport" } });

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
    expect(insertSpy.mock.calls[0][0]).toMatchObject({ professional_id: "pro-1", brand_name: "Dysport" });
    await waitFor(() => expect(toastSuccessMock).toHaveBeenCalledWith("Marca salva!"));
  });

  it("navigates back to the hub via the back button", async () => {
    renderPage();
    await screen.findByText("Juvederm Voluma");
    fireEvent.click(screen.getByRole("button", { name: "" }));
    expect(navigateMock).toHaveBeenCalledWith("/perfil");
  });

  describe("leitura de rótulo por IA — pré-preenche sem nunca salvar sozinha", () => {
    const openAddSheet = async () => {
      renderPage();
      await screen.findByText("Juvederm Voluma");
      fireEvent.click(screen.getAllByText("Adicionar marca")[0]);
    };

    const pickLabelPhoto = async () => {
      const fileInput = screen.getByTestId("insumo-label-file-input");
      const file = new File(["fake-label-photo"], "rotulo.jpg", { type: "image/jpeg" });
      fireEvent.change(fileInput, { target: { files: [file] } });
      // handleLabelPhotoChange é assíncrono (FileReader + invoke) — espera
      // a chamada à edge function acontecer antes de seguir com as
      // asserções.
      await waitFor(() => expect(functionsInvokeMock).toHaveBeenCalledTimes(1));
    };

    it("pre-fills brandName/concentration/expiresOn from the AI reading, without ever calling insert (no auto-save)", async () => {
      functionsInvokeMock.mockResolvedValueOnce({
        data: { available: true, brandName: "Dysport", concentration: "20mg/mL", expiryDate: "2027-05-01" },
        error: null,
      });

      await openAddSheet();
      await pickLabelPhoto();

      await waitFor(() => expect(screen.getByPlaceholderText("Ex: Juvederm Voluma")).toHaveValue("Dysport"));
      expect(screen.getByPlaceholderText("Ex: 20mg/mL")).toHaveValue("20mg/mL");

      // O ponto central do requisito: a leitura NUNCA salva sozinha — só
      // clicar em "Salvar" (não exercido aqui) chamaria insert.
      expect(insertSpy).not.toHaveBeenCalled();
      await waitFor(() => expect(toastSuccessMock).toHaveBeenCalledWith("Rótulo lido! Revise os campos antes de salvar."));
    });

    it("lets the professional overwrite any AI-suggested field before saving", async () => {
      functionsInvokeMock.mockResolvedValueOnce({
        data: { available: true, brandName: "Dysport", concentration: "20mg/mL" },
        error: null,
      });

      await openAddSheet();
      await pickLabelPhoto();
      await waitFor(() => expect(screen.getByPlaceholderText("Ex: Juvederm Voluma")).toHaveValue("Dysport"));

      // Profissional corrige a marca sugerida e a concentração antes de salvar.
      fireEvent.change(screen.getByPlaceholderText("Ex: Juvederm Voluma"), { target: { value: "Botox" } });
      fireEvent.change(screen.getByPlaceholderText("Ex: 20mg/mL"), { target: { value: "50mg/mL" } });
      fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

      await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
      expect(insertSpy.mock.calls[0][0]).toMatchObject({
        brand_name: "Botox",
        concentration: "50mg/mL",
      });
    });

    it("shows a manual-fill error toast (never blocking the form) when the AI reading comes back malformed/unusable", async () => {
      functionsInvokeMock.mockResolvedValueOnce({ data: null, error: { message: "bad gateway" } });

      await openAddSheet();
      await pickLabelPhoto();

      await waitFor(() =>
        expect(toastErrorMock).toHaveBeenCalledWith("Não foi possível ler o rótulo automaticamente. Preencha os campos manualmente.")
      );
      // O cadastro manual continua funcionando normalmente depois da falha.
      fireEvent.change(screen.getByPlaceholderText("Ex: Juvederm Voluma"), { target: { value: "Restylane" } });
      fireEvent.click(screen.getByRole("button", { name: "Salvar" }));
      await waitFor(() => expect(insertSpy).toHaveBeenCalledTimes(1));
      expect(insertSpy.mock.calls[0][0]).toMatchObject({ brand_name: "Restylane" });
    });

    it("hides the AI reading option after the function reports it's unavailable (no ANTHROPIC_API_KEY)", async () => {
      functionsInvokeMock.mockResolvedValueOnce({ data: { available: false }, error: null });

      await openAddSheet();
      await pickLabelPhoto();

      await waitFor(() => expect(screen.queryByTestId("insumo-label-file-input")).not.toBeInTheDocument());
      // O formulário manual continua 100% funcional mesmo com a IA indisponível.
      expect(screen.getByPlaceholderText("Ex: Juvederm Voluma")).toBeInTheDocument();
    });
  });
});
