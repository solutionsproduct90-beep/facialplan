import React, { useState, useEffect, useRef } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import GhostButton from '@/components/harmonize/GhostButton';
import HeaderSaveButton from '@/components/harmonize/HeaderSaveButton';
import AuthSelect from '@/components/harmonize/AuthSelect';
import PushNotificationsToggle from '@/components/harmonize/PushNotificationsToggle';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { retryFetch } from '@/lib/retryFetch';
import { toast } from 'sonner';
import { LogOut, ChevronRight } from 'lucide-react';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { SUPPORTED_LANGUAGES, type SupportedLanguage } from '@/i18n';

const SPECIALTIES = ['Médico', 'Dentista', 'Biomédico', 'Enfermeiro'];
const COUNCIL_TYPES = ['CRM', 'CRO', 'CRBM', 'COREN'];

const LANGUAGE_OPTIONS: { value: SupportedLanguage; labelKey: string }[] =
  SUPPORTED_LANGUAGES.map((lang) => ({ value: lang, labelKey: `common.language.${lang}` }));

/**
 * Hub do Perfil: só identidade (avatar/logo, nome, clínica, especialidade,
 * conselho, telefone, idioma) + navegação pras telas de configuração que
 * antes viviam todas juntas numa rolagem só (insumos/marcas, condições de
 * pagamento). Ver PerfilInsumos.tsx e PerfilPagamento.tsx.
 */
const Perfil: React.FC = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const fileRef = useRef<HTMLInputElement>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [fullName, setFullName] = useState('');
  const [clinicName, setClinicName] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [councilType, setCouncilType] = useState('');
  const [councilNumber, setCouncilNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [careInstructions, setCareInstructions] = useState('');

  useEffect(() => {
    if (!user) return;
    // Depends on user?.id, not the `user` object itself: onAuthStateChange
    // (e.g. a background token refresh) hands out a new `user` reference for
    // the same account, and re-running this effect would refetch the
    // profile and overwrite whatever the professional is mid-typing in the
    // form below with the last-saved server values.
    retryFetch(async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name, clinic_name, specialty, council_type, council_number, phone, logo_url, pre_post_care_instructions')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    })
      .then((data) => {
        setFullName(data.full_name || '');
        setClinicName(data.clinic_name || '');
        setSpecialty(data.specialty || '');
        setCouncilType(data.council_type || '');
        setCouncilNumber(data.council_number || '');
        setPhone(data.phone || '');
        setLogoUrl(data.logo_url || null);
        setCareInstructions(data.pre_post_care_instructions || '');
      })
      .catch(() => {
        // BUG CORRIGIDO: essa falha era engolida em silêncio (o `error` nunca
        // era checado) — qualquer soluço de rede/RLS bem na hora do login
        // deixava a tela em branco sem nenhum aviso, indistinguível de "meus
        // dados sumiram". Agora, além de avisar, já tentamos de novo (retry
        // com backoff) antes de desistir — a maioria dos casos reais é um
        // soluço transitório de rede logo após o login, não um erro real.
        toast.error(t('profile.loadError'));
      })
      .finally(() => {
        setLoading(false);
      });
  }, [user?.id, t]);

  const handleSave = async () => {
    if (!user) return;
    if (!fullName.trim()) { toast.error(t('profile.nameRequired')); return; }
    setSaving(true);
    try {
      // BUG CORRIGIDO: era um `.update(...).eq('id', user.id)` puro. Um
      // UPDATE do Postgres que não casa nenhuma linha (perfil ainda não
      // existe, ou a policy de RLS não bate por qualquer motivo) não é um
      // erro pro PostgREST — ele responde sucesso com zero linhas afetadas.
      // O app mostrava "Perfil salvo!" mesmo sem gravar nada, e no próximo
      // login o profissional via tudo em branco de novo. upsert + select
      // garante que a linha existe e devolve o que foi de fato persistido;
      // se nada voltar, tratamos como falha real em vez de fingir sucesso.
      const { data, error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          full_name: fullName.trim(),
          clinic_name: clinicName.trim() || null,
          specialty: specialty || null,
          council_type: councilType || null,
          council_number: councilNumber.trim() || null,
          phone: phone.trim() || null,
          pre_post_care_instructions: careInstructions.trim() || null,
        }, { onConflict: 'id' })
        .select('id')
        .single();
      if (error) throw error;
      if (!data) throw new Error(t('profile.saveError'));
      toast.success(t('profile.saved'));
    } catch (err: any) {
      toast.error(err.message || t('profile.saveError'));
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 2 * 1024 * 1024) { toast.error(t('profile.logoTooLarge')); return; }
    if (!['image/png', 'image/jpeg'].includes(file.type)) { toast.error(t('profile.logoInvalidType')); return; }

    setUploading(true);
    try {
      const path = `${user.id}/logo.png`;
      const { error: upErr } = await supabase.storage
        .from('professional-assets')
        .upload(path, file, { upsert: true });
      if (upErr) throw upErr;

      const { data: urlData } = supabase.storage
        .from('professional-assets')
        .getPublicUrl(path);

      const newUrl = `${urlData.publicUrl}?t=${Date.now()}`;
      const { error: profileErr } = await supabase.from('profiles').upsert(
        { id: user.id, logo_url: newUrl },
        { onConflict: 'id' }
      );
      if (profileErr) throw profileErr;
      setLogoUrl(newUrl);
      toast.success(t('profile.logoUpdated'));
    } catch (err: any) {
      toast.error(err.message || t('profile.logoUploadError'));
    } finally {
      setUploading(false);
    }
  };

  const handleLanguageChange = (lang: string) => {
    // i18next-browser-languagedetector persists the choice to localStorage automatically
    i18n.changeLanguage(lang);
  };

  const initials = fullName
    ? fullName.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()
    : '??';

  if (loading) {
    return (
      <AppLayout title={t('nav.profile')}>
        <div className="flex flex-col gap-3">
          <SkeletonCard lines={3} />
          <SkeletonCard lines={2} />
        </div>
      </AppLayout>
    );
  }

  return (
    <PageTransition>
    <AppLayout
      title={t('nav.profile')}
      rightAction={<HeaderSaveButton onClick={handleSave} saving={saving} />}
    >
      <div className="flex flex-col gap-4">
        {/* 1. Avatar + Logo Upload */}
        <div className="flex flex-col items-center">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt={t('profile.logoAlt')}
              className="w-[72px] h-[72px] rounded-full object-cover shadow-h-sm"
            />
          ) : (
            <div className="w-[72px] h-[72px] rounded-full bg-gradient-brand flex items-center justify-center">
              <span className="text-[28px] font-bold" style={{ color: '#fff' }}>{initials}</span>
            </div>
          )}
          <GhostButton
            onClick={() => fileRef.current?.click()}
            className="!w-auto !h-auto !min-h-[44px] mt-2 px-6 text-[13px]"
            disabled={uploading}
          >
            {uploading ? t('profile.uploading') : t('profile.changeLogo')}
          </GhostButton>
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg"
            className="hidden"
            onChange={handleLogoUpload}
          />
          <p className="text-[11px] text-h-text-3 mt-1">{t('profile.logoHint')}</p>
        </div>

        {/* 2. Professional Data */}
        <HCard>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: "#AAA8A5" }}>{t('profile.fullName')}</label>
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder={t('profile.fullNamePlaceholder')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: "#AAA8A5" }}>{t('profile.clinicName')}</label>
              <input
                value={clinicName}
                onChange={(e) => setClinicName(e.target.value)}
                placeholder={t('profile.clinicNamePlaceholder')}
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
            <AuthSelect
              label={t('profile.specialty')}
              options={SPECIALTIES.map(s => ({ value: s, label: s }))}
              value={specialty}
              onChange={(val) => setSpecialty(val)}
            />
            <div className="grid grid-cols-2 gap-3">
              <AuthSelect
                label={t('profile.council')}
                options={COUNCIL_TYPES.map(c => ({ value: c, label: c }))}
                value={councilType}
                onChange={(val) => setCouncilType(val)}
              />
              <div className="flex flex-col gap-1.5">
                <label style={{ fontSize: 11, fontWeight: 700, color: "#AAA8A5" }}>{t('profile.councilNumber')}</label>
                <input
                  value={councilNumber}
                  onChange={(e) => setCouncilNumber(e.target.value)}
                  placeholder="000000"
                  className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                  style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
                />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: "#AAA8A5" }}>{t('profile.phone')}</label>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(00) 00000-0000"
                type="tel"
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
          </div>
        </HCard>

        {/* 2.4. Care instructions — texto livre (v1 reduzida do backlog P1
            "Orientações pré/pós-procedimento"): um único texto padrão por
            profissional, anexado automaticamente ao PDF e às mensagens de
            WhatsApp/e-mail do resultado da sessão (ver SessaoEstagio3.tsx).
            Fora de escopo nesta v1: orientação por procedimento específico
            do catálogo (fica genérico por profissional) e editor rico —
            textarea simples, como o resto do app (ex.: notas do paciente em
            NovoPaciente.tsx). */}
        <HCard>
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: "#AAA8A5" }}>
              {t('profile.careInstructions.title')}
            </label>
            <p className="text-[11px] text-h-text-3 -mt-0.5 mb-1">
              {t('profile.careInstructions.subtitle')}
            </p>
            <textarea
              value={careInstructions}
              onChange={(e) => setCareInstructions(e.target.value)}
              placeholder={t('profile.careInstructions.placeholder')}
              rows={5}
              className="rounded-r-sm px-4 py-3 text-[14px] font-normal text-h-text bg-h-white border border-h-surface-3/40 outline-none resize-none focus:ring-2 focus:ring-h-g-mid/30 placeholder:text-h-text-3"
              style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
            />
          </div>
        </HCard>

        {/* 2.5. Language */}
        <HCard>
          <AuthSelect
            label={t('profile.language.label')}
            options={LANGUAGE_OPTIONS.map((opt) => ({ value: opt.value, label: t(opt.labelKey) }))}
            value={i18n.resolvedLanguage ?? i18n.language}
            onChange={handleLanguageChange}
          />
        </HCard>

        {/* 2.6. Push notifications — instalabilidade (PWA) + infraestrutura
            de push desta rodada. Ver src/hooks/usePushNotifications.ts para
            a lógica de permissão/inscrição. */}
        <HCard>
          <PushNotificationsToggle />
        </HCard>

        {/* 3. Navigation to the screens that used to be crammed into this
            same scroll — insumos/marcas and condições de pagamento each got
            their own screen (PerfilInsumos.tsx / PerfilPagamento.tsx). */}
        <HCard onClick={() => navigate('/perfil/insumos')} className="cursor-pointer press-scale">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[14px] font-semibold text-h-text">{t('profile.insumos.title')}</p>
              <p className="text-[12px] text-h-text-3 truncate">{t('profile.insumos.subtitle')}</p>
            </div>
            <ChevronRight size={18} className="text-h-text-3 flex-shrink-0" />
          </div>
        </HCard>

        <HCard onClick={() => navigate('/perfil/pagamento')} className="cursor-pointer press-scale">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[14px] font-semibold text-h-text">{t('profile.payment.title')}</p>
              <p className="text-[12px] text-h-text-3 truncate">{t('profile.payment.subtitle')}</p>
            </div>
            <ChevronRight size={18} className="text-h-text-3 flex-shrink-0" />
          </div>
        </HCard>

        {/* 4. Account Link — já existia, comportamento/rota mantidos; só os
            dois textos hardcoded em PT viraram i18n (achado de QA: com o
            app em outro idioma, "Assinatura"/"Ver plano" continuavam em
            português). */}
        <HCard onClick={() => navigate('/conta')}>
          <div className="flex items-center justify-between">
            <p className="text-[14px] font-semibold text-h-text">{t('account.subscription.title')}</p>
            <div className="flex items-center gap-1 text-h-g-start">
              <span className="text-[13px] font-semibold">{t('profile.viewPlan')}</span>
              <ChevronRight size={16} />
            </div>
          </div>
        </HCard>

        {/* 5. Sign Out */}
        <GhostButton onClick={signOut}>
          <span className="flex items-center justify-center gap-2">
            <LogOut size={16} />
            {t('common.signOut')}
          </span>
        </GhostButton>
      </div>
    </AppLayout>
    </PageTransition>
  );
};

export default Perfil;
