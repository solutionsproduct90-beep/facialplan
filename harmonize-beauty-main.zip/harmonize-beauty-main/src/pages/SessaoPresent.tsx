import React, { useCallback, useEffect, useRef, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Info, ShieldCheck, Maximize2, Minimize2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import LogoMark from '@/components/harmonize/LogoMark';
import GhostButton from '@/components/harmonize/GhostButton';
import GradientButton from '@/components/harmonize/GradientButton';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import BeforeAfterViewer from '@/components/harmonize/BeforeAfterViewer';
import { SUBSTANCE_LABEL, type ApplicationPoint, type Stage1Analysis } from '@/types/harmonize';
import type { Json } from '@/integrations/supabase/types';
import AnalysisProvenanceBanner from '@/components/harmonize/AnalysisProvenanceBanner';
import { analysisProvenance } from '@/lib/analysisProvenance';
import { useSessionPresentLink } from '@/hooks/useSessionPresentLink';
import { useSessionFeedbackLink } from '@/hooks/useSessionFeedbackLink';
import { useVideoExport } from '@/hooks/useVideoExport';
import { extractPatientExplanation, formatPatientExplanation } from '@/lib/patientJustification';
import { formatProfessionalRegistration } from '@/lib/professionalRegistration';

interface SessionData {
  selected_procedure: string | null;
  simulation_intensity: string | null;
  original_image_url: string | null;
  simulation_url: string | null;
  patient: { name: string } | null;
  professional_id: string | null;
  stage2_overlay: Json | null;
  // Análise da Etapa 1 — carregada AQUI só pela proveniência (`source`): o que
  // esta tela mostra ao paciente ("o que será feito", com a explicação clínica
  // de cada ponto) desce da análise da IA via `justification` copiada no
  // aceite da Etapa 1, então uma análise de DEMONSTRAÇÃO chega até aqui e é
  // apresentada ao paciente como se fosse leitura real. Ver
  // src/lib/analysisProvenance.ts.
  stage1_analysis: Json | null;
}

const SessaoPresent: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [session, setSession] = useState<SessionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<{
    clinic_name: string | null;
    logo_url: string | null;
    full_name: string | null;
    council_type: string | null;
    council_number: string | null;
  } | null>(null);
  const [beforeUrl, setBeforeUrl] = useState<string | null>(null);
  const [afterUrl, setAfterUrl] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const presentLink = useSessionPresentLink(id);
  const feedbackLink = useSessionFeedbackLink(id);

  // Modo "tela cheia" — alternativa real ao espelhamento em TV (já coberto
  // nativamente por AirPlay/Chromecast do SO): usa a Fullscreen API do
  // navegador no card de apresentação, escondendo o cabeçalho do app (logo,
  // nome da clínica, "Sair" e a linha do profissional responsável) pra dar o
  // máximo de espaço de tela na frente do paciente. Safari no iOS tem
  // suporte bem limitado/ausente à Fullscreen API em elementos comuns — por
  // isso o botão sempre funciona (esconde a UI via CSS) mesmo quando a
  // chamada nativa não existe (requestFullscreen ausente) ou falha.
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const enterFullscreen = useCallback(async () => {
    const el = containerRef.current as
      | (HTMLDivElement & { webkitRequestFullscreen?: () => Promise<void> | void })
      | null;
    const request = el?.requestFullscreen?.bind(el) ?? el?.webkitRequestFullscreen?.bind(el);
    if (request) {
      try {
        await request();
      } catch {
        // requestFullscreen pode rejeitar (chamada fora de um gesto direto
        // do usuário, permissão negada pelo navegador, etc.) — cai pro modo
        // apresentação só-CSS abaixo (esconder o cabeçalho) em vez de
        // quebrar a tela.
      }
    }
    setIsFullscreen(true);
  }, []);

  const exitFullscreen = useCallback(() => {
    const doc = document as Document & { webkitFullscreenElement?: Element; webkitExitFullscreen?: () => Promise<void> | void };
    if (doc.fullscreenElement || doc.webkitFullscreenElement) {
      const exit = doc.exitFullscreen?.bind(doc) ?? doc.webkitExitFullscreen?.bind(doc);
      exit?.();
    }
    setIsFullscreen(false);
  }, []);

  // Sincroniza o estado quando a tela cheia nativa é encerrada por fora do
  // nosso botão — tecla Esc (comportamento padrão do navegador) ou UI do
  // próprio navegador/SO.
  useEffect(() => {
    const doc = document as Document & { webkitFullscreenElement?: Element };
    const handleFullscreenChange = () => {
      if (!doc.fullscreenElement && !doc.webkitFullscreenElement) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Esc também precisa funcionar no fallback só-CSS (sem Fullscreen API
  // nativa), onde nenhum evento fullscreenchange é disparado pelo navegador.
  useEffect(() => {
    if (!isFullscreen) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        exitFullscreen();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen, exitFullscreen]);

  useEffect(() => {
    if (!id) return;
    const load = async () => {
      const { data } = await supabase
        .from('sessions')
        .select('selected_procedure, simulation_intensity, original_image_url, simulation_url, professional_id, stage2_overlay, stage1_analysis, patient:patients(name)')
        .eq('id', id)
        .single();
      // Sem simulation_url não há o que apresentar — acontece quando o
      // profissional navega direto para /present sem nunca ter gerado a
      // simulação na Etapa 3. Sem esta checagem, a tela seguia em frente e
      // mostrava o gradiente placeholder do "Depois" como se fosse um
      // resultado real.
      if (!data || !data.simulation_url) {
        setNotFound(true);
        setLoading(false);
        return;
      }
      const sessionData = {
        ...data,
        patient: Array.isArray(data.patient) ? data.patient[0] : data.patient,
      } as SessionData;
      setSession(sessionData);
      if (data.professional_id) {
        const { data: prof } = await supabase
          .from('profiles')
          .select('clinic_name, logo_url, full_name, council_type, council_number')
          .eq('id', data.professional_id)
          .single();
        if (prof) setProfile(prof);
      }
      if (data.original_image_url) {
        const { data: signedBefore } = await supabase.storage
          .from('patient-photos')
          .createSignedUrl(data.original_image_url, 3600);
        setBeforeUrl(signedBefore?.signedUrl ?? null);
      }
      // A simulação real fica em simulation-results; no modo mock (sem
      // GEMINI_API_KEY), generate-simulation reaproveita o mesmo path da
      // foto original, que vive em patient-photos — tenta o bucket certo
      // primeiro e cai pro outro se não achar.
      const { data: signedAfter } = await supabase.storage
        .from('simulation-results')
        .createSignedUrl(data.simulation_url, 3600);
      if (signedAfter?.signedUrl) {
        setAfterUrl(signedAfter.signedUrl);
      } else {
        const { data: signedAfterFallback } = await supabase.storage
          .from('patient-photos')
          .createSignedUrl(data.simulation_url, 3600);
        setAfterUrl(signedAfterFallback?.signedUrl ?? null);
      }
      setLoading(false);
    };
    load();
  }, [id]);

  const procedureName = session?.selected_procedure || t('sessions.present.defaultProcedure');
  const intensity = session?.simulation_intensity
    ? t(`sessions.stage3.intensity.${session.simulation_intensity}`, { defaultValue: t('sessions.present.defaultIntensity') })
    : t('sessions.present.defaultIntensity');
  const patientName = session?.patient?.name || t('sessions.present.defaultPatient');
  // Nome e registro (CRM/CRO/CRBM/etc — genérico, ver profile.council no
  // Perfil) do profissional responsável, pra dar credibilidade/rastreabilidade
  // ao paciente sobre quem de fato conduziu o procedimento. A linha inteira
  // some quando não há full_name (perfil incompleto); o registro por si só
  // só aparece quando tipo e número estão os dois preenchidos — ver
  // formatProfessionalRegistration.
  const professionalRegistration = formatProfessionalRegistration(profile?.council_type, profile?.council_number);
  // Proveniência da análise que originou o plano apresentado — ver comentário
  // em SessionData.stage1_analysis acima e o carimbo no JSX mais abaixo.
  const analysisProv = analysisProvenance(session?.stage1_analysis as unknown as Stage1Analysis | null);

  // "O que será feito" precisa refletir o plano real da sessão (pontos de
  // aplicação de fato definidos na Etapa 2), não uma cópia genérica fixa —
  // do contrário o paciente vê sempre a mesma promessa ("4 pontos de
  // aplicação precisos") mesmo quando o plano real é outro. stage2_overlay
  // só existe a partir da Etapa 2; sessões antigas/sem plano caem no texto
  // genérico como fallback.
  const overlay = (session?.stage2_overlay as unknown as ApplicationPoint[] | null) ?? [];
  // Cada item traz, além da linha "Região — dose de Substância", uma
  // explicação clínica curta em linguagem de paciente (achado + objetivo,
  // sem a nota técnica de aplicação) quando o ponto vem de uma sugestão de
  // IA aceita na Etapa 1 — ver extractPatientExplanation. Pontos manuais
  // (sem justification) seguem mostrando só a dose, sem quebrar.
  const highlights: { key: string; text: string; explanation?: string }[] = overlay.length > 0
    ? overlay.map((point, index) => {
        const explanation = extractPatientExplanation(point.justification);
        return {
          key: point.id || `${point.region}-${index}`,
          text: t('sessions.present.highlightItem', {
            label: point.label,
            quantity: point.quantity,
            unit: point.unit,
            substance: SUBSTANCE_LABEL[point.substance],
          }),
          explanation: explanation
            ? formatPatientExplanation(explanation, (finding, clinicalGoal) =>
                t('sessions.present.highlightExplanation', { finding, clinicalGoal }),
              )
            : undefined,
        };
      })
    : (t('sessions.present.highlights', { returnObjects: true }) as string[]).map((text, index) => ({
        key: `${index}-${text}`,
        text,
      }));

  const handleWhatsApp = () => {
    void presentLink.sendWhatsApp();
  };

  const videoExport = useVideoExport({
    sessionId: id,
    beforeUrl,
    afterUrl,
    title: procedureName,
    caption: t('sessions.present.disclaimerTitle'),
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-h-white flex items-center justify-center">
        <div className="animate-pulse"><LogoMark size={48} /></div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="min-h-screen bg-h-white flex flex-col items-center justify-center gap-4 px-8 text-center">
        <LogoMark size={48} />
        <p className="text-[15px] font-bold text-h-text">{t('sessions.present.noSimulationTitle')}</p>
        <p className="text-[13px] text-h-text-2">{t('sessions.present.noSimulationBody')}</p>
        <GhostButton onClick={() => navigate(-1)} className="!w-auto !h-auto !min-h-[44px] px-4 text-[13px] mt-2">
          {t('sessions.present.noSimulationBack')}
        </GhostButton>
      </div>
    );
  }

  return (
    <PageTransition>
    <div ref={containerRef} className="min-h-screen bg-h-white flex flex-col">
      <div className="max-w-[430px] mx-auto w-full flex flex-col flex-1 px-5 pt-5 pb-6">
        {/* Header — em modo apresentação (tela cheia) fica reduzido a só o
            botão de sair, pra dar o máximo de espaço de tela pro
            antes/depois na frente do paciente; ver isFullscreen acima. */}
        {isFullscreen ? (
          <div className="flex items-center justify-end">
            <button
              type="button"
              onClick={exitFullscreen}
              aria-label={t('sessions.present.fullscreen.exit')}
              title={t('sessions.present.fullscreen.exit')}
              className="flex items-center gap-1.5 h-11 min-h-[44px] rounded-full px-4 text-[13px] font-bold text-h-g-start transition-all active:scale-[0.98]"
              style={{ backgroundColor: 'rgba(224,92,138,0.10)' }}
            >
              <Minimize2 size={16} />
              {t('sessions.present.fullscreen.exit')}
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <LogoMark size={28} />
                <span className="text-[14px] font-bold text-h-text-2">
                  {profile?.clinic_name || 'FacialPlan'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void enterFullscreen()}
                  aria-label={t('sessions.present.fullscreen.enter')}
                  title={t('sessions.present.fullscreen.enter')}
                  className="w-11 h-11 min-h-[44px] rounded-full flex items-center justify-center text-h-g-start transition-all active:scale-[0.98]"
                  style={{ backgroundColor: 'rgba(224,92,138,0.10)' }}
                >
                  <Maximize2 size={18} />
                </button>
                <GhostButton onClick={() => navigate(-1)} className="!w-auto !h-auto !min-h-[44px] px-4 text-[13px]">
                  ✕ {t('sessions.present.exit')}
                </GhostButton>
              </div>
            </div>

            {/* Profissional responsável — nome + registro (CRM/CRO/CRBM/etc),
                quando cadastrados no Perfil. Ver comentário no cálculo de
                professionalRegistration acima. */}
            {profile?.full_name && (
              <p className="text-[11px] text-h-text-3 mt-0.5">
                {professionalRegistration
                  ? t('sessions.present.responsibleProfessionalWithRegistration', {
                      name: profile.full_name,
                      registration: professionalRegistration,
                    })
                  : t('sessions.present.responsibleProfessional', { name: profile.full_name })}
              </p>
            )}

            {/* Divider */}
            <div className="my-3" style={{ borderBottom: '1px solid #E5E3E0' }} />
          </>
        )}

        {/* Proveniência da análise — esta é a tela mostrada AO PACIENTE (e
            espelhada no link público, ver SessaoPresentPublico.tsx), então o
            carimbo usa a versão de texto voltada ao paciente, sem a instrução
            operacional de refazer a análise. Fica acima do antes/depois de
            propósito: se o conteúdo é de demonstração, o paciente precisa
            saber disso antes de olhar o resultado simulado, não depois. Não
            renderiza nada quando a análise é de IA de verdade. */}
        {analysisProv !== 'ai' && (
          <div className="mb-4">
            <AnalysisProvenanceBanner provenance={analysisProv} audience="patient" />
          </div>
        )}

        {/* Session info */}
        <div className="text-center mb-4">
          <p className="text-[13px] text-h-text-2">{patientName}</p>
          <h2 className="text-[20px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>
            {t('sessions.present.resultTitle')}
          </h2>
        </div>

        {/* Before/After — sem altura fixa: ao contrário do slider original,
            o BeforeAfterViewer também traz a barra de modos (e, no modo
            Riscar, a paleta/ações) acima da foto, então a altura precisa
            variar por modo em vez de recortar num "hero" de 280px fixos. */}
        <div className="-mx-5 mb-4">
          <BeforeAfterViewer beforeImageUrl={beforeUrl ?? undefined} afterImageUrl={afterUrl ?? undefined} />
        </div>

        {/* Info cards */}
        <div className="grid grid-cols-2 gap-[10px] mb-4">
          <div className="bg-h-white rounded-[14px] shadow-h-sm p-3">
            <p style={{ fontSize: 11, fontWeight: 600, color: '#AAA8A5', marginBottom: 4 }}>{t('sessions.present.procedure')}</p>
            <p className="text-[14px] font-bold text-h-text mt-1">{procedureName}</p>
          </div>
          <div className="bg-h-white rounded-[14px] shadow-h-sm p-3">
            <p style={{ fontSize: 11, fontWeight: 600, color: '#AAA8A5', marginBottom: 4 }}>{t('sessions.present.intensity')}</p>
            <p className="text-[14px] font-bold mt-1" style={{ color: '#A855B5' }}>{intensity}</p>
          </div>
        </div>

        {/* What will be done */}
        <div className="bg-h-white rounded-[14px] shadow-h-sm p-4 mb-4">
          <p style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5', marginBottom: 12 }}>{t('sessions.present.whatWillBeDone')}</p>
          <div className="flex flex-col gap-3">
            {highlights.map((item) => (
              <div key={item.key} className="flex items-start gap-2.5">
                <div className="w-[6px] h-[6px] rounded-full flex-shrink-0 mt-[7px]" style={{ background: '#BF5F82' }} />
                <div>
                  <p className="text-[13px] text-h-text-2">{item.text}</p>
                  {item.explanation && (
                    <p className="text-[11.5px] text-h-text-3 leading-snug mt-0.5">{item.explanation}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Public link sharing — permite o profissional mandar o resultado
            pro paciente ver sem precisar de conta/login (ver
            useSessionPresentLink.ts e /present/:token). Fica antes do
            disclaimer de segurança pra manter aquele bloco crítico como o
            último item antes do CTA, como já era. */}
        <div className="bg-h-white rounded-[14px] shadow-h-sm p-4 mb-4">
          <p style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5', marginBottom: 8 }}>
            {t('sessions.present.publicLink.title')}
          </p>
          <p className="text-[12px] text-h-text-2 mb-3">
            {t('sessions.present.publicLink.description')}
          </p>
          <div className="flex gap-2">
            <SecondaryButton onClick={presentLink.copyLink} disabled={presentLink.busy || presentLink.loading} className="flex-1">
              🔗 {t('sessions.present.publicLink.copyButton')}
            </SecondaryButton>
            {presentLink.token && (
              <SecondaryButton onClick={presentLink.disableLink} disabled={presentLink.busy} className="!w-auto px-3">
                {t('sessions.present.publicLink.disableButton')}
              </SecondaryButton>
            )}
          </div>
        </div>

        {/* Central de Depoimentos/NPS — link separado do de apresentação
            acima (useSessionFeedbackLink.ts e /feedback/:token): pede pro
            paciente avaliar o atendimento depois de ver o resultado, em vez
            de misturar isso na mesma tela pública de apresentação (que é
            revisitável e sem uma ação de "enviar" clara). Some assim que o
            paciente já respondeu (feedbackLink.answered) — não há mais link
            útil pra copiar/mandar. */}
        <div className="bg-h-white rounded-[14px] shadow-h-sm p-4 mb-4">
          <p style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5', marginBottom: 8 }}>
            {t('sessions.feedback.publicLink.title')}
          </p>
          {feedbackLink.answered ? (
            <p className="text-[12px] font-semibold" style={{ color: '#1D9A64' }}>
              {t('sessions.feedback.publicLink.answeredNotice')}
            </p>
          ) : (
            <>
              <p className="text-[12px] text-h-text-2 mb-3">
                {t('sessions.feedback.publicLink.description')}
              </p>
              <SecondaryButton onClick={feedbackLink.copyLink} disabled={feedbackLink.busy || feedbackLink.loading} className="w-full">
                🔗 {t('sessions.feedback.publicLink.copyButton')}
              </SecondaryButton>
            </>
          )}
        </div>

        {/* Vídeo antes/depois — gerado 100% client-side (Canvas 2D +
            WebCodecs, com fallback para MediaRecorder só quando o resultado
            é H.264 real de verdade; ver src/lib/videoExport.ts) para o
            profissional enviar como mídia de vídeo, não só o link de texto. */}
        <div className="bg-h-white rounded-[14px] shadow-h-sm p-4 mb-4">
          <p style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5', marginBottom: 8 }}>
            {t('sessions.present.video.title')}
          </p>
          <p className="text-[12px] text-h-text-2 mb-3">
            {t('sessions.present.video.description')}
          </p>
          {videoExport.status === 'ready' ? (
            <div className="flex gap-2">
              <SecondaryButton onClick={() => void videoExport.share()} className="flex-1">
                {videoExport.canShareFiles
                  ? t('sessions.present.video.shareButton')
                  : t('sessions.present.video.downloadButton')}
              </SecondaryButton>
              <SecondaryButton onClick={() => void videoExport.generate()} className="!w-auto px-3">
                {t('sessions.present.video.regenerateButton')}
              </SecondaryButton>
            </div>
          ) : (
            <>
              <SecondaryButton
                onClick={() => void videoExport.generate()}
                disabled={videoExport.status === 'generating'}
                className="w-full"
              >
                {videoExport.status === 'generating'
                  ? t('sessions.present.video.generatingLabel', { percent: Math.round(videoExport.progress * 100) })
                  : t('sessions.present.video.generateButton')}
              </SecondaryButton>
              {videoExport.status === 'generating' && (
                <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{ background: '#F0EEEC' }}>
                  <div
                    className="h-full bg-gradient-brand transition-all"
                    style={{ width: `${Math.round(videoExport.progress * 100)}%` }}
                  />
                </div>
              )}
            </>
          )}
        </div>

        {/* Disclaimer — tela voltada ao paciente: precisa ser pelo menos tão
            forte e visível quanto o disclaimer do profissional (Etapa 3),
            já que é aqui que a expectativa do paciente é de fato formada. */}
        <div
          className="rounded-r p-4 mb-4"
          style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
        >
          <div className="flex items-center gap-2 mb-1.5">
            <Info size={16} className="flex-shrink-0" style={{ color: '#D4900A' }} />
            <p className="text-[13px] font-bold" style={{ color: '#D4900A' }}>
              {t('sessions.present.disclaimerTitle')}
            </p>
          </div>
          <p className="text-[12px] text-h-text-2 leading-relaxed">
            {t('sessions.present.disclaimer')}
          </p>
        </div>

        {/* Frase de confiança do guardrail anatômico (backlog P2) — só
            exibida porque o prompt enviado à Gemini em generate-simulation
            de fato instrui limites anatômicos plausíveis (ver
            ANATOMICAL_SAFETY_INSTRUCTION em generate-simulation/index.ts);
            não é uma validação da imagem gerada, só do que foi pedido à IA. */}
        <div className="flex items-center justify-center gap-1.5 mb-4">
          <ShieldCheck size={13} className="flex-shrink-0" style={{ color: '#1A9E5C' }} />
          <p className="text-[11px] font-semibold text-h-text-2 text-center">
            {t('sessions.present.anatomicalGuardrail')}
          </p>
        </div>

        {/* WhatsApp CTA */}
        <div className="mt-auto">
          <GradientButton onClick={handleWhatsApp} className="w-full">
            {t('sessions.present.sendWhatsApp')}
          </GradientButton>
        </div>
      </div>
    </div>
    </PageTransition>
  );
};

export default SessaoPresent;
