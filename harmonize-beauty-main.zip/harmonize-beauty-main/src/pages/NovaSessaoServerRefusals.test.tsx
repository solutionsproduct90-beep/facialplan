import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import NovaSessao, { MOCK_ANALYSIS } from "./NovaSessao";
import i18n from "@/i18n";

// jsdom não implementa URL.createObjectURL — só usado pro preview visual da
// foto, irrelevante para os testes abaixo.
if (!URL.createObjectURL) {
  URL.createObjectURL = vi.fn(() => "blob:mock");
}

// Mesmo motivo de NovaSessaoMultiAngle.test.tsx: acelera os dois setTimeout
// reais de handleAnalyze (MIN_SCAN_DISPLAY_MS + 350ms) sem trocar pra fake
// timers completos, que quebrariam o polling do `waitFor`.
const realSetTimeout = globalThis.setTimeout;
beforeEach(() => {
  vi.stubGlobal("setTimeout", ((fn: (...args: unknown[]) => void, _ms?: number, ...args: unknown[]) =>
    realSetTimeout(fn, 0, ...args)) as typeof setTimeout);
});
afterEach(() => {
  vi.unstubAllGlobals();
});

// Achado do QA Contínuo: `handleAnalyze` (NovaSessao.tsx) só tratava a recusa
// de consentimento do paciente como caso especial — qualquer outro erro da
// invocação de `analyze-face` (incluindo 402 "assinatura inativa" do gate de
// _shared/subscriptionGate.ts) caía direto no fallback de análise MOCK, com
// só um toast vago de "IA indisponível". Um profissional inadimplente
// recebia, em silêncio, uma análise fabricada gravada no prontuário do
// paciente, sem nenhuma indicação de que precisava regularizar o pagamento.
// Estes testes fixam os três caminhos possíveis depois da correção (ver
// src/lib/edgeFunctionError.ts): recusa de assinatura, recusa de
// consentimento (regressão — já tratada, mas sem cobertura direta neste
// arquivo até agora) e falha "de verdade" (sem corpo de erro do servidor),
// que deve continuar caindo no fallback de demonstração como sempre.
const useAuthMock = vi.fn();
const fromMock = vi.fn();
const storageFromMock = vi.fn();
const uploadMock = vi.fn();
const invokeMock = vi.fn();
const navigateMock = vi.fn();
const toastErrorMock = vi.fn();
const toastInfoMock = vi.fn();
const toastWarningMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: { from: (...args: unknown[]) => storageFromMock(...args) },
    functions: { invoke: (...args: unknown[]) => invokeMock(...args) },
  },
}));

vi.mock("sonner", () => ({
  toast: {
    error: (...args: unknown[]) => toastErrorMock(...args),
    info: (...args: unknown[]) => toastInfoMock(...args),
    warning: (...args: unknown[]) => toastWarningMock(...args),
    success: vi.fn(),
  },
}));

const PATIENT = { id: "pat-1", name: "Maria Silva", consent_given: true, phone: null };

function patientsBuilder() {
  const builder = {
    select: () => builder,
    eq: () => builder,
    order: () => Promise.resolve({ data: [PATIENT], error: null }),
    single: () => Promise.resolve({ data: PATIENT, error: null }),
  };
  return builder;
}

const sessionsUpdateSpy = vi.fn();

function sessionsBuilder() {
  const builder = {
    insert: () => builder,
    select: () => builder,
    single: () => Promise.resolve({ data: { id: "session-1" }, error: null }),
    update: (payload: unknown) => {
      sessionsUpdateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter
      initialEntries={[{ pathname: "/sessoes/nova", state: { preselectedPatientId: "pat-1", preselectedPatientName: "Maria Silva" } }]}
    >
      <Routes>
        <Route path="/sessoes/nova" element={<NovaSessao />} />
      </Routes>
    </MemoryRouter>
  );

const goToUploadStep = async () => {
  renderPage();
  await screen.findByText("Maria Silva");
  return screen.getByText(/Analisar foto/);
};

const frontalFile = () => new File(["frontal-bytes"], "frontal.jpg", { type: "image/jpeg" });

/** Imita o `FunctionsHttpError` do supabase-js: a Response crua em `context`
 * (ver src/lib/edgeFunctionError.ts e o mesmo helper em SessaoEstagio2.test.tsx). */
function refusalInvokeResult(body: unknown, status: number) {
  return {
    data: null,
    error: {
      message: "Edge Function returned a non-2xx status code",
      context: new Response(JSON.stringify(body), {
        status,
        headers: { "Content-Type": "application/json" },
      }),
    },
  };
}

describe("NovaSessao — recusas do servidor em handleAnalyze (assinatura, consentimento, indisponibilidade real)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" } });
    fromMock.mockReset();
    storageFromMock.mockReset();
    uploadMock.mockReset();
    invokeMock.mockReset();
    navigateMock.mockReset();
    toastErrorMock.mockReset();
    toastInfoMock.mockReset();
    toastWarningMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return patientsBuilder();
      if (table === "sessions") return sessionsBuilder();
      throw new Error(`unexpected table ${table}`);
    });
    storageFromMock.mockImplementation(() => ({ upload: (...args: unknown[]) => uploadMock(...args) }));
    uploadMock.mockResolvedValue({ error: null });
  });

  it("blocks the flow and shows the server's subscription refusal message instead of recording a mock analysis (402)", async () => {
    invokeMock.mockResolvedValue(
      refusalInvokeResult({ error: "Assinatura inativa. Regularize seu pagamento para continuar usando a análise por IA." }, 402),
    );

    await goToUploadStep();
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fireEvent.change(fileInputs[0], { target: { files: [frontalFile()] } });
    fireEvent.click(await screen.findByText(/Analisar foto/));

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith(
        "Assinatura inativa. Regularize seu pagamento para continuar usando a análise por IA.",
      ),
    );

    // Nenhuma análise (real ou mock) foi gravada no prontuário — o fluxo foi
    // bloqueado ANTES do fallback mock, e a navegação pra Etapa 1 nunca
    // aconteceu.
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
    expect(navigateMock).not.toHaveBeenCalled();
    expect(toastInfoMock).not.toHaveBeenCalled();

    // Volta pra Etapa 2 (upload) em vez de ficar preso na tela de carregamento.
    expect(await screen.findByText(/Analisar foto/)).toBeInTheDocument();
  });

  it("blocks the flow and shows the server's consent refusal message instead of recording a mock analysis (451)", async () => {
    invokeMock.mockResolvedValue(
      refusalInvokeResult(
        {
          error: "Consentimento do paciente não registrado. Colha o termo na ficha do paciente.",
          code: "patient_consent_required",
        },
        451,
      ),
    );

    await goToUploadStep();
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fireEvent.change(fileInputs[0], { target: { files: [frontalFile()] } });
    fireEvent.click(await screen.findByText(/Analisar foto/));

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith(
        "Consentimento do paciente não registrado. Colha o termo na ficha do paciente.",
      ),
    );

    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
    expect(navigateMock).not.toHaveBeenCalled();
  });

  it("still falls back to the demo analysis for a real failure with no server error body (network/function down)", async () => {
    invokeMock.mockResolvedValue({
      data: null,
      error: { message: "Failed to fetch" },
    });

    await goToUploadStep();
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fireEvent.change(fileInputs[0], { target: { files: [frontalFile()] } });
    fireEvent.click(await screen.findByText(/Analisar foto/));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled(), { timeout: 4000 });
    const [payload] = sessionsUpdateSpy.mock.calls[0] as [Record<string, unknown>];
    expect(payload.stage1_analysis).toEqual(MOCK_ANALYSIS);
    expect(toastInfoMock).toHaveBeenCalled();
    expect(toastErrorMock).not.toHaveBeenCalled();

    await waitFor(
      () => expect(navigateMock).toHaveBeenCalledWith("/sessoes/session-1/estagio-1"),
      { timeout: 4000 },
    );
  }, 8000);
});
