import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Home from './Home';
import i18n from '@/i18n';

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const updateSpy = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

/** Builder genérico o bastante pra cobrir as três queries que o Home dispara
 * (`profiles` com `.single()`, `sessions` e `patients` sem `.single()` mas
 * awaited diretamente como thenable) — encadeia qualquer método usado e
 * resolve com `result` ao ser awaited ou ao chamar `.single()`. */
function makeBuilder(result: { data: unknown; error: unknown }) {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    not: () => builder,
    order: () => builder,
    limit: () => builder,
    single: () => Promise.resolve(result),
    then: (onFulfilled: (v: unknown) => unknown, onRejected?: (e: unknown) => unknown) =>
      Promise.resolve(result).then(onFulfilled, onRejected),
    update: (payload: Record<string, unknown>) => {
      updateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
  return builder;
}

const renderHome = () =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    </QueryClientProvider>,
  );

const mockTables = (profileRow: Record<string, unknown> | null) => {
  fromMock.mockImplementation((table: string) => {
    if (table === 'profiles') return makeBuilder({ data: profileRow, error: null });
    if (table === 'sessions') return makeBuilder({ data: [], error: null });
    if (table === 'patients') return makeBuilder({ data: [], error: null });
    throw new Error(`unexpected table ${table}`);
  });
};

describe('Home — onboarding pós-cadastro', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    fromMock.mockReset();
    updateSpy.mockReset();
  });

  it('shows the onboarding modal for a professional who never completed it (onboarding_completed_at is null)', async () => {
    mockTables({ id: 'pro-1', full_name: 'Ana', onboarding_completed_at: null });
    renderHome();

    expect(await screen.findByText('Bem-vindo ao FacialPlan')).toBeInTheDocument();
    expect(screen.getByText('Cadastre seu primeiro paciente')).toBeInTheDocument();
  });

  it('does not show the onboarding modal for a professional who already completed it', async () => {
    mockTables({ id: 'pro-1', full_name: 'Ana', onboarding_completed_at: '2026-01-01T00:00:00Z' });
    renderHome();

    // Espera o Home terminar de carregar (algo que só aparece pós-fetch)
    // antes de afirmar a ausência do modal — senão o teste passaria mesmo
    // que o modal só demorasse a aparecer.
    expect(await screen.findByText('Nova sessão')).toBeInTheDocument();
    expect(screen.queryByText('Bem-vindo ao FacialPlan')).not.toBeInTheDocument();
  });

  it('marks the profile as completed in the database as soon as the professional skips it', async () => {
    mockTables({ id: 'pro-1', full_name: 'Ana', onboarding_completed_at: null });
    renderHome();

    await screen.findByText('Bem-vindo ao FacialPlan');
    fireEvent.click(screen.getByRole('button', { name: 'Pular' }));

    // A sheet (vaul) roda uma transição de saída em CSS real antes de
    // desmontar o conteúdo do DOM — em jsdom essa transição nunca "termina"
    // de verdade, então a asserção de UI relevante aqui é sobre o efeito
    // que importa de fato para o requisito de negócio (não reaparecer):
    // gravar `onboarding_completed_at` assim que a pessoa fecha, e não só
    // ao concluir o último passo do wizard.
    await waitFor(() =>
      expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ onboarding_completed_at: expect.any(String) })),
    );
  });

});
