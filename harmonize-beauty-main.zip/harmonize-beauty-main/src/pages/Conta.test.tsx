import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Conta from './Conta';
import i18n from '@/i18n';
import type { AccessProfile } from '@/contexts/AuthContext';

// Achado de auditoria: a badge desta tela comparava só
// `subscription_status === 'active'`, então um profissional em 'past_due'
// DENTRO da carência (acesso normal ao app, banner amarelo do
// SubscriptionGraceBanner) via a badge dizer "Inativo" — mensagem
// contraditória com o app funcionando normalmente. Este arquivo prova que a
// badge agora segue a MESMA regra usada por ProtectedRoute/paywall
// (`hasAppAccess`, de src/lib/subscriptionAccess.ts), em vez de uma
// comparação própria e mais estrita.

const useAuthMock = vi.fn();

vi.mock('@/contexts/AuthContext', async () => {
  const actual = await vi.importActual<typeof import('@/contexts/AuthContext')>('@/contexts/AuthContext');
  return { ...actual, useAuth: () => useAuthMock() };
});

vi.mock('sonner', () => ({ toast: { info: vi.fn() } }));

const DAY_MS = 24 * 60 * 60 * 1000;

function profile(overrides: Partial<AccessProfile> = {}): AccessProfile {
  return {
    is_blocked: false,
    subscription_status: 'active',
    role: 'professional',
    past_due_since: null,
    ...overrides,
  };
}

function renderConta(p: AccessProfile | null) {
  useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, profile: p });
  return render(
    <MemoryRouter>
      <Conta />
    </MemoryRouter>,
  );
}

describe('Conta — badge de status da assinatura', () => {
  beforeEach(async () => {
    useAuthMock.mockReset();
    await i18n.changeLanguage('pt');
  });

  it('mostra "Ativo" para subscription_status active', () => {
    renderConta(profile());
    expect(screen.getByText('Ativo')).toBeInTheDocument();
    expect(screen.queryByText('Inativo')).not.toBeInTheDocument();
  });

  it('mostra "Ativo" (não "Inativo") para past_due DENTRO da carência — o app continua funcionando', () => {
    const since = new Date(Date.now() - 1 * DAY_MS).toISOString();
    renderConta(profile({ subscription_status: 'past_due', past_due_since: since }));
    expect(screen.getByText('Ativo')).toBeInTheDocument();
    expect(screen.queryByText('Inativo')).not.toBeInTheDocument();
  });

  it('mostra "Inativo" para past_due FORA da carência', () => {
    const since = new Date(Date.now() - 10 * DAY_MS).toISOString();
    renderConta(profile({ subscription_status: 'past_due', past_due_since: since }));
    expect(screen.getByText('Inativo')).toBeInTheDocument();
  });

  it('mostra "Inativo" para quem nunca assinou (default \'inactive\')', () => {
    renderConta(profile({ subscription_status: 'inactive' }));
    expect(screen.getByText('Inativo')).toBeInTheDocument();
  });

  it('mostra "Inativo" para cancelado/reembolsado', () => {
    renderConta(profile({ subscription_status: 'canceled' }));
    expect(screen.getByText('Inativo')).toBeInTheDocument();
  });

  it('mostra "Inativo" enquanto o perfil ainda não carregou (sem profile)', () => {
    renderConta(null);
    expect(screen.getByText('Inativo')).toBeInTheDocument();
  });
});
