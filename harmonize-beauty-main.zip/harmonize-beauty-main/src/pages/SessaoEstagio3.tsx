import React, { useState, useEffect, useMemo } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import TopBar from '@/components/harmonize/TopBar';
import StageDots from '@/components/harmonize/StageDots';
import GradientButton from '@/components/harmonize/GradientButton';
import GhostButton from '@/components/harmonize/GhostButton';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import BeforeAfterViewer from '@/components/harmonize/BeforeAfterViewer';
import LogoMark from '@/components/harmonize/LogoMark';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { toast } from 'sonner';
import { buildLastToxinDatesByRegion, TOXIN_HISTORY_EXCLUDED_STATUS } from '@/lib/toxinHistory';
// Import só de TIPO (apagado no build, custo zero de bundle) — o valor de
// runtime é carregado dinamicamente dentro de `handleExportPdf`, a única
// função que de fato usa a lib (ver comentário lá). `jspdf` pesa ~350KB
// minificado e antes entrava no chunk desta tela mesmo pra quem nunca clica
// em exportar PDF.
import type { jsPDF } from 'jspdf';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { MessageCircle, Mail, FileDown, FileText, ShieldCheck } from 'lucide-react';
import type { ApplicationPoint, Insumo, Stage1Analysis, Substance } from '@/types/harmonize';
import { SUBSTANCE_LABEL } from '@/types/harmonize';
import { regionLabel } from '@/lib/faceRegions';
import { computeBudget, computeInstallments, computeCashDiscount, formatCurrency, normalizeInsumos, priceForPoint, type BudgetBreakdown, type Installment, type CurrencyCode } from '@/lib/budget';
import { hasClinicalAnalysisContent, facialAnalysisRows, facialThirdsRows, hasCareInstructionsContent } from '@/lib/clinicalAnalysisPdf';
import AnalysisProvenanceBanner from '@/components/harmonize/AnalysisProvenanceBanner';
import { analysisProvenance, provenanceStampKeys, patientProvenanceStampKeys } from '@/lib/analysisProvenance';
import {
  computeSessionComplianceSummary,
  COMPLIANCE_GATE_ORDER,
  type SessionComplianceSummary,
  type ComplianceGateKey,
} from '@/lib/complianceSummary';
import { postProcedureChecklistSections, postProcedureChecklistShareText, postProcedureEmergencyWarning } from '@/lib/postProcedureChecklist';
import { ensureSpace as ensureSpaceOnPage } from '@/lib/pdfLayout';
import { procedureDisplayName, reduceToPlanB, hasReducedPlanB } from '@/lib/procedureCatalog';
import { protocolDisplayName } from '@/lib/namedProtocols';
import { generateQrCodeDataUrl } from '@/lib/qrCode';
import { useSessionPresentLink } from '@/hooks/useSessionPresentLink';
import { logDataAccess } from '@/lib/auditLog';
import { isValidEmail } from '@/lib/email';
import { aggregateConsumptionByInsumo } from '@/lib/stockBatches';
import { isPatientConsentRefusal, readEdgeFunctionError } from '@/lib/edgeFunctionError';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

// Achatamento em texto corrido da justificativa estruturada de um
// ApplicationPoint (achado observado / objetivo clínico / nota de técnica —
// ver JustificationParts em src/types/harmonize.ts) pra uso no PDF, que
// desenha texto plano via jsPDF (sem markup/headings por trecho, diferente
// da Etapa 1 na tela). Aceita defensivamente o formato antigo (string única)
// que um ponto persistido ANTES da migração para justificativa em 3 partes
// ainda pode trazer do banco — sem isso, um plano antigo reaberto no
// Estágio 3 quebraria o PDF em vez de só exibir a justificativa "achatada".
function justificationPdfText(justification: ApplicationPoint['justification']): string {
  if (!justification) return '';
  if (typeof justification === 'string') return justification;
  return [justification.finding, justification.clinicalGoal, justification.technicalNote]
    .filter(Boolean)
    .join('  ');
}

// Paleta de marca do app (ver tailwind.config.ts, tokens `h-g-start/mid/end`
// e demais tokens `h-*`) reaproveitada no PDF, que é desenhado manualmente
// via jsPDF (sem template HTML) e por isso não herda classes Tailwind.
const PDF_COLORS = {
  gStart: [224, 92, 138],
  gMid: [168, 85, 181],
  gEnd: [124, 90, 194],
  text: [26, 25, 24],
  text2: [107, 105, 101],
  text3: [170, 168, 165],
  surface: [247, 246, 244],
  surface3: [229, 227, 224],
  white: [255, 255, 255],
  green: [45, 184, 122],
  // Mesmo âmbar de acento já usado na paleta de marca (ver tailwind.config.ts
  // `h.amber`) — reaproveitado aqui só para o indicador "atenção" (nunca
  // vermelho/erro: os gates do selo de conformidade são uma trilha
  // informativa, não uma reprovação, ver src/lib/complianceSummary.ts).
  amber: [212, 144, 10],
  // Mesmo vermelho (#E05050) já usado no alerta de zona de risco vascular do
  // Estágio 2 (ver SessaoEstagio2.tsx) — reservado só para a seção de sinais
  // de alerta de emergência abaixo, o único conteúdo deste PDF que é de fato
  // uma orientação de segurança urgente, não uma trilha informativa.
  red: [224, 80, 80],
} as const;

// Clareia uma cor da marca em direção ao branco — usado para fundos sutis
// (ex.: o card de orçamento) que ainda carregam a identidade visual sem
// competir com o texto.
const pdfTint = (color: readonly [number, number, number], amount: number): [number, number, number] => [
  Math.round(color[0] + (255 - color[0]) * amount),
  Math.round(color[1] + (255 - color[1]) * amount),
  Math.round(color[2] + (255 - color[2]) * amount),
];

// jsPDF não tem preenchimento em gradiente nativo — simulamos desenhando
// muitas fatias verticais finas com a cor interpolada entre os stops.
const drawPdfGradient = (
  doc: jsPDF,
  x: number,
  y: number,
  w: number,
  h: number,
  stops: readonly (readonly [number, number, number])[],
) => {
  const slices = 64;
  const sliceW = w / slices;
  for (let i = 0; i < slices; i++) {
    const progress = i / (slices - 1);
    const segCount = stops.length - 1;
    const segPos = progress * segCount;
    const segIdx = Math.min(Math.floor(segPos), segCount - 1);
    const localT = segPos - segIdx;
    const from = stops[segIdx];
    const to = stops[segIdx + 1];
    const r = Math.round(from[0] + (to[0] - from[0]) * localT);
    const g = Math.round(from[1] + (to[1] - from[1]) * localT);
    const b = Math.round(from[2] + (to[2] - from[2]) * localT);
    doc.setFillColor(r, g, b);
    // sliceW + 0.75 evita frestas brancas entre as fatias por arredondamento
    doc.rect(x + sliceW * i, y, sliceW + 0.75, h, 'F');
  }
};

const SessaoEstagio3: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  // Link público de apresentação (/present/:token) reaproveitado como URL de
  // verificação do QR code do PDF do paciente — ver comentário de arquivo em
  // src/lib/qrCode.ts pra decisão de escopo completa.
  const { ensureLink: ensurePresentLink } = useSessionPresentLink(id);
  const [intensity, setIntensity] = useState<'sutil' | 'natural' | 'marcante'>('natural');
  const [genState, setGenState] = useState<'idle' | 'generating' | 'done'>('idle');
  const [genMsg, setGenMsg] = useState(0);
  const [variationCount, setVariationCount] = useState(1);
  const [loading, setLoading] = useState(true);
  const [patientId, setPatientId] = useState<string | null>(null);
  const [patientEmail, setPatientEmail] = useState<string | null>(null);
  const [beforeUrl, setBeforeUrl] = useState<string | null>(null);
  const [afterUrl, setAfterUrl] = useState<string | null>(null);
  const [stage2Overlay, setStage2Overlay] = useState<ApplicationPoint[]>([]);
  const [stage1Analysis, setStage1Analysis] = useState<Stage1Analysis | null>(null);
  const [insumos, setInsumos] = useState<Insumo[] | null>(null);
  const [laborFeePerSession, setLaborFeePerSession] = useState<number | null>(null);
  const [maxInstallments, setMaxInstallments] = useState<number | null>(null);
  const [cashDiscountPct, setCashDiscountPct] = useState<number | null>(null);
  const [currency, setCurrency] = useState<CurrencyCode>('BRL');
  // Orientações pré/pós-procedimento (backlog P1, v1 reduzida): texto único
  // configurado pelo profissional em Perfil.tsx (profiles.pre_post_care_instructions),
  // não por procedimento específico do catálogo — ver decisão de escopo no
  // comentário de `hasCareInstructionsContent` em clinicalAnalysisPdf.ts.
  // Anexado à seção "Orientações" do PDF (handleExportPdf) e ao final das
  // mensagens de WhatsApp/e-mail (handleShareWhatsApp/handleShareEmail)
  // quando preenchido; ausente/vazio omite ambos sem deixar rastro.
  const [careInstructions, setCareInstructions] = useState<string | null>(null);
  const [complianceSummary, setComplianceSummary] = useState<SessionComplianceSummary | null>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [pdfData, setPdfData] = useState<{
    patientName: string;
    procedureName: string;
    clinicName: string | null;
    professionalName: string | null;
    logoUrl: string | null;
  } | null>(null);

  const simMessages = t('sessions.stage3.messages', { returnObjects: true }) as string[];

  useEffect(() => {
    if (!id || !user) return;
    const load = async () => {
      const { data: session } = await supabase
        .from('sessions')
        .select('patient_id, selected_procedure, stage2_overlay, original_image_url, simulation_url, simulation_intensity, stage1_analysis, created_at')
        .eq('id', id)
        .single();
      if (!session) { setLoading(false); return; }

      setPatientId(session.patient_id);
      setStage2Overlay((session.stage2_overlay as unknown as ApplicationPoint[] | null) ?? []);
      setStage1Analysis((session.stage1_analysis as unknown as Stage1Analysis | null) ?? null);

      // Uma simulação já gerada antes (voltando pra essa tela depois de já ter
      // rodado) fica salva em sessions.simulation_url — sem isso, toda vez que
      // o profissional reabre a sessão teria que gerar de novo do zero.
      if (session.simulation_intensity) {
        setIntensity(session.simulation_intensity as 'sutil' | 'natural' | 'marcante');
      }
      if (session.simulation_url) {
        if (session.original_image_url) {
          const { data: signedBefore } = await supabase.storage
            .from('patient-photos')
            .createSignedUrl(session.original_image_url, 3600);
          if (signedBefore?.signedUrl) setBeforeUrl(signedBefore.signedUrl);
        }
        // A simulação real fica em simulation-results; no modo mock (sem
        // GEMINI_API_KEY) ela reaproveita o path da foto original, que vive
        // em patient-photos — tenta o bucket certo com fallback pro outro.
        const { data: signedAfter } = await supabase.storage
          .from('simulation-results')
          .createSignedUrl(session.simulation_url, 3600);
        if (signedAfter?.signedUrl) {
          setAfterUrl(signedAfter.signedUrl);
        } else {
          const { data: signedAfterFallback } = await supabase.storage
            .from('patient-photos')
            .createSignedUrl(session.simulation_url, 3600);
          if (signedAfterFallback?.signedUrl) setAfterUrl(signedAfterFallback.signedUrl);
        }
        setGenState('done');
      }

      const [
        { data: patient },
        { data: profile },
        { data: insumosData },
        { data: anamnesis },
        { data: procedureConsentRow },
        { data: skinScreeningRow },
        { data: pastSessions },
      ] = await Promise.all([
        supabase.from('patients').select('name, email, consent_given, last_consent_at').eq('id', session.patient_id).single(),
        supabase.from('profiles').select('full_name, clinic_name, logo_url, labor_fee_per_session, max_installments, cash_discount_pct, currency, pre_post_care_instructions').eq('id', user.id).single(),
        supabase
          .from('insumos')
          .select('id, substance, brand_name, cost_per_unit, price_per_unit, active')
          .eq('professional_id', user.id),
        // Selo de conformidade clínica (P6-2) — mesma checagem "existe
        // anamnese para este PACIENTE" do gate P0-4 em SessaoEstagio1.tsx,
        // não por sessão.
        supabase.from('anamnesis').select('created_at').eq('patient_id', session.patient_id).maybeSingle(),
        // TCLE por procedimento (P0-3) desta sessão específica.
        supabase
          .from('consents')
          .select('created_at, consent_text, ip_address')
          .eq('session_id', id)
          .eq('consent_type', 'procedimento')
          .maybeSingle(),
        // Triagem ABCDE (P0-1) desta sessão específica.
        supabase
          .from('skin_screenings')
          .select('has_suspicious_finding, referred_to_dermatology, proceeded_despite_finding, proceed_justification, updated_at')
          .eq('session_id', id)
          .maybeSingle(),
        // Histórico de sessões anteriores desta paciente, mesma query de
        // SessaoEstagio2.tsx (lastToxinDatesByRegion) — base do gate
        // opcional de intervalo mínimo entre aplicações de toxina. O critério
        // de "aplicação realizada" vive em src/lib/toxinHistory.ts.
        supabase
          .from('sessions')
          .select('created_at, stage2_overlay')
          .eq('patient_id', session.patient_id)
          .neq('status', TOXIN_HISTORY_EXCLUDED_STATUS)
          .neq('id', id),
      ]);

      setPdfData({
        patientName: patient?.name || t('sessions.stage3.pdf.defaultPatient'),
        procedureName: session.selected_procedure || t('sessions.stage3.pdf.defaultProcedure'),
        clinicName: profile?.clinic_name ?? null,
        professionalName: profile?.full_name ?? null,
        logoUrl: profile?.logo_url ?? null,
      });
      setPatientEmail(patient?.email ?? null);
      setLaborFeePerSession(profile?.labor_fee_per_session ?? null);
      setMaxInstallments(profile?.max_installments ?? null);
      setCashDiscountPct(profile?.cash_discount_pct ?? null);
      setCurrency((profile?.currency as CurrencyCode) ?? 'BRL');
      setCareInstructions(profile?.pre_post_care_instructions ?? null);
      setInsumos(normalizeInsumos(insumosData));

      // Selo de conformidade clínica (P6-2, ver src/lib/complianceSummary.ts)
      // — mesmo cálculo que o Alerta de Intervalo Mínimo faz ao vivo em
      // SessaoEstagio2.tsx, agora pela função compartilhada em vez de uma
      // cópia deste laço (que era como as duas telas herdavam o mesmo filtro
      // de status errado).
      const priorToxinDatesByRegion = buildLastToxinDatesByRegion(pastSessions);

      setComplianceSummary(
        computeSessionComplianceSummary({
          sessionId: id,
          sessionCreatedAt: session.created_at,
          applicationPoints: (session.stage2_overlay as unknown as ApplicationPoint[] | null) ?? [],
          skinScreening: skinScreeningRow
            ? {
                hasSuspiciousFinding: skinScreeningRow.has_suspicious_finding,
                referredToDermatology: skinScreeningRow.referred_to_dermatology,
                proceededDespiteFinding: skinScreeningRow.proceeded_despite_finding,
                proceedJustification: skinScreeningRow.proceed_justification,
                updatedAt: skinScreeningRow.updated_at,
              }
            : null,
          anamnesisCreatedAt: anamnesis?.created_at ?? null,
          patientConsentGiven: patient?.consent_given ?? null,
          patientLastConsentAt: patient?.last_consent_at ?? null,
          procedureConsent: procedureConsentRow
            ? {
                createdAt: procedureConsentRow.created_at,
                consentText: procedureConsentRow.consent_text,
                ipAddress: procedureConsentRow.ip_address,
              }
            : null,
          priorToxinDatesByRegion,
        }),
      );

      setLoading(false);
    };
    load();
  }, [id, user]);

  const runSimulation = async () => {
    if (!id || !patientId) return;
    setGenState('generating');
    setGenMsg(0);
    const interval = setInterval(() => {
      setGenMsg(prev => Math.min(prev + 1, simMessages.length - 1));
    }, 1500);

    try {
      const { data, error } = await supabase.functions.invoke('generate-simulation', {
        body: { sessionId: id, patientId, intensity },
      });

      const response = data as {
        simulationUrl: string | null;
        originalUrl: string | null;
        source: 'ai' | 'mock';
        error?: string;
        consentWarning?: string;
      } | null;

      if (error || !response || response.error) {
        // Numa resposta não-2xx o supabase-js guarda o corpo em
        // `error.context` e nunca o lê — sem isto, a recusa por falta de
        // consentimento do paciente (451, gate do squad w1-3, ver
        // supabase/functions/_shared/consentGate.ts) chegaria aqui como o
        // "non-2xx status code" genérico do SDK, escondendo justamente a
        // instrução de como destravar. Ver src/lib/edgeFunctionError.ts.
        const errorBody = await readEdgeFunctionError(error, data);
        if (isPatientConsentRefusal(errorBody)) {
          throw new Error(errorBody?.error || t('sessions.stage3.toastConsentRequired'));
        }
        throw new Error(errorBody?.error || error?.message || t('sessions.stage3.toastGenerationFailed'));
      }

      setBeforeUrl(response.originalUrl);
      setAfterUrl(response.simulationUrl);

      if (response.source === 'mock') {
        toast.info(t('sessions.stage3.toastMockSimulation'));
      }
      // Paciente legado dentro da janela de regularização (ver consentGate.ts).
      if (response.consentWarning) {
        toast.warning(t('sessions.stage3.toastConsentLegacy'));
      }
      setGenState('done');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('sessions.stage3.toastGenericError');
      toast.error(message);
      setGenState('idle');
    } finally {
      clearInterval(interval);
    }
  };

  const handleGenerate = () => {
    runSimulation();
  };

  const handleNewVariation = () => {
    if (variationCount >= 3) {
      toast.info(t('sessions.stage3.maxVariations'));
      return;
    }
    setVariationCount(prev => prev + 1);
    runSimulation();
  };

  const fetchImageAsDataUrl = async (url: string): Promise<string | null> => {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      return await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch {
      return null;
    }
  };

  const getImageFormatFromDataUrl = (dataUrl: string): 'PNG' | 'JPEG' | 'WEBP' => {
    const ext = /^data:image\/(\w+);/i.exec(dataUrl)?.[1]?.toLowerCase();
    if (ext === 'jpeg' || ext === 'jpg') return 'JPEG';
    if (ext === 'webp') return 'WEBP';
    return 'PNG';
  };

  // "Enviar por WhatsApp"/"Enviar por e-mail" montavam uma mensagem de texto
  // fixa ("Segue o seu plano...") sem NENHUM link ou anexo — wa.me/mailto:
  // não conseguem anexar arquivo nenhum (limitação do próprio esquema de
  // URL, não dá pra contornar), mas também nunca incluíam o link público de
  // apresentação (/present/:token) que a sessão já tem via
  // `useSessionPresentLink` (usado logo abaixo em `ensurePresentLink`, hoje
  // só consumido pelo QR code do PDF). Paciente recebia "aqui está seu
  // plano" sem nada de fato anexado ou linkado — o que o profissional
  // reporta como "enviar link não funciona". Os dois handlers viram async e
  // passam a incluir o link de verdade quando conseguem gerá-lo, com a
  // mensagem antiga como fallback se a geração falhar.
  const handleShareWhatsApp = async () => {
    if (!pdfData) return;
    setShareOpen(false);
    // window.open síncrono ANTES do await: depois de um `await`, a maioria
    // dos navegadores (Safari em especial) não reconhece mais o
    // window.open() como consequência direta do clique do usuário e
    // bloqueia como pop-up. Abrir a aba em branco já dentro do gesto de
    // clique e só preencher a URL depois evita esse bloqueio.
    const win = window.open('', '_blank');
    const link = await ensurePresentLink();
    const baseMessage = link
      ? t('sessions.stage3.shareWhatsAppMessageWithLink', { procedure: pdfData.procedureName, link })
      : t('sessions.stage3.shareWhatsAppMessage', { procedure: pdfData.procedureName });
    // Orientações pré/pós-procedimento (ver comentário de `careInstructions`
    // acima) anexadas ao final da mensagem quando o profissional preencheu —
    // mesmo texto usado na seção "Orientações" do PDF (handleExportPdf).
    const messageWithCare = hasCareInstructionsContent(careInstructions)
      ? `${baseMessage}${t('sessions.stage3.shareCareInstructionsSuffix', { instructions: careInstructions })}`
      : baseMessage;
    // Checklist de Pós-Procedimento Personalizado (ver comentário de
    // src/lib/postProcedureChecklist.ts): complemento AUTOMÁTICO ao texto
    // livre acima, gerado a partir das substâncias de fato usadas nesta
    // sessão — não o substitui, os dois aparecem juntos quando presentes.
    // `postProcedureChecklistShareText` já devolve o bloco todo (título +
    // nota + itens) traduzido, ou string vazia quando a sessão não tem
    // nenhum ponto de aplicação — nesse caso a mensagem fica idêntica à de
    // antes desta feature.
    const checklistText = postProcedureChecklistShareText(stage2Overlay, t);
    const message = checklistText ? `${messageWithCare}\n\n${checklistText}` : messageWithCare;
    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    if (win) win.location.href = url;
    else window.open(url, '_blank');
  };

  // Quando o paciente já tem e-mail cadastrado (`patients.email` —
  // NovoPaciente/EditarPaciente), "Enviar por e-mail" agora entrega de
  // verdade, a partir da plataforma via Resend (send-patient-email), direto
  // pro paciente — sem exigir que o profissional abra o próprio app de
  // e-mail e digite/lembre o endereço. Sem e-mail cadastrado, cai de volta
  // no `mailto:` de sempre (o profissional ainda decide pra quem mandar).
  const handleShareEmail = async () => {
    if (!pdfData || !id || !patientId) return;
    setShareOpen(false);

    // Trata e-mail malformado (ex.: registro antigo gravado por um caminho
    // que não passou pela validação da UI) igual a "sem e-mail": abre o
    // mailto: em vez de chamar send-patient-email, que rejeitaria (400
    // missing_patient_email) e deixaria o profissional sem nenhum canal
    // funcionando — nem mailto nem Resend.
    if (!patientEmail || !isValidEmail(patientEmail)) {
      const link = await ensurePresentLink();
      const subject = t('sessions.stage3.shareEmailSubject', { procedure: pdfData.procedureName });
      const bodyWithoutCare = link
        ? t('sessions.stage3.shareEmailBodyWithLink', { patient: pdfData.patientName, procedure: pdfData.procedureName, link })
        : t('sessions.stage3.shareEmailBody', { patient: pdfData.patientName, procedure: pdfData.procedureName });
      // Checklist de Pós-Procedimento Personalizado (ver comentário em
      // handleShareWhatsApp acima e em src/lib/postProcedureChecklist.ts) —
      // mesmo anexo condicional do WhatsApp, aqui no corpo do mailto: de
      // fallback (sem e-mail cadastrado/válido).
      const checklistText = postProcedureChecklistShareText(stage2Overlay, t);
      const body = checklistText ? `${bodyWithoutCare}\n\n${checklistText}` : bodyWithoutCare;
      toast.info(t('sessions.stage3.sendPatientEmailNoAddress'));
      window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      return;
    }

    const link = await ensurePresentLink();
    // Envio real via Resend (edge function send-patient-email) — o corpo do
    // e-mail já inclui as orientações pré/pós-procedimento quando
    // preenchidas (ver buildEmailHtml em send-patient-email/index.ts).
    // Mantém o fallback mailto: acima (sem e-mail cadastrado) intacto, que
    // também já anexa as orientações no corpo montado no client.
    try {
      const { data, error } = await supabase.functions.invoke('send-patient-email', {
        body: { sessionId: id, patientId, presentLink: link, locale: i18n.language },
      });
      const response = data as { sent?: boolean; source?: 'live' | 'mock'; error?: string } | null;
      if (error || !response || response.error) {
        throw new Error(response?.error || error?.message || t('sessions.stage3.sendPatientEmailFailed'));
      }
      if (response.source === 'mock') {
        toast.info(t('sessions.stage3.sendPatientEmailMock'));
      } else {
        toast.success(t('sessions.stage3.sendPatientEmailSuccess', { email: patientEmail }));
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : t('sessions.stage3.sendPatientEmailFailed');
      toast.error(t('sessions.stage3.sendPatientEmailFailed'));
      console.error('[SessaoEstagio3] Falha ao enviar e-mail ao paciente:', err);
      if (user) {
        logClientError({
          professionalId: user.id,
          sessionId: id,
          stage: 'send_email',
          errorType: 'send_patient_email_client_failed',
          message,
        });
      }
    }
  };

  const handleShareExportPdf = (audience: 'patient' | 'professional') => () => {
    setShareOpen(false);
    handleExportPdf(audience);
  };

  const handleExportPdf = async (audience: 'patient' | 'professional') => {
    if (!pdfData || !id || !user) return;
    const isProfessional = audience === 'professional';

    // Todo o corpo abaixo (desenho do PDF inteiro via jsPDF, fetch de fotos,
    // QR code, cálculo de orçamento) ficava sem nenhum try/catch — diferente
    // de todo outro handler assíncrono deste arquivo (runSimulation acima,
    // o try interno de persistência mais abaixo). Qualquer exceção lançada
    // no meio (ex.: campo de stage1_analysis com formato inesperado — ver
    // guarda de attentionPoints logo abaixo) rejeitava a Promise em
    // silêncio: o profissional clicava em "PDF" e nada acontecia, sem toast
    // de erro nenhum — exatamente o bug reportado. Cobre a função inteira,
    // igual ao padrão já usado em runSimulation/useSessionPresentLink
    // (toast de erro + registro em error_logs para investigação).
    try {

    // QR code de verificação (só no PDF do paciente — é o documento que sai
    // da clínica e se beneficia da camada de credibilidade/anti-fraude; o PDF
    // profissional já é de uso interno). Reaproveita o link público de
    // apresentação da sessão já existente — ver decisão de escopo em
    // src/lib/qrCode.ts. `ensurePresentLink` cria a linha em
    // `session_present_links` se ainda não existir uma; falha em gerar o
    // link ou o QR não deve travar a exportação, por isso os dois caem em
    // `null` em vez de lançar.
    const verificationUrl = isProfessional ? null : await ensurePresentLink();
    const qrDataUrl = verificationUrl ? await generateQrCodeDataUrl(verificationUrl) : null;

    // Import dinâmico: só baixa/avalia a lib (pesada) quando o profissional
    // de fato clica em exportar PDF, em vez de no carregamento da tela.
    const { jsPDF: JsPDFCtor } = await import('jspdf');
    const doc = new JsPDFCtor({ unit: 'pt', format: 'a4' });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const marginX = 40;
    const usableWidth = pageWidth - marginX * 2;
    const dateStr = format(new Date(), 'PPP', { locale: dateFnsLocale[i18n.language] ?? ptBR });
    let y = 56;

    // Wrapper fino sobre o helper puro/testável em src/lib/pdfLayout.ts —
    // mantém a assinatura original (só `needed`) usada em todas as chamadas
    // abaixo, aplicando `y` como estado local em vez de retorno explícito.
    const ensureSpace = (needed: number) => {
      y = ensureSpaceOnPage(doc, y, needed, pageHeight, 70, 56);
    };

    // Título de seção padronizado: pequena barra de destaque na cor da marca
    // + rótulo em caixa alta, criando uma hierarquia clara acima do corpo
    // de texto (antes tudo — título e corpo — usava o mesmo tamanho 11pt).
    //
    // `bodyHeight` (bug P2 "Quebra de página do PDF corta seção ao meio"):
    // cada seção abaixo mede a altura do que vem logo depois do título
    // (a caixa de análise clínica, os cards de orçamento, etc.) e passa
    // esse valor aqui ANTES de desenhar qualquer coisa. Sem isso, o título
    // reservava espaço só para si (36pt), era desenhado, e só depois o
    // corpo da seção era medido — se o corpo não coubesse, o jsPDF quebrava
    // a página ali, deixando o título sozinho no fim da página anterior e o
    // conteúdo começando na próxima. Reservar título+corpo juntos garante
    // que a quebra de página (quando necessária) aconteça antes do título
    // ser desenhado, e a seção inteira migra junto para a página nova.
    const drawSectionTitle = (label: string, bodyHeight = 0) => {
      ensureSpace(36 + bodyHeight);
      doc.setFillColor(...PDF_COLORS.gMid);
      doc.roundedRect(marginX, y - 10, 4, 15, 2, 2, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(...PDF_COLORS.text);
      doc.text(label.toUpperCase(), marginX + 13, y);
      y += 26;
    };

    const drawDivider = () => {
      ensureSpace(30);
      doc.setDrawColor(...PDF_COLORS.surface3);
      doc.setLineWidth(0.6);
      doc.line(marginX, y, pageWidth - marginX, y);
      y += 30;
    };

    // ---------- Cabeçalho: faixa em gradiente com a paleta da marca ----------
    const bandHeight = 108;
    drawPdfGradient(doc, 0, 0, pageWidth, bandHeight, [PDF_COLORS.gStart, PDF_COLORS.gMid, PDF_COLORS.gEnd]);

    let headerTextX = marginX;
    if (pdfData.logoUrl) {
      const dataUrl = await fetchImageAsDataUrl(pdfData.logoUrl);
      const circleR = 25;
      const circleCx = marginX + circleR;
      const circleCy = bandHeight / 2;
      doc.setFillColor(...PDF_COLORS.white);
      doc.circle(circleCx, circleCy, circleR, 'F');
      if (dataUrl) {
        try {
          const inset = 8;
          doc.addImage(
            dataUrl,
            getImageFormatFromDataUrl(dataUrl),
            circleCx - circleR + inset,
            circleCy - circleR + inset,
            (circleR - inset) * 2,
            (circleR - inset) * 2,
          );
        } catch {
          // formato de imagem incompatível com addImage — segue sem logo
        }
      }
      headerTextX = circleCx + circleR + 16;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(...PDF_COLORS.white);
    doc.text((pdfData.clinicName || 'FacialPlan').toUpperCase(), headerTextX, 38);

    doc.setFontSize(20);
    doc.text(t('sessions.stage3.pdf.planTitle'), headerTextX, 64);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    const headerSubtitle = [pdfData.professionalName, dateStr].filter(Boolean).join('   ·   ');
    doc.text(headerSubtitle, headerTextX, 84);

    // Selo indicando o público do documento — reforça visualmente a distinção
    // paciente/profissional que já existe no conteúdo (preço nunca aparece
    // na versão do paciente).
    const badgeLabel = isProfessional
      ? t('sessions.stage3.pdf.badgeProfessional')
      : t('sessions.stage3.pdf.badgePatient');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    const badgePadX = 12;
    const badgeH = 20;
    const badgeW = doc.getTextWidth(badgeLabel) + badgePadX * 2;
    const badgeX = pageWidth - marginX - badgeW;
    const badgeY = 26;
    doc.setFillColor(...PDF_COLORS.white);
    doc.roundedRect(badgeX, badgeY, badgeW, badgeH, badgeH / 2, badgeH / 2, 'F');
    doc.setTextColor(...PDF_COLORS.gEnd);
    doc.text(badgeLabel, badgeX + badgeW / 2, badgeY + badgeH / 2 + 3, { align: 'center' });

    y = bandHeight + 36;

    // ---------- Card com os dados do plano (paciente/procedimento/intensidade/data) ----------
    const infoFields: [string, string][] = [
      [t('sessions.stage3.pdf.patient'), pdfData.patientName],
      [t('sessions.stage3.pdf.procedure'), pdfData.procedureName],
      [t('sessions.stage3.pdf.simulationIntensity'), t(`sessions.stage3.intensity.${intensity}`)],
      [t('sessions.stage3.pdf.date'), dateStr],
    ];
    const cardPad = 20;
    const colWidth = usableWidth / 2;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12.5);
    const fieldValueWidth = colWidth - cardPad - 12;
    const fieldLines = infoFields.map(([, value]) => doc.splitTextToSize(value, fieldValueWidth));
    const rowLineCount = [
      Math.max(fieldLines[0].length, fieldLines[1].length),
      Math.max(fieldLines[2].length, fieldLines[3].length),
    ];
    const rowHeight = (lines: number) => 24 + lines * 15;
    const cardHeight = cardPad * 2 + rowHeight(rowLineCount[0]) + rowHeight(rowLineCount[1]);
    ensureSpace(cardHeight + 30);
    const cardY = y;
    doc.setFillColor(...PDF_COLORS.surface);
    doc.setDrawColor(...PDF_COLORS.surface3);
    doc.setLineWidth(0.75);
    doc.roundedRect(marginX, cardY, usableWidth, cardHeight, 10, 10, 'FD');

    const rowTop = cardY + cardPad;
    infoFields.forEach(([label, value], i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const fx = marginX + cardPad + col * colWidth;
      const fy = rowTop + (row === 1 ? rowHeight(rowLineCount[0]) : 0);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(...PDF_COLORS.text3);
      doc.text(label.toUpperCase(), fx, fy);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12.5);
      doc.setTextColor(...PDF_COLORS.text);
      doc.text(fieldLines[i], fx, fy + 17);
    });
    y = cardY + cardHeight + 34;

    // ---------- Carimbo de proveniência da análise ----------
    // Desenhado ANTES de qualquer conteúdo clínico (antes/depois, análise
    // clínica, lista de procedimentos) e sempre na primeira página, logo sob o
    // card de identificação: se a análise que originou este plano é de
    // demonstração (fabricada pelo fallback de analyze-face, ver
    // src/lib/analysisProvenance.ts), quem receber este PDF precisa ler isso
    // antes de qualquer outra coisa — não como asterisco de rodapé. Caixa
    // cheia com borda grossa na cor do alerta, não um rodapé em itálico, pelo
    // mesmo motivo. Some por completo quando a análise é de IA de verdade,
    // que é o caso comum.
    //
    // O PDF do paciente leva o texto voltado ao PACIENTE (sem a instrução
    // operacional de "refazer a análise", que é tarefa do profissional) —
    // mesma separação de público já aplicada ao preço, que nunca aparece na
    // versão do paciente.
    const provenance = analysisProvenance(stage1Analysis);
    const provenanceKeys = isProfessional
      ? provenanceStampKeys(provenance)
      : patientProvenanceStampKeys(provenance);
    if (provenanceKeys) {
      const stampAccent: readonly [number, number, number] =
        provenance === 'mock' ? PDF_COLORS.red : PDF_COLORS.amber;
      const stampPad = 16;
      const stampInnerWidth = usableWidth - stampPad * 2;
      const titleLineHeight = 15;
      const bodyLineHeight = 13;

      // Mesma disciplina do resto do arquivo (bug P2 "quebra de página corta
      // seção ao meio"): mede TUDO com a fonte que será de fato usada para
      // desenhar cada trecho, antes de reservar espaço. O título também é
      // quebrado em linhas — em francês/italiano ele não cabe numa linha só na
      // largura útil da página.
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11.5);
      const stampTitleLines: string[] = doc.splitTextToSize(t(provenanceKeys.title).toUpperCase(), stampInnerWidth);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      const stampBodyLines: string[] = doc.splitTextToSize(t(provenanceKeys.body), stampInnerWidth);
      doc.setFont('helvetica', 'bold');
      const stampActionLines: string[] = provenanceKeys.action
        ? doc.splitTextToSize(t(provenanceKeys.action), stampInnerWidth)
        : [];

      const stampHeight =
        stampPad * 2 +
        stampTitleLines.length * titleLineHeight +
        6 +
        stampBodyLines.length * bodyLineHeight +
        (stampActionLines.length > 0 ? 8 + stampActionLines.length * bodyLineHeight : 0);

      ensureSpace(stampHeight + 24);
      const stampY = y;
      doc.setFillColor(...pdfTint(stampAccent, 0.9));
      doc.setDrawColor(...stampAccent);
      doc.setLineWidth(1.5);
      doc.roundedRect(marginX, stampY, usableWidth, stampHeight, 8, 8, 'FD');

      let stampTextY = stampY + stampPad + 10;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11.5);
      doc.setTextColor(...stampAccent);
      doc.text(stampTitleLines, marginX + stampPad, stampTextY);
      stampTextY += stampTitleLines.length * titleLineHeight + 6;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(...PDF_COLORS.text);
      doc.text(stampBodyLines, marginX + stampPad, stampTextY);
      stampTextY += stampBodyLines.length * bodyLineHeight;

      if (stampActionLines.length > 0) {
        stampTextY += 8;
        doc.setFont('helvetica', 'bold');
        doc.text(stampActionLines, marginX + stampPad, stampTextY);
      }

      y = stampY + stampHeight + 24;
    }

    // ---------- Fotos antes/depois, com moldura e selo colorido ----------
    // Geometria calculada ANTES do título (bug P2 — ver comentário em
    // drawSectionTitle): só depende de usableWidth, não de `y`/estado do
    // doc, então pode ser movida pra cima sem afetar o resultado, e permite
    // reservar título+molduras como um bloco só.
    const photoColGap = usableWidth * 0.09;
    const photoColWidth = (usableWidth - photoColGap) / 2;
    const matPad = 10;
    const photoWidth = photoColWidth - matPad * 2;
    const photoHeight = photoWidth * (4 / 3);
    const frameHeight = photoHeight + matPad * 2;
    const pillHeight = 22;

    drawSectionTitle(t('sessions.stage3.pdf.beforeAfterTitle'), frameHeight + pillHeight + 30);

    const frameTop = y;
    const [beforeDataUrl, afterDataUrl] = await Promise.all([
      beforeUrl ? fetchImageAsDataUrl(beforeUrl) : Promise.resolve(null),
      afterUrl ? fetchImageAsDataUrl(afterUrl) : Promise.resolve(null),
    ]);

    const drawPhotoFrame = (dataUrl: string | null, colX: number, label: string, pillColor: readonly [number, number, number]) => {
      // sombra sutil + moldura branca ("mat") ao redor da foto
      doc.setFillColor(...PDF_COLORS.surface3);
      doc.roundedRect(colX + 3, frameTop + 3, photoColWidth, frameHeight, 10, 10, 'F');
      doc.setFillColor(...PDF_COLORS.white);
      doc.setDrawColor(...PDF_COLORS.surface3);
      doc.setLineWidth(0.75);
      doc.roundedRect(colX, frameTop, photoColWidth, frameHeight, 10, 10, 'FD');

      if (dataUrl) {
        try {
          doc.addImage(dataUrl, getImageFormatFromDataUrl(dataUrl), colX + matPad, frameTop + matPad, photoWidth, photoHeight);
        } catch {
          // formato de imagem incompatível com addImage — segue sem essa foto
        }
      } else {
        const cx = colX + photoColWidth / 2;
        const cy = frameTop + frameHeight / 2 - 8;
        doc.setDrawColor(...PDF_COLORS.text3);
        doc.setLineWidth(1);
        doc.roundedRect(cx - 15, cy - 10, 30, 20, 3, 3, 'S');
        doc.circle(cx, cy, 6.5, 'S');
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8.5);
        doc.setTextColor(...PDF_COLORS.text3);
        doc.text(t('sessions.stage3.pdf.imageUnavailable'), cx, cy + 26, { align: 'center' });
      }

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      const pillPadX = 14;
      const pillWidth = doc.getTextWidth(label) + pillPadX * 2;
      const pillX = colX + photoColWidth / 2 - pillWidth / 2;
      const pillY = frameTop + frameHeight + 12;
      doc.setFillColor(...pillColor);
      doc.roundedRect(pillX, pillY, pillWidth, pillHeight, pillHeight / 2, pillHeight / 2, 'F');
      doc.setTextColor(...PDF_COLORS.white);
      doc.text(label, colX + photoColWidth / 2, pillY + pillHeight / 2 + 3.5, { align: 'center' });
    };

    drawPhotoFrame(beforeDataUrl, marginX, t('common.before').toUpperCase(), PDF_COLORS.gStart);
    drawPhotoFrame(afterDataUrl, marginX + photoColWidth + photoColGap, t('common.after').toUpperCase(), PDF_COLORS.gEnd);

    // Seta entre as duas fotos reforçando a direção da transformação
    const arrowCx = marginX + photoColWidth + photoColGap / 2;
    const arrowCy = frameTop + frameHeight / 2;
    doc.setFillColor(...PDF_COLORS.gMid);
    doc.triangle(arrowCx - 5, arrowCy - 7, arrowCx - 5, arrowCy + 7, arrowCx + 6, arrowCy, 'F');

    y = frameTop + frameHeight + pillHeight + 12 + 34;

    drawDivider();

    // Análise clínica geral — combina o texto livre (Stage1Analysis.overallNotes)
    // com a leitura estrutural mais rica trazida da Etapa 1 (resumo do
    // paciente / formato-simetria-proporções / pontos de atenção — ver
    // src/types/harmonize.ts e src/lib/clinicalAnalysisPdf.ts). Antes só
    // ficava visível na Etapa 1 e se perdia dali pra frente; agora acompanha
    // o plano inteiro, destacada como um bloco de citação com barra de cor
    // à esquerda. Todos os campos são opcionais e aditivos — sem nenhum
    // deles, a seção inteira é omitida em vez de aparecer vazia.
    const overallNotes = stage1Analysis?.overallNotes ?? null;
    const clinicalRows = facialAnalysisRows(stage1Analysis, {
      shape: t('sessions.stage3.pdf.facialAnalysisShapeLabel'),
      symmetry: t('sessions.stage3.pdf.facialAnalysisSymmetryLabel'),
      proportions: t('sessions.stage3.pdf.facialAnalysisProportionsLabel'),
    });
    // Terços faciais/textura de pele/limitações da análise: a IA já produz
    // esses três campos e a Etapa 1 já os mostra ao profissional, mas o PDF
    // final (o documento de fato entregue/arquivado) nunca os incluía —
    // achado do squad Sessões/IA/Apresentação.
    const facialThirdsPdfRows = facialThirdsRows(stage1Analysis, {
      upper: t('sessions.stage3.pdf.facialThirdsUpperLabel'),
      middle: t('sessions.stage3.pdf.facialThirdsMiddleLabel'),
      lower: t('sessions.stage3.pdf.facialThirdsLowerLabel'),
    });
    if (overallNotes || hasClinicalAnalysisContent(stage1Analysis)) {
      const boxPad = 16;
      const innerWidth = usableWidth - boxPad * 2 - 10;

      // Corpo da seção (blocks/boxHeight) é medido ANTES do título ser
      // desenhado — bug P2 "Quebra de página do PDF corta seção ao meio":
      // desenhar o título e só DEPOIS medir/reservar espaço pro corpo
      // permitia que o título coubesse na página atual e o corpo, maior,
      // fosse empurrado pra próxima — título órfão no fim de uma página,
      // corpo começando sozinho na seguinte. Medindo tudo primeiro e
      // passando a altura total (boxHeight) pra drawSectionTitle() abaixo,
      // a verificação de espaço cobre título+corpo como um bloco só, e a
      // quebra de página (quando necessária) acontece antes do título.
      //
      // splitTextToSize() mede a largura de quebra usando a fonte
      // corrente do `doc` — por isso é setada aqui para normal/10.5, a
      // mesma usada de fato pra desenhar essas linhas mais abaixo (setada
      // de novo por bloco no forEach de render). Sem isso, cada bloco
      // seria medido como se fosse bold/13pt (fonte que drawSectionTitle
      // deixaria configurada): largura efetiva bem menor, linhas quebrando
      // cedo demais e a caixa crescendo mais alta do que o texto precisa.
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10.5);

      type ClinicalBlock = { heading?: string; lines: string[] };
      const blocks: ClinicalBlock[] = [];
      if (overallNotes) {
        blocks.push({ lines: doc.splitTextToSize(overallNotes, innerWidth) });
      }
      if (stage1Analysis?.patientSummary) {
        blocks.push({
          heading: t('sessions.stage3.pdf.patientSummaryLabel'),
          lines: doc.splitTextToSize(stage1Analysis.patientSummary, innerWidth),
        });
      }
      for (const { label, value } of clinicalRows) {
        blocks.push({ heading: label, lines: doc.splitTextToSize(value, innerWidth) });
      }
      for (const { label, value } of facialThirdsPdfRows) {
        blocks.push({ heading: label, lines: doc.splitTextToSize(value, innerWidth) });
      }
      if (typeof stage1Analysis?.skinTexture === 'string' && stage1Analysis.skinTexture.trim()) {
        blocks.push({
          heading: t('sessions.stage3.pdf.skinTextureLabel'),
          lines: doc.splitTextToSize(stage1Analysis.skinTexture, innerWidth),
        });
      }
      if (typeof stage1Analysis?.analysisLimitations === 'string' && stage1Analysis.analysisLimitations.trim()) {
        blocks.push({
          heading: t('sessions.stage3.pdf.analysisLimitationsLabel'),
          lines: doc.splitTextToSize(stage1Analysis.analysisLimitations, innerWidth),
        });
      }
      // `stage1_analysis` chega do banco via cast não validado (`as unknown
      // as Stage1Analysis` no load() acima) — o schema TS não é garantia
      // nenhuma em runtime. O servidor (analyze-face/sanitizeAnalysis) hoje
      // só grava `attentionPoints` quando é de fato um array de strings, mas
      // uma sessão antiga/gravada por outro caminho pode ter esse campo em
      // outro formato (ex.: uma string solta) — uma string TAMBÉM tem
      // `.length`, então o `&&` sozinho não pegava esse caso, e
      // `"string".flatMap` não existe (só Array tem) — TypeError sem
      // try/catch em volta, exatamente o "clica e não acontece nada"
      // reportado. `Array.isArray` fecha a guarda de verdade.
      if (Array.isArray(stage1Analysis?.attentionPoints) && stage1Analysis.attentionPoints.length > 0) {
        blocks.push({
          heading: t('sessions.stage3.pdf.attentionPointsLabel'),
          lines: stage1Analysis.attentionPoints.flatMap((point) => doc.splitTextToSize(`•  ${point}`, innerWidth)),
        });
      }

      const blockGap = 10;
      const headingHeight = 14;
      const boxHeight =
        boxPad * 2 +
        blocks.reduce((sum, b) => sum + (b.heading ? headingHeight : 0) + b.lines.length * 14, 0) +
        blockGap * (blocks.length - 1);

      drawSectionTitle(t('sessions.stage3.pdf.clinicalAnalysisTitle'), boxHeight + 30);
      const boxY = y - 8;
      doc.setFillColor(...PDF_COLORS.surface);
      doc.roundedRect(marginX, boxY, usableWidth, boxHeight, 8, 8, 'F');
      doc.setFillColor(...PDF_COLORS.gMid);
      doc.roundedRect(marginX, boxY, 4, boxHeight, 2, 2, 'F');

      let textY = boxY + boxPad + 8;
      blocks.forEach((block, i) => {
        if (block.heading) {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(9.5);
          doc.setTextColor(...PDF_COLORS.text2);
          doc.text(block.heading.toUpperCase(), marginX + boxPad + 8, textY);
          textY += headingHeight;
        }
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10.5);
        doc.setTextColor(...PDF_COLORS.text);
        doc.text(block.lines, marginX + boxPad + 8, textY);
        textY += block.lines.length * 14;
        if (i < blocks.length - 1) textY += blockGap;
      });

      y = boxY + boxHeight + 34;
      drawDivider();
    }

    // Explicação de cada procedimento planejado — cada item ganha um marcador
    // numerado na cor da marca em vez do "•" plano de antes.

    // "Protocolo de Procedimentos" (backlog #47, catálogo curado — ver
    // src/lib/procedureCatalog.ts): complemento/rótulo à lista de pontos já
    // existente acima, não uma segunda lista duplicada — cada ponto vinculado
    // a um procedimento nomeado do catálogo (ApplicationPoint.procedureId)
    // ganha uma linha extra com o nome do procedimento dentro do próprio item
    // (ver dentro de measureProcedureItem/drawProcedureItem abaixo). Esta
    // legenda só aparece quando pelo menos um ponto do plano tem um
    // procedimento nomeado — um plano feito inteiramente de pontos
    // manuais/antigos (sem procedureId) mantém o PDF idêntico ao de antes
    // desta feature.
    const hasNamedProcedures = stage2Overlay.some((point) => procedureDisplayName(point.procedureId, t) !== undefined);

    // Extraída de dentro do forEach original pra poder ser chamada duas
    // vezes: uma vez aqui embaixo só pra MEDIR o primeiro item (decidir se
    // título+primeiro-conteúdo cabem juntos na página — bug P2, ver
    // drawSectionTitle) e de novo dentro do forEach abaixo pra desenhar
    // cada item de fato. Puramente medição (mexe só no font state do doc,
    // sem desenhar nada), então chamá-la duas vezes pro item 0 é seguro.
    type MeasuredProcedureItem = {
      line: string;
      wrapped: string[];
      detailsText: string;
      detailsLines: string[];
      procedureLabelText: string;
      procedureLabelLines: string[];
      namedProtocolLabelText: string;
      namedProtocolLabelLines: string[];
      justificationText: string;
      justificationLines: string[];
      blockHeight: number;
    };
    const measureProcedureItem = (point: (typeof stage2Overlay)[number]): MeasuredProcedureItem => {
      // Preço por item é visão exclusiva do profissional — no PDF do
      // paciente a lista de procedimentos nunca inclui valor.
      const itemPrice = isProfessional ? priceForPoint(point, insumos) : null;
      const line = itemPrice !== null
        ? t('sessions.stage3.pdf.procedureItemWithPrice', {
            label: point.label,
            quantity: point.quantity,
            unit: point.unit,
            substance: SUBSTANCE_LABEL[point.substance],
            price: formatCurrency(itemPrice, currency),
          })
        : t('sessions.stage3.pdf.procedureItem', {
            label: point.label,
            quantity: point.quantity,
            unit: point.unit,
            substance: SUBSTANCE_LABEL[point.substance],
          });

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      const wrapped = doc.splitTextToSize(line, usableWidth - 30);

      // Técnica/profundidade/dispositivo (item 1 do backlog P0) — ausentes
      // num ponto criado antes desta feature, ou nunca editado pelo
      // profissional; nesse caso a linha inteira é omitida em vez de
      // aparecer com campos em branco.
      //
      // Origem do ponto (P2 "Trilha de auditoria clínica exposta no PDF"):
      // `ApplicationPoint.source` já diferencia sugestão de IA de ajuste
      // manual na Etapa 2 (borda tracejada vs. sólida), mas até aqui esse
      // dado morria na tela ao vivo — o laudo final não deixava rastro de
      // qual ponto veio de onde. Ao contrário de technique/depth/device,
      // `source` não é opcional no modelo (todo ponto criado pelo fluxo
      // atual traz um dos dois valores), então essa entrada aparece sempre,
      // na mesma linha de detalhes e no mesmo estilo sutil já usado ali —
      // não é redesenho, só mais um dado na lista que já existia. Um valor
      // fora de 'ai'/'manual' (dado antigo hipotético gravado antes deste
      // campo existir) cai no rótulo de ajuste manual, espelhando o mesmo
      // fallback que a Etapa 2 já usa pro estilo da borda.
      const detailParts = [
        point.technique ? `${t('sessions.stage2.technique.label')}: ${t(`sessions.stage2.technique.options.${point.technique}`)}` : null,
        point.depth ? `${t('sessions.stage2.depth.label')}: ${t(`sessions.stage2.depth.options.${point.depth}`)}` : null,
        point.device ? `${t('sessions.stage2.device.label')}: ${t(`sessions.stage2.device.options.${point.device}`)}` : null,
        point.source === 'ai' ? t('sessions.stage3.pdf.pointSourceAi') : t('sessions.stage3.pdf.pointSourceManual'),
      ].filter((v): v is string => Boolean(v));
      const detailsText = detailParts.join('   ·   ');

      // Nome do procedimento nomeado do catálogo vinculado a este ponto
      // (ver comentário de `hasNamedProcedures` acima) — ausente para todo
      // ponto sem `procedureId` (manual sem procedimento escolhido, vindo
      // de sugestão de IA, ou criado antes desta feature); nesse caso a
      // linha inteira é omitida, igual ao padrão já usado para
      // técnica/profundidade/dispositivo logo abaixo.
      const procedureLabel = procedureDisplayName(point.procedureId, t);
      const procedureLabelText = procedureLabel
        ? t('sessions.stage3.pdf.protocolItemLabel', { name: procedureLabel })
        : '';

      // Nome do Protocolo Nomeado (comitê técnico, ver src/lib/namedProtocols.ts)
      // vinculado a este ponto — conceito PARALELO ao procedimento nomeado do
      // catálogo acima (procedureId/procedureLabel), não o mesmo campo: um
      // ponto pode ter um, o outro, os dois ou nenhum. Ausente para todo
      // ponto sem `protocolId` (a imensa maioria — só pontos vindos de um
      // protocolo aplicado na Etapa 2 o carregam); mesmo padrão de omitir a
      // linha inteira quando ausente já usado nos demais campos aqui.
      const namedProtocolLabel = protocolDisplayName(point.protocolId, t);
      const namedProtocolLabelText = namedProtocolLabel
        ? t('sessions.stage3.pdf.namedProtocolItemLabel', { name: namedProtocolLabel })
        : '';

      const justificationText = justificationPdfText(point.justification);
      let justificationLines: string[] = [];
      let detailsLines: string[] = [];
      let procedureLabelLines: string[] = [];
      let namedProtocolLabelLines: string[] = [];
      let blockHeight = wrapped.length * 15 + 6;
      if (procedureLabelText) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        procedureLabelLines = doc.splitTextToSize(procedureLabelText, usableWidth - 30);
        blockHeight += procedureLabelLines.length * 12 + 4;
      }
      if (namedProtocolLabelText) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        namedProtocolLabelLines = doc.splitTextToSize(namedProtocolLabelText, usableWidth - 30);
        blockHeight += namedProtocolLabelLines.length * 12 + 4;
      }
      if (detailsText) {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        detailsLines = doc.splitTextToSize(detailsText, usableWidth - 30);
        blockHeight += detailsLines.length * 12 + 4;
      }
      if (justificationText) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(9.5);
        justificationLines = doc.splitTextToSize(justificationText, usableWidth - 40);
        blockHeight += justificationLines.length * 12 + 14;
      }
      return {
        line, wrapped, detailsText, detailsLines,
        procedureLabelText, procedureLabelLines,
        namedProtocolLabelText, namedProtocolLabelLines,
        justificationText, justificationLines, blockHeight,
      };
    };

    // Altura do que vem logo abaixo do título — a legenda "PROTOCOLO DE
    // PROCEDIMENTOS" quando aplicável, e o primeiro item da lista (ou a
    // mensagem "nenhum ponto") — reservada junto com o título (bug P2, ver
    // drawSectionTitle). A lista pode legitimamente continuar por várias
    // páginas quando é longa (isso não é o bug); o que importa é o título
    // nunca ficar sozinho acima de um conteúdo que foi pra próxima página.
    let firstProcedureContentHeight = hasNamedProcedures ? 18 : 0;
    firstProcedureContentHeight += stage2Overlay.length === 0
      ? 24
      : measureProcedureItem(stage2Overlay[0]).blockHeight + 12;

    drawSectionTitle(t('sessions.stage3.pdf.proceduresTitle'), firstProcedureContentHeight);

    if (hasNamedProcedures) {
      ensureSpace(18);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.setTextColor(...PDF_COLORS.gMid);
      doc.text(t('sessions.stage3.pdf.protocolTitle').toUpperCase(), marginX, y);
      y += 18;
    }

    if (stage2Overlay.length === 0) {
      ensureSpace(24);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(10.5);
      doc.setTextColor(...PDF_COLORS.text2);
      doc.text(t('sessions.stage3.pdf.noProcedurePoints'), marginX, y);
      y += 24;
    } else {
      stage2Overlay.forEach((point, index) => {
        const {
          wrapped, detailsText, detailsLines,
          procedureLabelText, procedureLabelLines,
          namedProtocolLabelText, namedProtocolLabelLines,
          justificationText, justificationLines, blockHeight,
        } = measureProcedureItem(point);
        ensureSpace(blockHeight + 12);

        const itemTop = y;
        doc.setFillColor(...PDF_COLORS.gMid);
        doc.circle(marginX + 8, itemTop - 3.5, 9, 'F');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(...PDF_COLORS.white);
        doc.text(String(index + 1), marginX + 8, itemTop - 0.5, { align: 'center' });

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(...PDF_COLORS.text);
        doc.text(wrapped, marginX + 26, itemTop);
        y = itemTop + wrapped.length * 15 + 4;

        if (procedureLabelText) {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(9);
          doc.setTextColor(...PDF_COLORS.gEnd);
          doc.text(procedureLabelLines, marginX + 26, y + 8);
          y += procedureLabelLines.length * 12 + 8;
        }

        if (namedProtocolLabelText) {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(9);
          doc.setTextColor(...PDF_COLORS.gEnd);
          doc.text(namedProtocolLabelLines, marginX + 26, y + 8);
          y += namedProtocolLabelLines.length * 12 + 8;
        }

        if (detailsText) {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(9);
          doc.setTextColor(...PDF_COLORS.text2);
          doc.text(detailsLines, marginX + 26, y + 8);
          y += detailsLines.length * 12 + 8;
        }

        // Justificativa clínica da IA para este ponto (Suggestion.justification,
        // copiada ao aceitar a sugestão na Etapa 1) — sem isso o PDF só listava
        // substância/quantidade, sem nenhuma explicação do porquê. Agora ganha
        // uma linha de guia sutil à esquerda, como uma citação recuada.
        if (justificationText) {
          const justTop = y + 6;
          doc.setDrawColor(...PDF_COLORS.surface3);
          doc.setLineWidth(1.5);
          doc.line(marginX + 26, justTop - 4, marginX + 26, justTop + justificationLines.length * 12 + 2);
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(9.5);
          doc.setTextColor(...PDF_COLORS.text2);
          doc.text(justificationLines, marginX + 38, justTop + 6);
          y = justTop + justificationLines.length * 12 + 16;
        } else {
          y += 12;
        }
      });
    }

    // Orientações pré/pós-procedimento (backlog P1 "Orientações
    // pré/pós-procedimento", v1 reduzida): texto único configurado pelo
    // profissional em Perfil.tsx (profiles.pre_post_care_instructions),
    // reaproveitado igual em toda sessão — sem orientação por procedimento
    // específico do catálogo nesta v1 (fora de escopo; ver
    // hasCareInstructionsContent em clinicalAnalysisPdf.ts). Aparece nos dois
    // públicos (paciente e profissional), diferente do orçamento logo
    // abaixo, porque a orientação clínica é igualmente relevante pros dois —
    // não é um dado sensível de preço. Usa os mesmos helpers
    // ensureSpace/drawSectionTitle/drawDivider já usados nas seções acima.
    if (hasCareInstructionsContent(careInstructions)) {
      drawDivider();
      // Corpo medido ANTES do título (bug P2, ver drawSectionTitle) pra
      // reservar título+texto como bloco único.
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10.5);
      const careLines = doc.splitTextToSize(careInstructions as string, usableWidth);
      drawSectionTitle(t('sessions.stage3.pdf.careInstructionsTitle'), careLines.length * 14 + 10);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10.5);
      doc.setTextColor(...PDF_COLORS.text);
      doc.text(careLines, marginX, y);
      y += careLines.length * 14 + 24;
    }

    // Checklist de Pós-Procedimento Personalizado (ideia do squad de
    // Produto): complemento AUTOMÁTICO à seção "Orientações" acima, gerado a
    // partir das substâncias de fato usadas NESTA sessão (não o texto livre
    // único do profissional) — ver comentário de arquivo em
    // src/lib/postProcedureChecklist.ts pra decisão de escopo completa.
    // Aparece nos dois públicos (paciente e profissional), mesmo raciocínio
    // já usado para "Orientações" logo acima: é cuidado clínico, não preço.
    // Uma sessão sem nenhum ponto de aplicação (`stage2Overlay` vazio) omite
    // a seção inteira em vez de aparecer vazia.
    const postCareChecklist = postProcedureChecklistSections(stage2Overlay, t);
    if (postCareChecklist.length > 0) {
      drawDivider();
      // Corpo medido ANTES do título (bug P2, ver drawSectionTitle) pra
      // reservar título+texto como bloco único — mesmo padrão já usado nas
      // seções acima (Análise Clínica, Orientações). A nota introdutória usa
      // fonte diferente dos blocos por substância, então cada uma é medida
      // com a fonte que de fato vai usar pra desenhar mais abaixo — sem
      // isso, `splitTextToSize` mediria a largura de quebra com a fonte
      // errada (a que `drawSectionTitle` deixaria configurada: bold/13pt) e
      // a altura reservada não bateria com o texto de verdade.
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      const checklistNoteLines = doc.splitTextToSize(t('sessions.stage3.postCareChecklist.note'), usableWidth);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10.5);
      const checklistBlocks = postCareChecklist.map(({ label, items }) => ({
        heading: label,
        lines: items.flatMap((item) => doc.splitTextToSize(`•  ${item}`, usableWidth)),
      }));
      const checklistBlockGap = 10;
      const checklistHeadingHeight = 14;
      const checklistBodyHeight =
        checklistNoteLines.length * 12 + 10 +
        checklistBlocks.reduce((sum, b) => sum + checklistHeadingHeight + b.lines.length * 14, 0) +
        checklistBlockGap * (checklistBlocks.length - 1);
      drawSectionTitle(t('sessions.stage3.pdf.postCareChecklistTitle'), checklistBodyHeight);

      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.setTextColor(...PDF_COLORS.text2);
      doc.text(checklistNoteLines, marginX, y);
      y += checklistNoteLines.length * 12 + 10;

      checklistBlocks.forEach((block, i) => {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9.5);
        doc.setTextColor(...PDF_COLORS.gMid);
        doc.text(block.heading.toUpperCase(), marginX, y);
        y += checklistHeadingHeight;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10.5);
        doc.setTextColor(...PDF_COLORS.text);
        doc.text(block.lines, marginX, y);
        y += block.lines.length * 14;
        if (i < checklistBlocks.length - 1) y += checklistBlockGap;
      });
      y += 24;
    }

    // Sinais de Alerta de Emergência (achado de Produto/segurança, 14/09):
    // só aparece quando ALGUM ponto de aplicação desta sessão foi de fato
    // marcado como zona de risco vascular (`isVascularRiskApplication` em
    // src/lib/faceRegions.ts, o mesmo critério do alerta educativo do
    // Estágio 2 — ver `postProcedureEmergencyWarning` em
    // src/lib/postProcedureChecklist.ts) — nunca por "essa substância pode
    // ter risco em geral". Até esta feature, esse alerta só era visível ao
    // profissional NO MOMENTO da aplicação; esta seção garante que ele
    // também chegue ao paciente no documento pós-procedimento. Aparece nos
    // dois públicos, mesmo raciocínio das seções acima (segurança clínica,
    // não preço). Texto em vermelho (mesma cor #E05050 do alerta do Estágio
    // 2) pra se destacar das demais seções, que são só informativas.
    const emergencyWarning = postProcedureEmergencyWarning(stage2Overlay, t);
    if (emergencyWarning) {
      drawDivider();
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      const emergencyIntroLines = doc.splitTextToSize(emergencyWarning.intro, usableWidth);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      const emergencySignLines = emergencyWarning.signs.flatMap((sign) => doc.splitTextToSize(`•  ${sign}`, usableWidth));
      const emergencyBodyHeight = emergencyIntroLines.length * 12 + 10 + emergencySignLines.length * 14;
      drawSectionTitle(t('sessions.stage3.pdf.postCareEmergencyTitle'), emergencyBodyHeight);

      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.setTextColor(...PDF_COLORS.red);
      doc.text(emergencyIntroLines, marginX, y);
      y += emergencyIntroLines.length * 12 + 10;

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(...PDF_COLORS.red);
      doc.text(emergencySignLines, marginX, y);
      y += emergencySignLines.length * 14 + 24;
    }

    // Orçamento (total, custo de material, margem, parcelamento/desconto) é
    // visão exclusiva do profissional — nunca aparece no PDF do paciente,
    // por decisão de produto (o preço não deve ser mostrado ao paciente
    // nem na tela nem no documento; o profissional relata verbalmente).
    // Vira um card de destaque com fundo em tom clarinho da marca, já que é
    // o número mais importante do documento profissional.
    if (isProfessional && hasBudget) {
      drawDivider();

      // Linhas de condição de pagamento (parcelamento sugerido / desconto à
      // vista) para um orçamento dado — extraída porque agora precisa rodar
      // duas vezes (Plano A e Plano B) quando `showPlanB` está ligado.
      const paymentLinesFor = (
        installmentsList: Installment[],
        cashDiscount: number | null,
      ): string[] => {
        const lines: string[] = [];
        if (installmentsList.length > 0) {
          const maxInstallment = installmentsList[installmentsList.length - 1];
          lines.push(
            t('sessions.stage3.pdf.paymentInstallments', { n: maxInstallment.n, value: formatCurrency(maxInstallment.value, currency) }),
          );
        }
        if (cashDiscount !== null) {
          lines.push(t('sessions.stage3.pdf.paymentCashDiscount', { pct: cashDiscountPct, value: formatCurrency(cashDiscount, currency) }));
        }
        return lines;
      };

      if (showPlanB) {
        // ---------- Plano A (protocolo completo) x Plano B (versão reduzida) ----------
        // Análise competitiva do Full Face Academy: mostrar os dois lado a
        // lado no mesmo documento, com as condições de pagamento já
        // calculadas pros dois (âncora + saída) — ver decisão de escopo do
        // Plano B em src/lib/procedureCatalog.ts (reduceToPlanB/hasReducedPlanB).
        // Título desenhado só depois de medir os dois cards (cardHeight) —
        // bug P2, ver drawSectionTitle — pra reservar título+cards juntos.
        const planGap = 16;
        const planColWidth = (usableWidth - planGap) / 2;
        const cardPad = 14;
        const innerWidth = planColWidth - cardPad * 2 - 6;

        type MeasuredPlan = {
          totalLines: string[];
          costLines: string[];
          marginLines: string[];
          paymentLineArrs: string[][];
          height: number;
        };

        const measurePlan = (budgetData: BudgetBreakdown, paymentLines: string[]): MeasuredPlan => {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(13);
          const totalLines = doc.splitTextToSize(
            t('sessions.stage3.pdf.budgetTotal', { total: formatCurrency(budgetData.totalPrice, currency) }),
            innerWidth,
          );
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8.5);
          const costLines = doc.splitTextToSize(t('sessions.stage3.pdf.budgetCost', { cost: formatCurrency(budgetData.totalCost, currency) }), innerWidth);
          const marginLines = doc.splitTextToSize(
            t('sessions.stage3.pdf.budgetMargin', { margin: formatCurrency(budgetData.margin, currency), pct: Math.round(budgetData.marginPct * 100) }),
            innerWidth,
          );
          const paymentLineArrs = paymentLines.map((line) => doc.splitTextToSize(line, innerWidth - 12));
          const height =
            cardPad * 2 +
            16 + // rótulo "PLANO A/B"
            totalLines.length * 15 +
            4 +
            costLines.length * 11 +
            marginLines.length * 11 +
            (paymentLineArrs.length > 0 ? 8 + paymentLineArrs.reduce((sum, arr) => sum + arr.length * 11, 0) : 0);
          return { totalLines, costLines, marginLines, paymentLineArrs, height };
        };

        const planA = measurePlan(budget, paymentLinesFor(installments, cashDiscountValue));
        const planB = measurePlan(budgetPlanB, paymentLinesFor(installmentsPlanB, cashDiscountValuePlanB));
        const cardHeight = Math.max(planA.height, planB.height);
        drawSectionTitle(t('sessions.stage3.pdf.budgetPlansTitle'), cardHeight + 30);
        const boxY = y;

        const drawPlanCard = (x: number, label: string, measured: MeasuredPlan) => {
          doc.setFillColor(...pdfTint(PDF_COLORS.gMid, 0.92));
          doc.roundedRect(x, boxY, planColWidth, cardHeight, 10, 10, 'F');
          doc.setFillColor(...PDF_COLORS.gEnd);
          doc.roundedRect(x, boxY, 5, cardHeight, 2.5, 2.5, 'F');

          let by = boxY + cardPad + 4;
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(10);
          doc.setTextColor(...PDF_COLORS.gEnd);
          doc.text(label.toUpperCase(), x + cardPad + 6, by);
          by += 16;

          doc.setFont('helvetica', 'bold');
          doc.setFontSize(13);
          doc.setTextColor(...PDF_COLORS.gEnd);
          doc.text(measured.totalLines, x + cardPad + 6, by);
          by += measured.totalLines.length * 15 + 4;

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8.5);
          doc.setTextColor(...PDF_COLORS.text2);
          doc.text(measured.costLines, x + cardPad + 6, by);
          by += measured.costLines.length * 11;
          doc.text(measured.marginLines, x + cardPad + 6, by);
          by += measured.marginLines.length * 11;

          if (measured.paymentLineArrs.length > 0) {
            by += 8;
            measured.paymentLineArrs.forEach((lines) => {
              doc.setFillColor(...PDF_COLORS.green);
              doc.circle(x + cardPad + 9, by - 3, 2.5, 'F');
              doc.setFont('helvetica', 'bold');
              doc.setFontSize(8.5);
              doc.setTextColor(...PDF_COLORS.text);
              doc.text(lines, x + cardPad + 18, by);
              by += lines.length * 11;
            });
          }
        };

        drawPlanCard(marginX, t('sessions.stage3.pdf.planALabel'), planA);
        drawPlanCard(marginX + planColWidth + planGap, t('sessions.stage3.pdf.planBLabel'), planB);

        y = boxY + cardHeight + 34;
      } else {
        // ---------- Orçamento único (sem Plano B a mostrar) ----------
        const budgetPad = 20;
        const paymentLines = paymentLinesFor(installments, cashDiscountValue);
        const boxHeight = budgetPad * 2 + 30 + 16 * 2 + (paymentLines.length > 0 ? 10 + paymentLines.length * 16 : 0);
        ensureSpace(boxHeight + 20);
        const boxY = y;
        doc.setFillColor(...pdfTint(PDF_COLORS.gMid, 0.92));
        doc.roundedRect(marginX, boxY, usableWidth, boxHeight, 10, 10, 'F');
        doc.setFillColor(...PDF_COLORS.gEnd);
        doc.roundedRect(marginX, boxY, 5, boxHeight, 2.5, 2.5, 'F');

        let by = boxY + budgetPad + 6;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(19);
        doc.setTextColor(...PDF_COLORS.gEnd);
        doc.text(t('sessions.stage3.pdf.budgetTotal', { total: formatCurrency(budget.totalPrice, currency) }), marginX + budgetPad + 8, by);
        by += 28;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(...PDF_COLORS.text2);
        doc.text(t('sessions.stage3.pdf.budgetCost', { cost: formatCurrency(budget.totalCost, currency) }), marginX + budgetPad + 8, by);
        by += 16;
        doc.text(
          t('sessions.stage3.pdf.budgetMargin', { margin: formatCurrency(budget.margin, currency), pct: Math.round(budget.marginPct * 100) }),
          marginX + budgetPad + 8,
          by,
        );
        by += 16;

        // Condições de pagamento configuradas em Perfil.tsx — referência pro
        // profissional relatar ao paciente verbalmente, já que o preço não
        // aparece em nenhum documento que o paciente recebe.
        if (paymentLines.length > 0) {
          by += 10;
          paymentLines.forEach(paymentLine => {
            doc.setFillColor(...PDF_COLORS.green);
            doc.circle(marginX + budgetPad + 11, by - 3, 3, 'F');
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(10);
            doc.setTextColor(...PDF_COLORS.text);
            doc.text(paymentLine, marginX + budgetPad + 22, by);
            by += 16;
          });
        }

        y = boxY + boxHeight + 34;
      }
    }

    // Achado do QA Contínuo: `hasBudget` (totalPrice > 0) some com a seção
    // de orçamento INTEIRA sem explicação quando `budget.unpriced.length > 0`
    // e nenhum ponto tem preço (ex.: sessão nova, nenhum insumo/marca
    // atribuído ainda) — parecia bug de exportação do PDF pro profissional,
    // não falta de cadastro. Mesmo quando o card de orçamento aparece
    // (`hasBudget` true, mas só PARTE dos pontos tem preço), o profissional
    // não tinha como saber que o total mostrado estava incompleto. Esta nota
    // discreta roda independente de `hasBudget` — é o oposto de omitir a
    // seção em silêncio — e usa sempre o Plano A (`budget`, não
    // `budgetPlanB`) porque é o protocolo completo que referencia todo ponto
    // sem preço, Plano B ou não.
    if (isProfessional && budget.unpriced.length > 0) {
      const unpricedNote = t('sessions.stage3.pdf.budgetUnpricedNote', { count: budget.unpriced.length });
      const unpricedLines = doc.splitTextToSize(unpricedNote, usableWidth);
      ensureSpace(unpricedLines.length * 12 + 20);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.setTextColor(...PDF_COLORS.amber);
      doc.text(unpricedLines, marginX, y);
      y += unpricedLines.length * 12 + 20;
    }

    drawDivider();

    // ---------- Selo de Conformidade Clínica (P6-2) ----------
    // Torna visível, por sessão, se a trilha de segurança clínica já
    // construída em squads anteriores (triagem ABCDE, anamnese, TCLE geral e
    // de procedimento, teto de dose, guardrail de zona de risco vascular e,
    // quando aplicável, intervalo mínimo entre aplicações de toxina — ver
    // src/lib/complianceSummary.ts) está completa para ESTA sessão. Nunca um
    // bloqueio novo: cada gate já bloqueia (raro) ou apenas alerta no fluxo
    // principal — esta seção só reúne o resultado num só lugar, auditável,
    // para o profissional e para o paciente. `complianceSummary` é null só
    // durante o `loading` inicial da tela; `handleExportPdf` já espera esse
    // carregamento terminar antes de habilitar o botão de exportar, então
    // na prática este bloco sempre desenha quando o PDF é gerado.
    if (complianceSummary) {
      const orderedGates = COMPLIANCE_GATE_ORDER
        .map((key) => complianceSummary.gates.find((g) => g.key === key))
        .filter((g): g is (typeof complianceSummary.gates)[number] => Boolean(g));

      const contextLabel = (key: ComplianceGateKey, context: string[]): string => {
        if (context.length === 0) return '';
        if (key === 'doseThreshold') {
          return context.map((s) => SUBSTANCE_LABEL[s as Substance] ?? s).join(', ');
        }
        return context.map((r) => regionLabel(r)).join(', ');
      };

      type ComplianceRow = { label: string; met: boolean; statusText: string; extraLines: string[] };
      const complianceRows: ComplianceRow[] = orderedGates.map((gate) => {
        const dateStr = gate.at
          ? format(new Date(gate.at), 'P', { locale: dateFnsLocale[i18n.language] ?? ptBR })
          : t('sessions.stage3.pdf.compliance.noDate');
        const statusText = t(
          gate.status === 'met' ? 'sessions.stage3.pdf.compliance.statusMet' : 'sessions.stage3.pdf.compliance.statusAttention',
          { date: dateStr },
        );
        const detail = contextLabel(gate.key, gate.context);
        const extraLines: string[] = [];
        if (detail) extraLines.push(t('sessions.stage3.pdf.compliance.detailLine', { detail }));
        if (gate.fingerprint) extraLines.push(t('sessions.stage3.pdf.compliance.fingerprintLine', { hash: gate.fingerprint }));
        return {
          label: t(`sessions.stage3.pdf.compliance.gates.${gate.key}`),
          met: gate.status === 'met',
          statusText,
          extraLines,
        };
      });

      const rowPad = 16;
      const rowGap = 14;
      const rowLabelHeight = 13;
      const rowStatusHeight = 12;
      const rowExtraLineHeight = 11;
      const rowHeights = complianceRows.map((r) => rowLabelHeight + rowStatusHeight + r.extraLines.length * rowExtraLineHeight);
      const boxHeight = rowPad * 2 + rowHeights.reduce((sum, h) => sum + h, 0) + rowGap * (complianceRows.length - 1);

      drawSectionTitle(t('sessions.stage3.pdf.compliance.title'), boxHeight + 30);
      const boxY = y - 8;
      doc.setFillColor(...PDF_COLORS.surface);
      doc.roundedRect(marginX, boxY, usableWidth, boxHeight, 8, 8, 'F');
      doc.setFillColor(...PDF_COLORS.gMid);
      doc.roundedRect(marginX, boxY, 4, boxHeight, 2, 2, 'F');

      // Ternário `met ? PDF_COLORS.x : PDF_COLORS.y` inline perde a tupla
      // (widen pra uma união de tuplas, que o spread de setFillColor/
      // setTextColor abaixo não aceita) — funções helper com tipo de
      // retorno explícito preservam a tupla.
      const dotColor = (met: boolean): readonly [number, number, number] =>
        met ? PDF_COLORS.green : PDF_COLORS.amber;
      const statusTextColor = (met: boolean): readonly [number, number, number] =>
        met ? PDF_COLORS.text2 : PDF_COLORS.amber;

      let rowY = boxY + rowPad + 8;
      const dotX = marginX + 20;
      const textX = marginX + 34;
      const textWidth = usableWidth - 34 - 16;
      complianceRows.forEach((row, i) => {
        doc.setFillColor(...dotColor(row.met));
        doc.circle(dotX, rowY - 4, 3.5, 'F');

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10.5);
        doc.setTextColor(...PDF_COLORS.text);
        doc.text(doc.splitTextToSize(row.label, textWidth), textX, rowY);
        rowY += rowLabelHeight;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(...statusTextColor(row.met));
        doc.text(row.statusText, textX, rowY);
        rowY += rowStatusHeight;

        if (row.extraLines.length > 0) {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8.5);
          doc.setTextColor(...PDF_COLORS.text3);
          row.extraLines.forEach((line) => {
            doc.text(line, textX, rowY);
            rowY += rowExtraLineHeight;
          });
        }

        if (i < complianceRows.length - 1) rowY += rowGap;
      });

      y = boxY + boxHeight + 34;
      drawDivider();
    }

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    doc.setTextColor(...PDF_COLORS.text3);
    const disclaimer = t('sessions.stage3.pdf.disclaimer');
    const disclaimerLines = doc.splitTextToSize(disclaimer, usableWidth);
    ensureSpace(disclaimerLines.length * 12);
    doc.text(disclaimerLines, marginX, y);
    y += disclaimerLines.length * 12 + 22;

    // QR code de verificação (item da análise competitiva do Full Face
    // Academy) — só desenhado quando a geração deu certo; ausente (professional,
    // ou falha ao gerar link/QR) simplesmente não desenha nada aqui, igual ao
    // padrão de `fetchImageAsDataUrl` acima pra fotos indisponíveis.
    if (qrDataUrl) {
      const qrSize = 58;
      const qrTextX = marginX + qrSize + 14;
      const qrTextWidth = usableWidth - qrSize - 14;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      const qrTitleLines = doc.splitTextToSize(t('sessions.stage3.pdf.verificationTitle'), qrTextWidth);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      const qrBodyLines = doc.splitTextToSize(t('sessions.stage3.pdf.verificationBody'), qrTextWidth);
      const qrBlockHeight = Math.max(qrSize, qrTitleLines.length * 11 + 6 + qrBodyLines.length * 10.5);
      ensureSpace(qrBlockHeight + 10);

      const qrTop = y;
      try {
        doc.addImage(qrDataUrl, 'PNG', marginX, qrTop, qrSize, qrSize);
      } catch {
        // Formato inesperado do data URL do QR — mesma rede de segurança já
        // usada nos addImage de foto/logo acima; segue sem o QR em vez de
        // derrubar o export inteiro por causa de um selo de verificação.
      }
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(...PDF_COLORS.text2);
      doc.text(qrTitleLines, qrTextX, qrTop + 12);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(...PDF_COLORS.text3);
      doc.text(qrBodyLines, qrTextX, qrTop + 12 + qrTitleLines.length * 11 + 6);

      y = qrTop + qrBlockHeight + 20;
    }

    // Rodapé com numeração de página e nome da clínica, aplicado a todas as
    // páginas quando o conteúdo ultrapassa uma única página.
    const totalPages = doc.getNumberOfPages();
    if (totalPages > 1) {
      for (let page = 1; page <= totalPages; page++) {
        doc.setPage(page);
        const footerY = pageHeight - 30;
        doc.setDrawColor(...PDF_COLORS.surface3);
        doc.setLineWidth(0.5);
        doc.line(marginX, footerY - 14, pageWidth - marginX, footerY - 14);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(...PDF_COLORS.text3);
        doc.text(
          t('sessions.stage3.pdf.footer', { clinic: pdfData.clinicName || 'FacialPlan', current: page, total: totalPages }),
          pageWidth / 2,
          footerY,
          { align: 'center' },
        );
      }
      doc.setPage(totalPages);
    }

    const audienceSuffix = isProfessional ? '_profissional' : '';
    const filename = `${pdfData.patientName.replace(/\s+/g, '_')}_${pdfData.procedureName.replace(/\s+/g, '_')}${audienceSuffix}.pdf`;
    const pdfBlob = doc.output('blob');
    doc.save(filename);
    toast.success(t('sessions.stage3.toastPdfGenerated'));
    logDataAccess('export_pdf', 'session', id);

    // Persiste o PDF no storage do paciente. Os dois públicos ficam em
    // caminhos distintos para não se sobrescreverem; sessions.pdf_url só é
    // atualizado pela versão do paciente (é a versão que representa "o
    // plano" para quem consome esse campo depois).
    try {
      const pdfPath = `${user.id}/${id}/plano${audienceSuffix}.pdf`;
      const { error: uploadErr } = await supabase.storage
        .from('patient-photos')
        .upload(pdfPath, pdfBlob, { upsert: true, contentType: 'application/pdf' });
      if (uploadErr) throw uploadErr;

      if (!isProfessional) {
        await supabase.from('sessions').update({ pdf_url: pdfPath }).eq('id', id);
      }
    } catch {
      // Falha ao persistir o PDF não deve travar o fluxo — o download local já aconteceu.
      toast.info(t('sessions.stage3.toastPdfNotPersisted'));
    }
    } catch (err: unknown) {
      // Chega aqui só se algo lançou ANTES do doc.save() (fetch de foto,
      // formato inesperado de stage1_analysis, cálculo de orçamento) — o
      // download local nunca aconteceu, diferente do catch interno acima.
      const message = err instanceof Error ? err.message : String(err);
      // eslint-disable-next-line no-console
      console.error('[SessaoEstagio3] Falha ao exportar PDF:', err);
      toast.error(t('sessions.stage3.toastPdfExportFailed'));
      logClientError({
        professionalId: user.id,
        sessionId: id,
        stage: 'export_pdf',
        errorType: 'pdf_export_failed',
        message: `audience=${audience} :: ${message}`,
      });
    }
  };

  const handleComplete = async () => {
    // Guarda contra duplo clique/duplo toque: sem isso, a baixa de estoque
    // por lote abaixo (consume_insumo_stock_fefo) roda duas vezes em
    // paralelo e decrementa o mesmo consumo real duas vezes do lote —
    // achado do QA Contínuo, mesmo padrão de `saving` já usado em
    // EstoqueTab.tsx/AgendaTab.tsx para botões assíncronos.
    //
    // Achado do QA Contínuo ciclo 100: faltava o try/catch/finally — se o
    // UPDATE abaixo rejeitasse (falha de rede real, não um erro HTTP normal
    // do Supabase, que vem como `{ error }` sem rejeitar a Promise),
    // `setCompleting(false)` nunca era alcançado e o botão "Concluir" ficava
    // desabilitado para sempre, sem nenhum toast, até um reload completo da
    // página — mesmo padrão de correção já usado em
    // EstoqueTab.tsx/AgendaTab.tsx para `saving`.
    if (!id || completing) return;
    setCompleting(true);
    try {
      await handleCompleteInner(id);
    } catch (err: any) {
      toast.error(err.message || t('sessions.stage3.sessionCompleteError'));
    } finally {
      setCompleting(false);
    }
  };

  const handleCompleteInner = async (id: string) => {
    await supabase.from('sessions').update({ status: 'complete' }).eq('id', id);

    // Decremento automático de estoque por lote (item 2 do escopo ERP de
    // estoque, ver migration 20260911040000_add_insumo_stock_batches.sql):
    // uma chamada por insumo/marca efetivamente usado nos pontos de
    // aplicação desta sessão, consumindo os lotes mais antigos/próximos do
    // vencimento primeiro (FEFO, com fallback pra FIFO — lógica espelhada em
    // src/lib/stockBatches.ts#computeFefoConsumption pra ser testável sem
    // banco). Roda em paralelo, DEPOIS de já ter marcado a sessão como
    // concluída, e nunca trava nem reverte a conclusão: falha de rede, RPC
    // ausente num ambiente ainda não migrado, ou simplesmente não haver
    // nenhum lote registrado pro insumo (comum vindo da V1 mini de estoque)
    // só significa que a baixa não teve de onde tirar lote — a função no
    // banco já lida com isso registrando uma movimentação sem lote, e aqui
    // do lado do client um erro é só logado, nunca exibido como bloqueio ao
    // profissional que já viu "sessão concluída".
    const consumptionByInsumo = aggregateConsumptionByInsumo(stage2Overlay);
    if (consumptionByInsumo.size > 0 && user) {
      void Promise.allSettled(
        Array.from(consumptionByInsumo.entries()).map(([insumoId, quantity]) =>
          supabase.rpc('consume_insumo_stock_fefo', { p_insumo_id: insumoId, p_quantity: quantity, p_session_id: id }),
        ),
      ).then((results) => {
        for (const result of results) {
          if (result.status === 'fulfilled' && result.value?.error) {
            console.error('[SessaoEstagio3] Falha ao decrementar estoque por lote:', result.value.error);
          } else if (result.status === 'rejected') {
            console.error('[SessaoEstagio3] Falha ao decrementar estoque por lote:', result.reason);
          }
        }
      });
    }

    toast.success(t('sessions.stage3.sessionCompleted'));
    // Antes ia para Home ('/'), que só lista sessões ativas — a sessão que
    // acabou de ser concluída desaparecia da tela imediatamente, sem
    // nenhum link de volta pra ela (só reaparecia se o profissional soubesse
    // ir em Sessões > Concluídas ou na ficha do paciente). Navegar direto
    // pra tela de apresentação entrega exatamente a visualização que o
    // profissional quer "ver novamente" logo depois de fechar o procedimento.
    navigate(`/sessoes/${id}/present`, { replace: true });
  };

  // Orçamento (custo x preço x margem) é visão exclusiva do profissional —
  // nunca aparece na tela de apresentação nem no PDF do paciente, só no PDF
  // profissional (ver handleExportPdf). Por isso é calculado sobre todos os
  // pontos, sem mecanismo de inclusão/exclusão ao vivo (não faz sentido
  // "negociar" um valor que o paciente nunca vê nesta tela).
  const budget = useMemo(
    () => computeBudget(stage2Overlay, insumos, laborFeePerSession),
    [stage2Overlay, insumos, laborFeePerSession],
  );
  const hasBudget = budget.totalPrice > 0;
  const installments = useMemo(
    () => computeInstallments(budget.totalPrice, maxInstallments),
    [budget.totalPrice, maxInstallments],
  );
  const cashDiscountValue = useMemo(
    () => computeCashDiscount(budget.totalPrice, cashDiscountPct),
    [budget.totalPrice, cashDiscountPct],
  );

  // "Plano B" (orçamento reduzido) — análise competitiva do Full Face
  // Academy: mostrar no mesmo laudo um protocolo completo (Plano A, acima) e
  // uma versão reduzida (Plano B) lado a lado, com as mesmas condições de
  // pagamento já calculadas pros dois. `showPlanB` só liga quando o Plano B
  // calculado é de fato mais enxuto em pelo menos um ponto (ver
  // `hasReducedPlanB` em procedureCatalog.ts) — sem isso, um plano sem
  // nenhum procedimento nomeado do catálogo mostraria dois cartões idênticos.
  const showPlanB = useMemo(() => hasReducedPlanB(stage2Overlay), [stage2Overlay]);
  const budgetPlanB = useMemo(
    () => computeBudget(reduceToPlanB(stage2Overlay), insumos, laborFeePerSession),
    [stage2Overlay, insumos, laborFeePerSession],
  );
  const installmentsPlanB = useMemo(
    () => computeInstallments(budgetPlanB.totalPrice, maxInstallments),
    [budgetPlanB.totalPrice, maxInstallments],
  );
  const cashDiscountValuePlanB = useMemo(
    () => computeCashDiscount(budgetPlanB.totalPrice, cashDiscountPct),
    [budgetPlanB.totalPrice, cashDiscountPct],
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-h-bg">
        <TopBar title={t('sessions.stage3.title')} showBack />
        <div className="pt-[56px] p-5">
          <div className="bg-h-white rounded-r shadow-h-sm h-[300px] animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg pb-28">
      <TopBar
        title={t('sessions.stage3.title')}
        showBack
        onBack={() => navigate(`/sessoes/${id}/estagio-2`)}
        rightAction={
          genState === 'done' ? (
            // BUG CORRIGIDO: era um link de texto rosa (`text-h-g-start`) no
            // header, sem fundo — quase invisível ao lado do "Concluir"
            // sólido (GradientButton) que já existe na barra inferior desta
            // mesma tela. Mesmo padrão já corrigido em HeaderSaveButton (Perfil).
            <GhostButton
              onClick={() => navigate(`/sessoes/${id}/present`)}
              className="!w-auto !h-auto !min-h-[44px] px-3 py-2 text-[13px]"
            >
              {t('sessions.stage3.present')}
            </GhostButton>
          ) : undefined
        }
      />
      <div className="pt-[56px] max-w-[430px] md:max-w-[560px] mx-auto w-full">
        <div className="px-5 py-4 flex justify-center">
          <StageDots currentStage={3} activeColor="#7C5AC2" />
        </div>

        <div className="px-5 flex flex-col gap-4">
          {/* Proveniência da análise da Etapa 1 — mesmo aviso persistente da
              Etapa 1 (ver SessaoEstagio1.tsx), repetido aqui porque é NESTA
              tela que o plano vira PDF assinado, e-mail e link de
              apresentação: o profissional precisa ver o carimbo antes de
              exportar, não só lá atrás. O PDF gerado abaixo leva o mesmo
              carimbo (ver handleExportPdf). */}
          <AnalysisProvenanceBanner provenance={analysisProvenance(stage1Analysis)} />

          {/* Intensity selector */}
          <div className="bg-h-white rounded-r-sm shadow-h-sm p-1 flex">
            {(['sutil', 'natural', 'marcante'] as const).map(opt => (
              <button
                key={opt}
                onClick={() => setIntensity(opt)}
                className={`flex-1 py-2.5 text-[13px] font-semibold rounded-[8px] transition-all capitalize ${
                  intensity === opt
                    ? 'bg-gradient-brand shadow-h-sm'
                    : 'text-h-text-3'
                }`}
                style={intensity === opt ? { color: '#fff' } : {}}
              >
                {t(`sessions.stage3.intensity.${opt}`)}
              </button>
            ))}
          </div>

          {/* Main content area */}
          {genState === 'idle' && (
            <button
              onClick={handleGenerate}
              className="w-full aspect-[3/4] bg-gradient-brand rounded-r flex flex-col items-center justify-center gap-3 transition-all active:scale-[0.98]"
            >
              <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                  <circle cx="12" cy="13" r="4" />
                </svg>
              </div>
              <p className="text-[16px] font-bold" style={{ color: '#fff' }}>{t('sessions.stage3.generate')}</p>
              <p className="text-[12px] font-medium" style={{ color: 'rgba(255,255,255,0.7)' }}>{t('sessions.stage3.generateEta')}</p>
            </button>
          )}

          {genState === 'generating' && (
            <div className="w-full aspect-[3/4] bg-h-white rounded-r shadow-h-sm flex flex-col items-center justify-center gap-5">
              <div className="animate-pulse">
                <LogoMark size={64} />
              </div>
              <p className="text-[14px] font-semibold text-h-text-2 animate-pulse">
                {simMessages[genMsg]}
              </p>
            </div>
          )}

          {genState === 'done' && (
            <>
              <BeforeAfterViewer beforeImageUrl={beforeUrl ?? undefined} afterImageUrl={afterUrl ?? undefined} />

              <SecondaryButton onClick={handleNewVariation} className="w-auto">
                ↺ {t('sessions.stage3.newVariation', { count: variationCount })}
              </SecondaryButton>
            </>
          )}

          {/* Disclaimer + frase de confiança do guardrail anatômico (backlog
              P2 "Guardrail anatômico como frase de confiança na UI") — só
              exibida porque o prompt enviado à Gemini em generate-simulation
              de fato instrui limites anatômicos plausíveis (ver
              ANATOMICAL_SAFETY_INSTRUCTION em generate-simulation/index.ts);
              não é uma validação da imagem gerada, só do que foi pedido à IA. */}
          <div className="bg-h-surface rounded-r-sm p-3 flex flex-col gap-1.5">
            <div className="flex items-center justify-center gap-1.5">
              <ShieldCheck size={12} className="flex-shrink-0" style={{ color: '#1A9E5C' }} />
              <p className="text-[10px] font-semibold text-h-text-2 text-center">
                {t('sessions.stage3.anatomicalGuardrail')}
              </p>
            </div>
            <p className="text-[10px] text-h-text-3 text-center leading-relaxed">
              {t('sessions.stage3.disclaimer')}
            </p>
          </div>
        </div>
      </div>

      {/* Bottom actions */}
      {genState === 'done' && (
        <div className="fixed bottom-0 left-0 right-0 p-5 bg-h-bg" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
          <div className="max-w-[430px] md:max-w-[560px] mx-auto flex gap-3">
            <SecondaryButton onClick={() => setShareOpen(true)} className="flex-1" disabled={!pdfData}>
              ↗ {t('sessions.stage3.share')}
            </SecondaryButton>
            <GradientButton onClick={handleComplete} className="flex-1" disabled={completing}>
              {t('sessions.stage3.complete')}
            </GradientButton>
          </div>
        </div>
      )}

      <BottomSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        title={t('sessions.stage3.shareSheetTitle')}
      >
        <div style={{ padding: '0 20px 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <ShareOptionRow
            icon={<MessageCircle size={20} color="#1A9E5C" />}
            label={t('sessions.stage3.shareWhatsApp')}
            onClick={handleShareWhatsApp}
          />
          <ShareOptionRow
            icon={<Mail size={20} color="#7C5AC2" />}
            label={t('sessions.stage3.shareEmail')}
            onClick={handleShareEmail}
          />
          <ShareOptionRow
            icon={<FileDown size={20} color="#BF5F82" />}
            label={t('sessions.stage3.exportPdfPatient')}
            onClick={handleShareExportPdf('patient')}
          />
          <ShareOptionRow
            icon={<FileText size={20} color="#2D8FB8" />}
            label={t('sessions.stage3.exportPdfProfessional')}
            onClick={handleShareExportPdf('professional')}
          />
          <button
            onClick={() => setShareOpen(false)}
            style={{
              width: '100%', padding: 16, fontSize: 15, fontWeight: 600,
              color: '#AAA8A5', background: 'transparent', border: 'none',
              cursor: 'pointer', marginTop: 4,
              fontFamily: "'Plus Jakarta Sans', sans-serif",
            }}
          >
            {t('sessions.stage3.shareCancel')}
          </button>
        </div>
      </BottomSheet>
    </div>
    </PageTransition>
  );
};

const ShareOptionRow: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void }> = ({ icon, label, onClick }) => (
  <button
    onClick={onClick}
    style={{
      width: '100%', display: 'flex', alignItems: 'center', gap: 14,
      padding: 16, fontSize: 15, fontWeight: 600, color: '#1A1918',
      background: '#F5F4F2', border: 'none', borderRadius: 12,
      cursor: 'pointer', textAlign: 'left',
      fontFamily: "'Plus Jakarta Sans', sans-serif",
    }}
  >
    <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 36, height: 36, borderRadius: '50%', background: '#FFFFFF', flexShrink: 0 }}>
      {icon}
    </span>
    {label}
  </button>
);

export default SessaoEstagio3;
