import React from 'react';
import LegalDocumentPage from '@/components/site/LegalDocumentPage';
import { PRIVACY_BODY_PT, PRIVACY_VERSION } from '@/lib/legalDocs';

// Rota pública /privacidade. Conteúdo real em
// src/content/legal/politica-de-privacidade.pt.md — inclui a lista de
// subprocessadores, que foi levantada do código (não de memória) e precisa
// ser atualizada no mesmo commit em que uma integração entrar ou sair.
const Privacidade: React.FC = () => (
  <LegalDocumentPage
    titleKey="legal.privacy.title"
    descriptionKey="legal.privacy.description"
    version={PRIVACY_VERSION}
    body={PRIVACY_BODY_PT}
  />
);

export default Privacidade;
