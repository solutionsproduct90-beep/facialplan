import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import PacienteDetalhe from "./PacienteDetalhe";
import { createQueryBuilder } from "@/test/supabaseMock";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();
const linksInsertSpy = vi.fn();
const functionsInvokeMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
    // TCLE geral (handleConsent) — ver descreve "Consentimento Geral (TCLE)"
    // abaixo: grava via edge function record-consent em vez de
    // `.from('consents').insert(...)` direto, mesmo padrão do TCLE de
    // procedimento (SessaoEstagio2.tsx).
    functions: { invoke: (...args: unknown[]) => functionsInvokeMock(...args) },
    // Ecoa o path recebido no próprio signedUrl (em vez de sempre `null`) —
    // permite que os testes da Linha do Tempo Evolutiva verifiquem qual
    // foto (path) acabou em cada <img>, sem afetar os testes existentes de
    // anamnese (que nunca têm `photo_url` preenchido). `createSignedUrl`
    // (singular) é usado pela foto de anamnese em PacienteDetalhe.tsx;
    // `createSignedUrls` (lote) é o usado por PatientEvolutionTimeline
    // desde a correção do N+1 de assinatura de URLs.
    storage: {
      from: () => ({
        createSignedUrl: async (path: string) => ({ data: { signedUrl: `https://signed.test/${path}` } }),
        createSignedUrls: async (paths: string[]) => ({
          data: paths.map((path) => ({ path, signedUrl: `https://signed.test/${path}`, signedURL: null, error: null })),
          error: null,
        }),
      }),
    },
  },
}));

const PATIENT = {
  id: "pat-1",
  name: "Maria Silva",
  phone: "11999999999",
  birth_date: null,
  notes: null,
  consent_given: true,
  last_consent_at: null,
  referral_code: "AB12CD34",
  referred_by_patient_id: null,
};

const ANAMNESIS = {
  id: "an-1",
  patient_id: "pat-1",
  professional_id: "pro-1",
  main_complaint: "Rugas na testa",
  skin_type: "oily",
  skin_texture: null,
  oiliness: null,
  discromia: [],
  vascularization: [],
  risk_flags: { diabetes: true, allergy: { has: true, which: "Dipirona" } },
  photo_url: null,
  filled_by: "patient_link",
  reviewed_at: null,
  created_at: "2026-01-10T00:00:00.000Z",
  updated_at: "2026-01-10T00:00:00.000Z",
};

/**
 * Builder específico pra `anamnesis_links`: só precisa suportar a chamada
 * feita por handleSendAnamnesisLink em PacienteDetalhe.tsx —
 * `.insert(payload).select('token').single()`.
 */
function createAnamnesisLinksBuilder(token: string) {
  return {
    insert: (payload: unknown) => {
      linksInsertSpy(payload);
      return {
        select: () => ({
          single: () => Promise.resolve({ data: { token }, error: null }),
        }),
      };
    },
  };
}

// `retry: false` porque um dos casos exercita a FALHA de leitura da anamnese:
// com o padrão do react-query (3 tentativas com backoff), o estado de erro só
// apareceria segundos depois. Não muda nada para os casos de sucesso.
const renderPage = () =>
  render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <MemoryRouter initialEntries={["/pacientes/pat-1"]}>
        <Routes>
          <Route path="/pacientes/:id" element={<PacienteDetalhe />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>
  );

describe("PacienteDetalhe — Prontuário (anamnese)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    rpcMock.mockReset();
    linksInsertSpy.mockReset();
    vi.spyOn(window, "open").mockImplementation(() => null);

    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT }, { data: PATIENT });
      if (table === "sessions") return createQueryBuilder({ data: [] }, { data: [] });
      if (table === "anamnesis_links") return createAnamnesisLinksBuilder("tok-abc-123");
      return createQueryBuilder();
    });
    // Anamnese agora é lida via RPC get_patient_anamnesis (SECURITY DEFINER,
    // já loga em audit_log no servidor — ver PacienteDetalhe.tsx e
    // 20260910220000_add_get_patient_anamnesis_rpc.sql), não mais via
    // `.from('anamnesis')` direto.
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "get_patient_anamnesis") return createQueryBuilder(undefined, { data: null });
      return createQueryBuilder();
    });
  });

  it("shows the empty state with a CTA when the patient has no anamnesis yet", async () => {
    renderPage();

    expect(await screen.findByText("Nenhuma anamnese preenchida ainda")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Preencher em nome do paciente" })).toBeInTheDocument();
  });

  it("generates an anamnesis link tied to the patient and opens WhatsApp with it", async () => {
    renderPage();
    await screen.findByText("Nenhuma anamnese preenchida ainda");

    const sendButtons = screen.getAllByRole("button", { name: "Enviar anamnese" });
    fireEvent.click(sendButtons[0]);

    await waitFor(() => expect(linksInsertSpy).toHaveBeenCalledTimes(1));
    const insertPayload = linksInsertSpy.mock.calls[0][0] as { patient_id: string; professional_id: string };
    expect(insertPayload.patient_id).toBe("pat-1");
    expect(insertPayload.professional_id).toBe("pro-1");

    await waitFor(() => expect(window.open).toHaveBeenCalledTimes(1));
    const [url] = (window.open as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(url).toContain("https://wa.me/?text=");
    expect(decodeURIComponent(url)).toContain("/anamnese/tok-abc-123");
  });

  it("splits an existing anamnesis into a read-only patient section and an editable clinical section, and 'Ver dados' scrolls to it", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT }, { data: PATIENT });
      if (table === "sessions") return createQueryBuilder({ data: [] }, { data: [] });
      if (table === "anamnesis_links") return createAnamnesisLinksBuilder("tok-abc-123");
      return createQueryBuilder({ data: [] }, { data: [] });
    });
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "get_patient_anamnesis") return createQueryBuilder(undefined, { data: ANAMNESIS });
      return createQueryBuilder();
    });

    renderPage();

    expect(await screen.findByText("Anamnese do Paciente")).toBeInTheDocument();
    expect(screen.getByText("Avaliação Clínica")).toBeInTheDocument();
    // Respostas do paciente aparecem como texto simples (Sim/Não), nunca
    // como checkbox editável — a edição fica restrita à Avaliação Clínica.
    expect(screen.getByText("Você tem diabetes?")).toBeInTheDocument();
    expect(screen.queryByRole("checkbox", { name: /diabetes/i })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Editar avaliação" })).toBeInTheDocument();

    const scrollSpy = vi.fn();
    // jsdom não implementa scrollIntoView — o botão precisa continuar
    // funcionando (guardado com `?.`) mesmo quando ele não existe.
    HTMLElement.prototype.scrollIntoView = scrollSpy;
    fireEvent.click(screen.getByRole("button", { name: "Ver dados" }));
    expect(scrollSpy).toHaveBeenCalledTimes(1);
  });

  // ── Falha ao LER a anamnese (achado do ciclo 54 do QA Contínuo) ──────────
  //
  // A queryFn relança o erro desde a correção original, mas `isError` nunca
  // era desestruturado e a renderização só tinha dois ramos. Uma falha de RPC
  // (permissão, rede, RLS) caía no ramo "nenhuma anamnese preenchida ainda" —
  // a mesma frase de um paciente que de fato nunca respondeu, que é
  // exatamente o sintoma que aquela correção existia para eliminar.
  //
  // A consequência passa de informação errada para perda de dado clínico:
  // AnamnesisSheet grava com `upsert(..., { onConflict: 'patient_id' })`,
  // então preencher nesse estado sobrescreve a anamnese que existe e só não
  // carregou, junto com as flags de risco que ela carrega.
  it("avisa que a leitura da anamnese falhou, em vez de dizer que não existe", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "get_patient_anamnesis") {
        return createQueryBuilder(undefined, { data: null, error: { message: "permission denied" } });
      }
      return createQueryBuilder();
    });

    renderPage();

    expect(await screen.findByText("Não foi possível carregar a anamnese")).toBeInTheDocument();
    expect(screen.queryByText("Nenhuma anamnese preenchida ainda")).not.toBeInTheDocument();
  });

  it("não oferece preencher nem enviar link quando a leitura falhou", async () => {
    // Este é o caso que protege o dado clínico. Enquanto não se sabe o que
    // existe, escrever é a operação errada — então os botões que escrevem não
    // podem estar na tela.
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "get_patient_anamnesis") {
        return createQueryBuilder(undefined, { data: null, error: { message: "permission denied" } });
      }
      return createQueryBuilder();
    });

    renderPage();
    await screen.findByText("Não foi possível carregar a anamnese");

    expect(screen.queryByRole("button", { name: "Preencher em nome do paciente" })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Tentar de novo" })).toBeInTheDocument();
  });

  it("segue mostrando o estado vazio de verdade quando a leitura funciona e não há anamnese", async () => {
    // Sem este caso, o ramo de erro poderia ter engolido o estado vazio
    // legítimo, que é o caminho comum de todo paciente novo.
    renderPage();

    expect(await screen.findByText("Nenhuma anamnese preenchida ainda")).toBeInTheDocument();
    expect(screen.queryByText("Não foi possível carregar a anamnese")).not.toBeInTheDocument();
  });

});

describe("PacienteDetalhe — Linha do Tempo Evolutiva", () => {
  const SESSIONS = [
    { id: "s1", created_at: "2026-01-05T00:00:00.000Z", status: "complete", original_image_url: "pro-1/s1.jpg", selected_procedure: "Botox" },
    { id: "s2", created_at: "2026-02-10T00:00:00.000Z", status: "complete", original_image_url: "pro-1/s2.jpg", selected_procedure: "Preenchimento" },
    // stage1 sem foto final ainda — não deve entrar na linha do tempo.
    { id: "s3", created_at: "2026-03-01T00:00:00.000Z", status: "stage1", original_image_url: null, selected_procedure: null },
  ];

  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT }, { data: PATIENT });
      if (table === "sessions") return createQueryBuilder({ data: SESSIONS }, { data: SESSIONS });
      if (table === "anamnesis") return createQueryBuilder(undefined, { data: null });
      return createQueryBuilder({ data: [] }, { data: [] });
    });
  });

  it("only lists completed sessions with a photo in the timeline gallery", async () => {
    renderPage();

    expect(await screen.findByTestId("evolution-photo-s1")).toBeInTheDocument();
    expect(screen.getByTestId("evolution-photo-s2")).toBeInTheDocument();
    expect(screen.queryByTestId("evolution-photo-s3")).not.toBeInTheDocument();
  });

  it("compares the two sessions picked from the timeline, oldest as before / newest as after", async () => {
    renderPage();

    const photoNew = await screen.findByTestId("evolution-photo-s2");
    const photoOld = screen.getByTestId("evolution-photo-s1");
    // Seleciona fora de ordem (mais nova primeiro) — a comparação deve
    // reordenar cronologicamente independente da ordem de clique.
    fireEvent.click(photoNew);
    fireEvent.click(photoOld);

    const compareButton = screen.getByRole("button", { name: "Comparar evolução" });
    expect(compareButton).not.toBeDisabled();
    fireEvent.click(compareButton);

    const viewer = await screen.findByTestId("before-after-viewer");
    const images = viewer.querySelectorAll("img");
    expect((images[0] as HTMLImageElement).src).toContain("pro-1/s1.jpg");
    expect((images[1] as HTMLImageElement).src).toContain("pro-1/s2.jpg");
  });

  it("does not render the timeline section when there are no completed sessions with a photo", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT }, { data: PATIENT });
      if (table === "sessions") return createQueryBuilder({ data: [SESSIONS[2]] }, { data: [SESSIONS[2]] });
      if (table === "anamnesis") return createQueryBuilder(undefined, { data: null });
      return createQueryBuilder({ data: [] }, { data: [] });
    });

    renderPage();

    await screen.findByText("Maria Silva");
    expect(screen.queryByTestId("evolution-timeline-gallery")).not.toBeInTheDocument();
  });
});

describe("PacienteDetalhe — Programa de Indicação", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    linksInsertSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT }, { data: PATIENT });
      if (table === "sessions") return createQueryBuilder({ data: [] }, { data: [] });
      if (table === "anamnesis") return createQueryBuilder(undefined, { data: null });
      if (table === "anamnesis_links") return createAnamnesisLinksBuilder("tok-abc-123");
      return createQueryBuilder();
    });
  });

  it("shows the patient's own referral code and copies it to the clipboard", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", { value: { writeText }, configurable: true });

    renderPage();

    expect(await screen.findByText(PATIENT.referral_code)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Copiar código/ }));
    await waitFor(() => expect(writeText).toHaveBeenCalledWith(PATIENT.referral_code));
  });

  it("shows no referrals yet when the count is zero", async () => {
    renderPage();
    expect(await screen.findByText("Ainda não indicou nenhum paciente")).toBeInTheDocument();
  });

  it("shows how many patients this patient has already referred", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT, count: 2 }, { data: PATIENT });
      if (table === "sessions") return createQueryBuilder({ data: [] }, { data: [] });
      if (table === "anamnesis") return createQueryBuilder(undefined, { data: null });
      if (table === "anamnesis_links") return createAnamnesisLinksBuilder("tok-abc-123");
      return createQueryBuilder();
    });

    renderPage();
    expect(await screen.findByText("Já indicou 2 pacientes")).toBeInTheDocument();
  });
});

describe("PacienteDetalhe — Consentimento Geral (TCLE)", () => {
  // Achado de auditoria LGPD/consentimento: este TCLE é o único que libera
  // enviar a foto do paciente pra IA de terceiros
  // (supabase/functions/_shared/consentGate.ts) — o consentimento mais
  // crítico do sistema. Ele gravava direto do client
  // (`supabase.from('consents').insert(...)`), sem `ip_address` nenhum, ao
  // contrário do TCLE de procedimento (SessaoEstagio2.tsx), que já passava
  // pela edge function record-consent. Os testes abaixo travam o fix: o TCLE
  // geral agora tem que passar pela mesma edge function.
  const PATIENT_NO_CONSENT = { ...PATIENT, consent_given: false, last_consent_at: null };

  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    rpcMock.mockReset();
    functionsInvokeMock.mockReset();
    functionsInvokeMock.mockResolvedValue({ data: { ok: true, consent: { id: "c1", ip_address: "203.0.113.5" } }, error: null });

    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return createQueryBuilder({ data: PATIENT_NO_CONSENT }, { data: PATIENT_NO_CONSENT });
      if (table === "sessions") return createQueryBuilder({ data: [] }, { data: [] });
      return createQueryBuilder({ data: [] }, { data: [] });
    });
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "get_patient_anamnesis") return createQueryBuilder(undefined, { data: null });
      return createQueryBuilder();
    });
  });

  const openModalAndConfirm = async () => {
    renderPage();
    fireEvent.click(await screen.findByRole("button", { name: "Coletar" }));

    // Mesmo destrave usado em ConsentModal.test.tsx: `scrolledToBottom` só
    // fica true depois de um scroll (ou do requestAnimationFrame de
    // "texto já cabe"), então aguarda o checkbox ficar clicável antes de
    // marcá-lo.
    const checkbox = await screen.findByRole("checkbox");
    await waitFor(() => expect(checkbox).not.toHaveStyle({ pointerEvents: "none" }));
    fireEvent.click(checkbox);

    const confirmButton = screen.getByRole("button", { name: "Confirmar consentimento" });
    await waitFor(() => expect(confirmButton).not.toBeDisabled());
    fireEvent.click(confirmButton);
  };

  it("grava o TCLE geral via invocação da edge function record-consent, não via insert direto na tabela consents", async () => {
    await openModalAndConfirm();

    await waitFor(() => expect(functionsInvokeMock).toHaveBeenCalledTimes(1));
    const [fnName, options] = functionsInvokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(fnName).toBe("record-consent");
    expect(options.body).toMatchObject({
      patientId: "pat-1",
      consentType: "geral",
    });
    expect(typeof options.body.consentText).toBe("string");
    expect((options.body.consentText as string).length).toBeGreaterThan(0);

    // O client nunca chama `.from('consents')` diretamente — é a edge
    // function que grava a linha (e extrai o IP real da requisição, ver
    // supabase/functions/record-consent/index.ts).
    expect(fromMock).not.toHaveBeenCalledWith("consents");
  });

  it("marca o paciente como consentido só depois que a edge function confirma sucesso", async () => {
    await openModalAndConfirm();

    await waitFor(() => expect(fromMock).toHaveBeenCalledWith("patients"));
    // A chamada de update em `patients` (consent_given/last_consent_at)
    // acontece depois da invocação — não antes, e não em paralelo sem
    // checar o resultado.
    const invokeCallOrder = functionsInvokeMock.mock.invocationCallOrder[0];
    const patientsUpdateCalls = fromMock.mock.calls
      .map((args, i) => ({ args, order: fromMock.mock.invocationCallOrder[i] }))
      .filter(({ args }) => args[0] === "patients");
    expect(patientsUpdateCalls.some(({ order }) => order > invokeCallOrder)).toBe(true);
  });

  it("não marca o paciente como consentido quando a edge function recusa (ex.: gate de posse do paciente)", async () => {
    functionsInvokeMock.mockResolvedValue({ data: null, error: { message: "Paciente não encontrado ou sem permissão" } });

    await openModalAndConfirm();

    await waitFor(() => expect(functionsInvokeMock).toHaveBeenCalledTimes(1));
    // O modal continua aberto (a recusa da edge function é lançada antes do
    // `setConsentOpen(false)` em handleConsent) e o botão volta a ficar
    // clicável assim que o loading termina — nunca chegou a marcar o
    // paciente como consentido nem a atualizar `patients`.
    const confirmButton = await screen.findByRole("button", { name: "Confirmar consentimento" });
    await waitFor(() => expect(confirmButton).not.toBeDisabled());
    expect(fromMock).not.toHaveBeenCalledWith("consents");
  });
});
