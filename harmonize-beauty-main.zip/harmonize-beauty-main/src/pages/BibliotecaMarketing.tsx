import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { Download, Share2, ImageOff, ShieldCheck } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import GhostButton from '@/components/harmonize/GhostButton';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import BeforeAfterViewer from '@/components/harmonize/BeforeAfterViewer';
import { useBeforeAfterExport } from '@/hooks/useBeforeAfterExport';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

interface MarketingSessionRow {
  id: string;
  created_at: string;
  selected_procedure: string | null;
  original_image_url: string | null;
  simulation_url: string | null;
  patient_id: string;
  patients: { id: string; name: string; marketing_consent: boolean } | null;
}

/**
 * Biblioteca de Antes/Depois para Redes Sociais (P3, ideia do squad de
 * Produto): lista as sessões concluídas do profissional cujo paciente tem
 * `marketing_consent = true`, e permite exportar o antes/depois como um PNG
 * pronto pra postar, com a marca da clínica sobreposta.
 *
 * GUARDRAIL ÉTICO/LEGAL (o único ponto realmente importante desta tela):
 * usar a imagem de um paciente para divulgação é uma finalidade diferente do
 * TCLE de uso de imagem + IA já coletado (esse cobre planejamento estético,
 * não marketing — ver CONSENT_TEXT em PacienteDetalhe.tsx). Por isso a
 * listagem exige `marketing_consent = true`, um opt-in **separado e
 * opcional** coletado no cadastro do paciente (NovoPaciente/EditarPaciente,
 * campo `patients.marketing_consent`, default false). O filtro é aplicado
 * DUAS vezes — no próprio select via `patients!inner` (não traz do servidor
 * o que não deveria) e de novo no cliente logo abaixo (defesa em
 * profundidade: nenhuma sessão chega a renderizar sem essa checagem
 * explícita, mesmo que a query mude no futuro).
 */
const BibliotecaMarketing: React.FC = () => {
  const { user } = useAuth();
  const { t } = useTranslation();

  const [profile, setProfile] = useState<{ clinic_name: string | null; logo_url: string | null } | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    supabase
      .from('profiles')
      .select('clinic_name, logo_url')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        if (!cancelled && data) setProfile(data);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  const { data: sessions, isLoading } = useQuery({
    queryKey: ['marketing-library-sessions', user?.id],
    queryFn: async () => {
      // Paginado (src/lib/fetchAllRows.ts): 'complete' é status terminal, essa
      // lista só cresce e não tem corte por data. O PostgREST trunca no teto de
      // linhas por resposta (Max Rows, 1000 por padrão) em silêncio, com
      // `error: null` — passando dele, os casos de antes-depois MAIS ANTIGOS
      // sumiriam da galeria sem nenhum indício de lista parcial. Estruturalmente
      // é a mesma query de "doneSessions" em Sessoes.tsx. Achado do ciclo 91 do
      // QA Contínuo; mesma classe dos ciclos 86 e 90.
      const data = await fetchAllRows((from, to) =>
        supabase
          .from('sessions')
          .select(
            'id, created_at, selected_procedure, original_image_url, simulation_url, patient_id, patients!inner(id, name, marketing_consent)'
          )
          .eq('professional_id', user!.id)
          .eq('status', 'complete')
          .eq('patients.marketing_consent', true)
          .order('created_at', { ascending: false })
          .range(from, to),
      );
      // Guardrail em profundidade — ver comentário no topo do arquivo: nunca
      // confia só no filtro da query para decidir o que é elegível.
      return (data as unknown as MarketingSessionRow[]).filter(
        (s) => s.patients?.marketing_consent === true && !!s.original_image_url && !!s.simulation_url
      );
    },
    enabled: !!user,
  });

  return (
    <PageTransition>
      <AppLayout title={t('marketingLibrary.title')} showBack>
        <div className="flex flex-col gap-4">
          <HCard className="flex items-start gap-2.5">
            <ShieldCheck size={16} className="flex-shrink-0 mt-0.5" style={{ color: '#1A9E5C' }} />
            <p className="text-[12px] text-h-text-2 leading-snug">{t('marketingLibrary.consentNotice')}</p>
          </HCard>

          {isLoading ? (
            <div className="flex flex-col gap-3">
              <SkeletonCard lines={3} />
              <SkeletonCard lines={3} />
            </div>
          ) : !sessions || sessions.length === 0 ? (
            <HCard className="flex flex-col items-center gap-2 text-center py-8">
              <ImageOff size={28} style={{ color: '#AAA8A5' }} />
              <p className="text-[13px] font-semibold text-h-text">{t('marketingLibrary.emptyTitle')}</p>
              <p className="text-[12px] text-h-text-3">{t('marketingLibrary.emptyHint')}</p>
            </HCard>
          ) : (
            <div className="flex flex-col gap-4">
              {sessions.map((session) => (
                <MarketingLibraryItem
                  key={session.id}
                  session={session}
                  clinicName={profile?.clinic_name ?? null}
                  logoUrl={profile?.logo_url ?? null}
                />
              ))}
            </div>
          )}
        </div>
      </AppLayout>
    </PageTransition>
  );
};

interface MarketingLibraryItemProps {
  session: MarketingSessionRow;
  clinicName: string | null;
  logoUrl: string | null;
}

const MarketingLibraryItem: React.FC<MarketingLibraryItemProps> = ({ session, clinicName, logoUrl }) => {
  const { t, i18n } = useTranslation();
  const [beforeUrl, setBeforeUrl] = useState<string | null>(null);
  const [afterUrl, setAfterUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      if (session.original_image_url) {
        const { data } = await supabase.storage
          .from('patient-photos')
          .createSignedUrl(session.original_image_url, 3600);
        if (!cancelled) setBeforeUrl(data?.signedUrl ?? null);
      }
      if (session.simulation_url) {
        // Mesmo fallback de bucket usado em SessaoPresent.tsx: no modo mock
        // (sem GEMINI_API_KEY) a "simulação" reaproveita o path da foto
        // original, que vive em patient-photos, não em simulation-results.
        const { data } = await supabase.storage
          .from('simulation-results')
          .createSignedUrl(session.simulation_url, 3600);
        if (data?.signedUrl) {
          if (!cancelled) setAfterUrl(data.signedUrl);
        } else {
          const { data: fallback } = await supabase.storage
            .from('patient-photos')
            .createSignedUrl(session.simulation_url, 3600);
          if (!cancelled) setAfterUrl(fallback?.signedUrl ?? null);
        }
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [session.original_image_url, session.simulation_url]);

  const exportHook = useBeforeAfterExport({
    sessionId: session.id,
    beforeUrl,
    afterUrl,
    clinicName,
    logoUrl,
  });

  return (
    <HCard>
      <div className="flex items-center justify-between mb-1">
        <p className="text-[14px] font-semibold text-h-text">{session.patients?.name}</p>
        <p className="text-[11px] text-h-text-3">
          {format(new Date(session.created_at), 'PP', { locale: dateFnsLocale[i18n.language] ?? ptBR })}
        </p>
      </div>
      <p className="text-[12px] text-h-text-3 mb-3">
        {session.selected_procedure || t('patients.detail.procedureNotDefined')}
      </p>

      <BeforeAfterViewer beforeImageUrl={beforeUrl} afterImageUrl={afterUrl} />

      <div className="flex gap-2 mt-3">
        {exportHook.status === 'ready' ? (
          <>
            <SecondaryButton onClick={() => void exportHook.share()} className="flex-1">
              {exportHook.canShareFiles ? (
                <span className="flex items-center justify-center gap-1.5">
                  <Share2 size={14} /> {t('marketingLibrary.export.shareButton')}
                </span>
              ) : (
                <span className="flex items-center justify-center gap-1.5">
                  <Download size={14} /> {t('marketingLibrary.export.downloadButton')}
                </span>
              )}
            </SecondaryButton>
            <GhostButton onClick={() => void exportHook.generate()} className="!w-auto px-3">
              {t('marketingLibrary.export.regenerateButton')}
            </GhostButton>
          </>
        ) : (
          <SecondaryButton
            onClick={() => void exportHook.generate()}
            disabled={exportHook.status === 'generating' || !beforeUrl || !afterUrl}
            className="w-full"
          >
            {exportHook.status === 'generating'
              ? t('marketingLibrary.export.generatingLabel')
              : t('marketingLibrary.export.generateButton')}
          </SecondaryButton>
        )}
      </div>
    </HCard>
  );
};

export default BibliotecaMarketing;
