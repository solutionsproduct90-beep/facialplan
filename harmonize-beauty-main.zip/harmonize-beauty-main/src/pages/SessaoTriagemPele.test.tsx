import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import SessaoTriagemPele from "./SessaoTriagemPele";
import { createQueryBuilder } from "@/test/supabaseMock";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const sessionsUpdateSpy = vi.fn();
const screeningUpsertSpy = vi.fn();
const toastErrorMock = vi.fn();
const toastSuccessMock = vi.fn();
// Segunda Checagem Automática de IA ("advogado do diabo" — ver
// src/lib/adversarialRiskCheck.ts): resolves to "unavailable" by default so
// every pre-existing test in this file (which never asserts on the widget)
// keeps behaving exactly as before. The dedicated describe block below
// overrides this per-test to exercise the actual loading/ready UI.
const functionsInvokeSpy = vi.fn(async (..._args: unknown[]) => ({ data: { available: false }, error: null }));

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    functions: { invoke: (...args: unknown[]) => functionsInvokeSpy(...args) },
  },
}));

/**
 * Query-builder stand-in for `sessions`: supports the read
 * (`select().eq().single()`) SessaoTriagemPele does on load, plus the
 * `update(payload).eq(id)` it issues once the screening is resolved and the
 * session is allowed to advance to Stage 2.
 */
function createSessionsBuilder(overrides: { selected_procedure?: string | null } = {}) {
  const selectResolution = {
    data: { patient_id: "pat-1", selected_procedure: overrides.selected_procedure ?? "Preenchimento Labial" },
  };
  const builder = {
    select: () => builder,
    eq: () => builder,
    single: () => builder,
    update: (payload: unknown) => {
      sessionsUpdateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve(selectResolution).then(onFulfilled),
  };
  return builder;
}

/**
 * Query-builder stand-in for `skin_screenings`.
 *
 * Além do `.upsert(payload, opts)`, cobre a leitura da triagem já salva que a
 * tela faz ao montar (`select().eq().maybeSingle()`). `existing` é a linha
 * devolvida por essa leitura — `null` é a sessão que nunca foi triada.
 */
type ScreeningRow = {
  asymmetry: boolean;
  irregular_borders: boolean;
  color_variation: boolean;
  diameter_over_6mm: boolean;
  recent_evolution: boolean;
  lesion_location: string | null;
  notes: string | null;
  has_suspicious_finding: boolean;
  referred_to_dermatology: boolean;
  proceeded_despite_finding: boolean;
  updated_at: string;
};

function createScreeningBuilder(error: unknown = null, existing: ScreeningRow | null = null) {
  const builder = {
    select: () => builder,
    eq: () => builder,
    maybeSingle: () => Promise.resolve({ data: existing, error: null }),
    upsert: (payload: unknown, opts: unknown) => {
      screeningUpsertSpy(payload, opts);
      return Promise.resolve({ error });
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/sessoes/s1/triagem-pele"]}>
      <Routes>
        <Route path="/sessoes/:id/triagem-pele" element={<SessaoTriagemPele />} />
      </Routes>
    </MemoryRouter>
  );

describe("SessaoTriagemPele — triagem ABCDE de lesão cutânea", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    screeningUpsertSpy.mockReset();
    toastErrorMock.mockReset();
    toastSuccessMock.mockReset();
    functionsInvokeSpy.mockReset();
    functionsInvokeSpy.mockImplementation(async (..._args: unknown[]) => ({ data: { available: false }, error: null }));

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "skin_screenings") return createScreeningBuilder();
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () =>
    waitFor(() => expect(screen.getByText("Critérios ABCDE")).toBeInTheDocument());

  const answerAllCriteria = (answer: "Não observado" | "Presente") => {
    const buttons = screen.getAllByRole("radio", { name: answer });
    buttons.forEach((btn) => fireEvent.click(btn));
  };

  it("keeps the professional gated until all 5 ABCDE criteria are answered — no AI auto-detection, no default answer", async () => {
    renderPage();
    await waitForLoaded();

    expect(screen.getByText("Responda os 5 critérios acima para continuar.")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Continuar para o planejamento →" })).not.toBeInTheDocument();

    // Answer only 4 of the 5 criteria — still incomplete.
    const notObserved = screen.getAllByRole("radio", { name: "Não observado" });
    notObserved.slice(0, 4).forEach((btn) => fireEvent.click(btn));

    expect(screen.getByText("Responda os 5 critérios acima para continuar.")).toBeInTheDocument();
  });

  it("no positive criterion -> shows the non-diagnostic no-findings message and lets the professional continue to planning (status flips to stage2 only here)", async () => {
    renderPage();
    await waitForLoaded();

    answerAllCriteria("Não observado");

    expect(
      screen.getByText(
        "Nenhum dos critérios ABCDE foi marcado como presente nesta avaliação. Isso não substitui o exame dermatológico de rotina — apenas indica que nenhum sinal de alerta foi observado agora."
      )
    ).toBeInTheDocument();
    // Never a clean bill of health, even with a fully negative checklist —
    // no "está tudo bem" / "descartamos [câncer/malignidade]" wording. (The
    // explainer legitimately says the checklist itself "não descarta nada
    // automaticamente" — that phrase is fine and expected; it's the exact
    // opposite claim this guards against.)
    expect(screen.queryByText(/tudo bem/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/descartamos/i)).not.toBeInTheDocument();

    const continueBtn = screen.getByRole("button", { name: "Continuar para o planejamento →" });
    fireEvent.click(continueBtn);

    await waitFor(() => expect(screeningUpsertSpy).toHaveBeenCalledTimes(1));
    const [payload] = screeningUpsertSpy.mock.calls[0] as [Record<string, unknown>];
    expect(payload).toMatchObject({
      session_id: "s1",
      patient_id: "pat-1",
      professional_id: "pro-1",
      has_suspicious_finding: false,
      referred_to_dermatology: false,
      proceeded_despite_finding: false,
      proceed_justification: null,
    });

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalledWith({ status: "stage2" }));
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/sessoes/s1/estagio-2"));
  });

  it("a single positive criterion surfaces the dermatology-referral warning instead of advancing, and never auto-advances", async () => {
    renderPage();
    await waitForLoaded();

    answerAllCriteria("Não observado");
    const presentButtons = screen.getAllByRole("radio", { name: "Presente" });
    fireEvent.click(presentButtons[0]); // Asymmetry marked present

    expect(screen.getByText("Achado que sugere avaliação dermatológica")).toBeInTheDocument();
    expect(
      screen.getByText(
        "Um ou mais critérios ABCDE foram marcados como presentes. Isto não é um diagnóstico — é apenas um sinal de alerta clínico. Recomendamos encaminhar o paciente para avaliação dermatológica antes de realizar qualquer procedimento injetável nesta região."
      )
    ).toBeInTheDocument();
    // The "no findings" bottom bar must not appear once a finding is present.
    expect(screen.queryByRole("button", { name: "Continuar para o planejamento →" })).not.toBeInTheDocument();
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
  });

  it("lets the professional refer the patient and pause the session, without proceeding to Stage 2 — the finding is still logged", async () => {
    renderPage();
    await waitForLoaded();

    answerAllCriteria("Não observado");
    fireEvent.click(screen.getAllByRole("radio", { name: "Presente" })[0]);

    fireEvent.click(screen.getByRole("button", { name: "Não prosseguir agora — encaminhar" }));

    await waitFor(() => expect(screeningUpsertSpy).toHaveBeenCalledTimes(1));
    const [payload] = screeningUpsertSpy.mock.calls[0] as [Record<string, unknown>];
    expect(payload).toMatchObject({
      has_suspicious_finding: true,
      referred_to_dermatology: true,
      proceeded_despite_finding: false,
    });

    // Session is paused, not advanced: no status update, no navigation to Stage 2.
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/sessoes"));
    expect(toastSuccessMock).toHaveBeenCalled();
  });

  it("gates the 'proceed anyway' path behind an explicit acknowledgement AND a written justification, then logs the override and advances", async () => {
    renderPage();
    await waitForLoaded();

    answerAllCriteria("Não observado");
    fireEvent.click(screen.getAllByRole("radio", { name: "Presente" })[0]);

    const proceedAnywayBtn = screen.getByRole("button", { name: "Prosseguir mesmo assim →" });
    expect(proceedAnywayBtn).toBeDisabled();

    // Checking the box alone isn't enough — still needs a real justification.
    fireEvent.click(screen.getByRole("checkbox"));
    expect(proceedAnywayBtn).toBeDisabled();

    fireEvent.change(
      screen.getByPlaceholderText("Justifique a decisão de prosseguir mesmo assim (obrigatório)"),
      { target: { value: "Lesão já em acompanhamento dermatológico, longe da área de aplicação." } }
    );
    expect(proceedAnywayBtn).toBeEnabled();

    fireEvent.click(proceedAnywayBtn);

    await waitFor(() => expect(screeningUpsertSpy).toHaveBeenCalledTimes(1));
    const [payload] = screeningUpsertSpy.mock.calls[0] as [Record<string, unknown>];
    expect(payload).toMatchObject({
      has_suspicious_finding: true,
      referred_to_dermatology: false,
      proceeded_despite_finding: true,
      proceed_justification: "Lesão já em acompanhamento dermatológico, longe da área de aplicação.",
    });

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalledWith({ status: "stage2" }));
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/sessoes/s1/estagio-2"));
  });

  it("shows an error toast and does not advance when saving the screening fails", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "skin_screenings") return createScreeningBuilder({ message: "network error" });
      return createQueryBuilder();
    });

    renderPage();
    await waitForLoaded();
    answerAllCriteria("Não observado");

    fireEvent.click(screen.getByRole("button", { name: "Continuar para o planejamento →" }));

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalled());
    expect(sessionsUpdateSpy).not.toHaveBeenCalled();
    expect(navigateMock).not.toHaveBeenCalled();
  });

  // Segunda Checagem Automática de IA ("advogado do diabo" — item P7-3):
  // dispara exatamente quando o botão "Prosseguir mesmo assim" ficaria
  // habilitável, mostra um contraponto crítico da IA, e NUNCA impede o
  // profissional de confirmar — nem enquanto a resposta ainda está
  // carregando, nem se o recurso estiver indisponível.
  describe("segunda checagem automática de IA ('advogado do diabo')", () => {
    const triggerSuspiciousProceedAnyway = () => {
      answerAllCriteria("Não observado");
      fireEvent.click(screen.getAllByRole("radio", { name: "Presente" })[0]);
      fireEvent.click(screen.getByRole("checkbox"));
      fireEvent.change(
        screen.getByPlaceholderText("Justifique a decisão de prosseguir mesmo assim (obrigatório)"),
        { target: { value: "Lesão já em acompanhamento dermatológico, longe da área de aplicação." } }
      );
    };

    it("is not called before the professional has an acknowledged, justified decision to proceed", async () => {
      renderPage();
      await waitForLoaded();
      answerAllCriteria("Não observado");
      fireEvent.click(screen.getAllByRole("radio", { name: "Presente" })[0]);

      expect(functionsInvokeSpy).not.toHaveBeenCalled();
    });

    it("shows a loading state with a skip option, then the AI's counterpoint, without ever disabling the confirm button", async () => {
      let resolveInvoke: (value: unknown) => void = () => {};
      functionsInvokeSpy.mockImplementation(() => new Promise((resolve) => { resolveInvoke = resolve; }));

      renderPage();
      await waitForLoaded();
      triggerSuspiciousProceedAnyway();

      const proceedAnywayBtn = screen.getByRole("button", { name: "Prosseguir mesmo assim →" });
      expect(proceedAnywayBtn).toBeEnabled();

      expect(await screen.findByText(/Consultando uma segunda opinião crítica da IA/)).toBeInTheDocument();
      expect(proceedAnywayBtn).toBeEnabled(); // still never blocked while loading

      resolveInvoke({
        data: { available: true, counterpoint: "Risco concreto: lesão com bordas irregulares na região malar." },
        error: null,
      });

      await waitFor(() =>
        expect(
          screen.getByText("Risco concreto: lesão com bordas irregulares na região malar.")
        ).toBeInTheDocument()
      );
      expect(proceedAnywayBtn).toBeEnabled();
    });

    it("hides the widget without any visible error when the AI check is unavailable (e.g. no server-side API key)", async () => {
      functionsInvokeSpy.mockResolvedValue({ data: { available: false }, error: null });

      renderPage();
      await waitForLoaded();
      triggerSuspiciousProceedAnyway();

      await waitFor(() => expect(functionsInvokeSpy).toHaveBeenCalledTimes(1));
      expect(screen.queryByTestId("adversarial-risk-check")).not.toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Prosseguir mesmo assim →" })).toBeEnabled();
    });

    it("skipping the wait hides the widget and still lets the professional proceed and save normally", async () => {
      functionsInvokeSpy.mockImplementation(() => new Promise(() => {})); // never resolves

      renderPage();
      await waitForLoaded();
      triggerSuspiciousProceedAnyway();

      fireEvent.click(await screen.findByTestId("adversarial-risk-check-skip"));
      expect(screen.queryByTestId("adversarial-risk-check")).not.toBeInTheDocument();

      fireEvent.click(screen.getByRole("button", { name: "Prosseguir mesmo assim →" }));
      await waitFor(() => expect(screeningUpsertSpy).toHaveBeenCalledTimes(1));
      await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/sessoes/s1/estagio-2"));
    });
  });
});

// ── Regressão do ciclo 73 do QA Contínuo ────────────────────────────────
//
// A tela nunca lia a triagem já salva. Como `skin_screenings` tem uma linha
// por sessão e o save usa `upsert(..., { onConflict: 'session_id' })`, que
// substitui a linha inteira, reabrir a sessão e refazer a triagem apagava o
// registro anterior.
//
// O caminho é real: "Encaminhar e não prosseguir" não avança
// `sessions.status` de propósito, então a sessão fica em `stage1` e a lista
// do paciente leva de volta para a Etapa 1 e daí para esta tela. Em branco,
// sem nada indicando que já houve um achado suspeito e um encaminhamento ao
// dermatologista.
describe("SessaoTriagemPele — triagem já registrada para a sessão", () => {
  const TRIAGEM_COM_ACHADO: ScreeningRow = {
    asymmetry: true,
    irregular_borders: false,
    color_variation: false,
    diameter_over_6mm: false,
    recent_evolution: false,
    lesion_location: "Têmpora direita",
    notes: "Paciente relata mudança recente.",
    has_suspicious_finding: true,
    referred_to_dermatology: true,
    proceeded_despite_finding: false,
    updated_at: "2026-09-10T14:30:00.000Z",
  };

  const renderComTriagem = (existing: ScreeningRow | null) => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "skin_screenings") return createScreeningBuilder(null, existing);
      return createQueryBuilder();
    });
    return renderPage();
  };

  it("avisa que a sessão já foi triada, dizendo que houve encaminhamento", async () => {
    renderComTriagem(TRIAGEM_COM_ACHADO);
    await waitFor(() => expect(screen.getByText("Esta sessão já foi triada")).toBeInTheDocument());

    expect(screen.getByText(/encaminhado ao dermatologista/)).toBeInTheDocument();
  });

  it("traz de volta as respostas salvas em vez de abrir em branco", async () => {
    renderComTriagem(TRIAGEM_COM_ACHADO);
    await waitFor(() => expect(screen.getByText("Esta sessão já foi triada")).toBeInTheDocument());

    // O critério positivo volta marcado, então o bloco de achado suspeito
    // aparece sem ninguém precisar lembrar de remarcá-lo.
    expect(screen.getByDisplayValue("Têmpora direita")).toBeInTheDocument();
    const marcados = screen.getAllByRole("radio", { checked: true });
    expect(marcados.length).toBe(5);
  });

  it("não mostra o aviso quando a sessão nunca foi triada", async () => {
    renderComTriagem(null);
    await waitFor(() => expect(screen.getByText("Critérios ABCDE")).toBeInTheDocument());

    expect(screen.queryByText("Esta sessão já foi triada")).not.toBeInTheDocument();
    expect(screen.queryAllByRole("radio", { checked: true })).toHaveLength(0);
  });
});
