import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import SessaoPresent from './SessaoPresent';
import i18n from '@/i18n';

/**
 * Covers the P0 fix for the "Apresentar" screen (SessaoPresent.tsx): the
 * "O que será feito" list must show a short patient-facing clinical
 * explanation (finding + clinicalGoal) under each item that has one, while
 * a manual point (no justification) — or one persisted before the 3-part
 * justification migration (legacy single string) — must keep working
 * without crashing. See src/lib/patientJustification.ts for the shared
 * extraction logic covered at the unit level in patientJustification.test.ts;
 * this file covers it wired into the actual rendered list.
 *
 * Direct-fetch dependencies (the `sessions`/`profiles` reads and storage
 * signed URLs) are stubbed via `@/integrations/supabase/client`; the two
 * present-screen hooks are stubbed at the module boundary since their own
 * Supabase/Auth wiring is unrelated to this list.
 */
let sessionSelectResult: { data: unknown };
// Perfil do profissional responsável, usado nos testes de "Responsável"
// abaixo — default com nome + registro completos; testes específicos
// sobrescrevem antes de renderizar.
let profileSelectResult: { data: unknown } = {
  data: { clinic_name: 'Clínica Bela Face', logo_url: null, full_name: 'Dra. Camila Rocha', council_type: 'CRM', council_number: '123456' },
};

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (table: string) => {
      if (table === 'sessions') {
        return {
          select: () => ({
            eq: () => ({ single: async () => sessionSelectResult }),
          }),
        };
      }
      if (table === 'profiles') {
        return {
          select: () => ({
            eq: () => ({ single: async () => profileSelectResult }),
          }),
        };
      }
      throw new Error(`unexpected table: ${table}`);
    },
    storage: {
      from: () => ({
        createSignedUrl: async () => ({ data: { signedUrl: 'https://storage.example/signed.jpg' } }),
      }),
    },
  },
}));

vi.mock('@/hooks/useSessionPresentLink', () => ({
  useSessionPresentLink: () => ({
    token: null,
    busy: false,
    sendWhatsApp: vi.fn(),
    copyLink: vi.fn(),
    disableLink: vi.fn(),
  }),
}));

vi.mock('@/hooks/useSessionFeedbackLink', () => ({
  useSessionFeedbackLink: () => ({
    token: null,
    answered: false,
    busy: false,
    sendWhatsApp: vi.fn(),
    copyLink: vi.fn(),
  }),
}));

vi.mock('@/hooks/useVideoExport', () => ({
  useVideoExport: () => ({
    status: 'idle',
    progress: 0,
    canShareFiles: false,
    generate: vi.fn(),
    share: vi.fn(),
  }),
}));

const renderAt = (id: string) =>
  render(
    <MemoryRouter initialEntries={[`/sessoes/${id}/present`]}>
      <Routes>
        <Route path="/sessoes/:id/present" element={<SessaoPresent />} />
      </Routes>
    </MemoryRouter>
  );

describe('SessaoPresent — "O que será feito"', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    profileSelectResult = {
      data: { clinic_name: 'Clínica Bela Face', logo_url: null, full_name: 'Dra. Camila Rocha', council_type: 'CRM', council_number: '123456' },
    };
  });

  it('shows the patient-facing explanation under a point that has finding/clinicalGoal', async () => {
    sessionSelectResult = {
      data: {
        selected_procedure: 'Preenchimento labial',
        simulation_intensity: 'natural',
        original_image_url: null,
        simulation_url: 'sim.png',
        professional_id: 'pro-1',
        stage2_overlay: [
          {
            id: 'p1',
            region: 'labio_superior',
            label: 'Lábio Superior',
            substance: 'acido_hialuronico',
            quantity: 1,
            unit: 'ml',
            x: 0.5,
            y: 0.5,
            source: 'ai',
            justification: {
              finding: 'Volume reduzido no lábio superior',
              clinicalGoal: 'Restaurar volume e contorno do vermelhão',
              technicalNote: 'Aplicação em bolus retrovermelhão, evitando comissuras',
            },
          },
        ],
        patient: { name: 'Maria Silva' },
      },
    };

    renderAt('sess-1');

    expect(await screen.findByText('Lábio Superior — 1 ml de Ácido Hialurônico')).toBeInTheDocument();
    expect(
      screen.getByText('Volume reduzido no lábio superior Restaurar volume e contorno do vermelhão')
    ).toBeInTheDocument();
    // A nota técnica é jargão de aplicação (pra profissional, não paciente) —
    // nunca deve aparecer nesta tela.
    expect(screen.queryByText(/comissuras/)).not.toBeInTheDocument();
  });

  it('shows only the dose line, without crashing, for a manual point with no justification', async () => {
    sessionSelectResult = {
      data: {
        selected_procedure: 'Preenchimento labial',
        simulation_intensity: 'natural',
        original_image_url: null,
        simulation_url: 'sim.png',
        professional_id: 'pro-1',
        stage2_overlay: [
          {
            id: 'p2',
            region: 'malar_direita',
            label: 'Malar Direita',
            substance: 'acido_hialuronico',
            quantity: 1,
            unit: 'ml',
            x: 0.5,
            y: 0.5,
            source: 'manual',
          },
        ],
        patient: { name: 'Maria Silva' },
      },
    };

    renderAt('sess-2');

    const item = await screen.findByText('Malar Direita — 1 ml de Ácido Hialurônico');
    expect(item).toBeInTheDocument();
    // Sem justification, o card do item deve conter só a linha de dose — sem
    // um segundo parágrafo de explicação vazio.
    expect(item.parentElement?.children.length).toBe(1);
  });

  it('does not crash on the legacy single-string justification format', async () => {
    sessionSelectResult = {
      data: {
        selected_procedure: 'Toxina Botulínica',
        simulation_intensity: 'natural',
        original_image_url: null,
        simulation_url: 'sim.png',
        professional_id: 'pro-1',
        stage2_overlay: [
          {
            id: 'p3',
            region: 'glabela',
            label: 'Glabela',
            substance: 'toxina_botulinica',
            quantity: 15,
            unit: 'unidades',
            x: 0.5,
            y: 0.3,
            source: 'ai',
            justification: 'texto legado único, pré-migração para justificativa em 3 partes',
          },
        ],
        patient: { name: 'Maria Silva' },
      },
    };

    renderAt('sess-3');

    expect(await screen.findByText('Glabela — 15 unidades de Toxina Botulínica')).toBeInTheDocument();
    expect(
      screen.getByText('texto legado único, pré-migração para justificativa em 3 partes')
    ).toBeInTheDocument();
  });
});

/**
 * Covers the P1 backlog item: the "Apresentar" screen must show the
 * responsible professional's name and, when filled in on the Perfil screen,
 * their professional registration (CRM/CRO/CRBM/etc — see COUNCIL_TYPES in
 * Perfil.tsx and formatProfessionalRegistration in
 * src/lib/professionalRegistration.ts) for credibility/traceability. The
 * line must degrade gracefully: no full_name -> no line at all; full_name
 * with only one of council_type/council_number -> name only, no dangling
 * "CRM" or bare number.
 */
describe('SessaoPresent — profissional responsável', () => {
  const baseSession = {
    selected_procedure: 'Preenchimento labial',
    simulation_intensity: 'natural',
    original_image_url: null,
    simulation_url: 'sim.png',
    professional_id: 'pro-1',
    stage2_overlay: [],
    patient: { name: 'Maria Silva' },
  };

  beforeEach(() => {
    sessionSelectResult = { data: baseSession };
  });

  it('shows the professional name with the registration when both council_type and council_number are set', async () => {
    profileSelectResult = {
      data: { clinic_name: 'Clínica Bela Face', logo_url: null, full_name: 'Dra. Camila Rocha', council_type: 'CRM', council_number: '123456' },
    };

    renderAt('sess-4');

    expect(await screen.findByText('Responsável: Dra. Camila Rocha — CRM 123456')).toBeInTheDocument();
  });

  it('shows only the professional name when the registration number is missing', async () => {
    profileSelectResult = {
      data: { clinic_name: 'Clínica Bela Face', logo_url: null, full_name: 'Dra. Camila Rocha', council_type: 'CRM', council_number: null },
    };

    renderAt('sess-5');

    expect(await screen.findByText('Responsável: Dra. Camila Rocha')).toBeInTheDocument();
    expect(screen.queryByText(/CRM/)).not.toBeInTheDocument();
  });

  it('shows nothing when the professional has no full_name on file', async () => {
    profileSelectResult = {
      data: { clinic_name: 'Clínica Bela Face', logo_url: null, full_name: null, council_type: 'CRM', council_number: '123456' },
    };

    renderAt('sess-6');

    await screen.findByText('Clínica Bela Face');
    expect(screen.queryByText(/Responsável/)).not.toBeInTheDocument();
  });
});
