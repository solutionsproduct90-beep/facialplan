import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import Minisite from './Minisite';
import i18n from '@/i18n';

/**
 * Mini-site público — fala com a edge function `public-minisite` por
 * `fetch` puro (ver comentário no topo de Minisite.tsx), mesma técnica de
 * DepoimentoPublico.test.tsx/SessaoPresentPublico.test.tsx, então o double
 * aqui também é `global.fetch`.
 */
function jsonResponse(body: unknown) {
  return Promise.resolve({ ok: true, json: () => Promise.resolve(body) } as Response);
}

const VALID_SLUG = 'dra-ana-clinica';

const renderAt = (path: string) =>
  render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/m/:slug" element={<Minisite />} />
      </Routes>
    </MemoryRouter>
  );

describe('Minisite — título e meta tags por profissional (SEO/preview)', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    vi.stubGlobal('fetch', vi.fn());
    document.title = 'FacialPlan';
    document.head.querySelectorAll('meta[name="description"], meta[property^="og:"]').forEach((el) => el.remove());
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  function metaContent(attr: 'name' | 'property', key: string): string | null {
    return document.head.querySelector(`meta[${attr}="${key}"]`)?.getAttribute('content') ?? null;
  }

  it('sets the tab title and OG tags with the loaded professional name once the page is ready', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        clinicName: 'Clínica Bela Face',
        professionalName: 'Dra. Ana Souza',
        logoUrl: 'https://example.com/logo.png',
        gallery: [],
      })
    );

    renderAt(`/m/${VALID_SLUG}`);

    await waitFor(() => expect(document.title).toBe('Dra. Ana Souza — Antes e Depois'));
    expect(metaContent('name', 'description')).toBe(
      'Confira resultados reais de antes e depois com Dra. Ana Souza e entre em contato para agendar sua avaliação.'
    );
    expect(metaContent('property', 'og:title')).toBe('Dra. Ana Souza — Antes e Depois');
    expect(metaContent('property', 'og:image')).toBe('https://example.com/logo.png');
  });

  it('falls back to the generic title/description when the professional has no name on record', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({ valid: true, clinicName: null, professionalName: null, logoUrl: null, gallery: [] })
    );

    renderAt(`/m/${VALID_SLUG}`);

    await screen.findByText('Antes e Depois');
    // `document.title`/meta tags são efeitos passivos (useDocumentMeta usa
    // useEffect, não useLayoutEffect) — podem não ter sido aplicados ainda no
    // exato instante em que o texto acima aparece no DOM (a mutação de texto
    // do render é síncrona; o efeito que seta o título roda numa fase
    // separada). `waitFor` evita o teste ficar instável sob carga (visto
    // falhar de forma intermitente ao rodar junto com toda a suíte), mesmo
    // padrão já usado no teste anterior deste arquivo.
    await waitFor(() => expect(document.title).toBe('Antes e Depois'));
    expect(metaContent('name', 'description')).toBe(
      'Confira resultados reais de antes e depois e entre em contato para agendar sua avaliação.'
    );
  });

  it('falls back to a gallery photo for og:image when there is no clinic logo', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        clinicName: null,
        professionalName: 'Dra. Ana Souza',
        logoUrl: null,
        gallery: [{ beforeUrl: 'https://example.com/before.jpg', afterUrl: 'https://example.com/after.jpg', procedureName: null }],
      })
    );

    renderAt(`/m/${VALID_SLUG}`);

    await waitFor(() => expect(metaContent('property', 'og:image')).toBe('https://example.com/after.jpg'));
  });

  it('leaves the generic app title untouched on the not-found state', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false }));

    renderAt(`/m/${VALID_SLUG}`);

    await screen.findByText('Página não encontrada');
    expect(document.title).toBe('FacialPlan');
  });
});
