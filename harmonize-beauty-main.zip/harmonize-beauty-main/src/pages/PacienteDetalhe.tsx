import React, { useState, useEffect } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import ConsentModal from '@/components/harmonize/ConsentModal';
import GhostButton from '@/components/harmonize/GhostButton';
import AnamnesisSheet from '@/components/harmonize/AnamnesisSheet';
import AnamnesisRiskBanner from '@/components/harmonize/AnamnesisRiskBanner';
import AnamnesisPatientAnswers from '@/components/harmonize/AnamnesisPatientAnswers';
import AdverseEventsSection from '@/components/harmonize/AdverseEventsSection';
import TreatmentPlanSection from '@/components/harmonize/TreatmentPlanSection';
import SessionRealResultsGallery from '@/components/harmonize/SessionRealResultsGallery';
import PatientEvolutionTimeline from '@/components/harmonize/PatientEvolutionTimeline';
import TreatedRegionsSummary from '@/components/harmonize/TreatedRegionsSummary';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { format, differenceInYears, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { AlertTriangle, Calendar, Phone, Mail, FileText, ShieldCheck, Download, Copy, Users, RotateCcw, Repeat } from 'lucide-react';
import { toast } from 'sonner';
import { getActiveRiskLabels } from '@/lib/anamnesisRisk';
import { returnRadarForSessions, formatReturnRadarWindow } from '@/lib/returnRadar';
import { mostRegularRecurrencePattern } from '@/lib/recurrencePattern';
import { SUBSTANCE_LABEL } from '@/types/harmonize';
import { useEnabledAnamnesisQuestionKeys } from '@/hooks/useAnamnesisQuestionSettings';
import { useSendAnamnesisLink } from '@/hooks/useSendAnamnesisLink';
import type { Anamnesis, RiskFlags } from '@/types/anamnesis';
import { logDataAccess } from '@/lib/auditLog';
import { normalizeInsumos } from '@/lib/budget';
import { buildPatientRecordExport, downloadPatientRecordExport } from '@/lib/patientRecordExport';
import { analysisProvenance } from '@/lib/analysisProvenance';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

const CONSENT_TEXT = `TERMO DE CONSENTIMENTO PARA USO DE IMAGEM E INTELIGÊNCIA ARTIFICIAL\n\nAo prosseguir, o paciente consente com:\n• Captura e processamento de foto facial por inteligência artificial\n• Armazenamento seguro das imagens para fins de planejamento estético\n• Geração de simulação visual ilustrativa do resultado estimado\n• Que a simulação não constitui promessa ou garantia de resultado\n• Direito de solicitar exclusão dos dados a qualquer momento\n\nAs imagens serão processadas por APIs de inteligência artificial de terceiros e armazenadas com segurança. Seus dados são protegidos conforme a legislação de proteção de dados aplicável.`;

const PacienteDetalhe: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { t, i18n } = useTranslation();
  const [consentOpen, setConsentOpen] = useState(false);
  const [consentLoading, setConsentLoading] = useState(false);
  const [anamnesisSheetOpen, setAnamnesisSheetOpen] = useState(false);
  const [fillAnamnesisOnBehalf, setFillAnamnesisOnBehalf] = useState(false);
  const { sendAnamnesisLink, linkGenerating } = useSendAnamnesisLink();
  const [anamnesisPhotoUrl, setAnamnesisPhotoUrl] = useState<string | null>(null);
  const [exportingRecord, setExportingRecord] = useState(false);
  const prontuarioRef = React.useRef<HTMLDivElement>(null);
  const enabledQuestionKeys = useEnabledAnamnesisQuestionKeys(user?.id);

  const { data: patient, isLoading } = useQuery({
    queryKey: ['patient', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('patients')
        .select('*')
        .eq('id', id!)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  // Programa de Indicação — quantos pacientes (do mesmo profissional) este
  // paciente já indicou. `head: true` pede só o count exato, sem trazer as
  // linhas em si (a tela não precisa listar quem foi indicado, só o total).
  const { data: referralsCount } = useQuery({
    queryKey: ['patient-referrals-count', id],
    queryFn: async () => {
      const { count } = await supabase
        .from('patients')
        .select('id', { count: 'exact', head: true })
        .eq('referred_by_patient_id', id!)
        .eq('is_deleted', false);
      return count ?? 0;
    },
    enabled: !!id,
  });

  const { data: sessions, isLoading: loadingSessions } = useQuery({
    queryKey: ['patient-sessions', id],
    queryFn: async () => {
      const { data } = await supabase
        .from('sessions')
        .select('*')
        .eq('patient_id', id!)
        .order('created_at', { ascending: false });
      return data ?? [];
    },
    enabled: !!id,
  });

  const {
    data: anamnesis,
    isLoading: loadingAnamnesis,
    // `isError` e `refetch` existem porque a queryFn abaixo relança o erro em
    // vez de engoli-lo. O comentário dentro dela já afirmava isso desde a
    // correção original, mas os dois nunca chegaram a ser desestruturados —
    // então a tela caía no ramo "sem anamnese" também quando a LEITURA
    // falhava, reproduzindo o mesmo sintoma que aquela correção existia para
    // eliminar (achado do ciclo 54 do QA Contínuo).
    isError: anamnesisLoadFailed,
    refetch: refetchAnamnesis,
  } = useQuery({
    queryKey: ['anamnesis', id],
    queryFn: async () => {
      // Bug corrigido: antes o `error` era descartado silenciosamente e
      // qualquer falha (rede, permissão, etc.) virava um "sem anamnese"
      // indistinguível de fato não ter sido preenchida — daí o relato de
      // "ao clicar em ver dados não aparece nada" mesmo com o paciente já
      // tendo respondido. Agora o erro é logado (console + error_logs, o
      // mesmo canal que a Admin > Log de Erros já usa) e propagado para o
      // react-query, que expõe `isError` para a UI reagir de verdade.
      //
      // Leitura via RPC get_patient_anamnesis (SECURITY DEFINER) em vez de
      // `.from('anamnesis').select('*')` direto: a função já grava o log de
      // auditoria no servidor, na mesma leitura, antes de devolver a linha —
      // ver 20260910220000_add_get_patient_anamnesis_rpc.sql. Isso fecha,
      // pra este ponto de leitura, a lacuna de "log é uma segunda chamada
      // que o client pode nunca fazer" que as migrations anteriores
      // (20260910170000_add_audit_log.sql) documentam como limitação
      // conhecida do restante do app — por isso a chamada a logDataAccess()
      // que existia aqui foi removida (o RPC já loga por conta própria).
      const { data, error } = await supabase
        .rpc('get_patient_anamnesis', { p_patient_id: id! })
        .maybeSingle();
      if (error) {
        // eslint-disable-next-line no-console
        console.error('[PacienteDetalhe] Falha ao carregar anamnese:', error);
        if (user) {
          logClientError({
            professionalId: user.id,
            stage: 'anamnesis',
            errorType: 'anamnesis_read_failed',
            message: `patient_id=${id} :: ${error.message}`,
          });
        }
        throw error;
      }
      return (data as unknown as Anamnesis) ?? null;
    },
    enabled: !!id,
  });

  useEffect(() => {
    if (!anamnesis?.photo_url) {
      setAnamnesisPhotoUrl(null);
      return;
    }
    let cancelled = false;
    supabase.storage
      .from('patient-photos')
      .createSignedUrl(anamnesis.photo_url, 3600)
      .then(({ data }) => {
        if (!cancelled && data?.signedUrl) {
          setAnamnesisPhotoUrl(data.signedUrl);
          if (id) logDataAccess('view_patient_photo', 'patient', id);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [anamnesis?.photo_url, id]);

  const activeRiskLabels = getActiveRiskLabels(anamnesis?.risk_flags as RiskFlags | undefined, t);

  // Radar de Retorno / Protocolo de Manutenção por Substância (ver
  // src/lib/returnRadar.ts) — calculado a partir da última sessão CONCLUÍDA
  // deste paciente. `null` quando ainda não há nenhuma sessão fechada com
  // substância reconhecida (paciente novo, ou histórico anterior a essa
  // etapa do fluxo existir), caso em que o card simplesmente não aparece.
  const returnRadar = returnRadarForSessions(sessions);

  // Sugestão de assinatura/recorrência (ver src/lib/recurrencePattern.ts) —
  // evolução do Radar de Retorno acima: em vez de olhar só a última sessão
  // concluída, olha o histórico INTEIRO em busca de um padrão de retorno já
  // consolidado (2+ ciclos completos no ritmo esperado da substância).
  // `null` na maioria dos pacientes (histórico curto ou irregular) — a
  // sugestão só aparece quando de fato há um padrão pra apontar.
  const recurrencePattern = mostRegularRecurrencePattern(sessions);
  // Contador incrementado pelo CTA da sugestão — TreatmentPlanSection.tsx
  // reage a cada mudança abrindo o formulário "Novo plano" (ver
  // openNewPlanSignal lá). Aponta pro Construtor de Protocolo Combinado
  // Multi-Sessão já existente (Combo Plans) em vez de inventar um fluxo de
  // assinatura/cobrança recorrente novo — ver comentário de cabeçalho de
  // recurrencePattern.ts.
  const [openTreatmentPlanSignal, setOpenTreatmentPlanSignal] = useState(0);
  const handleRecurrenceSuggestionCta = () => {
    setOpenTreatmentPlanSignal((v) => v + 1);
    document.getElementById('treatment-plan-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleSendAnamnesisLink = async () => {
    if (!patient) return;
    await sendAnamnesisLink({ id: patient.id, name: patient.name });
  };

  const handleMarkAnamnesisReviewed = async () => {
    if (!anamnesis) return;
    await supabase.from('anamnesis').update({ reviewed_at: new Date().toISOString() }).eq('id', anamnesis.id);
    queryClient.invalidateQueries({ queryKey: ['anamnesis', id] });
    toast.success(t('anamnesis.detail.reviewedToast'));
  };

  const handleCopyReferralCode = async () => {
    if (!patient) return;
    try {
      await navigator.clipboard.writeText(patient.referral_code);
      toast.success(t('patients.detail.referralCodeCopied'));
    } catch {
      // Mesmo fallback de useSessionPresentLink.copyLink: clipboard pode
      // estar indisponível (permissão negada, contexto não seguro) — mostra
      // o código pra copiar manualmente em vez de falhar silenciosamente.
      toast.info(patient.referral_code);
    }
  };

  const handleConsent = async () => {
    if (!user || !patient) return;
    setConsentLoading(true);
    try {
      // Bug corrigido (achado de auditoria LGPD/consentimento): este TCLE
      // GERAL é o único que libera enviar a foto do paciente para IA de
      // terceiros (ver supabase/functions/_shared/consentGate.ts) — o
      // consentimento mais crítico do sistema. Ainda assim ele gravava
      // direto do client com `supabase.from('consents').insert(...)`, sem
      // `ip_address` algum, enquanto o TCLE de procedimento (ver
      // handleConfirmProcedureConsent em SessaoEstagio2.tsx) já passava pela
      // edge function record-consent, que extrai o IP real da requisição
      // (supabase/functions/_shared/consentUtils.ts) — daí toda linha
      // consent_type='geral' em produção ter ip_address NULL. Agora este
      // TCLE segue o mesmo caminho: a inserção sai do client e passa pela
      // edge function, que também revalida que o paciente pertence ao
      // profissional autenticado antes de gravar.
      const { error: consentError } = await supabase.functions.invoke('record-consent', {
        body: {
          patientId: patient.id,
          consentType: 'geral',
          consentText: CONSENT_TEXT,
          consentVersion: '1.0',
        },
      });
      if (consentError) throw consentError;

      await supabase.from('patients').update({
        consent_given: true,
        last_consent_at: new Date().toISOString(),
      }).eq('id', patient.id);

      queryClient.invalidateQueries({ queryKey: ['patient', id] });
      setConsentOpen(false);
      toast.success(t('patients.detail.consentSuccess'));
    } catch (err: any) {
      toast.error(err.message || t('patients.detail.consentError'));
    } finally {
      setConsentLoading(false);
    }
  };

  /**
   * "Exportação Completa do Prontuário pelo Paciente" — direito de
   * portabilidade de dados (compliance/LGPD, item de Produto) que até aqui
   * só existia descrito na política de privacidade, sem nenhum fluxo
   * funcional. Gera um JSON com tudo que o profissional tem sobre o
   * paciente (cadastro, anamnese, todas as sessões — análises e pontos de
   * aplicação — e eventos adversos), deliberadamente SEM os campos de
   * custo/margem do profissional (ver cabeçalho de patientRecordExport.ts e
   * a mesma regra já aplicada ao PDF do paciente em budget.ts) — só o que o
   * próprio paciente teria direito de ver sobre si mesmo.
   *
   * Busca os dados direto do Supabase (em vez de reusar os states já
   * carregados pela tela) para `sessions`/`insumos`/`adverse_events`, que
   * aqui view carrega parcialmente ou não carrega — só `patient` e
   * `anamnesis` já vêm prontos das queries acima e são reaproveitados.
   */
  const handleExportFullRecord = async () => {
    if (!patient || !user) return;
    setExportingRecord(true);
    try {
      const [
        { data: profile },
        { data: insumosRaw },
        { data: sessionsRaw },
        { data: adverseEventsRaw },
        { data: consentsRaw },
        { data: skinScreeningsRaw },
        { data: skinScreeningRevisionsRaw },
      ] = await Promise.all([
        supabase.from('profiles').select('labor_fee_per_session, currency').eq('id', user.id).single(),
        supabase.from('insumos').select('id, substance, brand_name, cost_per_unit, price_per_unit, active').eq('professional_id', user.id),
        supabase.from('sessions').select('id, status, selected_procedure, stage1_analysis, stage2_overlay, created_at, simulation_url').eq('patient_id', patient.id).order('created_at', { ascending: false }),
        supabase.from('adverse_events').select('id, event_type, severity, description, occurred_at, session_id, insumo_id').eq('patient_id', patient.id).order('occurred_at', { ascending: false }),
        // TCLE (geral e por procedimento) — faltava no "prontuário completo",
        // ver ExportedConsent em patientRecordExport.ts. Achado de auditoria
        // LGPD/Pacientes.
        supabase
          .from('consents')
          .select('id, consent_type, consent_text, consent_version, procedure_summary, signer_name, ip_address, created_at, session_id')
          .eq('patient_id', patient.id)
          .order('created_at', { ascending: false }),
        // Triagem ABCDE de lesão cutânea. Ficava fora do prontuário
        // "completo": o arquivo se apresentava como portabilidade total sob a
        // LGPD e omitia, sem ressalva, o encaminhamento ao dermatologista e os
        // critérios que o motivaram (achado do ciclo 81 do QA Contínuo).
        supabase
          .from('skin_screenings')
          .select('id, session_id, asymmetry, irregular_borders, color_variation, diameter_over_6mm, recent_evolution, has_suspicious_finding, lesion_location, notes, referred_to_dermatology, proceeded_despite_finding, proceed_justification, created_at, updated_at')
          .eq('patient_id', patient.id)
          .order('created_at', { ascending: false }),
        // Versões substituídas da triagem. Um erro aqui (por exemplo antes de
        // a migração 20260922180000 ser aplicada) devolve `data: null` em vez
        // de lançar, então o export continua saindo com a triagem atual.
        supabase
          .from('skin_screening_revisions')
          .select('id, screening_id, session_id, asymmetry, irregular_borders, color_variation, diameter_over_6mm, recent_evolution, has_suspicious_finding, lesion_location, notes, referred_to_dermatology, proceeded_despite_finding, proceed_justification, recorded_at, superseded_at')
          .eq('patient_id', patient.id),
      ]);

      const record = buildPatientRecordExport({
        patient,
        anamnesis: anamnesis ?? null,
        sessions: sessionsRaw ?? [],
        adverseEvents: adverseEventsRaw ?? [],
        consents: consentsRaw ?? [],
        skinScreenings: skinScreeningsRaw ?? [],
        skinScreeningRevisions: skinScreeningRevisionsRaw ?? [],
        insumos: normalizeInsumos(insumosRaw),
        laborFeePerSession: profile?.labor_fee_per_session ?? null,
        currency: profile?.currency || 'BRL',
        // Avisos de proveniência traduzidos aqui (a função de export é pura e
        // não conhece i18n) — sem eles um prontuário exportado entregaria
        // análise de DEMONSTRAÇÃO com a mesma aparência de uma leitura real de
        // IA. Ver src/lib/analysisProvenance.ts.
        provenanceNotices: {
          demo: t('sessions.analysisProvenance.export.demoNotice'),
          unknown: t('sessions.analysisProvenance.export.unknownNotice'),
        },
      });

      downloadPatientRecordExport(record, `prontuario_${patient.name.replace(/\s+/g, '_')}`);
      toast.success(t('patients.detail.exportRecordSuccess'));
      // Melhor esforço, roda depois do export já ter acontecido — mesma
      // política do restante do módulo de auditoria (ver auditLog.ts).
      void logDataAccess('export_full_record', 'patient', patient.id);
    } catch (err: any) {
      // eslint-disable-next-line no-console
      console.error('[PacienteDetalhe] Falha ao exportar prontuário completo:', err);
      toast.error(err.message || t('patients.detail.exportRecordError'));
    } finally {
      setExportingRecord(false);
    }
  };

  if (isLoading) {
    return (
      <AppLayout title={t('patients.detail.title')} showBack>
        <div className="flex flex-col gap-3">
          <SkeletonCard lines={3} />
          <SkeletonCard />
          <SkeletonCard />
        </div>
      </AppLayout>
    );
  }

  if (!patient) {
    return (
      <AppLayout title={t('patients.detail.title')} showBack>
        <p className="text-center text-h-text-3 py-12">{t('patients.detail.notFound')}</p>
      </AppLayout>
    );
  }

  const initials = patient.name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
  const age = patient.birth_date ? differenceInYears(new Date(), new Date(patient.birth_date)) : null;

  const statusVariant: Record<string, 'grad' | 'baixa' | 'neutral' | 'media' | 'alta'> = {
    stage1: 'grad',
    stage2: 'media',
    stage3: 'alta',
    complete: 'baixa',
    abandoned: 'neutral',
  };

  return (
    <PageTransition>
    <AppLayout
      title={patient.name.split(' ')[0]}
      showBack
      rightAction={
        // BUG CORRIGIDO: era um link de texto rosa (`text-h-g-start`) sem
        // fundo no header — mesmo padrão já corrigido em HeaderSaveButton
        // (Perfil).
        <GhostButton
          onClick={() => navigate(`/pacientes/${id}/editar`)}
          className="!w-auto !h-auto !min-h-[44px] px-3 py-2 text-[13px]"
        >
          {t('patients.detail.edit')}
        </GhostButton>
      }
    >
      <div className="flex flex-col gap-4">
        {/* 1. Patient Header */}
        <HCard>
          <div className="flex flex-col items-center py-2">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center text-[22px] font-bold mb-3"
              style={{ background: '#BF5F82', color: '#fff' }}
            >
              {initials}
            </div>
            <h2 className="text-[20px] font-extrabold text-h-text">{patient.name}</h2>
            <div className="flex items-center gap-2 mt-1 flex-wrap justify-center">
              {age !== null && (
                <span className="text-[13px] text-h-text-2 flex items-center gap-1">
                  <Calendar size={12} /> {t('patients.detail.age', { count: age })}
                </span>
              )}
              {patient.phone && (
                <span className="text-[13px] text-h-text-2 flex items-center gap-1">
                  <Phone size={12} /> {patient.phone}
                </span>
              )}
              {patient.email && (
                <span className="text-[13px] text-h-text-2 flex items-center gap-1">
                  <Mail size={12} /> {patient.email}
                </span>
              )}
            </div>
          </div>
        </HCard>

        {/* 2. Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <GradientButton onClick={() => navigate('/sessoes/nova', { state: { preselectedPatientId: patient.id, preselectedPatientName: patient.name } })}>
            {t('patients.detail.newSession')}
          </GradientButton>
          <SecondaryButton
            onClick={() => prontuarioRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'start' })}
          >
            {t('patients.detail.viewData')}
          </SecondaryButton>
        </div>
        <GhostButton onClick={handleSendAnamnesisLink} disabled={linkGenerating}>
          {linkGenerating ? t('anamnesis.linkGenerating') : t('anamnesis.sendButton')}
        </GhostButton>

        {/* Radar de Retorno — ver comentário de cálculo acima e
            src/lib/returnRadar.ts. Só aparece quando há uma sessão concluída
            com substância reconhecida; não é uma etapa obrigatória do
            cadastro, então sua ausência não é tratada como erro/vazio. */}
        {returnRadar && (
          <HCard>
            <div className="flex items-center gap-3">
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: returnRadar.isOverdue ? 'rgba(224,80,80,0.08)' : 'rgba(168,85,181,0.10)' }}
              >
                <RotateCcw size={16} style={{ color: returnRadar.isOverdue ? '#E05050' : '#A855B5' }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-semibold text-h-text">
                  {t('patients.detail.returnRadar.title', {
                    window: formatReturnRadarWindow(returnRadar, dateFnsLocale[i18n.language] ?? ptBR),
                  })}
                </p>
                <p className="text-[11px] text-h-text-3 mt-0.5">
                  {t('patients.detail.returnRadar.substance', { substance: SUBSTANCE_LABEL[returnRadar.substance] })}
                </p>
              </div>
              {returnRadar.isOverdue && (
                <HarmonizeBadge variant="alta">{t('patients.detail.returnRadar.overdueBadge')}</HarmonizeBadge>
              )}
            </div>
          </HCard>
        )}

        {/* Sugestão de assinatura/recorrência — ver
            src/lib/recurrencePattern.ts. Deliberadamente discreta (uma
            linha de texto + link, não um HCard cheio nem um modal): é uma
            dica pro profissional considerar, não um alerta que precisa de
            ação imediata como o Radar de Retorno acima. Só aparece quando
            já há um padrão regular consolidado (2+ ciclos), então é raro na
            prática — a maioria dos pacientes não chega a acionar isso. */}
        {recurrencePattern && (
          <div className="flex items-center gap-2 px-1 -mt-1">
            <Repeat size={13} className="text-h-g-mid flex-shrink-0" />
            <p className="text-[12px] text-h-text-2 flex-1 min-w-0">
              {t('patients.detail.recurrenceSuggestion.message', {
                days: recurrencePattern.averageIntervalDays,
                substance: SUBSTANCE_LABEL[recurrencePattern.substance],
              })}{' '}
              <button
                type="button"
                onClick={handleRecurrenceSuggestionCta}
                className="font-semibold underline press-scale"
                style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
              >
                {t('patients.detail.recurrenceSuggestion.cta')}
              </button>
            </p>
          </div>
        )}

        {/* 3. Session History */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
            <p className="text-[13px] font-semibold text-h-text">{t('patients.detail.sessionHistory')}</p>
          </div>
          {loadingSessions ? (
            <div className="flex flex-col gap-2">
              {[1, 2].map(i => <SkeletonCard key={i} />)}
            </div>
          ) : sessions && sessions.length > 0 ? (
            <div className="flex flex-col gap-2">
              {sessions.map((s: any) => {
                const variant = statusVariant[s.status] || statusVariant.stage1;
                const label = t(`sessions.status.${s.status}`, { defaultValue: t('sessions.status.stage1') });
                // "/sessoes/:id" sozinho não é uma rota válida — cada estágio
                // (e a visualização de uma sessão concluída) tem seu próprio
                // caminho. "abandoned" não tem tela de revisão pois nunca
                // chegou a gerar uma simulação.
                const sessionRoutes: Record<string, string> = {
                  stage1: `/sessoes/${s.id}/estagio-1`,
                  stage2: `/sessoes/${s.id}/estagio-2`,
                  stage3: `/sessoes/${s.id}/estagio-3`,
                  complete: `/sessoes/${s.id}/present`,
                };
                const sessionRoute = sessionRoutes[s.status];
                // Proveniência da análise da Etapa 1 desta sessão — o
                // histórico é a linha do tempo clínica do paciente, então uma
                // sessão cuja análise é de DEMONSTRAÇÃO (ou sem origem
                // registrada) precisa ser reconhecível aqui, sem ter que abrir
                // a sessão pra descobrir. Ver src/lib/analysisProvenance.ts.
                // Sessão sem nenhuma análise (ex.: abandonada antes da Etapa
                // 1) não recebe selo: não há conteúdo clínico a qualificar.
                const sessionProvenance = s.stage1_analysis ? analysisProvenance(s.stage1_analysis) : 'ai';
                return (
                  <HCard key={s.id}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[13px] font-semibold text-h-text">
                          {format(new Date(s.created_at), 'PP', { locale: dateFnsLocale[i18n.language] ?? ptBR })}
                        </p>
                        <p className="text-[11px] text-h-text-3 mt-0.5">
                          {s.selected_procedure || t('patients.detail.procedureNotDefined')}
                        </p>
                        {sessionProvenance !== 'ai' && (
                          <p
                            className="text-[10.5px] font-bold mt-1"
                            style={{ color: sessionProvenance === 'mock' ? '#E05050' : '#D4900A' }}
                          >
                            {sessionProvenance === 'mock'
                              ? t('sessions.analysisProvenance.badgeDemo')
                              : t('sessions.analysisProvenance.badgeUnknown')}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <HarmonizeBadge variant={variant}>{label}</HarmonizeBadge>
                        {sessionRoute && (
                          <button
                            onClick={() => navigate(sessionRoute)}
                            className="text-[12px] font-semibold text-h-g-start"
                          >
                            {t('patients.detail.view')}
                          </button>
                        )}
                      </div>
                    </div>
                    {/* Captura de Resultado Real Pós-Procedimento (ideia do
                        squad de Produto) — só faz sentido numa sessão já
                        concluída: é o resultado de verdade do procedimento,
                        não a simulação gerada por IA no Estágio 3. */}
                    {s.status === 'complete' && user && (
                      <SessionRealResultsGallery
                        sessionId={s.id}
                        professionalId={user.id}
                        hasSimulation={!!s.simulation_url}
                      />
                    )}
                  </HCard>
                );
              })}
            </div>
          ) : (
            <div className="bg-h-white rounded-r p-5 shadow-h-sm text-center">
              <p className="text-[14px] text-h-text-3">{t('patients.detail.noSessions')}</p>
            </div>
          )}
        </div>

        {/* Construtor de Protocolo Combinado Multi-Sessão (Combo Plans) —
            protocolo faseado desenhado desde a primeira consulta (ex.:
            toxina hoje + bioestimulador em 30 dias + skinbooster em 60
            dias), cada etapa virando uma sessão futura planejada vinculada
            ao mesmo plano. Ver TreatmentPlanSection.tsx. */}
        <TreatmentPlanSection patientId={patient.id} openNewPlanSignal={openTreatmentPlanSignal} />

        {/* Linha do Tempo Evolutiva — galeria cronológica das fotos frontais
            de cada sessão concluída, com comparador entre duas datas
            quaisquer (não confundir com o antes/depois de uma única sessão,
            já coberto em Etapa 3 / SessaoPresent). Não renderiza nada
            quando não há sessões concluídas com foto. */}
        <PatientEvolutionTimeline sessions={sessions} />

        {/* Indicador Qualitativo de Regiões Tratadas — alternativa descritiva
            a um score de harmonia em percentual (decisão histórica rejeitada
            no produto por ser pseudo-precisão de IA sem lastro clínico).
            Reaproveita as mesmas sessões concluídas da Linha do Tempo
            Evolutiva acima; não renderiza nada quando nenhuma região foi
            tratada ainda. */}
        <TreatedRegionsSummary sessions={sessions} />

        {/* Prontuário (anamnese) */}
        <div ref={prontuarioRef}>
          <div className="flex items-center gap-2 mb-3">
            <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
            <p className="text-[13px] font-semibold text-h-text">{t('anamnesis.detail.title')}</p>
          </div>

          {activeRiskLabels.length > 0 && (
            <div className="mb-3">
              <AnamnesisRiskBanner title={t('anamnesis.detail.riskBannerTitle')} labels={activeRiskLabels} />
            </div>
          )}

          {loadingAnamnesis ? (
            <SkeletonCard />
          ) : anamnesisLoadFailed ? (
            /*
              TERCEIRO RAMO, e ele não é cosmético.
              Sem ele, uma falha de leitura (RLS, rede, permissão negada no
              RPC) caía no ramo de baixo e a tela dizia "nenhuma anamnese
              preenchida ainda" — a mesma frase de um paciente que de fato
              nunca respondeu.
              O risco não é só informar errado. AnamnesisSheet grava com
              `upsert(..., { onConflict: 'patient_id' })`: se o profissional
              acreditasse na tela e clicasse em "Preencher em nome do
              paciente", ele sobrescreveria a anamnese que existe e só não
              carregou — junto com as flags de risco (implante metálico,
              marca-passo, alergias) que ela carrega.
              Por isso este ramo NÃO oferece preencher nem enviar link. A
              única ação possível é tentar carregar de novo: enquanto não se
              sabe o que existe, escrever é a operação errada.
            */
            <div className="bg-h-white rounded-r p-5 shadow-h-sm text-center flex flex-col gap-3 items-center">
              <p className="text-[14px] font-bold text-h-text">{t('anamnesis.detail.loadFailed')}</p>
              <p className="text-[12px] text-h-text-3">{t('anamnesis.detail.loadFailedHint')}</p>
              <SecondaryButton className="w-full" onClick={() => { void refetchAnamnesis(); }}>
                {t('anamnesis.detail.loadFailedRetry')}
              </SecondaryButton>
            </div>
          ) : anamnesis ? (
            <div className="flex flex-col gap-3">
              {/* Seção 1 — Anamnese do Paciente: SÓ leitura. É o histórico que
                  o próprio paciente respondeu (link) ou que o profissional
                  registrou em nome dele (sem link disponível) — nunca
                  reeditado a partir daqui, ver AnamnesisSheet fillOnBehalf. */}
              <HCard>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-[12px] font-bold uppercase tracking-wide text-h-g-mid">
                    {t('anamnesis.detail.patientSectionTitle')}
                  </p>
                  <HarmonizeBadge variant={anamnesis.filled_by === 'patient_link' ? 'grad' : 'neutral'}>
                    {anamnesis.filled_by === 'patient_link'
                      ? t('anamnesis.detail.filledByPatientLink')
                      : t('anamnesis.detail.filledByProfessional')}
                  </HarmonizeBadge>
                </div>
                <p className="text-[11px] text-h-text-3 mb-3">
                  {t('anamnesis.detail.filledOn', { date: format(new Date(anamnesis.created_at), 'P', { locale: dateFnsLocale[i18n.language] ?? ptBR }) })}
                </p>

                {anamnesis.main_complaint && (
                  <div className="mb-3">
                    <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide mb-1">
                      {t('anamnesis.detail.mainComplaint')}
                    </p>
                    <p className="text-[13px] text-h-text-2 leading-snug">{anamnesis.main_complaint}</p>
                  </div>
                )}

                <AnamnesisPatientAnswers riskFlags={anamnesis.risk_flags} enabledKeys={enabledQuestionKeys} />

                {anamnesisPhotoUrl && (
                  <div className="mt-3">
                    <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide mb-1">{t('anamnesis.detail.photo')}</p>
                    <img src={anamnesisPhotoUrl} alt={t('anamnesis.detail.photo')} className="w-full max-w-[160px] rounded-r-sm object-cover" />
                  </div>
                )}

                <div className="flex items-center justify-between mt-3 pt-2" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
                  <p className="text-[11px] text-h-text-3">
                    {anamnesis.reviewed_at
                      ? t('anamnesis.detail.reviewedOn', { date: format(new Date(anamnesis.reviewed_at), 'P', { locale: dateFnsLocale[i18n.language] ?? ptBR }) })
                      : null}
                  </p>
                  {!anamnesis.reviewed_at && (
                    <button onClick={handleMarkAnamnesisReviewed} className="text-[11px] font-bold text-h-g-start">
                      {t('anamnesis.detail.markReviewed')}
                    </button>
                  )}
                </div>
              </HCard>

              {/* Seção 2 — Avaliação Clínica: sempre preenchida/editável pelo
                  profissional, independente de quem respondeu a anamnese acima. */}
              <HCard>
                <div className="flex items-center justify-between mb-3">
                  <p className="text-[12px] font-bold uppercase tracking-wide text-h-g-mid">
                    {t('anamnesis.detail.clinicalSectionTitle')}
                  </p>
                  <button
                    onClick={() => { setFillAnamnesisOnBehalf(false); setAnamnesisSheetOpen(true); }}
                    className="text-[12px] font-semibold text-h-g-start min-h-[32px]"
                  >
                    {t('anamnesis.detail.editClinical')}
                  </button>
                </div>

                {(anamnesis.skin_type || anamnesis.skin_texture || anamnesis.oiliness ||
                  anamnesis.discromia?.length || anamnesis.vascularization?.length) ? (
                  <div className="flex flex-col gap-1">
                    {anamnesis.skin_type && (
                      <p className="text-[12px] text-h-text-2">
                        {t('anamnesis.detail.skinType')}: {t(`anamnesis.form.skinTypeOptions.${anamnesis.skin_type}`, { defaultValue: anamnesis.skin_type })}
                      </p>
                    )}
                    {anamnesis.skin_texture && (
                      <p className="text-[12px] text-h-text-2">
                        {t('anamnesis.detail.skinTexture')}: {t(`anamnesis.form.skinTextureOptions.${anamnesis.skin_texture}`, { defaultValue: anamnesis.skin_texture })}
                      </p>
                    )}
                    {anamnesis.oiliness && (
                      <p className="text-[12px] text-h-text-2">
                        {t('anamnesis.detail.oiliness')}: {t(`anamnesis.form.oilinessOptions.${anamnesis.oiliness}`, { defaultValue: anamnesis.oiliness })}
                      </p>
                    )}
                    {!!anamnesis.discromia?.length && (
                      <p className="text-[12px] text-h-text-2">
                        {t('anamnesis.detail.discromia')}: {anamnesis.discromia.map(d => t(`anamnesis.form.discromiaOptions.${d}`, { defaultValue: d })).join(', ')}
                      </p>
                    )}
                    {!!anamnesis.vascularization?.length && (
                      <p className="text-[12px] text-h-text-2">
                        {t('anamnesis.detail.vascularization')}: {anamnesis.vascularization.map(v => t(`anamnesis.form.vascularizationOptions.${v}`, { defaultValue: v })).join(', ')}
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-[12px] text-h-text-3">{t('anamnesis.detail.noClinicalData')}</p>
                )}
              </HCard>
            </div>
          ) : (
            <div className="bg-h-white rounded-r p-5 shadow-h-sm text-center flex flex-col gap-3 items-center">
              <p className="text-[14px] text-h-text-3">{t('anamnesis.detail.empty')}</p>
              <p className="text-[12px] text-h-text-3">{t('anamnesis.detail.emptyHint')}</p>
              <div className="flex gap-2 w-full">
                <SecondaryButton className="flex-1" onClick={() => { setFillAnamnesisOnBehalf(true); setAnamnesisSheetOpen(true); }}>
                  {t('anamnesis.detail.fillNow')}
                </SecondaryButton>
                <GhostButton className="flex-1" onClick={handleSendAnamnesisLink} disabled={linkGenerating}>
                  {t('anamnesis.sendButton')}
                </GhostButton>
              </div>
            </div>
          )}
        </div>

        {/* 4. Consent Status */}
        <HCard>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {patient.consent_given ? (
                <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(45,184,122,0.10)' }}>
                  <ShieldCheck size={18} className="text-h-green" />
                </div>
              ) : (
                <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(224,80,80,0.08)' }}>
                  <AlertTriangle size={18} style={{ color: 'hsl(0 70% 60%)' }} />
                </div>
              )}
              <div>
                <p className="text-[14px] font-semibold text-h-text">
                  {patient.consent_given ? t('patients.detail.consentActive') : t('patients.detail.consentMissing')}
                </p>
                <p className="text-[11px] text-h-text-3">
                  {patient.consent_given && patient.last_consent_at
                    ? t('patients.detail.consentCollectedOn', { date: format(new Date(patient.last_consent_at), 'P', { locale: dateFnsLocale[i18n.language] ?? ptBR }) })
                    : t('patients.detail.consentPending')}
                </p>
              </div>
            </div>
            {!patient.consent_given && (
              <button
                onClick={() => setConsentOpen(true)}
                className="text-[12px] font-bold text-h-g-start min-h-[32px]"
              >
                {t('patients.detail.collect')}
              </button>
            )}
          </div>
        </HCard>

        {/* Programa de Indicação */}
        <HCard>
          <div className="flex items-center gap-2 mb-3">
            <Users size={14} className="text-h-g-mid" />
            <p className="text-[13px] font-semibold text-h-text-2">{t('patients.detail.referralTitle')}</p>
          </div>
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-[11px] text-h-text-3">{t('patients.detail.referralCode')}</p>
              <p className="text-[16px] font-bold tracking-wide text-h-text">{patient.referral_code}</p>
            </div>
            <button
              onClick={handleCopyReferralCode}
              className="flex items-center gap-1.5 text-[12px] font-bold text-h-g-start min-h-[32px] px-2"
            >
              <Copy size={14} />
              {t('patients.detail.referralCodeCopy')}
            </button>
          </div>
          <p className="text-[12px] text-h-text-2">
            {referralsCount
              ? t('patients.detail.referralsCount', { count: referralsCount })
              : t('patients.detail.referralsCountEmpty')}
          </p>
        </HCard>

        {/* Eventos adversos (farmacovigilância por lote/marca de insumo) */}
        <AdverseEventsSection patientId={patient.id} />

        {/* Notes */}
        {patient.notes && (
          <HCard>
            <div className="flex items-center gap-2 mb-2">
              <FileText size={14} className="text-h-g-mid" />
              <p className="text-[13px] font-semibold text-h-text-2">{t('patients.detail.clinicalNotes')}</p>
            </div>
            <p className="text-[14px] text-h-text-2 leading-relaxed">{patient.notes}</p>
          </HCard>
        )}

        {/* Portabilidade de dados (LGPD) — exportação completa do prontuário */}
        <SecondaryButton onClick={handleExportFullRecord} disabled={exportingRecord}>
          <span className="flex items-center justify-center gap-2">
            <Download size={16} />
            {exportingRecord ? t('patients.detail.exportRecordGenerating') : t('patients.detail.exportRecord')}
          </span>
        </SecondaryButton>
      </div>

      {/* Consent Modal */}
      <ConsentModal
        open={consentOpen}
        onClose={() => setConsentOpen(false)}
        onConfirm={handleConsent}
        canClose={!!patient.consent_given}
        loading={consentLoading}
      />

      {/* Anamnesis Sheet */}
      <AnamnesisSheet
        open={anamnesisSheetOpen}
        onClose={() => setAnamnesisSheetOpen(false)}
        patientId={patient.id}
        initial={anamnesis ?? null}
        fillOnBehalf={fillAnamnesisOnBehalf}
        onSaved={() => queryClient.invalidateQueries({ queryKey: ['anamnesis', id] })}
      />
    </AppLayout>
    </PageTransition>
  );
};

export default PacienteDetalhe;
