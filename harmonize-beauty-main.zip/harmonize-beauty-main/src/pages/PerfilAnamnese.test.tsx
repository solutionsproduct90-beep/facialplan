import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import PerfilAnamnese from "./PerfilAnamnese";
import { createQueryBuilder } from "@/test/supabaseMock";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const upsertSpy = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
  },
}));

function settingsBuilder(rows: { question_key: string; enabled: boolean }[]) {
  return {
    select: () => ({
      eq: async () => ({ data: rows, error: null }),
    }),
    upsert: (payload: unknown, opts: unknown) => {
      upsertSpy(payload, opts);
      return Promise.resolve({ error: null });
    },
  };
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/perfil/anamnese"]}>
      <PerfilAnamnese />
    </MemoryRouter>
  );

describe("PerfilAnamnese — perguntas configuráveis por profissional", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    upsertSpy.mockReset();
  });

  it("shows all 18 patient questions enabled by default", async () => {
    fromMock.mockImplementation(() => settingsBuilder([]));
    renderPage();

    expect(await screen.findByText("Você tem diabetes?")).toBeInTheDocument();
    const checkbox = screen.getByRole("checkbox", { name: "Você tem diabetes?" });
    expect(checkbox).toBeChecked();
  });

  it("reflects a previously disabled question as unchecked", async () => {
    fromMock.mockImplementation(() => settingsBuilder([{ question_key: "keloid_tendency", enabled: false }]));
    renderPage();

    await screen.findByText("Você tem diabetes?");
    const keloidLabel = "Você tem tendência a formar queloides (cicatrizes espessas/salientes)?";
    expect(screen.getByRole("checkbox", { name: keloidLabel })).not.toBeChecked();
  });

  it("upserts enabled:false when a question is turned off", async () => {
    fromMock.mockImplementation(() => settingsBuilder([]));
    renderPage();

    const checkbox = await screen.findByRole("checkbox", { name: "Você tem diabetes?" });
    fireEvent.click(checkbox);

    await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
    const [payload, opts] = upsertSpy.mock.calls[0];
    expect(payload).toEqual({ professional_id: "pro-1", question_key: "diabetes", enabled: false });
    expect(opts).toEqual({ onConflict: "professional_id,question_key" });
  });
});
