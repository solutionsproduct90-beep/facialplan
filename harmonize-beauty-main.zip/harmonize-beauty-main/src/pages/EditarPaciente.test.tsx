import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import EditarPaciente from "./EditarPaciente";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const updateSpy = vi.fn();
const navigateMock = vi.fn();
const toastErrorMock = vi.fn();
const toastSuccessMock = vi.fn();
const rpcMock = vi.fn();
const storageRemoveMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

/** Builder pra `patients`: `.select(...).eq(id).single()` (load) e `.update(payload).eq(id)` (save). */
function createPatientsBuilder(row: Record<string, unknown>) {
  const readBuilder = {
    select: () => readBuilder,
    eq: () => readBuilder,
    single: () => Promise.resolve({ data: row, error: null }),
  };
  return {
    ...readBuilder,
    update: (payload: unknown) => {
      updateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
}

const renderPage = (patientRow: Record<string, unknown>) => {
  fromMock.mockImplementation((table: string) => {
    if (table === "patients") return createPatientsBuilder(patientRow);
    throw new Error(`unexpected table in test: ${table}`);
  });
  return render(
    <MemoryRouter initialEntries={["/pacientes/pat-1/editar"]}>
      <Routes>
        <Route path="/pacientes/:id/editar" element={<EditarPaciente />} />
      </Routes>
    </MemoryRouter>
  );
};

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
    storage: { from: () => ({ remove: (...args: unknown[]) => storageRemoveMock(...args) }) },
  },
}));

describe("EditarPaciente — edição de telefone com DDI e e-mail", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    updateSpy.mockReset();
    navigateMock.mockReset();
    toastErrorMock.mockReset();
    toastSuccessMock.mockReset();
    rpcMock.mockReset();
    storageRemoveMock.mockReset();
  });

  it("splits a phone already stored with a known DDI into the DDI selector + local number field", async () => {
    renderPage({ name: "Maria Silva", phone: "+5521658924242", email: "maria@exemplo.com", birth_date: null, notes: null });

    expect(await screen.findByRole("button", { name: "+55 Brasil" })).toBeInTheDocument();
    expect(screen.getByDisplayValue("21658924242")).toBeInTheDocument();
    expect(screen.getByDisplayValue("maria@exemplo.com")).toBeInTheDocument();
  });

  it("treats a legacy phone (no leading '+', pre-dating this feature) as local-only, defaulting the DDI to Brazil", async () => {
    renderPage({ name: "João Antigo", phone: "21658924242", email: null, birth_date: null, notes: null });

    expect(await screen.findByRole("button", { name: "+55 Brasil" })).toBeInTheDocument();
    expect(screen.getByDisplayValue("21658924242")).toBeInTheDocument();
  });

  it("saves the edited phone re-composed with DDI, and the edited email", async () => {
    renderPage({ name: "Maria Silva", phone: "+5521658924242", email: null, birth_date: null, notes: null });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.change(screen.getByDisplayValue("21658924242"), { target: { value: "21999998888" } });
    fireEvent.change(screen.getByPlaceholderText("paciente@exemplo.com"), { target: { value: "nova@exemplo.com" } });
    fireEvent.click(screen.getByRole("button", { name: "Salvar alterações" }));

    await waitFor(() => expect(updateSpy).toHaveBeenCalledTimes(1));
    const payload = updateSpy.mock.calls[0][0] as { phone: string | null; email: string | null };
    expect(payload.phone).toBe("+5521999998888");
    expect(payload.email).toBe("nova@exemplo.com");
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/pacientes/pat-1"));
  });

  it("defaults the AI-improvement opt-in checkbox to unchecked for an existing patient that never had the field set (safe default for pre-existing patients)", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null, ai_improvement_consent: undefined });
    await screen.findByRole("button", { name: "+55 Brasil" });

    expect(screen.getByRole("checkbox", { name: /melhorar as sugestões de IA/i })).not.toBeChecked();
  });

  it("reflects an existing ai_improvement_consent = true from the database as checked", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null, ai_improvement_consent: true });
    await screen.findByRole("button", { name: "+55 Brasil" });

    expect(screen.getByRole("checkbox", { name: /melhorar as sugestões de IA/i })).toBeChecked();
  });

  it("turning the opt-in ON for a patient that never had it stamps a fresh ai_improvement_consent_at", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null, ai_improvement_consent: false });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("checkbox", { name: /melhorar as sugestões de IA/i }));
    fireEvent.click(screen.getByRole("button", { name: "Salvar alterações" }));

    await waitFor(() => expect(updateSpy).toHaveBeenCalledTimes(1));
    const payload = updateSpy.mock.calls[0][0] as {
      ai_improvement_consent: boolean;
      ai_improvement_consent_at?: string | null;
    };
    expect(payload.ai_improvement_consent).toBe(true);
    expect(typeof payload.ai_improvement_consent_at).toBe("string");
  });

  it("saving unchanged (already-true) consent again does not re-stamp ai_improvement_consent_at — omits the field from the update payload", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null, ai_improvement_consent: true });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("button", { name: "Salvar alterações" }));

    await waitFor(() => expect(updateSpy).toHaveBeenCalledTimes(1));
    const payload = updateSpy.mock.calls[0][0] as Record<string, unknown>;
    expect(payload.ai_improvement_consent).toBe(true);
    expect("ai_improvement_consent_at" in payload).toBe(false);
  });

  it("turning the opt-in OFF clears ai_improvement_consent_at back to null", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null, ai_improvement_consent: true });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("checkbox", { name: /melhorar as sugestões de IA/i }));
    fireEvent.click(screen.getByRole("button", { name: "Salvar alterações" }));

    await waitFor(() => expect(updateSpy).toHaveBeenCalledTimes(1));
    const payload = updateSpy.mock.calls[0][0] as {
      ai_improvement_consent: boolean;
      ai_improvement_consent_at: string | null;
    };
    expect(payload.ai_improvement_consent).toBe(false);
    expect(payload.ai_improvement_consent_at).toBeNull();
  });

  it("blocks saving an invalid email and never calls update", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.change(screen.getByPlaceholderText("paciente@exemplo.com"), { target: { value: "não-e-mail" } });
    fireEvent.click(screen.getByRole("button", { name: "Salvar alterações" }));

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("E-mail inválido"));
    expect(updateSpy).not.toHaveBeenCalled();
  });
});

describe("EditarPaciente — exclusão definitiva (hard delete real, ver patientPermanentDeletion.ts)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    fromMock.mockReset();
    updateSpy.mockReset();
    navigateMock.mockReset();
    toastErrorMock.mockReset();
    toastSuccessMock.mockReset();
    rpcMock.mockReset();
    storageRemoveMock.mockReset();
  });

  it("keeps the confirmation button disabled until the typed text matches the patient's full name exactly", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("button", { name: "Excluir definitivamente" }));
    const confirmInput = await screen.findByPlaceholderText("Nome completo do paciente");
    const confirmButton = screen.getAllByRole("button", { name: "Excluir definitivamente" }).slice(-1)[0];
    expect(confirmButton).toBeDisabled();

    fireEvent.change(confirmInput, { target: { value: "Maria" } });
    expect(confirmButton).toBeDisabled();

    fireEvent.change(confirmInput, { target: { value: "Maria Silva" } });
    expect(confirmButton).not.toBeDisabled();
  });

  it("on confirm, calls the delete_patient_permanently RPC, cleans up Storage, and navigates away — never touches is_deleted (that's the reversible archive, a different action)", async () => {
    rpcMock.mockResolvedValue({
      data: [{ patient_photos_paths: ["pro-1/s1/frontal.jpg"], simulation_results_paths: [] }],
      error: null,
    });
    storageRemoveMock.mockResolvedValue({ error: null });
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("button", { name: "Excluir definitivamente" }));
    const confirmInput = await screen.findByPlaceholderText("Nome completo do paciente");
    fireEvent.change(confirmInput, { target: { value: "Maria Silva" } });
    fireEvent.click(screen.getAllByRole("button", { name: "Excluir definitivamente" }).slice(-1)[0]);

    await waitFor(() => expect(rpcMock).toHaveBeenCalledWith("delete_patient_permanently", { p_patient_id: "pat-1" }));
    await waitFor(() => expect(storageRemoveMock).toHaveBeenCalledWith(["pro-1/s1/frontal.jpg"]));
    expect(updateSpy).not.toHaveBeenCalled();
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/pacientes"));
    expect(toastSuccessMock).toHaveBeenCalledWith("Paciente excluído definitivamente");
  });

  it("surfaces the RPC's ownership rejection (another professional's patient) as an error toast, without navigating away", async () => {
    rpcMock.mockResolvedValue({ data: null, error: { message: "not authorized to delete this patient" } });
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("button", { name: "Excluir definitivamente" }));
    const confirmInput = await screen.findByPlaceholderText("Nome completo do paciente");
    fireEvent.change(confirmInput, { target: { value: "Maria Silva" } });
    fireEvent.click(screen.getAllByRole("button", { name: "Excluir definitivamente" }).slice(-1)[0]);

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("not authorized to delete this patient"));
    expect(navigateMock).not.toHaveBeenCalled();
    expect(storageRemoveMock).not.toHaveBeenCalled();
  });

  it("keeps the reversible archive action separate: archiving still only sets is_deleted/deleted_at and never calls the permanent-deletion RPC", async () => {
    renderPage({ name: "Maria Silva", phone: null, email: null, birth_date: null, notes: null });
    await screen.findByRole("button", { name: "+55 Brasil" });

    fireEvent.click(screen.getByRole("button", { name: "Arquivar paciente" }));
    fireEvent.click(screen.getAllByRole("button", { name: "Arquivar paciente" }).slice(-1)[0]);

    await waitFor(() => expect(updateSpy).toHaveBeenCalledWith(
      expect.objectContaining({ is_deleted: true }),
    ));
    expect(rpcMock).not.toHaveBeenCalled();
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/pacientes"));
  });
});
