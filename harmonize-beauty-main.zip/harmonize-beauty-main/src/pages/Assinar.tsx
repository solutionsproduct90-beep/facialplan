import React from 'react';
import { Loader2, LogOut, RefreshCw } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import GhostButton from '@/components/harmonize/GhostButton';
import { useAuth } from '@/contexts/AuthContext';
import { useSubscriptionActivationWatch } from '@/hooks/useSubscriptionActivationWatch';
import RecuperarCompraHotmart from '@/components/harmonize/RecuperarCompraHotmart';

// Link de checkout da Hotmart — configure VITE_HOTMART_CHECKOUT_URL no .env
// assim que o produto/oferta for criado no painel da Hotmart. Sem isso, o
// botão continua desativado em vez de levar a um link quebrado.
const HOTMART_CHECKOUT_URL = import.meta.env.VITE_HOTMART_CHECKOUT_URL as string | undefined;

// Tela de destino padrão de todo profissional recém-cadastrado (subscription_status
// começa 'inactive' — ProtectedRoute redireciona pra cá). Mesma saída das telas irmãs
// Regularizar.tsx/ContaBloqueada.tsx: sem o logout, quem decide não assinar agora ficava
// preso aqui, sobretudo enquanto o checkout ainda não está configurado.
const Assinar: React.FC = () => {
  const { t } = useTranslation();
  const { signOut } = useAuth();

  // O checkout abre em outra aba; o webhook libera o acesso no banco segundos
  // depois. Sem isto, quem paga volta e continua vendo esta tela, porque o
  // perfil no cliente é o de antes da compra. Ver o hook para o raciocínio da
  // espera escalonada.
  const { status, attempt, totalAttempts, check, armOnReturn } = useSubscriptionActivationWatch();

  // O redirecionamento é explícito: o ProtectedRoute manda pra cá quem não tem
  // acesso, mas não faz o caminho de volta — /assinar continua acessível para
  // quem já assinou.
  if (status === 'activated') {
    return <Navigate to="/inicio" replace />;
  }

  const checking = status === 'checking';

  return (
  <PageTransition>
  <div className="min-h-screen bg-h-bg flex items-start justify-center pt-16">
    <div className="w-full max-w-[430px] px-6">
      <div className="flex flex-col items-center mb-6">
        <div className="flex items-center gap-2 mb-2">
          <LogoMark size={32} />
          <span className="text-[18px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>FacialPlan</span>
        </div>
        <h1 className="text-[28px] font-extrabold text-h-text" style={{ letterSpacing: '-0.03em' }}>
          {t('account.subscribe.heading')}
        </h1>
        <p className="text-[14px] text-h-text-2 mt-1">
          {t('account.subscribe.subtitle')}
        </p>
      </div>
      <p className="text-[15px] text-h-text-2 mb-8 leading-relaxed text-center">
        {t('account.subscribe.description')}
      </p>
      {HOTMART_CHECKOUT_URL ? (
        <a
          href={HOTMART_CHECKOUT_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="block"
          onClick={armOnReturn}
        >
          <GradientButton>{t('account.subscribe.cta')}</GradientButton>
        </a>
      ) : (
        <>
          <GradientButton disabled>{t('account.subscribe.cta')}</GradientButton>
          <p className="text-[12px] text-h-text-3 mt-3 text-center">{t('account.subscribe.comingSoon')}</p>
        </>
      )}

      {/* Verificação manual. Fica sempre visível (e não só depois de clicar no
          checkout) porque o caso real mais chato é o outro: pagou no celular,
          abriu o app no computador, e aqui nunca houve um clique pra armar a
          checagem automática. */}
      <div className="mt-4">
        <GhostButton
          onClick={() => { void check(); }}
          disabled={checking}
          className="disabled:opacity-60 disabled:active:scale-100"
        >
          <span className="flex items-center justify-center gap-2">
            {checking ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
            {checking ? t('account.subscribe.checkingPayment') : t('account.subscribe.verifyNow')}
          </span>
        </GhostButton>
      </div>

      {checking && attempt > 0 && (
        <p className="text-[12px] text-h-text-3 mt-2 text-center" aria-live="polite">
          {t('account.subscribe.checkingAttempt', { attempt, total: totalAttempts })}
        </p>
      )}

      {status === 'not_yet' && (
        <div
          className="mt-4 rounded-r border border-h-surface-3 bg-h-surface px-4 py-3"
          role="status"
          aria-live="polite"
        >
          <p className="text-[13px] font-semibold text-h-text">
            {t('account.subscribe.notYetTitle')}
          </p>
          <p className="text-[12px] text-h-text-2 mt-1 leading-relaxed">
            {t('account.subscribe.notYetBody')}
          </p>
        </div>
      )}

      <div className="mt-4">
        <GhostButton onClick={signOut}>
          <span className="flex items-center justify-center gap-2">
            <LogOut size={16} />
            {t('common.signOut')}
          </span>
        </GhostButton>
      </div>
      {/* Caminho de recuperação de quem JÁ pagou na Hotmart e não foi
          liberado (webhook que não casou o e-mail, ou compra feita antes do
          cadastro). Vem antes do mailto de suporte porque resolve sozinho o
          caso mais comum — o e-mail da compra é o mesmo da conta. */}
      <RecuperarCompraHotmart />
      <a
        href="mailto:suporte@harmonize.app"
        className="block text-center mt-4"
        style={{ fontSize: 13, color: '#AAA8A5', textDecoration: 'none' }}
      >
        {t('account.subscribe.contactSupport')}
      </a>
    </div>
  </div>
  </PageTransition>
  );
};

export default Assinar;
