import { describe, it, expect } from "vitest";
import { SCAN_REGIONS, SCAN_STEPS } from "./NovaSessao";
import { FACE_REGION_KEYS, FACE_REGIONS } from "@/lib/faceRegions";

// SCAN_REGIONS/SCAN_STEPS drive the "escaneamento" animation on the Nova
// Sessão loading screen (ver NovaSessao.tsx) — os pontos que aparecem sobre
// a foto real do paciente e o checklist de status abaixo dela. Estes testes
// garantem que a lista de regiões continue usando a mesma taxonomia clínica
// do resto do app (src/lib/faceRegions.ts) em vez de slugs inventados que
// divergiriam da Etapa 2, e que a ordem continue uma varredura plausível de
// cima para baixo na foto.
describe("SCAN_REGIONS — regiões usadas na animação de escaneamento", () => {
  it("uses only slugs that exist in the shared clinical taxonomy", () => {
    for (const region of SCAN_REGIONS) {
      expect(FACE_REGION_KEYS).toContain(region);
    }
  });

  it("has no duplicate regions", () => {
    expect(new Set(SCAN_REGIONS).size).toBe(SCAN_REGIONS.length);
  });

  it("sweeps top-to-bottom by each region's fallback y position", () => {
    const ys = SCAN_REGIONS.map((region) => FACE_REGIONS[region].fallback.y);
    const sorted = [...ys].sort((a, b) => a - b);
    expect(ys).toEqual(sorted);
  });
});

describe("SCAN_STEPS — passos do checklist de status", () => {
  it("has at least one step for each real async boundary handleAnalyze crosses", () => {
    // upload da foto, chamada à edge function, e finalização/navegação —
    // ver o comentário de handleAnalyze em NovaSessao.tsx.
    expect(SCAN_STEPS.length).toBeGreaterThanOrEqual(3);
  });

  it("has no duplicate step keys", () => {
    expect(new Set(SCAN_STEPS).size).toBe(SCAN_STEPS.length);
  });
});
