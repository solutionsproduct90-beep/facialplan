import React, { useState, useEffect } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import GradientButton from '@/components/harmonize/GradientButton';
import AuthInput from '@/components/harmonize/AuthInput';
import PhoneField from '@/components/harmonize/PhoneField';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { toast } from 'sonner';
import { format, parseISO, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { CalendarIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { composePhone, parsePhoneForEdit, DEFAULT_DIAL_CODE } from '@/lib/phone';
import { isValidEmail } from '@/lib/email';
import { confirmationMatchesPatientName, deletePatientPermanently } from '@/lib/patientPermanentDeletion';

// Ver comentário equivalente em NovoPaciente.tsx.
const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

const EditarPaciente: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const calendarLocale = dateFnsLocale[i18n.language] ?? ptBR;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteSheetOpen, setDeleteSheetOpen] = useState(false);
  // Exclusão DEFINITIVA (hard delete + Storage, ver patientPermanentDeletion.ts)
  // — ação separada do arquivamento acima (deleteSheetOpen), que é reversível
  // e não apaga nada de fato. Confirmação reforçada: precisa digitar o nome
  // completo do paciente, não só um segundo clique.
  const [permanentDeleteSheetOpen, setPermanentDeleteSheetOpen] = useState(false);
  const [permanentDeleteConfirmText, setPermanentDeleteConfirmText] = useState('');
  const [permanentDeleting, setPermanentDeleting] = useState(false);
  const [name, setName] = useState('');
  const [phoneDial, setPhoneDial] = useState(DEFAULT_DIAL_CODE);
  const [phoneCustomDial, setPhoneCustomDial] = useState('');
  const [phoneLocal, setPhoneLocal] = useState('');
  const [email, setEmail] = useState('');
  const [birthDate, setBirthDate] = useState<Date | undefined>();
  const [birthDatePopoverOpen, setBirthDatePopoverOpen] = useState(false);
  const [notes, setNotes] = useState('');
  // Ver comentário equivalente em NovoPaciente.tsx — opt-in opcional e
  // separado do TCLE de uso de imagem + IA, guardrail da Biblioteca de
  // Antes/Depois (src/pages/BibliotecaMarketing.tsx).
  const [marketingConsent, setMarketingConsent] = useState(false);
  // Ver comentário equivalente em NovoPaciente.tsx — opt-in opcional e
  // específico para uso de dados agregados/anonimizados da sessão na Central
  // de Inteligência do admin (ai_improvement_consent).
  const [aiImprovementConsent, setAiImprovementConsent] = useState(false);
  // Valor original carregado do banco — usado em handleSave só para decidir
  // se `ai_improvement_consent_at` precisa ser (re)carimbado (opt-in novo ou
  // reafirmado) ou zerado (opt-out), sem sobrescrever a data de um
  // consentimento que já existia e não mudou nesta edição.
  const [initialAiImprovementConsent, setInitialAiImprovementConsent] = useState(false);

  useEffect(() => {
    if (!id) return;
    supabase
      .from('patients')
      .select('name, phone, email, birth_date, notes, marketing_consent, ai_improvement_consent')
      .eq('id', id)
      .single()
      .then(({ data }) => {
        if (data) {
          setName(data.name);
          const parsedPhone = parsePhoneForEdit(data.phone);
          setPhoneDial(parsedPhone.dial);
          setPhoneCustomDial(parsedPhone.customDial);
          setPhoneLocal(parsedPhone.local);
          setEmail(data.email || '');
          setBirthDate(data.birth_date ? parseISO(data.birth_date) : undefined);
          setNotes(data.notes || '');
          setMarketingConsent(!!data.marketing_consent);
          setAiImprovementConsent(!!data.ai_improvement_consent);
          setInitialAiImprovementConsent(!!data.ai_improvement_consent);
        }
        setLoading(false);
      });
  }, [id]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { toast.error(t('patients.edit.nameRequired')); return; }
    if (email.trim() && !isValidEmail(email)) { toast.error(t('patients.fields.emailInvalid')); return; }
    if (!id) return;

    setSaving(true);
    try {
      const { error } = await supabase.from('patients').update({
        name: name.trim(),
        phone: composePhone(phoneDial, phoneCustomDial, phoneLocal),
        email: email.trim() || null,
        birth_date: birthDate ? format(birthDate, 'yyyy-MM-dd') : null,
        notes: notes.trim() || null,
        marketing_consent: marketingConsent,
        ai_improvement_consent: aiImprovementConsent,
        // Só recarimba a data quando o opt-in está marcado E não estava
        // marcado antes desta edição (consentimento novo) — um opt-in que já
        // era true e continua true mantém a data original no banco (omitido
        // do update). Desmarcar zera a data.
        ...(aiImprovementConsent
          ? (initialAiImprovementConsent ? {} : { ai_improvement_consent_at: new Date().toISOString() })
          : { ai_improvement_consent_at: null }),
      }).eq('id', id);

      if (error) throw error;
      toast.success(t('patients.edit.updated'));
      navigate(`/pacientes/${id}`);
    } catch (err: any) {
      toast.error(err.message || t('patients.edit.errorSaving'));
    } finally {
      setSaving(false);
    }
  };

  const handleArchive = async () => {
    if (!id) return;
    try {
      const { error } = await supabase.from('patients').update({
        is_deleted: true,
        deleted_at: new Date().toISOString(),
      }).eq('id', id);
      if (error) throw error;
      toast.success(t('patients.edit.archived'));
      navigate('/pacientes');
    } catch (err: any) {
      toast.error(err.message || t('patients.edit.errorArchiving'));
    }
  };

  /**
   * Eliminação real de dados (LGPD art. 18 / GDPR art. 17) — ver
   * src/lib/patientPermanentDeletion.ts e a migration
   * 20260911100000_add_delete_patient_permanently_rpc.sql para o que é
   * apagado. Irreversível: exige que o texto digitado bata com o nome
   * completo do paciente antes de chamar a RPC — barreira deliberadamente
   * mais forte que o segundo clique do arquivamento acima.
   */
  const handlePermanentDelete = async () => {
    if (!id) return;
    if (!confirmationMatchesPatientName(permanentDeleteConfirmText, name)) {
      toast.error(t('patients.edit.permanentDelete.confirmMismatch'));
      return;
    }
    setPermanentDeleting(true);
    try {
      const { storageCleanupFailedPaths } = await deletePatientPermanently(id, user?.id);

      // Dois desfechos diferentes, e a diferença importa: o hard delete no
      // banco é atômico e já aconteceu, mas a limpeza dos arquivos é uma
      // segunda chamada que pode falhar. Anunciar "excluído definitivamente"
      // com fotos do paciente ainda no bucket é afirmar conclusão que não
      // houve — justamente na funcionalidade que existe para cumprir o
      // direito ao esquecimento. Quando sobra arquivo, o aviso diz o que
      // falta e quantos, para o profissional poder acionar o suporte.
      if (storageCleanupFailedPaths.length > 0) {
        toast.warning(
          t('patients.edit.permanentDelete.storageCleanupFailed', { count: storageCleanupFailedPaths.length }),
          { duration: 10000 },
        );
      } else {
        toast.success(t('patients.edit.permanentDelete.success'));
      }
      navigate('/pacientes');
    } catch (err: any) {
      toast.error(err.message || t('patients.edit.permanentDelete.error'));
    } finally {
      setPermanentDeleting(false);
    }
  };

  if (loading) {
    return (
      <AppLayout title={t('patients.edit.title')} showBack>
        <div className="flex flex-col gap-3">
          <SkeletonCard lines={4} />
        </div>
      </AppLayout>
    );
  }

  return (
    <PageTransition>
    <AppLayout title={t('patients.edit.title')} showBack>
      <form onSubmit={handleSave} className="flex flex-col gap-4">
        <AuthInput
          label={t('patients.fields.fullName')}
          placeholder={t('patients.fields.fullNamePlaceholder')}
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <PhoneField
          label={t('patients.fields.phone')}
          dial={phoneDial}
          onDialChange={setPhoneDial}
          customDial={phoneCustomDial}
          onCustomDialChange={setPhoneCustomDial}
          local={phoneLocal}
          onLocalChange={setPhoneLocal}
          localPlaceholder={t('patients.fields.phonePlaceholder')}
        />

        <AuthInput
          label={t('patients.fields.email')}
          placeholder={t('patients.fields.emailPlaceholder')}
          // type="text" (não "email") de propósito — ver mesmo comentário em
          // NovoPaciente.tsx: evita que a validação nativa do navegador
          // bloqueie o submit antes da nossa validação traduzida rodar.
          type="text"
          inputMode="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        {/* Date Picker */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[13px] font-medium text-h-text-2">{t('patients.fields.birthDate')}</label>
          <Popover open={birthDatePopoverOpen} onOpenChange={setBirthDatePopoverOpen}>
            <PopoverTrigger asChild>
              <button
                type="button"
                className={cn(
                  'h-[48px] min-h-[44px] rounded-r-sm px-4 text-[15px] font-normal text-left bg-h-white border border-h-surface-3/40 outline-none flex items-center gap-2',
                  !birthDate && 'text-h-text-3'
                )}
              >
                <CalendarIcon size={16} className="text-h-text-3" />
                {birthDate ? format(birthDate, 'dd/MM/yyyy') : t('patients.fields.selectDate')}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto max-w-[calc(100vw-2rem)] p-0" align="start" side="bottom" collisionPadding={16}>
              <Calendar
                mode="single"
                selected={birthDate}
                onSelect={(date) => {
                  setBirthDate(date);
                  setBirthDatePopoverOpen(false);
                }}
                disabled={(date) => date > new Date() || date < new Date('1900-01-01')}
                captionLayout="dropdown"
                fromYear={1900}
                toYear={new Date().getFullYear()}
                defaultMonth={birthDate ?? new Date(new Date().getFullYear() - 30, 0)}
                locale={calendarLocale}
                initialFocus
                className={cn('p-3 pointer-events-auto')}
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Notes */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[13px] font-medium text-h-text-2">{t('patients.fields.notes')}</label>
          <textarea
            placeholder={t('patients.fields.notesPlaceholder')}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="rounded-r-sm px-4 py-3 text-[15px] font-normal text-h-text bg-h-white border border-h-surface-3/40 outline-none resize-none focus:ring-2 focus:ring-h-g-mid/30 placeholder:text-h-text-3"
          />
        </div>

        {/* Consentimento de marketing — ver comentário no estado
            marketingConsent acima. */}
        <label className="flex items-start gap-2.5 rounded-r-sm px-4 py-3 bg-h-white border border-h-surface-3/40 cursor-pointer">
          <input
            type="checkbox"
            checked={marketingConsent}
            onChange={(e) => setMarketingConsent(e.target.checked)}
            className="mt-0.5 w-[18px] h-[18px] flex-shrink-0 accent-h-g-start"
          />
          <span className="text-[13px] text-h-text-2 leading-snug">
            {t('patients.fields.marketingConsent')}
          </span>
        </label>

        {/* Consentimento de melhoria de IA — ver comentário no estado
            aiImprovementConsent acima. */}
        <label className="flex items-start gap-2.5 rounded-r-sm px-4 py-3 bg-h-white border border-h-surface-3/40 cursor-pointer">
          <input
            type="checkbox"
            checked={aiImprovementConsent}
            onChange={(e) => setAiImprovementConsent(e.target.checked)}
            className="mt-0.5 w-[18px] h-[18px] flex-shrink-0 accent-h-g-start"
          />
          <span className="text-[13px] text-h-text-2 leading-snug">
            {t('patients.fields.aiImprovementConsent')}
          </span>
        </label>

        <div className="mt-2">
          <GradientButton type="submit" disabled={saving}>
            {saving ? t('patients.edit.saving') : t('patients.edit.save')}
          </GradientButton>
        </div>

        {/* Archive trigger — reversível, ver handleArchive acima */}
        <div className="mt-4 flex justify-center">
          <button
            type="button"
            onClick={() => setDeleteSheetOpen(true)}
            style={{
              width: '100%', padding: 14, fontSize: 14, fontWeight: 600,
              color: '#E05050', background: 'rgba(224,80,80,0.08)',
              border: 'none', borderRadius: 12, cursor: 'pointer',
            }}
            className="min-h-[44px]"
          >
            {t('patients.edit.archiveButton')}
          </button>
        </div>

        {/* Zona de risco: exclusão DEFINITIVA — separada de propósito do
            arquivamento acima (visual e funcionalmente), ver
            handlePermanentDelete e patientPermanentDeletion.ts. */}
        <div className="mt-6 pt-4" style={{ borderTop: '1px solid #E5E3E0' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase', color: '#AAA8A5', textAlign: 'center', marginBottom: 10 }}>
            {t('patients.edit.permanentDelete.sectionTitle')}
          </p>
          <button
            type="button"
            onClick={() => { setPermanentDeleteConfirmText(''); setPermanentDeleteSheetOpen(true); }}
            style={{
              width: '100%', padding: 14, fontSize: 14, fontWeight: 700,
              color: '#FFFFFF', background: '#E05050',
              border: 'none', borderRadius: 12, cursor: 'pointer',
            }}
            className="min-h-[44px]"
          >
            {t('patients.edit.permanentDelete.button')}
          </button>
        </div>
      </form>

      {/* Archive action sheet (reversível) */}
      <BottomSheet
        open={deleteSheetOpen}
        onClose={() => setDeleteSheetOpen(false)}
      >
        <div style={{ padding: '8px 16px 16px' }}>
          <p style={{ fontSize: 13, color: '#AAA8A5', textAlign: 'center', marginBottom: 16, padding: '0 20px' }}>
            {t('patients.edit.archiveHint')}
          </p>
          <button
            onClick={handleArchive}
            style={{
              width: '100%', padding: 16, fontSize: 16, fontWeight: 600,
              color: '#E05050', background: '#F5F4F2',
              border: 'none', borderRadius: 12, cursor: 'pointer',
              marginBottom: 8,
            }}
            className="min-h-[44px]"
          >
            {t('patients.edit.archiveButton')}
          </button>
          <button
            onClick={() => setDeleteSheetOpen(false)}
            style={{
              width: '100%', padding: 16, fontSize: 16, fontWeight: 600,
              color: '#1A1918', background: '#F5F4F2',
              border: 'none', borderRadius: 12, cursor: 'pointer',
            }}
            className="min-h-[44px]"
          >
            {t('patients.edit.cancel')}
          </button>
        </div>
      </BottomSheet>

      {/* Permanent deletion sheet — irreversível, exige digitar o nome
          completo do paciente antes de habilitar o botão de confirmação. */}
      <BottomSheet
        open={permanentDeleteSheetOpen}
        onClose={() => setPermanentDeleteSheetOpen(false)}
      >
        <div style={{ padding: '8px 16px 16px' }}>
          <p style={{ fontSize: 13, color: '#E05050', fontWeight: 600, textAlign: 'center', marginBottom: 16, padding: '0 8px' }}>
            {t('patients.edit.permanentDelete.warning')}
          </p>
          <label style={{ display: 'block', fontSize: 13, fontWeight: 500, color: '#1A1918', marginBottom: 6 }}>
            {t('patients.edit.permanentDelete.confirmLabel')}
          </label>
          <input
            type="text"
            value={permanentDeleteConfirmText}
            onChange={(e) => setPermanentDeleteConfirmText(e.target.value)}
            placeholder={t('patients.edit.permanentDelete.confirmPlaceholder')}
            style={{
              width: '100%', height: 48, padding: '0 14px', fontSize: 15,
              borderRadius: 12, border: '1px solid #E5E3E0', outline: 'none',
              marginBottom: 16, boxSizing: 'border-box',
            }}
          />
          <button
            onClick={handlePermanentDelete}
            disabled={permanentDeleting || !confirmationMatchesPatientName(permanentDeleteConfirmText, name)}
            style={{
              width: '100%', padding: 16, fontSize: 16, fontWeight: 700,
              color: '#FFFFFF',
              background: confirmationMatchesPatientName(permanentDeleteConfirmText, name) ? '#E05050' : '#E9A8A8',
              border: 'none', borderRadius: 12,
              cursor: confirmationMatchesPatientName(permanentDeleteConfirmText, name) ? 'pointer' : 'not-allowed',
              marginBottom: 8,
            }}
            className="min-h-[44px]"
          >
            {permanentDeleting ? t('patients.edit.permanentDelete.deleting') : t('patients.edit.permanentDelete.confirmButton')}
          </button>
          <button
            onClick={() => setPermanentDeleteSheetOpen(false)}
            disabled={permanentDeleting}
            style={{
              width: '100%', padding: 16, fontSize: 16, fontWeight: 600,
              color: '#1A1918', background: '#F5F4F2',
              border: 'none', borderRadius: 12, cursor: 'pointer',
            }}
            className="min-h-[44px]"
          >
            {t('patients.edit.cancel')}
          </button>
        </div>
      </BottomSheet>
    </AppLayout>
    </PageTransition>
  );
};

export default EditarPaciente;
