import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import GradientButton from '@/components/harmonize/GradientButton';
import AuthInput from '@/components/harmonize/AuthInput';
import PhoneField from '@/components/harmonize/PhoneField';
import VoiceDictationButton from '@/components/harmonize/VoiceDictationButton';
import { toast } from 'sonner';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { CalendarIcon, Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { composePhone, dialCodeForCountry, DEFAULT_DIAL_CODE } from '@/lib/phone';
import { detectVisitorCountry } from '@/lib/geoCountry';
import { isValidEmail } from '@/lib/email';

// Candidato mostrado no dropdown de "Indicado por" — só os campos usados
// pela busca/exibição, nunca dados clínicos (o professional_id do próprio
// usuário já restringe a busca via RLS, então nada aqui vaza pacientes de
// outro profissional).
type ReferralCandidate = { id: string; name: string; referral_code: string };

// Mesmo mapa de locale do date-fns usado em AgendaTab.tsx/TreatmentPlanSection.tsx
// etc — sem isso o Calendar do react-day-picker sempre mostra mês/dias da
// semana em inglês, mesmo com o resto da tela traduzida.
const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

const NovoPaciente: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const calendarLocale = dateFnsLocale[i18n.language] ?? ptBR;
  const [name, setName] = useState('');
  const [phoneDial, setPhoneDial] = useState(DEFAULT_DIAL_CODE);
  const [phoneCustomDial, setPhoneCustomDial] = useState('');
  const [phoneLocal, setPhoneLocal] = useState('');
  const [email, setEmail] = useState('');
  const [birthDate, setBirthDate] = useState<Date | undefined>();
  const [birthDatePopoverOpen, setBirthDatePopoverOpen] = useState(false);
  const [notes, setNotes] = useState('');
  // Opt-in explícito e opcional (default false) para uso das fotos
  // antes/depois do paciente em divulgação/marketing — finalidade distinta
  // do TCLE de uso de imagem + IA coletado em PacienteDetalhe.tsx (aquele
  // cobre planejamento estético, não redes sociais). Guardrail principal da
  // Biblioteca de Antes/Depois (src/pages/BibliotecaMarketing.tsx): sem
  // marcar aqui, o paciente nunca aparece lá.
  const [marketingConsent, setMarketingConsent] = useState(false);
  // Opt-in explícito e opcional (default false), separado do consentimento
  // clínico geral (consent_given, coletado em PacienteDetalhe.tsx) e do
  // marketing_consent acima — finalidade própria: permitir que os dados da
  // sessão deste paciente entrem no cálculo AGREGADO E ANONIMIZADO que
  // alimenta a Central de Inteligência do admin (/admin/inteligencia). As 3
  // RPCs que a alimentam já filtram por este campo (ver
  // 20260911140000_filter_admin_intelligence_rpcs_by_ai_consent.sql) —
  // desmarcado aqui, a sessão do paciente nunca entra em nenhuma das
  // estatísticas, mesmo que o profissional tenha os outros consentimentos.
  const [aiImprovementConsent, setAiImprovementConsent] = useState(false);
  const [loading, setLoading] = useState(false);

  // "Indicado por" — Programa de Indicação: o profissional pode buscar/
  // selecionar outro paciente já cadastrado, ou colar diretamente o código
  // de indicação que recebeu (referral_code do paciente que indicou). Os
  // dois caminhos convergem para o mesmo `referred_by_patient_id` gravado no
  // INSERT — ver resolveReferredByPatientId em handleSave.
  const [referredByQuery, setReferredByQuery] = useState('');
  const [referredByPatient, setReferredByPatient] = useState<ReferralCandidate | null>(null);
  const [referredByOptions, setReferredByOptions] = useState<ReferralCandidate[]>([]);
  const [referredByOpen, setReferredByOpen] = useState(false);

  // Busca por nome OU código, restrita aos pacientes do próprio profissional
  // (RLS de `patients` já garante isso no servidor — o .eq abaixo é só pra
  // não pedir linhas que a policy ia barrar de qualquer forma). Só dispara
  // com paciente ainda não selecionado e texto digitado — nada é buscado no
  // carregamento da tela, então o campo fica silencioso até o profissional
  // interagir com ele.
  useEffect(() => {
    if (!user || referredByPatient || !referredByQuery.trim()) {
      setReferredByOptions([]);
      return;
    }
    let cancelled = false;
    const q = referredByQuery.trim();
    // Remove vírgula e parênteses antes de interpolar no filtro .or() do
    // PostgREST — esses caracteres têm significado sintático ali (separador
    // de condição e agrupamento) e um texto digitado com eles quebraria ou
    // alteraria o filtro pretendido.
    const safeQ = q.replace(/[,()]/g, '');
    const timer = setTimeout(async () => {
      if (!safeQ) {
        if (!cancelled) setReferredByOptions([]);
        return;
      }
      const { data } = await supabase
        .from('patients')
        .select('id, name, referral_code')
        .eq('professional_id', user.id)
        .eq('is_deleted', false)
        .or(`name.ilike.%${safeQ}%,referral_code.ilike.%${safeQ}%`)
        .order('name')
        .limit(5);
      if (!cancelled) setReferredByOptions((data as ReferralCandidate[] | null) ?? []);
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [user, referredByQuery, referredByPatient]);

  const handleSelectReferredBy = (candidate: ReferralCandidate) => {
    setReferredByPatient(candidate);
    setReferredByQuery('');
    setReferredByOpen(false);
  };

  const clearReferredBy = () => {
    setReferredByPatient(null);
    setReferredByQuery('');
  };

  // Resolve o texto digitado em "Indicado por" para um id de paciente:
  // - paciente já selecionado no dropdown -> usa o id direto;
  // - texto colado sem seleção (ex.: código de indicação recebido do
  //   paciente, sem passar pela busca) -> tenta casar por referral_code
  //   exato (case-insensitive);
  // - campo vazio -> não veio de indicação (null).
  // Retorna `undefined` quando o texto não bateu com nenhum paciente, para
  // handleSave distinguir "sem indicação" de "código inválido" e avisar o
  // profissional em vez de silenciosamente ignorar o que ele digitou.
  const resolveReferredByPatientId = async (): Promise<string | null | undefined> => {
    if (referredByPatient) return referredByPatient.id;
    const code = referredByQuery.trim();
    if (!code) return null;
    if (!user) return undefined;
    const { data } = await supabase
      .from('patients')
      .select('id, name, referral_code')
      .eq('professional_id', user.id)
      .eq('is_deleted', false)
      .eq('referral_code', code.toUpperCase())
      .maybeSingle();
    return (data as ReferralCandidate | null)?.id ?? undefined;
  };

  // Pré-seleciona o DDI por geolocalização (mesma lógica usada pra detectar
  // idioma, ver src/i18n/index.ts) — o profissional pode trocar livremente.
  // Só ajusta se o campo ainda não foi tocado (dial ainda no default), pra
  // nunca sobrescrever uma escolha manual feita antes da resposta chegar.
  useEffect(() => {
    let cancelled = false;
    detectVisitorCountry().then((country) => {
      if (cancelled) return;
      setPhoneDial((current) => (current === DEFAULT_DIAL_CODE ? dialCodeForCountry(country) : current));
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { toast.error(t('patients.new.nameRequired')); return; }
    if (email.trim() && !isValidEmail(email)) { toast.error(t('patients.fields.emailInvalid')); return; }
    if (!user) return;

    const referredByPatientId = await resolveReferredByPatientId();
    if (referredByPatientId === undefined) {
      toast.error(t('patients.new.referredByNotFound'));
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.from('patients').insert({
        professional_id: user.id,
        name: name.trim(),
        phone: composePhone(phoneDial, phoneCustomDial, phoneLocal),
        email: email.trim() || null,
        birth_date: birthDate ? format(birthDate, 'yyyy-MM-dd') : null,
        notes: notes.trim() || null,
        referred_by_patient_id: referredByPatientId,
        marketing_consent: marketingConsent,
        ai_improvement_consent: aiImprovementConsent,
        ai_improvement_consent_at: aiImprovementConsent ? new Date().toISOString() : null,
      }).select().single();

      if (error) throw error;
      toast.success(t('patients.new.created'));
      navigate(`/pacientes/${data.id}`);
    } catch (err: any) {
      toast.error(err.message || t('patients.new.errorSaving'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageTransition>
    <AppLayout title={t('patients.new.title')} showBack>
      <form onSubmit={handleSave} className="flex flex-col gap-4">
        <AuthInput
          label={t('patients.fields.fullName')}
          placeholder={t('patients.fields.fullNamePlaceholder')}
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <PhoneField
          label={t('patients.fields.phone')}
          dial={phoneDial}
          onDialChange={setPhoneDial}
          customDial={phoneCustomDial}
          onCustomDialChange={setPhoneCustomDial}
          local={phoneLocal}
          onLocalChange={setPhoneLocal}
          localPlaceholder={t('patients.fields.phonePlaceholder')}
        />

        <AuthInput
          label={t('patients.fields.email')}
          placeholder={t('patients.fields.emailPlaceholder')}
          // type="text" (não "email") de propósito: o campo é opcional e a
          // validação de formato é feita à mão em handleSave (mensagem
          // traduzida via toast) — com type="email" a validação nativa do
          // navegador bloquearia o submit silenciosamente antes que esse
          // código rodasse, mostrando um aviso não traduzido em vez do nosso.
          type="text"
          inputMode="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        {/* Indicado por — Programa de Indicação */}
        <div className="flex flex-col gap-1.5 relative">
          <label className="text-[13px] font-medium text-h-text-2">{t('patients.fields.referredBy')}</label>
          {referredByPatient ? (
            <div className="h-[48px] min-h-[44px] rounded-r-sm px-4 bg-h-white border border-h-surface-3/40 flex items-center justify-between">
              <span className="text-[15px] font-medium text-h-text truncate">{referredByPatient.name}</span>
              <button
                type="button"
                onClick={clearReferredBy}
                aria-label={t('patients.fields.referredByClear')}
                className="text-h-text-3 flex-shrink-0"
              >
                <X size={16} />
              </button>
            </div>
          ) : (
            <div className="h-[48px] min-h-[44px] rounded-r-sm px-4 bg-h-white border border-h-surface-3/40 flex items-center gap-2">
              <Search size={16} className="text-h-text-3 flex-shrink-0" />
              <input
                type="text"
                placeholder={t('patients.fields.referredByPlaceholder')}
                value={referredByQuery}
                onChange={(e) => { setReferredByQuery(e.target.value); setReferredByOpen(true); }}
                onFocus={() => setReferredByOpen(true)}
                onBlur={() => setTimeout(() => setReferredByOpen(false), 150)}
                className="flex-1 bg-transparent text-[15px] font-normal text-h-text outline-none placeholder:text-h-text-3"
              />
            </div>
          )}
          {referredByOpen && referredByOptions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 z-10 bg-h-white rounded-r-sm shadow-h-sm border border-h-surface-3/40 overflow-hidden">
              {referredByOptions.map((candidate) => (
                <button
                  key={candidate.id}
                  type="button"
                  onClick={() => handleSelectReferredBy(candidate)}
                  className="w-full text-left px-4 py-2.5 text-[14px] text-h-text hover:bg-h-surface-2/60"
                >
                  <span>{candidate.name}</span>
                  <span className="ml-1.5 text-[11px] text-h-text-3">· {candidate.referral_code}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Date Picker */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[13px] font-medium text-h-text-2">{t('patients.fields.birthDate')}</label>
          <Popover open={birthDatePopoverOpen} onOpenChange={setBirthDatePopoverOpen}>
            <PopoverTrigger asChild>
              <button
                type="button"
                className={cn(
                  'h-[48px] min-h-[44px] rounded-r-sm px-4 text-[15px] font-normal text-left bg-h-white border border-h-surface-3/40 outline-none flex items-center gap-2',
                  !birthDate && 'text-h-text-3'
                )}
              >
                <CalendarIcon size={16} className="text-h-text-3" />
                {birthDate ? format(birthDate, 'dd/MM/yyyy') : t('patients.fields.selectDate')}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto max-w-[calc(100vw-2rem)] p-0" align="start" side="bottom" collisionPadding={16}>
              <Calendar
                mode="single"
                selected={birthDate}
                onSelect={(date) => {
                  setBirthDate(date);
                  setBirthDatePopoverOpen(false);
                }}
                disabled={(date) => date > new Date() || date < new Date('1900-01-01')}
                captionLayout="dropdown"
                fromYear={1900}
                toYear={new Date().getFullYear()}
                defaultMonth={birthDate ?? new Date(new Date().getFullYear() - 30, 0)}
                locale={calendarLocale}
                initialFocus
                className={cn('p-3 pointer-events-auto')}
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Notes */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between gap-2">
            <label className="text-[13px] font-medium text-h-text-2">{t('patients.fields.notes')}</label>
            {/* Assistente de prontuário por voz — ditar em vez de digitar
                com o paciente na frente (ver useVoiceDictation). */}
            <VoiceDictationButton value={notes} onTranscript={setNotes} />
          </div>
          <textarea
            placeholder={t('patients.fields.notesPlaceholder')}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="rounded-r-sm px-4 py-3 text-[15px] font-normal text-h-text bg-h-white border border-h-surface-3/40 outline-none resize-none focus:ring-2 focus:ring-h-g-mid/30 placeholder:text-h-text-3"
          />
        </div>

        {/* Consentimento de marketing — opcional, opt-in explícito, default
            desmarcado. Ver comentário no estado marketingConsent acima. */}
        <label className="flex items-start gap-2.5 rounded-r-sm px-4 py-3 bg-h-white border border-h-surface-3/40 cursor-pointer">
          <input
            type="checkbox"
            checked={marketingConsent}
            onChange={(e) => setMarketingConsent(e.target.checked)}
            className="mt-0.5 w-[18px] h-[18px] flex-shrink-0 accent-h-g-start"
          />
          <span className="text-[13px] text-h-text-2 leading-snug">
            {t('patients.fields.marketingConsent')}
          </span>
        </label>

        {/* Consentimento de melhoria de IA — opcional, opt-in explícito,
            default desmarcado. Ver comentário no estado aiImprovementConsent
            acima. */}
        <label className="flex items-start gap-2.5 rounded-r-sm px-4 py-3 bg-h-white border border-h-surface-3/40 cursor-pointer">
          <input
            type="checkbox"
            checked={aiImprovementConsent}
            onChange={(e) => setAiImprovementConsent(e.target.checked)}
            className="mt-0.5 w-[18px] h-[18px] flex-shrink-0 accent-h-g-start"
          />
          <span className="text-[13px] text-h-text-2 leading-snug">
            {t('patients.fields.aiImprovementConsent')}
          </span>
        </label>

        <div className="mt-2">
          <GradientButton type="submit" disabled={loading}>
            {loading ? t('patients.new.saving') : t('patients.new.save')}
          </GradientButton>
        </div>
      </form>
    </AppLayout>
    </PageTransition>
  );
};

export default NovoPaciente;
