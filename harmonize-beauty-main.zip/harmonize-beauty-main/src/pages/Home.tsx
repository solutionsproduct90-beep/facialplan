import React, { useState, useRef } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate, Navigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useAuth } from '@/contexts/AuthContext';
import TopBar from '@/components/harmonize/TopBar';
import BottomNav from '@/components/harmonize/BottomNav';
import DesktopNav from '@/components/harmonize/DesktopNav';
import LogoMark from '@/components/harmonize/LogoMark';
import SessionCard from '@/components/harmonize/SessionCard';
import PullToRefresh from '@/components/harmonize/PullToRefresh';
import OnboardingModal from '@/components/harmonize/OnboardingModal';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { Plus, UserPlus, RefreshCw } from 'lucide-react';

/* ─── helpers ─── */
const getInitials = (name: string) =>
  name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);

const AVATAR_COLORS = [
  '#BF5F82', '#A855B5', '#7C5AC2', '#5B8FBF', '#2DB87A',
];

const Home: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const [scrolled, setScrolled] = useState(false);
  const [onboardingDismissed, setOnboardingDismissed] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  /* profile */
  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('profiles').select('*').eq('id', user!.id).single();
      return data;
    },
    enabled: !!user,
  });

  // Onboarding pós-cadastro (P1): aparece uma única vez, só depois que o
  // perfil terminou de carregar (evita flash antes de sabermos o valor real
  // de `onboarding_completed_at`).
  //
  // Os dois termos da condição têm papéis diferentes, e confundi-los foi um
  // bug real (ciclo 52 do QA Contínuo): `onboardingDismissed` só esconde na
  // hora, dentro desta montagem do componente, sem esperar a resposta do
  // banco. Quem faz a dispensa DURAR é o `queryClient.setQueryData` dentro de
  // OnboardingModal.finish, que grava `onboarding_completed_at` no cache
  // desta query. Precisa ser assim porque App.tsx usa
  // `<Routes key={location.pathname}>`: a cada navegação a árvore de rotas
  // remonta, este componente é recriado e `onboardingDismissed` volta a
  // `false`. Só o cache atravessa o remount.
  const showOnboarding = !!profile && !profile.onboarding_completed_at && !onboardingDismissed;

  /* active sessions */
  const {
    data: activeSessions,
    isLoading: loadingActive,
    isError: activeError,
    refetch: refetchActive,
  } = useQuery({
    queryKey: ['sessions-active', user?.id],
    queryFn: () =>
      // Paginado (src/lib/fetchAllRows.ts), como a mesma leitura em
      // Sessoes.tsx: o teto de linhas por resposta do PostgREST (Max Rows,
      // 1000 por padrão) é aplicado em silêncio, com `error: null`.
      fetchAllRows((from, to) =>
        supabase
          .from('sessions')
          .select('*, patients!inner(name)')
          .eq('professional_id', user!.id)
          .not('status', 'in', '("complete","abandoned")')
          .order('last_active_at', { ascending: false })
          .range(from, to),
      ),
    enabled: !!user,
  });

  /* recent patients — deduplicated by patient_id ordered by last session */
  const {
    data: recentPatients,
    isLoading: loadingPatients,
    isError: patientsError,
    refetch: refetchPatients,
  } = useQuery({
    queryKey: ['recent-patients', user?.id],
    queryFn: async () => {
      const { data: sessData, error: sessError } = await supabase
        .from('sessions')
        .select('patient_id, patients!inner(id, name), last_active_at')
        .eq('professional_id', user!.id)
        .order('last_active_at', { ascending: false })
        .limit(20);
      if (sessError) throw sessError;

      if (sessData && sessData.length > 0) {
        const seen = new Set<string>();
        const unique: { id: string; name: string }[] = [];
        for (const s of sessData) {
          const p = Array.isArray(s.patients) ? s.patients[0] : s.patients;
          if (p && !seen.has(p.id)) {
            seen.add(p.id);
            unique.push({ id: p.id, name: p.name });
            if (unique.length === 5) break;
          }
        }
        if (unique.length > 0) return unique;
      }

      const { data: patData, error: patError } = await supabase
        .from('patients')
        .select('id, name')
        .eq('professional_id', user!.id)
        .eq('is_deleted', false)
        .order('created_at', { ascending: false })
        .limit(5);
      if (patError) throw patError;

      return (patData ?? []).map(p => ({ id: p.id, name: p.name }));
    },
    enabled: !!user,
  });

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return t('home.greeting.morning');
    if (h < 18) return t('home.greeting.afternoon');
    return t('home.greeting.evening');
  };

  const firstName =
    profile?.full_name?.split(' ')[0] ||
    user?.user_metadata?.full_name?.split(' ')[0] ||
    t('home.defaultName');
  const initial = firstName[0]?.toUpperCase() || 'P';

  if (authLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-h-bg gap-4">
        <LogoMark size={48} />
        <div className="flex gap-1.5">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-[6px] h-[6px] rounded-full"
              style={{
                background: '#BF5F82',
                animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/auth/login" replace />;

  const hasActiveSessions = activeSessions && activeSessions.length > 0;
  const hasPatients = recentPatients && recentPatients.length > 0;
  // Em desktop a DesktopNav já cobre navegação e a TopBar (sem título) não renderiza mais
  // — então o "Em andamento" e "Pacientes recentes" viram duas colunas lado a lado quando
  // ambos têm conteúdo, aproveitando a largura real da tela em vez de ficar tudo empilhado.
  const showActiveBlock = loadingActive || hasActiveSessions || activeError;

  return (
    <PageTransition>
      <div className="min-h-screen bg-h-bg relative">

        <OnboardingModal open={showOnboarding} onDismiss={() => setOnboardingDismissed(true)} />

        {/* Wash decorativo pra preencher o espaço extra em telas grandes — some em mobile. */}
        <div
          className="hidden md:block fixed inset-0 -z-10 pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(224,92,138,0.07), transparent 60%), ' +
              'radial-gradient(ellipse 50% 35% at 100% 100%, rgba(124,90,194,0.05), transparent 55%)',
          }}
        />

        {/* ── TopBar ── */}
        <TopBar
          offsetForDesktopNav
          leftAction={
            <div className="flex items-center gap-2">
              <LogoMark size={28} />
              <span
                className="transition-opacity duration-200"
                style={{
                  fontSize: 16, fontWeight: 800, color: '#1A1918',
                  letterSpacing: '-0.02em',
                  opacity: scrolled ? 1 : 0,
                }}
              >
                {firstName}
              </span>
            </div>
          }
          rightAction={
            <button
              onClick={() => navigate('/perfil')}
              style={{
                width: 32, height: 32, borderRadius: '50%',
                background: '#BF5F82', display: 'flex',
                alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontSize: 12, fontWeight: 700,
                border: 'none', cursor: 'pointer',
              }}
            >
              {initial}
            </button>
          }
        />

        {/* ── Scroll container ── */}
        <div
          ref={scrollRef}
          className="scroll-container pt-[calc(56px+env(safe-area-inset-top,0px))] md:pt-24 pb-[calc(80px+env(safe-area-inset-bottom,0px))] md:pb-10"
          style={{
            minHeight: '100vh',
          }}
          onScroll={(e) => setScrolled(e.currentTarget.scrollTop > 40)}
        >
          <PullToRefresh onRefresh={async () => {
            await queryClient.invalidateQueries({ queryKey: ['sessions-active'] });
            await queryClient.invalidateQueries({ queryKey: ['recent-patients'] });
          }}>
            <div className="max-w-[430px] md:max-w-[680px] lg:max-w-[920px] mx-auto px-4 py-4 md:py-8 flex flex-col gap-5">

              {/* ── 1. Large greeting ── */}
              <div
                className="transition-all duration-200"
                style={{
                  opacity: scrolled ? 0 : 1,
                  transform: scrolled ? 'translateY(-8px)' : 'translateY(0)',
                  maxHeight: scrolled ? 0 : 60,
                  overflow: 'hidden',
                }}
              >
                <p style={{ fontSize: 13, fontWeight: 500, color: '#AAA8A5', marginBottom: 4 }}>
                  {greeting()}
                </p>
                <h2 style={{ fontSize: 26, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.03em', lineHeight: 1.1 }}>
                  {firstName}
                </h2>
              </div>

              {/* ── 2. Glass CTA ── */}
              <button
                onClick={() => navigate('/sessoes/nova')}
                className="w-full text-left press-scale"
                style={{
                  borderRadius: 24, padding: '20px',
                  position: 'relative', overflow: 'hidden',
                  background: 'linear-gradient(135deg, rgba(224,92,138,0.85) 0%, rgba(168,85,181,0.80) 50%, rgba(124,90,194,0.85) 100%)',
                  backdropFilter: 'blur(24px)',
                  WebkitBackdropFilter: 'blur(24px)',
                  border: '1px solid rgba(255,255,255,0.35)',
                  boxShadow: '0 8px 32px rgba(168,85,181,0.30), inset 0 1px 0 rgba(255,255,255,0.40)',
                }}
              >
                {/* highlight layers */}
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '50%', background: 'linear-gradient(180deg, rgba(255,255,255,0.12) 0%, transparent 100%)', borderRadius: '24px 24px 0 0', pointerEvents: 'none' }} />
                <div style={{ position: 'absolute', bottom: -40, right: -40, width: 120, height: 120, borderRadius: '50%', background: 'rgba(255,255,255,0.06)', pointerEvents: 'none' }} />

                <div className="flex items-start justify-between" style={{ position: 'relative', zIndex: 1 }}>
                  <div>
                    <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 11, fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '0.08em', marginBottom: 6 }}>
                      {t('home.newSession.label')}
                    </p>
                    <p style={{ color: '#FFFFFF', fontSize: 20, fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.2 }}>
                      {t('home.newSession.titleLine1')}<br/>{t('home.newSession.titleLine2')}
                    </p>
                  </div>
                  <div style={{ width: 44, height: 44, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.30)', background: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Plus size={20} color="rgba(255,255,255,0.9)" />
                  </div>
                </div>

                <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: 11, fontWeight: 500, marginTop: 14, position: 'relative', zIndex: 1 }}>
                  {t('home.newSession.subtitle')}
                </p>
              </button>

              {/* ── 3 & 4. Em andamento + Pacientes recentes: colunas lado a lado em desktop ── */}
              <div className="flex flex-col gap-5 md:grid md:grid-cols-2 md:gap-6 md:items-start">

              {/* ── 3. Em andamento (conditional) ── */}
              {showActiveBlock && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
                    <p className="text-[13px] font-semibold text-h-text">{t('home.activeSessions.title')}</p>
                  </div>
                  {loadingActive ? (
                    <div className="flex flex-col gap-2">
                      {[1, 2].map(i => <SkeletonCard key={i} />)}
                    </div>
                  ) : activeError ? (
                    <div
                      className="bg-h-white rounded-[16px] shadow-h-sm p-4 flex flex-col items-center gap-2 text-center"
                    >
                      <p className="text-[13px] text-h-text-2">{t('home.error.activeSessions')}</p>
                      <button
                        onClick={() => refetchActive()}
                        className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
                        style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
                      >
                        <RefreshCw size={14} />
                        {t('home.error.retry')}
                      </button>
                    </div>
                  ) : (
                    <div className="bg-h-white rounded-[16px] shadow-h-sm overflow-hidden">
                      {activeSessions!.map((s: any, index: number) => (
                        <React.Fragment key={s.id}>
                          <SessionCard
                            id={s.id}
                            patientName={s.patients?.name ?? t('home.defaultPatientName')}
                            status={s.status}
                            createdAt={s.created_at}
                            selectedProcedure={s.selected_procedure}
                            grouped={true}
                          />
                          {index < activeSessions!.length - 1 && (
                            <div style={{ height: 0.5, background: '#E5E3E0', marginLeft: 62 }} />
                          )}
                        </React.Fragment>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* ── 4. Pacientes recentes ── */}
              <div className={showActiveBlock ? '' : 'md:col-span-2'}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
                    <p className="text-[13px] font-semibold text-h-text">{t('home.recentPatients.title')}</p>
                  </div>
                  <button
                    onClick={() => navigate('/pacientes')}
                    style={{ fontSize: 12, fontWeight: 600, color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer' }}
                  >
                    {t('home.recentPatients.viewAll')}
                  </button>
                </div>

                {loadingPatients ? (
                  <div className="flex gap-3 overflow-hidden">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="flex flex-col items-center gap-1.5 animate-pulse" style={{ minWidth: 52 }}>
                        <div className="w-[44px] h-[44px] rounded-full bg-h-surface-3" />
                        <div className="h-2 w-10 bg-h-surface-3 rounded" />
                      </div>
                    ))}
                  </div>
                ) : patientsError ? (
                  <div
                    className="w-full p-4 rounded-[14px] flex flex-col items-center gap-2 text-center"
                    style={{ background: 'rgba(191,95,130,0.06)', border: '1px solid rgba(191,95,130,0.15)' }}
                  >
                    <p className="text-[13px] text-h-text-2">{t('home.error.recentPatients')}</p>
                    <button
                      onClick={() => refetchPatients()}
                      className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
                      style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
                    >
                      <RefreshCw size={14} />
                      {t('home.error.retry')}
                    </button>
                  </div>
                ) : hasPatients ? (
                  <div className="flex gap-3 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
                    {recentPatients!.map((patient, index) => (
                      <button
                        key={patient.id}
                        onClick={() => navigate('/sessoes/nova', {
                          state: { preselectedPatientId: patient.id, preselectedPatientName: patient.name },
                        })}
                        className="flex flex-col items-center gap-1.5 flex-shrink-0 press-scale"
                        style={{ minWidth: 52, background: 'none', border: 'none', cursor: 'pointer' }}
                      >
                        <div
                          className="w-[44px] h-[44px] rounded-full flex items-center justify-center text-[13px] font-bold"
                          style={{ background: AVATAR_COLORS[index % AVATAR_COLORS.length], color: '#fff' }}
                        >
                          {getInitials(patient.name)}
                        </div>
                        <span style={{ fontSize: 11, fontWeight: 500, color: '#6B6965' }}>
                          {patient.name.split(' ')[0]}
                        </span>
                      </button>
                    ))}

                    {/* + add new */}
                    <button
                      onClick={() => navigate('/pacientes/novo')}
                      className="flex flex-col items-center gap-1.5 flex-shrink-0 press-scale"
                      style={{ minWidth: 52, background: 'none', border: 'none', cursor: 'pointer' }}
                    >
                      <div
                        className="w-[44px] h-[44px] rounded-full flex items-center justify-center"
                        style={{ background: '#F5F4F2', border: '1.5px dashed #D0CECA' }}
                      >
                        <UserPlus size={16} style={{ color: '#AAA8A5' }} />
                      </div>
                      <span style={{ fontSize: 11, fontWeight: 500, color: '#AAA8A5' }}>
                        {t('home.recentPatients.addNew')}
                      </span>
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => navigate('/pacientes/novo')}
                    style={{
                      width: '100%', padding: '16px',
                      background: 'rgba(191,95,130,0.06)',
                      border: '1.5px dashed rgba(191,95,130,0.25)',
                      borderRadius: 14, cursor: 'pointer',
                      display: 'flex', alignItems: 'center', gap: 10,
                    }}
                  >
                    <UserPlus size={18} style={{ color: '#BF5F82' }} />
                    <span style={{ fontSize: 14, fontWeight: 600, color: '#BF5F82' }}>
                      {t('home.recentPatients.addFirst')}
                    </span>
                  </button>
                )}
              </div>

              </div>

            </div>
          </PullToRefresh>
        </div>

        <DesktopNav />
        <BottomNav />
      </div>
    </PageTransition>
  );
};

export default Home;
