import React, { useState, useEffect, useCallback, useRef } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { logClientError } from '@/lib/logClientError';
import { useAuth } from '@/contexts/AuthContext';
import TopBar from '@/components/harmonize/TopBar';
import StageDots from '@/components/harmonize/StageDots';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import SheetSelect from '@/components/harmonize/SheetSelect';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import GhostButton from '@/components/harmonize/GhostButton';
import AnamnesisSheet from '@/components/harmonize/AnamnesisSheet';
import { AlertTriangle, Check, X, Minus, Plus, ShieldAlert, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import type { ApplicationPoint, Stage1Analysis, Substance, Suggestion } from '@/types/harmonize';
import {
  SUBSTANCE_DEFAULT_UNIT,
  SUBSTANCE_KEYS,
  SUBSTANCE_LABEL,
  SUBSTANCE_DEFAULT_TECHNIQUE,
  SUBSTANCE_DEFAULT_DEPTH,
  SUBSTANCE_DEFAULT_DEVICE,
} from '@/types/harmonize';
import { regionLabel, regionFallbackPosition } from '@/lib/faceRegions';
import type { Json } from '@/integrations/supabase/types';
import AnamnesisRiskBanner from '@/components/harmonize/AnamnesisRiskBanner';
import AnalysisProvenanceBanner from '@/components/harmonize/AnalysisProvenanceBanner';
import { analysisProvenance } from '@/lib/analysisProvenance';
import { getActiveRiskLabels } from '@/lib/anamnesisRisk';
import { risksAffectingRegion } from '@/types/anamnesis';
import type { RiskFlags, SimpleRiskKey } from '@/types/anamnesis';
import { logDataAccess } from '@/lib/auditLog';
import { useSendAnamnesisLink } from '@/hooks/useSendAnamnesisLink';
import { useOfflineSessionDraft } from '@/hooks/useOfflineSessionDraft';
import type { Stage1ReviewDraft } from '@/types/offlineDraft';
import PendingSyncIndicator from '@/components/harmonize/PendingSyncIndicator';

type Decision = 'pending' | 'accepted' | 'discarded';

const confidenceVariant = (c: number) => {
  if (c >= 70) return 'alta' as const;
  if (c >= 45) return 'media' as const;
  return 'baixa' as const;
};

const SessaoEstagio1: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useTranslation();
  const { sendAnamnesisLink, linkGenerating } = useSendAnamnesisLink();
  const [analysis, setAnalysis] = useState<Stage1Analysis | null>(null);
  const [patientId, setPatientId] = useState<string | null>(null);
  const [patientName, setPatientName] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [decisions, setDecisions] = useState<Record<string, Decision>>({});
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  // Substância editada pelo profissional para cada sugestão (chave = Suggestion.id),
  // divergindo da `substance` original sugerida pela IA — ver comentário em
  // handleProceed sobre por que o aceite usa este valor, não `s.substance`.
  const [substances, setSubstances] = useState<Record<string, Substance>>({});
  // Sugestões cujo campo de quantidade OU substância já recebeu foco/clique
  // do profissional — item P1 do backlog: hoje um único toque no botão
  // "Aceitar" bastava para aprovar uma sugestão de IA sem o profissional
  // nunca ter olhado a quantidade/substância proposta, risco de segurança
  // clínica. Marcado em `adjustQuantity`, `setSubstance` e no `onOpen` do
  // seletor de substância (abrir o sheet já conta como revisão, mesmo que o
  // profissional feche sem trocar o valor) — nunca desmarcado depois de
  // marcado. Gate aplicado só à TRANSIÇÃO para "accepted" no botão de
  // aceite; ajustar e descartar continuam livres (ver `canAccept` abaixo).
  const [reviewedSuggestions, setReviewedSuggestions] = useState<Record<string, boolean>>({});
  // Id da sugestão cujo disclaimer de confiança está aberto (só um por vez) —
  // controlado manualmente porque o modo padrão do Radix Tooltip (hover/
  // focus) nunca abre com toque em touchscreen (onFocus é suprimido quando
  // isPointerDownRef já está true pelo próprio pointerdown do tap, e onClick
  // só fecha) — sem isso o disclaimer fica invisível pra quem usa celular/
  // tablet, que é o dispositivo principal do app.
  const [openConfidenceDisclaimerId, setOpenConfidenceDisclaimerId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [riskLabels, setRiskLabels] = useState<string[]>([]);
  // Flags cruas da anamnese (não só os rótulos já traduzidos em `riskLabels`)
  // — precisamos delas aqui pra cruzar risco×região por sugestão (ver
  // `risksAffectingRegion` em src/types/anamnesis.ts), o que os rótulos
  // sozinhos não permitem.
  const [riskFlags, setRiskFlags] = useState<RiskFlags | null>(null);
  const [riskAcknowledged, setRiskAcknowledged] = useState(false);
  // `null` enquanto ainda não checamos; `false` só depois de confirmar que
  // não existe NENHUMA anamnese para este paciente (nem respondida por ele,
  // nem preenchida em nome dele) — é essa distinção (e não `riskLabels`
  // vazio, que também acontece com uma anamnese sem nenhum risco marcado)
  // que decide se a tela de bloqueio abaixo aparece. Ver `anamnesisGate`.
  const [hasAnamnesis, setHasAnamnesis] = useState<boolean | null>(null);
  const [anamnesisSheetOpen, setAnamnesisSheetOpen] = useState(false);
  const [anamnesisLinkSent, setAnamnesisLinkSent] = useState(false);
  const [checkingAnamnesis, setCheckingAnamnesis] = useState(false);

  // Rascunho offline da revisão desta Etapa (backlog "Modo offline-first
  // (PWA) completo pra sala de procedimento") — decisões/quantidades/
  // substâncias/revisão e o reconhecimento do banner de risco só existem em
  // memória até o toque em "Avançar" (ver handleProceed), então hoje se
  // perdem inteiramente num reload. Sem `onSync`: não há uma coluna própria
  // no Supabase pra esse estado de revisão em progresso, então este
  // rascunho serve só pra SOBREVIVER a um reload/queda de conexão — nunca é
  // reenviado sozinho ao servidor (diferente do rascunho de pontos da
  // Etapa 2, que tem um alvo real, ver SessaoEstagio2.tsx).
  const {
    draft: offlineDraft,
    loaded: offlineDraftLoaded,
    hasPendingDraft,
    saveDraft: saveOfflineDraft,
    clearDraft: clearOfflineDraft,
  } = useOfflineSessionDraft({ sessionId: id });
  const draftRestoredRef = useRef(false);
  const photoCachedRef = useRef(false);

  // Extraído do load inicial pra poder ser chamado de novo depois: (a) pelo
  // botão "Já preencheu? Verificar novamente" da tela de bloqueio, quando o
  // paciente preencheu pelo link enquanto o profissional aguardava aqui; e
  // (b) pelo `onSaved` do preenchimento em nome do paciente, que precisa
  // recarregar as flags de risco recém-salvas (não só destravar o gate).
  const loadAnamnesis = useCallback(async (patientIdParam: string) => {
    const { data: anamnesis, error } = await supabase
      .from('anamnesis')
      .select('risk_flags')
      .eq('patient_id', patientIdParam)
      .maybeSingle();

    if (error) {
      // Falha ao consultar (rede, permissão) não é o mesmo que "não existe
      // anamnese" — mas também não temos como confirmar que existe. Erra pro
      // lado seguro (mantém o gate) em vez de liberar o avanço silenciosamente
      // por causa de uma falha transitória; ver mesmo padrão de log em
      // PacienteDetalhe.tsx.
      // eslint-disable-next-line no-console
      console.error('[SessaoEstagio1] Falha ao verificar anamnese:', error);
      if (user) {
        logClientError({
          professionalId: user.id,
          stage: 'anamnesis',
          errorType: 'anamnesis_read_failed',
          message: `patient_id=${patientIdParam} :: ${error.message ?? 'erro desconhecido'}`,
        });
      }
      setHasAnamnesis(false);
      setRiskFlags(null);
      setRiskLabels([]);
      return;
    }

    setHasAnamnesis(!!anamnesis);
    if (anamnesis) {
      const flags = anamnesis.risk_flags as unknown as RiskFlags;
      setRiskFlags(flags);
      setRiskLabels(getActiveRiskLabels(flags, t));
      logDataAccess('view_anamnesis', 'patient', patientIdParam);
    } else {
      setRiskFlags(null);
      setRiskLabels([]);
    }
  }, [t, user]);

  useEffect(() => {
    if (!id || !user) return;
    const load = async () => {
      const { data: session } = await supabase
        .from('sessions')
        .select('stage1_analysis, patient_id, original_image_url')
        .eq('id', id)
        .single();
      if (session) {
        const parsed = session.stage1_analysis as unknown as Stage1Analysis | null;
        setAnalysis(parsed);
        setPatientId(session.patient_id);
        const initialQty: Record<string, number> = {};
        const initialSubstance: Record<string, Substance> = {};
        parsed?.suggestions?.forEach(s => {
          initialQty[s.id] = s.quantitySuggested;
          initialSubstance[s.id] = s.substance;
        });
        setQuantities(initialQty);
        setSubstances(initialSubstance);

        const { data: patient } = await supabase
          .from('patients')
          .select('name')
          .eq('id', session.patient_id)
          .single();
        if (patient) setPatientName(patient.name);

        await loadAnamnesis(session.patient_id);

        if (session.original_image_url) {
          const { data: signed } = await supabase.storage
            .from('patient-photos')
            .createSignedUrl(session.original_image_url, 3600);
          if (signed?.signedUrl) {
            setPhotoUrl(signed.signedUrl);
            logDataAccess('view_patient_photo', 'session', id);
          }
        }
      }
      setLoading(false);
    };
    load();
  }, [id, user, loadAnamnesis]);

  // Recupera o rascunho local (se houver) assim que TANTO o carregamento do
  // Supabase quanto a leitura do IndexedDB terminarem — roda uma única vez
  // por sessão. Um rascunho pendente prevalece sobre os valores iniciais
  // (derivados de `analysis.suggestions` acima) porque representa uma
  // revisão do profissional feita DEPOIS daquele carregamento, possivelmente
  // offline. Sem foto carregada ainda (offline no reload, antes da URL
  // assinada do Storage ser reobtida), cai pro cache local da foto — ver
  // comentário do próximo efeito sobre o que esse cache cobre/não cobre.
  useEffect(() => {
    if (draftRestoredRef.current) return;
    if (loading || !offlineDraftLoaded) return;
    draftRestoredRef.current = true;
    const review = offlineDraft?.pendingSync ? offlineDraft.stage1Review : null;
    if (review) {
      setDecisions(review.decisions);
      setQuantities(review.quantities);
      setSubstances(review.substances);
      setReviewedSuggestions(review.reviewedSuggestions);
      setRiskAcknowledged(review.riskAcknowledged);
    }
    if (!photoUrl && offlineDraft?.photoDataUrl) {
      setPhotoUrl(offlineDraft.photoDataUrl);
    }
  }, [loading, offlineDraftLoaded, offlineDraft, photoUrl]);

  // Cache local da foto do paciente (data URL) — só para a tela continuar
  // mostrando a foto se a conexão cair DEPOIS que ela já foi carregada uma
  // vez (a URL assinada do Storage expira e depende de rede pra ser
  // reobtida a cada visita); nunca a foto original em si, que já vive no
  // Supabase Storage antes de qualquer rascunho existir. Roda uma única vez
  // por foto carregada (`photoCachedRef`); falha silenciosamente (rede,
  // CORS, indisponibilidade do IndexedDB) sem afetar a exibição normal da
  // foto — é só uma rede de segurança para o cenário offline acima.
  useEffect(() => {
    if (!photoUrl || photoCachedRef.current) return;
    if (typeof fetch !== 'function' || typeof FileReader === 'undefined') return;
    photoCachedRef.current = true;
    let cancelled = false;
    (async () => {
      try {
        const response = await fetch(photoUrl);
        const blob = await response.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(blob);
        });
        if (!cancelled) saveOfflineDraft({ photoDataUrl: dataUrl });
      } catch (err) {
        console.error('[SessaoEstagio1] Falha ao cachear foto localmente:', err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [photoUrl, saveOfflineDraft]);

  // Salva a revisão em progresso (decisões, quantidades, substâncias,
  // sugestões revisadas, reconhecimento do risco) assim que ela muda —
  // debounced pelo próprio hook. Só começa a observar DEPOIS da restauração
  // acima (`draftRestoredRef`) para não gravar um rascunho vazio por cima
  // de um rascunho recém-recuperado, na primeira renderização antes do
  // efeito de restauração rodar.
  useEffect(() => {
    if (!draftRestoredRef.current) return;
    const review: Stage1ReviewDraft = {
      decisions,
      quantities,
      substances,
      reviewedSuggestions,
      riskAcknowledged,
    };
    saveOfflineDraft({ stage1Review: review });
  }, [decisions, quantities, substances, reviewedSuggestions, riskAcknowledged, saveOfflineDraft]);

  const handleRecheckAnamnesis = async () => {
    if (!patientId) return;
    setCheckingAnamnesis(true);
    try {
      await loadAnamnesis(patientId);
    } finally {
      setCheckingAnamnesis(false);
    }
  };

  const handleSendAnamnesisLinkFromGate = async () => {
    if (!patientId) return;
    const sent = await sendAnamnesisLink({ id: patientId, name: patientName });
    if (sent) setAnamnesisLinkSent(true);
  };

  const handleAnamnesisSaved = async () => {
    if (patientId) await loadAnamnesis(patientId);
  };

  const suggestions = analysis?.suggestions ?? [];
  const acceptedCount = suggestions.filter(s => decisions[s.id] === 'accepted').length;

  const decisionOf = (s: Suggestion): Decision => decisions[s.id] ?? 'pending';

  // Substância efetiva de uma sugestão: a editada pelo profissional (se
  // houver) ou a original sugerida pela IA — e a unidade correspondente,
  // que muda junto (ex: trocar toxina_botulinica por acido_hialuronico troca
  // "unidades" por "ml"). Usadas tanto pela UI (stepper/rótulo) quanto pelo
  // aceite em handleProceed, pra nunca divergirem entre si.
  const substanceOf = (s: Suggestion): Substance => substances[s.id] ?? s.substance;
  const unitOf = (s: Suggestion): 'ml' | 'unidades' => SUBSTANCE_DEFAULT_UNIT[substanceOf(s)];

  const setDecision = (s: Suggestion, decision: Decision) => {
    setDecisions(prev => ({ ...prev, [s.id]: decision }));
  };

  const markReviewed = (s: Suggestion) => {
    setReviewedSuggestions(prev => (prev[s.id] ? prev : { ...prev, [s.id]: true }));
  };

  const isReviewed = (s: Suggestion) => !!reviewedSuggestions[s.id];

  const setSubstance = (s: Suggestion, substance: Substance) => {
    setSubstances(prev => ({ ...prev, [s.id]: substance }));
    markReviewed(s);
  };

  const adjustQuantity = (s: Suggestion, delta: number) => {
    setQuantities(prev => {
      const current = prev[s.id] ?? s.quantitySuggested;
      const step = unitOf(s) === 'unidades' ? 1 : 0.1;
      const next = Math.max(step, Math.round((current + delta * step) * 100) / 100);
      return { ...prev, [s.id]: next };
    });
    markReviewed(s);
  };

  const handleProceed = async () => {
    if (!id || acceptedCount === 0) return;
    setSaving(true);

    const acceptedPoints: ApplicationPoint[] = suggestions
      .filter(s => decisionOf(s) === 'accepted')
      .map(s => {
        const fallback = regionFallbackPosition(s.region);
        // Substância/unidade: a versão EDITADA (substanceOf/unitOf), não a
        // original sugerida pela IA (s.substance/s.unit) — o profissional
        // pode ter corrigido a substância na revisão desta sugestão, antes
        // de aceitar, e essa correção precisa sobreviver ao aceite.
        const substance = substanceOf(s);
        return {
          id: s.id,
          region: s.region,
          label: s.label,
          substance,
          quantity: quantities[s.id] ?? s.quantitySuggested,
          unit: unitOf(s),
          x: fallback.x,
          y: fallback.y,
          confidence: s.confidence,
          source: 'ai',
          justification: s.justification,
          // Valor sensato por substância (item 1 do backlog P0) — o
          // profissional pode editar cada campo livremente na Etapa 2.
          technique: SUBSTANCE_DEFAULT_TECHNIQUE[substance],
          depth: SUBSTANCE_DEFAULT_DEPTH[substance],
          device: SUBSTANCE_DEFAULT_DEVICE[substance],
        };
      });

    const summaryLabel = acceptedPoints.length === 1
      ? acceptedPoints[0].label
      : `${acceptedPoints.length} pontos planejados`;

    // Status só avança para 'stage2' depois da triagem de pele obrigatória
    // (critérios ABCDE) — ver SessaoTriagemPele. stage2_overlay já é
    // persistido aqui pra não perder as escolhas do profissional se ele
    // sair no meio da triagem e retomar a sessão depois.
    await supabase.from('sessions').update({
      stage2_overlay: acceptedPoints as unknown as Json,
      selected_procedure: summaryLabel,
    }).eq('id', id);

    // Revisão da Etapa 1 confirmada no Supabase — o rascunho local de
    // revisão (se houver) não tem mais função, a sessão avança de etapa.
    clearOfflineDraft();
    setSaving(false);
    navigate(`/sessoes/${id}/triagem-pele`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-h-bg">
        <TopBar title={t('sessions.stage1.title')} showBack />
        <div className="pt-[56px] p-5 flex flex-col gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-h-white rounded-r shadow-h-sm h-[120px] animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (!analysis) return null;

  // Gate P0: sem NENHUMA anamnese registrada para o paciente (nem respondida
  // por ele, nem preenchida em nome dele — ver AnamnesisSheet.fillOnBehalf),
  // o profissional não vê a revisão de sugestões/avanço para o planejamento
  // — só esta tela, com as duas saídas já existentes no produto para
  // resolver isso ali mesmo. Antes desta mudança, ausência total de
  // anamnese não acionava nem o banner de risco (que só aparece quando HÁ
  // flags ativas), então o avanço nunca era bloqueado de fato — a triagem de
  // risco virava opcional na prática. Uma anamnese de sessão anterior do
  // MESMO paciente já libera normalmente (`anamnesis` é por paciente, não
  // por sessão — ver UNIQUE(patient_id) na migration).
  if (hasAnamnesis === false && patientId) {
    return (
      <PageTransition>
        <div className="min-h-screen bg-h-bg">
          <TopBar
            title={t('sessions.stage1.title')}
            showBack
            onBack={() => navigate(-1)}
            rightAction={patientName ? <HarmonizeBadge variant="grad">{patientName.split(' ')[0]}</HarmonizeBadge> : undefined}
          />
          <div className="pt-[56px] max-w-[430px] md:max-w-[560px] mx-auto w-full">
            <div className="px-5 py-4 flex justify-center">
              <StageDots currentStage={1} activeColor="#BF5F82" />
            </div>
            <div className="px-5">
              <div className="bg-h-white rounded-r shadow-h-sm p-5 flex flex-col items-center text-center gap-3">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: 'rgba(224,80,80,0.10)' }}
                >
                  <ShieldAlert size={22} style={{ color: '#E05050' }} />
                </div>
                <p className="text-[15px] font-bold text-h-text">{t('sessions.stage1.anamnesisGate.title')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{t('sessions.stage1.anamnesisGate.body')}</p>

                {anamnesisLinkSent && (
                  <p className="text-[12px] font-semibold" style={{ color: '#2DB87A' }}>
                    {t('sessions.stage1.anamnesisGate.linkSentHint')}
                  </p>
                )}

                <div className="flex flex-col gap-2 w-full mt-1">
                  <GradientButton onClick={() => setAnamnesisSheetOpen(true)}>
                    {t('anamnesis.detail.fillNow')}
                  </GradientButton>
                  <SecondaryButton onClick={handleSendAnamnesisLinkFromGate} disabled={linkGenerating}>
                    {linkGenerating ? t('anamnesis.linkGenerating') : t('anamnesis.sendButton')}
                  </SecondaryButton>
                  <GhostButton onClick={handleRecheckAnamnesis} disabled={checkingAnamnesis}>
                    {checkingAnamnesis
                      ? t('sessions.stage1.anamnesisGate.checking')
                      : t('sessions.stage1.anamnesisGate.recheck')}
                  </GhostButton>
                </div>
              </div>
            </div>
          </div>
        </div>

        <AnamnesisSheet
          open={anamnesisSheetOpen}
          onClose={() => setAnamnesisSheetOpen(false)}
          patientId={patientId}
          initial={null}
          fillOnBehalf
          onSaved={handleAnamnesisSaved}
        />
      </PageTransition>
    );
  }

  return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg pb-28">
      <TopBar
        title={t('sessions.stage1.title')}
        showBack
        onBack={() => navigate(-1)}
        rightAction={patientName ? <HarmonizeBadge variant="grad">{patientName.split(' ')[0]}</HarmonizeBadge> : undefined}
      />
      <div className="pt-[56px] max-w-[430px] md:max-w-[560px] mx-auto w-full">
        <div className="px-5 py-4 flex flex-col items-center gap-2">
          <StageDots currentStage={1} activeColor="#BF5F82" />
          <PendingSyncIndicator pending={hasPendingDraft} syncing={false} />
        </div>

        <div className="px-5 flex flex-col gap-4">
          {/* Proveniência da análise — aviso PERSISTENTE (não um toast) sempre
              que a sessão carregar uma análise que não é comprovadamente da
              IA. Antes desta mudança, o único sinal de que a análise gravada
              era de demonstração era o toast disparado uma única vez em
              NovaSessao (toastAiUnavailable/toastAiMock): quem reabrisse a
              sessão depois — ou outro profissional — não tinha como saber. Vem
              ANTES da foto e de qualquer conteúdo clínico de propósito: é a
              primeira coisa a ser lida, não uma ressalva no rodapé. Não
              renderiza nada quando a análise é de IA de verdade. Ver
              src/lib/analysisProvenance.ts. */}
          <AnalysisProvenanceBanner provenance={analysisProvenance(analysis)} />

          {/* Patient photo */}
          <div className="relative w-full aspect-[3/4] bg-h-surface-3 rounded-r overflow-hidden">
            {photoUrl ? (
              <img src={photoUrl} alt={t('sessions.stage1.photoAlt')} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-gradient-to-b from-h-surface-3 to-h-bg flex items-center justify-center">
                <span className="text-h-text-3 text-[14px]">{t('sessions.stage1.photoPlaceholder')}</span>
              </div>
            )}
          </div>

          {/* Anamnesis risk banner — reconhecimento explícito, não bloqueia
              definitivamente: o botão de continuar só fica desabilitado até
              o checkbox ser marcado. */}
          {riskLabels.length > 0 && (
            <AnamnesisRiskBanner title={t('sessions.stage1.riskBanner.title')} labels={riskLabels}>
              <label className="flex items-start gap-2.5 mt-3 pt-3 cursor-pointer" style={{ borderTop: '1px solid rgba(224,80,80,0.18)' }}>
                <input
                  type="checkbox"
                  checked={riskAcknowledged}
                  onChange={(e) => setRiskAcknowledged(e.target.checked)}
                  style={{ marginTop: 2, width: 20, height: 20, flexShrink: 0 }}
                />
                <span className="text-[12px] font-semibold text-h-text-2 leading-snug">
                  {t('sessions.stage1.riskBanner.ack')}
                </span>
              </label>
            </AnamnesisRiskBanner>
          )}

          {/* Resumo do Paciente — leitura geral do perfil facial, distinta
              das sugestões pontuais abaixo (ver src/types/harmonize.ts).
              Campo aditivo/opcional: ausente numa análise mais antiga, ou
              se a IA não trouxe esse campo, a seção simplesmente não
              aparece. */}
          {analysis.patientSummary && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4">
              <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide mb-1">{t('sessions.stage1.patientSummaryTitle')}</p>
              <p className="text-[13px] text-h-text-2 leading-snug">{analysis.patientSummary}</p>
            </div>
          )}

          {/* Análise Estrutural — formato/simetria/proporções, sempre como
              texto descritivo (nunca um score 0-100, ver comentário em
              FacialStructureAnalysis). */}
          {analysis.facialAnalysis && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4 flex flex-col gap-3">
              <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide">{t('sessions.stage1.facialAnalysisTitle')}</p>
              <div>
                <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.stage1.facialAnalysisShape')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{analysis.facialAnalysis.shape}</p>
              </div>
              <div>
                <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.stage1.facialAnalysisSymmetry')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{analysis.facialAnalysis.symmetry}</p>
              </div>
              <div>
                <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.stage1.facialAnalysisProportions')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{analysis.facialAnalysis.proportions}</p>
              </div>
            </div>
          )}

          {/* Terços Faciais — leitura específica de cada terço (superior/
              médio/inferior), complementando `facialAnalysis.proportions`
              acima (que só COMPARA os três terços entre si) com um achado
              concreto DENTRO de cada um. Mesmo padrão aditivo/opcional dos
              demais campos: ausente numa análise antiga ou incompleta, a
              seção some inteira em vez de aparecer pela metade. */}
          {analysis.facialThirds && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4 flex flex-col gap-3">
              <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide">{t('sessions.stage1.facialThirdsTitle')}</p>
              <div>
                <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.stage1.facialThirdsUpper')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{analysis.facialThirds.upper}</p>
              </div>
              <div>
                <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.stage1.facialThirdsMiddle')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{analysis.facialThirds.middle}</p>
              </div>
              <div>
                <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.stage1.facialThirdsLower')}</p>
                <p className="text-[13px] text-h-text-2 leading-snug">{analysis.facialThirds.lower}</p>
              </div>
            </div>
          )}

          {/* Textura e Qualidade de Pele — leitura qualitativa (nunca um
              score, ver decisão registrada em src/types/harmonize.ts),
              aditiva/opcional como o restante do bloco de leitura geral. */}
          {analysis.skinTexture && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4">
              <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide mb-1">{t('sessions.stage1.skinTextureTitle')}</p>
              <p className="text-[13px] text-h-text-2 leading-snug">{analysis.skinTexture}</p>
            </div>
          )}

          {/* Pontos de Atenção — achados clínicos gerais que embasam o
              plano; distintos da lista de sugestões de procedimento
              pontuais logo abaixo. */}
          {analysis.attentionPoints && analysis.attentionPoints.length > 0 && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4">
              <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide mb-2">{t('sessions.stage1.attentionPointsTitle')}</p>
              <ul className="flex flex-col gap-1.5">
                {analysis.attentionPoints.map((point, i) => (
                  <li key={i} className="text-[13px] text-h-text-2 leading-snug flex gap-2">
                    <span className="text-h-g-mid flex-shrink-0">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Overall notes */}
          {analysis.overallNotes && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4">
              <p className="text-[11px] font-bold text-h-g-mid uppercase tracking-wide mb-1">{t('sessions.stage1.overallNotes')}</p>
              <p className="text-[13px] text-h-text-2 leading-snug">{analysis.overallNotes}</p>
            </div>
          )}

          {/* Nota de limitação da análise (foto 2D) — aditiva/opcional como
              o resto do bloco; estilo deliberadamente discreto (ícone +
              texto menor, sem o cartão branco das seções acima) por ser uma
              ressalva metodológica, não um achado clínico sobre o
              paciente. */}
          {analysis.analysisLimitations && (
            <div className="flex items-start gap-2 px-1">
              <Info size={13} className="text-h-text-3 flex-shrink-0" style={{ marginTop: 2 }} />
              <p className="text-[11.5px] text-h-text-3 leading-snug italic">{analysis.analysisLimitations}</p>
            </div>
          )}

          {/* Suggestions */}
          <div className="flex items-center gap-2 mt-2">
            <div className="w-[4px] h-[4px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
            <p className="text-[13px] font-semibold text-h-text">{t('sessions.stage1.suggestionsCount', { count: suggestions.length })}</p>
          </div>

          {suggestions.map(s => {
            const decision = decisionOf(s);
            const qty = quantities[s.id] ?? s.quantitySuggested;
            const unit = unitOf(s);
            // Riscos da anamnese cuja região mapeada (ver RISK_REGION_MAP em
            // src/types/anamnesis.ts — heurística sujeita a validação
            // profissional) inclui a região desta sugestão específica.
            // Complementa o banner geral acima; não o substitui.
            const suggestionRisks: SimpleRiskKey[] = risksAffectingRegion(riskFlags, s.region);
            // Aceitar exige ter revisado quantidade/substância primeiro (ver
            // `reviewedSuggestions` acima) — mas só na transição PARA
            // "accepted". Desfazer um aceite (accepted → pending) nunca fica
            // bloqueado, senão o próprio botão de aceite viraria uma
            // armadilha sem saída.
            const reviewed = isReviewed(s);
            const canAccept = decision === 'accepted' || reviewed;
            return (
              <div
                key={s.id}
                className="bg-h-white rounded-r shadow-h-sm p-4 transition-all"
                style={decision === 'accepted' ? {
                  boxShadow: '0 0 0 1.5px #2DB87A, 0 0 0 5px rgba(45,184,122,0.10)',
                } : decision === 'discarded' ? { opacity: 0.5 } : {}}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-[14px] font-bold text-h-text">{s.label || regionLabel(s.region)}</p>
                  {/* O percentual é a autoavaliação do próprio modelo de IA,
                      não uma métrica clínica validada — o ícone/tooltip ao
                      lado existe para evitar viés de automação (o profissional
                      tratar o número como se fosse um score clínico). */}
                  <div className="flex items-center gap-1">
                    <HarmonizeBadge variant={confidenceVariant(s.confidence)}>{s.confidence}%</HarmonizeBadge>
                    {/* TooltipProvider próprio: este card pode ser renderizado
                        fora da árvore do App (ex. em teste), então não
                        depende do provider global em App.tsx. Controlado
                        (open/onOpenChange) em vez do padrão hover/focus do
                        Radix — ver comentário de `openConfidenceDisclaimerId`
                        acima sobre por que toque em touchscreen nunca abriria
                        o modo automático. */}
                    <TooltipProvider>
                      <Tooltip
                        open={openConfidenceDisclaimerId === s.id}
                        onOpenChange={(open) => setOpenConfidenceDisclaimerId(open ? s.id : null)}
                      >
                        <TooltipTrigger asChild>
                          <button
                            type="button"
                            aria-label={t('sessions.stage1.confidenceDisclaimer.iconLabel')}
                            className="text-h-text-3 hover:text-h-text-2 flex-shrink-0"
                            onClick={() =>
                              setOpenConfidenceDisclaimerId((current) => (current === s.id ? null : s.id))
                            }
                          >
                            <Info size={13} />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-[220px] text-[11px] leading-snug">
                          {t('sessions.stage1.confidenceDisclaimer.text')}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>

                {suggestionRisks.length > 0 && (
                  <div
                    className="flex items-start gap-1.5 rounded-r-sm px-2.5 py-2 mb-2"
                    style={{ background: 'rgba(224,80,80,0.08)', border: '1px solid rgba(224,80,80,0.24)' }}
                  >
                    <AlertTriangle size={13} style={{ color: '#E05050', marginTop: 1, flexShrink: 0 }} />
                    <span className="text-[11px] font-semibold leading-snug" style={{ color: '#E05050' }}>
                      {t('sessions.stage1.riskBanner.suggestionWarning', {
                        risks: suggestionRisks.map(k => t(`anamnesis.riskLabels.${k}`)).join(', '),
                      })}
                    </span>
                  </div>
                )}

                {/* Substância editável ANTES do aceite — o profissional pode
                    corrigir a substância sugerida pela IA aqui, na revisão,
                    em vez de só descobrir/ajustar isso depois no Estágio 2
                    (ver comentário em handleProceed). Reaproveita o mesmo
                    SheetSelect usado pela Etapa 2 para região, em vez de um
                    componente novo. */}
                <div className="mb-2">
                  <p className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide mb-1">{t('sessions.stage1.substanceLabel')}</p>
                  <SheetSelect
                    value={substanceOf(s)}
                    onChange={(value) => setSubstance(s, value as Substance)}
                    onOpen={() => markReviewed(s)}
                    title={t('sessions.stage1.substanceLabel')}
                    options={SUBSTANCE_KEYS.map(sub => ({ value: sub, label: SUBSTANCE_LABEL[sub] }))}
                    className={decision === 'discarded' ? 'opacity-40 pointer-events-none' : ''}
                  />
                </div>

                {/* Justificativa clínica em 4 partes: achado observado →
                    objetivo clínico → nota de técnica → selo de hipótese
                    (este último fixo, igual para toda sugestão de IA — não
                    faz parte do dado armazenado, ver JustificationParts em
                    src/types/harmonize.ts). */}
                <div className="flex flex-col gap-1.5 mb-3">
                  <div>
                    <span className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">{t('sessions.stage1.justification.findingLabel')}</span>
                    <p className="text-[12px] text-h-text-2 leading-snug">{s.justification.finding}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">{t('sessions.stage1.justification.clinicalGoalLabel')}</span>
                    <p className="text-[12px] text-h-text-2 leading-snug">{s.justification.clinicalGoal}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">{t('sessions.stage1.justification.technicalNoteLabel')}</span>
                    <p className="text-[12px] text-h-text-2 leading-snug">{s.justification.technicalNote}</p>
                  </div>
                  <p className="text-[10.5px] italic text-h-text-3 leading-snug mt-0.5">{t('sessions.stage1.justification.hypothesisStamp')}</p>
                </div>

                <div className="flex items-center justify-between gap-2">
                  {/* Quantity stepper */}
                  <div className="flex items-center gap-2 bg-h-surface rounded-full px-1 py-1">
                    <button
                      onClick={() => adjustQuantity(s, -1)}
                      disabled={decision === 'discarded'}
                      className="w-7 h-7 rounded-full bg-h-white flex items-center justify-center shadow-h-sm disabled:opacity-40"
                    >
                      <Minus size={13} />
                    </button>
                    <span className="text-[12px] font-bold text-h-text min-w-[64px] text-center">
                      {qty} {unit}
                    </span>
                    <button
                      onClick={() => adjustQuantity(s, 1)}
                      disabled={decision === 'discarded'}
                      className="w-7 h-7 rounded-full bg-h-white flex items-center justify-center shadow-h-sm disabled:opacity-40"
                    >
                      <Plus size={13} />
                    </button>
                  </div>

                  {/* Accept / discard */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setDecision(s, decision === 'discarded' ? 'pending' : 'discarded')}
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{
                        background: decision === 'discarded' ? 'rgba(224,80,80,0.12)' : '#F5F4F2',
                        color: decision === 'discarded' ? '#E05050' : '#AAA8A5',
                      }}
                    >
                      <X size={15} />
                    </button>
                    <button
                      onClick={() => {
                        if (!canAccept) return;
                        setDecision(s, decision === 'accepted' ? 'pending' : 'accepted');
                      }}
                      disabled={!canAccept}
                      title={!canAccept ? t('sessions.stage1.reviewRequiredHint') : undefined}
                      aria-label={t('sessions.stage1.acceptSuggestion')}
                      className="w-8 h-8 rounded-full flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed"
                      style={{
                        background: decision === 'accepted' ? 'rgba(45,184,122,0.12)' : '#F5F4F2',
                        color: decision === 'accepted' ? '#2DB87A' : '#AAA8A5',
                      }}
                    >
                      <Check size={15} />
                    </button>
                  </div>
                </div>

                {/* Exige ao menos um toque no seletor de substância ou no
                    stepper de quantidade antes de liberar "Aceitar" — item
                    P1 do backlog: sem isso, um único toque aceitava a
                    sugestão da IA sem o profissional nunca ter olhado esses
                    valores (risco de segurança clínica). Some assim que a
                    revisão acontece; nunca reaparece depois. */}
                {!reviewed && (
                  <p className="text-[10.5px] text-h-text-3 leading-snug mt-2 text-right">
                    {t('sessions.stage1.reviewRequiredHint')}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom action */}
      <div className="fixed bottom-0 left-0 right-0 p-5 bg-h-bg" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
        <div className="max-w-[430px] md:max-w-[560px] mx-auto">
          <GradientButton
            onClick={handleProceed}
            disabled={acceptedCount === 0 || saving || (riskLabels.length > 0 && !riskAcknowledged)}
          >
            {acceptedCount > 0 ? t('sessions.stage1.planPoints', { count: acceptedCount }) : t('sessions.stage1.acceptAtLeastOne')}
          </GradientButton>
        </div>
      </div>
    </div>
    </PageTransition>
  );
};

export default SessaoEstagio1;
