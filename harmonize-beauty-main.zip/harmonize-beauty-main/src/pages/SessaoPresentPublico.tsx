import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Info, ShieldCheck } from 'lucide-react';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import BeforeAfterSlider from '@/components/harmonize/BeforeAfterSlider';
import { SUBSTANCE_LABEL, type Substance } from '@/types/harmonize';
import { isValidPresentToken } from '@/lib/presentLink';
import { extractPatientExplanation, formatPatientExplanation } from '@/lib/patientJustification';
import AnalysisProvenanceBanner from '@/components/harmonize/AnalysisProvenanceBanner';
import type { AnalysisProvenance } from '@/lib/analysisProvenance';
import { buildReactivationWhatsAppLink } from '@/lib/patientReactivation';

// Página pública (fora do ProtectedRoute — ver rota /present/:token em
// App.tsx). O paciente nunca é um usuário autenticado do Supabase: a
// "sessão" dele é só o token na URL, validado pela edge function pública
// `public-session-presentation` (supabase/functions/public-session-presentation/index.ts),
// que usa a service role key — por isso a leitura aqui passa por fetch
// simples para essa função, nunca pelo client `supabase` autenticado. Mesmo
// padrão de AnamneseCompartilhada.tsx.
const FUNCTIONS_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/public-session-presentation`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

type PageState = 'loading' | 'ready' | 'not_found' | 'revoked' | 'no_simulation' | 'error';

interface OverlayPointPublic {
  label: string;
  substance: string;
  quantity: number;
  unit: string;
  // Presentes só quando o ponto veio de uma sugestão de IA aceita na Etapa 1
  // — ver public-session-presentation/index.ts (sanitizeOverlay) e
  // extractPatientExplanation. technicalNote nunca é exposto aqui de
  // propósito: é jargão de técnica de aplicação, não linguagem de paciente.
  finding?: string;
  clinicalGoal?: string;
}

interface PresentationData {
  patientName: string | null;
  clinicName: string | null;
  logoUrl: string | null;
  // Nome do profissional responsável e seu registro (CRM/CRO/CRBM/etc — já
  // formatado "TIPO NÚMERO" pela edge function, ver
  // formatProfessionalRegistration em public-session-presentation/index.ts).
  // professionalRegistration só vem preenchido quando tipo e número foram
  // os dois cadastrados no Perfil; caso contrário é null e a linha some.
  professionalName: string | null;
  professionalRegistration: string | null;
  // Telefone da CLÍNICA/profissional (não do paciente) — ver comentário em
  // public-session-presentation/index.ts. Alimenta só o botão "Falar com o
  // profissional" abaixo; `null`/ausente (payload de uma versão anterior da
  // edge function) esconde o botão em vez de abrir um link `wa.me` quebrado.
  professionalPhone?: string | null;
  procedureName: string | null;
  intensity: string | null;
  beforeUrl: string | null;
  afterUrl: string | null;
  overlay: OverlayPointPublic[];
  // Origem da análise da Etapa 1 que deu origem ao plano apresentado — só o
  // rótulo, nunca o conteúdo (ver public-session-presentation/index.ts). Um
  // payload antigo/de uma versão anterior da function não traz o campo: aí a
  // normalização abaixo trata como 'unknown', nunca como 'ai'.
  analysisProvenance?: AnalysisProvenance;
}

const StatusScreen: React.FC<{ title: string; body: string }> = ({ title, body }) => (
  <div className="min-h-screen bg-h-white flex flex-col items-center justify-center px-8 text-center gap-3">
    <LogoMark size={48} />
    <p className="text-[15px] font-bold text-h-text">{title}</p>
    <p className="text-[13px] text-h-text-2">{body}</p>
  </div>
);

const SessaoPresentPublico: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const { t } = useTranslation();
  const [data, setData] = useState<PresentationData | null>(null);
  const [state, setState] = useState<PageState>('loading');

  useEffect(() => {
    if (!isValidPresentToken(token)) {
      setState('not_found');
      return;
    }
    let active = true;
    (async () => {
      try {
        const res = await fetch(`${FUNCTIONS_URL}?token=${encodeURIComponent(token)}`, {
          headers: { apikey: ANON_KEY, Authorization: `Bearer ${ANON_KEY}` },
        });
        const body = await res.json();
        if (!active) return;
        if (body?.valid) {
          setData(body as PresentationData);
          setState('ready');
        } else {
          setState((body?.reason as PageState) ?? 'not_found');
        }
      } catch {
        if (active) setState('error');
      }
    })();
    return () => {
      active = false;
    };
  }, [token]);

  if (state === 'loading') {
    return (
      <div className="min-h-screen bg-h-white flex items-center justify-center">
        <div className="animate-pulse"><LogoMark size={48} /></div>
      </div>
    );
  }

  if (state === 'not_found' || state === 'error') {
    return (
      <StatusScreen title={t('sessions.presentPublic.invalidTitle')} body={t('sessions.presentPublic.invalidBody')} />
    );
  }
  if (state === 'revoked') {
    return (
      <StatusScreen title={t('sessions.presentPublic.revokedTitle')} body={t('sessions.presentPublic.revokedBody')} />
    );
  }
  if (state === 'no_simulation') {
    return (
      <StatusScreen
        title={t('sessions.presentPublic.noSimulationTitle')}
        body={t('sessions.presentPublic.noSimulationBody')}
      />
    );
  }

  const procedureName = data?.procedureName || t('sessions.present.defaultProcedure');
  const intensity = data?.intensity
    ? t(`sessions.stage3.intensity.${data.intensity}`, { defaultValue: t('sessions.present.defaultIntensity') })
    : t('sessions.present.defaultIntensity');
  const patientName = data?.patientName || t('sessions.present.defaultPatient');

  // Botão "Falar com o profissional" — achado do QA Contínuo: antes abria
  // `wa.me/` sem número nenhum (link morto). `professionalPhone` vem do
  // servidor (ver public-session-presentation/index.ts) só quando cadastrado
  // no Perfil — sem ele, `handleContactProfessional` nunca é acionado porque
  // o botão nem é desenhado (ver JSX abaixo), então não precisa lidar com
  // telefone ausente aqui dentro. Reaproveita `buildReactivationWhatsAppLink`
  // (src/lib/patientReactivation.ts) — mesma normalização de dígitos/DDI já
  // usada pelo resto do app pra montar um link `wa.me` — em vez de duplicar
  // a lógica.
  const handleContactProfessional = () => {
    if (!data?.professionalPhone) return;
    const message = t('sessions.presentPublic.contactProfessionalMessage', { name: patientName });
    window.open(buildReactivationWhatsAppLink(data.professionalPhone, message), '_blank');
  };
  // Qualquer valor que não seja exatamente 'ai' ou 'mock' (inclusive o campo
  // ausente, vindo de uma versão anterior da edge function) vira 'unknown' —
  // mesma regra de src/lib/analysisProvenance.ts: errar para o lado do aviso,
  // nunca para o lado do silêncio.
  const analysisProv: AnalysisProvenance =
    data?.analysisProvenance === 'ai' || data?.analysisProvenance === 'mock'
      ? data.analysisProvenance
      : 'unknown';
  const overlay = data?.overlay ?? [];
  // Mesmo padrão de SessaoPresent.tsx (tela do profissional): cada item
  // ganha uma explicação clínica curta em linguagem de paciente quando o
  // payload público traz finding/clinicalGoal (ver OverlayPointPublic).
  const highlights: { key: string; text: string; explanation?: string }[] = overlay.length > 0
    ? overlay.map((point, index) => {
        const explanation = extractPatientExplanation(
          point.finding || point.clinicalGoal ? { finding: point.finding, clinicalGoal: point.clinicalGoal } : null,
        );
        return {
          key: `${point.label}-${index}`,
          text: t('sessions.present.highlightItem', {
            label: point.label,
            quantity: point.quantity,
            unit: point.unit,
            substance: SUBSTANCE_LABEL[point.substance as Substance] ?? point.substance,
          }),
          explanation: explanation
            ? formatPatientExplanation(explanation, (finding, clinicalGoal) =>
                t('sessions.present.highlightExplanation', { finding, clinicalGoal }),
              )
            : undefined,
        };
      })
    : (t('sessions.present.highlights', { returnObjects: true }) as string[]).map((text, index) => ({
        key: `${index}-${text}`,
        text,
      }));

  return (
    <PageTransition>
      <div className="min-h-screen bg-h-white flex flex-col">
        <div className="max-w-[430px] mx-auto w-full flex flex-col flex-1 px-5 pt-5 pb-6">
          {/* Header — sem botão de saída: não há área autenticada pra
              onde voltar, diferente de SessaoPresent.tsx (profissional). */}
          <div className="flex items-center gap-2">
            <LogoMark size={28} />
            <span className="text-[14px] font-bold text-h-text-2">
              {data?.clinicName || 'FacialPlan'}
            </span>
          </div>

          {/* Profissional responsável — mesma exibição condicional de
              SessaoPresent.tsx (tela do profissional), mas os dois campos já
              vêm prontos do edge function. */}
          {data?.professionalName && (
            <p className="text-[11px] text-h-text-3 mt-0.5">
              {data.professionalRegistration
                ? t('sessions.present.responsibleProfessionalWithRegistration', {
                    name: data.professionalName,
                    registration: data.professionalRegistration,
                  })
                : t('sessions.present.responsibleProfessional', { name: data.professionalName })}
            </p>
          )}

          {/* Divider */}
          <div className="my-3" style={{ borderBottom: '1px solid #E5E3E0' }} />

          {/* Proveniência da análise — mesmo carimbo (versão paciente) da
              tela autenticada SessaoPresent.tsx. Acima do antes/depois de
              propósito: se o plano nasceu de uma análise de demonstração, o
              paciente precisa saber antes de olhar o resultado simulado. */}
          {analysisProv !== 'ai' && (
            <div className="mb-4">
              <AnalysisProvenanceBanner provenance={analysisProv} audience="patient" />
            </div>
          )}

          {/* Session info */}
          <div className="text-center mb-4">
            <p className="text-[13px] text-h-text-2">{patientName}</p>
            <h2 className="text-[20px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>
              {t('sessions.present.resultTitle')}
            </h2>
          </div>

          {/* Before/After */}
          <div className="-mx-5 mb-4 overflow-hidden" style={{ height: 280 }}>
            <div className="h-full">
              <BeforeAfterSlider beforeImageUrl={data?.beforeUrl ?? undefined} afterImageUrl={data?.afterUrl ?? undefined} />
            </div>
          </div>

          {/* Info cards */}
          <div className="grid grid-cols-2 gap-[10px] mb-4">
            <div className="bg-h-white rounded-[14px] shadow-h-sm p-3">
              <p style={{ fontSize: 11, fontWeight: 600, color: '#AAA8A5', marginBottom: 4 }}>{t('sessions.present.procedure')}</p>
              <p className="text-[14px] font-bold text-h-text mt-1">{procedureName}</p>
            </div>
            <div className="bg-h-white rounded-[14px] shadow-h-sm p-3">
              <p style={{ fontSize: 11, fontWeight: 600, color: '#AAA8A5', marginBottom: 4 }}>{t('sessions.present.intensity')}</p>
              <p className="text-[14px] font-bold mt-1" style={{ color: '#A855B5' }}>{intensity}</p>
            </div>
          </div>

          {/* What will be done */}
          <div className="bg-h-white rounded-[14px] shadow-h-sm p-4 mb-4">
            <p style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5', marginBottom: 12 }}>{t('sessions.present.whatWillBeDone')}</p>
            <div className="flex flex-col gap-3">
              {highlights.map((item) => (
                <div key={item.key} className="flex items-start gap-2.5">
                  <div className="w-[6px] h-[6px] rounded-full flex-shrink-0 mt-[7px]" style={{ background: '#BF5F82' }} />
                  <div>
                    <p className="text-[13px] text-h-text-2">{item.text}</p>
                    {item.explanation && (
                      <p className="text-[11.5px] text-h-text-3 leading-snug mt-0.5">{item.explanation}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Disclaimer — mesmo bloco/força visual da tela do profissional. */}
          <div
            className="rounded-r p-4 mb-4"
            style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
          >
            <div className="flex items-center gap-2 mb-1.5">
              <Info size={16} className="flex-shrink-0" style={{ color: '#D4900A' }} />
              <p className="text-[13px] font-bold" style={{ color: '#D4900A' }}>
                {t('sessions.present.disclaimerTitle')}
              </p>
            </div>
            <p className="text-[12px] text-h-text-2 leading-relaxed">
              {t('sessions.present.disclaimer')}
            </p>
          </div>

          {/* Frase de confiança do guardrail anatômico (backlog P2) — mesmo
              bloco da tela do profissional (SessaoPresent.tsx); só exibida
              porque o prompt enviado à Gemini em generate-simulation de fato
              instrui limites anatômicos plausíveis (ver
              ANATOMICAL_SAFETY_INSTRUCTION em generate-simulation/index.ts). */}
          <div className="flex items-center justify-center gap-1.5 mb-4">
            <ShieldCheck size={13} className="flex-shrink-0" style={{ color: '#1A9E5C' }} />
            <p className="text-[11px] font-semibold text-h-text-2 text-center">
              {t('sessions.present.anatomicalGuardrail')}
            </p>
          </div>

          {/* Aviso de proteção de dados — deixa explícito ao paciente que
              este link mostra só a simulação dele, sem citar uma lei
              específica de um único país (app roda em 5 mercados). */}
          <p className="text-[10px] text-h-text-3 text-center mb-4 leading-relaxed">
            {t('sessions.presentPublic.dataProtectionNotice')}
          </p>

          {/* Sem telefone cadastrado no Perfil, o botão simplesmente não
              aparece — nunca um link `wa.me` quebrado (achado do QA
              Contínuo, ver handleContactProfessional acima). */}
          <div className="mt-auto">
            {data?.professionalPhone ? (
              <GradientButton onClick={handleContactProfessional} className="w-full">
                {t('sessions.presentPublic.contactProfessional')}
              </GradientButton>
            ) : (
              <p className="text-[12px] text-h-text-3 text-center leading-relaxed">
                {t('sessions.presentPublic.contactProfessionalUnavailable')}
              </p>
            )}
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default SessaoPresentPublico;
