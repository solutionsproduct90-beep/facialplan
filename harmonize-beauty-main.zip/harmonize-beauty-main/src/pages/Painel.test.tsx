import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Painel from "./Painel";
import i18n from "@/i18n";
import { createRangeSlicer } from "@/test/supabaseMock";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const updateSpy = vi.fn();
// get_professional_conversion_benchmark (ver src/lib/panel.ts,
// getConversionBenchmarkBucket): por padrão devolve zero linhas (nenhum
// bucket), mesmo estado "sem dado suficiente" que a RPC real devolve — cada
// teste do card sobrescreve com mockResolvedValueOnce/mockImplementation
// quando quiser um bucket específico ou um erro.
const rpcMock = vi.fn().mockResolvedValue({ data: [], error: null });

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

vi.mock("sonner", () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}));

/** Builder pra `profiles`: .select().eq().single() e .update().eq(). */
function createProfileBuilder(row: Record<string, unknown>) {
  return {
    select: () => ({
      eq: () => ({
        single: () => Promise.resolve({ data: row, error: null }),
      }),
    }),
    update: (payload: Record<string, unknown>) => {
      updateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
}

/** Builder pra `insumos`/`sessions`/`appointments`/`patients`: .select().eq()[.gte()/.order()] thenable. */
function createListBuilder(rows: unknown[]) {
  const pagina = createRangeSlicer();
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    gte: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve({ data: pagina.apply(rows), error: null }).then(onFulfilled),
  };
  return builder;
}

const renderPage = () =>
  render(
    <QueryClientProvider client={new QueryClient()}>
      <MemoryRouter initialEntries={["/painel"]}>
        <Routes>
          <Route path="/painel" element={<Painel />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>
  );

describe("Painel", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" } });
    fromMock.mockReset();
    updateSpy.mockReset();
    rpcMock.mockReset();
    rpcMock.mockResolvedValue({ data: [], error: null });
  });

  it("hides ROI values by default and reveals them only after an explicit click — privacy-by-default", async () => {
    const now = new Date();
    const sessionCreatedAt = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: 150,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") {
        return createListBuilder([
          { id: "ins-1", substance: "acido_hialuronico", brand_name: "Juvederm Voluma", cost_per_unit: 400, price_per_unit: 1500, active: true },
        ]);
      }
      if (table === "sessions") {
        return createListBuilder([
          {
            created_at: sessionCreatedAt,
            stage2_overlay: [
              { id: "p1", region: "malar_direita", label: "Malar Direita", substance: "acido_hialuronico", quantity: 1, unit: "ml", x: 0.5, y: 0.5, source: "manual", insumoId: "ins-1" },
            ],
          },
        ]);
      }
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    // Estado inicial: valores mascarados, nunca o número real.
    expect(await screen.findAllByText("•••••")).toHaveLength(2);
    expect(screen.queryByText("R$ 1.500,00")).not.toBeInTheDocument();
    expect(screen.getByText("Mostrar valores")).toBeInTheDocument();

    fireEvent.click(screen.getByText("Mostrar valores"));

    // Depois do clique: potencial do mês (R$ 1.500,00) e mensalidade (R$ 150,00) visíveis,
    // e o múltiplo do ROI (1500 / 150 = 10x) no destaque verde.
    await waitFor(() => expect(screen.getByText("R$ 1.500,00")).toBeInTheDocument());
    expect(screen.getByText("R$ 150,00")).toBeInTheDocument();
    expect(screen.getByText("Já pagou 10x a assinatura este mês")).toBeInTheDocument();
    expect(screen.getByText("Ocultar valores")).toBeInTheDocument();
    expect(screen.queryByText("•••••")).not.toBeInTheDocument();
  });

  it("prompts to configure the subscription value and the goal when neither is set yet, without inventing numbers", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    expect(await screen.findByText("Configure quanto você paga de mensalidade para ver o retorno da assinatura.")).toBeInTheDocument();
    expect(screen.getByText("Defina quantas sessões você quer fazer por semana ou por mês.")).toBeInTheDocument();
    // Nenhum paciente com sessões cadastradas: Radar de Retorno sem nada
    // pendente, mensagem de estado vazio (nunca 0/0 inventado sem contexto).
    expect(screen.getByText("Nenhum retorno previsto ou atrasado no momento.")).toBeInTheDocument();
    // Sem sessões nos últimos 90 dias: sequência zerada, com mensagem de incentivo (não de bloqueio).
    expect(screen.getByText("Comece hoje sua sequência de dias ativos.")).toBeInTheDocument();
    // Sem feedback de paciente ainda (Central de Depoimentos/NPS): mensagem
    // de estado vazio, nunca uma média inventada (ex. 0.0).
    expect(screen.getByText("Ainda sem avaliações de pacientes.")).toBeInTheDocument();
    // Sem avaliações de precisão da simulação ainda: mesmo cuidado, mensagem
    // de estado vazio, nunca uma média/percentual inventados.
    expect(screen.getByText("Ainda sem sessões avaliadas.")).toBeInTheDocument();
  });

  it("shows the recent NPS average and response count from patient_feedback", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") {
        return createListBuilder([{ nps_score: 10 }, { nps_score: 9 }, { nps_score: 8 }]);
      }
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    expect(await screen.findByText("Nota média: 9.0")).toBeInTheDocument();
    expect(screen.getByText("3 avaliações nos últimos 90 dias")).toBeInTheDocument();
  });

  it("shows the simulation accuracy average and good-match percentage from the professional's own ratings", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") {
        return createListBuilder([{ rating: 5 }, { rating: 4 }, { rating: 3 }, { rating: 2 }]);
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    // Média 3.5 (5+4+3+2 ÷ 4) e 50% de "correspondeu bem" (2 de 4 notas ≥ 4)
    // — só o que a autoavaliação do profissional já digitou, nunca um
    // recálculo automático de IA.
    expect(await screen.findByText("Nota média: 3.5 de 5")).toBeInTheDocument();
    expect(screen.getByText("Sua simulação correspondeu bem ao resultado real em 50% das sessões avaliadas")).toBeInTheDocument();
    expect(screen.getByText("4 sessões avaliadas nos últimos 90 dias")).toBeInTheDocument();
    expect(screen.getByText("Autoavaliação sua, feita sessão a sessão — não é uma métrica automatizada de IA.")).toBeInTheDocument();
  });

  it("saves the subscription value the professional types", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    fireEvent.click(await screen.findByText("Configurar mensalidade"));
    fireEvent.change(screen.getByLabelText("Valor da mensalidade"), { target: { value: "150" } });
    fireEvent.click(screen.getByText("Salvar"));

    await waitFor(() => expect(updateSpy).toHaveBeenCalledWith({ subscription_monthly_value: 150 }));
  });

  it('shows the overview (ROI/goal/streak) tab selected by default, as a pill tab alongside Agenda and Estoque', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    await screen.findByText("Configurar mensalidade");
    expect(screen.getByTestId("panel-tab-overview")).toHaveAttribute("aria-selected", "true");
    expect(screen.getByTestId("panel-tab-agenda")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByTestId("panel-tab-stock")).toHaveAttribute("aria-selected", "false");
    expect(screen.getByTestId("panel-tab-billing")).toHaveAttribute("aria-selected", "false");
  });

  it('switches to the Agenda tab and mounts it in place of the ROI/goal/streak cards', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "appointments") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "appointment_waitlist") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    await screen.findByText("Configurar mensalidade");

    fireEvent.click(screen.getByTestId("panel-tab-agenda"));

    expect(screen.getByTestId("panel-tab-agenda")).toHaveAttribute("aria-selected", "true");
    expect(screen.queryByText("Configurar mensalidade")).not.toBeInTheDocument();
    expect(await screen.findByText("Nenhum compromisso agendado ainda.")).toBeInTheDocument();
  });

  it('switches to the Estoque tab and mounts it in place of the ROI/goal/streak cards', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    await screen.findByText("Configurar mensalidade");

    fireEvent.click(screen.getByTestId("panel-tab-stock"));

    expect(screen.getByTestId("panel-tab-stock")).toHaveAttribute("aria-selected", "true");
    expect(screen.queryByText("Configurar mensalidade")).not.toBeInTheDocument();
    expect(await screen.findByText("Nenhum insumo cadastrado ainda.")).toBeInTheDocument();
  });

  it('switches to the Faturamento tab and mounts it in place of the ROI/goal/streak cards', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") return createListBuilder([]);
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    await screen.findByText("Configurar mensalidade");

    fireEvent.click(screen.getByTestId("panel-tab-billing"));

    expect(screen.getByTestId("panel-tab-billing")).toHaveAttribute("aria-selected", "true");
    expect(screen.queryByText("Configurar mensalidade")).not.toBeInTheDocument();
    expect(await screen.findByText("Nenhuma sessão concluída este mês ainda.")).toBeInTheDocument();
  });

  it("shows the Return Radar alert card counting patients due this week separately from overdue ones", async () => {
    const now = new Date();
    const monthsAgo = (n: number) => {
      const d = new Date(now);
      d.setMonth(d.getMonth() - n);
      return d.toISOString();
    };
    const daysAgo = (n: number) => {
      const d = new Date(now);
      d.setDate(d.getDate() - n);
      return d.toISOString();
    };
    const completedSession = (createdAt: string, substance: string) => ({
      status: "complete",
      created_at: createdAt,
      stage2_overlay: [{ id: "p1", region: "malar_direita", label: "x", substance, quantity: 1, unit: "ml", x: 0.5, y: 0.5, source: "manual" }],
    });

    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfileBuilder({
          labor_fee_per_session: null,
          subscription_monthly_value: null,
          session_goal_target: null,
          session_goal_period: "weekly",
        });
      }
      if (table === "insumos") return createListBuilder([]);
      if (table === "sessions") return createListBuilder([]);
      if (table === "patients") {
        return createListBuilder([
          // Previsto para esta semana: toxina botulínica aplicada há 4 meses
          // — janela (4-6 meses) já abriu.
          { sessions: [completedSession(monthsAgo(4), "toxina_botulinica")] },
          // Atrasado: ácido hialurônico aplicado há 20 meses — já passou do
          // fim da janela (9-18 meses).
          { sessions: [completedSession(monthsAgo(20), "acido_hialuronico")] },
          // Nem um nem outro: bioestimulador aplicado há 5 dias — janela
          // (12-24 meses) só abre daqui a quase 1 ano.
          { sessions: [completedSession(daysAgo(5), "bioestimulador")] },
        ]);
      }
      if (table === "patient_feedback") return createListBuilder([]);
      if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    const dueLabel = await screen.findByText("Previstos para esta semana");
    expect(dueLabel.previousElementSibling?.textContent).toBe("1");

    const overdueLabel = screen.getByText("Retornos atrasados");
    expect(overdueLabel.previousElementSibling?.textContent).toBe("1");

    expect(screen.queryByText("Nenhum retorno previsto ou atrasado no momento.")).not.toBeInTheDocument();
  });

  describe("conversion benchmark card (get_professional_conversion_benchmark)", () => {
    const mockBaseTables = () => {
      fromMock.mockImplementation((table: string) => {
        if (table === "profiles") {
          return createProfileBuilder({
            labor_fee_per_session: null,
            subscription_monthly_value: null,
            session_goal_target: null,
            session_goal_period: "weekly",
          });
        }
        if (table === "insumos") return createListBuilder([]);
        if (table === "sessions") return createListBuilder([]);
        if (table === "patients") return createListBuilder([]);
        if (table === "patient_feedback") return createListBuilder([]);
        if (table === "session_simulation_accuracy_ratings") return createListBuilder([]);
        throw new Error(`unexpected table ${table}`);
      });
    };

    it("shows the top-third message when the RPC returns that bucket, without naming any other professional", async () => {
      mockBaseTables();
      rpcMock.mockResolvedValue({ data: [{ conversion_bucket: "top_third" }], error: null });

      renderPage();

      expect(
        await screen.findByText(
          "Sua taxa de conversão sessão → procedimento está no terço superior entre profissionais da mesma especialidade."
        )
      ).toBeInTheDocument();
      expect(screen.getByText("Comparativo de conversão")).toBeInTheDocument();
      expect(rpcMock).toHaveBeenCalledWith("get_professional_conversion_benchmark");
    });

    it("renders no benchmark section when the RPC returns zero rows (comparison group too small)", async () => {
      mockBaseTables();
      rpcMock.mockResolvedValue({ data: [], error: null });

      renderPage();

      // Espera a tela terminar de carregar (outro card qualquer já visível)
      // antes de afirmar a ausência — evita falso positivo por render incompleto.
      await screen.findByText("Configurar mensalidade");
      expect(screen.queryByText("Comparativo de conversão")).not.toBeInTheDocument();
    });

    it("swallows an RPC error without breaking the rest of the panel", async () => {
      mockBaseTables();
      rpcMock.mockResolvedValue({ data: null, error: new Error("boom") });

      renderPage();

      await screen.findByText("Configurar mensalidade");
      expect(screen.getByText("Defina quantas sessões você quer fazer por semana ou por mês.")).toBeInTheDocument();
      expect(screen.queryByText("Comparativo de conversão")).not.toBeInTheDocument();
    });
  });
});
