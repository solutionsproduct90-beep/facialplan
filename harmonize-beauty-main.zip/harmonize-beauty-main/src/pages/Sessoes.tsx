import React, { useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import SessionCard from '@/components/harmonize/SessionCard';
import GradientButton from '@/components/harmonize/GradientButton';
import GhostButton from '@/components/harmonize/GhostButton';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { Plus, Camera, Layers } from 'lucide-react';

const Sessoes: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [tab, setTab] = useState<'active' | 'done'>('active');

  const { data: activeSessions, isLoading: loadingActive } = useQuery({
    queryKey: ['all-sessions-active', user?.id],
    queryFn: () =>
      // Paginado (src/lib/fetchAllRows.ts): o teto de linhas por resposta do
      // PostgREST (Max Rows, 1000 por padrão) é aplicado em silêncio, e esta
      // lista não tem corte por data — sessões sumiriam da tela sem aviso.
      fetchAllRows((from, to) =>
        supabase
          .from('sessions')
          .select('*, patients!inner(name)')
          .eq('professional_id', user!.id)
          .not('status', 'in', '("complete","abandoned")')
          .order('last_active_at', { ascending: false })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const { data: doneSessions, isLoading: loadingDone } = useQuery({
    queryKey: ['all-sessions-done', user?.id],
    queryFn: () =>
      // Idem: o histórico de concluídas só cresce, então é a aba que alcança
      // o teto primeiro.
      fetchAllRows((from, to) =>
        supabase
          .from('sessions')
          .select('*, patients!inner(name)')
          .eq('professional_id', user!.id)
          .eq('status', 'complete')
          .order('created_at', { ascending: false })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const displayed = tab === 'active' ? activeSessions : doneSessions;
  const isLoading = tab === 'active' ? loadingActive : loadingDone;

    return (
    <PageTransition>
    <AppLayout
      title={t('nav.sessions')}
      rightAction={
        // BUG CORRIGIDO: era um ícone "+" em link de texto rosa
        // (`text-h-g-start`), sem fundo, quase invisível no header — mesmo
        // padrão já corrigido em HeaderSaveButton (Perfil).
        <GhostButton
          onClick={() => navigate('/sessoes/nova')}
          className="!w-auto !h-auto !min-h-[44px] !min-w-[44px] px-2.5 py-2 flex items-center justify-center"
        >
          <Plus size={18} />
        </GhostButton>
      }
    >
      <div className="flex flex-col gap-4">
        {/* iOS Segmented Control */}
        <div style={{ display: 'flex', gap: 2, padding: 3, borderRadius: 10, background: 'rgba(0,0,0,0.06)' }}>
          {(['active', 'done'] as const).map((tabKey) => (
            <button
              key={tabKey}
              onClick={() => setTab(tabKey)}
              style={{
                flex: 1,
                height: 34,
                borderRadius: 8,
                fontSize: 13,
                fontWeight: 600,
                fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif",
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                background: tab === tabKey ? '#FFFFFF' : 'transparent',
                color: tab === tabKey ? '#1A1918' : '#AAA8A5',
                boxShadow: tab === tabKey ? '0 1px 4px rgba(0,0,0,0.10)' : 'none',
              }}
            >
              {tabKey === 'active'
                ? `${t('sessions.list.tabs.active')}${activeSessions?.length ? ` (${activeSessions.length})` : ''}`
                : `${t('sessions.list.tabs.done')}${doneSessions?.length ? ` (${doneSessions.length})` : ''}`
              }
            </button>
          ))}
        </div>

        {/* Sessions */}
        {isLoading ? (
          <div className="flex flex-col gap-2">
            {[1, 2, 3].map(i => <SkeletonCard key={i} />)}
          </div>
        ) : displayed && displayed.length > 0 ? (
          <div className="bg-h-white rounded-[16px] shadow-h-sm overflow-hidden">
            {displayed.map((s: any, index: number) => (
              <React.Fragment key={s.id}>
                <SessionCard
                  id={s.id}
                  patientName={s.patients?.name ?? t('home.defaultPatientName')}
                  status={s.status}
                  createdAt={s.created_at}
                  selectedProcedure={s.selected_procedure}
                  grouped={true}
                />
                {index < displayed.length - 1 && (
                  <div style={{ height: 0.5, background: '#E5E3E0', marginLeft: 62 }} />
                )}
              </React.Fragment>
            ))}
          </div>
        ) : (
          <div className="rounded-[14px] py-8 flex flex-col items-center text-center" style={{ background: 'rgba(168,85,181,0.04)' }}>
            <Layers size={22} style={{ color: '#AAA8A5' }} />
            <p style={{ fontSize: 13, fontWeight: 600, color: '#AAA8A5', marginTop: 8 }}>{t('sessions.list.empty')}</p>
          </div>
        )}

        <GradientButton onClick={() => navigate('/sessoes/nova')}>
          <span className="flex items-center justify-center gap-2">
            <Camera size={18} />
            {t('sessions.list.newSession')}
          </span>
        </GradientButton>
      </div>
    </AppLayout>
    </PageTransition>
  );
};

export default Sessoes;
