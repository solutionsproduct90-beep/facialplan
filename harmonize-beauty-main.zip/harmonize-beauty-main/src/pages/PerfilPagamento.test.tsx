import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import PerfilPagamento from "./PerfilPagamento";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const upsertSpy = vi.fn();
const toastSuccessMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

const CONFIG = { labor_fee_per_session: 50, max_installments: 12, cash_discount_pct: 5 };

function createProfilesBuilder(
  getResponse: { data: unknown; error: unknown },
  upsertResponse: { data: unknown; error: unknown }
) {
  let mode: "select" | "upsert" = "select";
  const builder = {
    select: () => builder,
    eq: () => builder,
    upsert: (payload: unknown, opts: unknown) => {
      mode = "upsert";
      upsertSpy(payload, opts);
      return builder;
    },
    single: () => Promise.resolve(mode === "upsert" ? upsertResponse : getResponse),
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/perfil/pagamento"]}>
      <Routes>
        <Route path="/perfil/pagamento" element={<PerfilPagamento />} />
      </Routes>
    </MemoryRouter>
  );

describe("PerfilPagamento", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" } });
    fromMock.mockReset();
    navigateMock.mockReset();
    upsertSpy.mockReset();
    toastSuccessMock.mockReset();
    toastErrorMock.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: CONFIG, error: null },
          { data: { id: "pro-1" }, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });
  });

  it("loads the saved labor fee, installments and cash discount", async () => {
    renderPage();
    expect(await screen.findByDisplayValue("50")).toBeInTheDocument();
    expect(screen.getByDisplayValue("12")).toBeInTheDocument();
    expect(screen.getByDisplayValue("5")).toBeInTheDocument();
  });

  it("keeps a labor fee of exactly 0 visible instead of blanking it out", async () => {
    // Regressão do bug `laborFeePerSession || ''`: um valor 0 (falsy) sumia
    // do campo mesmo estando de fato salvo. O componente agora usa `??`.
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: { ...CONFIG, labor_fee_per_session: 0 }, error: null },
          { data: { id: "pro-1" }, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    expect(await screen.findByDisplayValue("0")).toBeInTheDocument();
  });

  it("shows an error toast instead of silently blanking the form when the fetch fails", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: null, error: { message: "boom" } },
          { data: null, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith("Não foi possível carregar seu perfil. Tente novamente.")
    );
  });

  it("upserts payment config on save and confirms a row actually came back", async () => {
    renderPage();
    await screen.findByDisplayValue("50");

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
    const [payload, opts] = upsertSpy.mock.calls[0];
    expect(payload).toEqual({ id: "pro-1", labor_fee_per_session: 50, max_installments: 12, cash_discount_pct: 5, currency: "BRL" });
    expect(opts).toEqual({ onConflict: "id" });

    await waitFor(() => expect(toastSuccessMock).toHaveBeenCalledWith("Perfil salvo!"));
  });

  it("surfaces a save error instead of a false 'saved' toast when the write reports no affected row", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "profiles") {
        return createProfilesBuilder(
          { data: CONFIG, error: null },
          { data: null, error: null }
        );
      }
      throw new Error(`unexpected table ${table}`);
    });

    renderPage();
    await screen.findByDisplayValue("50");

    fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

    await waitFor(() => expect(toastErrorMock).toHaveBeenCalledWith("Erro ao salvar"));
    expect(toastSuccessMock).not.toHaveBeenCalled();
  });

  // Achado de QA: os campos não vivem dentro de um <form>, então o
  // min/max do HTML5 nunca é checado — só dispara em submit. handleSave
  // precisa validar a faixa ele mesmo antes de gravar.
  describe("range validation (QA finding: no <form>, HTML5 min/max never fires)", () => {
    it("blocks saving an out-of-range installment count (> 24) with a clear error, without writing anything", async () => {
      renderPage();
      await screen.findByDisplayValue("50");

      fireEvent.change(screen.getByPlaceholderText("Ex: 12"), { target: { value: "999" } });
      fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

      await waitFor(() =>
        expect(toastErrorMock).toHaveBeenCalledWith("O máximo de parcelas deve ser um número inteiro entre 1 e 24")
      );
      expect(upsertSpy).not.toHaveBeenCalled();
    });

    it("blocks saving a cash discount above 100%", async () => {
      renderPage();
      await screen.findByDisplayValue("50");

      fireEvent.change(screen.getByPlaceholderText("0%"), { target: { value: "250" } });
      fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

      await waitFor(() =>
        expect(toastErrorMock).toHaveBeenCalledWith("O desconto à vista deve ser maior que 0% e no máximo 100%")
      );
      expect(upsertSpy).not.toHaveBeenCalled();
    });

    it("blocks saving a negative labor fee", async () => {
      renderPage();
      await screen.findByDisplayValue("50");

      // A moeda default (BRL) formata "0,00" com espaço não separável entre o
      // símbolo e o número — usa regex em vez de string exata pela mesma
      // razão do teste de formatCurrency em budget.test.ts.
      fireEvent.change(screen.getByPlaceholderText(/R\$\s*0,00/), { target: { value: "-50" } });
      fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

      await waitFor(() =>
        expect(toastErrorMock).toHaveBeenCalledWith("A taxa de mão de obra não pode ser negativa")
      );
      expect(upsertSpy).not.toHaveBeenCalled();
    });

    it("accepts in-range values at the boundaries (24 installments, 100% discount)", async () => {
      renderPage();
      await screen.findByDisplayValue("50");

      fireEvent.change(screen.getByPlaceholderText("Ex: 12"), { target: { value: "24" } });
      fireEvent.change(screen.getByPlaceholderText("0%"), { target: { value: "100" } });
      fireEvent.click(screen.getByRole("button", { name: "Salvar" }));

      await waitFor(() => expect(upsertSpy).toHaveBeenCalledTimes(1));
      expect(upsertSpy.mock.calls[0][0]).toMatchObject({ max_installments: 24, cash_discount_pct: 100 });
      expect(toastErrorMock).not.toHaveBeenCalled();
    });
  });
});
