import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AdminLayout from '@/components/harmonize/AdminLayout';
import HarmonizeBadge from '@/components/harmonize/Badge';
import { supabase } from '@/integrations/supabase/client';
import { formatDistanceToNow, type Locale } from 'date-fns';
import { ptBR, enUS, es } from 'date-fns/locale';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es };

/** Uma linha do agregado devolvido por `admin_error_log_summary`. */
type ErrorSummaryRow = {
  stage: string;
  error_type: string;
  n: number;
  last_seen_at: string | null;
};

/**
 * Janela em dias. É de TEMPO e não de linhas de propósito.
 *
 * Antes a tela lia as 50 linhas mais recentes de `error_logs` e agrupava aqui.
 * A contagem que aparecia nunca era o total de um tipo de erro — era quantos
 * daquele tipo couberam nas 50 —, e um único tipo barulhento com 50+
 * ocorrências ocupava a janela inteira, fazendo todo tipo mais antigo
 * DESAPARECER da tela. Não aparecer com contagem menor: não aparecer.
 *
 * Isso importa porque esta tela é o único canal operacional de alguns erros.
 * A falha de limpeza de Storage numa exclusão LGPD, por exemplo, é registrada
 * aqui justamente para alguém reprocessar à mão (ver
 * src/lib/patientPermanentDeletion.ts) — e era exatamente o tipo de linha que
 * sumia quando outro erro fazia barulho no mesmo período.
 *
 * Achado do ciclo 65 do QA Contínuo, mesma classe do achado do ciclo 41 em
 * alert-error-spike: "a janela encheu" virando motivo para esconder dado.
 */
const WINDOW_DAYS = 7;

const AdminErros: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [rows, setRows] = useState<ErrorSummaryRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      // Agregação no banco: GROUP BY por stage + tipo sobre a janela de tempo.
      // Devolve poucas linhas, com a contagem REAL, e nenhum tipo de erro pode
      // ser empurrado para fora por outro.
      const { data } = await supabase.rpc('admin_error_log_summary', { p_days: WINDOW_DAYS });
      setRows((data as ErrorSummaryRow[] | null) ?? []);
      setLoading(false);
    };
    load();
  }, []);

  return (
    <PageTransition>
    <AdminLayout>
      <h2 className="text-[22px] font-extrabold text-h-text tracking-tight mb-1">{t('admin.errors.title')}</h2>
      {/* Sem dizer a janela, tanto as contagens quanto o estado vazio ficam
          sem escala: "Nenhum erro registrado" passa a significar "nenhum nos
          últimos 7 dias", que é outra afirmação. */}
      <p className="text-[12px] text-h-text-3 mb-5">{t('admin.errors.window', { count: WINDOW_DAYS })}</p>

      <div className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
        {loading ? (
          <div className="p-5 flex flex-col gap-3">
            {[1, 2, 3].map(i => <div key={i} className="h-[40px] bg-h-surface-3 rounded animate-pulse" />)}
          </div>
        ) : rows.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-[14px] text-h-text-3">{t('admin.errors.emptyInWindow', { count: WINDOW_DAYS })}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="border-b border-h-surface-3">
                  <th className="text-left py-3 px-4 font-semibold text-h-text-3">Stage</th>
                  <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.errors.table.type')}</th>
                  <th className="text-center py-3 px-4 font-semibold text-h-text-3">Count</th>
                  <th className="text-right py-3 px-4 font-semibold text-h-text-3">{t('admin.errors.table.last')}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((e) => (
                  <tr key={`${e.stage}::${e.error_type}`} className="border-b border-h-surface-3 last:border-0">
                    <td className="py-3 px-4 text-h-text-2 font-medium">{e.stage}</td>
                    <td className="py-3 px-4 text-h-text font-medium">{e.error_type}</td>
                    <td className="py-3 px-4 text-center">
                      <HarmonizeBadge variant={e.n >= 10 ? 'alta' : 'neutral'}>{e.n}</HarmonizeBadge>
                    </td>
                    <td className="py-3 px-4 text-right text-h-text-3">
                      {e.last_seen_at ? formatDistanceToNow(new Date(e.last_seen_at), { addSuffix: true, locale: dateFnsLocale[i18n.language] ?? ptBR }) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
    </PageTransition>
  );
};

export default AdminErros;
