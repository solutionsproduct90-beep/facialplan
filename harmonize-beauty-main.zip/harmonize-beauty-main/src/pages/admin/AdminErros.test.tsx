import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AdminErros from "./AdminErros";
import { createQueryBuilder } from "@/test/supabaseMock";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

/** Resolve a RPC de resumo quando o caso quiser, para testar o skeleton. */
let resumo: { resolve: (value: { data: unknown; error: null }) => void };

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/admin/erros"]}>
      <AdminErros />
    </MemoryRouter>
  );

describe("AdminErros", () => {
  beforeEach(async () => {
    // Trava o idioma em português (fallback do app) para as asserções de
    // texto não dependerem do navigator do ambiente de teste.
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });

    // `from` continua existindo por causa do AdminLayout, que consulta o
    // próprio role antes de montar a página.
    fromMock.mockReset();
    fromMock.mockImplementation(() => createQueryBuilder(undefined, { data: { role: "admin" } }));

    let resolveFn!: (value: { data: unknown; error: null }) => void;
    const pendente = new Promise<{ data: unknown; error: null }>((resolve) => {
      resolveFn = resolve;
    });
    resumo = { resolve: resolveFn };
    rpcMock.mockReset();
    rpcMock.mockReturnValue(pendente);
  });

  it("mostra o skeleton enquanto o resumo não chegou", async () => {
    const { container } = renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    expect(container.querySelectorAll(".animate-pulse").length).toBeGreaterThan(0);
    expect(screen.queryByText(/Nenhum erro registrado/)).not.toBeInTheDocument();
  });

  it("pede a agregação ao banco, com a janela em dias", async () => {
    // A agregação tem que acontecer no SQL. Se a tela voltar a ler linhas
    // cruas de error_logs e agrupar aqui, um tipo barulhento volta a poder
    // esconder os outros — ver o caso de regressão mais abaixo.
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    expect(rpcMock).toHaveBeenCalledWith("admin_error_log_summary", { p_days: 7 });
  });

  it("diz qual é a janela, para as contagens terem escala", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    expect(screen.getByText("Agrupado por tipo, últimos 7 dias")).toBeInTheDocument();
  });

  it("mostra o estado vazio dizendo que é da janela, não do histórico inteiro", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    resumo.resolve({ data: [], error: null });

    await waitFor(() =>
      expect(screen.getByText("Nenhum erro registrado nos últimos 7 dias 🎉")).toBeInTheDocument()
    );
  });

  it("renderiza as linhas do agregado com a contagem que o banco devolveu", async () => {
    const agora = new Date().toISOString();
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    resumo.resolve({
      data: [
        { stage: "stage2", error_type: "timeout", n: 2, last_seen_at: agora },
        { stage: "stage1", error_type: "validation", n: 1, last_seen_at: agora },
      ],
      error: null,
    });

    await waitFor(() => expect(screen.getByText("timeout")).toBeInTheDocument());
    expect(screen.getByText("stage2")).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument();
    expect(screen.getByText("validation")).toBeInTheDocument();
  });

  it("marca com o badge de alta severidade a partir de 10 ocorrências", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    resumo.resolve({
      data: [{ stage: "stage3", error_type: "crash", n: 12, last_seen_at: new Date().toISOString() }],
      error: null,
    });

    await waitFor(() => expect(screen.getByText("12")).toBeInTheDocument());
    expect(screen.getByText("12")).toHaveStyle({ color: "#E05050" });
  });

  // ── Regressão do ciclo 65 do QA Contínuo ────────────────────────────────
  //
  // A tela lia as 50 linhas mais recentes e agrupava aqui. Um tipo de erro
  // com 50+ ocorrências recentes ocupava a janela inteira e fazia todo tipo
  // mais antigo DESAPARECER — não aparecer com contagem menor: sumir.
  //
  // O caso concreto que motivou: `patient_storage_cleanup_failed` é
  // registrado quando a exclusão LGPD não consegue apagar as fotos do
  // paciente do Storage, e esta tela é o único lugar onde alguém vê isso para
  // reprocessar à mão (ver src/lib/patientPermanentDeletion.ts). Ele sumia
  // sempre que qualquer outro erro fizesse barulho no mesmo período.
  it("mostra um erro raro mesmo quando outro tipo tem volume muito maior", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Erros")).toBeInTheDocument());

    // O agregado do banco devolve os dois, independente da diferença de
    // volume: não há janela de LINHAS para um empurrar o outro para fora.
    resumo.resolve({
      data: [
        { stage: "integracoes", error_type: "external_provider_timeout", n: 4821, last_seen_at: new Date().toISOString() },
        { stage: "lgpd_hard_delete", error_type: "patient_storage_cleanup_failed", n: 1, last_seen_at: new Date().toISOString() },
      ],
      error: null,
    });

    await waitFor(() => expect(screen.getByText("external_provider_timeout")).toBeInTheDocument());
    expect(screen.getByText("patient_storage_cleanup_failed")).toBeInTheDocument();
    // E a contagem do barulhento é a real, não o teto de uma janela.
    expect(screen.getByText("4821")).toBeInTheDocument();
  });
});
