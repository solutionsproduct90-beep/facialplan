import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AdminComprasPendentes from './AdminComprasPendentes';
import i18n from '@/i18n';
import { createRangeSlicer } from '@/test/supabaseMock';

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

vi.mock('sonner', () => ({
  toast: { error: vi.fn(), success: vi.fn(), info: vi.fn() },
}));

const PROFILES = [
  { id: 'pro-1', full_name: 'Dra. Ana', email: 'ana@clinica.com' },
  { id: 'pro-2', full_name: 'Dr. Bruno', email: 'bruno@clinica.com' },
];

let pendingRows: Record<string, unknown>[] = [];
// Registra se a consulta da página filtrou por resolved_at IS NULL — é o que
// distingue "fila" de "histórico".
let lastIsNullFilter: string | null = null;

/**
 * Builder por tabela, mesmo padrão de AdminAuditoria.test.tsx: `profiles`
 * serve o gate de admin do AdminLayout (`.select('role').eq(...).single()`) e
 * a lista de profissionais do seletor de vínculo.
 */
function makeBuilder(table: string) {
  const pagina = createRangeSlicer();
  let isSingle = false;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const builder: any = {
    select: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    eq: () => builder,
    is: (field: string) => { lastIsNullFilter = field; return builder; },
    single: () => { isSingle = true; return builder; },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    then: (onFulfilled: any) => {
      let result: unknown;
      if (table === 'profiles') {
        result = isSingle ? { data: { role: 'admin' } } : { data: pagina.apply(PROFILES) };
      } else if (table === 'hotmart_pending_purchases') {
        result = { data: pagina.apply(pendingRows), error: null };
      } else {
        result = { data: [] };
      }
      return Promise.resolve(result).then(onFulfilled);
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={['/admin/compras-pendentes']}>
      <AdminComprasPendentes />
    </MemoryRouter>
  );

describe('AdminComprasPendentes', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    lastIsNullFilter = null;
    rpcMock.mockReset();
    rpcMock.mockResolvedValue({ error: null });
    useAuthMock.mockReturnValue({
      user: { id: 'admin-1', email: 'admin@example.com' },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockImplementation((table: string) => makeBuilder(table));
    pendingRows = [
      {
        id: 'pend-1',
        buyer_email: 'pagou@gmail.com',
        transaction_id: 'HP17654321',
        event: 'PURCHASE_APPROVED',
        target_status: 'active',
        received_at: '2026-09-16T10:00:00Z',
        claim_requested_by: 'pro-1',
        claim_requested_at: '2026-09-16T12:00:00Z',
        resolved_at: null,
        resolved_profile_id: null,
        resolution: null,
        payload_excerpt: { buyer_name: 'Ana Paula', product_name: 'FacialPlan Pro' },
      },
    ];
  });

  it('lista só as compras ainda pendentes por padrão', async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText('pagou@gmail.com')).toBeTruthy());
    expect(lastIsNullFilter).toBe('resolved_at');
    expect(screen.getByText('HP17654321')).toBeTruthy();
    expect(screen.getByText('Ana Paula')).toBeTruthy();
  });

  it('mostra quem reivindicou a compra como PALPITE a conferir, não como fato', async () => {
    renderPage();
    await waitFor(() =>
      expect(screen.getByText('Reivindicada por Dra. Ana (conferir antes de vincular)')).toBeTruthy());
  });

  it('vincula manualmente ao profissional que o admin escolher, não ao que reivindicou', async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText('Vincular')).toBeTruthy());
    fireEvent.click(screen.getByText('Vincular'));

    const search = await screen.findByPlaceholderText('Buscar profissional por nome ou e-mail');
    fireEvent.change(search, { target: { value: 'bruno' } });
    fireEvent.click(await screen.findByText('Dr. Bruno'));

    await waitFor(() =>
      expect(rpcMock).toHaveBeenCalledWith('admin_link_hotmart_pending_purchase', {
        p_pending_id: 'pend-1',
        p_profile_id: 'pro-2',
      }));
  });

  it('não oferece o botão de vincular numa compra já resolvida — mostra por qual caminho foi', async () => {
    pendingRows = [{
      ...pendingRows[0],
      resolved_at: '2026-09-17T09:00:00Z',
      resolved_profile_id: 'pro-1',
      resolution: 'signup',
      claim_requested_by: null,
    }];
    renderPage();
    await waitFor(() => expect(screen.getByText('Resolvida no cadastro')).toBeTruthy());
    expect(screen.queryByText('Vincular')).toBeNull();
  });

  it('mostra estado vazio quando a fila está limpa', async () => {
    pendingRows = [];
    renderPage();
    await waitFor(() => expect(screen.getByText('Nenhuma compra pendente.')).toBeTruthy());
  });
});
