import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useAuth } from '@/contexts/AuthContext';
import AdminLayout from '@/components/harmonize/AdminLayout';
import HarmonizeBadge from '@/components/harmonize/Badge';
import { Search } from 'lucide-react';
import { toast } from 'sonner';

const localeTag: Record<string, string> = { pt: 'pt-BR', en: 'en-US', es: 'es-ES' };

type Profile = {
  id: string;
  full_name: string | null;
  specialty: string | null;
  is_blocked: boolean | null;
  created_at: string | null;
  role: string | null;
};

const AdminUsuarios: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    // Paginado (src/lib/fetchAllRows.ts): esta é a lista de TODOS os usuários
    // do sistema, sem filtro por profissional. O teto de linhas por resposta
    // do PostgREST (Max Rows, 1000 por padrão) é aplicado em silêncio, com
    // `error: null` — passando dele, um profissional deixaria de aparecer no
    // admin, inclusive pra bloquear. Mesma classe do ciclo 86.
    const data = await fetchAllRows<Profile>((from, to) =>
      supabase
        .from('profiles')
        .select('id, full_name, specialty, is_blocked, created_at, role')
        .order('created_at', { ascending: false })
        .range(from, to),
    ).catch(() => null);
    setProfiles(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = profiles.filter(p =>
    (p.full_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const toggleBlock = async (profile: Profile) => {
    // Defense in depth: the action button is already hidden for the admin's
    // own row (see render below), but guard here too so a stale row from a
    // pending confirmation can never actually lock the current admin out.
    if (profile.id === user?.id) {
      toast.error(t('admin.users.cannotSelfBlock'));
      setConfirmId(null);
      return;
    }
    const newVal = !profile.is_blocked;
    const { error } = await supabase.rpc('admin_toggle_professional_block', {
      p_professional_id: profile.id,
      p_blocked: newVal,
    });
    setConfirmId(null);
    if (error) {
      toast.error(t('admin.users.toggleError'));
      return;
    }
    toast.success(newVal ? t('admin.users.blockedToast') : t('admin.users.unblockedToast'));
    load();
  };

  const formatDate = (d: string | null) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString(localeTag[i18n.language] ?? 'pt-BR', { day: '2-digit', month: 'short', year: '2-digit' });
  };

  return (
    <PageTransition>
    <AdminLayout>
      <h2 className="text-[22px] font-extrabold text-h-text tracking-tight mb-5">{t('admin.users.title')}</h2>

      {/* Search */}
      <div className="bg-h-white rounded-r-sm shadow-h-sm flex items-center gap-3 px-4 h-[48px] mb-4">
        <Search size={18} className="text-h-text-3 flex-shrink-0" />
        <input
          type="text"
          placeholder={t('admin.users.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 bg-transparent text-[14px] text-h-text outline-none placeholder:text-h-text-3"
        />
      </div>

      <p className="text-[12px] text-h-text-3 mb-3">{t('admin.users.count', { count: filtered.length })}</p>

      {/* Table */}
      <div className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
        {loading ? (
          <div className="p-5 flex flex-col gap-3">
            {[1, 2, 3].map(i => <div key={i} className="h-[48px] bg-h-surface-3 rounded animate-pulse" />)}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="border-b border-h-surface-3">
                  <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.users.table.name')}</th>
                  <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.users.table.specialty')}</th>
                  <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.users.table.status')}</th>
                  <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.users.table.created')}</th>
                  <th className="text-right py-3 px-4 font-semibold text-h-text-3">{t('admin.users.table.actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr
                    key={p.id}
                    className="border-b border-h-surface-3 last:border-0 hover:bg-h-surface/50 cursor-pointer transition-colors"
                    onClick={() => navigate(`/admin/usuarios/${p.id}`)}
                  >
                    <td className="py-3 px-4">
                      <p className="text-[13px] font-bold text-h-text">{p.full_name || t('admin.users.noName')}</p>
                      <p className="text-[10px] text-h-text-3">{p.role || 'professional'}</p>
                    </td>
                    <td className="py-3 px-4 text-h-text-2">{p.specialty || '—'}</td>
                    <td className="py-3 px-4 text-center">
                      <HarmonizeBadge variant={p.is_blocked ? 'alta' : 'baixa'}>
                        {p.is_blocked ? t('admin.users.blocked') : t('admin.users.active')}
                      </HarmonizeBadge>
                    </td>
                    <td className="py-3 px-4 text-center text-h-text-3">{formatDate(p.created_at)}</td>
                    <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                      {p.id === user?.id ? (
                        <HarmonizeBadge variant="neutral">{t('admin.users.you')}</HarmonizeBadge>
                      ) : confirmId === p.id ? (
                        <div className="flex items-center gap-1 justify-end">
                          <button
                            onClick={() => toggleBlock(p)}
                            className="text-[11px] font-bold px-2 py-1 rounded-full"
                            style={{ backgroundColor: 'rgba(224,80,80,0.08)', color: '#E05050' }}
                          >
                            {t('admin.users.confirm')}
                          </button>
                          <button
                            onClick={() => setConfirmId(null)}
                            className="text-[11px] font-medium text-h-text-3 px-2 py-1"
                          >
                            {t('admin.users.cancel')}
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmId(p.id)}
                          className="text-[11px] font-bold px-3 py-1 rounded-full"
                          style={p.is_blocked
                            ? { backgroundColor: 'rgba(45,184,122,0.10)', color: '#2DB87A' }
                            : { backgroundColor: 'rgba(224,80,80,0.08)', color: '#E05050' }
                          }
                        >
                          {p.is_blocked ? t('admin.users.unblock') : t('admin.users.block')}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
    </PageTransition>
  );
};

export default AdminUsuarios;
