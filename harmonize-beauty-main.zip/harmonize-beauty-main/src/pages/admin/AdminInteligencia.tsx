import React, { useEffect, useMemo, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AdminLayout from '@/components/harmonize/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { Info, RefreshCw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { SUBSTANCE_LABEL, type Substance } from '@/types/harmonize';
import { regionLabel } from '@/lib/faceRegions';
import {
  mapDoseAccuracyGroups,
  filterAdverseEventPatterns,
  filterAnamnesisFlagFrequency,
  type DoseAccuracyGroup,
  type DoseAccuracyGroupRow,
  type AdverseEventPattern,
  type AdverseEventPatternRow,
  type AnamnesisFlagFrequency,
  type AnamnesisFlagFrequencyRow,
} from '@/lib/adminIntelligence';

/**
 * Central de Inteligência do admin (/admin/inteligencia, backlog P5) — três
 * agregações cross-profissional (a plataforma inteira, não um profissional
 * por vez, diferente de /admin/metricas) pensadas pra ajudar a melhorar as
 * sugestões de IA do Estágio 1/2: correlação substância+região+faixa-de-dose
 * com a nota de precisão da simulação (session_simulation_accuracy_ratings,
 * P4), padrões de evento adverso por substância/marca (adverse_events, P1) e
 * a distribuição de frequência das flags de anamnese mais comuns na base.
 *
 * DECISÃO DE PRIVACIDADE — v1 só com dado agregado e anonimizado: as três
 * RPCs SECURITY DEFINER que alimentam esta tela (ver
 * supabase/migrations/20260911070000_add_admin_intelligence_rpcs.sql) nunca
 * selecionam paciente/profissional/sessão, e as funções puras que consomem o
 * resultado aqui (src/lib/adminIntelligence.ts) omitem qualquer grupo com
 * menos de MIN_SAMPLE_SIZE amostras — nenhuma foto, nome, telefone ou ficha
 * individual chega perto desta tela em nenhuma circunstância. Mesmo padrão
 * de fetch (useEffect + Promise.all, sem react-query) de AdminMetricas.tsx/
 * AdminAuditoria.tsx, pra consistência dentro de /admin.
 */
type IntelligenceSection = 'doseAccuracy' | 'adverseEvents' | 'anamnesisFlags';

/**
 * Lê o resultado de UMA chamada do `Promise.allSettled` abaixo: uma rejeição
 * (exceção de rede) e um `{ error }` resolvido normalmente (falha reportada
 * pela RPC) contam igualmente como "esta seção falhou" — o chamador não
 * precisa distinguir os dois casos.
 */
function unwrapRpcSettlement<T>(
  settled: PromiseSettledResult<{ data: T[] | null; error: unknown }>,
): { rows: T[]; failed: boolean } {
  if (settled.status === 'rejected' || settled.value.error) return { rows: [], failed: true };
  return { rows: settled.value.data ?? [], failed: false };
}

const AdminInteligencia: React.FC = () => {
  const { t } = useTranslation();
  const [doseAccuracy, setDoseAccuracy] = useState<DoseAccuracyGroup[] | null>(null);
  const [adverseEvents, setAdverseEvents] = useState<AdverseEventPattern[] | null>(null);
  const [anamnesisFlags, setAnamnesisFlags] = useState<AnamnesisFlagFrequency[] | null>(null);
  const [loading, setLoading] = useState(true);
  // `hasError` só cobre a falha TOTAL (as 3 RPCs falharam, ou algo estourou
  // antes mesmo de chamá-las) — a tela inteira fica bloqueada só nesse caso.
  const [hasError, setHasError] = useState(false);
  // Falha de 1 ou 2 das 3 RPCs (achado do QA Contínuo: antes, `Promise.all`
  // derrubava a tela inteira mesmo com as outras 2 tendo sucesso) — cada
  // seção decide sozinha se mostra o gráfico ou um aviso discreto.
  const [sectionErrors, setSectionErrors] = useState<Record<IntelligenceSection, boolean>>({
    doseAccuracy: false,
    adverseEvents: false,
    anamnesisFlags: false,
  });

  const load = async () => {
    setLoading(true);
    setHasError(false);
    setSectionErrors({ doseAccuracy: false, adverseEvents: false, anamnesisFlags: false });
    try {
      const [doseSettled, adverseSettled, flagSettled] = await Promise.allSettled([
        supabase.rpc('admin_dose_accuracy_correlation'),
        supabase.rpc('admin_adverse_event_patterns'),
        supabase.rpc('admin_anamnesis_flag_frequency'),
      ]);

      const dose = unwrapRpcSettlement<DoseAccuracyGroupRow>(doseSettled);
      const adverse = unwrapRpcSettlement<AdverseEventPatternRow>(adverseSettled);
      const flag = unwrapRpcSettlement<AnamnesisFlagFrequencyRow>(flagSettled);

      setDoseAccuracy(dose.failed ? null : mapDoseAccuracyGroups(dose.rows));
      setAdverseEvents(adverse.failed ? null : filterAdverseEventPatterns(adverse.rows));
      setAnamnesisFlags(flag.failed ? null : filterAnamnesisFlagFrequency(flag.rows));
      setSectionErrors({ doseAccuracy: dose.failed, adverseEvents: adverse.failed, anamnesisFlags: flag.failed });

      // Só vira a tela de erro cheia (com o botão "Tentar novamente" no lugar
      // de tudo) quando NENHUMA das 3 seções tem dado pra mostrar.
      if (dose.failed && adverse.failed && flag.failed) setHasError(true);
    } catch {
      setHasError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const adverseEventChartData = useMemo(
    () =>
      (adverseEvents ?? []).slice(0, 8).map((p) => ({
        name: `${SUBSTANCE_LABEL[p.substance as Substance] ?? p.substance} · ${p.brandName}`,
        n: p.n,
      })),
    [adverseEvents],
  );

  const anamnesisFlagChartData = useMemo(
    () => (anamnesisFlags ?? []).slice(0, 8).map((f) => ({ name: t(`anamnesis.riskLabels.${f.flagKey}`), n: f.n })),
    [anamnesisFlags, t],
  );

  // Aviso discreto de UMA seção que falhou enquanto as outras carregaram
  // normalmente — bem menor que o bloco de erro cheio (`hasError` acima), só
  // um aviso + "tentar novamente" no lugar do gráfico/tabela daquela seção.
  const sectionWarning = (
    <div className="flex items-center justify-between gap-2 py-6 px-4">
      <p className="text-[12.5px] text-h-text-3">{t('admin.intelligence.sectionError')}</p>
      <button
        onClick={load}
        className="flex items-center gap-1 text-[11.5px] font-semibold press-scale flex-shrink-0"
        style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 32 }}
      >
        <RefreshCw size={12} />
        {t('admin.intelligence.retry')}
      </button>
    </div>
  );

  const privacyNotice = (
    <div
      className="flex items-start gap-2 rounded-r p-3"
      style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
    >
      <Info size={15} className="flex-shrink-0 mt-0.5" style={{ color: '#D4900A' }} />
      <p className="text-[11.5px] leading-relaxed" style={{ color: '#8A6300' }}>
        {t('admin.intelligence.privacyNotice')}
      </p>
    </div>
  );

  return (
    <PageTransition>
      <AdminLayout>
        <h2 className="text-[22px] font-extrabold text-h-text tracking-tight mb-2">{t('admin.intelligence.title')}</h2>

        <div className="mb-4">{privacyNotice}</div>

        {loading ? (
          <div className="flex flex-col gap-4">
            <div className="bg-h-white rounded-r shadow-h-sm h-[160px] animate-pulse" />
            <div className="bg-h-white rounded-r shadow-h-sm h-[220px] animate-pulse" />
            <div className="bg-h-white rounded-r shadow-h-sm h-[220px] animate-pulse" />
          </div>
        ) : hasError ? (
          <div className="bg-h-white rounded-r shadow-h-sm flex flex-col items-center gap-2 text-center py-6">
            <p className="text-[13px] text-h-text-2">{t('admin.intelligence.error')}</p>
            <button
              onClick={load}
              className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
              style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
            >
              <RefreshCw size={14} />
              {t('admin.intelligence.retry')}
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {/* Substância + região + faixa de dose -> precisão da simulação */}
            <div className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
              <p className="text-[15px] font-bold text-h-text p-4 pb-3">{t('admin.intelligence.doseAccuracy.title')}</p>
              {sectionErrors.doseAccuracy ? sectionWarning : (doseAccuracy ?? []).length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-[14px] text-h-text-3">{t('admin.intelligence.doseAccuracy.empty')}</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-[12px]">
                    <thead>
                      <tr className="border-b border-h-surface-3">
                        <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.intelligence.doseAccuracy.table.substance')}</th>
                        <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.intelligence.doseAccuracy.table.region')}</th>
                        <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.intelligence.doseAccuracy.table.doseRange')}</th>
                        <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.intelligence.doseAccuracy.table.averageRating')}</th>
                        <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.intelligence.doseAccuracy.table.sampleSize')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(doseAccuracy ?? []).map((g) => (
                        <tr key={`${g.substance}|${g.region}|${g.doseBucket}`} className="border-b border-h-surface-3 last:border-0">
                          <td className="py-3 px-4 text-h-text font-semibold">{SUBSTANCE_LABEL[g.substance]}</td>
                          <td className="py-3 px-4 text-h-text-2">{regionLabel(g.region)}</td>
                          <td className="py-3 px-4 text-center text-h-text-2">{t(`admin.intelligence.doseAccuracy.doseBucket.${g.doseBucket}`)}</td>
                          <td className="py-3 px-4 text-center text-h-text font-semibold">{g.averageRating.toFixed(1)}</td>
                          <td className="py-3 px-4 text-center text-h-text-3">{g.n}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Padrões de evento adverso por substância/marca */}
            <div className="bg-h-white rounded-r shadow-h-sm p-5">
              <p className="text-[15px] font-bold text-h-text mb-4">{t('admin.intelligence.adverseEvents.title')}</p>
              {sectionErrors.adverseEvents ? sectionWarning : (adverseEvents ?? []).length === 0 ? (
                <p className="text-[14px] text-h-text-3 text-center py-4">{t('admin.intelligence.adverseEvents.empty')}</p>
              ) : (
                <>
                  <div className="w-full" style={{ height: 220 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={adverseEventChartData} margin={{ top: 4, right: 8, left: -20, bottom: 4 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E5E3E0" vertical={false} />
                        <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#6B6965' }} interval={0} angle={-20} textAnchor="end" height={60} />
                        <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#6B6965' }} />
                        <Tooltip
                          contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.12)', fontSize: 12 }}
                          formatter={(value: number) => [value, t('admin.intelligence.adverseEvents.table.count')]}
                        />
                        <Bar dataKey="n" fill="#E05C8A" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="overflow-x-auto mt-4">
                    <table className="w-full text-[12px]">
                      <thead>
                        <tr className="border-b border-h-surface-3">
                          <th className="text-left py-2 px-3 font-semibold text-h-text-3">{t('admin.intelligence.adverseEvents.table.substance')}</th>
                          <th className="text-left py-2 px-3 font-semibold text-h-text-3">{t('admin.intelligence.adverseEvents.table.brand')}</th>
                          <th className="text-left py-2 px-3 font-semibold text-h-text-3">{t('admin.intelligence.adverseEvents.table.eventType')}</th>
                          <th className="text-center py-2 px-3 font-semibold text-h-text-3">{t('admin.intelligence.adverseEvents.table.count')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(adverseEvents ?? []).map((p) => (
                          <tr key={`${p.substance}|${p.brandName}|${p.eventType}`} className="border-b border-h-surface-3 last:border-0">
                            <td className="py-2 px-3 text-h-text-2">{SUBSTANCE_LABEL[p.substance as Substance] ?? p.substance}</td>
                            <td className="py-2 px-3 text-h-text font-semibold">{p.brandName}</td>
                            <td className="py-2 px-3 text-h-text-2">{t(`adverseEvents.eventType.${p.eventType}`)}</td>
                            <td className="py-2 px-3 text-center text-h-text-3">{p.n}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>

            {/* Distribuição de frequência das flags de anamnese */}
            <div className="bg-h-white rounded-r shadow-h-sm p-5">
              <p className="text-[15px] font-bold text-h-text mb-4">{t('admin.intelligence.anamnesisFlags.title')}</p>
              {sectionErrors.anamnesisFlags ? sectionWarning : (anamnesisFlags ?? []).length === 0 ? (
                <p className="text-[14px] text-h-text-3 text-center py-4">{t('admin.intelligence.anamnesisFlags.empty')}</p>
              ) : (
                <div className="w-full" style={{ height: 220 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={anamnesisFlagChartData} margin={{ top: 4, right: 8, left: -20, bottom: 4 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E5E3E0" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#6B6965' }} interval={0} angle={-20} textAnchor="end" height={60} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#6B6965' }} />
                      <Tooltip
                        contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.12)', fontSize: 12 }}
                        formatter={(value: number) => [value, t('admin.intelligence.anamnesisFlags.count')]}
                      />
                      <Bar dataKey="n" fill="#A855B5" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Rodapé de responsabilidade — mesmo aviso do topo, repetido de propósito
            (pedido explícito do dono do produto: reforçar em dois pontos da tela
            que o dado é sempre agregado/anonimizado, nunca individualizável). */}
        <p className="text-[10.5px] text-h-text-3 text-center leading-relaxed mt-6 mb-2 px-4">
          {t('admin.intelligence.privacyNotice')}
        </p>
      </AdminLayout>
    </PageTransition>
  );
};

export default AdminInteligencia;
