import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import AdminUsuarioDetalhe from "./AdminUsuarioDetalhe";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();
const toastSuccessMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

const DIA_MS = 24 * 60 * 60 * 1000;
/** Atrasado há 1 dia: ainda dentro dos 3 dias de carência. */
const ATRASADO_EM_CARENCIA = new Date(Date.now() - 1 * DIA_MS).toISOString();
/** Atrasado há 5 dias: carência vencida, acesso já bloqueado. */
const ATRASADO_VENCIDO = new Date(Date.now() - 5 * DIA_MS).toISOString();

const PROFILES: Record<string, any> = {
  "admin-1": { id: "admin-1", full_name: "Admin Principal", is_blocked: false, role: "admin", subscription_status: "active" },
  "pro-1": { id: "pro-1", full_name: "Dra. Ana", is_blocked: false, role: "professional", subscription_status: "active" },
  // Os dois perfis abaixo têm EXATAMENTE o mesmo subscription_status. A
  // única diferença é past_due_since — e era justamente por isso que a tela
  // os mostrava idênticos antes desta rodada.
  "pro-carencia": {
    id: "pro-carencia", full_name: "Dr. Em Carência", is_blocked: false, role: "professional",
    subscription_status: "past_due", past_due_since: ATRASADO_EM_CARENCIA,
  },
  "pro-vencido": {
    id: "pro-vencido", full_name: "Dra. Vencida", is_blocked: false, role: "professional",
    subscription_status: "past_due", past_due_since: ATRASADO_VENCIDO,
  },
};

/**
 * Universal builder for every `.from()` call this page and AdminLayout make:
 * AdminLayout's own-role lookup (`select().eq().single()` on the *auth*
 * user's id, always "admin" here), this page's profile-by-:id lookup
 * (`select().eq(id).single()`), and the sessions count
 * (`select(..., {count})` with `.eq()`). The block/unblock action itself
 * goes through `supabase.rpc('admin_toggle_professional_block', ...)` (see
 * rpcMock below), not `.from(...).update(...)`.
 */
function makeUniversalBuilder() {
  let isSingle = false;
  let isCount = false;
  let lastEqId: string | undefined;

  const builder: any = {
    select: (_cols: unknown, options?: { count?: string }) => {
      if (options?.count) isCount = true;
      return builder;
    },
    single: () => {
      isSingle = true;
      return builder;
    },
    eq: (_col: string, val: string) => {
      lastEqId = val;
      return builder;
    },
    then: (onFulfilled: any) => {
      let result: unknown;
      if (isCount) {
        result = { count: 3 };
      } else if (isSingle) {
        // AdminLayout always checks the *logged-in admin's* own row; the
        // page itself looks up whatever :id is in the URL. Both resolve
        // from the same fixture keyed by id.
        result = { data: (lastEqId && PROFILES[lastEqId]) ?? PROFILES["admin-1"] };
      } else {
        result = { data: [] };
      }
      return Promise.resolve(result).then(onFulfilled);
    },
  };
  return builder;
}

const renderPage = (id: string) =>
  render(
    <MemoryRouter initialEntries={[`/admin/usuarios/${id}`]}>
      <Routes>
        <Route path="/admin/usuarios/:id" element={<AdminUsuarioDetalhe />} />
      </Routes>
    </MemoryRouter>
  );

describe("AdminUsuarioDetalhe", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockReset();
    fromMock.mockImplementation(() => makeUniversalBuilder());
    rpcMock.mockReset();
    rpcMock.mockResolvedValue({ error: null });
    toastSuccessMock.mockReset();
    toastErrorMock.mockReset();
  });

  it("hides the block/unblock action and explains why when viewing the admin's own profile", async () => {
    renderPage("admin-1");

    await waitFor(() => expect(screen.getByText("Admin Principal")).toBeInTheDocument());

    expect(screen.queryByText("Bloquear usuário")).not.toBeInTheDocument();
    expect(screen.queryByText("Desbloquear usuário")).not.toBeInTheDocument();
    expect(screen.getByText("Você não pode bloquear sua própria conta")).toBeInTheDocument();
  });

  it("shows the normal block action for another professional's profile", async () => {
    renderPage("pro-1");

    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    expect(screen.getByText("Bloquear usuário")).toBeInTheDocument();
  });

  it("shows an error toast and does not report success when the block/unblock update fails", async () => {
    renderPage("pro-1");
    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    rpcMock.mockResolvedValue({ error: { message: "network down" } });
    fireEvent.click(screen.getByText("Bloquear usuário"));

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith("Não foi possível atualizar o status do usuário")
    );
    expect(toastSuccessMock).not.toHaveBeenCalled();
    expect(rpcMock).toHaveBeenCalledWith("admin_toggle_professional_block", {
      p_professional_id: "pro-1",
      p_blocked: true,
    });
  });

  // ── Carência de past_due (achado do ciclo 48 do QA Contínuo) ─────────────
  //
  // Esta é a tela que a equipe abre quando o profissional liga dizendo que
  // não consegue entrar. Até esta rodada ela mostrava só o status cru, então
  // "ainda tem 2 dias" e "já perdeu o acesso" apareciam do mesmo jeito: o
  // texto "past_due" num badge cinza. A pergunta que motiva abrir a tela era
  // a única que ela não respondia.
  it("mostra quantos dias de carência restam para um pagamento atrasado recente", async () => {
    renderPage("pro-carencia");

    await waitFor(() => expect(screen.getByText("Dr. Em Carência")).toBeInTheDocument());

    expect(screen.getByText("Carência")).toBeInTheDocument();
    expect(screen.getByText("2 dias restantes")).toBeInTheDocument();
    expect(screen.queryByText("Encerrada — acesso bloqueado")).not.toBeInTheDocument();
  });

  it("diz que a carência acabou quando o atraso passou do prazo", async () => {
    renderPage("pro-vencido");

    await waitFor(() => expect(screen.getByText("Dra. Vencida")).toBeInTheDocument());

    expect(screen.getByText("Encerrada — acesso bloqueado")).toBeInTheDocument();
    expect(screen.queryByText(/dias restantes/)).not.toBeInTheDocument();
  });

  it("mostra desde quando o pagamento está atrasado, para a equipe conferir com a Hotmart", async () => {
    renderPage("pro-carencia");

    await waitFor(() => expect(screen.getByText("Dr. Em Carência")).toBeInTheDocument());

    expect(screen.getByText("Atrasado desde")).toBeInTheDocument();
    // A data formatada, não a ISO crua.
    expect(screen.queryByText(ATRASADO_EM_CARENCIA)).not.toBeInTheDocument();
  });

  it("não mostra linha de carência nenhuma para quem está com a assinatura ativa", async () => {
    // Sem isto, a correção poderia ter virado ruído permanente na tela de
    // todo profissional em dia.
    renderPage("pro-1");

    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    expect(screen.queryByText("Carência")).not.toBeInTheDocument();
    expect(screen.queryByText("Atrasado desde")).not.toBeInTheDocument();
  });
});
