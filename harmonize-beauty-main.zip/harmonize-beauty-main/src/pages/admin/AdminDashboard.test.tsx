import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AdminDashboard from "./AdminDashboard";
import { createQueryBuilder, type QueryResolution } from "@/test/supabaseMock";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

let listResponse: { resolve: (value: QueryResolution) => void };

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/admin"]}>
      <AdminDashboard />
    </MemoryRouter>
  );

describe("AdminDashboard", () => {
  beforeEach(async () => {
    // Locks the UI language to Portuguese (the app's fallback/default) so
    // assertions on rendered text are deterministic regardless of the test
    // environment's navigator language.
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });

    let resolveFn!: (value: QueryResolution) => void;
    const pending = new Promise<QueryResolution>((resolve) => {
      resolveFn = resolve;
    });
    listResponse = { resolve: resolveFn };
    fromMock.mockReset();
    fromMock.mockImplementation(() =>
      createQueryBuilder(pending, { data: { role: "admin" } })
    );
  });

  it("shows loading skeletons for the metrics grid and stage breakdown while data is fetched", async () => {
    const { container } = renderPage();

    await waitFor(() => expect(screen.getByRole("heading", { name: "Dashboard" })).toBeInTheDocument());

    expect(container.querySelectorAll(".animate-pulse").length).toBeGreaterThan(0);
    expect(screen.getByText("Sessões por Estágio")).toBeInTheDocument();
  });

  it("renders zeroed metrics, stage percentages and green error indicators when there is no data", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByRole("heading", { name: "Dashboard" })).toBeInTheDocument());

    listResponse.resolve({ data: [], count: 0 });

    await waitFor(() =>
      expect(screen.getByText("Usuários totais")).toBeInTheDocument()
    );

    expect(screen.getAllByText("0").length).toBeGreaterThan(0);
    expect(screen.getByText("Erros nas últimas 24h")).toBeInTheDocument();
    expect(screen.getByText("Erros nos últimos 7 dias").previousSibling).toHaveStyle({
      color: "#2DB87A",
    });
  });

  it("renders fetched counts and highlights errors in amber once there are error logs", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByRole("heading", { name: "Dashboard" })).toBeInTheDocument());

    listResponse.resolve({
      data: [
        { professional_id: "pro-1", status: "stage1" },
        { professional_id: "pro-2", status: "stage2" },
      ],
      count: 5,
    });

    await waitFor(() => expect(screen.getAllByText("5").length).toBeGreaterThan(0));

    // totalUsers / totalSessions / activeSubscribers all come from the same
    // mocked `count`, so "5" should show up more than once in the grid.
    expect(screen.getAllByText("5").length).toBeGreaterThanOrEqual(3);

    // Stage breakdown derived from the `status` field of each session row.
    expect(screen.getByText("Stage 1")).toBeInTheDocument();
    expect(screen.getByText("Stage 2")).toBeInTheDocument();

    // errCount24h / errCount7d also resolve to 5 (> 0), so both should render
    // with the amber "attention" color instead of the green "all clear" one.
    expect(screen.getByText("Erros nas últimas 24h").previousSibling).toHaveStyle({
      color: "#D4900A",
    });
    expect(screen.getByText("Erros nos últimos 7 dias").previousSibling).toHaveStyle({
      color: "#D4900A",
    });
  });

  /**
   * O PostgREST aplica o teto de linhas por resposta (Max Rows, 1000 por
   * padrão) EM SILÊNCIO: devolve 1000 linhas com `error: null`. Antes, o
   * card "Total de Sessões" usava uma contagem exata enquanto a quebra por
   * estágio contava linhas de um `select('status')` sem paginação — as duas
   * seções da MESMA tela passariam a discordar do total sem nenhum aviso.
   * "Profissionais ativos no mês" tem o mesmo problema, e lá não há contagem
   * exata possível (não existe count-distinct via PostgREST), então a leitura
   * pagina. Achado do ciclo 86 do QA Contínuo.
   */
  describe("teto de linhas do PostgREST", () => {
    const PAGE_CAP = 1000;
    const TOTAL_SESSIONS = 1200;
    // Um profissional distinto por sessão: "ativos no mês" só chega em 1200
    // se todas as páginas forem lidas.
    const MONTH_SESSIONS = Array.from({ length: TOTAL_SESSIONS }, (_, i) => ({
      professional_id: `pro-${i}`,
      status: "stage1",
    }));

    beforeEach(() => {
      fromMock.mockImplementation((table: string) => {
        let head = false;
        let statusFilter: string | null = null;
        let rangeFrom: number | null = null;
        let rangeTo: number | null = null;
        const builder: any = {
          select: (_cols?: unknown, opts?: { head?: boolean }) => {
            head = Boolean(opts?.head);
            return builder;
          },
          eq: (col: string, value: string) => {
            if (col === "status") statusFilter = value;
            return builder;
          },
          gte: () => builder,
          range: (from: number, to: number) => {
            rangeFrom = from;
            rangeTo = to;
            return builder;
          },
          single: () => {
            head = false;
            statusFilter = "__single__";
            return builder;
          },
          then: (onFulfilled: any) => {
            if (statusFilter === "__single__") {
              return Promise.resolve({ data: { role: "admin" } }).then(onFulfilled);
            }
            if (head) {
              // `head: true` não devolve linha nenhuma, então nem existe teto
              // a estourar: a contagem é sempre a real.
              if (table === "sessions") {
                const count = statusFilter === null || statusFilter === "stage1" ? TOTAL_SESSIONS : 0;
                return Promise.resolve({ data: null, count }).then(onFulfilled);
              }
              return Promise.resolve({ data: null, count: table === "profiles" ? 3 : 0 }).then(onFulfilled);
            }
            const rows = table === "sessions" ? MONTH_SESSIONS : [];
            const from = rangeFrom ?? 0;
            const to = rangeTo === null ? rows.length - 1 : rangeTo;
            return Promise.resolve({
              data: rows.slice(from, Math.min(to + 1, from + PAGE_CAP)),
            }).then(onFulfilled);
          },
        };
        return builder;
      });
    });

    it("keeps the stage breakdown and the active-professionals card consistent past the row cap", async () => {
      renderPage();

      await waitFor(() => expect(screen.getAllByText(String(TOTAL_SESSIONS)).length).toBeGreaterThan(0));

      // Card "Total de Sessões" (contagem exata) e a linha "Stage 1" da
      // quebra por estágio precisam mostrar o MESMO total.
      const stage1Row = screen.getByText("Stage 1").closest("div")!;
      expect(stage1Row).toHaveTextContent(String(TOTAL_SESSIONS));

      // Profissionais distintos no mês: 1200, não as 1000 da primeira página.
      expect(screen.getByText("Ativos este mês").previousSibling).toHaveTextContent(
        String(TOTAL_SESSIONS),
      );
      expect(screen.queryByText(String(PAGE_CAP))).not.toBeInTheDocument();
    });
  });
});
