import React, { useEffect, useMemo, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AdminLayout from '@/components/harmonize/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { Search, RefreshCw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatCurrency } from '@/lib/budget';
import {
  computeProfessionalMetrics,
  filterMetricsBySearch,
  summarizeProfessionalMetrics,
  buildSessionsChartData,
  type ProfessionalMetrics,
  type SessionForAdminMetrics,
  type InsumoRowForAdminMetrics,
  type ProfessionalProfileForMetrics,
} from '@/lib/adminMetrics';

/**
 * Visão agregada do operador do SaaS sobre TODOS os profissionais
 * (/admin/metricas, item P1 do backlog "Painel de métricas/ROI por
 * profissional no Admin") — bem diferente do /painel (src/pages/Painel.tsx),
 * que é o PRÓPRIO profissional olhando só pros números dele. Aqui: sessões
 * criadas, conversão sessão → procedimento fechado, receita agregada
 * estimada e taxa de retorno, por profissional, com uma busca simples por
 * profissional/clínica (não existe uma entidade de clínica separada no
 * schema — ver comentário em src/lib/adminMetrics.ts).
 *
 * "Fechado" = sessions.status === 'complete', o mesmo valor gravado quando o
 * profissional conclui o procedimento no Estágio 3 (handleComplete em
 * SessaoEstagio3.tsx) — não existe status de "vendido"/"pago" separado hoje.
 *
 * Segue o mesmo padrão de fetch (useEffect + Promise.all, sem react-query)
 * já usado pelas outras telas de admin (AdminDashboard.tsx, AdminErros.tsx),
 * pra consistência dentro da seção /admin.
 */
const AdminMetricas: React.FC = () => {
  const { t } = useTranslation();
  const [metrics, setMetrics] = useState<ProfessionalMetrics[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [search, setSearch] = useState('');

  const load = async () => {
    setLoading(true);
    setHasError(false);
    try {
      // As três leituras são paginadas (ver src/lib/fetchAllRows.ts).
      //
      // Antes eram `select()` globais, sem filtro nem `.range()`: o PostgREST
      // trunca no teto de linhas por resposta (Max Rows, 1000 por padrão) em
      // silêncio, com `error: null`. Conversão, receita estimada e taxa de
      // retorno POR PROFISSIONAL passariam a ser calculadas sobre um recorte
      // assim que o total de sessões, insumos ou perfis do sistema — global,
      // não por profissional — cruzasse esse teto. O resultado não fica
      // incompleto, fica errado com aparência de certo.
      //
      // A agregação continua no cliente de propósito: a receita estimada usa
      // `computeBudget` (src/lib/budget.ts), a mesma função que o app usa para
      // precificar. Reimplementá-la em SQL criaria duas fontes de verdade para
      // preço — foi essa classe de duplicação que produziu o achado do ciclo
      // 76. Achado do ciclo 86 do QA Contínuo.
      const [profilesData, sessionsData, insumosData] = await Promise.all([
        fetchAllRows<{ id: string; full_name: string | null; clinic_name: string | null; currency: string | null; labor_fee_per_session: number | null; role: string | null }>(
          (from, to) =>
            supabase
              .from('profiles')
              .select('id, full_name, clinic_name, currency, labor_fee_per_session, role')
              .range(from, to),
        ),
        fetchAllRows<SessionForAdminMetrics>((from, to) =>
          supabase
            .from('sessions')
            .select('professional_id, patient_id, status, created_at, stage2_overlay')
            .range(from, to),
        ),
        fetchAllRows<InsumoRowForAdminMetrics>((from, to) =>
          supabase
            .from('insumos')
            .select('professional_id, id, substance, brand_name, cost_per_unit, price_per_unit, active')
            .range(from, to),
        ),
      ]);

      // Filtrado no client (não via `.neq('role', 'admin')` na query): a
      // coluna tem DEFAULT 'professional' no banco, mas uma policy de neq no
      // Postgres exclui silenciosamente qualquer linha com role NULL (NULL
      // <> 'admin' avalia pra unknown), o que apagaria profissionais legados
      // sem essa coluna preenchida — mesma cautela do `p.role || 'professional'`
      // já usado em AdminUsuarios.tsx.
      const professionalProfiles: ProfessionalProfileForMetrics[] = profilesData.filter(
        (p: { role: string | null }) => p.role !== 'admin',
      );

      setMetrics(
        computeProfessionalMetrics(sessionsData, insumosData, professionalProfiles),
      );
    } catch {
      setHasError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => filterMetricsBySearch(metrics ?? [], search), [metrics, search]);
  const sortedForTable = useMemo(
    () => [...filtered].sort((a, b) => b.sessionsCount - a.sessionsCount),
    [filtered],
  );
  const summary = useMemo(() => summarizeProfessionalMetrics(filtered), [filtered]);
  const chartData = useMemo(() => buildSessionsChartData(filtered), [filtered]);

  const formatPct = (pct: number) => `${Math.round(pct * 100)}%`;
  const displayName = (m: ProfessionalMetrics) => m.fullName || m.clinicName || t('admin.metrics.noName');

  return (
    <PageTransition>
      <AdminLayout>
        <h2 className="text-[22px] font-extrabold text-h-text tracking-tight mb-5">{t('admin.metrics.title')}</h2>

        {/* Search */}
        <div className="bg-h-white rounded-r-sm shadow-h-sm flex items-center gap-3 px-4 h-[48px] mb-4">
          <Search size={18} className="text-h-text-3 flex-shrink-0" />
          <input
            type="text"
            placeholder={t('admin.metrics.searchPlaceholder')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent text-[14px] text-h-text outline-none placeholder:text-h-text-3"
          />
        </div>

        {loading ? (
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-h-white rounded-r shadow-h-sm p-4 h-[64px] animate-pulse" />
              ))}
            </div>
            <div className="bg-h-white rounded-r shadow-h-sm h-[220px] animate-pulse" />
            <div className="bg-h-white rounded-r shadow-h-sm h-[160px] animate-pulse" />
          </div>
        ) : hasError ? (
          <div className="bg-h-white rounded-r shadow-h-sm flex flex-col items-center gap-2 text-center py-6">
            <p className="text-[13px] text-h-text-2">{t('admin.metrics.error')}</p>
            <button
              onClick={load}
              className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
              style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
            >
              <RefreshCw size={14} />
              {t('admin.metrics.retry')}
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {/* Summary cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-h-white rounded-r shadow-h-sm p-4">
                <p className="text-[22px] font-extrabold leading-none text-h-text">{summary.totalSessions}</p>
                <p className="text-[11px] font-semibold text-h-text-3 mt-1">{t('admin.metrics.summary.sessions')}</p>
              </div>
              <div className="bg-h-white rounded-r shadow-h-sm p-4">
                <p className="text-[22px] font-extrabold leading-none text-h-text">{formatPct(summary.overallConversionPct)}</p>
                <p className="text-[11px] font-semibold text-h-text-3 mt-1">{t('admin.metrics.summary.conversion')}</p>
              </div>
              <div className="bg-h-white rounded-r shadow-h-sm p-4">
                <p className="text-[22px] font-extrabold leading-none text-h-text">
                  {summary.currency ? formatCurrency(summary.totalRevenue ?? 0, summary.currency) : '—'}
                </p>
                <p className="text-[11px] font-semibold text-h-text-3 mt-1">
                  {summary.currency ? t('admin.metrics.summary.revenue') : t('admin.metrics.summary.revenueMixedCurrencies')}
                </p>
              </div>
              <div className="bg-h-white rounded-r shadow-h-sm p-4">
                <p className="text-[22px] font-extrabold leading-none text-h-text">{formatPct(summary.overallReturnRatePct)}</p>
                <p className="text-[11px] font-semibold text-h-text-3 mt-1">{t('admin.metrics.summary.returnRate')}</p>
              </div>
            </div>

            {/* Chart: sessions by professional */}
            {chartData.length > 0 && (
              <div className="bg-h-white rounded-r shadow-h-sm p-5">
                <p className="text-[15px] font-bold text-h-text mb-4">{t('admin.metrics.chartTitle')}</p>
                <div className="w-full" style={{ height: 220 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 4, right: 8, left: -20, bottom: 4 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E5E3E0" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#6B6965' }} interval={0} angle={-20} textAnchor="end" height={50} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#6B6965' }} />
                      <Tooltip
                        contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.12)', fontSize: 12 }}
                        formatter={(value: number) => [value, t('admin.metrics.summary.sessions')]}
                      />
                      <Bar dataKey="sessions" fill="#A855B5" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Table */}
            <div className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
              {sortedForTable.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-[14px] text-h-text-3">{t('admin.metrics.empty')}</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-[12px]">
                    <thead>
                      <tr className="border-b border-h-surface-3">
                        <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.metrics.table.professional')}</th>
                        <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.metrics.table.sessions')}</th>
                        <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.metrics.table.conversion')}</th>
                        <th className="text-right py-3 px-4 font-semibold text-h-text-3">{t('admin.metrics.table.revenue')}</th>
                        <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.metrics.table.returnRate')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedForTable.map((m) => (
                        <tr key={m.professionalId} className="border-b border-h-surface-3 last:border-0">
                          <td className="py-3 px-4">
                            <p className="text-[13px] font-bold text-h-text">{displayName(m)}</p>
                            {m.clinicName && m.fullName && (
                              <p className="text-[10px] text-h-text-3">{m.clinicName}</p>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center text-h-text-2 font-medium">{m.sessionsCount}</td>
                          <td className="py-3 px-4 text-center text-h-text-2 font-medium">
                            {formatPct(m.conversionPct)}
                            <span className="text-h-text-3"> ({m.closedCount})</span>
                          </td>
                          <td className="py-3 px-4 text-right text-h-text font-semibold">
                            {formatCurrency(m.estimatedRevenue, m.currency)}
                          </td>
                          <td className="py-3 px-4 text-center text-h-text-2 font-medium">
                            {formatPct(m.returnRatePct)}
                            <span className="text-h-text-3"> ({m.returningPatientsCount}/{m.uniquePatientsCount})</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </AdminLayout>
    </PageTransition>
  );
};

export default AdminMetricas;
