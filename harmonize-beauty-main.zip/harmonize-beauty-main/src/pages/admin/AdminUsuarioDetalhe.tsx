import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { graceDaysRemaining } from '@/lib/subscriptionAccess';
import AdminLayout from '@/components/harmonize/AdminLayout';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import { ChevronLeft } from 'lucide-react';
import { toast } from 'sonner';

const localeTag: Record<string, string> = { pt: 'pt-BR', en: 'en-US', es: 'es-ES' };

const AdminUsuarioDetalhe: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const [profile, setProfile] = useState<any>(null);
  const [sessionCount, setSessionCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = async (idAtCallTime: string, isStale: () => boolean) => {
    const [{ data: p }, { count }] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', idAtCallTime).single(),
      supabase.from('sessions').select('*', { count: 'exact', head: true }).eq('professional_id', idAtCallTime),
    ]);
    // Bail out if `id` changed (or the component unmounted) while this
    // request was in flight — otherwise a slow response for a previous
    // user could overwrite the newer user's data on screen.
    if (isStale()) return;
    setProfile(p);
    setSessionCount(count || 0);
    setLoading(false);
  };

  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    setLoading(true);
    load(id, () => cancelled);
    return () => { cancelled = true; };
  }, [id]);

  const toggleBlock = async () => {
    if (!profile) return;
    // Never let an admin block their own account — they'd have no way to
    // undo it (ProtectedRoute redirects blocked accounts to /conta-bloqueada
    // before they can reach any admin screen again).
    if (profile.id === user?.id) {
      toast.error(t('admin.users.cannotSelfBlock'));
      return;
    }
    const newVal = !profile.is_blocked;
    const { error } = await supabase.rpc('admin_toggle_professional_block', {
      p_professional_id: profile.id,
      p_blocked: newVal,
    });
    if (error) {
      toast.error(t('admin.users.toggleError'));
      return;
    }
    toast.success(newVal ? t('admin.users.blockedToast') : t('admin.users.unblockedToast'));
    load(profile.id, () => false);
  };

  const getInitials = (name: string | null) =>
    (name || 'U').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);

  const formatDate = (d: string | null) =>
    d ? new Date(d).toLocaleDateString(localeTag[i18n.language] ?? 'pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }) : '—';

  const isPastDue = profile?.subscription_status === 'past_due';
  // null quando a carência já acabou — mesma semântica do banner in-app.
  const graceDays = isPastDue ? graceDaysRemaining(profile?.past_due_since) : null;
  // A cor carrega a urgência: verde para ativo, âmbar para quem ainda tem
  // prazo, vermelho para quem já perdeu o acesso. Sem isso, os dois estados
  // de 'past_due' ficam com o mesmo cinza e a tela não distingue nada.
  const statusVariant = profile?.subscription_status === 'active'
    ? 'baixa'
    : isPastDue
      ? (graceDays === null ? 'alta' : 'media')
      : 'neutral';

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex flex-col gap-4">
          {[1, 2, 3].map(i => <div key={i} className="bg-h-white rounded-r shadow-h-sm h-[100px] animate-pulse" />)}
        </div>
      </AdminLayout>
    );
  }

  if (!profile) return <AdminLayout><p className="text-h-text-3">{t('admin.userDetail.notFound')}</p></AdminLayout>;

  return (
    <PageTransition>
    <AdminLayout>
      <button onClick={() => navigate('/admin/usuarios')} className="flex items-center gap-1 text-h-g-start text-[13px] font-semibold mb-4">
        <ChevronLeft size={16} /> {t('admin.userDetail.back')}
      </button>

      {/* Profile header */}
      <div className="bg-h-white rounded-r shadow-h-sm p-5 mb-4">
        <div className="flex items-center gap-4">
          <div
            className="w-[56px] h-[56px] rounded-full flex items-center justify-center text-[18px] font-bold flex-shrink-0"
            style={{ background: '#BF5F82', color: '#fff' }}
          >
            {getInitials(profile.full_name)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[18px] font-extrabold text-h-text">{profile.full_name || t('admin.userDetail.noName')}</p>
            <p className="text-[12px] text-h-text-3">{profile.specialty || t('admin.userDetail.noSpecialty')}</p>
            <div className="flex items-center gap-2 mt-1">
              <HarmonizeBadge variant={profile.is_blocked ? 'alta' : 'baixa'}>
                {profile.is_blocked ? t('admin.users.blocked') : t('admin.users.active')}
              </HarmonizeBadge>
              <HarmonizeBadge variant="neutral">{profile.role || 'professional'}</HarmonizeBadge>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-h-white rounded-r shadow-h-sm p-4 text-center">
          <p className="text-[22px] font-extrabold text-h-text">{sessionCount}</p>
          <p className="text-[10px] font-semibold text-h-text-3">{t('admin.userDetail.stats.totalSessions')}</p>
        </div>
        <div className="bg-h-white rounded-r shadow-h-sm p-4 text-center">
          <p className="text-[22px] font-extrabold text-h-text">—</p>
          <p className="text-[10px] font-semibold text-h-text-3">{t('admin.userDetail.stats.thisMonth')}</p>
        </div>
        <div className="bg-h-white rounded-r shadow-h-sm p-4 text-center">
          <p className="text-[22px] font-extrabold text-h-text">—</p>
          <p className="text-[10px] font-semibold text-h-text-3">{t('admin.userDetail.stats.lastAccess')}</p>
        </div>
      </div>

      {/* Details */}
      <div className="bg-h-white rounded-r shadow-h-sm p-5 mb-4">
        <p className="text-[15px] font-bold text-h-text mb-3">{t('admin.userDetail.profileData')}</p>
        {[
          { label: t('admin.userDetail.fields.council'), value: `${profile.council_type || '—'} ${profile.council_number || ''}` },
          { label: t('admin.userDetail.fields.clinic'), value: profile.clinic_name || '—' },
          { label: t('admin.userDetail.fields.phone'), value: profile.phone || '—' },
          { label: t('admin.userDetail.fields.country'), value: profile.country || '—' },
          { label: t('admin.userDetail.fields.createdAt'), value: formatDate(profile.created_at) },
        ].map(row => (
          <div key={row.label} className="flex justify-between py-2 border-b border-h-surface-3 last:border-0">
            <span className="text-[12px] text-h-text-3">{row.label}</span>
            <span className="text-[12px] font-medium text-h-text">{row.value}</span>
          </div>
        ))}
      </div>

      {/* Subscription */}
      {/*
        'past_due' concede GRACE_PERIOD_DAYS de acesso antes do bloqueio
        efetivo (ver src/lib/subscriptionAccess.ts). Até aqui esta tela
        mostrava só o status cru, então quem ainda tem prazo e quem já perdeu
        o acesso apareciam idênticos: o mesmo texto "past_due", o mesmo
        cinza. É a tela que a equipe abre justamente quando o profissional
        liga dizendo que não consegue entrar, e ela não respondia a única
        pergunta que importa nessa hora.

        Os dias vêm de graceDaysRemaining — a mesma função que o banner
        in-app usa, para os dois nunca discordarem sobre quanto resta.
      */}
      <div className="bg-h-white rounded-r shadow-h-sm p-5 mb-4">
        <p className="text-[15px] font-bold text-h-text mb-3">{t('admin.userDetail.subscription')}</p>
        <div className="flex justify-between py-2">
          <span className="text-[12px] text-h-text-3">{t('admin.userDetail.status')}</span>
          <HarmonizeBadge variant={statusVariant}>
            {profile.subscription_status || 'inactive'}
          </HarmonizeBadge>
        </div>

        {isPastDue && (
          <>
            <div className="flex justify-between py-2 border-t border-h-surface-3">
              <span className="text-[12px] text-h-text-3">{t('admin.userDetail.grace.label')}</span>
              <span className="text-[12px] font-medium text-h-text">
                {graceDays === null
                  ? t('admin.userDetail.grace.ended')
                  : t('admin.userDetail.grace.remaining', { count: graceDays })}
              </span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-[12px] text-h-text-3">{t('admin.userDetail.grace.sinceLabel')}</span>
              <span className="text-[12px] font-medium text-h-text">
                {formatDate(profile.past_due_since)}
              </span>
            </div>
          </>
        )}
      </div>

      {/* Actions */}
      {profile.id === user?.id ? (
        <p className="text-[12px] text-h-text-3">{t('admin.users.cannotSelfBlock')}</p>
      ) : (
        <div className="flex gap-3">
          {profile.is_blocked ? (
            <GradientButton onClick={toggleBlock}>{t('admin.userDetail.unblockUser')}</GradientButton>
          ) : (
            <SecondaryButton onClick={toggleBlock} className="border border-h-red/20">
              <span style={{ color: '#E05050' }}>{t('admin.userDetail.blockUser')}</span>
            </SecondaryButton>
          )}
        </div>
      )}
    </AdminLayout>
    </PageTransition>
  );
};

export default AdminUsuarioDetalhe;
