import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AdminMetricas from "./AdminMetricas";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: { from: (...args: unknown[]) => fromMock(...args) },
}));

const PROFILES = [
  { id: "admin-1", full_name: "Admin Principal", clinic_name: null, currency: "BRL", labor_fee_per_session: null, role: "admin" },
  { id: "pro-1", full_name: "Dra. Ana", clinic_name: "Clínica Bela", currency: "BRL", labor_fee_per_session: 100, role: "professional" },
  { id: "pro-2", full_name: "Dr. Bruno", clinic_name: null, currency: "BRL", labor_fee_per_session: null, role: "professional" },
];

const SESSIONS = [
  { professional_id: "pro-1", patient_id: "pat-1", status: "complete", created_at: "2026-09-01T10:00:00.000Z", stage2_overlay: null },
  { professional_id: "pro-1", patient_id: "pat-1", status: "stage1", created_at: "2026-09-02T10:00:00.000Z", stage2_overlay: null },
];

const INSUMOS: unknown[] = [];

/**
 * Builder que devolve dados diferentes por tabela (`.from(table)`), já que
 * esta tela — diferente das outras de admin — consulta `profiles`,
 * `sessions` E `insumos` em paralelo, além do lookup de role feito pelo
 * próprio AdminLayout (`profiles` + `.single()`).
 */
function makeBuilder(table: string) {
  let isSingle = false;
  // `.range(from, to)` recorta de verdade, em vez de devolver a lista inteira
  // a cada página: a tela lê essas tabelas por `fetchAllRows`, que pagina até
  // a primeira página curta. Um duplo que ignorasse o recorte devolveria a
  // lista completa em toda página e a paginação nunca terminaria — ou pior,
  // passaria mesmo com um bug de recorte na tela.
  let rangeFrom: number | null = null;
  let rangeTo: number | null = null;
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    range: (from: number, to: number) => {
      rangeFrom = from;
      rangeTo = to;
      return builder;
    },
    single: () => {
      isSingle = true;
      return builder;
    },
    then: (onFulfilled: any) => {
      const paginate = (rows: unknown[]) =>
        rangeFrom === null || rangeTo === null ? rows : rows.slice(rangeFrom, rangeTo + 1);

      let result: unknown;
      if (table === "profiles") {
        result = isSingle ? { data: { role: "admin" } } : { data: paginate(PROFILES) };
      } else if (table === "sessions") {
        result = { data: paginate(SESSIONS) };
      } else if (table === "insumos") {
        result = { data: paginate(INSUMOS) };
      } else {
        result = { data: [] };
      }
      return Promise.resolve(result).then(onFulfilled);
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/admin/metricas"]}>
      <AdminMetricas />
    </MemoryRouter>
  );

describe("AdminMetricas", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockReset();
    fromMock.mockImplementation((table: string) => makeBuilder(table));
  });

  it("lists every non-admin professional, even one with zero sessions, with sessions/conversion computed", async () => {
    renderPage();

    await waitFor(() => expect(screen.getByText("Métricas por Profissional")).toBeInTheDocument());
    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    // pro-1: 2 sessions, 1 "complete" -> 50% conversion.
    const anaRow = screen.getByText("Dra. Ana").closest("tr")!;
    expect(anaRow).toHaveTextContent("2"); // sessions count
    expect(anaRow).toHaveTextContent("50%");

    // pro-2 has no sessions at all but must still show up, zeroed.
    const brunoRow = screen.getByText("Dr. Bruno").closest("tr")!;
    expect(brunoRow).toHaveTextContent("0%");

    // The admin's own row is never listed as a "professional" here.
    expect(screen.queryByText("Admin Principal")).not.toBeInTheDocument();
  });

  it("filters the table by a search matching professional or clinic name", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    fireEvent.change(screen.getByPlaceholderText("Buscar por profissional ou clínica..."), {
      target: { value: "Bela" },
    });

    await waitFor(() => expect(screen.queryByText("Dr. Bruno")).not.toBeInTheDocument());
    expect(screen.getByText("Dra. Ana")).toBeInTheDocument();
  });

  it("shows an empty state when the search matches nobody", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    fireEvent.change(screen.getByPlaceholderText("Buscar por profissional ou clínica..."), {
      target: { value: "ninguém encontrado aqui" },
    });

    await waitFor(() => expect(screen.getByText("Nenhum profissional encontrado")).toBeInTheDocument());
  });

  /**
   * O PostgREST aplica o teto de linhas por resposta (Max Rows, 1000 por
   * padrão) EM SILÊNCIO: devolve 1000 linhas com `error: null`. Sem
   * paginação, a contagem de sessões por profissional — e, com ela,
   * conversão, receita estimada e taxa de retorno — passaria a ser calculada
   * sobre esse recorte assim que o total GLOBAL de sessões do sistema
   * cruzasse o teto. Achado do ciclo 86 do QA Contínuo.
   */
  describe("teto de linhas do PostgREST", () => {
    const PAGE_CAP = 1000;
    const BIG_SESSIONS = Array.from({ length: 1200 }, (_, i) => ({
      professional_id: "pro-1",
      patient_id: `pat-${i}`,
      status: "stage1",
      created_at: "2026-09-01T10:00:00.000Z",
      stage2_overlay: null,
    }));

    beforeEach(() => {
      fromMock.mockImplementation((table: string) => {
        let isSingle = false;
        let rangeFrom: number | null = null;
        let rangeTo: number | null = null;
        const builder: any = {
          select: () => builder,
          eq: () => builder,
          range: (from: number, to: number) => {
            rangeFrom = from;
            rangeTo = to;
            return builder;
          },
          single: () => {
            isSingle = true;
            return builder;
          },
          then: (onFulfilled: any) => {
            // Recorta pelo `.range` pedido E aplica o teto do servidor, que
            // vale mesmo quando ninguém pede recorte nenhum.
            const serve = (rows: unknown[]) => {
              const from = rangeFrom ?? 0;
              const to = rangeTo === null ? rows.length - 1 : rangeTo;
              return rows.slice(from, Math.min(to + 1, from + PAGE_CAP));
            };
            let result: unknown;
            if (table === "profiles") {
              result = isSingle ? { data: { role: "admin" } } : { data: serve(PROFILES) };
            } else if (table === "sessions") {
              result = { data: serve(BIG_SESSIONS) };
            } else if (table === "insumos") {
              result = { data: serve(INSUMOS) };
            } else {
              result = { data: [] };
            }
            return Promise.resolve(result).then(onFulfilled);
          },
        };
        return builder;
      });
    });

    it("counts every session past the row cap instead of only the first page", async () => {
      renderPage();

      await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

      const anaRow = screen.getByText("Dra. Ana").closest("tr")!;
      expect(anaRow).toHaveTextContent(String(BIG_SESSIONS.length));
      expect(anaRow).not.toHaveTextContent(String(PAGE_CAP));
    });
  });
});
