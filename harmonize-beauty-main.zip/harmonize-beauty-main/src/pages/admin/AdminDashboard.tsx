import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AdminLayout from '@/components/harmonize/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';

type Metrics = {
  totalUsers: number;
  activeThisMonth: number;
  totalSessions: number;
  activeSubscribers: number;
};

type StageBreakdown = { label: string; status: string; count: number; pct: number };

// Rótulos de estágio do funil ficam em inglês de propósito — jargão interno
// já usado assim no dashboard mesmo com o restante da UI em português, e por
// isso não passam por tradução (só o texto do admin ao redor é traduzido).
const STAGE_LABELS: Record<string, string> = {
  stage1: 'Stage 1',
  stage2: 'Stage 2',
  stage3: 'Stage 3',
  complete: 'Complete',
};

const AdminDashboard: React.FC = () => {
  const { t } = useTranslation();
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [stages, setStages] = useState<StageBreakdown[]>([]);
  const [errors24h, setErrors24h] = useState(0);
  const [errors7d, setErrors7d] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const last7d = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

      // Contagem por estágio vem do banco, uma contagem exata por status, em
      // vez de trazer uma linha por sessão e contar aqui.
      //
      // Antes: `select('status')` sem paginação alimentava `allSessions`, e
      // `allSessions.length` era o denominador das porcentagens — enquanto o
      // card "Total de Sessões" logo acima usava uma contagem exata. Passando
      // do teto de linhas por resposta do PostgREST (Max Rows, 1000 por
      // padrão, aplicado em silêncio), as duas seções da MESMA tela passariam
      // a discordar do total, sem nenhum aviso de dado parcial.
      //
      // `head: true` não devolve linha nenhuma, então nem existe teto a
      // estourar aqui. Ver src/lib/fetchAllRows.ts. Achado do ciclo 86 do QA
      // Contínuo.
      const STAGE_STATUSES = ['stage1', 'stage2', 'stage3', 'complete'] as const;

      const [
        { count: totalUsers },
        { count: totalSessions },
        { count: activeSubscribers },
        recentSessions,
        stageCounts,
        { count: errCount24h },
        { count: errCount7d },
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('sessions').select('*', { count: 'exact', head: true }),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('subscription_status', 'active'),
        // Profissionais distintos com sessão no mês: precisa das linhas (não
        // há count-distinct via PostgREST), então pagina — um mês com mais de
        // 1000 sessões subnotificaria o número sem isso.
        fetchAllRows<{ professional_id: string | null }>((from, to) =>
          supabase
            .from('sessions')
            .select('professional_id')
            .gte('created_at', startOfMonth.toISOString())
            .range(from, to),
        ),
        Promise.all(
          STAGE_STATUSES.map(async (status) => {
            const { count } = await supabase
              .from('sessions')
              .select('*', { count: 'exact', head: true })
              .eq('status', status);
            return [status, count ?? 0] as const;
          }),
        ),
        supabase.from('error_logs').select('*', { count: 'exact', head: true }).gte('created_at', last24h),
        supabase.from('error_logs').select('*', { count: 'exact', head: true }).gte('created_at', last7d),
      ]);

      const activeThisMonth = new Set(recentSessions.map((s) => s.professional_id)).size;

      // Denominador é a contagem real de sessões, a mesma que o card acima
      // mostra — não o tamanho de um recorte.
      const total = totalSessions || 1;
      const breakdown: StageBreakdown[] = stageCounts.map(([status, count]) => ({
        status,
        label: STAGE_LABELS[status],
        count,
        pct: Math.round((count / total) * 100),
      }));

      setMetrics({
        totalUsers: totalUsers ?? 0,
        activeThisMonth,
        totalSessions: totalSessions ?? 0,
        activeSubscribers: activeSubscribers ?? 0,
      });
      setStages(breakdown);
      setErrors24h(errCount24h ?? 0);
      setErrors7d(errCount7d ?? 0);
      setLoading(false);
    };
    load();
  }, []);

  const METRICS = metrics
    ? [
        { value: String(metrics.totalUsers), label: t('admin.dashboard.metrics.totalUsers') },
        { value: String(metrics.activeThisMonth), label: t('admin.dashboard.metrics.activeThisMonth') },
        { value: String(metrics.totalSessions), label: t('admin.dashboard.metrics.totalSessions') },
        { value: String(metrics.activeSubscribers), label: t('admin.dashboard.metrics.activeSubscribers') },
      ]
    : [];

  return (
    <PageTransition>
    <AdminLayout>
      <h2 className="text-[22px] font-extrabold text-h-text tracking-tight mb-5">{t('admin.dashboard.title')}</h2>

      {/* Metrics grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {(loading ? Array.from({ length: 4 }, () => ({ value: '', label: '' })) : METRICS).map((m, i) => (
          <div key={i} className="bg-h-white rounded-r shadow-h-sm p-4">
            {loading ? (
              <div className="h-[28px] w-16 bg-h-surface-3 rounded animate-pulse mb-1" />
            ) : (
              <p className="text-[28px] font-extrabold leading-none text-h-text">{m.value}</p>
            )}
            <p className="text-[11px] font-semibold text-h-text-3 mt-1">{loading ? '' : m.label}</p>
          </div>
        ))}
      </div>

      {/* Sessions by Stage */}
      <div className="bg-h-white rounded-r shadow-h-sm p-5 mb-4">
        <p className="text-[15px] font-bold text-h-text mb-4">{t('admin.dashboard.sessionsByStage')}</p>
        <div className="flex flex-col gap-3">
          {loading ? (
            [1, 2, 3, 4].map(i => <div key={i} className="h-[16px] bg-h-surface-3 rounded animate-pulse" />)
          ) : (
            stages.map(s => (
              <div key={s.status} className="flex items-center gap-3">
                <span className="text-[12px] font-semibold text-h-text-2 w-[70px] flex-shrink-0">{s.label}</span>
                <div className="flex-1 h-[8px] bg-h-surface-3 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${s.pct}%`, background: '#A855B5' }} />
                </div>
                <span className="text-[12px] font-bold text-h-text w-[36px] text-right">{s.count}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Error rate summary */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-h-white rounded-r shadow-h-sm p-4 text-center">
          <p className="text-[22px] font-extrabold leading-none" style={{ color: errors24h > 0 ? '#D4900A' : '#2DB87A' }}>
            {loading ? '—' : errors24h}
          </p>
          <p className="text-[10px] font-semibold text-h-text-3 mt-1.5">{t('admin.dashboard.errors24h')}</p>
        </div>
        <div className="bg-h-white rounded-r shadow-h-sm p-4 text-center">
          <p className="text-[22px] font-extrabold leading-none" style={{ color: errors7d > 0 ? '#D4900A' : '#2DB87A' }}>
            {loading ? '—' : errors7d}
          </p>
          <p className="text-[10px] font-semibold text-h-text-3 mt-1.5">{t('admin.dashboard.errors7d')}</p>
        </div>
      </div>
    </AdminLayout>
    </PageTransition>
  );
};

export default AdminDashboard;
