import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AdminInteligencia from "./AdminInteligencia";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

// Uma linha crua de cada uma das 3 RPCs (ver src/lib/adminIntelligence.ts),
// já acima de MIN_SAMPLE_SIZE (5) pra não ser cortada no client.
const DOSE_ROWS = [
  { substance: "acido_hialuronico", region: "labio_superior", dose_bucket: "baixa", n: 8, average_rating: 4.2 },
];
const ADVERSE_ROWS = [
  { substance: "acido_hialuronico", brand_name: "Juvederm Voluma", event_type: "nodulo", n: 6 },
];
const FLAG_ROWS = [{ flag_key: "pregnant", n: 12 }];

/**
 * Builder mínimo só para a checagem de role feita por AdminLayout
 * (`.from('profiles').select('role').eq(...).single()`) — mesmo padrão de
 * AdminMetricas.test.tsx/AdminAuditoria.test.tsx. Esta tela não faz nenhuma
 * outra chamada a `.from(...)`, só às 3 RPCs.
 */
function makeProfilesBuilder() {
  const builder: any = {
    select: () => builder,
    eq: () => builder,
    single: () => Promise.resolve({ data: { role: "admin" } }),
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/admin/inteligencia"]}>
      <AdminInteligencia />
    </MemoryRouter>
  );

describe("AdminInteligencia", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockReset();
    fromMock.mockImplementation(() => makeProfilesBuilder());
    rpcMock.mockReset();
  });

  it("renders all three sections when the 3 RPCs succeed", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "admin_dose_accuracy_correlation") return Promise.resolve({ data: DOSE_ROWS, error: null });
      if (fn === "admin_adverse_event_patterns") return Promise.resolve({ data: ADVERSE_ROWS, error: null });
      if (fn === "admin_anamnesis_flag_frequency") return Promise.resolve({ data: FLAG_ROWS, error: null });
      throw new Error(`RPC inesperada: ${fn}`);
    });

    renderPage();

    await waitFor(() => expect(screen.getByText("Central de Inteligência")).toBeInTheDocument());

    // Precisão da simulação por dose — uma linha da tabela.
    expect(await screen.findByText("Lábio Superior")).toBeInTheDocument();
    expect(screen.getByText("4.2")).toBeInTheDocument();

    // Padrões de evento adverso.
    expect(screen.getByText("Juvederm Voluma")).toBeInTheDocument();

    // Frequência de flags de anamnese — só o gráfico usa o rótulo traduzido
    // (a tela não tem tabela pra esta seção), e o `ResponsiveContainer` do
    // recharts não mede largura/altura em jsdom (0x0), então não renderiza o
    // <BarChart> filho — nem em produção, nem em nenhum outro teste deste
    // repositório que usa recharts (ver AdminMetricas.test.tsx). Sinal
    // indireto de sucesso: nem o estado vazio nem o aviso de erro da seção
    // aparecem.
    expect(screen.queryByText("Ainda não há amostra suficiente para mostrar a frequência de flags")).not.toBeInTheDocument();

    // Nenhum aviso de seção nem o bloco de erro cheio.
    expect(screen.queryByText(/Não foi possível carregar/)).not.toBeInTheDocument();
  });

  it("keeps the other two sections rendered when only one of the three RPCs fails (Promise.allSettled, not Promise.all)", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "admin_dose_accuracy_correlation") return Promise.resolve({ data: DOSE_ROWS, error: null });
      if (fn === "admin_adverse_event_patterns") return Promise.resolve({ data: null, error: { message: "boom" } });
      if (fn === "admin_anamnesis_flag_frequency") return Promise.resolve({ data: FLAG_ROWS, error: null });
      throw new Error(`RPC inesperada: ${fn}`);
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Central de Inteligência")).toBeInTheDocument());

    // As duas seções cujas RPCs tiveram sucesso continuam mostrando dado —
    // a tela NÃO cai inteira por causa de 1 das 3 RPCs falhando.
    expect(await screen.findByText("Lábio Superior")).toBeInTheDocument();
    // Flags de anamnese: sem estado vazio nem aviso de erro para esta seção
    // (ver comentário equivalente no teste de sucesso total sobre o
    // ResponsiveContainer do recharts não renderizar em jsdom).
    expect(screen.queryByText("Ainda não há amostra suficiente para mostrar a frequência de flags")).not.toBeInTheDocument();

    // A seção de evento adverso mostra um aviso discreto no lugar do
    // gráfico/tabela, não o bloco de erro cheio da tela inteira.
    expect(screen.getByText("Não foi possível carregar estes dados agora")).toBeInTheDocument();
    expect(screen.queryByText("Juvederm Voluma")).not.toBeInTheDocument();
    expect(screen.queryByText("Não foi possível carregar os dados de inteligência")).not.toBeInTheDocument();
  });

  it("shows the full error state only when all three RPCs fail", async () => {
    rpcMock.mockResolvedValue({ data: null, error: { message: "boom" } });

    renderPage();
    await waitFor(() => expect(screen.getByText("Central de Inteligência")).toBeInTheDocument());

    expect(await screen.findByText("Não foi possível carregar os dados de inteligência")).toBeInTheDocument();
  });

  it("retries only by re-running load() when clicking retry on a failed section", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "admin_dose_accuracy_correlation") return Promise.resolve({ data: DOSE_ROWS, error: null });
      if (fn === "admin_adverse_event_patterns") return Promise.resolve({ data: null, error: { message: "boom" } });
      if (fn === "admin_anamnesis_flag_frequency") return Promise.resolve({ data: FLAG_ROWS, error: null });
      throw new Error(`RPC inesperada: ${fn}`);
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Não foi possível carregar estes dados agora")).toBeInTheDocument());

    rpcMock.mockClear();
    fireEvent.click(screen.getByText("Tentar novamente"));

    await waitFor(() => expect(rpcMock).toHaveBeenCalledWith("admin_dose_accuracy_correlation"));
    expect(rpcMock).toHaveBeenCalledWith("admin_adverse_event_patterns");
    expect(rpcMock).toHaveBeenCalledWith("admin_anamnesis_flag_frequency");
  });
});
