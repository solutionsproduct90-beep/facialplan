import React, { useEffect, useMemo, useState } from 'react';
import { format } from 'date-fns';
import { ptBR, enUS, es, fr, it, type Locale } from 'date-fns/locale';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AdminLayout from '@/components/harmonize/AdminLayout';
import HarmonizeBadge from '@/components/harmonize/Badge';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { ChevronLeft, ChevronRight, RefreshCw, Info, Search, CheckCircle2, AlertTriangle } from 'lucide-react';
import type { AuditAction } from '@/lib/auditLog';
import type { ApplicationPoint, Substance } from '@/types/harmonize';
import { SUBSTANCE_LABEL } from '@/types/harmonize';
import { regionLabel } from '@/lib/faceRegions';
import {
  computeSessionComplianceSummary,
  COMPLIANCE_GATE_ORDER,
  type ComplianceGateKey,
  type SessionComplianceSummary,
} from '@/lib/complianceSummary';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

const localeTag: Record<string, string> = { pt: 'pt-BR', en: 'en-US', es: 'es-ES', fr: 'fr-FR', it: 'it-IT' };

// QA Contínuo ciclo 29: as 3 últimas (gravadas direto pelas RPCs de admin,
// não por logDataAccess()) faltavam aqui — sem elas, um admin investigando
// exclusão permanente de paciente ou bloqueio/desbloqueio de profissional
// não conseguia isolar essas ações pelo filtro, só vasculhando a lista
// inteira. Mantém em sincronia com AuditAction em src/lib/auditLog.ts.
const ACTIONS: AuditAction[] = [
  'view_patient_photo',
  'view_anamnesis',
  'export_pdf',
  'send_anamnesis_link',
  'export_full_record',
  'patient_permanent_deletion',
  'admin_view_session_compliance',
  'admin_toggle_professional_block',
  // Squad w1-5: as 2 do caminho de recuperação de compra da Hotmart. São as
  // únicas ações do produto que concedem assinatura sem o webhook ter casado
  // o pagamento sozinho — precisam ser isoláveis no filtro justamente por
  // isso.
  'hotmart_purchase_self_recovery',
  'admin_link_hotmart_purchase',
];
// Usado pelo filtro "Tipo de recurso" abaixo — os labels de cada valor vêm
// das mesmas chaves `admin.auditLog.resourceType.*` já usadas para exibir
// `resource_type` na tabela, então não há tradução nova a manter em sincronia.
const RESOURCE_TYPES = ['patient', 'session', 'anamnesis', 'profile'] as const;

const ACTION_BADGE: Record<AuditAction, 'alta' | 'media' | 'baixa' | 'grad' | 'neutral'> = {
  view_patient_photo: 'media',
  view_anamnesis: 'grad',
  export_pdf: 'baixa',
  send_anamnesis_link: 'neutral',
  export_full_record: 'alta',
  patient_permanent_deletion: 'alta',
  admin_view_session_compliance: 'media',
  admin_toggle_professional_block: 'alta',
  hotmart_purchase_self_recovery: 'media',
  admin_link_hotmart_purchase: 'alta',
};

const PAGE_SIZE = 20;

type AuditRow = {
  id: string;
  actor_id: string;
  action: string;
  resource_type: string;
  resource_id: string;
  patient_id: string | null;
  created_at: string;
};

type ProfessionalOption = { id: string; full_name: string | null };

const shortId = (id: string) => `${id.slice(0, 8)}…`;

// Shape de retorno de `admin_get_session_compliance_context` (ver
// supabase/migrations/20260911100000_add_admin_session_compliance_rpc.sql)
// — uma única RPC estreita em vez de novas policies de admin em
// anamnesis/consents/patients (mesma decisão já registrada ali e em
// 20260910210000_audit_log_admin_view_and_patient_link.sql).
type SessionComplianceContext = {
  session: { id: string; created_at: string | null; stage2_overlay: ApplicationPoint[] };
  patient: { name: string | null; consent_given: boolean | null; last_consent_at: string | null } | null;
  anamnesis: { created_at: string | null } | null;
  procedure_consent: { created_at: string | null; consent_text: string | null; ip_address: string | null } | null;
  skin_screening: {
    has_suspicious_finding: boolean;
    referred_to_dermatology: boolean;
    proceeded_despite_finding: boolean;
    proceed_justification: string | null;
    updated_at: string | null;
  } | null;
  past_toxin_sessions: { created_at: string | null; stage2_overlay: ApplicationPoint[] }[];
};

type ComplianceLookupResult = {
  patientName: string | null;
  sessionCreatedAt: string | null;
  summary: SessionComplianceSummary;
};

/**
 * Visão de admin sobre `audit_log` (/admin/auditoria — item P2 do backlog
 * "Log de auditoria só melhor esforço": até aqui a tabela existia e era
 * alimentada (ver src/lib/auditLog.ts e supabase/migrations/20260910170000_add_audit_log.sql)
 * mas não tinha nenhuma UI pra consumir os dados — os registros só existiam
 * pra uma eventual investigação manual via SQL). Filtros: profissional,
 * ação, período e paciente (por id — ver nota abaixo), paginado no servidor.
 *
 * Paginação real (range() + count: 'exact'), diferente das outras telas de
 * admin (AdminUsuarios/AdminMetricas), que buscam tudo e filtram no client —
 * audit_log pode crescer sem limite (uma linha por leitura sensível, sem
 * expurgo), então trazer a tabela inteira pro browser não escala.
 *
 * Filtro por paciente é por ID colado, não por busca de nome: mostrar o
 * NOME ao lado do ID (ver `patientNames`) já usa o mínimo necessário —
 * `admin_resolve_patient_names`, que só resolve os ids que já apareceram
 * nesta página de resultados (não é um endpoint de busca) — porque abrir uma
 * policy de "admin lê todos os pacientes" só para permitir buscar por nome
 * aqui alargaria o acesso do admin a uma tabela com telefone/anotações
 * clínicas, bem além do que este painel precisa. Clicar em "Ver tudo deste
 * paciente" numa linha preenche o filtro com o patient_id daquela linha —
 * dá pra navegar o histórico de um paciente sem precisar buscar por nome.
 */
const AdminAuditoria: React.FC = () => {
  const { t, i18n } = useTranslation();

  const [professionals, setProfessionals] = useState<ProfessionalOption[]>([]);
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [patientNames, setPatientNames] = useState<Record<string, string>>({});
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  // Filtros aplicados (o que efetivamente vira query). Profissional/ação
  // disparam a query assim que trocam (select discreto); data/paciente têm
  // um rascunho separado abaixo, só aplicado ao clicar "Aplicar" — evitar
  // uma query por tecla digitada no campo de ID/data.
  const [professionalId, setProfessionalId] = useState('');
  const [action, setAction] = useState('');
  const [resourceType, setResourceType] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [patientId, setPatientId] = useState('');

  const [draftDateFrom, setDraftDateFrom] = useState('');
  const [draftDateTo, setDraftDateTo] = useState('');
  const [draftPatientId, setDraftPatientId] = useState('');

  // Selo de Conformidade Clínica por Sessão (P6-2, ver
  // src/lib/complianceSummary.ts) — busca independente da tabela de log
  // acima: dado o ID de UMA sessão, reconstrói o mesmo resumo já usado no
  // PDF do profissional (SessaoEstagio3.tsx), via a RPC estreita
  // `admin_get_session_compliance_context`.
  const [complianceSessionIdDraft, setComplianceSessionIdDraft] = useState('');
  const [complianceLoading, setComplianceLoading] = useState(false);
  const [complianceError, setComplianceError] = useState(false);
  const [complianceNotFound, setComplianceNotFound] = useState(false);
  const [complianceResult, setComplianceResult] = useState<ComplianceLookupResult | null>(null);

  const runComplianceLookup = async () => {
    const sessionId = complianceSessionIdDraft.trim();
    if (!sessionId) return;
    setComplianceLoading(true);
    setComplianceError(false);
    setComplianceNotFound(false);
    setComplianceResult(null);
    try {
      const { data, error } = await supabase.rpc('admin_get_session_compliance_context', { p_session_id: sessionId });
      if (error) throw error;
      if (!data) {
        setComplianceNotFound(true);
        return;
      }
      const ctx = data as unknown as SessionComplianceContext;

      // Mesmo reduce de src/pages/SessaoEstagio2.tsx/SessaoEstagio3.tsx
      // (lastToxinDatesByRegion): última data de toxina prévia por região,
      // a partir das sessões concluídas que a RPC já trouxe.
      const priorToxinDatesByRegion: Record<string, string> = {};
      (ctx.past_toxin_sessions ?? []).forEach((past) => {
        if (!past.created_at) return;
        (past.stage2_overlay ?? []).forEach((p) => {
          if (p.substance !== 'toxina_botulinica') return;
          const current = priorToxinDatesByRegion[p.region];
          if (!current || new Date(past.created_at as string) > new Date(current)) {
            priorToxinDatesByRegion[p.region] = past.created_at as string;
          }
        });
      });

      const summary = computeSessionComplianceSummary({
        sessionId: ctx.session.id,
        sessionCreatedAt: ctx.session.created_at,
        applicationPoints: ctx.session.stage2_overlay,
        skinScreening: ctx.skin_screening
          ? {
              hasSuspiciousFinding: ctx.skin_screening.has_suspicious_finding,
              referredToDermatology: ctx.skin_screening.referred_to_dermatology,
              proceededDespiteFinding: ctx.skin_screening.proceeded_despite_finding,
              proceedJustification: ctx.skin_screening.proceed_justification,
              updatedAt: ctx.skin_screening.updated_at,
            }
          : null,
        anamnesisCreatedAt: ctx.anamnesis?.created_at ?? null,
        patientConsentGiven: ctx.patient?.consent_given ?? null,
        patientLastConsentAt: ctx.patient?.last_consent_at ?? null,
        procedureConsent: ctx.procedure_consent
          ? {
              createdAt: ctx.procedure_consent.created_at,
              consentText: ctx.procedure_consent.consent_text,
              ipAddress: ctx.procedure_consent.ip_address,
            }
          : null,
        priorToxinDatesByRegion,
      });

      setComplianceResult({
        patientName: ctx.patient?.name ?? null,
        sessionCreatedAt: ctx.session.created_at,
        summary,
      });
    } catch {
      setComplianceError(true);
    } finally {
      setComplianceLoading(false);
    }
  };

  const complianceContextLabel = (key: ComplianceGateKey, context: string[]): string => {
    if (context.length === 0) return '';
    if (key === 'doseThreshold') {
      return context.map((s) => SUBSTANCE_LABEL[s as Substance] ?? s).join(', ');
    }
    return context.map((r) => regionLabel(r)).join(', ');
  };

  const actorNameById = useMemo(() => {
    const map: Record<string, string> = {};
    for (const p of professionals) map[p.id] = p.full_name || t('admin.auditLog.unnamedProfessional');
    return map;
  }, [professionals, t]);

  useEffect(() => {
    // Paginado (src/lib/fetchAllRows.ts): lista do sistema inteiro, usada
    // pra resolver o nome do ator de cada linha de auditoria e pra filtrar
    // por profissional. Um perfil fora do teto silencioso do PostgREST (Max
    // Rows, 1000 por padrão) apareceria como ator desconhecido e ficaria de
    // fora do filtro. Mesma classe do ciclo 86.
    void fetchAllRows<ProfessionalOption>((from, to) =>
      supabase
        .from('profiles')
        .select('id, full_name')
        .order('full_name', { ascending: true })
        .range(from, to),
    )
      .then((data) => setProfessionals(data))
      .catch(() => setProfessionals([]));
  }, []);

  const load = async () => {
    setLoading(true);
    setHasError(false);
    try {
      let query = supabase
        .from('audit_log')
        .select('id, actor_id, action, resource_type, resource_id, patient_id, created_at', { count: 'exact' })
        .order('created_at', { ascending: false });

      if (professionalId) query = query.eq('actor_id', professionalId);
      if (action) query = query.eq('action', action);
      if (resourceType) query = query.eq('resource_type', resourceType);
      if (patientId) query = query.eq('patient_id', patientId);
      if (dateFrom) query = query.gte('created_at', new Date(`${dateFrom}T00:00:00`).toISOString());
      if (dateTo) query = query.lte('created_at', new Date(`${dateTo}T23:59:59.999`).toISOString());

      const { data, count, error } = await query.range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      if (error) throw error;

      const list = (data as AuditRow[]) ?? [];
      setRows(list);
      setTotalCount(count ?? 0);

      // Resolve nome só dos pacientes que apareceram nesta página — ver
      // comentário de escopo no topo do arquivo.
      const ids = Array.from(new Set(list.map((r) => r.patient_id).filter((id): id is string => !!id)));
      if (ids.length > 0) {
        const { data: names } = await supabase.rpc('admin_resolve_patient_names', { p_patient_ids: ids });
        const map: Record<string, string> = {};
        for (const n of names ?? []) map[n.id] = n.name;
        setPatientNames(map);
      } else {
        setPatientNames({});
      }
    } catch {
      setHasError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [professionalId, action, resourceType, dateFrom, dateTo, patientId, page]);

  const applyDraftFilters = () => {
    setPage(0);
    setDateFrom(draftDateFrom);
    setDateTo(draftDateTo);
    setPatientId(draftPatientId.trim());
  };

  const clearFilters = () => {
    setProfessionalId('');
    setAction('');
    setResourceType('');
    setDateFrom('');
    setDateTo('');
    setPatientId('');
    setDraftDateFrom('');
    setDraftDateTo('');
    setDraftPatientId('');
    setPage(0);
  };

  const viewAllForPatient = (id: string) => {
    setDraftPatientId(id);
    setPatientId(id);
    setPage(0);
  };

  const formatDateTime = (iso: string) =>
    new Date(iso).toLocaleString(localeTag[i18n.language] ?? 'pt-BR', {
      day: '2-digit',
      month: 'short',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });

  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
  const hasFiltersApplied = !!(professionalId || action || resourceType || dateFrom || dateTo || patientId);

  const inputClass =
    'bg-h-white rounded-r-sm shadow-h-sm px-3 h-[40px] text-[13px] text-h-text outline-none placeholder:text-h-text-3 border-none';

  return (
    <PageTransition>
      <AdminLayout>
        <h2 className="text-[22px] font-extrabold text-h-text tracking-tight mb-2">{t('admin.auditLog.title')}</h2>

        {/* Nota de limitação — o próprio backlog documenta isto (ver
            supabase/migrations/20260910170000_add_audit_log.sql): melhor
            esforço, disparado pelo client após a leitura, não cobre acesso
            via API/token adulterado que nunca chame a RPC de log. */}
        <div
          className="flex items-start gap-2 rounded-r p-3 mb-4"
          style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
        >
          <Info size={15} className="flex-shrink-0 mt-0.5" style={{ color: '#D4900A' }} />
          <p className="text-[11.5px] leading-relaxed" style={{ color: '#8A6300' }}>
            {t('admin.auditLog.limitationNotice')}
          </p>
        </div>

        {/* Selo de Conformidade Clínica por Sessão (P6-2) — busca própria,
            independente do log/filtros abaixo: dado o ID de uma sessão,
            reconstrói o mesmo resumo de gates já usado no PDF do
            profissional (ver src/lib/complianceSummary.ts). */}
        <div className="bg-h-white rounded-r shadow-h-sm p-4 mb-4 flex flex-col gap-3">
          <div>
            <h3 className="text-[15px] font-bold text-h-text">{t('admin.auditLog.sessionCompliance.title')}</h3>
            <p className="text-[12px] text-h-text-3 leading-relaxed mt-0.5">
              {t('admin.auditLog.sessionCompliance.description')}
            </p>
          </div>
          <form
            className="flex flex-wrap gap-2"
            onSubmit={(e) => { e.preventDefault(); runComplianceLookup(); }}
          >
            <input
              type="text"
              value={complianceSessionIdDraft}
              onChange={(e) => setComplianceSessionIdDraft(e.target.value)}
              placeholder={t('admin.auditLog.sessionCompliance.sessionIdPlaceholder')}
              className={`${inputClass} flex-1 min-w-[220px]`}
            />
            <button
              type="submit"
              disabled={complianceLoading || !complianceSessionIdDraft.trim()}
              className="flex items-center gap-1.5 text-[12px] font-bold px-3 py-1.5 rounded-full disabled:opacity-40"
              style={{ backgroundColor: 'rgba(168,85,181,0.10)', color: '#A855B5', minHeight: 36 }}
            >
              <Search size={13} />
              {t('admin.auditLog.sessionCompliance.searchButton')}
            </button>
          </form>

          {complianceLoading && (
            <div className="flex flex-col gap-2">
              {[1, 2, 3].map((i) => <div key={i} className="h-[36px] bg-h-surface-3 rounded animate-pulse" />)}
            </div>
          )}

          {!complianceLoading && complianceError && (
            <p className="text-[13px] text-h-text-2">{t('admin.auditLog.sessionCompliance.error')}</p>
          )}

          {!complianceLoading && complianceNotFound && (
            <p className="text-[13px] text-h-text-3">{t('admin.auditLog.sessionCompliance.notFound')}</p>
          )}

          {!complianceLoading && complianceResult && (
            <div className="flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-[13px] font-semibold text-h-text-2">
                  {t('admin.auditLog.sessionCompliance.patientLabel', {
                    name: complianceResult.patientName || t('admin.auditLog.sessionCompliance.unknownPatient'),
                  })}
                  <span className="text-h-text-3 font-normal">
                    {'  ·  '}
                    {t('admin.auditLog.sessionCompliance.sessionDateLabel', {
                      date: complianceResult.sessionCreatedAt
                        ? format(new Date(complianceResult.sessionCreatedAt), 'P', { locale: dateFnsLocale[i18n.language] ?? ptBR })
                        : t('admin.auditLog.sessionCompliance.noSessionDate'),
                    })}
                  </span>
                </p>
                <HarmonizeBadge variant={complianceResult.summary.allMet ? 'baixa' : 'media'}>
                  {complianceResult.summary.allMet
                    ? t('admin.auditLog.sessionCompliance.allMetBanner')
                    : t('admin.auditLog.sessionCompliance.someAttentionBanner')}
                </HarmonizeBadge>
              </div>

              <div className="flex flex-col gap-2">
                {COMPLIANCE_GATE_ORDER
                  .map((key) => complianceResult.summary.gates.find((g) => g.key === key))
                  .filter((g): g is (typeof complianceResult.summary.gates)[number] => Boolean(g))
                  .map((gate) => {
                    const met = gate.status === 'met';
                    const dateStr = gate.at
                      ? format(new Date(gate.at), 'P', { locale: dateFnsLocale[i18n.language] ?? ptBR })
                      : t('sessions.stage3.pdf.compliance.noDate');
                    const detail = complianceContextLabel(gate.key, gate.context);
                    return (
                      <div
                        key={gate.key}
                        className="flex items-start gap-2.5 p-2.5 rounded-r-sm"
                        style={{ background: met ? 'rgba(45,184,122,0.06)' : 'rgba(212,144,10,0.06)' }}
                      >
                        {met ? (
                          <CheckCircle2 size={16} className="flex-shrink-0 mt-0.5" style={{ color: '#2DB87A' }} />
                        ) : (
                          <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" style={{ color: '#D4900A' }} />
                        )}
                        <div className="flex flex-col gap-0.5">
                          <p className="text-[13px] font-semibold text-h-text">
                            {t(`sessions.stage3.pdf.compliance.gates.${gate.key}`)}
                          </p>
                          <p className="text-[12px]" style={{ color: met ? '#6B6965' : '#8A6300' }}>
                            {t(met ? 'sessions.stage3.pdf.compliance.statusMet' : 'sessions.stage3.pdf.compliance.statusAttention', { date: dateStr })}
                          </p>
                          {detail && (
                            <p className="text-[11.5px] text-h-text-3">
                              {t('sessions.stage3.pdf.compliance.detailLine', { detail })}
                            </p>
                          )}
                          {gate.fingerprint && (
                            <p className="text-[11.5px] text-h-text-3 font-mono">
                              {t('sessions.stage3.pdf.compliance.fingerprintLine', { hash: gate.fingerprint })}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}
        </div>

        {/* Filtros */}
        <div className="bg-h-white rounded-r shadow-h-sm p-4 mb-4 flex flex-col gap-3">
          <div className="flex flex-wrap gap-2">
            <select
              value={professionalId}
              onChange={(e) => { setPage(0); setProfessionalId(e.target.value); }}
              className={inputClass}
            >
              <option value="">{t('admin.auditLog.filters.allProfessionals')}</option>
              {professionals.map((p) => (
                <option key={p.id} value={p.id}>{p.full_name || t('admin.auditLog.unnamedProfessional')}</option>
              ))}
            </select>

            <select
              value={action}
              onChange={(e) => { setPage(0); setAction(e.target.value); }}
              className={inputClass}
            >
              <option value="">{t('admin.auditLog.filters.allActions')}</option>
              {ACTIONS.map((a) => (
                <option key={a} value={a}>{t(`admin.auditLog.actions.${a}`)}</option>
              ))}
            </select>

            <select
              value={resourceType}
              onChange={(e) => { setPage(0); setResourceType(e.target.value); }}
              className={inputClass}
            >
              <option value="">{t('admin.auditLog.filters.allResourceTypes')}</option>
              {RESOURCE_TYPES.map((r) => (
                <option key={r} value={r}>{t(`admin.auditLog.resourceType.${r}`)}</option>
              ))}
            </select>

            <input
              type="date"
              value={draftDateFrom}
              onChange={(e) => setDraftDateFrom(e.target.value)}
              className={inputClass}
              aria-label={t('admin.auditLog.filters.dateFrom')}
            />
            <input
              type="date"
              value={draftDateTo}
              onChange={(e) => setDraftDateTo(e.target.value)}
              className={inputClass}
              aria-label={t('admin.auditLog.filters.dateTo')}
            />
            <input
              type="text"
              value={draftPatientId}
              onChange={(e) => setDraftPatientId(e.target.value)}
              placeholder={t('admin.auditLog.filters.patientIdPlaceholder')}
              className={`${inputClass} flex-1 min-w-[180px]`}
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={applyDraftFilters}
              className="text-[12px] font-bold px-3 py-1.5 rounded-full"
              style={{ backgroundColor: 'rgba(168,85,181,0.10)', color: '#A855B5', minHeight: 36 }}
            >
              {t('admin.auditLog.filters.apply')}
            </button>
            {hasFiltersApplied && (
              <button
                onClick={clearFilters}
                className="text-[12px] font-medium text-h-text-3 px-2"
                style={{ minHeight: 36 }}
              >
                {t('admin.auditLog.filters.clear')}
              </button>
            )}
          </div>
        </div>

        {/* Tabela */}
        <div className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
          {loading ? (
            <div className="p-5 flex flex-col gap-3">
              {[1, 2, 3, 4].map((i) => <div key={i} className="h-[40px] bg-h-surface-3 rounded animate-pulse" />)}
            </div>
          ) : hasError ? (
            <div className="p-8 flex flex-col items-center gap-2 text-center">
              <p className="text-[14px] text-h-text-2">{t('admin.auditLog.error')}</p>
              <button
                onClick={load}
                className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
                style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
              >
                <RefreshCw size={14} />
                {t('admin.auditLog.retry')}
              </button>
            </div>
          ) : rows.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-[14px] text-h-text-3">{t('admin.auditLog.empty')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="border-b border-h-surface-3">
                    <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.auditLog.table.date')}</th>
                    <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.auditLog.table.professional')}</th>
                    <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.auditLog.table.action')}</th>
                    <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.auditLog.table.resource')}</th>
                    <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.auditLog.table.patient')}</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="border-b border-h-surface-3 last:border-0">
                      <td className="py-3 px-4 text-h-text-3 whitespace-nowrap">{formatDateTime(r.created_at)}</td>
                      <td className="py-3 px-4 text-h-text-2 font-medium">
                        {actorNameById[r.actor_id] ?? shortId(r.actor_id)}
                      </td>
                      <td className="py-3 px-4">
                        <HarmonizeBadge variant={ACTION_BADGE[r.action as AuditAction] ?? 'neutral'}>
                          {t(`admin.auditLog.actions.${r.action}`, { defaultValue: r.action })}
                        </HarmonizeBadge>
                      </td>
                      <td className="py-3 px-4 text-h-text-3">
                        {t(`admin.auditLog.resourceType.${r.resource_type}`, { defaultValue: r.resource_type })}
                        <span className="text-h-text-3"> · {shortId(r.resource_id)}</span>
                      </td>
                      <td className="py-3 px-4">
                        {r.patient_id ? (
                          <button
                            onClick={() => viewAllForPatient(r.patient_id as string)}
                            className="text-h-text-2 font-medium hover:underline text-left"
                            title={t('admin.auditLog.filterByThisPatient')}
                          >
                            {patientNames[r.patient_id] ?? shortId(r.patient_id)}
                          </button>
                        ) : (
                          <span className="text-h-text-3">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Paginação */}
        {!loading && !hasError && totalCount > 0 && (
          <div className="flex items-center justify-between mt-3">
            <p className="text-[11.5px] text-h-text-3">
              {t('admin.auditLog.pagination.summary', {
                from: page * PAGE_SIZE + 1,
                to: Math.min(totalCount, page * PAGE_SIZE + rows.length),
                total: totalCount,
              })}
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
                className="flex items-center justify-center rounded-full disabled:opacity-30"
                style={{ width: 32, height: 32, color: '#6B6965' }}
                aria-label={t('admin.auditLog.pagination.previous')}
              >
                <ChevronLeft size={16} />
              </button>
              <span className="text-[11.5px] text-h-text-3 px-1">
                {t('admin.auditLog.pagination.pageOf', { page: page + 1, totalPages })}
              </span>
              <button
                onClick={() => setPage((p) => (p + 1 < totalPages ? p + 1 : p))}
                disabled={page + 1 >= totalPages}
                className="flex items-center justify-center rounded-full disabled:opacity-30"
                style={{ width: 32, height: 32, color: '#6B6965' }}
                aria-label={t('admin.auditLog.pagination.next')}
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </AdminLayout>
    </PageTransition>
  );
};

export default AdminAuditoria;
