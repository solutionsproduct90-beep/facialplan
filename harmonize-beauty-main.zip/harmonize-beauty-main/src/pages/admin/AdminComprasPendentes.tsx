import React, { useEffect, useMemo, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import AdminLayout from '@/components/harmonize/AdminLayout';
import HarmonizeBadge from '@/components/harmonize/Badge';
import { Search, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

const localeTag: Record<string, string> = { pt: 'pt-BR', en: 'en-US', es: 'es-ES', fr: 'fr-FR', it: 'it-IT' };

// Visibilidade do admin sobre as compras da Hotmart que chegaram sem dono
// (ver supabase/functions/hotmart-webhook e a migration
// 20260917153000_add_hotmart_pending_purchases.sql). O cadastro e o
// autoatendimento do paywall resolvem sozinhos o caso em que o e-mail da
// compra é o e-mail da conta; o que sobra nesta tela é exatamente o que
// NENHUM caminho automático pode resolver com segurança — pagou com um
// e-mail e se cadastrou com outro — e que antes simplesmente sumia.
//
// O vínculo é manual de propósito: casar dois e-mails diferentes é um ato de
// confiança que exige alguém conferir a transação no painel da Hotmart. Por
// isso a RPC exige admin e grava audit_log (mesmo padrão de
// admin_toggle_professional_block).

type PendingRow = {
  id: string;
  buyer_email: string;
  transaction_id: string | null;
  event: string;
  target_status: string;
  received_at: string;
  claim_requested_by: string | null;
  claim_requested_at: string | null;
  resolved_at: string | null;
  resolved_profile_id: string | null;
  resolution: string | null;
  payload_excerpt: { buyer_name?: string | null; product_name?: string | null } | null;
};

type ProfileOption = { id: string; full_name: string | null; email: string | null };

const STATUS_BADGE: Record<string, 'alta' | 'media' | 'baixa' | 'grad' | 'neutral'> = {
  active: 'baixa',
  past_due: 'media',
  canceled: 'alta',
  refunded: 'alta',
};

const AdminComprasPendentes: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [rows, setRows] = useState<PendingRow[]>([]);
  const [profiles, setProfiles] = useState<ProfileOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [showResolved, setShowResolved] = useState(false);
  // Linha em que o admin abriu o seletor de profissional, e o texto de busca
  // dentro dela. Um de cada vez: vincular é ação destrutiva o bastante pra
  // não deixar dois seletores meio preenchidos na tela ao mesmo tempo.
  const [linkingId, setLinkingId] = useState<string | null>(null);
  const [profileSearch, setProfileSearch] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    // As duas leituras são paginadas (src/lib/fetchAllRows.ts) e nenhuma tem
    // filtro por profissional: a fila do webhook só cresce, e a lista de
    // perfis é a do sistema inteiro. O teto de linhas por resposta do
    // PostgREST (Max Rows, 1000 por padrão) é aplicado em silêncio, com
    // `error: null` — uma compra pendente fora do teto ficaria invisível (e
    // portanto não vinculável), e um profissional fora do teto não apareceria
    // no seletor de vínculo. Mesma classe do ciclo 86.
    // `payload_excerpt` vem como `Json` nos tipos gerados, daí o cast — o
    // mesmo que o código já fazia antes de paginar.
    const data = (await fetchAllRows((from, to) => {
      const query = supabase
        .from('hotmart_pending_purchases')
        .select('id, buyer_email, transaction_id, event, target_status, received_at, claim_requested_by, claim_requested_at, resolved_at, resolved_profile_id, resolution, payload_excerpt')
        .order('received_at', { ascending: false })
        .range(from, to);
      return showResolved ? query : query.is('resolved_at', null);
    }).catch(() => null)) as PendingRow[] | null;
    setRows(data || []);

    const profileData = await fetchAllRows<ProfileOption>((from, to) =>
      supabase
        .from('profiles')
        .select('id, full_name, email')
        .order('created_at', { ascending: false })
        .range(from, to),
    ).catch(() => null);
    setProfiles(profileData || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [showResolved]);

  const profileById = useMemo(() => {
    const map: Record<string, ProfileOption> = {};
    for (const p of profiles) map[p.id] = p;
    return map;
  }, [profiles]);

  // Busca por nome OU e-mail: o e-mail é justamente o que diverge nestes
  // casos, então filtrar só por nome deixaria o admin sem a pista principal.
  const profileMatches = useMemo(() => {
    const term = profileSearch.trim().toLowerCase();
    if (!term) return [];
    return profiles
      .filter(p =>
        (p.full_name || '').toLowerCase().includes(term) ||
        (p.email || '').toLowerCase().includes(term))
      .slice(0, 6);
  }, [profiles, profileSearch]);

  const formatDate = (d: string | null) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString(localeTag[i18n.language] ?? 'pt-BR', {
      day: '2-digit', month: 'short', year: '2-digit',
    });
  };

  const link = async (row: PendingRow, profileId: string) => {
    setSubmitting(true);
    const { error } = await supabase.rpc('admin_link_hotmart_pending_purchase', {
      p_pending_id: row.id,
      p_profile_id: profileId,
    });
    setSubmitting(false);
    if (error) {
      toast.error(t('admin.pendingPurchases.linkError'));
      return;
    }
    toast.success(t('admin.pendingPurchases.linkSuccess'));
    setLinkingId(null);
    setProfileSearch('');
    load();
  };

  const openLinking = (row: PendingRow) => {
    setLinkingId(row.id);
    // Pré-carrega a busca com quem reivindicou, quando alguém reivindicou —
    // é o candidato mais provável, mas continua sendo o admin quem escolhe.
    const claimant = row.claim_requested_by ? profileById[row.claim_requested_by] : undefined;
    setProfileSearch(claimant?.email || claimant?.full_name || '');
  };

  return (
    <PageTransition>
    <AdminLayout>
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-[22px] font-extrabold text-h-text tracking-tight">{t('admin.pendingPurchases.title')}</h2>
        <button onClick={load} className="min-h-[44px] min-w-[44px] flex items-center justify-center text-h-text-3">
          <RefreshCw size={16} />
        </button>
      </div>
      <p className="text-[13px] text-h-text-2 mb-4 leading-relaxed">{t('admin.pendingPurchases.description')}</p>

      <label className="flex items-center gap-2 mb-4 text-[13px] text-h-text-2">
        <input
          type="checkbox"
          checked={showResolved}
          onChange={(e) => setShowResolved(e.target.checked)}
        />
        {t('admin.pendingPurchases.showResolved')}
      </label>

      <div className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
        {loading ? (
          <div className="p-5 flex flex-col gap-3">
            {[1, 2, 3].map(i => <div key={i} className="h-[48px] bg-h-surface-3 rounded animate-pulse" />)}
          </div>
        ) : rows.length === 0 ? (
          <p className="p-5 text-[13px] text-h-text-3">{t('admin.pendingPurchases.empty')}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="border-b border-h-surface-3">
                  <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.pendingPurchases.table.buyer')}</th>
                  <th className="text-left py-3 px-4 font-semibold text-h-text-3">{t('admin.pendingPurchases.table.transaction')}</th>
                  <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.pendingPurchases.table.status')}</th>
                  <th className="text-center py-3 px-4 font-semibold text-h-text-3">{t('admin.pendingPurchases.table.received')}</th>
                  <th className="text-right py-3 px-4 font-semibold text-h-text-3">{t('admin.pendingPurchases.table.actions')}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(row => {
                  const claimant = row.claim_requested_by ? profileById[row.claim_requested_by] : undefined;
                  const resolvedProfile = row.resolved_profile_id ? profileById[row.resolved_profile_id] : undefined;
                  return (
                    <tr key={row.id} className="border-b border-h-surface-3 last:border-0 align-top">
                      <td className="py-3 px-4">
                        <p className="text-[13px] font-bold text-h-text">{row.buyer_email}</p>
                        {row.payload_excerpt?.buyer_name ? (
                          <p className="text-[10px] text-h-text-3">{row.payload_excerpt.buyer_name}</p>
                        ) : null}
                        {claimant && !row.resolved_at ? (
                          <p className="text-[10px] mt-1" style={{ color: '#D97706' }}>
                            {t('admin.pendingPurchases.claimedBy', {
                              name: claimant.full_name || claimant.email || claimant.id,
                            })}
                          </p>
                        ) : null}
                      </td>
                      <td className="py-3 px-4 text-h-text-2">
                        <p>{row.transaction_id || '—'}</p>
                        <p className="text-[10px] text-h-text-3">{row.event}</p>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <HarmonizeBadge variant={STATUS_BADGE[row.target_status] ?? 'neutral'}>
                          {row.target_status}
                        </HarmonizeBadge>
                      </td>
                      <td className="py-3 px-4 text-center text-h-text-3">{formatDate(row.received_at)}</td>
                      <td className="py-3 px-4 text-right">
                        {row.resolved_at ? (
                          <div>
                            <HarmonizeBadge variant="baixa">
                              {t(`admin.pendingPurchases.resolution.${row.resolution}`)}
                            </HarmonizeBadge>
                            <p className="text-[10px] text-h-text-3 mt-1">
                              {resolvedProfile?.full_name || resolvedProfile?.email || row.resolved_profile_id}
                            </p>
                          </div>
                        ) : linkingId === row.id ? (
                          <div className="text-left">
                            <div className="flex items-center gap-2 bg-h-surface rounded-r-sm px-2 h-[36px] mb-2">
                              <Search size={14} className="text-h-text-3 flex-shrink-0" />
                              <input
                                type="text"
                                autoFocus
                                value={profileSearch}
                                onChange={(e) => setProfileSearch(e.target.value)}
                                placeholder={t('admin.pendingPurchases.searchProfilePlaceholder')}
                                className="flex-1 bg-transparent text-[12px] text-h-text outline-none placeholder:text-h-text-3"
                              />
                            </div>
                            {profileMatches.map(p => (
                              <button
                                key={p.id}
                                disabled={submitting}
                                onClick={() => link(row, p.id)}
                                className="block w-full text-left text-[12px] py-1.5 px-2 rounded hover:bg-h-surface disabled:opacity-50"
                              >
                                <span className="font-bold text-h-text">{p.full_name || t('admin.pendingPurchases.noName')}</span>
                                <span className="text-h-text-3"> · {p.email || '—'}</span>
                              </button>
                            ))}
                            {profileSearch.trim() && profileMatches.length === 0 ? (
                              <p className="text-[11px] text-h-text-3 px-2">{t('admin.pendingPurchases.noProfileMatch')}</p>
                            ) : null}
                            <button
                              onClick={() => { setLinkingId(null); setProfileSearch(''); }}
                              className="text-[11px] font-medium text-h-text-3 px-2 py-1 mt-1"
                            >
                              {t('admin.pendingPurchases.cancel')}
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => openLinking(row)}
                            className="text-[11px] font-bold px-3 py-1 rounded-full"
                            style={{ backgroundColor: 'rgba(45,184,122,0.10)', color: '#2DB87A' }}
                          >
                            {t('admin.pendingPurchases.link')}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
    </PageTransition>
  );
};

export default AdminComprasPendentes;
