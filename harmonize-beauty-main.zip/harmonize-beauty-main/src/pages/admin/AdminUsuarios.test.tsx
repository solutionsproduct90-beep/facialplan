import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AdminUsuarios from "./AdminUsuarios";
import i18n from "@/i18n";
import { createRangeSlicer } from "@/test/supabaseMock";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();
const toastSuccessMock = vi.fn();
const toastErrorMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

vi.mock("sonner", () => ({
  toast: {
    success: (...args: unknown[]) => toastSuccessMock(...args),
    error: (...args: unknown[]) => toastErrorMock(...args),
  },
}));

const PROFILES = [
  { id: "admin-1", full_name: "Admin Principal", specialty: null, is_blocked: false, created_at: "2026-01-01", role: "admin" },
  { id: "pro-1", full_name: "Dra. Ana", specialty: "Dermato", is_blocked: false, created_at: "2026-01-02", role: "professional" },
];

/**
 * One builder standing in for every `.from()` call this page tree makes:
 * AdminLayout's own "am I admin?" lookup (`select().eq().single()`) and the
 * page's profiles listing (`select().order()`). The block/unblock action
 * itself goes through `supabase.rpc('admin_toggle_professional_block', ...)`
 * (see rpcMock below), not `.from(...).update(...)`.
 */
function makeUniversalBuilder() {
  const pagina = createRangeSlicer();
  let isSingle = false;

  const builder: any = {
    select: () => builder,
    order: () => builder,
    range: (from: number, to: number) => {
      pagina.record(from, to);
      return builder;
    },
    eq: () => builder,
    single: () => {
      isSingle = true;
      return builder;
    },
    then: (onFulfilled: any) =>
      Promise.resolve(isSingle ? { data: { role: "admin" } } : { data: pagina.apply(PROFILES) }).then(onFulfilled),
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/admin/usuarios"]}>
      <AdminUsuarios />
    </MemoryRouter>
  );

describe("AdminUsuarios", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockReset();
    fromMock.mockImplementation(() => makeUniversalBuilder());
    rpcMock.mockReset();
    rpcMock.mockResolvedValue({ error: null });
    toastSuccessMock.mockReset();
    toastErrorMock.mockReset();
  });

  it("shows the current admin's own row as 'Você' with no block/unblock button", async () => {
    renderPage();

    await waitFor(() => expect(screen.getByText("Admin Principal")).toBeInTheDocument());

    const ownRow = screen.getByText("Admin Principal").closest("tr")!;
    expect(ownRow).toHaveTextContent("Você");
    expect(ownRow.querySelector("button")).toBeNull();

    // The other professional's row keeps its normal block action.
    const otherRow = screen.getByText("Dra. Ana").closest("tr")!;
    expect(otherRow).toHaveTextContent("Bloquear");
  });

  it("shows an error toast and does not report success when the block/unblock update fails", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    rpcMock.mockResolvedValue({ error: { message: "network down" } });
    const fromCallsBeforeAction = fromMock.mock.calls.length;

    fireEvent.click(screen.getByText("Bloquear"));
    fireEvent.click(screen.getByText("Confirmar"));

    await waitFor(() =>
      expect(toastErrorMock).toHaveBeenCalledWith("Não foi possível atualizar o status do usuário")
    );
    expect(toastSuccessMock).not.toHaveBeenCalled();
    expect(rpcMock).toHaveBeenCalledWith("admin_toggle_professional_block", {
      p_professional_id: "pro-1",
      p_blocked: true,
    });

    // A failed RPC call should never trigger a list reload (as happens on
    // the success path, which calls `from` again).
    expect(fromMock.mock.calls.length).toBe(fromCallsBeforeAction);
  });
});
