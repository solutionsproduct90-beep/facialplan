import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AdminAuditoria from "./AdminAuditoria";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const rpcMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    rpc: (...args: unknown[]) => rpcMock(...args),
  },
}));

const PROFESSIONALS = [
  { id: "pro-1", full_name: "Dra. Ana" },
  { id: "pro-2", full_name: "Dr. Bruno" },
];

let auditRows: Record<string, unknown>[] = [];
let auditCount = 0;

/**
 * Builder que devolve dados diferentes por tabela, espelhando o padrão de
 * AdminMetricas.test.tsx: `profiles` serve tanto o gate de admin do
 * AdminLayout (`.select('role').eq(...).single()`) quanto a lista de
 * profissionais pro filtro (`.select('id, full_name').order(...)`, sem
 * `.single()`); `audit_log` devolve as linhas da página atual + `count`.
 */
function makeBuilder(table: string) {
  let isSingle = false;
  const builder: any = {
    select: () => builder,
    order: () => builder,
    eq: () => builder,
    gte: () => builder,
    lte: () => builder,
    range: () => builder,
    single: () => {
      isSingle = true;
      return builder;
    },
    then: (onFulfilled: any) => {
      let result: unknown;
      if (table === "profiles") {
        result = isSingle ? { data: { role: "admin" } } : { data: PROFESSIONALS };
      } else if (table === "audit_log") {
        result = { data: auditRows, count: auditCount, error: null };
      } else {
        result = { data: [] };
      }
      return Promise.resolve(result).then(onFulfilled);
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/admin/auditoria"]}>
      <AdminAuditoria />
    </MemoryRouter>
  );

describe("AdminAuditoria", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockReset();
    fromMock.mockImplementation((table: string) => makeBuilder(table));
    rpcMock.mockReset();
    rpcMock.mockResolvedValue({ data: [{ id: "pat-1", name: "Maria Silva" }], error: null });
    auditRows = [];
    auditCount = 0;
  });

  it("shows an empty state when there are no audit log entries", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Auditoria")).toBeInTheDocument());

    await waitFor(() => expect(screen.getByText("Nenhum registro encontrado")).toBeInTheDocument());
  });

  it("renders fetched rows with translated action labels and resolved patient names", async () => {
    auditRows = [
      {
        id: "log-1",
        actor_id: "pro-1",
        action: "view_patient_photo",
        resource_type: "session",
        resource_id: "sess-1",
        patient_id: "pat-1",
        created_at: "2026-09-10T12:00:00.000Z",
      },
    ];
    auditCount = 1;

    renderPage();

    // "Visualizou foto do paciente" também aparece como texto de uma <option>
    // do filtro de ação — usa o badge dentro da linha da tabela pra
    // desambiguar (ver getAllByText abaixo).
    await waitFor(() => expect(screen.getAllByText("Visualizou foto do paciente").length).toBe(2));
    // "Dra. Ana" também aparece como <option> do filtro de profissional.
    expect(screen.getAllByText("Dra. Ana").length).toBe(2);
    // Nome do paciente resolvido via admin_resolve_patient_names, não o id cru.
    expect(await screen.findByText("Maria Silva")).toBeInTheDocument();
    expect(rpcMock).toHaveBeenCalledWith("admin_resolve_patient_names", { p_patient_ids: ["pat-1"] });
  });

  it("does not call admin_resolve_patient_names when no row has a patient_id", async () => {
    auditRows = [
      {
        id: "log-1",
        actor_id: "pro-1",
        action: "export_pdf",
        resource_type: "session",
        resource_id: "sess-1",
        patient_id: null,
        created_at: "2026-09-10T12:00:00.000Z",
      },
    ];
    auditCount = 1;

    renderPage();

    // Mesma ambiguidade de texto do teste acima ("Exportou PDF" também é uma
    // <option> do filtro de ação).
    await waitFor(() => expect(screen.getAllByText("Exportou PDF").length).toBe(2));
    expect(rpcMock).not.toHaveBeenCalled();
  });

  it("shows the limitation notice about best-effort, client-triggered logging", async () => {
    renderPage();
    await waitFor(() =>
      expect(screen.getByText(/melhor esforço/)).toBeInTheDocument()
    );
  });

  it("re-fetches with the selected professional as a filter", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Auditoria")).toBeInTheDocument());
    await waitFor(() => expect(screen.getByText("Dra. Ana")).toBeInTheDocument());

    fromMock.mockClear();
    fireEvent.change(screen.getByDisplayValue("Todos os profissionais"), { target: { value: "pro-2" } });

    await waitFor(() => expect(fromMock).toHaveBeenCalledWith("audit_log"));
  });

  // Filtro de tipo de recurso (RESOURCE_TYPES) — antes só uma constante morta,
  // nunca ligada à UI. Mesmo padrão do teste de filtro por profissional acima.
  it("re-fetches with the selected resource type as a filter", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("Log de Auditoria")).toBeInTheDocument());

    fromMock.mockClear();
    fireEvent.change(screen.getByDisplayValue("Todos os tipos de recurso"), { target: { value: "anamnesis" } });

    await waitFor(() => expect(fromMock).toHaveBeenCalledWith("audit_log"));
  });
});

// Selo de Conformidade Clínica por Sessão (P6-2, ver
// src/lib/complianceSummary.ts) — busca independente do log de auditoria
// acima, via a RPC estreita `admin_get_session_compliance_context` (ver
// supabase/migrations/20260911100000_add_admin_session_compliance_rpc.sql).
// A função pura em si já tem sua própria suíte (complianceSummary.test.ts);
// a cobertura aqui é só a fiação — busca por ID, estados de not-found/erro,
// e que o resultado da RPC de fato chega renderizado como gates.
describe("AdminAuditoria — Selo de Conformidade Clínica por Sessão (P6-2)", () => {
  const CLEAN_CONTEXT = {
    session: {
      id: "sess-1",
      created_at: "2026-05-01T10:00:00.000Z",
      stage2_overlay: [
        { id: "p1", region: "testa", label: "Testa", substance: "toxina_botulinica", quantity: 20, unit: "unidades", x: 0.5, y: 0.3, source: "manual" },
      ],
    },
    patient: { name: "Maria Silva", consent_given: true, last_consent_at: "2026-04-01T00:00:00.000Z" },
    anamnesis: { created_at: "2026-04-01T00:00:00.000Z" },
    procedure_consent: { created_at: "2026-05-01T09:30:00.000Z", consent_text: "Texto do TCLE aceito", ip_address: "203.0.113.5" },
    skin_screening: {
      has_suspicious_finding: false,
      referred_to_dermatology: false,
      proceeded_despite_finding: false,
      proceed_justification: null,
      updated_at: "2026-05-01T09:00:00.000Z",
    },
    past_toxin_sessions: [],
  };

  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({
      user: { id: "admin-1", email: "admin@example.com" },
      loading: false,
      signOut: vi.fn(),
    });
    fromMock.mockReset();
    fromMock.mockImplementation((table: string) => makeBuilder(table));
    rpcMock.mockReset();
    auditRows = [];
    auditCount = 0;
  });

  it("looks up a session by ID and shows every gate as met when everything on file is clean", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "admin_get_session_compliance_context") return Promise.resolve({ data: CLEAN_CONTEXT, error: null });
      return Promise.resolve({ data: [], error: null });
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Selo de Conformidade Clínica por Sessão")).toBeInTheDocument());

    fireEvent.change(screen.getByPlaceholderText("ID da sessão"), { target: { value: "sess-1" } });
    fireEvent.click(screen.getByText("Buscar"));

    expect(await screen.findByText("Paciente: Maria Silva")).toBeInTheDocument();
    expect(rpcMock).toHaveBeenCalledWith("admin_get_session_compliance_context", { p_session_id: "sess-1" });

    expect(await screen.findByText("Triagem de lesão suspeita (ABCDE)")).toBeInTheDocument();
    // `{ selector: 'p' }` desambigua do texto igual na nova <option> do filtro
    // de tipo de recurso ("Anamnese", ver admin.auditLog.resourceType).
    expect(screen.getByText("Anamnese", { selector: 'p' })).toBeInTheDocument();
    expect(screen.getByText("Termo de consentimento do procedimento (TCLE)")).toBeInTheDocument();
    expect(screen.getByText("Todos os gates cumpridos para esta sessão.")).toBeInTheDocument();
    expect(screen.getByText(/Hash do texto aceito/)).toBeInTheDocument();
    // Prova de integridade é só o hash — o texto completo do TCLE nunca aparece.
    expect(screen.queryByText("Texto do TCLE aceito")).not.toBeInTheDocument();
  });

  it("shows an attention badge and status when a related record (e.g. anamnesis) is missing", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "admin_get_session_compliance_context") {
        return Promise.resolve({
          data: { ...CLEAN_CONTEXT, anamnesis: null, procedure_consent: null, skin_screening: null },
          error: null,
        });
      }
      return Promise.resolve({ data: [], error: null });
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Selo de Conformidade Clínica por Sessão")).toBeInTheDocument());

    fireEvent.change(screen.getByPlaceholderText("ID da sessão"), { target: { value: "sess-1" } });
    fireEvent.click(screen.getByText("Buscar"));

    expect(await screen.findByText("Um ou mais gates precisam de atenção nesta sessão.")).toBeInTheDocument();
    expect(screen.getAllByText(/Em atenção/).length).toBeGreaterThan(0);
  });

  it("shows a not-found message when no session matches the given ID", async () => {
    rpcMock.mockImplementation((fn: string) => {
      if (fn === "admin_get_session_compliance_context") return Promise.resolve({ data: null, error: null });
      return Promise.resolve({ data: [], error: null });
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("Selo de Conformidade Clínica por Sessão")).toBeInTheDocument());

    fireEvent.change(screen.getByPlaceholderText("ID da sessão"), { target: { value: "does-not-exist" } });
    fireEvent.click(screen.getByText("Buscar"));

    expect(await screen.findByText("Nenhuma sessão encontrada com este ID.")).toBeInTheDocument();
  });
});
