import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import NovaSessao from "./NovaSessao";
import i18n from "@/i18n";

// jsdom não implementa URL.createObjectURL — NovaSessao usa isso só para
// gerar o preview visual de cada foto (frontal e das 3 extras), o que não é
// relevante para os testes de payload/upload abaixo.
if (!URL.createObjectURL) {
  URL.createObjectURL = vi.fn(() => "blob:mock");
}

// handleAnalyze (NovaSessao.tsx) aguarda dois setTimeout reais (MIN_SCAN_
// DISPLAY_MS = 2600ms + 350ms) antes de chamar navigate() — tempo real
// propositalmente curto pra UX, mas caro demais rodando 3x neste arquivo
// dentro da suíte inteira (70+ arquivos em paralelo no CI): sob contenção de
// CPU, esses timers reais viram uma corrida entre o teste terminar e o
// setTimeout dessa análise específica realmente disparar — quando ele
// dispara DEPOIS do ambiente jsdom deste arquivo já ter sido destruído, vira
// um "ReferenceError: window is not defined" não tratado que derruba o
// processo do Vitest inteiro mesmo com todo teste passando individualmente
// (visto no CI, não reproduzido rodando este arquivo isolado). Acelerar só
// o setTimeout (não um fake timer completo, que quebraria o polling real
// que `waitFor` usa por baixo) elimina os dois timers reais de 2.6s/0.35s
// sem mudar nenhuma outra semântica de promise/microtask do teste.
const realSetTimeout = globalThis.setTimeout;
beforeEach(() => {
  vi.stubGlobal("setTimeout", ((fn: (...args: unknown[]) => void, _ms?: number, ...args: unknown[]) =>
    realSetTimeout(fn, 0, ...args)) as typeof setTimeout);
});
afterEach(() => {
  vi.unstubAllGlobals();
});

// Cobre o backlog P1 "Fotos multiângulo na análise": 3 slots opcionais
// (oblíqua esq./dir., perfil) além da frontal (sempre obrigatória). Os três
// comportamentos exigidos pela feature:
//   1. quem só envia a frontal continua funcionando exatamente como antes;
//   2. quando um ângulo extra é enviado, seu storagePath entra no payload
//      passado para a edge function `analyze-face`;
//   3. uma falha ao enviar uma foto extra nunca derruba o fluxo principal —
//      a sessão segue e a frontal sozinha basta.
const useAuthMock = vi.fn();
const fromMock = vi.fn();
const storageFromMock = vi.fn();
const uploadMock = vi.fn();
const invokeMock = vi.fn();
const navigateMock = vi.fn();
const toastErrorMock = vi.fn();
const toastInfoMock = vi.fn();
const toastWarningMock = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: { from: (...args: unknown[]) => storageFromMock(...args) },
    functions: { invoke: (...args: unknown[]) => invokeMock(...args) },
  },
}));

vi.mock("sonner", () => ({
  toast: {
    error: (...args: unknown[]) => toastErrorMock(...args),
    info: (...args: unknown[]) => toastInfoMock(...args),
    warning: (...args: unknown[]) => toastWarningMock(...args),
    success: vi.fn(),
  },
}));

const PATIENT = { id: "pat-1", name: "Maria Silva", consent_given: true, phone: null };

/**
 * Builder mínimo pra `patients`: cobre tanto a listagem inicial da Etapa 1
 * (`select().eq().eq().order()`) quanto o fetch do paciente pré-selecionado
 * (`select().eq('id', ...).single()`) usado quando chegamos direto na
 * Etapa 2 via `location.state.preselectedPatientId`.
 */
function patientsBuilder() {
  const builder = {
    select: () => builder,
    eq: () => builder,
    order: () => Promise.resolve({ data: [PATIENT], error: null }),
    single: () => Promise.resolve({ data: PATIENT, error: null }),
  };
  return builder;
}

function sessionsBuilder() {
  const builder = {
    insert: () => builder,
    select: () => builder,
    single: () => Promise.resolve({ data: { id: "session-1" }, error: null }),
    update: (payload: unknown) => {
      sessionsUpdateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
  };
  return builder;
}

const sessionsUpdateSpy = vi.fn();

const renderPage = () =>
  render(
    <MemoryRouter
      initialEntries={[{ pathname: "/sessoes/nova", state: { preselectedPatientId: "pat-1", preselectedPatientName: "Maria Silva" } }]}
    >
      <Routes>
        <Route path="/sessoes/nova" element={<NovaSessao />} />
      </Routes>
    </MemoryRouter>
  );

const goToUploadStep = async () => {
  renderPage();
  // A Etapa 2 (upload) só aparece depois do fetch do paciente pré-selecionado
  // resolver — aguarda o nome do paciente aparecer na tela.
  await screen.findByText("Maria Silva");
  return screen.getByText(/Analisar foto/);
};

const frontalFile = () => new File(["frontal-bytes"], "frontal.jpg", { type: "image/jpeg" });
const extraFile = (name: string) => new File(["extra-bytes"], name, { type: "image/jpeg" });

describe("NovaSessao — fotos multiângulo opcionais (oblíqua esq./dir., perfil)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" } });
    fromMock.mockReset();
    storageFromMock.mockReset();
    uploadMock.mockReset();
    invokeMock.mockReset();
    navigateMock.mockReset();
    toastErrorMock.mockReset();
    toastInfoMock.mockReset();
    toastWarningMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "patients") return patientsBuilder();
      if (table === "sessions") return sessionsBuilder();
      throw new Error(`unexpected table ${table}`);
    });
    storageFromMock.mockImplementation(() => ({ upload: (...args: unknown[]) => uploadMock(...args) }));
    uploadMock.mockResolvedValue({ error: null });
    invokeMock.mockResolvedValue({
      data: { suggestions: [], source: "ai" },
      error: null,
    });
  });

  it("analyzes normally with only the frontal photo — preserves current single-photo behavior", async () => {
    await goToUploadStep();

    const fileInputs = document.querySelectorAll('input[type="file"]');
    expect(fileInputs.length).toBe(4); // frontal + 3 slots extras

    fireEvent.change(fileInputs[0], { target: { files: [frontalFile()] } });
    fireEvent.click(await screen.findByText(/Analisar foto/));

    await waitFor(() => expect(invokeMock).toHaveBeenCalledTimes(1));
    const [fnName, opts] = invokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(fnName).toBe("analyze-face");
    expect(opts.body).toEqual({
      sessionId: "session-1",
      patientId: "pat-1",
      storagePath: "pro-1/session-1.jpg",
    });
    // Só o upload da frontal aconteceu — nenhum ângulo extra foi tocado.
    expect(uploadMock).toHaveBeenCalledTimes(1);

    await waitFor(
      () => expect(navigateMock).toHaveBeenCalledWith("/sessoes/session-1/estagio-1"),
      { timeout: 4000 },
    );
  }, 8000);

  it("includes extra angle paths in the analyze-face payload when those photos are provided", async () => {
    await goToUploadStep();

    const fileInputs = document.querySelectorAll('input[type="file"]');
    // Ordem: [0] frontal, [1] oblíqua esquerda, [2] oblíqua direita, [3] perfil.
    fireEvent.change(fileInputs[0], { target: { files: [frontalFile()] } });
    fireEvent.change(fileInputs[1], { target: { files: [extraFile("esq.jpg")] } });
    fireEvent.change(fileInputs[3], { target: { files: [extraFile("perfil.jpg")] } });
    // Oblíqua direita fica de fora de propósito — o payload não deve trazer
    // obliqueRightPath nenhum.

    fireEvent.click(await screen.findByText(/Analisar foto/));

    await waitFor(() => expect(invokeMock).toHaveBeenCalledTimes(1), { timeout: 4000 });
    const [, opts] = invokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(opts.body).toMatchObject({
      sessionId: "session-1",
      patientId: "pat-1",
      storagePath: "pro-1/session-1.jpg",
      obliqueLeftPath: "pro-1/session-1_oblique_esq.jpg",
      profilePath: "pro-1/session-1_perfil.jpg",
    });
    expect(opts.body).not.toHaveProperty("obliqueRightPath");

    // 1 upload da frontal + 2 uploads das extras enviadas.
    expect(uploadMock).toHaveBeenCalledTimes(3);
    expect(uploadMock).toHaveBeenCalledWith(
      "pro-1/session-1_oblique_esq.jpg",
      expect.anything(),
      expect.objectContaining({ upsert: true }),
    );
  }, 8000);

  it("degrades gracefully when an extra photo fails to upload — main flow still completes with only the frontal", async () => {
    await goToUploadStep();

    uploadMock.mockImplementation(async (path: string) => {
      if (path.includes("oblique_esq")) return { error: { message: "network reset" } };
      return { error: null };
    });

    const fileInputs = document.querySelectorAll('input[type="file"]');
    fireEvent.change(fileInputs[0], { target: { files: [frontalFile()] } });
    fireEvent.change(fileInputs[1], { target: { files: [extraFile("esq.jpg")] } });

    fireEvent.click(await screen.findByText(/Analisar foto/));

    // Aviso não-bloqueante sobre a foto extra, mas SEM o erro genérico de
    // falha de análise — o fluxo principal não deve ser tratado como erro.
    await waitFor(() => expect(toastWarningMock).toHaveBeenCalled(), { timeout: 4000 });
    expect(toastErrorMock).not.toHaveBeenCalled();

    await waitFor(() => expect(invokeMock).toHaveBeenCalledTimes(1), { timeout: 4000 });
    const [, opts] = invokeMock.mock.calls[0] as [string, { body: Record<string, unknown> }];
    // A foto que falhou nunca aparece no payload — só a frontal, como se o
    // profissional nunca tivesse tentado enviar a extra.
    expect(opts.body).toEqual({
      sessionId: "session-1",
      patientId: "pat-1",
      storagePath: "pro-1/session-1.jpg",
    });

    await waitFor(
      () => expect(navigateMock).toHaveBeenCalledWith("/sessoes/session-1/estagio-1"),
      { timeout: 4000 },
    );
  }, 8000);
});
