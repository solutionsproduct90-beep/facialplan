import React, { useEffect, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ALL_QUESTION_KEYS } from '@/types/anamnesis';

/**
 * /perfil/anamnese — configuração, por profissional, de quais das 18
 * perguntas do histórico do PACIENTE aparecem no formulário (link público e
 * "preencher em nome do paciente") e na visualização. A Avaliação Clínica
 * (tipo de pele etc.) não é configurável aqui — é sempre preenchida pelo
 * profissional, então não faz sentido "desligar" nenhum campo dela.
 *
 * Cada toggle salva imediatamente (upsert em `anamnesis_question_settings`)
 * — não há um botão "Salvar" separado, para ficar consistente com o resto
 * do app não ter uma tela de configurações com estado pendente.
 */
const PerfilAnamnese: React.FC = () => {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [disabledKeys, setDisabledKeys] = useState<Set<string>>(new Set());
  const [savingKey, setSavingKey] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('anamnesis_question_settings')
        .select('question_key, enabled')
        .eq('professional_id', user.id);
      if (cancelled) return;
      if (error) {
        toast.error(t('anamnesis.settings.loadError'));
      } else {
        setDisabledKeys(new Set((data ?? []).filter((r) => r.enabled === false).map((r) => r.question_key)));
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user, t]);

  const toggle = async (key: string, nextEnabled: boolean) => {
    if (!user) return;
    setSavingKey(key);
    const previous = new Set(disabledKeys);
    setDisabledKeys((prev) => {
      const next = new Set(prev);
      if (nextEnabled) next.delete(key);
      else next.add(key);
      return next;
    });

    const { error } = await supabase
      .from('anamnesis_question_settings')
      .upsert(
        { professional_id: user.id, question_key: key, enabled: nextEnabled },
        { onConflict: 'professional_id,question_key' },
      );

    if (error) {
      setDisabledKeys(previous);
      toast.error(t('anamnesis.settings.saveError'));
    }
    setSavingKey(null);
  };

  return (
    <PageTransition>
      <AppLayout title={t('anamnesis.settings.title')} showBack>
        <div className="flex flex-col gap-4">
          <p className="text-[13px] text-h-text-2 leading-relaxed">{t('anamnesis.settings.subtitle')}</p>

          {loading ? (
            <SkeletonCard />
          ) : (
            <HCard>
              <div className="flex flex-col">
                {ALL_QUESTION_KEYS.map((key) => {
                  const enabled = !disabledKeys.has(key);
                  return (
                    <label
                      key={key}
                      className="flex items-center justify-between gap-3 py-3 cursor-pointer"
                      style={{ borderBottom: '0.5px solid rgba(0,0,0,0.06)' }}
                    >
                      <span className="text-[13px] text-h-text leading-snug flex-1">
                        {t(`anamnesis.form.questions.${key}`)}
                      </span>
                      <input
                        type="checkbox"
                        checked={enabled}
                        disabled={savingKey === key}
                        onChange={(e) => toggle(key, e.target.checked)}
                        style={{ width: 20, height: 20, flexShrink: 0 }}
                      />
                    </label>
                  );
                })}
              </div>
            </HCard>
          )}
        </div>
      </AppLayout>
    </PageTransition>
  );
};

export default PerfilAnamnese;
