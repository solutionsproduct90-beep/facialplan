import React, { useState, useEffect, useRef } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import GradientButton from '@/components/harmonize/GradientButton';
import ConsentModal from '@/components/harmonize/ConsentModal';
import LogoMark from '@/components/harmonize/LogoMark';
import VoiceDictationButton from '@/components/harmonize/VoiceDictationButton';
import { Search, Plus, Sun, User, GlassesIcon, Meh, Camera, Image, Check, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { FaceRegionKey } from '@/lib/faceRegions';
import { regionLabel, regionFallbackPosition, landmarkPositionForRegion } from '@/lib/faceRegions';
import { loadFaceLandmarker } from '@/lib/faceLandmarker';
import { compressImageFile } from '@/lib/imageCompression';
import { withTimeout } from '@/lib/withTimeout';
import { isPatientConsentRefusal, isSubscriptionInactiveRefusal, readEdgeFunctionError } from '@/lib/edgeFunctionError';

// Regiões usadas na animação de "escaneamento" da tela de carregamento —
// mesmos slugs/posições da taxonomia clínica (ver src/lib/faceRegions.ts,
// usada também na Etapa 2), na ordem em que aparecem sobre a foto (varredura
// de cima para baixo, pela posição y de fallback de cada região). Reaproveitar
// a mesma taxonomia em vez de inventar rótulos novos mantém a animação
// consistente com o resto do produto.
export const SCAN_REGIONS: FaceRegionKey[] = [
  'terco_frontal',
  'glabela',
  'dorso_nasal',
  'malar_esquerda',
  'malar_direita',
  'ponta_nasal',
  'sulco_nasolabial_esquerdo',
  'sulco_nasolabial_direito',
  'labio_superior',
  'labio_inferior',
  'mandibula_esquerda',
  'mandibula_direita',
  'mento',
];

// Passos do checklist abaixo da foto — cada um corresponde a um marco real
// do que `handleAnalyze` está fazendo (upload da foto, chamada à edge
// function `analyze-face`, gravação da sessão), nunca a algo fictício.
export const SCAN_STEPS = ['uploading', 'analyzing', 'generating', 'finalizing'] as const;
export type ScanStepKey = (typeof SCAN_STEPS)[number];

// Tempo mínimo de exibição da animação de escaneamento — é a "transição de
// revelação dramatizada" pedida pelo produto: mesmo quando a análise
// responde muito rápido (ou vem do mock), a animação tem tempo de rodar por
// inteiro em vez de piscar na tela. Nunca estende o tempo real de espera
// além do necessário para a IA/rede — só evita que ele seja curto demais.
const MIN_SCAN_DISPLAY_MS = 2600;

// Tempo máximo que a detecção real de landmarks (MediaPipe) pode atrasar a
// atualização visual dos pontos — é só um reforço estético (posições reais
// da foto em vez das fixas plausíveis), então nunca deve travar a análise:
// se não responder a tempo, os pontos ficam nas posições fixas mesmo.
const LANDMARK_DETECTION_TIMEOUT_MS = 3500;

// Mesmo formato de sessions.stage1_analysis usado hoje pelo fluxo clínico
// ({ suggestions: Suggestion[], overallNotes? } — ver src/types/harmonize.ts
// e o MOCK_ANALYSIS de supabase/functions/analyze-face/index.ts). Este é o
// fallback usado quando a própria invocação da edge function falha (rede,
// função fora do ar); antes trazia o formato antigo (harmony_score /
// recommended_procedures), que a Etapa 1 não sabe mais ler — a sessão ficava
// com stage1_analysis.suggestions undefined e nenhuma sugestão aparecia,
// travando o profissional sem conseguir avançar.
export const MOCK_ANALYSIS = {
  suggestions: [
    {
      id: 'labio_superior_ha', region: 'labio_superior', label: 'Lábio Superior',
      substance: 'acido_hialuronico', confidence: 82, quantitySuggested: 0.5, unit: 'ml',
      justification: {
        finding: 'Volume reduzido com contorno pouco definido no lábio superior.',
        clinicalGoal: 'Restaurar volume e definir melhor o contorno do vermelhão.',
        technicalNote: 'Técnica de bolus retrovermelhão, com reforço pontual do arco do cupido.',
      },
    },
    {
      id: 'malar_direita_ha', region: 'malar_direita', label: 'Malar Direita',
      substance: 'acido_hialuronico', confidence: 68, quantitySuggested: 1, unit: 'ml',
      justification: {
        finding: 'Leve perda de volume na região malar direita em relação à esquerda.',
        clinicalGoal: 'Equilibrar a projeção malar entre os dois lados do rosto.',
        technicalNote: 'Aplicação supraperiosteal em bolus, priorizando o terço lateral do malar.',
      },
    },
    {
      id: 'malar_esquerda_ha', region: 'malar_esquerda', label: 'Malar Esquerda',
      substance: 'acido_hialuronico', confidence: 60, quantitySuggested: 0.8, unit: 'ml',
      justification: {
        finding: 'Volume malar já adequado, mas assimétrico frente ao reforço planejado à direita.',
        clinicalGoal: 'Acompanhar o reforço do lado direito para preservar a simetria final.',
        technicalNote: 'Aplicação supraperiosteal em volume reduzido, reavaliando após o lado direito.',
      },
    },
    {
      id: 'glabela_toxina', region: 'glabela', label: 'Glabela',
      substance: 'toxina_botulinica', confidence: 74, quantitySuggested: 20, unit: 'unidades',
      justification: {
        finding: 'Linhas de expressão glabelares moderadas em repouso.',
        clinicalGoal: 'Suavizar as linhas glabelares mantendo mobilidade natural da testa.',
        technicalNote: 'Pontos padrão em corrugador e prócero, dose fracionada por ponto.',
      },
    },
  ],
  overallNotes: 'Leve assimetria entre os lados direito e esquerdo do terço médio — priorizar o lado mais afetado.',
  // Mesmos campos aditivos descritos em src/types/harmonize.ts e gerados por
  // supabase/functions/analyze-face/index.ts — mantidos aqui em sincronia
  // pra que este fallback (usado só quando a própria invocação da edge
  // function falha, não quando ela responde em modo "mock") tenha o mesmo
  // formato de quem chamou a IA de verdade com sucesso.
  patientSummary: 'Rosto de formato oval, com boa base óssea e proporções harmônicas entre os terços faciais. ' +
    'O envelhecimento é discreto: observa-se principalmente perda pontual de volume no terço médio (região ' +
    'malar) e no lábio superior, além de linhas de expressão dinâmicas na região frontal e glabelar. Os ' +
    'ajustes sugeridos são de natureza preventiva e de refinamento, não corretivos.',
  facialAnalysis: {
    shape: 'Formato oval, com terço inferior levemente mais estreito que o terço médio — proporção ' +
      'compatível com o padrão considerado harmônico para a maioria das etnias.',
    symmetry: 'Assimetria leve entre os lados direito e esquerdo do terço médio, mais evidente na região ' +
      'malar direita, que apresenta volume discretamente inferior ao lado esquerdo.',
    proportions: 'Terços faciais (frontal, médio e inferior) proporcionalmente equilibrados, com leve ' +
      'estreitamento na região malar direita já mencionado na simetria.',
  },
  attentionPoints: [
    'Perda de volume localizada na região malar direita, discretamente mais acentuada que à esquerda.',
    'Linhas de expressão dinâmicas na região glabelar e frontal, ainda reversíveis em repouso.',
  ],
  // Marcador de PROVENIÊNCIA — não é decorativo: é ele que faz a Etapa 1, o
  // PDF clínico, a exportação de prontuário e a apresentação ao paciente
  // carimbarem esta análise como demonstração (ver
  // src/lib/analysisProvenance.ts). Este objeto é gravado inteiro em
  // sessions.stage1_analysis no caminho de fallback abaixo, então remover
  // este campo volta a produzir análise fabricada indistinguível de uma
  // leitura real da IA — exatamente o achado que originou o carimbo.
  source: 'mock',
};

type Patient = {
  id: string;
  name: string;
  consent_given: boolean | null;
  phone: string | null;
};

// Ângulos extras opcionais da foto (backlog P1 "Fotos multiângulo na
// análise") — complementam a frontal (sempre obrigatória, nunca um destes 3)
// para dar à IA uma leitura melhor de simetria/contorno em analyze-face. O
// sufixo é o que diferencia o path de cada ângulo dentro da MESMA pasta do
// profissional no bucket `patient-photos` (ver migration
// 20260910190200_add_session_multiangle_photos.sql e o comentário em
// handleAnalyze abaixo).
type ExtraAngle = 'obliqueLeft' | 'obliqueRight' | 'profile';
const EXTRA_ANGLE_SUFFIX: Record<ExtraAngle, string> = {
  obliqueLeft: 'oblique_esq',
  obliqueRight: 'oblique_dir',
  profile: 'perfil',
};
const EXTRA_ANGLE_BODY_KEY: Record<ExtraAngle, 'obliqueLeftPath' | 'obliqueRightPath' | 'profilePath'> = {
  obliqueLeft: 'obliqueLeftPath',
  obliqueRight: 'obliqueRightPath',
  profile: 'profilePath',
};
const EXTRA_ANGLE_SESSION_COLUMN: Record<ExtraAngle, 'oblique_left_image_url' | 'oblique_right_image_url' | 'profile_image_url'> = {
  obliqueLeft: 'oblique_left_image_url',
  obliqueRight: 'oblique_right_image_url',
  profile: 'profile_image_url',
};
const EXTRA_ANGLES: ExtraAngle[] = ['obliqueLeft', 'obliqueRight', 'profile'];

const NovaSessao: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scanImgRef = useRef<HTMLImageElement>(null);
  // Um input de arquivo escondido por ângulo extra — cada slot abre o seu
  // próprio picker, independente do da frontal.
  const obliqueLeftInputRef = useRef<HTMLInputElement>(null);
  const obliqueRightInputRef = useRef<HTMLInputElement>(null);
  const profileInputRef = useRef<HTMLInputElement>(null);
  const extraAngleInputRefs: Record<ExtraAngle, React.RefObject<HTMLInputElement>> = {
    obliqueLeft: obliqueLeftInputRef,
    obliqueRight: obliqueRightInputRef,
    profile: profileInputRef,
  };

  const preselected = location.state as {
    preselectedPatientId?: string;
    preselectedPatientName?: string;
  } | null;

  const [step, setStep] = useState<1 | 2 | 'loading'>(
    preselected?.preselectedPatientId ? 2 : 1
  );
  const [search, setSearch] = useState('');
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showConsent, setShowConsent] = useState(false);
  const [consentLoading, setConsentLoading] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  // Contexto clínico livre, opcional, escrito pelo profissional ANTES de
  // disparar a análise de IA (backlog P1 "Observações clínicas em texto
  // livre no prompt da IA") — ex: "paciente já fez toxina há 3 meses, quer
  // reforçar só a região frontal". Vai junto no body de `analyze-face` e é
  // incorporado ao prompt lá como contexto adicional, não como fato clínico
  // validado (ver ANALYSIS_PROMPT/professionalNotes em
  // supabase/functions/analyze-face/index.ts). Nunca bloqueia o avanço: um
  // campo vazio simplesmente não é enviado.
  const [professionalNotes, setProfessionalNotes] = useState('');
  // Fotos extras opcionais (oblíqua esq./dir., perfil) — chave por ângulo.
  // Ausentes por padrão: quem nunca toca nesses 3 slots segue o fluxo
  // exatamente como antes, só com a frontal.
  const [extraPhotoFiles, setExtraPhotoFiles] = useState<Partial<Record<ExtraAngle, File>>>({});
  const [extraPhotoPreviews, setExtraPhotoPreviews] = useState<Partial<Record<ExtraAngle, string>>>({});
  const [patientsLoading, setPatientsLoading] = useState(true);
  // Índice do passo do checklist em andamento (passos < este já concluídos).
  const [scanStepIndex, setScanStepIndex] = useState(0);
  // Landmarks reais do MediaPipe, quando a detecção termina a tempo — até lá
  // (e se falhar/expirar), os pontos usam as posições fixas plausíveis de
  // `regionFallbackPosition`.
  const [scanLandmarks, setScanLandmarks] = useState<{ x: number; y: number }[] | null>(null);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      setPatientsLoading(true);
      // Paginado (src/lib/fetchAllRows.ts): um paciente que caísse fora do
      // teto de linhas por resposta do PostgREST (Max Rows, 1000 por padrão,
      // aplicado em silêncio) simplesmente não apareceria no seletor, e o
      // profissional não teria como abrir sessão pra ele.
      const data = await fetchAllRows((from, to) =>
        supabase
          .from('patients')
          .select('id, name, consent_given, phone')
          .eq('professional_id', user.id)
          .eq('is_deleted', false)
          .order('created_at', { ascending: false })
          .range(from, to),
      ).catch(() => null);
      setPatients(data || []);
      setPatientsLoading(false);

      // If patient was preselected from Home, set it directly
      if (preselected?.preselectedPatientId) {
        const { data: patientData } = await supabase
          .from('patients')
          .select('id, name, consent_given, phone')
          .eq('id', preselected.preselectedPatientId)
          .single();
        if (patientData) {
          setSelectedPatient(patientData);
          if (!patientData.consent_given) {
            setShowConsent(true);
            setStep(1);
          }
        }
      }
    };
    load();
  }, [user, preselected?.preselectedPatientId]);

  const filtered = patients.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelectPatient = (patient: Patient) => {
    setSelectedPatient(patient);
    if (!patient.consent_given) {
      setShowConsent(true);
    } else {
      setStep(2);
    }
  };

  const handleConsent = async () => {
    if (!selectedPatient || !user) return;
    setConsentLoading(true);
    await supabase.from('consents').insert({
      patient_id: selectedPatient.id,
      professional_id: user.id,
      consent_text: 'Proteção de Dados v1.0',
      consent_version: '1.0',
    });
    await supabase.from('patients').update({
      consent_given: true,
      last_consent_at: new Date().toISOString(),
    }).eq('id', selectedPatient.id);
    setConsentLoading(false);
    setShowConsent(false);
    setStep(2);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Guarda contra arquivo bruto absurdamente grande — mantida como estava,
    // ANTES da compressão (que ainda precisa decodificar o arquivo inteiro
    // na memória para desenhar no canvas).
    if (file.size > 10 * 1024 * 1024) {
      toast.error(t('sessions.nova.toastFileTooLarge'));
      return;
    }
    // Redimensiona/recomprime no client (canvas + JPEG ~0.8, maior lado até
    // ~1800px — ver src/lib/imageCompression.ts) ANTES de guardar no estado:
    // tanto o upload da frontal quanto o preview abaixo passam a usar a
    // versão já comprimida. Fotos de celular moderno (12-48MP) chegam a
    // vários MB cada; uma sessão com até 4 fotos multiplicava isso no
    // upload. Best-effort: se a compressão falhar por qualquer motivo, a
    // função devolve o arquivo original em vez de lançar.
    const compressed = await compressImageFile(file);
    setPhotoFile(compressed);
    setPhotoPreview(URL.createObjectURL(compressed));
  };

  // Mesma validação de tamanho + mesma compressão client-side da frontal —
  // os 3 slots extras são opcionais, mas quando usados seguem a mesma regra
  // de arquivo (ver comentário de handleFileChange acima).
  const handleExtraFileChange = (angle: ExtraAngle) => async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast.error(t('sessions.nova.toastFileTooLarge'));
      return;
    }
    const compressed = await compressImageFile(file);
    setExtraPhotoFiles(prev => ({ ...prev, [angle]: compressed }));
    setExtraPhotoPreviews(prev => ({ ...prev, [angle]: URL.createObjectURL(compressed) }));
  };

  // Envia uma foto extra (oblíqua/perfil) pro mesmo bucket `patient-photos`
  // da frontal, com o sufixo do ângulo no nome do arquivo (ver
  // EXTRA_ANGLE_SUFFIX). Ao contrário do upload da frontal — que é
  // obrigatório e propaga erro pro catch de handleAnalyze — uma falha aqui
  // NUNCA deve travar o fluxo principal: a sessão já tem a frontal enviada
  // e a análise segue normalmente sem este ângulo, só avisando o
  // profissional com um toast informativo.
  const uploadExtraPhoto = async (
    angle: ExtraAngle,
    file: File | undefined,
    professionalId: string,
    sessionId: string,
  ): Promise<string | null> => {
    if (!file) return null;
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const path = `${professionalId}/${sessionId}_${EXTRA_ANGLE_SUFFIX[angle]}.${ext}`;
      const { error } = await supabase.storage
        .from('patient-photos')
        .upload(path, file, { upsert: true, contentType: file.type });
      if (error) throw error;
      return path;
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error(`[NovaSessao] Falha ao enviar foto extra (${angle}):`, err);
      toast.warning(t('sessions.nova.toastExtraPhotoFailed'));
      return null;
    }
  };

  const handleAnalyze = async () => {
    if (!selectedPatient || !user || !photoFile) return;
    setStep('loading');
    setScanStepIndex(0);
    setScanLandmarks(null);

    // Garante que a animação de escaneamento tenha tempo de rodar por
    // inteiro — nunca estende a espera real além do necessário para a
    // IA/rede, só evita que a revelação pisque na tela quando tudo responde
    // rápido demais (rede local, análise mock).
    const minDisplay = new Promise<void>(resolve => setTimeout(resolve, MIN_SCAN_DISPLAY_MS));

    try {
      const { data: session, error: sessionErr } = await supabase.from('sessions').insert({
        patient_id: selectedPatient.id,
        professional_id: user.id,
        status: 'stage1',
      }).select('id').single();

      if (sessionErr || !session) throw sessionErr ?? new Error('Falha ao criar sessão');

      const ext = photoFile.name.split('.').pop() || 'jpg';
      const storagePath = `${user.id}/${session.id}.${ext}`;

      const { error: uploadErr } = await supabase.storage
        .from('patient-photos')
        .upload(storagePath, photoFile, { upsert: true, contentType: photoFile.type });
      if (uploadErr) throw uploadErr;

      // Fotos extras (oblíqua esq./dir., perfil) são opcionais e enviadas em
      // paralelo — cada uma falha de forma isolada (ver uploadExtraPhoto):
      // uma falha aqui nunca lança, então nunca cai no catch abaixo nem
      // impede a análise de prosseguir só com a frontal, exatamente como
      // funcionava antes desta feature.
      const extraPaths = await Promise.all(
        EXTRA_ANGLES.map(angle => uploadExtraPhoto(angle, extraPhotoFiles[angle], user.id, session.id)),
      );
      const extraPathsByAngle: Partial<Record<ExtraAngle, string>> = {};
      EXTRA_ANGLES.forEach((angle, i) => {
        if (extraPaths[i]) extraPathsByAngle[angle] = extraPaths[i]!;
      });
      const extraSessionColumns = Object.fromEntries(
        EXTRA_ANGLES.map(angle => [EXTRA_ANGLE_SESSION_COLUMN[angle], extraPathsByAngle[angle] ?? null]),
      );
      setScanStepIndex(1); // upload concluído → analisando

      const trimmedNotes = professionalNotes.trim();
      const { data: analysisData, error: fnError } = await supabase.functions.invoke('analyze-face', {
        body: {
          sessionId: session.id,
          patientId: selectedPatient.id,
          storagePath,
          // Opcional — omitido inteiramente quando vazio, em vez de enviar
          // string vazia, para o corpo da requisição não sugerir que o campo
          // é obrigatório.
          ...(trimmedNotes ? { professionalNotes: trimmedNotes } : {}),
          ...Object.fromEntries(
            EXTRA_ANGLES.filter(angle => extraPathsByAngle[angle]).map(angle => [EXTRA_ANGLE_BODY_KEY[angle], extraPathsByAngle[angle]]),
          ),
        },
      });

      if (fnError || !analysisData || (analysisData as any).error) {
        // Recusa por falta de consentimento do paciente (gate do squad w1-3,
        // ver supabase/functions/_shared/consentGate.ts) NÃO é
        // indisponibilidade de IA: cair no fallback de demonstração aqui
        // gravaria uma análise fabricada no prontuário de quem não autorizou
        // e esconderia do profissional a única coisa que ele precisa fazer
        // (colher o termo). Esse caso para o fluxo e mostra o que fazer.
        const errorBody = await readEdgeFunctionError(fnError, analysisData);
        if (isPatientConsentRefusal(errorBody)) {
          toast.error(errorBody?.error || t('sessions.nova.toastConsentRequired'));
          setStep(2);
          return;
        }
        // Assinatura inativa (402, gate de _shared/subscriptionGate.ts — ver
        // src/lib/edgeFunctionError.ts) também NÃO é indisponibilidade de IA:
        // é exatamente o mesmo tipo de recusa que a de consentimento acima,
        // só que por outro motivo. Antes desta checagem, qualquer erro que
        // não fosse a recusa de consentimento caía direto no fallback mock
        // logo abaixo — um profissional inadimplente recebia uma análise
        // fabricada gravada no prontuário do paciente, em silêncio, em vez de
        // ser avisado que precisa regularizar o pagamento (mesmo bug já
        // corrigido no fluxo de Protocolo Nomeado, ver
        // src/pages/SessaoEstagio2.tsx).
        if (isSubscriptionInactiveRefusal(errorBody)) {
          toast.error(errorBody?.error || t('sessions.nova.toastSubscriptionInactive'));
          setStep(2);
          return;
        }
        // Edge function indisponível/sem chave configurada: mantém o fluxo
        // funcionando com a análise de demonstração em vez de travar o app.
        // As fotos extras (quando presentes) já foram enviadas ao storage
        // acima, então seus paths são persistidos aqui também — mesmo neste
        // caminho de fallback, sem depender da edge function ter rodado.
        // MOCK_ANALYSIS já carrega `source: 'mock'`, então a sessão nasce
        // carimbada: o toast abaixo some, mas o aviso persistente da Etapa 1 e
        // o carimbo no PDF/prontuário/apresentação continuam lá.
        await supabase.from('sessions').update({
          stage1_analysis: MOCK_ANALYSIS as any,
          original_image_url: storagePath,
          ...extraSessionColumns,
        } as any).eq('id', session.id);
        toast.info(t('sessions.nova.toastAiUnavailable'));
      } else if ((analysisData as any).source === 'mock') {
        toast.info(t('sessions.nova.toastAiMock'));
      }

      // Paciente legado liberado pela janela de regularização (ver
      // consentGate.ts): a análise rodou, mas o profissional precisa saber
      // que o consentimento ainda está pendente e que a janela tem prazo.
      // A data exata fica no error_logs/admin; aqui basta o aviso acionável.
      if ((analysisData as { consentWarning?: string } | null)?.consentWarning) {
        toast.warning(t('sessions.nova.toastConsentLegacy'));
      }
      setScanStepIndex(2); // análise (real ou mock) resolvida → gerando sugestões

      await minDisplay;
      setScanStepIndex(3); // sugestões prontas → finalizando/navegando
      await new Promise(resolve => setTimeout(resolve, 350));
      setScanStepIndex(SCAN_STEPS.length);
      navigate(`/sessoes/${session.id}/estagio-1`);
    } catch (err: any) {
      toast.error(err.message || t('sessions.nova.toastAnalyzeError'));
      setStep(2);
    }
  };

  // Reforço puramente visual: tenta detectar os landmarks reais do rosto na
  // própria foto do paciente (mesma lib/modelo já usados na Etapa 2, ver
  // src/lib/faceLandmarker.ts) para posicionar os pontos da animação nos
  // lugares reais da foto em vez das posições fixas plausíveis. Roda em
  // paralelo ao upload/análise (nunca atrasa a navegação) e desiste depois
  // de LANDMARK_DETECTION_TIMEOUT_MS — se falhar ou demorar demais, os
  // pontos simplesmente continuam nas posições fixas.
  const handleScanImageLoad = () => {
    const img = scanImgRef.current;
    if (!img) return;
    withTimeout(
      loadFaceLandmarker().then(landmarker => landmarker.detect(img).faceLandmarks?.[0] ?? null),
      LANDMARK_DETECTION_TIMEOUT_MS,
    ).then(landmarks => {
      if (landmarks && landmarks.length > 0) setScanLandmarks(landmarks);
    });
  };

  const getInitials = (name: string) =>
    name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);

  // Loading screen — "escaneia" a própria foto do paciente (pontos de região
  // facial surgindo progressivamente sobre ela) enquanto um checklist abaixo
  // acompanha o andamento real do envio/análise. Ver SCAN_REGIONS/SCAN_STEPS
  // acima e o comentário de handleAnalyze para o que cada passo representa.
  if (step === 'loading') {
    return (
      <div className="fixed inset-0 z-[90] bg-h-bg overflow-y-auto safe-top safe-bottom">
        <div className="max-w-[430px] mx-auto w-full flex flex-col gap-5 px-5 pt-10 pb-10">
          <div className="flex flex-col items-center gap-2.5">
            <LogoMark size={40} />
            <p className="text-[13px] font-extrabold text-h-g-mid uppercase tracking-wide text-center">
              {t('sessions.nova.scan.heading')}
            </p>
          </div>

          {/* Foto + pontos de região escaneando */}
          <div className="relative w-full aspect-[3/4] rounded-r overflow-hidden bg-h-surface-3">
            {photoPreview ? (
              <img
                ref={scanImgRef}
                src={photoPreview}
                alt={t('sessions.nova.patientPhoto')}
                className="w-full h-full object-cover"
                onLoad={handleScanImageLoad}
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-b from-h-surface-3 to-h-bg" />
            )}

            {/* Vinheta escura leve pra dar contraste aos pontos/labels */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{ background: 'linear-gradient(180deg, rgba(0,0,0,0.08) 0%, rgba(0,0,0,0.05) 40%, rgba(0,0,0,0.30) 100%)' }}
            />

            {/* Linha de varredura */}
            <div
              className="absolute left-0 right-0 h-[2px] pointer-events-none"
              style={{
                background: 'linear-gradient(90deg, transparent, #E05C8A, #7C5AC2, transparent)',
                boxShadow: '0 0 14px 2px rgba(168,85,181,0.55)',
                animation: 'scanSweep 2.4s ease-in-out infinite',
              }}
            />

            {/* Pontos de região facial — surgem escalonados; usam a posição
                real da foto (landmarks do MediaPipe) quando a detecção
                termina a tempo, senão a posição fixa plausível. */}
            {SCAN_REGIONS.map((region, i) => {
              const detected = landmarkPositionForRegion(region, scanLandmarks ?? undefined);
              const pos = detected ?? regionFallbackPosition(region);
              // Rótulo à esquerda do ponto pro lado esquerdo do rosto e à
              // direita pro lado direito/central — evita que pares
              // simétricos (ex.: sulco nasolabial esq./dir., quase na mesma
              // altura) tenham os rótulos se sobrepondo no meio da foto.
              const labelOnLeft = pos.x < 0.5;
              return (
                <div
                  key={region}
                  className={`absolute flex items-center gap-1.5 pointer-events-none ${labelOnLeft ? 'flex-row-reverse' : ''}`}
                  style={{
                    top: `${pos.y * 100}%`,
                    left: `${pos.x * 100}%`,
                    opacity: 0,
                    animation: 'scanDotIn 0.45s ease-out forwards',
                    animationDelay: `${200 + i * 170}ms`,
                    transition: 'top 0.4s ease-out, left 0.4s ease-out',
                  }}
                >
                  <span
                    className="w-[9px] h-[9px] rounded-full flex-shrink-0"
                    style={{ background: '#fff', boxShadow: '0 0 0 3px rgba(168,85,181,0.45), 0 0 8px rgba(124,90,194,0.6)' }}
                  />
                  <span
                    className="text-[9px] font-bold text-white px-1.5 py-0.5 rounded-full whitespace-nowrap"
                    style={{ background: 'rgba(20,10,25,0.6)' }}
                  >
                    {t(`sessions.nova.scan.regions.${region}`, { defaultValue: regionLabel(region) })}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Checklist de status — progressivo, sincronizado com o andamento
              real do envio/análise em handleAnalyze. */}
          <div className="flex flex-col gap-3">
            {SCAN_STEPS.map((stepKey, i) => {
              const done = i < scanStepIndex;
              const active = i === scanStepIndex;
              return (
                <div key={stepKey} className="flex items-center gap-3">
                  <span
                    className="w-[22px] h-[22px] rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: done ? 'linear-gradient(135deg, #E05C8A, #7C5AC2)' : 'rgba(0,0,0,0.06)' }}
                  >
                    {done && <Check size={12} color="#fff" strokeWidth={3} />}
                    {active && !done && <Loader2 size={12} className="animate-spin" color="#A855B5" />}
                  </span>
                  <span className={`text-[13px] font-semibold ${done || active ? 'text-h-text' : 'text-h-text-3'}`}>
                    {t(`sessions.nova.scan.steps.${stepKey}`)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <PageTransition>
    <>
      <AppLayout title={t('sessions.nova.title')} showBack hideNav>
        {step === 1 && (
          <div className="flex flex-col gap-4">
            {/* Search */}
            <div className="bg-h-white rounded-r-sm shadow-h-sm flex items-center gap-3 px-4 h-[48px]">
              <Search size={18} className="text-h-text-3 flex-shrink-0" />
              <input
                type="text"
                placeholder={t('sessions.nova.searchPlaceholder')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1 bg-transparent text-[14px] text-h-text outline-none placeholder:text-h-text-3"
              />
            </div>

            {/* Patient list */}
            {patientsLoading ? (
              <div className="flex flex-col gap-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="bg-h-white rounded-r shadow-h-sm h-[64px] animate-pulse" />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-[14px] text-h-text-3">{t('sessions.nova.noPatients')}</p>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {filtered.slice(0, 10).map(patient => (
                  <button
                    key={patient.id}
                    onClick={() => handleSelectPatient(patient)}
                    className={`bg-h-white rounded-r shadow-h-sm p-4 flex items-center gap-3 text-left transition-all active:scale-[0.98] ${
                      selectedPatient?.id === patient.id ? 'ring-[1.5px] ring-h-g-mid' : ''
                    }`}
                  >
                    <div
                      className="w-[40px] h-[40px] rounded-full flex items-center justify-center flex-shrink-0 text-[13px] font-bold"
                      style={{
                        background: 'linear-gradient(135deg, #E05C8A 0%, #A855B5 50%, #7C5AC2 100%)',
                        color: '#fff',
                      }}
                    >
                      {getInitials(patient.name)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[14px] font-bold text-h-text truncate">{patient.name}</p>
                      <p className="text-[11px] text-h-text-3">
                        {patient.consent_given ? t('sessions.nova.consentActive') : t('sessions.nova.consentMissing')}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* New patient */}
            <button
              onClick={() => navigate('/pacientes/novo')}
              className="flex items-center gap-3 px-4 py-3 text-h-g-start"
            >
              <Plus size={18} />
              <span className="text-[14px] font-bold">{t('sessions.nova.newPatient')}</span>
            </button>
          </div>
        )}

        {step === 2 && selectedPatient && (
          <div className="flex flex-col gap-5">
            {/* Patient info */}
            <div className="flex items-center gap-3">
              <div
                className="w-[36px] h-[36px] rounded-full flex items-center justify-center text-[12px] font-bold flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #E05C8A 0%, #A855B5 50%, #7C5AC2 100%)', color: '#fff' }}
              >
                {getInitials(selectedPatient.name)}
              </div>
              <div>
                <p className="text-[15px] font-bold text-h-text">{selectedPatient.name}</p>
                <p className="text-[11px] text-h-text-3">{t('sessions.nova.patientPhoto')}</p>
              </div>
            </div>

            {/* Photo guide */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: <Sun size={20} />, label: t('sessions.nova.guideLighting') },
                { icon: <User size={20} />, label: t('sessions.nova.guideFrontal') },
                { icon: <GlassesIcon size={20} />, label: t('sessions.nova.guideNoGlasses') },
                { icon: <Meh size={20} />, label: t('sessions.nova.guideNeutral') },
              ].map((item, i) => (
                <div key={i} className="bg-h-white rounded-r-sm shadow-h-sm p-3 flex items-center gap-2.5">
                  <span className="text-h-g-mid">{item.icon}</span>
                  <span className="text-[12px] font-semibold text-h-text-2">{item.label}</span>
                </div>
              ))}
            </div>

            {/* Upload area */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png"
              className="hidden"
              onChange={handleFileChange}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-[3/4] rounded-r border-2 border-dashed border-h-surface-3 flex flex-col items-center justify-center gap-3 overflow-hidden transition-all active:scale-[0.99]"
              style={photoPreview ? { border: 'none' } : {}}
            >
              {photoPreview ? (
                <img src={photoPreview} alt="Foto" className="w-full h-full object-cover rounded-r" />
              ) : (
                <>
                  <div
                    className="w-14 h-14 rounded-full flex items-center justify-center"
                    style={{ background: 'rgba(168,85,181,0.08)' }}
                  >
                    <Camera size={24} className="text-h-g-mid" />
                  </div>
                  <p className="text-[14px] font-bold text-h-text">{t('sessions.nova.takePhoto')}</p>
                  <p className="text-[12px] text-h-text-3">{t('sessions.nova.orChooseGallery')}</p>
                  <p className="text-[10px] text-h-text-3">{t('sessions.nova.fileHint')}</p>
                </>
              )}
            </button>

            {/* Contexto clínico livre e opcional — ver comentário em
                `professionalNotes` acima sobre como este texto viaja até o
                prompt da IA. */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor="professional-notes" className="text-[12px] font-bold text-h-text-2">
                  {t('sessions.nova.clinicalNotesLabel')}
                </label>
                {/* Assistente de prontuário por voz — ditar em vez de digitar
                    com o paciente na frente (ver useVoiceDictation). */}
                <VoiceDictationButton value={professionalNotes} onTranscript={setProfessionalNotes} />
              </div>
              <textarea
                id="professional-notes"
                value={professionalNotes}
                onChange={(e) => setProfessionalNotes(e.target.value)}
                placeholder={t('sessions.nova.clinicalNotesPlaceholder')}
                rows={3}
                className="w-full bg-h-white rounded-r-sm shadow-h-sm p-3 text-[13px] text-h-text outline-none placeholder:text-h-text-3 resize-none"
              />
            </div>

            {/* Fotos adicionais opcionais (oblíqua esq./dir., perfil) —
                backlog P1 "Fotos multiângulo na análise". Nunca bloqueiam o
                avanço (botão abaixo só depende da frontal); quando
                presentes, são enviadas em handleAnalyze e passadas para
                analyze-face, que ajusta a leitura de simetria/contorno para
                usar os ângulos disponíveis (ver comentário no topo da edge
                function). Fora de escopo v1: a Etapa 2 (editor de pontos)
                não usa esses ângulos extras, e não há validação automática
                de que a foto enviada em cada slot realmente corresponde ao
                ângulo pedido. */}
            <div>
              <p className="text-[12px] font-bold text-h-text mb-0.5">{t('sessions.nova.extraPhotos.title')}</p>
              <p className="text-[11px] text-h-text-3 mb-3 leading-snug">{t('sessions.nova.extraPhotos.subtitle')}</p>
              <div className="grid grid-cols-3 gap-2.5">
                {EXTRA_ANGLES.map(angle => {
                  const labelKey = `sessions.nova.extraPhotos.${angle === 'obliqueLeft' ? 'obliqueLeftLabel' : angle === 'obliqueRight' ? 'obliqueRightLabel' : 'profileLabel'}`;
                  const hintKey = `sessions.nova.extraPhotos.${angle === 'obliqueLeft' ? 'obliqueLeftHint' : angle === 'obliqueRight' ? 'obliqueRightHint' : 'profileHint'}`;
                  const preview = extraPhotoPreviews[angle];
                  return (
                    <React.Fragment key={angle}>
                      <input
                        ref={extraAngleInputRefs[angle]}
                        type="file"
                        accept="image/jpeg,image/png"
                        className="hidden"
                        onChange={handleExtraFileChange(angle)}
                      />
                      <button
                        type="button"
                        onClick={() => extraAngleInputRefs[angle].current?.click()}
                        title={t(hintKey)}
                        aria-label={`${t(labelKey)} — ${t(hintKey)}`}
                        className="aspect-square rounded-r-sm border-2 border-dashed border-h-surface-3 flex flex-col items-center justify-center gap-1 overflow-hidden p-1.5 transition-all active:scale-[0.97]"
                        style={preview ? { border: 'none' } : {}}
                      >
                        {preview ? (
                          <img src={preview} alt={t(labelKey)} className="w-full h-full object-cover rounded-r-sm" />
                        ) : (
                          <>
                            <Camera size={16} className="text-h-g-mid" />
                            <span className="text-[9.5px] font-semibold text-h-text-2 text-center leading-tight">
                              {t(labelKey)}
                            </span>
                          </>
                        )}
                      </button>
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            <GradientButton onClick={handleAnalyze} disabled={!photoFile}>
              {t('sessions.nova.analyzePhoto')}
            </GradientButton>
          </div>
        )}
      </AppLayout>

      <ConsentModal
        open={showConsent}
        onConfirm={handleConsent}
        canClose={false}
        loading={consentLoading}
      />
    </>
    </PageTransition>
  );
};

export default NovaSessao;
