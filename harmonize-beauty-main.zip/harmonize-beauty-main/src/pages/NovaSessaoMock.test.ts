import { describe, it, expect } from "vitest";
import { MOCK_ANALYSIS } from "./NovaSessao";

// MOCK_ANALYSIS is the fallback used by NovaSessao.tsx when invoking the
// analyze-face edge function itself fails (network, function down — not the
// "IA sem chave configurada" mock the edge function returns, see
// analyzeFaceFallback.test.ts for that one). It must stay shaped like a real
// AI analysis (see src/types/harmonize.ts / supabase/functions/analyze-face)
// so the Etapa 1 screen renders identically either way.
describe("NovaSessao MOCK_ANALYSIS — fallback quando a invocação da edge function falha", () => {
  it("has a non-empty suggestions list", () => {
    expect(Array.isArray(MOCK_ANALYSIS.suggestions)).toBe(true);
    expect(MOCK_ANALYSIS.suggestions.length).toBeGreaterThan(0);
  });

  it("includes the additive clinical-reading fields with realistic content", () => {
    expect(typeof MOCK_ANALYSIS.patientSummary).toBe("string");
    expect(MOCK_ANALYSIS.patientSummary.length).toBeGreaterThan(20);

    expect(typeof MOCK_ANALYSIS.facialAnalysis).toBe("object");
    expect(typeof MOCK_ANALYSIS.facialAnalysis.shape).toBe("string");
    expect(typeof MOCK_ANALYSIS.facialAnalysis.symmetry).toBe("string");
    expect(typeof MOCK_ANALYSIS.facialAnalysis.proportions).toBe("string");

    expect(Array.isArray(MOCK_ANALYSIS.attentionPoints)).toBe(true);
    expect(MOCK_ANALYSIS.attentionPoints.length).toBeGreaterThan(0);
  });

  it("never includes a numeric 0-100 'harmony score' style field — decided against on purpose", () => {
    expect(MOCK_ANALYSIS).not.toHaveProperty("harmonyScore");
    expect(MOCK_ANALYSIS).not.toHaveProperty("scores");
  });

  it("marks itself as source: 'mock'", () => {
    expect(MOCK_ANALYSIS.source).toBe("mock");
  });
});
