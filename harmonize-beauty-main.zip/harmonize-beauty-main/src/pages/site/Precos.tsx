import React from 'react';
import { useTranslation } from 'react-i18next';
import { Plus } from 'lucide-react';
import SiteLayout from '@/components/site/SiteLayout';
import { CONTAINER, Eyebrow, PrimaryLink } from '@/components/site/SiteUi';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

interface Faq {
  q: string;
  a: string;
}

const Precos: React.FC = () => {
  const { t } = useTranslation();

  useDocumentMeta({
    title: `${t('site.pricing.heading')} — FacialPlan`,
    description: t('site.pricing.subtitle'),
  });

  const included = t('site.pricing.included', { returnObjects: true }) as string[];
  const faq = t('site.pricing.faq', { returnObjects: true }) as Faq[];

  return (
    <SiteLayout>
      {/* Plano único: em vez de um card de preço isolado no meio da página
          (o padrão "pricing table" de SaaS), a oferta é uma página dupla —
          a promessa e a ação à esquerda, a lista do que está incluído à
          direita, como o verso de um folder. O valor em si só aparece no
          checkout (/assinar), então não há número pra destacar aqui. */}
      <section className={`${CONTAINER} grid gap-14 pb-20 pt-16 md:pb-28 md:pt-24 lg:grid-cols-12 lg:gap-16`}>
        <div className="lg:col-span-6">
          <Eyebrow>{t('site.pricing.heading')}</Eyebrow>
          <h1 className="mt-8 font-display text-balance text-[42px] font-normal leading-[1.02] tracking-[-0.025em] sm:text-[58px] lg:text-[72px]">
            {t('site.pricing.title')}
          </h1>
          <p className="mt-7 max-w-[30rem] text-pretty text-[17px] leading-relaxed text-s-ink-2">{t('site.pricing.subtitle')}</p>
          <div className="mt-10">
            <PrimaryLink to="/assinar">{t('site.pricing.ctaButton')}</PrimaryLink>
            <p className="mt-4 text-[13px] text-s-ink-3">{t('site.pricing.ctaNote')}</p>
          </div>
        </div>

        <div className="lg:col-span-5 lg:col-start-8 lg:pt-4">
          <p className="border-b-2 border-s-ink pb-4 text-[11.5px] font-semibold uppercase tracking-[0.2em] text-s-ink">
            {t('site.pricing.includedHeading')}
          </p>
          <ul>
            {included.map((item) => (
              <li key={item} className="flex items-baseline gap-4 border-b border-s-line py-4 text-[16px] leading-snug text-s-ink">
                <span aria-hidden="true" className="relative -top-[2px] block h-1.5 w-1.5 shrink-0 rounded-full bg-gradient-brand" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Perguntas frequentes em <details> nativo: acessível por teclado sem
          JS e, principalmente, com a resposta presente no HTML
          pré-renderizado — um acordeão controlado por estado só teria a
          resposta no DOM depois do clique. */}
      <section className="border-t border-s-line bg-s-paper">
        <div className={`${CONTAINER} grid gap-10 py-20 md:py-28 lg:grid-cols-12 lg:gap-16`}>
          <h2 className="font-display text-balance text-[34px] font-normal leading-[1.08] tracking-[-0.02em] sm:text-[44px] lg:col-span-4">
            {t('site.pricing.faqHeading')}
          </h2>
          <div className="border-b border-s-line lg:col-span-8">
            {faq.map((item) => (
              <details key={item.q} className="group border-t border-s-line">
                <summary className="site-summary site-focus flex cursor-pointer items-start justify-between gap-6 py-6 md:py-7">
                  <span className="font-display opsz-text text-[21px] leading-snug tracking-[-0.01em] transition-colors group-hover:text-s-accent md:text-[24px]">
                    {item.q}
                  </span>
                  <Plus
                    size={20}
                    strokeWidth={1.25}
                    aria-hidden="true"
                    className="mt-1 shrink-0 text-s-ink-2 transition-transform duration-300 group-open:rotate-45"
                  />
                </summary>
                <p className="max-w-[40rem] pb-8 pr-10 text-pretty text-[16px] leading-relaxed text-s-ink-2">{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
};

export default Precos;
