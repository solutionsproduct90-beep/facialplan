import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowRight, Check } from 'lucide-react';
import SiteLayout from '@/components/site/SiteLayout';
import { CONTAINER, ClosingCta, Eyebrow, PrimaryLink, TextLink, splitAtDash } from '@/components/site/SiteUi';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { useSiteLocale } from '@/hooks/useSiteLocale';
import { localizedPath } from '@/lib/siteLocale';
import { formatBlogDate, getAllBlogPosts, type BlogLocale } from '@/lib/blog';
import heroImage from '@/assets/site/consulta-retrato.webp';

interface Item {
  title: string;
  desc: string;
}

interface PlanRow {
  region: string;
  substance: string;
  amount: string;
  origin: string;
}

interface Plan {
  title: string;
  session: string;
  rows: PlanRow[];
  totalsLabel: string;
  totals: Array<{ substance: string; amount: string }>;
  consent: string;
  note: string;
}

// Etapas são sequência de verdade — o único lugar da página onde numerar
// faz sentido. Romanos em itálico, no registro editorial da serifa, em vez
// dos "01/02/03" de interface.
const ROMAN = ['I', 'II', 'III', 'IV'];

// Landing institucional pública — renderizada em "/" (e em "/es", "/en")
// para visitantes sem sessão (ver RootRoute.tsx). Usuários autenticados
// continuam caindo no dashboard via redirect pra "/inicio".
//
// Direção visual: editorial de clínica de alto padrão, não página de
// produto tech. Serifa de moda (Bodoni Moda) nos títulos, tons de pele e
// papel no fundo, um único acento rosa profundo e composição assimétrica
// — texto ancorado à esquerda, imagem sangrando até a borda da tela. A
// peça central da página é o "plano de tratamento" tipografado (seção
// escura): em vez de afirmar que a simulação nasce de um plano clínico, a
// página MOSTRA o plano, com a mesma estrutura que o app registra (região,
// substância, quantidade, origem IA/manual, total por substância, TCLE).
const LandingPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const locale = useSiteLocale();

  useDocumentMeta({
    title: t('site.home.metaTitle'),
    description: t('site.home.heroSubtitle'),
  });

  const highlights = t('site.home.highlights', { returnObjects: true }) as Item[];
  const steps = t('site.home.steps', { returnObjects: true }) as Item[];
  const plan = t('site.home.plan', { returnObjects: true }) as Plan;
  const [darkLead, darkAccent] = splitAtDash(t('site.home.darkHeading'));
  const posts = getAllBlogPosts(locale as BlogLocale).slice(0, 3);

  return (
    <SiteLayout>
      {/* HERO — cartaz: texto num fundo calmo à esquerda, foto sangrando
          até a borda direita e até o rodapé da dobra. A coluna de texto
          alinha com o CONTAINER das outras seções via padding calculado,
          já que o hero em si não tem largura máxima. */}
      <section className="relative grid lg:min-h-[calc(100svh-76px)] lg:grid-cols-[minmax(0,1.12fr)_minmax(0,1fr)] lg:[max-height:960px]">
        <div className="flex flex-col justify-center px-5 pb-14 pt-14 sm:px-8 sm:pt-20 lg:py-20 lg:pl-[max(3rem,calc((100vw-1360px)/2+3rem))] lg:pr-16">
          <div className="site-rise" style={{ '--d': '0ms' } as React.CSSProperties}>
            <Eyebrow>{t('site.home.heroEyebrow')}</Eyebrow>
          </div>
          <h1 className="mt-8 font-display text-[44px] font-normal leading-[1.02] tracking-[-0.025em] text-s-ink sm:text-[64px] lg:text-[72px] xl:text-[84px]">
            <span className="block overflow-hidden pb-[0.06em]">
              <span className="site-rise block" style={{ '--d': '120ms' } as React.CSSProperties}>
                {t('site.home.heroTitle')}
              </span>
            </span>
            <span className="block overflow-hidden pb-[0.12em]">
              <em className="site-rise block italic text-s-accent" style={{ '--d': '260ms' } as React.CSSProperties}>
                {t('site.home.heroTitleAccent')}
              </em>
            </span>
          </h1>
          <p
            className="site-rise mt-7 max-w-[34rem] text-pretty text-[17px] leading-relaxed text-s-ink-2 md:text-[18px]"
            style={{ '--d': '420ms' } as React.CSSProperties}
          >
            {t('site.home.heroSubtitle')}
          </p>
          <div className="site-rise mt-10 flex flex-wrap items-center gap-x-8 gap-y-5" style={{ '--d': '540ms' } as React.CSSProperties}>
            <PrimaryLink to="/auth/cadastro">{t('site.home.ctaPrimary')}</PrimaryLink>
            <TextLink to={localizedPath('/recursos', locale)}>{t('site.home.ctaSecondary')}</TextLink>
          </div>
          <p className="site-rise mt-6 text-[13px] text-s-ink-3" style={{ '--d': '640ms' } as React.CSSProperties}>
            {t('site.home.heroNote')}
          </p>
        </div>

        <figure className="relative aspect-[4/5] sm:aspect-[5/4] lg:aspect-auto">
          <div className="site-unveil absolute inset-0 overflow-hidden bg-s-blush" style={{ '--d': '200ms' } as React.CSSProperties}>
            <img
              src={heroImage}
              alt=""
              width={614}
              height={768}
              className="h-full w-full object-cover object-[50%_45%]"
            />
          </div>
          <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 via-black/25 to-transparent px-5 pb-5 pt-20 text-[12.5px] leading-snug text-white/85 sm:px-8 lg:px-10 lg:pb-8">
            <span className="block max-w-[22rem]">{t('site.home.heroCaption')}</span>
          </figcaption>
        </figure>
      </section>

      {/* O PRODUTO — título preso no lado esquerdo enquanto a lista rola ao
          lado (sticky só no desktop). Os itens não são sequência, então não
          levam número: o marcador é o mesmo ponto em gradiente do plano de
          tratamento logo abaixo — o desenho de um ponto de aplicação. */}
      <section className="border-t border-s-line">
        <div className={`${CONTAINER} grid gap-12 py-24 md:py-32 lg:grid-cols-12 lg:gap-16`}>
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-36">
              <Eyebrow>{t('site.home.highlightsEyebrow')}</Eyebrow>
              <h2 className="mt-6 font-display text-balance text-[36px] font-normal leading-[1.05] tracking-[-0.02em] sm:text-[46px] lg:text-[54px]">
                {t('site.home.highlightsHeading')}
              </h2>
            </div>
          </div>
          <ul className="border-t border-s-line lg:col-span-7">
            {highlights.map((item) => (
              <li
                key={item.title}
                className="site-reveal grid gap-3 border-b border-s-line py-9 md:grid-cols-[auto_minmax(0,0.9fr)_minmax(0,1.2fr)] md:gap-x-8 md:py-11"
              >
                <span aria-hidden="true" className="mt-[0.7rem] hidden h-2 w-2 rounded-full bg-gradient-brand md:block" />
                <h3 className="font-display text-balance text-[25px] font-normal leading-[1.12] tracking-[-0.01em] md:text-[28px]">
                  {item.title}
                </h3>
                <p className="text-pretty text-[15.5px] leading-relaxed text-s-ink-2">{item.desc}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* O PRINCÍPIO — a seção de contraste máximo, com o plano tipografado. */}
      <section className="relative overflow-hidden bg-s-night text-white">
        <div className={`${CONTAINER} grid items-center gap-16 py-24 md:py-36 lg:grid-cols-12`}>
          <div className="lg:col-span-5">
            <Eyebrow tone="dark">{t('site.home.darkEyebrow')}</Eyebrow>
            <h2 className="mt-7 font-display text-balance text-[36px] font-normal leading-[1.06] tracking-[-0.02em] sm:text-[48px] lg:text-[56px]">
              {darkLead}
              {darkAccent && <em className="mt-1 block italic text-s-accent-soft">{darkAccent}</em>}
            </h2>
            <p className="mt-7 max-w-[28rem] text-pretty text-[16px] leading-relaxed text-white/60">{t('site.home.darkSubtitle')}</p>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <TreatmentPlanSheet plan={plan} />
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section>
        <div className={`${CONTAINER} py-24 md:py-32`}>
          <Eyebrow>{t('site.home.howEyebrow')}</Eyebrow>
          <h2 className="mt-6 max-w-[22em] font-display text-balance text-[34px] font-normal leading-[1.08] tracking-[-0.02em] sm:text-[44px] lg:text-[52px]">
            {t('site.home.howSubtitle')}
          </h2>
          <ol className="mt-16 grid border-t border-s-line md:grid-cols-3">
            {steps.map((step, index) => (
              <li
                key={step.title}
                className="site-reveal border-b border-s-line py-10 md:border-b-0 md:px-10 md:py-12 md:first:pl-0 md:last:pr-0 md:[&+li]:border-l"
              >
                <span aria-hidden="true" className="block font-display text-[60px] italic leading-none text-s-accent">
                  {ROMAN[index]}
                </span>
                <h3 className="mt-8 font-display text-[26px] font-normal leading-tight tracking-[-0.01em]">{step.title}</h3>
                <p className="mt-3 text-pretty text-[15.5px] leading-relaxed text-s-ink-2">{step.desc}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* DO BLOG — só aparece no idioma que já tem artigo (hoje, en não tem). */}
      {posts.length > 0 && (
        <section className="border-t border-s-line bg-s-paper">
          <div className={`${CONTAINER} py-24 md:py-28`}>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <Eyebrow>{t('site.home.blogEyebrow')}</Eyebrow>
                <h2 className="mt-6 font-display text-[34px] font-normal leading-[1.08] tracking-[-0.02em] sm:text-[44px]">
                  {t('site.blog.title')}
                </h2>
              </div>
              <TextLink to={localizedPath('/blog', locale)}>
                {t('site.home.blogAll')}
                <ArrowRight size={15} strokeWidth={1.75} />
              </TextLink>
            </div>
            <ul className="mt-14 grid gap-x-10 md:grid-cols-3">
              {posts.map((post) => (
                <li key={post.slug} className="site-reveal border-t border-s-line">
                  <Link to={localizedPath(`/blog/${post.slug}`, locale)} className="site-focus group block pb-10 pt-6">
                    <p className="text-[11.5px] font-semibold uppercase tracking-[0.16em] text-s-ink-3">
                      {post.tags[0] && <span className="text-s-accent">{post.tags[0]}</span>}
                      {post.tags[0] && <span aria-hidden="true"> · </span>}
                      {formatBlogDate(post.date, i18n.language)}
                    </p>
                    <h3 className="mt-4 font-display opsz-text text-balance text-[24px] font-normal leading-[1.18] tracking-[-0.01em] transition-colors duration-300 group-hover:text-s-accent">
                      {post.title}
                    </h3>
                    <p className="mt-3 line-clamp-3 text-pretty text-[14.5px] leading-relaxed text-s-ink-2">{post.description}</p>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <ClosingCta
        title={t('site.home.ctaBannerTitle')}
        body={t('site.home.ctaBannerSubtitle')}
        to="/auth/cadastro"
        label={t('site.home.ctaBannerButton')}
      />
    </SiteLayout>
  );
};

/**
 * O plano de tratamento como documento impresso: papel claro sobre a seção
 * escura, régua dupla no topo, linhas finas entre pontos. Os pontos levam o
 * gradiente da marca — o único lugar da página onde ele aparece fora do
 * logo, e justamente onde ele "é" o produto (os pontos de aplicação do
 * editor usam a mesma cor).
 */
const TreatmentPlanSheet: React.FC<{ plan: Plan }> = ({ plan }) => (
  <figure className="site-reveal">
    <div className="rounded-[2px] bg-s-paper p-6 text-s-ink shadow-[0_60px_120px_-40px_rgba(0,0,0,0.7)] sm:p-10">
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-2 border-b-2 border-s-ink pb-4">
        <p className="font-display text-[26px] leading-none sm:text-[30px]">{plan.title}</p>
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.18em] text-s-ink-3">{plan.session}</p>
      </div>

      <ol>
        {plan.rows.map((row) => (
          <li
            key={`${row.region}-${row.substance}`}
            className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-baseline gap-x-4 border-b border-s-line py-4"
          >
            <span aria-hidden="true" className="relative -top-[2px] block h-2 w-2 rounded-full bg-gradient-brand" />
            <div>
              <p className="font-display opsz-text text-[19px] leading-tight">{row.region}</p>
              <p className="mt-1 text-[12.5px] text-s-ink-3">{row.substance}</p>
            </div>
            <div className="text-right">
              <p className="text-[15px] font-semibold tabular-nums">{row.amount}</p>
              <p className="mt-1 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-s-ink-3">{row.origin}</p>
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-7">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.18em] text-s-ink-3">{plan.totalsLabel}</p>
        <dl className="mt-3 grid grid-cols-2 gap-6">
          {plan.totals.map((total) => (
            <div key={total.substance}>
              <dt className="text-[12.5px] text-s-ink-2">{total.substance}</dt>
              <dd className="mt-1 font-display text-[30px] leading-none tabular-nums">{total.amount}</dd>
            </div>
          ))}
        </dl>
      </div>

      <p className="mt-8 flex items-center gap-2.5 border-t border-s-line pt-5 text-[12.5px] text-s-ink-2">
        <Check size={15} strokeWidth={2} className="shrink-0 text-s-accent" />
        {plan.consent}
      </p>
    </div>
    <figcaption className="mt-5 text-[12.5px] text-white/45">{plan.note}</figcaption>
  </figure>
);

export default LandingPage;
