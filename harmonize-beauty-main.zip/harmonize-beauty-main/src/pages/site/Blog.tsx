import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowUpRight } from 'lucide-react';
import SiteLayout from '@/components/site/SiteLayout';
import { CONTAINER, Eyebrow } from '@/components/site/SiteUi';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { useSiteLocale } from '@/hooks/useSiteLocale';
import { localizedPath } from '@/lib/siteLocale';
import { formatBlogDate, getAllBlogPosts, readingMinutes } from '@/lib/blog';
import FaceScanVisual from '@/components/site/FaceScanVisual';

const Blog: React.FC = () => {
  const { t, i18n } = useTranslation();
  const locale = useSiteLocale();

  useDocumentMeta({
    title: `${t('site.blog.heading')} — FacialPlan`,
    description: t('site.blog.subtitle'),
  });

  const [featured, ...rest] = getAllBlogPosts(locale);

  const meta = (post: { date: string; content: string }) =>
    `${formatBlogDate(post.date, i18n.language)} · ${t('site.blog.readingTime', { count: readingMinutes(post.content) })}`;

  return (
    <SiteLayout>
      <section className={`${CONTAINER} pb-14 pt-16 md:pb-20 md:pt-24`}>
        <Eyebrow>{t('site.blog.heading')}</Eyebrow>
        <div className="mt-8 grid gap-8 lg:grid-cols-12 lg:items-end">
          <h1 className="font-display text-balance text-[42px] font-normal leading-[1.02] tracking-[-0.025em] sm:text-[58px] lg:col-span-8 lg:text-[76px]">
            {t('site.blog.title')}
          </h1>
          <p className="max-w-[28rem] text-pretty text-[17px] leading-relaxed text-s-ink-2 lg:col-span-4 lg:pb-3">
            {t('site.blog.subtitle')}
          </p>
        </div>
      </section>

      {!featured ? (
        <section className={`${CONTAINER} border-t border-s-line pb-28 pt-10`}>
          <p className="text-[16px] text-s-ink-2">{t('site.blog.emptyState')}</p>
        </section>
      ) : (
        <>
          {/* Destaque: o artigo mais recente. Em vez de foto de banco de
              imagens (a mesma em toda edição fazia o blog parecer gerado),
              a capa é o próprio conceito do produto desenhado à mão: ver
              FaceScanVisual — diagrama do cânone facial com os pontos de
              região reais, no vocabulário editorial do site. */}
          <section className={CONTAINER}>
            <Link
              to={localizedPath(`/blog/${featured.slug}`, locale)}
              className="site-focus group grid gap-8 border-t border-s-ink pt-8 lg:grid-cols-12 lg:gap-12"
            >
              <div className="self-start overflow-hidden lg:col-span-7">
                <FaceScanVisual className="aspect-[16/10] w-full transition-transform duration-[1200ms] ease-out group-hover:scale-[1.03]" />
              </div>
              <div className="flex flex-col lg:col-span-5 lg:py-2">
                <p className="text-[11.5px] font-semibold uppercase tracking-[0.18em] text-s-accent">
                  {t('site.blog.latest')}
                  {featured.tags[0] && <span className="text-s-ink-3"> · {featured.tags[0]}</span>}
                </p>
                <h2 className="mt-5 font-display text-balance text-[32px] font-normal leading-[1.08] tracking-[-0.02em] transition-colors duration-300 group-hover:text-s-accent sm:text-[40px] lg:text-[44px]">
                  {featured.title}
                </h2>
                <p className="mt-5 text-pretty text-[16px] leading-relaxed text-s-ink-2">{featured.description}</p>
                <p className="mt-6 text-[13px] text-s-ink-3 lg:mt-auto lg:pt-8">{meta(featured)}</p>
              </div>
            </Link>
          </section>

          {/* Índice: data e tempo de leitura numa coluna estreita, título em
              serifa, tag à direita — varre-se de cima a baixo lendo só os
              títulos. */}
          <section className={`${CONTAINER} pb-24 pt-16 md:pb-32 md:pt-24`}>
            <ul className="border-b border-s-line">
              {rest.map((post) => (
                <li key={post.slug} className="site-reveal border-t border-s-line">
                  <Link
                    to={localizedPath(`/blog/${post.slug}`, locale)}
                    className="site-focus group grid gap-3 py-8 md:grid-cols-12 md:gap-8 md:py-10"
                  >
                    <p className="text-[13px] text-s-ink-3 md:col-span-3 md:pt-2">{meta(post)}</p>
                    <div className="md:col-span-7">
                      <h2 className="font-display text-balance text-[25px] font-normal leading-[1.15] tracking-[-0.01em] transition-colors duration-300 group-hover:text-s-accent md:text-[30px]">
                        {post.title}
                      </h2>
                      <p className="mt-3 line-clamp-2 max-w-[42rem] text-pretty text-[15px] leading-relaxed text-s-ink-2">
                        {post.description}
                      </p>
                    </div>
                    <div className="flex items-start justify-between gap-4 md:col-span-2 md:flex-col md:items-end md:pt-2">
                      {post.tags[0] && (
                        <span className="text-[11.5px] font-semibold uppercase tracking-[0.16em] text-s-ink-3 md:text-right">
                          {post.tags[0]}
                        </span>
                      )}
                      <ArrowUpRight
                        size={20}
                        strokeWidth={1.25}
                        aria-hidden="true"
                        className="text-s-ink-3 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-s-accent"
                      />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </>
      )}
    </SiteLayout>
  );
};

export default Blog;
