import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ArrowLeft } from 'lucide-react';
import SiteLayout from '@/components/site/SiteLayout';
import { CONTAINER, ClosingCta } from '@/components/site/SiteUi';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { useSiteLocale } from '@/hooks/useSiteLocale';
import { localizedPath } from '@/lib/siteLocale';
import { formatBlogDate, getAllBlogPosts, getBlogPostBySlug, readingMinutes } from '@/lib/blog';

const BlogPost: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { t, i18n } = useTranslation();
  const locale = useSiteLocale();
  const post = slug ? getBlogPostBySlug(slug, locale) : undefined;

  useDocumentMeta({
    title: post ? `${post.title} — FacialPlan` : t('site.blog.notFoundTitle'),
    description: post?.description,
  });

  const backLink = (
    <Link
      to={localizedPath('/blog', locale)}
      className="site-link inline-flex items-center gap-2 pb-0.5 text-[13.5px] font-semibold text-s-ink-2 hover:text-s-ink"
    >
      <ArrowLeft size={15} strokeWidth={1.75} />
      {t('site.blog.backToBlog')}
    </Link>
  );

  if (!post) {
    return (
      <SiteLayout>
        <div className={`${CONTAINER} py-28 md:py-40`}>
          <h1 className="font-display text-[40px] font-normal leading-tight tracking-[-0.02em] sm:text-[56px]">
            {t('site.blog.notFoundTitle')}
          </h1>
          <p className="mb-10 mt-4 text-[16px] text-s-ink-2">{t('site.blog.notFoundBody')}</p>
          {backLink}
        </div>
      </SiteLayout>
    );
  }

  const more = getAllBlogPosts(locale)
    .filter((other) => other.slug !== post.slug)
    .slice(0, 2);

  return (
    <SiteLayout>
      {/* Progresso de leitura: fio no gradiente da marca colado no topo,
          acima do header. Só CSS (ver .site-progress em index.css). */}
      <div aria-hidden="true" className="site-progress fixed inset-x-0 top-0 z-50 h-[2px] bg-gradient-brand" />

      <article>
        {/* Abertura do artigo: tipográfica, sem foto. A foto de capa que
            existia aqui era a mesma em todos os artigos — sem imagem própria
            por post, um título grande em serifa carrega melhor o topo. */}
        <header className={`${CONTAINER} pb-12 pt-10 md:pb-16 md:pt-14`}>
          {backLink}
          <div className="mx-auto mt-14 max-w-[880px] md:mt-20">
            <p className="text-[11.5px] font-semibold uppercase tracking-[0.18em] text-s-ink-3">
              {post.tags[0] && <span className="text-s-accent">{post.tags[0]}</span>}
              {post.tags[0] && <span aria-hidden="true"> · </span>}
              {t('site.blog.readingTime', { count: readingMinutes(post.content) })}
            </p>
            <h1 className="mt-6 font-display text-balance text-[36px] font-normal leading-[1.06] tracking-[-0.022em] sm:text-[50px] lg:text-[62px]">
              {post.title}
            </h1>
            <p className="mt-7 max-w-[40rem] font-display opsz-text text-pretty text-[20px] italic leading-[1.5] text-s-ink-2 md:text-[23px]">
              {post.description}
            </p>
            <p className="mt-10 border-t border-s-line pt-5 text-[13.5px] text-s-ink-3">
              {t('site.blog.publishedOn', { date: formatBlogDate(post.date, i18n.language) })} ·{' '}
              {t('site.blog.byAuthor', { author: post.author })}
            </p>
          </div>
        </header>

        <div className={`${CONTAINER} pb-24 md:pb-32`}>
          <div className="site-prose mx-auto max-w-[680px]">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{post.content}</ReactMarkdown>
          </div>
        </div>
      </article>

      {more.length > 0 && (
        <section className="border-t border-s-line bg-s-paper">
          <div className={`${CONTAINER} py-20 md:py-24`}>
            <p className="text-[11.5px] font-semibold uppercase tracking-[0.2em] text-s-ink-3">{t('site.blog.continueReading')}</p>
            <ul className="mt-8 grid gap-x-12 md:grid-cols-2">
              {more.map((other) => (
                <li key={other.slug} className="border-t border-s-line">
                  <Link to={localizedPath(`/blog/${other.slug}`, locale)} className="site-focus group block py-7">
                    <p className="text-[13px] text-s-ink-3">{formatBlogDate(other.date, i18n.language)}</p>
                    <h2 className="mt-3 font-display text-balance text-[24px] font-normal leading-[1.18] tracking-[-0.01em] transition-colors duration-300 group-hover:text-s-accent md:text-[28px]">
                      {other.title}
                    </h2>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <ClosingCta title={t('site.blog.ctaTitle')} body={t('site.home.ctaBannerSubtitle')} to="/auth/cadastro" label={t('site.nav.cta')} />
    </SiteLayout>
  );
};

export default BlogPost;
