import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import AuthInput from '@/components/harmonize/AuthInput';
import BeforeAfterSlider from '@/components/harmonize/BeforeAfterSlider';
import { isValidMinisiteSlug } from '@/lib/minisiteLink';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

// Página pública (fora do ProtectedRoute — ver rota /m/:slug em App.tsx).
// Mini-site/Página de Captação por Profissional (P4): landing page com
// nome/logo da clínica, uma galeria de antes/depois (só pacientes com
// `marketing_consent = true`, mesmo guardrail reaproveitado da Biblioteca de
// Antes/Depois — ver BibliotecaMarketing.tsx) e um formulário de captação de
// lead. Assim como SessaoPresentPublico.tsx/DepoimentoPublico.tsx, o
// visitante nunca é um usuário autenticado do Supabase: toda leitura/
// gravação passa por fetch simples para a edge function pública
// `public-minisite` (supabase/functions/public-minisite/index.ts), que usa a
// service role key — nunca pelo client `supabase` autenticado.
const FUNCTIONS_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/public-minisite`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;
const MAX_MESSAGE_LENGTH = 2000;

type PageState = 'loading' | 'ready' | 'not_found' | 'error';
type SubmitState = 'idle' | 'submitting' | 'success' | 'error';

interface GalleryItem {
  beforeUrl: string;
  afterUrl: string;
  procedureName: string | null;
}

interface MinisiteData {
  clinicName: string | null;
  logoUrl: string | null;
  professionalName: string | null;
  gallery: GalleryItem[];
}

const PublicShell: React.FC<{ children: React.ReactNode; clinicName?: string | null }> = ({ children, clinicName }) => (
  <div className="min-h-screen bg-h-bg flex items-start justify-center pt-10 pb-16">
    <div className="w-full max-w-[480px] px-6">
      <div className="flex items-center justify-center gap-2.5 mb-8">
        <LogoMark size={32} />
        <span style={{ fontSize: 18, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
          {clinicName || 'FacialPlan'}
        </span>
      </div>
      {children}
    </div>
  </div>
);

const StatusScreen: React.FC<{ title: string; body: string }> = ({ title, body }) => (
  <PublicShell>
    <div className="bg-h-white rounded-r shadow-h-sm p-6 text-center flex flex-col items-center gap-2">
      <h1 style={{ fontSize: 19, fontWeight: 800, color: '#1A1918' }}>{title}</h1>
      <p className="text-[14px] text-h-text-2 leading-relaxed">{body}</p>
    </div>
  </PublicShell>
);

const Minisite: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { t } = useTranslation();

  const [state, setState] = useState<PageState>('loading');
  const [data, setData] = useState<MinisiteData | null>(null);

  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [message, setMessage] = useState('');
  const [submitState, setSubmitState] = useState<SubmitState>('idle');

  useEffect(() => {
    if (!isValidMinisiteSlug(slug)) {
      setState('not_found');
      return;
    }
    let active = true;
    (async () => {
      try {
        const res = await fetch(`${FUNCTIONS_URL}?slug=${encodeURIComponent(slug)}`, {
          headers: { apikey: ANON_KEY, Authorization: `Bearer ${ANON_KEY}` },
        });
        const body = await res.json();
        if (!active) return;
        if (body?.valid) {
          setData({
            clinicName: body.clinicName ?? null,
            logoUrl: body.logoUrl ?? null,
            professionalName: body.professionalName ?? null,
            gallery: Array.isArray(body.gallery) ? body.gallery : [],
          });
          setState('ready');
        } else {
          setState('not_found');
        }
      } catch {
        if (active) setState('error');
      }
    })();
    return () => {
      active = false;
    };
  }, [slug]);

  // Título da aba + meta description/OG por profissional (ver
  // `useDocumentMeta` para a limitação: isto NÃO corrige o preview do link
  // no WhatsApp/Instagram, que exigiria pré-renderização no edge — não
  // implementada nesta squad, ver comentário no topo do hook). Só aplica
  // com dado real do profissional já carregado (`state === 'ready'`); nas
  // telas de carregamento/erro/não-encontrado o título genérico do
  // `index.html` permanece.
  const metaTitle = data?.professionalName
    ? t('minisite.public.metaTitleProfessional', { name: data.professionalName })
    : t('minisite.public.title');
  const metaDescription = data?.professionalName
    ? t('minisite.public.metaDescriptionProfessional', { name: data.professionalName })
    : t('minisite.public.metaDescriptionGeneric');
  const metaImage = data?.logoUrl || data?.gallery[0]?.afterUrl || null;

  useDocumentMeta({
    title: state === 'ready' ? metaTitle : undefined,
    description: state === 'ready' ? metaDescription : undefined,
    ogImage: state === 'ready' ? metaImage : undefined,
  });

  const handleSubmit = async () => {
    if (!slug || !name.trim() || !contact.trim()) return;
    setSubmitState('submitting');
    try {
      const res = await fetch(FUNCTIONS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: ANON_KEY, Authorization: `Bearer ${ANON_KEY}` },
        body: JSON.stringify({
          slug,
          name: name.trim(),
          contact: contact.trim(),
          message: message.trim() || undefined,
        }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.success) throw new Error('submit_failed');
      setSubmitState('success');
    } catch {
      setSubmitState('error');
    }
  };

  if (state === 'loading') {
    return (
      <div className="min-h-screen bg-h-bg flex items-center justify-center">
        <div className="animate-pulse"><LogoMark size={48} /></div>
      </div>
    );
  }

  if (state === 'not_found' || state === 'error') {
    return <StatusScreen title={t('minisite.public.invalidTitle')} body={t('minisite.public.invalidBody')} />;
  }

  return (
    <PublicShell clinicName={data?.clinicName}>
      <div className="flex flex-col gap-5">
        <div className="text-center">
          <h1 style={{ fontSize: 21, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
            {t('minisite.public.title')}
          </h1>
          {data?.professionalName && (
            <p className="text-[13px] text-h-text-2 mt-1">
              {t('minisite.public.byProfessional', { name: data.professionalName })}
            </p>
          )}
        </div>

        {data && data.gallery.length > 0 && (
          <div className="flex flex-col gap-4">
            <p className="text-[11px] font-bold uppercase tracking-wide text-h-text-3 text-center">
              {t('minisite.public.galleryTitle')}
            </p>
            {data.gallery.map((item, index) => (
              <div key={index} className="bg-h-white rounded-r shadow-h-sm overflow-hidden">
                <div style={{ height: 260 }}>
                  <BeforeAfterSlider beforeImageUrl={item.beforeUrl} afterImageUrl={item.afterUrl} />
                </div>
                {item.procedureName && (
                  <p className="text-[12.5px] font-semibold text-h-text-2 text-center py-2 px-3">
                    {item.procedureName}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="bg-h-white rounded-r shadow-h-sm p-5">
          {submitState === 'success' ? (
            <div className="text-center flex flex-col items-center gap-2 py-2">
              <h2 style={{ fontSize: 16, fontWeight: 800, color: '#1A1918' }}>
                {t('minisite.public.form.successTitle')}
              </h2>
              <p className="text-[13px] text-h-text-2 leading-relaxed">{t('minisite.public.form.successBody')}</p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              <h2 style={{ fontSize: 15, fontWeight: 800, color: '#1A1918' }}>
                {t('minisite.public.form.title')}
              </h2>
              <p className="text-[12.5px] text-h-text-2 -mt-1">{t('minisite.public.form.description')}</p>

              <AuthInput
                label={t('minisite.public.form.nameLabel')}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t('minisite.public.form.namePlaceholder')}
                maxLength={200}
              />
              <AuthInput
                label={t('minisite.public.form.contactLabel')}
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                placeholder={t('minisite.public.form.contactPlaceholder')}
                maxLength={200}
              />
              <div className="flex flex-col gap-1.5">
                <label className="text-[13px] font-semibold text-h-text-2">
                  {t('minisite.public.form.messageLabel')}
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value.slice(0, MAX_MESSAGE_LENGTH))}
                  placeholder={t('minisite.public.form.messagePlaceholder')}
                  rows={3}
                  className="w-full rounded-[12px] p-3 text-[14px] bg-h-white border border-black/10 outline-none"
                />
              </div>

              {submitState === 'error' && (
                <p className="text-[13px] text-center" style={{ color: '#E05050' }}>
                  {t('minisite.public.form.errorGeneric')}
                </p>
              )}

              <GradientButton
                onClick={handleSubmit}
                disabled={!name.trim() || !contact.trim() || submitState === 'submitting'}
              >
                {submitState === 'submitting'
                  ? t('minisite.public.form.submitting')
                  : t('minisite.public.form.submit')}
              </GradientButton>
            </div>
          )}
        </div>
      </div>
    </PublicShell>
  );
};

export default Minisite;
