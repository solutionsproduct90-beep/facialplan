import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import LogoMark from '@/components/harmonize/LogoMark';
import GradientButton from '@/components/harmonize/GradientButton';
import { isValidFeedbackToken } from '@/lib/feedbackLink';

// Página pública (fora do ProtectedRoute — ver rota /feedback/:token em
// App.tsx). O paciente nunca é um usuário autenticado do Supabase: a
// "sessão" dele é só o token na URL, validado pela edge function pública
// `public-patient-feedback` (supabase/functions/public-patient-feedback/index.ts),
// que usa a service role key — por isso toda leitura/gravação aqui passa por
// fetch simples para essa função, nunca pelo client `supabase` autenticado.
// Mesmo padrão de AnamneseCompartilhada.tsx e SessaoPresentPublico.tsx.
const FUNCTIONS_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/public-patient-feedback`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;
const MAX_COMMENT_LENGTH = 2000;
const NPS_SCALE = Array.from({ length: 11 }, (_, i) => i); // 0..10

type TokenState = 'loading' | 'valid' | 'not_found' | 'used' | 'error';
type SubmitState = 'idle' | 'submitting' | 'success' | 'error';

const PublicShell: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="min-h-screen bg-h-bg flex items-start justify-center pt-10 pb-16">
    <div className="w-full max-w-[430px] px-6">
      <div className="flex items-center justify-center gap-2.5 mb-8">
        <LogoMark size={32} />
        <span style={{ fontSize: 18, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>FacialPlan</span>
      </div>
      {children}
    </div>
  </div>
);

const StatusScreen: React.FC<{ title: string; body: string }> = ({ title, body }) => (
  <PublicShell>
    <div className="bg-h-white rounded-r shadow-h-sm p-6 text-center flex flex-col items-center gap-2">
      <h1 style={{ fontSize: 19, fontWeight: 800, color: '#1A1918' }}>{title}</h1>
      <p className="text-[14px] text-h-text-2 leading-relaxed">{body}</p>
    </div>
  </PublicShell>
);

// Cor do NPS por faixa (0-6 detrator, 7-8 neutro, 9-10 promotor) — mesma
// convenção padrão de NPS usada no mercado, só para dar feedback visual
// imediato de qual nota está selecionada.
function scoreColor(score: number): string {
  if (score <= 6) return '#E05050';
  if (score <= 8) return '#D4900A';
  return '#1D9A64';
}

const DepoimentoPublico: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const { t } = useTranslation();

  const [tokenState, setTokenState] = useState<TokenState>('loading');
  const [patientFirstName, setPatientFirstName] = useState<string | null>(null);
  const [clinicName, setClinicName] = useState<string | null>(null);

  const [score, setScore] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [submitState, setSubmitState] = useState<SubmitState>('idle');

  useEffect(() => {
    if (!isValidFeedbackToken(token)) {
      setTokenState('not_found');
      return;
    }
    let active = true;
    (async () => {
      try {
        const res = await fetch(`${FUNCTIONS_URL}?token=${encodeURIComponent(token)}`, {
          headers: { apikey: ANON_KEY, Authorization: `Bearer ${ANON_KEY}` },
        });
        const data = await res.json();
        if (!active) return;
        if (data?.valid) {
          setPatientFirstName(data.patientFirstName ?? null);
          setClinicName(data.clinicName ?? null);
          setTokenState('valid');
        } else {
          setTokenState((data?.reason as TokenState) ?? 'not_found');
        }
      } catch {
        if (active) setTokenState('error');
      }
    })();
    return () => {
      active = false;
    };
  }, [token]);

  const handleSubmit = async () => {
    if (!token || score === null) return;
    setSubmitState('submitting');
    try {
      const res = await fetch(FUNCTIONS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: ANON_KEY, Authorization: `Bearer ${ANON_KEY}` },
        body: JSON.stringify({ token, npsScore: score, comment: comment.trim() || undefined }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.success) throw new Error('submit_failed');
      setSubmitState('success');
    } catch {
      setSubmitState('error');
    }
  };

  if (tokenState === 'loading') {
    return (
      <PublicShell>
        <p className="text-center text-[14px] text-h-text-3">{t('feedback.public.validating')}</p>
      </PublicShell>
    );
  }

  if (tokenState === 'not_found' || tokenState === 'error') {
    return <StatusScreen title={t('feedback.public.invalidTitle')} body={t('feedback.public.invalidBody')} />;
  }
  if (tokenState === 'used') {
    return <StatusScreen title={t('feedback.public.usedTitle')} body={t('feedback.public.usedBody')} />;
  }

  if (submitState === 'success') {
    return <StatusScreen title={t('feedback.public.successTitle')} body={t('feedback.public.successBody')} />;
  }

  return (
    <PublicShell>
      <div className="flex flex-col gap-5">
        <div className="text-center">
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#1A1918', letterSpacing: '-0.02em' }}>
            {patientFirstName ? t('feedback.public.greeting', { name: patientFirstName }) : t('feedback.public.title')}
          </h1>
          <p className="text-[13px] text-h-text-2 mt-1">
            {clinicName ? t('feedback.public.introWithClinic', { clinic: clinicName }) : t('feedback.public.intro')}
          </p>
        </div>

        <div className="bg-h-white rounded-r shadow-h-sm p-4">
          <p className="text-[14px] font-bold text-h-text mb-3">{t('feedback.public.scoreLabel')}</p>
          <div className="grid grid-cols-6 sm:grid-cols-11 gap-1.5" role="radiogroup" aria-label={t('feedback.public.scoreLabel')}>
            {NPS_SCALE.map((value) => (
              <button
                key={value}
                type="button"
                role="radio"
                aria-checked={score === value}
                onClick={() => setScore(value)}
                className="h-10 min-h-[40px] rounded-[10px] text-[13px] font-bold transition-all active:scale-[0.95]"
                style={
                  score === value
                    ? { background: scoreColor(value), color: '#fff' }
                    : { background: 'rgba(0,0,0,0.04)', color: '#6B6864' }
                }
              >
                {value}
              </button>
            ))}
          </div>
          <div className="flex items-center justify-between mt-2">
            <span className="text-[11px] text-h-text-3">{t('feedback.public.scoreLow')}</span>
            <span className="text-[11px] text-h-text-3">{t('feedback.public.scoreHigh')}</span>
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[13px] font-semibold text-h-text-2">{t('feedback.public.commentLabel')}</label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value.slice(0, MAX_COMMENT_LENGTH))}
            placeholder={t('feedback.public.commentPlaceholder')}
            rows={4}
            className="w-full rounded-[12px] p-3 text-[14px] bg-h-white border border-black/10 outline-none"
          />
        </div>

        {submitState === 'error' && (
          <p className="text-[13px] text-center" style={{ color: '#E05050' }}>{t('feedback.public.errorGeneric')}</p>
        )}

        <GradientButton onClick={handleSubmit} disabled={score === null || submitState === 'submitting'}>
          {submitState === 'submitting' ? t('feedback.public.submitting') : t('feedback.public.submit')}
        </GradientButton>
      </div>
    </PublicShell>
  );
};

export default DepoimentoPublico;
