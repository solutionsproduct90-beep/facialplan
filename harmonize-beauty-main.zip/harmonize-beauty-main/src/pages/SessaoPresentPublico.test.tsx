import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import SessaoPresentPublico from './SessaoPresentPublico';
import i18n from '@/i18n';

/**
 * The public page talks to the `public-session-presentation` edge function
 * by plain `fetch` (not the authenticated `supabase` client — see the
 * comment at the top of SessaoPresentPublico.tsx), same technique as
 * AnamneseCompartilhada.test.tsx, so the double here is `global.fetch`.
 */
function jsonResponse(body: unknown) {
  return Promise.resolve({ ok: true, json: () => Promise.resolve(body) } as Response);
}

const VALID_TOKEN = '8ce48925-2a03-4b67-b118-e17df300570a';

const renderAt = (path: string) =>
  render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/present/:token" element={<SessaoPresentPublico />} />
      </Routes>
    </MemoryRouter>
  );

describe('SessaoPresentPublico', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    vi.stubGlobal('fetch', vi.fn());
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('shows the invalid-link state without calling the backend for a malformed token', async () => {
    renderAt('/present/not-a-real-token');

    expect(await screen.findByText('Link indisponível')).toBeInTheDocument();
    expect(fetch).not.toHaveBeenCalled();
  });

  it('shows the invalid-link state for a well-formed but unknown token', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: 'not_found' }));

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Link indisponível')).toBeInTheDocument();
    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining(`token=${VALID_TOKEN}`),
      expect.any(Object)
    );
  });

  it('shows the revoked-link state for a token the professional turned off', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: 'revoked' }));

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Link desativado')).toBeInTheDocument();
  });

  it('shows the no-simulation state when the session has nothing to present yet', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: 'no_simulation' }));

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Resultado ainda não disponível')).toBeInTheDocument();
  });

  it('shows the invalid-link state when the request itself fails', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('network down'));

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Link indisponível')).toBeInTheDocument();
  });

  it('renders only the curated presentation fields for a valid, active token', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    await waitFor(() => expect(screen.getByText('Maria Souza')).toBeInTheDocument());
    expect(screen.getByText('Clínica Bela Face')).toBeInTheDocument();
    expect(screen.getByText('Preenchimento labial')).toBeInTheDocument();
    expect(screen.getByText('Natural')).toBeInTheDocument();
    expect(screen.getByText(/proteção de dados/i)).toBeInTheDocument();
    expect(screen.queryByText('Link indisponível')).not.toBeInTheDocument();
  });

  it('renders the real application-point overlay instead of the generic placeholder when present', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [{ label: 'Lábio superior', substance: 'acido_hialuronico', quantity: 1, unit: 'ml' }],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Lábio superior — 1 ml de Ácido Hialurônico')).toBeInTheDocument();
    expect(screen.queryByText('Volume e definição nos lábios')).not.toBeInTheDocument();
  });

  it('shows the patient-facing clinical explanation for a point with finding/clinicalGoal', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [
          {
            label: 'Lábio superior',
            substance: 'acido_hialuronico',
            quantity: 1,
            unit: 'ml',
            finding: 'Volume reduzido no lábio superior',
            clinicalGoal: 'Restaurar volume e contorno do vermelhão',
          },
        ],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Lábio superior — 1 ml de Ácido Hialurônico')).toBeInTheDocument();
    expect(
      screen.getByText('Volume reduzido no lábio superior Restaurar volume e contorno do vermelhão')
    ).toBeInTheDocument();
  });

  it('shows the professional name with registration when the edge function returns both', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        professionalName: 'Dra. Camila Rocha',
        professionalRegistration: 'CRM 123456',
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Responsável: Dra. Camila Rocha — CRM 123456')).toBeInTheDocument();
  });

  it('shows only the professional name when the edge function has no registration to show', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        professionalName: 'Dra. Camila Rocha',
        professionalRegistration: null,
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    expect(await screen.findByText('Responsável: Dra. Camila Rocha')).toBeInTheDocument();
    expect(screen.queryByText(/CRM/)).not.toBeInTheDocument();
  });

  it('shows no responsible-professional line when professionalName is absent', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        professionalName: null,
        professionalRegistration: null,
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    await waitFor(() => expect(screen.getByText('Clínica Bela Face')).toBeInTheDocument());
    expect(screen.queryByText(/Responsável/)).not.toBeInTheDocument();
  });

  it('does not render an explanation line for a manual point with no finding/clinicalGoal', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({
        valid: true,
        patientName: 'Maria Souza',
        clinicName: 'Clínica Bela Face',
        logoUrl: null,
        procedureName: 'Preenchimento labial',
        intensity: 'natural',
        beforeUrl: null,
        afterUrl: null,
        overlay: [{ label: 'Malar direita', substance: 'acido_hialuronico', quantity: 1, unit: 'ml' }],
      })
    );

    renderAt(`/present/${VALID_TOKEN}`);

    const item = await screen.findByText('Malar direita — 1 ml de Ácido Hialurônico');
    // A explicação some inteira quando não há finding/clinicalGoal — não deve
    // sobrar nenhum parágrafo extra vazio no card do item.
    expect(item.parentElement?.children.length).toBe(1);
  });

  const basePayload = {
    valid: true,
    patientName: 'Maria Souza',
    clinicName: 'Clínica Bela Face',
    logoUrl: null,
    procedureName: 'Preenchimento labial',
    intensity: 'natural',
    beforeUrl: null,
    afterUrl: null,
    overlay: [],
  };

  // Achado do QA Contínuo: o botão "Falar com o profissional" abria
  // `wa.me/` sem telefone nem texto nenhum (link morto), porque a edge
  // function nunca devolvia o telefone da clínica. `professionalPhone` (ver
  // public-session-presentation/index.ts) resolve isso — mas só quando
  // presente: sem ele, o botão precisa sumir em vez de abrir o link quebrado.
  describe('botão "Falar com o profissional" (wa.me)', () => {
    it('opens a wa.me link built from the professional phone and a pre-filled message when the phone is present', async () => {
      (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
        jsonResponse({ ...basePayload, patientName: 'Maria Souza', professionalPhone: '11987654321' })
      );
      const openSpy = vi.spyOn(window, 'open').mockImplementation(() => null);

      renderAt(`/present/${VALID_TOKEN}`);

      const button = await screen.findByRole('button', { name: 'Falar com o profissional' });
      fireEvent.click(button);

      expect(openSpy).toHaveBeenCalledTimes(1);
      const [url, target] = openSpy.mock.calls[0];
      expect(url).toMatch(/^https:\/\/wa\.me\/11987654321\?text=/);
      expect(decodeURIComponent(String(url).split('?text=')[1])).toContain('Maria Souza');
      expect(target).toBe('_blank');
    });

    it('hides the button — never opening a phoneless wa.me link — when the professional has no phone on file', async () => {
      (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
        jsonResponse({ ...basePayload, professionalPhone: null })
      );
      const openSpy = vi.spyOn(window, 'open').mockImplementation(() => null);

      renderAt(`/present/${VALID_TOKEN}`);

      await waitFor(() => expect(screen.getByText('Clínica Bela Face')).toBeInTheDocument());
      expect(screen.queryByRole('button', { name: 'Falar com o profissional' })).not.toBeInTheDocument();
      expect(screen.getByText(/Contato direto indisponível/i)).toBeInTheDocument();
      expect(openSpy).not.toHaveBeenCalled();
    });

    it('hides the button the same way for an older payload that omits professionalPhone entirely', async () => {
      (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ ...basePayload }));

      renderAt(`/present/${VALID_TOKEN}`);

      await waitFor(() => expect(screen.getByText('Clínica Bela Face')).toBeInTheDocument());
      expect(screen.queryByRole('button', { name: 'Falar com o profissional' })).not.toBeInTheDocument();
      expect(screen.getByText(/Contato direto indisponível/i)).toBeInTheDocument();
    });
  });

});
