import React, { useState, useEffect, useRef } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Camera, Loader2 } from 'lucide-react';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import BottomSheet from '@/components/harmonize/BottomSheet';
import GradientButton from '@/components/harmonize/GradientButton';
import type { Insumo, InsumoCategory, ThreadType } from '@/types/harmonize';
import { INSUMO_CATEGORY_KEYS, INSUMO_CATEGORY_LABEL, INSUMO_CATEGORY_DEFAULT_UNIT, THREAD_TYPES } from '@/types/harmonize';
import { normalizeInsumos, formatCurrency, type CurrencyCode } from '@/lib/budget';

// Tamanho máximo de foto aceito pro rótulo (mesmo teto de 10MB usado em
// NovaSessao.tsx/AnamneseCompartilhada.tsx para upload de foto) — validado
// no client antes mesmo de gerar o base64, pra não travar a UI convertendo
// um arquivo enorme só pra a edge function rejeitar depois.
const MAX_LABEL_PHOTO_BYTES = 10 * 1024 * 1024;

// Resposta esperada de supabase.functions.invoke('read-insumo-label', ...)
// — todos os campos de sugestão são opcionais (a IA só devolve o que
// conseguiu ler com confiança do rótulo, ver LABEL_PROMPT na edge
// function). `available: false` é o caminho "sem OPENAI_API_KEY
// configurada" (ver supabase/functions/read-insumo-label/index.ts).
type ReadInsumoLabelResponse = {
  available: boolean;
  brandName?: string;
  concentration?: string;
  expiryDate?: string;
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/**
 * Catálogo de insumos/marcas por substância — parte de Perfil.tsx antes de
 * virar tela própria (`/perfil/insumos`). Só cuida do CRUD via BottomSheet;
 * taxa de mão de obra/parcelamento/desconto ficaram em PerfilPagamento.tsx.
 */
const PerfilInsumos: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const [loading, setLoading] = useState(true);
  const [insumos, setInsumos] = useState<Insumo[]>([]);
  const [currency, setCurrency] = useState<CurrencyCode>('BRL');
  const [insumoSheetOpen, setInsumoSheetOpen] = useState(false);
  const [editingInsumoId, setEditingInsumoId] = useState<string | null>(null);
  const [insumoSaving, setInsumoSaving] = useState(false);
  const [draftSubstance, setDraftSubstance] = useState<InsumoCategory>('acido_hialuronico');
  const [draftBrandName, setDraftBrandName] = useState('');
  const [draftCost, setDraftCost] = useState('');
  const [draftPrice, setDraftPrice] = useState('');
  // Atributos de produto só usados quando draftSubstance === 'fios_sustentacao'
  // (ver Insumo.threadType/threadLengthMm em src/types/harmonize.ts) — vazio
  // em qualquer outra categoria, nunca enviado ao salvar.
  const [draftThreadType, setDraftThreadType] = useState<ThreadType | ''>('');
  const [draftThreadLengthMm, setDraftThreadLengthMm] = useState('');
  const [draftConcentration, setDraftConcentration] = useState('');
  const [draftExpiresOn, setDraftExpiresOn] = useState('');
  // Leitura de rótulo por IA (backlog P8-2) — nunca preenche sozinha sem
  // que o profissional dispare a ação, e NUNCA salva automaticamente: só
  // pré-preenche os campos do formulário acima (draftBrandName/
  // draftConcentration/draftExpiresOn) pra revisão. `aiUnavailable` fica
  // `true` assim que a function responder `{ available: false }` uma vez
  // (sem OPENAI_API_KEY configurada) — não faz sentido deixar o
  // profissional tentar de novo dentro da mesma sessão de uso, já que a
  // causa (chave ausente no servidor) não muda entre tentativas.
  const [aiLabelLoading, setAiLabelLoading] = useState(false);
  const [aiUnavailable, setAiUnavailable] = useState(false);
  const labelFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [{ data, error }, { data: profile }] = await Promise.all([
        supabase
          .from('insumos')
          .select('id, substance, brand_name, cost_per_unit, price_per_unit, active, thread_type, thread_length_mm, concentration, expires_on')
          .eq('professional_id', user.id)
          .order('substance', { ascending: true })
          .order('brand_name', { ascending: true }),
        supabase.from('profiles').select('currency').eq('id', user.id).single(),
      ]);
      // Mesma correção aplicada em Perfil.tsx/PerfilPagamento.tsx: uma
      // falha aqui não pode virar silenciosamente "nenhuma marca
      // cadastrada" — isso pareceria com dados perdidos.
      if (error) {
        toast.error(t('profile.loadError'));
      } else {
        setInsumos(normalizeInsumos(data));
      }
      setCurrency((profile?.currency as CurrencyCode) ?? 'BRL');
      setLoading(false);
    })();
  }, [user?.id, t]);

  const openAddInsumo = (substance: InsumoCategory) => {
    setEditingInsumoId(null);
    setDraftSubstance(substance);
    setDraftBrandName('');
    setDraftCost('');
    setDraftPrice('');
    setDraftThreadType('');
    setDraftThreadLengthMm('');
    setDraftConcentration('');
    setDraftExpiresOn('');
    setInsumoSheetOpen(true);
  };

  const openEditInsumo = (insumo: Insumo) => {
    setEditingInsumoId(insumo.id);
    setDraftSubstance(insumo.substance);
    setDraftBrandName(insumo.brandName);
    setDraftCost(String(insumo.costPerUnit));
    setDraftPrice(String(insumo.pricePerUnit));
    setDraftThreadType(insumo.threadType ?? '');
    setDraftThreadLengthMm(insumo.threadLengthMm != null ? String(insumo.threadLengthMm) : '');
    setDraftConcentration(insumo.concentration ?? '');
    setDraftExpiresOn(insumo.expiresOn ?? '');
    setInsumoSheetOpen(true);
  };

  // Converte a foto do rótulo pra base64 e pede à edge function pra ler
  // marca/concentração/validade — SEMPRE pré-preenche os campos do
  // formulário acima pra revisão, nunca salva sozinha (o profissional ainda
  // precisa apertar "Salvar", podendo corrigir qualquer campo antes). Falha
  // de qualquer tipo (rede, IA indisponível, leitura malformada) nunca
  // bloqueia o cadastro manual normal — só avisa e deixa os campos como
  // estavam pro profissional preencher à mão.
  const handleLabelPhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // permite escolher o mesmo arquivo de novo depois de um erro
    if (!file) return;
    if (file.size > MAX_LABEL_PHOTO_BYTES) {
      toast.error(t('profile.insumos.aiPhotoTooLarge'));
      return;
    }

    setAiLabelLoading(true);
    try {
      const imageBase64 = await fileToBase64(file);
      const { data, error } = await supabase.functions.invoke<ReadInsumoLabelResponse>('read-insumo-label', {
        body: { imageBase64, mimeType: file.type },
      });

      if (error || !data) {
        toast.error(t('profile.insumos.aiReadError'));
        return;
      }
      if (!data.available) {
        setAiUnavailable(true);
        toast.message(t('profile.insumos.aiUnavailable'));
        return;
      }
      if (!data.brandName && !data.concentration && !data.expiryDate) {
        // A IA respondeu, mas não conseguiu ler nada com confiança nesta
        // foto — mesmo tratamento de "não deu pra ler automaticamente" do
        // que um erro de rede, sem soar como uma falha técnica.
        toast.error(t('profile.insumos.aiReadError'));
        return;
      }

      // Só sobrescreve os campos que a IA de fato leu — um campo que o
      // profissional já tinha preenchido manualmente (ou que a IA não
      // conseguiu ler) fica intocado.
      if (data.brandName) setDraftBrandName(data.brandName);
      if (data.concentration) setDraftConcentration(data.concentration);
      if (data.expiryDate) setDraftExpiresOn(data.expiryDate);
      toast.success(t('profile.insumos.aiReadSuccess'));
    } catch (err) {
      toast.error(t('profile.insumos.aiReadError'));
    } finally {
      setAiLabelLoading(false);
    }
  };

  const handleSaveInsumo = async () => {
    if (!user) return;
    if (!draftBrandName.trim()) { toast.error(t('profile.insumos.brandNameRequired')); return; }
    const costPerUnit = Number(draftCost) || 0;
    const pricePerUnit = Number(draftPrice) || 0;
    // Campos de fio só são gravados para a categoria fios_sustentacao — pra
    // qualquer outra, sempre null (limpa um valor herdado se o profissional
    // trocar a categoria de um insumo já cadastrado).
    const isThread = draftSubstance === 'fios_sustentacao';
    const threadType = isThread && draftThreadType ? draftThreadType : null;
    const threadLengthMmNum = Number(draftThreadLengthMm);
    const threadLengthMm = isThread && draftThreadLengthMm.trim() && Number.isFinite(threadLengthMmNum) && threadLengthMmNum > 0
      ? threadLengthMmNum
      : null;
    // Concentração/validade (ver Insumo.concentration/expiresOn) — livres e
    // opcionais pra qualquer categoria, ao contrário dos campos de fio
    // acima: tanto a IA quanto o preenchimento manual podem deixá-los em
    // branco sem afetar o salvamento.
    const concentration = draftConcentration.trim() || null;
    const expiresOn = draftExpiresOn || null;
    setInsumoSaving(true);
    try {
      if (editingInsumoId) {
        const { error } = await supabase
          .from('insumos')
          .update({
            brand_name: draftBrandName.trim(),
            substance: draftSubstance,
            cost_per_unit: costPerUnit,
            price_per_unit: pricePerUnit,
            thread_type: threadType,
            thread_length_mm: threadLengthMm,
            concentration,
            expires_on: expiresOn,
          })
          .eq('id', editingInsumoId);
        if (error) throw error;
        setInsumos(prev => prev.map(i => i.id === editingInsumoId
          ? {
              ...i,
              brandName: draftBrandName.trim(),
              substance: draftSubstance,
              costPerUnit,
              pricePerUnit,
              threadType: threadType ?? undefined,
              threadLengthMm: threadLengthMm ?? undefined,
              concentration: concentration ?? undefined,
              expiresOn: expiresOn ?? undefined,
            }
          : i));
      } else {
        const { data, error } = await supabase
          .from('insumos')
          .insert({
            professional_id: user.id,
            substance: draftSubstance,
            brand_name: draftBrandName.trim(),
            cost_per_unit: costPerUnit,
            price_per_unit: pricePerUnit,
            thread_type: threadType,
            thread_length_mm: threadLengthMm,
            concentration,
            expires_on: expiresOn,
          })
          .select('id, substance, brand_name, cost_per_unit, price_per_unit, active, thread_type, thread_length_mm, concentration, expires_on')
          .single();
        if (error) throw error;
        const [created] = normalizeInsumos(data ? [data] : []);
        if (created) setInsumos(prev => [...prev, created]);
      }
      toast.success(t('profile.insumos.toastSaved'));
      setInsumoSheetOpen(false);
    } catch (err: any) {
      toast.error(err.message || t('profile.insumos.toastError'));
    } finally {
      setInsumoSaving(false);
    }
  };

  const handleDeleteInsumo = async (id: string) => {
    const { error } = await supabase.from('insumos').delete().eq('id', id);
    if (error) { toast.error(error.message || t('profile.insumos.toastError')); return; }
    setInsumos(prev => prev.filter(i => i.id !== id));
    toast.success(t('profile.insumos.toastRemoved'));
    setInsumoSheetOpen(false);
  };

  if (loading) {
    return (
      <AppLayout title={t('profile.insumos.title')} showBack onBack={() => navigate('/perfil')}>
        <div className="flex flex-col gap-3">
          <SkeletonCard lines={3} />
          <SkeletonCard lines={3} />
        </div>
      </AppLayout>
    );
  }

  return (
    <PageTransition>
    <AppLayout
      title={t('profile.insumos.title')}
      showBack
      onBack={() => navigate('/perfil')}
    >
      <div className="flex flex-col gap-4">
        <HCard>
          <p className="text-[11px] text-h-text-3 mb-3">{t('profile.insumos.subtitle')}</p>
          <div className="flex flex-col gap-4">
            {INSUMO_CATEGORY_KEYS.map((s) => {
              const unit = INSUMO_CATEGORY_DEFAULT_UNIT[s];
              const items = insumos.filter(i => i.substance === s);
              return (
                <div key={s} className="flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <p className="text-[13px] font-bold text-h-text-2">
                      {t(`profile.insumos.categories.${s}`, { defaultValue: INSUMO_CATEGORY_LABEL[s] })}
                      <span className="text-h-text-3 font-normal"> / {unit}</span>
                    </p>
                    <button
                      onClick={() => openAddInsumo(s)}
                      className="flex items-center gap-1 text-[12px] font-semibold text-h-g-start min-h-[32px]"
                    >
                      <Plus size={14} />
                      {t('profile.insumos.addBrand')}
                    </button>
                  </div>
                  {items.length === 0 ? (
                    <p className="text-[12px] text-h-text-3 pb-1">{t('profile.insumos.empty')}</p>
                  ) : (
                    <div className="flex flex-col gap-1.5">
                      {items.map((insumo) => (
                        <button
                          key={insumo.id}
                          onClick={() => openEditInsumo(insumo)}
                          className="flex items-center gap-3 bg-h-surface rounded-r-sm p-2.5 text-left"
                        >
                          <div className="flex-1 min-w-0">
                            <p className="text-[13px] font-semibold text-h-text truncate">{insumo.brandName}</p>
                            <p className="text-[11px] text-h-text-3">
                              {t('profile.insumos.cost')} {formatCurrency(insumo.costPerUnit, currency)} · {t('profile.insumos.price')} {formatCurrency(insumo.pricePerUnit, currency)}
                            </p>
                          </div>
                          <Pencil size={14} className="text-h-text-3 flex-shrink-0" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </HCard>
      </div>
    </AppLayout>

    <BottomSheet
      open={insumoSheetOpen}
      onClose={() => setInsumoSheetOpen(false)}
      title={editingInsumoId ? t('profile.insumos.editTitle') : t('profile.insumos.newTitle')}
    >
      <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
        <div>
          <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('profile.insumos.substance')}</p>
          <select
            value={draftSubstance}
            onChange={(e) => setDraftSubstance(e.target.value as InsumoCategory)}
            className="w-full bg-h-surface rounded-r-sm px-3 py-3 text-[14px] font-semibold text-h-text outline-none"
          >
            {INSUMO_CATEGORY_KEYS.map(s => (
              <option key={s} value={s}>
                {t(`profile.insumos.categories.${s}`, { defaultValue: INSUMO_CATEGORY_LABEL[s] })}
              </option>
            ))}
          </select>
        </div>

        {/* Leitura de rótulo por IA (backlog P8-2) — some da tela assim que
            a function responder que está indisponível (sem
            OPENAI_API_KEY no servidor), em vez de deixar um botão que
            sempre falharia. Nunca é a única forma de cadastrar: os campos
            abaixo continuam 100% editáveis à mão, com ou sem esta opção. */}
        {!aiUnavailable && (
          <div className="flex flex-col gap-1">
            <input
              ref={labelFileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              data-testid="insumo-label-file-input"
              onChange={handleLabelPhotoChange}
            />
            <button
              type="button"
              onClick={() => labelFileInputRef.current?.click()}
              disabled={aiLabelLoading}
              className="flex items-center justify-center gap-2 rounded-r-sm py-2.5 text-[13px] font-bold text-h-g-start bg-h-surface disabled:opacity-60"
            >
              {aiLabelLoading ? <Loader2 size={15} className="animate-spin" /> : <Camera size={15} />}
              {aiLabelLoading ? t('profile.insumos.aiReading') : t('profile.insumos.aiReadLabel')}
            </button>
            <p className="text-[10px] text-h-text-3 text-center">{t('profile.insumos.aiDisclaimer')}</p>
          </div>
        )}

        <div className="flex flex-col gap-1.5">
          <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.brandName')}</label>
          <input
            value={draftBrandName}
            onChange={(e) => setDraftBrandName(e.target.value)}
            placeholder={t('profile.insumos.brandNamePlaceholder')}
            className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
            style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.concentration')}</label>
            <input
              value={draftConcentration}
              onChange={(e) => setDraftConcentration(e.target.value)}
              placeholder={t('profile.insumos.concentrationPlaceholder')}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
              style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.expiresOn')}</label>
            <input
              type="date"
              value={draftExpiresOn}
              onChange={(e) => setDraftExpiresOn(e.target.value)}
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none focus:ring-2 focus:ring-h-g-mid/30"
              style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.cost')}</label>
            <input
              type="number"
              min={0}
              step="0.01"
              inputMode="decimal"
              value={draftCost}
              onChange={(e) => setDraftCost(e.target.value)}
              placeholder="0,00"
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
              style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.price')}</label>
            <input
              type="number"
              min={0}
              step="0.01"
              inputMode="decimal"
              value={draftPrice}
              onChange={(e) => setDraftPrice(e.target.value)}
              placeholder="0,00"
              className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
              style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
            />
          </div>
        </div>
        {draftSubstance === 'fios_sustentacao' && (
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.threadType')}</label>
              <select
                value={draftThreadType}
                onChange={(e) => setDraftThreadType(e.target.value as ThreadType | '')}
                className="w-full bg-h-surface rounded-r-sm px-3 py-3 text-[14px] font-semibold text-h-text outline-none"
              >
                <option value="">{t('profile.insumos.threadTypeNone')}</option>
                {THREAD_TYPES.map(tt => (
                  <option key={tt} value={tt}>{t(`profile.insumos.threadTypeOption.${tt}`)}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label style={{ fontSize: 11, fontWeight: 700, color: '#AAA8A5' }}>{t('profile.insumos.threadLength')}</label>
              <input
                type="number"
                min={0}
                step="1"
                inputMode="decimal"
                value={draftThreadLengthMm}
                onChange={(e) => setDraftThreadLengthMm(e.target.value)}
                placeholder="0"
                className="h-[48px] min-h-[44px] rounded-r-sm px-[14px] text-[14px] font-semibold text-h-text bg-h-white shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/30"
                style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif" }}
              />
            </div>
          </div>
        )}
        <div className="flex gap-3">
          {editingInsumoId && (
            <button
              onClick={() => handleDeleteInsumo(editingInsumoId)}
              className="flex-1 flex items-center justify-center gap-2 rounded-full py-3 min-h-[44px]"
              style={{ background: 'rgba(224,80,80,0.08)', color: '#E05050' }}
            >
              <Trash2 size={15} />
              <span className="text-[13px] font-bold">{t('profile.insumos.remove')}</span>
            </button>
          )}
          <div className="flex-1">
            <GradientButton onClick={handleSaveInsumo} disabled={insumoSaving}>
              {t('profile.insumos.save')}
            </GradientButton>
          </div>
        </div>
      </div>
    </BottomSheet>
    </PageTransition>
  );
};

export default PerfilInsumos;
