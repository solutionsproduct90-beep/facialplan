import React, { useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useTranslation } from 'react-i18next';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import HarmonizeBadge from '@/components/harmonize/Badge';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import { useAuth } from '@/contexts/AuthContext';
import { hasAppAccess } from '@/lib/subscriptionAccess';
import { toast } from 'sonner';

// Área de assinantes da Hotmart — configure VITE_HOTMART_MEMBER_PORTAL_URL
// no .env assim que o produto for criado. É lá que o comprador cancela a
// própria assinatura (a Hotmart, não este app, processa o cancelamento).
const HOTMART_MEMBER_PORTAL_URL = import.meta.env.VITE_HOTMART_MEMBER_PORTAL_URL as string | undefined;

const Conta: React.FC = () => {
  const { profile } = useAuth();
  const { t } = useTranslation();
  const features = t('account.subscription.features', { returnObjects: true }) as string[];
  const [cancelSheet, setCancelSheet] = useState(false);

  // Achado de auditoria: esta tela comparava só `subscription_status ===
  // 'active'`, então quem está em 'past_due' DENTRO da carência (acesso
  // normal ao app, banner amarelo do SubscriptionGraceBanner) via a badge
  // desta tela dizer "Inativa" — mensagem contraditória com o app
  // funcionando normalmente. `hasAppAccess` (src/lib/subscriptionAccess.ts)
  // já encapsula essa mesma regra usada por ProtectedRoute/paywall
  // (inclusive admin e a carência de past_due), então reaproveitar `profile`
  // do AuthContext em vez de buscar `subscription_status` à parte também
  // elimina uma segunda query redundante em profiles.
  const isActive = hasAppAccess(profile);

  const handleCancel = () => {
    if (HOTMART_MEMBER_PORTAL_URL) {
      window.open(HOTMART_MEMBER_PORTAL_URL, '_blank', 'noopener,noreferrer');
    } else {
      toast.info(t('account.subscription.cancelRequested'));
    }
  };

  return (
    <PageTransition>
    <AppLayout title={t('account.subscription.title')} showBack>
      <div className="flex flex-col gap-4">
        {/* Plan card */}
        <HCard className="overflow-hidden relative">
          <div className="absolute top-0 left-0 right-0 h-1" style={{ background: '#A855B5' }} />
          <div className="pt-2">
            <div className="flex items-center justify-between mb-1">
              <h2 className="text-[18px] font-extrabold text-h-text">{t('account.subscription.planName')}</h2>
              <HarmonizeBadge variant={isActive ? 'baixa' : 'neutral'}>
                {isActive ? t('account.subscription.active') : t('account.subscription.inactive')}
              </HarmonizeBadge>
            </div>
            <p className="text-[13px] text-h-text-2">{t('account.subscription.accessSummary')}</p>
            <p className="text-[12px] text-h-text-3 mt-2">{t('account.subscription.nextBilling')}</p>
          </div>
        </HCard>

        {/* Features */}
        <HCard>
          <p className="text-[14px] font-bold text-h-text mb-3">{t('account.subscription.included')}</p>
          <div className="flex flex-col gap-2.5">
            {features.map((f) => (
              <div key={f} className="flex items-center gap-2.5">
                <div className="w-[6px] h-[6px] rounded-full flex-shrink-0" style={{ background: '#BF5F82' }} />
                <p className="text-[13px] text-h-text-2">{f}</p>
              </div>
            ))}
          </div>
        </HCard>

        {/* Update card */}
        <SecondaryButton onClick={() => toast.info(t('account.subscription.comingSoon'))} className="w-full">
          {t('account.subscription.updateCard')}
        </SecondaryButton>

        {/* Cancel section */}
        <div className="mt-4">
          <p className="text-[11px] text-h-text-3 text-center mb-3">
            {t('account.subscription.cancelHint')}
          </p>
          <button
            onClick={() => setCancelSheet(true)}
            style={{
              width: '100%', minHeight: 48, borderRadius: 12, fontWeight: 700,
              fontSize: 15, background: 'rgba(224,80,80,0.08)', color: '#E05050',
              border: 'none', cursor: 'pointer',
              fontFamily: "'Plus Jakarta Sans', sans-serif",
            }}
          >
            {t('account.subscription.cancelSubscription')}
          </button>
          <BottomSheet open={cancelSheet} onClose={() => setCancelSheet(false)}>
            <div style={{ padding: '8px 16px 16px' }}>
              <p style={{ fontSize: 13, color: '#AAA8A5', textAlign: 'center', marginBottom: 16, padding: '0 20px' }}>
                {t('account.subscription.cancelHint')}
              </p>
              <button
                onClick={() => { handleCancel(); setCancelSheet(false); }}
                style={{
                  width: '100%', padding: 16, fontSize: 16, fontWeight: 600,
                  color: '#E05050', background: '#F5F4F2', border: 'none',
                  borderRadius: 12, cursor: 'pointer', marginBottom: 8,
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                }}
              >
                {t('account.subscription.confirmCancel')}
              </button>
              <button
                onClick={() => setCancelSheet(false)}
                style={{
                  width: '100%', padding: 16, fontSize: 16, fontWeight: 600,
                  color: '#1A1918', background: '#F5F4F2', border: 'none',
                  borderRadius: 12, cursor: 'pointer',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                }}
              >
                {t('account.subscription.back')}
              </button>
            </div>
          </BottomSheet>
        </div>
      </div>
    </AppLayout>
    </PageTransition>
  );
};

export default Conta;
