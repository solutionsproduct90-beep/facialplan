import React from "react";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import AnamneseCompartilhada from "./AnamneseCompartilhada";
import i18n from "@/i18n";

/**
 * A página pública fala com a edge function `public-anamnesis` por `fetch`
 * puro (não pelo client `supabase` autenticado — ver comentário no topo de
 * AnamneseCompartilhada.tsx), então o dublê aqui é o `global.fetch`: a
 * primeira chamada (GET) valida o token, a segunda (POST, quando o form é
 * enviado) grava a anamnese.
 */
function jsonResponse(body: unknown, ok = true) {
  return Promise.resolve({
    ok,
    json: () => Promise.resolve(body),
  } as Response);
}

const renderPage = (token = "tok-1") =>
  render(
    <MemoryRouter initialEntries={[`/anamnese/${token}`]}>
      <Routes>
        <Route path="/anamnese/:token" element={<AnamneseCompartilhada />} />
      </Routes>
    </MemoryRouter>
  );

describe("AnamneseCompartilhada — validação de token e envio", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    vi.stubGlobal("fetch", vi.fn());
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("shows a clear error screen for a token that doesn't exist", async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: "not_found" }));

    renderPage();

    expect(await screen.findByText("Link indisponível")).toBeInTheDocument();
    expect(screen.getByText(/Peça um novo link ao seu profissional/)).toBeInTheDocument();
  });

  it("shows a clear error screen for an expired token", async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: "expired" }));

    renderPage();

    expect(await screen.findByText("Link expirado")).toBeInTheDocument();
  });

  it("shows a clear error screen for an already-used token", async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: "used" }));

    renderPage();

    expect(await screen.findByText("Anamnese já enviada")).toBeInTheDocument();
  });

  it("loads the form for a valid token, greeting the patient by first name", async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({ valid: true, patientFirstName: "Maria" })
    );

    renderPage();

    expect(await screen.findByText("Olá, Maria!")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar" })).toBeInTheDocument();
  });

  it("submits the filled form to the edge function and shows the success screen", async () => {
    const fetchMock = fetch as ReturnType<typeof vi.fn>;
    fetchMock.mockReturnValueOnce(jsonResponse({ valid: true, patientFirstName: "Maria" }));
    fetchMock.mockReturnValueOnce(jsonResponse({ success: true }));

    renderPage("tok-valid");

    await screen.findByText("Olá, Maria!");

    fireEvent.change(screen.getByPlaceholderText("O que o paciente deseja tratar ou melhorar?"), {
      target: { value: "Volume labial" },
    });

    // O botão de envio fica desabilitado até o consentimento de uso de
    // dados/fotos ser marcado — ver checkbox obrigatório em
    // AnamneseCompartilhada.tsx.
    expect(screen.getByRole("button", { name: "Enviar" })).toBeDisabled();
    fireEvent.click(screen.getByRole("checkbox", { name: /proteção de dados/i }));
    expect(screen.getByRole("button", { name: "Enviar" })).toBeEnabled();

    fireEvent.click(screen.getByRole("button", { name: "Enviar" }));

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));

    const postCall = fetchMock.mock.calls[1];
    expect(postCall[0]).toContain("public-anamnesis");
    const postBody = JSON.parse(postCall[1].body as string);
    expect(postBody.token).toBe("tok-valid");
    expect(postBody.mainComplaint).toBe("Volume labial");
    expect(postBody.consentDataProcessing).toBe(true);

    expect(await screen.findByText("Recebemos suas informações!")).toBeInTheDocument();
  });

  it("hides questions the professional disabled in /perfil/anamnese", async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({ valid: true, patientFirstName: "Maria", disabledQuestions: ["keloid_tendency"] })
    );

    renderPage("tok-valid");
    await screen.findByText("Olá, Maria!");

    expect(screen.queryByText(/tendência a formar queloides/i)).not.toBeInTheDocument();
    expect(screen.getByText(/Você tem diabetes\?/)).toBeInTheDocument();
  });
});
