import React, { useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { format, type Locale } from 'date-fns';
import { ptBR, enUS, es, fr, it } from 'date-fns/locale';
import { Copy, Inbox, Link2, Pencil, Share2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import SecondaryButton from '@/components/harmonize/SecondaryButton';
import GhostButton from '@/components/harmonize/GhostButton';
import AuthInput from '@/components/harmonize/AuthInput';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { useMinisiteLink } from '@/hooks/useMinisiteLink';
import { buildMinisiteLink } from '@/lib/minisiteLink';

const dateFnsLocale: Record<string, Locale> = { pt: ptBR, en: enUS, es, fr, it };

interface LeadRow {
  id: string;
  name: string;
  contact: string;
  message: string | null;
  created_at: string;
}

/**
 * Tela do profissional pro Mini-site/Página de Captação (P4): mostra/edita o
 * link público (/m/:slug, ver useMinisiteLink.ts) e lista os leads recebidos
 * pelo formulário daquela landing page. Leads são só-leitura aqui — a
 * gravação é exclusiva da edge function pública `public-minisite` (ver
 * migration 20260911030100_add_marketing_leads.sql: sem policy de INSERT
 * para authenticated).
 */
const MeusLeads: React.FC = () => {
  const { user } = useAuth();
  const { t, i18n } = useTranslation();
  const minisite = useMinisiteLink();

  const [editingSlug, setEditingSlug] = useState(false);
  const [slugInput, setSlugInput] = useState('');

  const { data: leads, isLoading } = useQuery({
    queryKey: ['marketing-leads', user?.id],
    queryFn: () =>
      // Paginado (src/lib/fetchAllRows.ts): lead é contato comercial, e o teto
      // de linhas por resposta do PostgREST (Max Rows, 1000 por padrão) é
      // aplicado em silêncio — sem paginar, um mini-site que converte bem
      // esconderia leads antigos sem nenhum aviso de lista parcial.
      fetchAllRows<LeadRow>((from, to) =>
        supabase
          .from('marketing_leads')
          .select('id, name, contact, message, created_at')
          .eq('professional_id', user!.id)
          .order('created_at', { ascending: false })
          .range(from, to),
      ),
    enabled: !!user,
  });

  const currentLink = minisite.slug ? buildMinisiteLink(window.location.origin, minisite.slug) : null;

  const handleSaveSlug = async () => {
    const ok = await minisite.updateSlug(slugInput);
    if (ok) setEditingSlug(false);
  };

  return (
    <PageTransition>
      <AppLayout title={t('leads.title')} showBack>
        <div className="flex flex-col gap-4">
          {/* ── Link público do mini-site ── */}
          <HCard>
            <div className="flex items-center gap-2 mb-1">
              <Link2 size={16} style={{ color: '#A855B5' }} />
              <p className="text-[13px] font-bold text-h-text">{t('leads.link.title')}</p>
            </div>
            <p className="text-[12px] text-h-text-2 mb-3">{t('leads.link.description')}</p>

            {editingSlug ? (
              <div className="flex flex-col gap-3">
                <AuthInput
                  label={t('leads.link.slugLabel')}
                  value={slugInput}
                  onChange={(e) => setSlugInput(e.target.value.toLowerCase())}
                  placeholder={t('leads.link.slugPlaceholder')}
                  maxLength={60}
                />
                <div className="flex gap-2">
                  <SecondaryButton onClick={handleSaveSlug} disabled={minisite.busy || !slugInput.trim()} className="flex-1">
                    {t('leads.link.saveButton')}
                  </SecondaryButton>
                  <GhostButton onClick={() => setEditingSlug(false)} disabled={minisite.busy} className="!w-auto px-3">
                    {t('leads.link.cancelButton')}
                  </GhostButton>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {currentLink && (
                  <p className="text-[12.5px] font-mono text-h-text bg-h-surface-2/60 rounded-[10px] px-3 py-2 break-all">
                    {currentLink}
                  </p>
                )}
                <div className="flex gap-2">
                  <SecondaryButton onClick={() => void minisite.copyLink()} disabled={minisite.busy || minisite.loading} className="flex-1">
                    <span className="flex items-center justify-center gap-1.5">
                      <Copy size={14} /> {t('leads.link.copyButton')}
                    </span>
                  </SecondaryButton>
                  <SecondaryButton onClick={() => void minisite.sendWhatsApp()} disabled={minisite.busy || minisite.loading} className="!w-auto px-3">
                    <Share2 size={14} />
                  </SecondaryButton>
                  <GhostButton
                    onClick={() => {
                      setSlugInput(minisite.slug ?? '');
                      setEditingSlug(true);
                    }}
                    disabled={minisite.busy || minisite.loading}
                    className="!w-auto px-3"
                  >
                    <Pencil size={14} />
                  </GhostButton>
                </div>
              </div>
            )}
          </HCard>

          {/* ── Leads recebidos ── */}
          {isLoading ? (
            <div className="flex flex-col gap-3">
              <SkeletonCard lines={2} />
              <SkeletonCard lines={2} />
            </div>
          ) : !leads || leads.length === 0 ? (
            <HCard className="flex flex-col items-center gap-2 text-center py-8">
              <Inbox size={28} style={{ color: '#AAA8A5' }} />
              <p className="text-[13px] font-semibold text-h-text">{t('leads.emptyTitle')}</p>
              <p className="text-[12px] text-h-text-3">{t('leads.emptyHint')}</p>
            </HCard>
          ) : (
            <div className="flex flex-col gap-3">
              {leads.map((lead) => (
                <HCard key={lead.id}>
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-[14px] font-semibold text-h-text">{lead.name}</p>
                    <p className="text-[11px] text-h-text-3">
                      {format(new Date(lead.created_at), 'Pp', { locale: dateFnsLocale[i18n.language] ?? ptBR })}
                    </p>
                  </div>
                  <p className="text-[12.5px] text-h-text-2">{lead.contact}</p>
                  {lead.message && (
                    <p className="text-[12px] text-h-text-3 mt-1.5 leading-snug">{lead.message}</p>
                  )}
                </HCard>
              ))}
            </div>
          )}
        </div>
      </AppLayout>
    </PageTransition>
  );
};

export default MeusLeads;
