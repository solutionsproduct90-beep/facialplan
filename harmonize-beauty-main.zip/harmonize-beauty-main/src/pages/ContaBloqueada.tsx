import React from 'react';
import { AlertTriangle, LogOut } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import GhostButton from '@/components/harmonize/GhostButton';

// Tela de destino quando profiles.is_blocked = true (ProtectedRoute
// redireciona pra cá). Precisa de uma saída — sem o botão de logout abaixo
// o usuário bloqueado ficava preso aqui sem conseguir nem deslogar.
const ContaBloqueada: React.FC = () => {
  const { t } = useTranslation();
  const { signOut } = useAuth();

  return (
    <div className="min-h-screen bg-h-bg flex items-start justify-center pt-20">
      <div className="w-full max-w-[430px] px-6 text-center">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(224,80,80,0.08)' }}>
            <AlertTriangle size={28} style={{ color: 'hsl(0 70% 60%)' }} />
          </div>
        </div>
        <h1 className="text-[24px] font-extrabold text-h-text mb-2">{t('account.blocked.title')}</h1>
        <p className="text-[15px] text-h-text-2 leading-relaxed mb-8">
          {t('account.blocked.message')}
          <br />
          <strong className="text-h-text">suporte@harmonize.app</strong>
        </p>
        <GhostButton onClick={signOut}>
          <span className="flex items-center justify-center gap-2">
            <LogOut size={16} />
            {t('common.signOut')}
          </span>
        </GhostButton>
      </div>
    </div>
  );
};

export default ContaBloqueada;
