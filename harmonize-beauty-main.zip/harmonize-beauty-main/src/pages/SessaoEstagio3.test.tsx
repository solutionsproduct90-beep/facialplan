import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import SessaoEstagio3 from './SessaoEstagio3';
import { createQueryBuilder } from '@/test/supabaseMock';
import i18n from '@/i18n';
import type { ApplicationPoint } from '@/types/harmonize';

/**
 * Integration coverage for the three PDF opportunities of this squad
 * (Full Face Academy competitive analysis): the Plano A/Plano B budget
 * split, the verification QR code, and the revised disclaimer — all three
 * only observable together at the point `handleExportPdf` (SessaoEstagio3.tsx)
 * actually draws the document. Runs the *real* jsPDF and the *real*
 * `qrcode` library (both work headlessly under jsdom — see
 * src/lib/qrCode.ts and src/lib/procedureCatalog.ts for the unit-level
 * coverage of the pure logic).
 *
 * jsPDF (v4) assigns `.text`/`.addImage` etc as OWN properties on each
 * instance from inside its constructor (not shared prototype methods —
 * confirmed by inspecting a real instance), so `vi.spyOn(jsPDF.prototype,
 * 'text')` silently spies on nothing. Instead, `jspdf` is mocked with a thin
 * subclass that re-wraps `this.text`/`this.addImage` right after calling
 * `super()`, recording every call while still delegating to the real
 * implementation — the document produced is byte-for-byte what the app
 * would really generate, we just get to observe what was drawn into it.
 */
// `textCallPages[i]` is the page number (`doc.internal.getCurrentPageInfo().pageNumber`)
// the doc was on at the time `textCalls[i]` was made — same index, pushed in
// lockstep from inside the mock below. Used by the page-break regression
// suite further down to check that a section title and the content drawn
// right after it always land on the same page (bug P2 "Quebra de página do
// PDF corta seção ao meio" — see src/lib/pdfLayout.ts).
const { textCalls, addImageCalls, textCallPages } = vi.hoisted(() => ({
  textCalls: [] as unknown[][],
  addImageCalls: [] as unknown[][],
  textCallPages: [] as number[],
}));

vi.mock('jspdf', async () => {
  const actual = await vi.importActual<typeof import('jspdf')>('jspdf');
  class SpyingJsPDF extends actual.jsPDF {
    constructor(...args: unknown[]) {
      super(...args);
      const originalText = this.text.bind(this);
      this.text = (...a: unknown[]) => {
        textCalls.push(a);
        textCallPages.push(this.getCurrentPageInfo().pageNumber);
        return originalText(...a);
      };
      const originalAddImage = this.addImage.bind(this);
      this.addImage = (...a: unknown[]) => {
        addImageCalls.push(a);
        return originalAddImage(...a);
      };
      // `doc.save()` runs after `doc.output('blob')` in handleExportPdf — by
      // then the blob already reflects everything drawn above, so save()
      // itself is pure download-trigger side effect we don't need for these
      // assertions. Left un-stubbed, jsPDF's Node fallback for `.save()`
      // writes a real PDF file into the current working directory on every
      // test run (confirmed while developing this test) — a no-op here
      // keeps the test hermetic (no stray files in the repo checkout).
      // @ts-expect-error — no-op stub, save()'s return type isn't used by the app
      this.save = () => this;
    }
  }
  return { ...actual, jsPDF: SpyingJsPDF };
});

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const sessionsUpdateSpy = vi.fn();
const presentLinkInsertSpy = vi.fn();
const uploadSpy = vi.fn().mockResolvedValue({ error: null });
const errorLogsInsertSpy = vi.fn();

/**
 * Stand-in de `supabase.from('error_logs')` para os testes desta tela.
 *
 * O `insert` PRECISA devolver um objeto com `then`. O cliente real devolve um
 * `PostgrestBuilder`, que implementa `PromiseLike` — e é justamente chamando
 * `then` que `src/lib/logClientError.ts` dispara a requisição. Um mock que
 * devolvesse `undefined`, como este devolvia até o ciclo 54 do QA Contínuo,
 * não quebra o teste (a asserção sobre o payload continua passando, porque
 * `insert` foi chamado) mas deixa escapar um TypeError como Unhandled
 * Rejection. O Vitest reporta isso como "Errors: 1 error" ao lado de uma
 * suíte verde, com o aviso de que pode gerar falso positivo.
 *
 * Uma função em vez das nove cópias que existiam: um mock de nove lugares é
 * um mock que diverge no décimo.
 */
function errorLogsBuilder() {
  return {
    insert: (payload: unknown) => {
      errorLogsInsertSpy(payload);
      return {
        then: (aoResolver: (r: { data: null; error: null }) => void) =>
          aoResolver({ data: null, error: null }),
      };
    },
  };
}
const functionsInvokeSpy = vi.fn();
// Override do stage1_analysis retornado por `sessions.select()` — usado pelo
// teste de robustez do cast não validado (`as unknown as Stage1Analysis` em
// SessaoEstagio3.tsx) mais abaixo.
let stage1AnalysisOverride: unknown = null;
// Orientações pré/pós-procedimento (backlog P1, v1 reduzida) — texto
// configurado em Perfil.tsx (profiles.pre_post_care_instructions), lido por
// SessaoEstagio3.tsx pro PDF e pras mensagens de WhatsApp/e-mail. `null` por
// padrão reproduz um profissional que nunca preencheu o campo.
let profileCareInstructions: string | null = null;
// null (padrão) = paciente sem e-mail cadastrado, exercitando o fallback
// pra mailto: de handleShareEmail — sobrescrito por teste pra exercitar o
// envio direto via Resend (send-patient-email).
let patientEmailOverride: string | null = null;

vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom');
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: {
      from: () => ({
        createSignedUrl: async () => ({ data: { signedUrl: null } }),
        upload: (...args: unknown[]) => uploadSpy(...args),
      }),
    },
    rpc: vi.fn().mockResolvedValue({ error: null }),
    functions: {
      invoke: (...args: unknown[]) => functionsInvokeSpy(...args),
    },
  },
}));

// A ponto acima da faixa "suave" de preenchimento_labial (0.5-1.0) para que
// o Plano B calculado seja de fato mais enxuto que o Plano A (ver
// hasReducedPlanB em src/lib/procedureCatalog.ts) — sem isso a seção de dois
// planos não seria desenhada.
const POINTS: ApplicationPoint[] = [
  {
    id: 'p1',
    region: 'labio_superior',
    label: 'Lábio Superior',
    substance: 'acido_hialuronico',
    quantity: 2,
    unit: 'ml',
    x: 0.5,
    y: 0.5,
    source: 'manual',
    procedureId: 'preenchimento_labial',
    insumoId: 'ins-1',
  },
];

function createSessionsBuilder(stage1Analysis: unknown = null, stage2Overlay: ApplicationPoint[] = POINTS) {
  const selectResolution = {
    data: {
      patient_id: 'pat-1',
      selected_procedure: 'Harmonização Facial',
      stage2_overlay: stage2Overlay,
      original_image_url: null,
      // Truthy simulation_url is what flips genState to 'done' on load,
      // which is what makes the Share sheet (and its PDF export rows)
      // reachable at all.
      simulation_url: 'sim.png',
      simulation_intensity: 'natural',
      stage1_analysis: stage1Analysis,
    },
  };
  // `sessions` é consultada de duas formas bem diferentes no mesmo load():
  // uma vez com `.single()` pra pegar ESTA sessão (resolve pra
  // `selectResolution`, um objeto), e outra sem `.single()` — filtrando por
  // `patient_id`/`status`/`neq(id)` — pro histórico de sessões concluídas
  // anteriores da paciente, usado pelo gate opcional `toxinMinInterval` do
  // selo de conformidade (ver src/lib/complianceSummary.ts). Real Supabase
  // resolve a segunda pra uma LISTA (array), nunca pro mesmo objeto —
  // `isSingle` replica essa diferença aqui; sem isso, o `.forEach` sobre
  // `pastSessions` em SessaoEstagio3.tsx quebraria (objeto não tem
  // `.forEach`). Nenhum teste deste arquivo depende de histórico real, então
  // uma lista vazia (nenhuma sessão anterior) é a resolução certa.
  let isSingle = false;
  const builder = {
    select: () => builder,
    eq: () => builder,
    neq: () => builder,
    single: () => {
      isSingle = true;
      return builder;
    },
    update: (payload: unknown) => {
      sessionsUpdateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
    then: (onFulfilled: (v: unknown) => unknown) =>
      Promise.resolve(isSingle ? selectResolution : { data: [] }).then(onFulfilled),
  };
  return builder;
}

// Stand-in for the `session_present_links` table queried by
// useSessionPresentLink.ts — starts with no active link (mirrors a session
// that never had its public present link generated before), so exporting
// the patient PDF must create one via `ensureLink()`'s insert.
function createPresentLinkBuilder() {
  let token: string | null = null;
  const builder = {
    select: () => builder,
    eq: () => builder,
    is: () => builder,
    order: () => builder,
    limit: () => builder,
    maybeSingle: () => Promise.resolve({ data: token ? { token } : null }),
    insert: (payload: unknown) => {
      presentLinkInsertSpy(payload);
      token = 'present-token-abc';
      return {
        select: () => ({
          single: () => Promise.resolve({ data: { token }, error: null }),
        }),
      };
    },
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={['/sessoes/s1/estagio-3']}>
      <Routes>
        <Route path="/sessoes/:id/estagio-3" element={<SessaoEstagio3 />} />
      </Routes>
    </MemoryRouter>
  );

describe('SessaoEstagio3 — exportação de PDF (Plano A/B, QR de verificação, disclaimer)', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    textCalls.length = 0;
    addImageCalls.length = 0;
    textCallPages.length = 0;

    stage1AnalysisOverride = null;
    profileCareInstructions = null;
    patientEmailOverride = null;
    errorLogsInsertSpy.mockReset();
    functionsInvokeSpy.mockReset();
    functionsInvokeSpy.mockResolvedValue({ data: { sent: true, source: 'live' }, error: null });
    // Usado só pelos testes de compartilhamento (handleShareWhatsApp) abaixo
    // — window.open real do jsdom não navega de verdade, mas mockar deixa a
    // asserção explícita sobre a URL/gesto.
    vi.spyOn(window, 'open').mockImplementation(() => null);

    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(stage1AnalysisOverride);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        const patient = { name: 'Maria Silva', email: patientEmailOverride };
        return createQueryBuilder({ data: patient }, { data: patient });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: profileCareInstructions,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  it('draws the current disclaimer and the verification QR (from the present link) in the patient PDF — no budget/Plano A-B (price is never shown to the patient)', async () => {
    renderPage();

    // Só aparece quando genState vira 'done' no efeito de carga.
    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    // handleExportPdf termina persistindo o PDF e atualizando sessions.pdf_url
    // (só na versão do paciente) — esperar por isso garante que toda a
    // geração assíncrona (incluindo o QR) já rodou antes das asserções.
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    // ---------- Decisão de escopo do QR: reaproveita o link público de apresentação ----------
    expect(presentLinkInsertSpy).toHaveBeenCalledWith({ session_id: 's1', professional_id: 'pro-1' });
    expect(addImageCalls).toHaveLength(1);
    const [qrDataUrl, qrFormat] = addImageCalls[0];
    expect(qrDataUrl).toMatch(/^data:image\/png;base64,/);
    expect(qrFormat).toBe('PNG');

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );

    // ---------- Disclaimer revisado ----------
    const expectedDisclaimer = i18n.t('sessions.stage3.pdf.disclaimer');
    expect(flattenedTexts).toContain(expectedDisclaimer);
    // Não repete a contradição do concorrente (alegar eliminar todo risco de
    // artificialidade num documento que no mesmo parágrafo diz ser gerado
    // por IA sem constituir garantia de resultado).
    expect(expectedDisclaimer.toLowerCase()).not.toContain('elimina');

    // Preço/orçamento (incluindo o Plano A/B) é visão exclusiva do
    // profissional — nunca aparece no PDF do paciente (decisão de produto já
    // existente, ver comentário em handleExportPdf).
    expect(flattenedTexts).not.toContain(i18n.t('sessions.stage3.pdf.planALabel').toUpperCase());
    expect(flattenedTexts.some((text) => text.includes('INVESTIMENTO'))).toBe(false);
  });

  it('draws the disclaimer and the Plano A/Plano B budget split in the professional PDF, without any verification QR (no public-link side effect)', async () => {
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfProfessional')));

    // A versão profissional nunca escreve sessions.pdf_url (só a do
    // paciente) — espera pelo upload no storage como sinal de conclusão.
    await waitFor(() => expect(uploadSpy).toHaveBeenCalled());

    // Nenhum link público de apresentação é criado pra gerar o PDF do
    // profissional (só o do paciente carrega o QR de verificação).
    expect(presentLinkInsertSpy).not.toHaveBeenCalled();
    expect(addImageCalls).toHaveLength(0);

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );

    // ---------- Disclaimer revisado (idêntico nos dois públicos) ----------
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.disclaimer'));

    // ---------- Plano A / Plano B lado a lado ----------
    // O ponto de teste usa procedureId 'preenchimento_labial' com dose acima
    // da faixa "suave" (ver hasReducedPlanB em procedureCatalog.ts), então o
    // Plano B calculado é de fato mais enxuto e os dois cartões são desenhados.
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.planALabel').toUpperCase());
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.planBLabel').toUpperCase());
  });

  // Regressão do bug reportado ("clica em PDF e não acontece nada"):
  // `stage1_analysis` chega do banco via cast não validado (`as unknown as
  // Stage1Analysis`) — `attentionPoints` tipado como `string[]` mas sem
  // NENHUMA garantia disso em runtime pro client (o servidor valida na
  // gravação, mas uma sessão antiga/gravada por outro caminho pode não ter
  // passado por essa validação). Antes da correção, `attentionPoints` como
  // string (que também tem `.length`, passando pelo guard antigo) lançava
  // `TypeError: ...flatMap is not a function` no meio do handler, sem
  // try/catch em volta — a Promise rejeitava em silêncio e nada acontecia
  // pro profissional.
  it('does not crash the PDF export when stage1_analysis.attentionPoints comes back as a plain string instead of an array', async () => {
    stage1AnalysisOverride = {
      suggestions: [],
      attentionPoints: 'Achado único gravado como string solta, não como array',
    };
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    // O export completa normalmente (persiste o PDF) em vez de travar sem
    // nenhum feedback — a guarda `Array.isArray` descarta o campo malformado
    // e segue sem essa seção, igual ao padrão já usado pros demais campos
    // opcionais de stage1_analysis.
    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    expect(errorLogsInsertSpy).not.toHaveBeenCalled();
  });
});

// Achado do QA Contínuo: `hasBudget` (budget.totalPrice > 0) fazia a seção de
// orçamento inteira sumir do PDF profissional, sem explicação nenhuma,
// sempre que nenhum ponto tinha preço (nenhum insumo/marca atribuído) — e
// mesmo quando a seção aparecia (parte dos pontos com preço), não havia
// nenhum aviso sobre os pontos que ficaram de fora do total. Ver
// src/lib/budget.ts#computeBudget (campo `unpriced`) e o bloco logo após a
// seção de orçamento em handleExportPdf (SessaoEstagio3.tsx).
describe('SessaoEstagio3 — nota de pontos sem preço no orçamento do PDF profissional', () => {
  const UNPRICED_POINT: ApplicationPoint = {
    id: 'p2',
    region: 'malar_direita',
    label: 'Malar Direita',
    substance: 'acido_hialuronico',
    quantity: 1,
    unit: 'ml',
    x: 0.7,
    y: 0.5,
    source: 'manual',
    // Sem insumoId — cai em `budget.unpriced` (nenhuma marca/insumo atribuído).
  };

  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    textCalls.length = 0;
    addImageCalls.length = 0;
    textCallPages.length = 0;
    errorLogsInsertSpy.mockReset();
    functionsInvokeSpy.mockReset();
    functionsInvokeSpy.mockResolvedValue({ data: { sent: true, source: 'live' }, error: null });
    vi.spyOn(window, 'open').mockImplementation(() => null);

    fromMock.mockImplementation((table: string) => {
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        const patient = { name: 'Maria Silva', email: null };
        return createQueryBuilder({ data: patient }, { data: patient });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: null,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  const exportProfessionalPdf = async () => {
    renderPage();
    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfProfessional')));
    await waitFor(() => expect(uploadSpy).toHaveBeenCalled());
    return textCalls.map(([content]) => (Array.isArray(content) ? (content as string[]).join(' ') : (content as string)));
  };

  it('shows a discreet note (singular) instead of hiding the whole budget section when every point lacks a price', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(null, [UNPRICED_POINT]);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') return createQueryBuilder({ data: { name: 'Maria Silva', email: null } }, { data: { name: 'Maria Silva', email: null } });
      if (table === 'profiles') {
        const profile = { full_name: 'Dra. Ana', clinic_name: 'Clínica Exemplo', logo_url: null, labor_fee_per_session: 100, max_installments: 3, cash_discount_pct: 5, pre_post_care_instructions: null };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      // Nenhum insumo cadastrado com o id do ponto — fica sem preço.
      if (table === 'insumos') return createQueryBuilder({ data: [] });
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });

    const flattenedTexts = await exportProfessionalPdf();

    // A seção de orçamento em si (o "INVESTIMENTO ESTIMADO") não aparece —
    // totalPrice é 0 — mas a nota explica por quê, em vez de sumir em
    // silêncio.
    expect(flattenedTexts.some((text) => text.includes('INVESTIMENTO'))).toBe(false);
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.budgetUnpricedNote', { count: 1 }));
  });

  it('shows the note alongside the normal budget card when only some points lack a price', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(null, [...POINTS, UNPRICED_POINT]);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') return createQueryBuilder({ data: { name: 'Maria Silva', email: null } }, { data: { name: 'Maria Silva', email: null } });
      if (table === 'profiles') {
        const profile = { full_name: 'Dra. Ana', clinic_name: 'Clínica Exemplo', logo_url: null, labor_fee_per_session: 100, max_installments: 3, cash_discount_pct: 5, pre_post_care_instructions: null };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });

    const flattenedTexts = await exportProfessionalPdf();

    // O card de orçamento normal (com o total precificado) continua
    // aparecendo — a nota só complementa, nunca substitui.
    expect(flattenedTexts.some((text) => text.includes('INVESTIMENTO'))).toBe(true);
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.budgetUnpricedNote', { count: 1 }));
  });

  it('never shows the note (nor breaks the export) when every point already has a price', async () => {
    const flattenedTexts = await (async () => {
      fromMock.mockImplementation((table: string) => {
        if (table === 'sessions') return createSessionsBuilder(null, POINTS);
        if (table === 'error_logs') return errorLogsBuilder();
        if (table === 'patients') return createQueryBuilder({ data: { name: 'Maria Silva', email: null } }, { data: { name: 'Maria Silva', email: null } });
        if (table === 'profiles') {
          const profile = { full_name: 'Dra. Ana', clinic_name: 'Clínica Exemplo', logo_url: null, labor_fee_per_session: 100, max_installments: 3, cash_discount_pct: 5, pre_post_care_instructions: null };
          return createQueryBuilder({ data: profile }, { data: profile });
        }
        if (table === 'insumos') {
          return createQueryBuilder({
            data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
          });
        }
        if (table === 'session_present_links') return createPresentLinkBuilder();
        return createQueryBuilder();
      });
      return exportProfessionalPdf();
    })();

    expect(flattenedTexts.some((text) => text.includes('INVESTIMENTO'))).toBe(true);
    expect(flattenedTexts.some((text) => text.includes('sem preço'))).toBe(false);
  });
});

// Backlog P1 "Orientações pré/pós-procedimento" (v1 reduzida): texto único
// configurado pelo profissional em Perfil.tsx (profiles.pre_post_care_instructions),
// anexado automaticamente à seção "Orientações" do PDF e ao final da
// mensagem de WhatsApp já existente — nunca por procedimento específico do
// catálogo (fora de escopo nesta v1). O caminho de e-mail é coberto à parte
// (ver describe "Enviar por e-mail" abaixo): quando o paciente tem e-mail
// cadastrado, o envio passa a ser via send-patient-email/Resend, cujo corpo
// já inclui as orientações (ver buildEmailHtml em
// supabase/functions/send-patient-email/index.ts) — não há mais um mailto:
// client-side pra esse caminho, então essa combinação não é testável aqui.
describe('SessaoEstagio3 — orientações pré/pós-procedimento anexadas ao compartilhamento', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    textCalls.length = 0;
    addImageCalls.length = 0;
    textCallPages.length = 0;
    stage1AnalysisOverride = null;
    profileCareInstructions = null;
    errorLogsInsertSpy.mockReset();
    vi.spyOn(window, 'open').mockImplementation(() => null);

    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(stage1AnalysisOverride);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        return createQueryBuilder({ data: { name: 'Maria Silva' } }, { data: { name: 'Maria Silva' } });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: profileCareInstructions,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  const CARE_TEXT = 'Evite exposição solar por 48h e não use maquiagem no local por 24h.';

  it('draws the "Orientações" section with the configured text in the patient PDF', async () => {
    profileCareInstructions = CARE_TEXT;
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.careInstructionsTitle').toUpperCase());
    expect(flattenedTexts).toContain(CARE_TEXT);
  });

  it('omits the "Orientações" section entirely when the professional has not configured care instructions', async () => {
    profileCareInstructions = null;
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );
    expect(flattenedTexts).not.toContain(i18n.t('sessions.stage3.pdf.careInstructionsTitle').toUpperCase());
  });

  it('appends the configured care instructions to the WhatsApp share message', async () => {
    profileCareInstructions = CARE_TEXT;
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareWhatsApp')));

    // handleShareWhatsApp abre uma aba em branco primeiro (gesto de clique),
    // e só depois preenche a URL de fato — o mock de window.open devolve
    // `null` pras duas chamadas, então o handler cai no fallback
    // `window.open(url, '_blank')`: a chamada com a mensagem é a última.
    await waitFor(() => expect(window.open).toHaveBeenCalledTimes(2));
    const lastCall = (window.open as ReturnType<typeof vi.fn>).mock.calls.at(-1) as [string, string];
    const [url] = lastCall;
    expect(url).toContain('https://wa.me/?text=');
    const decoded = decodeURIComponent(url);
    expect(decoded).toContain(CARE_TEXT);
    expect(decoded).toContain(i18n.t('sessions.stage3.shareCareInstructionsSuffix', { instructions: CARE_TEXT }));
  });

  it('does not append anything to the WhatsApp message when care instructions are not configured', async () => {
    profileCareInstructions = null;
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareWhatsApp')));

    await waitFor(() => expect(window.open).toHaveBeenCalledTimes(2));
    const lastCall = (window.open as ReturnType<typeof vi.fn>).mock.calls.at(-1) as [string, string];
    const decoded = decodeURIComponent(lastCall[0]);
    expect(decoded).not.toContain('Orientações');
  });
});

// Checklist de Pós-Procedimento Personalizado (ideia do squad de Produto):
// complemento AUTOMÁTICO às orientações de texto livre acima — gerado a
// partir da(s) substância(s) de fato usada(s) na sessão (POINTS acima traz
// um ponto de `acido_hialuronico`), não do texto configurado pelo
// profissional. Os dois convivem juntos no PDF e no compartilhamento — ver
// src/lib/postProcedureChecklist.ts.
describe('SessaoEstagio3 — checklist de pós-procedimento gerado automaticamente por substância', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    textCalls.length = 0;
    addImageCalls.length = 0;
    textCallPages.length = 0;
    stage1AnalysisOverride = null;
    profileCareInstructions = null;
    errorLogsInsertSpy.mockReset();
    vi.spyOn(window, 'open').mockImplementation(() => null);

    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(stage1AnalysisOverride);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        return createQueryBuilder({ data: { name: 'Maria Silva' } }, { data: { name: 'Maria Silva' } });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: profileCareInstructions,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  it('draws the checklist section with the substance label and at least one care item in the PDF, based on stage2Overlay', async () => {
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.postCareChecklistTitle').toUpperCase());
    // POINTS (topo do arquivo) só usa ácido hialurônico — a seção de toxina
    // botulínica/bioestimulador não deve aparecer.
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.postCareChecklist.substanceLabel.acido_hialuronico').toUpperCase());
    expect(flattenedTexts.join(' ')).toContain(
      i18n.t('sessions.stage3.postCareChecklist.items.acido_hialuronico', { returnObjects: true })[0],
    );
    expect(flattenedTexts).not.toContain(i18n.t('sessions.stage3.postCareChecklist.substanceLabel.toxina_botulinica').toUpperCase());
    // POINTS aplica em 'labio_superior', que NÃO é zona de risco vascular —
    // a seção de sinais de alerta de emergência não deve aparecer.
    expect(flattenedTexts).not.toContain(i18n.t('sessions.stage3.pdf.postCareEmergencyTitle').toUpperCase());
  });

  // Sinais de Alerta de Emergência (achado de Produto/segurança, 14/09): só
  // aparecem quando ALGUM ponto de aplicação desta sessão foi de fato
  // marcado como zona de risco vascular (isVascularRiskApplication em
  // src/lib/faceRegions.ts) — ver hasVascularRiskWarning/
  // postProcedureEmergencyWarning em src/lib/postProcedureChecklist.ts.
  it('draws the emergency warning section in the PDF when a point of this session is a vascular-risk point', async () => {
    const riskPoints: ApplicationPoint[] = [
      { ...POINTS[0], id: 'p-risk', region: 'glabela', substance: 'acido_hialuronico' },
    ];
    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(null, riskPoints);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        return createQueryBuilder({ data: { name: 'Maria Silva' } }, { data: { name: 'Maria Silva' } });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: null,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.postCareEmergencyTitle').toUpperCase());
    expect(flattenedTexts.join(' ')).toContain(i18n.t('sessions.stage3.postCareChecklist.emergency.intro'));
    expect(flattenedTexts.join(' ')).toContain(
      i18n.t('sessions.stage3.postCareChecklist.emergency.signs', { returnObjects: true })[0],
    );
  });

  it('appends the automatic checklist to the WhatsApp share message, alongside the free-text care instructions', async () => {
    profileCareInstructions = 'Evite exposição solar por 48h.';
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareWhatsApp')));

    await waitFor(() => expect(window.open).toHaveBeenCalledTimes(2));
    const lastCall = (window.open as ReturnType<typeof vi.fn>).mock.calls.at(-1) as [string, string];
    const decoded = decodeURIComponent(lastCall[0]);
    // O texto livre do profissional continua presente (complemento, não
    // substituição) e o checklist automático aparece depois dele.
    expect(decoded).toContain('Evite exposição solar por 48h.');
    expect(decoded).toContain(i18n.t('sessions.stage3.postCareChecklist.title'));
    expect(decoded).toContain(i18n.t('sessions.stage3.postCareChecklist.items.acido_hialuronico', { returnObjects: true })[0]);
    // POINTS aplica em 'labio_superior', que NÃO é zona de risco vascular —
    // a seção de sinais de alerta de emergência não deve aparecer.
    expect(decoded).not.toContain(i18n.t('sessions.stage3.postCareChecklist.emergency.title'));
  });

  it('appends the emergency warning section to the WhatsApp share message when a point of this session is a vascular-risk point', async () => {
    const riskPoints: ApplicationPoint[] = [
      { ...POINTS[0], id: 'p-risk', region: 'glabela', substance: 'acido_hialuronico' },
    ];
    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(null, riskPoints);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        return createQueryBuilder({ data: { name: 'Maria Silva' } }, { data: { name: 'Maria Silva' } });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: null,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareWhatsApp')));

    await waitFor(() => expect(window.open).toHaveBeenCalledTimes(2));
    const lastCall = (window.open as ReturnType<typeof vi.fn>).mock.calls.at(-1) as [string, string];
    const decoded = decodeURIComponent(lastCall[0]);
    expect(decoded).toContain(i18n.t('sessions.stage3.postCareChecklist.emergency.title').toUpperCase());
    expect(decoded).toContain(i18n.t('sessions.stage3.postCareChecklist.emergency.intro'));
    expect(decoded).toContain(
      i18n.t('sessions.stage3.postCareChecklist.emergency.signs', { returnObjects: true })[0],
    );
  });
});

// "Enviar por e-mail" (P1: envio de análise por e-mail via Resend) — quando
// o paciente já tem e-mail cadastrado, o botão passa a entregar de verdade
// através de send-patient-email em vez de só abrir o mailto: do
// profissional; sem e-mail cadastrado, mantém o fallback mailto de sempre.
describe('SessaoEstagio3 — "Enviar por e-mail" (send-patient-email via Resend)', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    stage1AnalysisOverride = null;
    patientEmailOverride = null;
    errorLogsInsertSpy.mockReset();
    functionsInvokeSpy.mockReset();
    functionsInvokeSpy.mockResolvedValue({ data: { sent: true, source: 'live' }, error: null });

    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(stage1AnalysisOverride);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        const patient = { name: 'Maria Silva', email: patientEmailOverride };
        return createQueryBuilder({ data: patient }, { data: patient });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  it('sends directly via send-patient-email when the patient has an email on file, with the public present link and the professional\'s locale', async () => {
    patientEmailOverride = 'paciente@example.com';
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareEmail')));

    await waitFor(() => expect(functionsInvokeSpy).toHaveBeenCalled());
    const [fnName, options] = functionsInvokeSpy.mock.calls[0] as [string, { body: Record<string, unknown> }];
    expect(fnName).toBe('send-patient-email');
    expect(options.body).toMatchObject({ sessionId: 's1', patientId: 'pat-1', locale: 'pt' });
    expect(typeof options.body.presentLink).toBe('string');
    expect(options.body.presentLink as string).toContain('present-token-abc');

    // O link público de apresentação é gerado (ou reaproveitado) igual ao
    // caminho já coberto pra exportação de PDF — mesma insert já validada
    // acima nesse arquivo.
    expect(presentLinkInsertSpy).toHaveBeenCalledWith({ session_id: 's1', professional_id: 'pro-1' });
  });

  it('falls back to mailto: when the patient has no email on file, without calling send-patient-email', async () => {
    patientEmailOverride = null;
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareEmail')));

    await waitFor(() => expect(presentLinkInsertSpy).toHaveBeenCalled());
    expect(functionsInvokeSpy).not.toHaveBeenCalled();
  });

  it('logs to error_logs when send-patient-email fails, without crashing the click handler', async () => {
    patientEmailOverride = 'paciente@example.com';
    functionsInvokeSpy.mockResolvedValue({ data: { error: 'resend_down' }, error: null });
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.shareEmail')));

    await waitFor(() => expect(errorLogsInsertSpy).toHaveBeenCalled());
    expect(errorLogsInsertSpy).toHaveBeenCalledWith(
      expect.objectContaining({ professional_id: 'pro-1', session_id: 's1', error_type: 'send_patient_email_client_failed' }),
    );
  });
});

// Regressão do bug P2 "Quebra de página do PDF corta seção ao meio": o
// título de uma seção (ex.: "ANÁLISE CLÍNICA") cabia sozinho no fim de uma
// página — reservava espaço só pra si mesmo (36pt) antes de ser desenhado —
// e só depois o corpo era medido/reservado; quando o corpo não cabia, o
// jsPDF empurrava só ele pra próxima página, deixando o título órfão. A
// correção (drawSectionTitle(label, bodyHeight) + ensureSpace/pdfLayout.ts
// em SessaoEstagio3.tsx) mede o corpo ANTES de desenhar o título e reserva
// os dois como um bloco só. Verificado abaixo com conteúdo grande o
// suficiente pra forçar várias páginas, checando que cada título de seção
// desenhado está sempre na mesma página que o conteúdo desenhado logo em
// seguida (ver `textCallPages` no topo do arquivo).
describe('SessaoEstagio3 — quebra de página não corta uma seção ao meio (bug P2)', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    textCalls.length = 0;
    addImageCalls.length = 0;
    textCallPages.length = 0;
    errorLogsInsertSpy.mockReset();
    vi.spyOn(window, 'open').mockImplementation(() => null);

    // Parágrafo propositalmente longo (bem acima de uma linha) pra forçar
    // cada bloco de texto a quebrar em várias linhas — e, empilhado nas
    // várias seções com conteúdo abaixo, forçar o PDF inteiro a várias
    // páginas.
    const longParagraph = Array.from(
      { length: 30 },
      (_, i) => `Observação clínica número ${i + 1} descrita em detalhe, com frases longas o bastante para ocupar múltiplas linhas no documento gerado.`,
    ).join(' ');
    const bigStage1Analysis = {
      suggestions: [],
      overallNotes: longParagraph,
      patientSummary: longParagraph,
      facialAnalysis: { shape: longParagraph, symmetry: longParagraph, proportions: longParagraph },
      attentionPoints: Array.from({ length: 15 }, (_, i) => `Ponto de atenção ${i + 1}: ${longParagraph}`),
    };

    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(bigStage1Analysis);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        return createQueryBuilder({ data: { name: 'Maria Silva' } }, { data: { name: 'Maria Silva' } });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: longParagraph,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  it('spans multiple pages and keeps every section title on the same page as the content drawn right after it', async () => {
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    // Confirma que o cenário de fato força mais de uma página — sem isso a
    // checagem abaixo seria trivialmente verdadeira (tudo numa página só).
    expect(Math.max(...textCallPages)).toBeGreaterThan(1);

    const sectionTitles = [
      i18n.t('sessions.stage3.pdf.beforeAfterTitle'),
      i18n.t('sessions.stage3.pdf.clinicalAnalysisTitle'),
      i18n.t('sessions.stage3.pdf.proceduresTitle'),
      i18n.t('sessions.stage3.pdf.careInstructionsTitle'),
      i18n.t('sessions.stage3.pdf.postCareChecklistTitle'),
    ].map((label) => label.toUpperCase());

    sectionTitles.forEach((label) => {
      const titleIdx = textCalls.findIndex(([content]) => content === label);
      expect(titleIdx).toBeGreaterThanOrEqual(0);
      // O próximo doc.text(...) depois do título é sempre o começo do
      // corpo da própria seção (rótulo/citação/primeiro item/parágrafo) —
      // tem que estar na MESMA página que o título. Antes da correção, um
      // título cujo corpo não coubesse ficava no fim de uma página com o
      // corpo pulando pra seguinte, quebrando essa igualdade.
      expect(textCallPages[titleIdx + 1]).toBe(textCallPages[titleIdx]);
    });
  });
});

// Selo de Conformidade Clínica por Sessão (P6-2, ver
// src/lib/complianceSummary.ts) — reúne no PDF o que já existe disperso
// (triagem ABCDE, anamnese, TCLE geral e de procedimento, teto de dose e
// guardrail de zona de risco vascular). A função pura em si já tem sua
// própria suíte (complianceSummary.test.ts); a cobertura aqui é só a fiação
// — os dados vindos das novas queries de fato chegam à seção desenhada.
describe('SessaoEstagio3 — Selo de Conformidade Clínica no PDF (P6-2)', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    useAuthMock.mockReturnValue({ user: { id: 'pro-1' }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    presentLinkInsertSpy.mockReset();
    uploadSpy.mockClear();
    textCalls.length = 0;
    addImageCalls.length = 0;
    textCallPages.length = 0;
    stage1AnalysisOverride = null;
    profileCareInstructions = null;
    errorLogsInsertSpy.mockReset();
    vi.spyOn(window, 'open').mockImplementation(() => null);

    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(stage1AnalysisOverride);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        const patient = { name: 'Maria Silva', consent_given: true, last_consent_at: '2026-04-01T00:00:00.000Z' };
        return createQueryBuilder({ data: patient }, { data: patient });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: null,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      if (table === 'anamnesis') {
        return createQueryBuilder(undefined, { data: { created_at: '2026-04-01T00:00:00.000Z' } });
      }
      if (table === 'consents') {
        return createQueryBuilder(undefined, {
          data: { created_at: '2026-05-01T09:30:00.000Z', consent_text: 'Texto do TCLE aceito', ip_address: '203.0.113.5' },
        });
      }
      if (table === 'skin_screenings') {
        return createQueryBuilder(undefined, {
          data: {
            has_suspicious_finding: false,
            referred_to_dermatology: false,
            proceeded_despite_finding: false,
            proceed_justification: null,
            updated_at: '2026-05-01T09:00:00.000Z',
          },
        });
      }
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });
  });

  it('draws every gate label and a "met" status when every related record is present and clean', async () => {
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );

    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.title').toUpperCase());
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.gates.skinScreening'));
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.gates.anamnesis'));
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.gates.consentGeneral'));
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.gates.consentProcedure'));
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.gates.doseThreshold'));
    expect(flattenedTexts).toContain(i18n.t('sessions.stage3.pdf.compliance.gates.vascularRiskZone'));

    // Todo gate cumprido nesse cenário -> nenhuma linha "Em atenção".
    const attentionPrefix = i18n.t('sessions.stage3.pdf.compliance.statusAttention', { date: '' }).split('—')[0].trim();
    expect(flattenedTexts.some((text) => text.startsWith(attentionPrefix))).toBe(false);

    // Fingerprint do TCLE de procedimento aparece (prova de integridade, não o texto completo).
    expect(flattenedTexts.some((text) => text.includes('Hash do texto aceito'))).toBe(true);
    expect(flattenedTexts.some((text) => text.includes('Texto do TCLE aceito'))).toBe(false);
  });

  it('draws an "attention" status for a gate whose related record is missing (e.g. no anamnesis on file)', async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === 'sessions') return createSessionsBuilder(stage1AnalysisOverride);
      if (table === 'error_logs') return errorLogsBuilder();
      if (table === 'patients') {
        const patient = { name: 'Maria Silva', consent_given: true, last_consent_at: '2026-04-01T00:00:00.000Z' };
        return createQueryBuilder({ data: patient }, { data: patient });
      }
      if (table === 'profiles') {
        const profile = {
          full_name: 'Dra. Ana',
          clinic_name: 'Clínica Exemplo',
          logo_url: null,
          labor_fee_per_session: 100,
          max_installments: 3,
          cash_discount_pct: 5,
          pre_post_care_instructions: null,
        };
        return createQueryBuilder({ data: profile }, { data: profile });
      }
      if (table === 'insumos') {
        return createQueryBuilder({
          data: [{ id: 'ins-1', substance: 'acido_hialuronico', brand_name: 'Restylane', cost_per_unit: 400, price_per_unit: 1500, active: true }],
        });
      }
      // Anamnese ainda não preenchida para esta paciente (gate P0-4 em atenção).
      if (table === 'anamnesis') return createQueryBuilder(undefined, { data: null });
      if (table === 'consents') return createQueryBuilder(undefined, { data: null });
      if (table === 'skin_screenings') return createQueryBuilder(undefined, { data: null });
      if (table === 'session_present_links') return createPresentLinkBuilder();
      return createQueryBuilder();
    });

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: /Compartilhar/ }));
    fireEvent.click(await screen.findByText(i18n.t('sessions.stage3.exportPdfPatient')));

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());

    const flattenedTexts = textCalls.map(([content]) =>
      Array.isArray(content) ? (content as string[]).join(' ') : (content as string),
    );

    const anamnesisIdx = flattenedTexts.indexOf(i18n.t('sessions.stage3.pdf.compliance.gates.anamnesis'));
    expect(anamnesisIdx).toBeGreaterThanOrEqual(0);
    const attentionPrefix = i18n.t('sessions.stage3.pdf.compliance.statusAttention', { date: '' }).split('—')[0].trim();
    // A linha de status logo abaixo do rótulo do gate é a próxima chamada de doc.text().
    expect(flattenedTexts[anamnesisIdx + 1]).toContain(attentionPrefix);
  });
});
