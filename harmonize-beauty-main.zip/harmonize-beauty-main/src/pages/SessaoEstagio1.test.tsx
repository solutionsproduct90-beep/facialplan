import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, within, fireEvent } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import SessaoEstagio1 from "./SessaoEstagio1";
import { createQueryBuilder } from "@/test/supabaseMock";
import { regionFallbackPosition } from "@/lib/faceRegions";
import type { Stage1Analysis } from "@/types/harmonize";
import i18n from "@/i18n";

const useAuthMock = vi.fn();
const fromMock = vi.fn();
const navigateMock = vi.fn();
const sessionsUpdateSpy = vi.fn();

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => useAuthMock(),
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return { ...actual, useNavigate: () => navigateMock };
});

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (...args: unknown[]) => fromMock(...args),
    storage: { from: () => ({ createSignedUrl: async () => ({ data: { signedUrl: null } }) }) },
  },
}));

const ANALYSIS: Stage1Analysis = {
  suggestions: [
    {
      id: "labio_superior_ha",
      region: "labio_superior",
      label: "Lábio Superior",
      substance: "acido_hialuronico",
      confidence: 82,
      quantitySuggested: 0.5,
      unit: "ml",
      justification: {
        finding: "Volume reduzido no lábio superior.",
        clinicalGoal: "Restaurar volume e contorno do vermelhão.",
        technicalNote: "Aplicação em bolus retrovermelhão.",
      },
    },
    {
      id: "glabela_toxina",
      region: "glabela",
      label: "Glabela",
      substance: "toxina_botulinica",
      confidence: 74,
      quantitySuggested: 20,
      unit: "unidades",
      justification: {
        finding: "Linhas glabelares moderadas.",
        clinicalGoal: "Suavizar a marcação das linhas glabelares.",
        technicalNote: "Pontos padrão em corrugador e prócero.",
      },
    },
  ],
  overallNotes: "Leve assimetria facial.",
};

/**
 * A query-builder mock rich enough for this page: it behaves like the
 * standard thenable `select().eq().single()` chain from supabaseMock for
 * reads, but also supports `.update(payload).eq(id)` — recording the payload
 * via `sessionsUpdateSpy` — since SessaoEstagio1's "Planejar" action persists
 * the accepted points with a plain `await ...update(...).eq(...)` (no further
 * chaining the generic mock would need to support).
 */
function createSessionsBuilder(analysis: Stage1Analysis = ANALYSIS) {
  const selectResolution = {
    data: { stage1_analysis: analysis, patient_id: "pat-1", original_image_url: null },
  };
  const builder = {
    select: () => builder,
    eq: () => builder,
    single: () => builder,
    update: (payload: unknown) => {
      sessionsUpdateSpy(payload);
      return { eq: () => Promise.resolve({ error: null }) };
    },
    then: (onFulfilled: (v: unknown) => unknown) => Promise.resolve(selectResolution).then(onFulfilled),
  };
  return builder;
}

const renderPage = () =>
  render(
    <MemoryRouter initialEntries={["/sessoes/s1/estagio-1"]}>
      <Routes>
        <Route path="/sessoes/:id/estagio-1" element={<SessaoEstagio1 />} />
      </Routes>
    </MemoryRouter>
  );

/**
 * Satisfaz a exigência de revisão mínima (P1) tocando no stepper de
 * quantidade — incrementa e decrementa de volta ao valor original, então não
 * altera nenhuma asserção de quantidade nos testes que só querem "revisar e
 * seguir". `card` = último `bg-h-white` do wrapper da sugestão (mesmo
 * seletor usado no resto deste arquivo); últimos 4 botões = [minus, plus,
 * discard, accept] (ver comentário original abaixo).
 */
const reviewSuggestion = (card: HTMLElement) => {
  const [minusBtn, plusBtn] = within(card).getAllByRole("button").slice(-4);
  fireEvent.click(plusBtn);
  fireEvent.click(minusBtn);
};

describe("SessaoEstagio1 — aceite/edição/descarte de sugestões", () => {
  beforeEach(async () => {
    // Trava o idioma da UI em português (padrão/fallback do app) pra que as
    // asserções em texto renderizado sejam determinísticas.
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  const waitForLoaded = () =>
    waitFor(() => expect(screen.getByText("2 sugestões de ajuste")).toBeInTheDocument());

  it("keeps the proceed button disabled and shows the empty-selection prompt until a suggestion is accepted", async () => {
    renderPage();
    await waitForLoaded();

    expect(screen.getByRole("button", { name: "Aceite ao menos 1 sugestão" })).toBeDisabled();
  });

  it("accepting a suggestion enables proceeding and persists the correct ApplicationPoint", async () => {
    renderPage();
    await waitForLoaded();

    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const acceptBtn = within(card).getAllByRole("button").at(-1)!; // [minus, plus, discard, accept]
    reviewSuggestion(card);
    fireEvent.click(acceptBtn);

    const proceedBtn = await screen.findByRole("button", { name: "Planejar 1 ponto →" });
    expect(proceedBtn).toBeEnabled();

    fireEvent.click(proceedBtn);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    // Não navega direto para o Estágio 2 nem marca a sessão como "stage2"
    // aqui — antes disso passa pela triagem de pele obrigatória (critérios
    // ABCDE, P0), que é quem decide se/quando o status avança. Ver
    // SessaoTriagemPele.tsx.
    await waitFor(() => expect(navigateMock).toHaveBeenCalledWith("/sessoes/s1/triagem-pele"));

    const payload = sessionsUpdateSpy.mock.calls[0][0] as {
      stage2_overlay: unknown[];
      selected_procedure: string;
      status?: string;
    };
    expect(payload.status).toBeUndefined();
    expect(payload.selected_procedure).toBe("Lábio Superior");
    expect(payload.stage2_overlay).toEqual([
      {
        id: "labio_superior_ha",
        region: "labio_superior",
        label: "Lábio Superior",
        substance: "acido_hialuronico",
        quantity: 0.5,
        unit: "ml",
        x: regionFallbackPosition("labio_superior").x,
        y: regionFallbackPosition("labio_superior").y,
        confidence: 82,
        source: "ai",
        justification: {
          finding: "Volume reduzido no lábio superior.",
          clinicalGoal: "Restaurar volume e contorno do vermelhão.",
          technicalNote: "Aplicação em bolus retrovermelhão.",
        },
        // Valores sensatos por substância aplicados ao aceitar (item 1 do
        // backlog P0) — ver SUBSTANCE_DEFAULT_TECHNIQUE/DEPTH/DEVICE.
        technique: "bolus",
        depth: "subcutaneo",
        device: "canula",
      },
    ]);
  });

  it("does not include a discarded suggestion in the persisted points, even if it was accepted first", async () => {
    renderPage();
    await waitForLoaded();

    const labioCard = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const glabelaCard = screen.getByText("Glabela").closest("div.bg-h-white") as HTMLElement;

    // Accept both, then discard Glabela.
    reviewSuggestion(labioCard);
    reviewSuggestion(glabelaCard);
    fireEvent.click(within(labioCard).getAllByRole("button").at(-1)!);
    fireEvent.click(within(glabelaCard).getAllByRole("button").at(-1)!);
    expect(await screen.findByRole("button", { name: "Planejar 2 pontos →" })).toBeInTheDocument();

    const [discardBtn] = within(glabelaCard).getAllByRole("button").slice(-2, -1);
    fireEvent.click(discardBtn);

    const proceedBtn = await screen.findByRole("button", { name: "Planejar 1 ponto →" });
    fireEvent.click(proceedBtn);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls[0][0] as { stage2_overlay: { id: string }[] };
    expect(payload.stage2_overlay).toHaveLength(1);
    expect(payload.stage2_overlay[0].id).toBe("labio_superior_ha");
  });

  it("carries an edited quantity (not the original suggested amount) into the persisted point", async () => {
    renderPage();
    await waitForLoaded();

    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    // Últimos 4 botões do card = [minus, plus, discard, accept] — usa slice
    // a partir do fim (em vez de índices absolutos) porque o card também
    // tem o botão do seletor de substância (SheetSelect) antes deles.
    const [, plusBtn, , acceptBtn] = within(card).getAllByRole("button").slice(-4);
    fireEvent.click(plusBtn);
    fireEvent.click(plusBtn);
    expect(within(card).getByText("0.7 ml")).toBeInTheDocument();

    fireEvent.click(acceptBtn);
    const proceedBtn = await screen.findByRole("button", { name: "Planejar 1 ponto →" });
    fireEvent.click(proceedBtn);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls[0][0] as { stage2_overlay: { quantity: number }[] };
    expect(payload.stage2_overlay[0].quantity).toBe(0.7);
  });

  it("renders the 4-part clinical justification (finding, clinical goal, technical note, hypothesis stamp) for a suggestion", async () => {
    renderPage();
    await waitForLoaded();

    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    expect(within(card).getByText("Volume reduzido no lábio superior.")).toBeInTheDocument();
    expect(within(card).getByText("Restaurar volume e contorno do vermelhão.")).toBeInTheDocument();
    expect(within(card).getByText("Aplicação em bolus retrovermelhão.")).toBeInTheDocument();
    expect(
      within(card).getByText("Leitura preliminar da IA — sujeita a confirmação presencial pelo profissional.")
    ).toBeInTheDocument();
  });

  it("lets the professional edit the suggested substance before accepting, and persists the EDITED substance/unit (not the AI's original) into the ApplicationPoint", async () => {
    // Fixture com uma única sugestão pra evitar ambiguidade: outra sugestão
    // já usando "Toxina Botulínica" como rótulo faria `getByText` encontrar
    // mais de um elemento (o próprio seletor fechado dela) quando o sheet
    // desta sugestão abre com essa mesma opção na lista.
    const SINGLE_SUGGESTION: Stage1Analysis = {
      suggestions: [ANALYSIS.suggestions[0]],
    };
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(SINGLE_SUGGESTION);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });

    render(
      <MemoryRouter initialEntries={["/sessoes/s1/estagio-1"]}>
        <Routes>
          <Route path="/sessoes/:id/estagio-1" element={<SessaoEstagio1 />} />
        </Routes>
      </MemoryRouter>
    );

    await waitFor(() => expect(screen.getByText("1 sugestão de ajuste")).toBeInTheDocument());
    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;

    // Abre o seletor de substância (mostra a substância sugerida pela IA) e
    // escolhe uma diferente no BottomSheet.
    fireEvent.click(within(card).getByText("Ácido Hialurônico"));
    fireEvent.click(await screen.findByText("Toxina Botulínica"));

    // O card reflete a substância editada — inclusive a unidade da
    // quantidade, que muda junto (ml → unidades).
    expect(within(card).getByText("Toxina Botulínica")).toBeInTheDocument();
    expect(within(card).getByText("0.5 unidades")).toBeInTheDocument();

    // `{ hidden: true }`: o vaul Drawer marca o resto da página como
    // aria-hidden enquanto o BottomSheet está aberto, e em jsdom (sem
    // animationend real) essa marca pode não ser desfeita de forma síncrona
    // — sem isso, as queries por role deixariam de enxergar os botões da
    // página mesmo já com o sheet fechado.
    const acceptBtn = within(card).getAllByRole("button", { hidden: true }).at(-1)!;
    fireEvent.click(acceptBtn);
    const proceedBtn = await screen.findByRole("button", { name: "Planejar 1 ponto →", hidden: true });
    fireEvent.click(proceedBtn);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls[0][0] as {
      stage2_overlay: { substance: string; unit: string }[];
    };
    expect(payload.stage2_overlay[0].substance).toBe("toxina_botulinica");
    expect(payload.stage2_overlay[0].unit).toBe("unidades");
  });

  it("discarding a suggestion excludes it from the accepted count even after it was previously accepted", async () => {
    renderPage();
    await waitForLoaded();

    const card = screen.getByText("Glabela").closest("div.bg-h-white") as HTMLElement;
    const [discardBtn, acceptBtn] = within(card).getAllByRole("button").slice(-2);

    reviewSuggestion(card);
    fireEvent.click(acceptBtn);
    expect(await screen.findByRole("button", { name: "Planejar 1 ponto →" })).toBeInTheDocument();

    fireEvent.click(discardBtn);
    expect(await screen.findByRole("button", { name: "Aceite ao menos 1 sugestão" })).toBeDisabled();
  });

  it("summarizes multiple accepted points with a count label instead of a single region name", async () => {
    renderPage();
    await waitForLoaded();

    const cards = [screen.getByText("Lábio Superior"), screen.getByText("Glabela")].map(
      (el) => el.closest("div.bg-h-white") as HTMLElement
    );
    for (const card of cards) {
      reviewSuggestion(card);
      fireEvent.click(within(card).getAllByRole("button").at(-1)!);
    }

    const proceedBtn = await screen.findByRole("button", { name: "Planejar 2 pontos →" });
    fireEvent.click(proceedBtn);

    await waitFor(() => expect(sessionsUpdateSpy).toHaveBeenCalled());
    const payload = sessionsUpdateSpy.mock.calls[0][0] as { selected_procedure: string };
    expect(payload.selected_procedure).toBe("2 pontos planejados");
  });
});

// P1: até aqui, um único toque no botão "Aceitar" bastava para aprovar a
// sugestão da IA sem o profissional nunca ter olhado/tocado a
// quantidade/substância propostas — risco de segurança clínica. Este bloco
// cobre a exigência de revisão mínima adicionada (ver `reviewedSuggestions`
// em SessaoEstagio1.tsx) isoladamente do resto do fluxo de aceite/descarte,
// já coberto (com a revisão já satisfeita via `reviewSuggestion`) nos testes
// acima.
describe("SessaoEstagio1 — revisão mínima antes de aceitar uma sugestão", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();

    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });
  });

  it("keeps the accept button disabled for a suggestion whose quantity/substance was never touched, and clicking it does nothing", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("2 sugestões de ajuste")).toBeInTheDocument());

    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const acceptBtn = within(card).getAllByRole("button").at(-1)!; // [minus, plus, discard, accept]
    expect(acceptBtn).toBeDisabled();

    fireEvent.click(acceptBtn);

    // Nada aconteceu: a sugestão continua pendente e o botão de prosseguir
    // continua no estado de "nenhuma sugestão aceita ainda".
    expect(screen.getByRole("button", { name: "Aceite ao menos 1 sugestão" })).toBeDisabled();
  });

  it("enables the accept button once the quantity stepper has been touched, even without a net change to the value", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("2 sugestões de ajuste")).toBeInTheDocument());

    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const [minusBtn, plusBtn, , acceptBtn] = within(card).getAllByRole("button").slice(-4);
    expect(acceptBtn).toBeDisabled();

    // Toca no stepper (some pra 0.6 e volta pra 0.5) — a revisão conta a
    // partir do primeiro toque, não exige manter o valor alterado.
    fireEvent.click(plusBtn);
    expect(acceptBtn).toBeEnabled();
    fireEvent.click(minusBtn);
    expect(within(card).getByText("0.5 ml")).toBeInTheDocument();
    expect(acceptBtn).toBeEnabled();

    fireEvent.click(acceptBtn);
    expect(await screen.findByRole("button", { name: "Planejar 1 ponto →" })).toBeEnabled();
  });

  it("enables the accept button after the substance selector is opened, even if the professional closes it without changing the value", async () => {
    const SINGLE_SUGGESTION: Stage1Analysis = { suggestions: [ANALYSIS.suggestions[0]] };
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(SINGLE_SUGGESTION);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });

    renderPage();
    await waitFor(() => expect(screen.getByText("1 sugestão de ajuste")).toBeInTheDocument());
    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const acceptBtn = within(card).getAllByRole("button", { hidden: true }).at(-1)!;
    expect(acceptBtn).toBeDisabled();

    // Basta abrir o seletor de substância (ver a lista com o valor sugerido
    // já destacado) — olhar o valor, mesmo sem trocá-lo, já satisfaz a
    // revisão mínima.
    fireEvent.click(within(card).getByText("Ácido Hialurônico"));

    expect(acceptBtn).toBeEnabled();
  });

  it("never blocks discarding a suggestion, regardless of the review requirement", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("2 sugestões de ajuste")).toBeInTheDocument());

    const card = screen.getByText("Glabela").closest("div.bg-h-white") as HTMLElement;
    const [discardBtn] = within(card).getAllByRole("button").slice(-2);
    fireEvent.click(discardBtn);

    // A sugestão foi descartada mesmo sem nenhuma revisão prévia.
    const cardAfter = screen.getByText("Glabela").closest("div.bg-h-white") as HTMLElement;
    expect(cardAfter).toHaveStyle({ opacity: "0.5" });
  });

  it("never blocks adjusting the quantity, regardless of the review requirement", async () => {
    renderPage();
    await waitFor(() => expect(screen.getByText("2 sugestões de ajuste")).toBeInTheDocument());

    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const [, plusBtn] = within(card).getAllByRole("button").slice(-4);
    fireEvent.click(plusBtn);

    expect(within(card).getByText("0.6 ml")).toBeInTheDocument();
  });
});

describe("SessaoEstagio1 — banner de risco da anamnese", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
  });

  const acceptFirstSuggestion = async () => {
    await waitFor(() => expect(screen.getByText("2 sugestões de ajuste")).toBeInTheDocument());
    const card = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    reviewSuggestion(card);
    fireEvent.click(within(card).getAllByRole("button").at(-1)!);
  };

  it("shows the risk banner with the active anamnesis flags and keeps the proceed button gated until acknowledged", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") {
        return createQueryBuilder(
          undefined,
          { data: { risk_flags: { pregnant: true, allergy: { has: true, which: "Dipirona" } } } }
        );
      }
      return createQueryBuilder();
    });

    render(
      <MemoryRouter initialEntries={["/sessoes/s1/estagio-1"]}>
        <Routes>
          <Route path="/sessoes/:id/estagio-1" element={<SessaoEstagio1 />} />
        </Routes>
      </MemoryRouter>
    );

    await acceptFirstSuggestion();

    expect(await screen.findByText("Pontos de atenção da anamnese")).toBeInTheDocument();
    expect(screen.getByText("• Gestante ou amamentando")).toBeInTheDocument();
    expect(screen.getByText("• Alergia")).toBeInTheDocument();

    // Mesmo com 1 sugestão aceita, o botão continua desabilitado até o
    // profissional marcar o reconhecimento de risco.
    const proceedBtn = screen.getByRole("button", { name: "Planejar 1 ponto →" });
    expect(proceedBtn).toBeDisabled();

    const ackCheckbox = screen.getByText("Estou ciente e decido prosseguir").closest("label")!.querySelector("input")!;
    fireEvent.click(ackCheckbox);

    expect(proceedBtn).toBeEnabled();
  });

  it("shows a region-specific inline warning only on the suggestion whose region the risk maps to (herpes_recurrent → lip regions), complementing (not replacing) the general banner", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") {
        return createQueryBuilder(undefined, { data: { risk_flags: { herpes_recurrent: true } } });
      }
      return createQueryBuilder();
    });

    render(
      <MemoryRouter initialEntries={["/sessoes/s1/estagio-1"]}>
        <Routes>
          <Route path="/sessoes/:id/estagio-1" element={<SessaoEstagio1 />} />
        </Routes>
      </MemoryRouter>
    );

    // O banner geral continua aparecendo — este recurso complementa, não
    // substitui.
    expect(await screen.findByText("Pontos de atenção da anamnese")).toBeInTheDocument();

    const labioCard = screen.getByText("Lábio Superior").closest("div.bg-h-white") as HTMLElement;
    const glabelaCard = screen.getByText("Glabela").closest("div.bg-h-white") as HTMLElement;

    // labio_superior está no mapeamento de herpes_recurrent → aviso inline
    // específico nesta sugestão...
    expect(
      within(labioCard).getByText("Risco da anamnese relevante para esta região: Herpes labial recorrente")
    ).toBeInTheDocument();
    // ...mas glabela não tem essa associação, então não ganha o aviso.
    expect(
      within(glabelaCard).queryByText(/Risco da anamnese relevante para esta região/)
    ).not.toBeInTheDocument();
  });

  it("does not show the risk banner or gate the proceed button when the patient has no anamnesis risk flags", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") {
        return createQueryBuilder(undefined, { data: { risk_flags: {} } });
      }
      return createQueryBuilder();
    });

    render(
      <MemoryRouter initialEntries={["/sessoes/s1/estagio-1"]}>
        <Routes>
          <Route path="/sessoes/:id/estagio-1" element={<SessaoEstagio1 />} />
        </Routes>
      </MemoryRouter>
    );

    await acceptFirstSuggestion();

    expect(await screen.findByRole("button", { name: "Planejar 1 ponto →" })).toBeEnabled();
    expect(screen.queryByText("Pontos de atenção da anamnese")).not.toBeInTheDocument();
  });
});

// Cobre a renderização condicional das seções aditivas do Stage1Analysis
// (patientSummary/facialAnalysis/attentionPoints — ver src/types/harmonize.ts
// e o prompt em supabase/functions/analyze-face/index.ts): elas devem
// aparecer quando presentes e não devem quebrar (nem aparecer vazias) numa
// análise mais antiga que só tem "suggestions" (como a `ANALYSIS` usada nos
// describes acima).
describe("SessaoEstagio1 — seções aditivas da análise (resumo/estrutural/pontos de atenção)", () => {
  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
  });

  const RICH_ANALYSIS: Stage1Analysis = {
    ...ANALYSIS,
    patientSummary: "Rosto de formato oval, com boa base óssea e proporções harmônicas.",
    facialAnalysis: {
      shape: "Formato oval com terço inferior levemente mais estreito.",
      symmetry: "Leve assimetria entre os malares, mais evidente à direita.",
      proportions: "Terços faciais equilibrados; regra dos quintos preservada.",
    },
    facialThirds: {
      upper: "Fronte lisa em repouso, com linhas horizontais discretas apenas à contração.",
      middle: "Projeção malar levemente reduzida à direita em relação à esquerda.",
      lower: "Contorno mandibular ainda bem definido, com leve perda de nitidez à direita.",
    },
    skinTexture: "Sinais leves de fotoenvelhecimento na região malar, sem flacidez relevante.",
    analysisLimitations: "Leitura baseada em foto 2D: profundidade real do malar pode não estar totalmente capturada.",
    attentionPoints: [
      "Perda de volume localizada na região malar direita.",
      "Linhas de expressão dinâmicas na região glabelar.",
    ],
  };

  it("renders the patient summary, structural analysis and attention points sections when present", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(RICH_ANALYSIS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });

    renderPage();

    expect(await screen.findByText("Resumo do Paciente")).toBeInTheDocument();
    expect(screen.getByText("Rosto de formato oval, com boa base óssea e proporções harmônicas.")).toBeInTheDocument();

    expect(screen.getByText("Análise Estrutural")).toBeInTheDocument();
    expect(screen.getByText("Formato do rosto")).toBeInTheDocument();
    expect(screen.getByText("Formato oval com terço inferior levemente mais estreito.")).toBeInTheDocument();
    expect(screen.getByText("Simetria")).toBeInTheDocument();
    expect(screen.getByText("Leve assimetria entre os malares, mais evidente à direita.")).toBeInTheDocument();
    expect(screen.getByText("Proporções")).toBeInTheDocument();
    expect(screen.getByText("Terços faciais equilibrados; regra dos quintos preservada.")).toBeInTheDocument();

    expect(screen.getByText("Pontos de Atenção")).toBeInTheDocument();
    expect(screen.getByText("Perda de volume localizada na região malar direita.")).toBeInTheDocument();
    expect(screen.getByText("Linhas de expressão dinâmicas na região glabelar.")).toBeInTheDocument();
  });

  // Backlog P2 "Aprofundar ainda mais a análise facial da IA": terços
  // faciais, textura de pele e a ressalva de limitação de foto 2D — mesmo
  // padrão aditivo/opcional das seções cobertas acima.
  it("renders the facial thirds, skin texture and 2D-limitation sections when present", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(RICH_ANALYSIS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });

    renderPage();

    expect(await screen.findByText("Terços Faciais")).toBeInTheDocument();
    expect(screen.getByText("Terço superior")).toBeInTheDocument();
    expect(screen.getByText("Fronte lisa em repouso, com linhas horizontais discretas apenas à contração.")).toBeInTheDocument();
    expect(screen.getByText("Terço médio")).toBeInTheDocument();
    expect(screen.getByText("Projeção malar levemente reduzida à direita em relação à esquerda.")).toBeInTheDocument();
    expect(screen.getByText("Terço inferior")).toBeInTheDocument();
    expect(screen.getByText("Contorno mandibular ainda bem definido, com leve perda de nitidez à direita.")).toBeInTheDocument();

    expect(screen.getByText("Textura e Qualidade de Pele")).toBeInTheDocument();
    expect(screen.getByText("Sinais leves de fotoenvelhecimento na região malar, sem flacidez relevante.")).toBeInTheDocument();

    expect(
      screen.getByText("Leitura baseada em foto 2D: profundidade real do malar pode não estar totalmente capturada.")
    ).toBeInTheDocument();
  });

  it("degrades gracefully — omits the new sections entirely for an older analysis with only suggestions", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder(ANALYSIS);
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      return createQueryBuilder();
    });

    renderPage();

    // Espera algo da tela carregar antes de afirmar ausência, pra não passar
    // "sem querer" contra a tela de loading.
    expect(await screen.findByText("Lábio Superior")).toBeInTheDocument();

    expect(screen.queryByText("Resumo do Paciente")).not.toBeInTheDocument();
    expect(screen.queryByText("Análise Estrutural")).not.toBeInTheDocument();
    expect(screen.queryByText("Terços Faciais")).not.toBeInTheDocument();
    expect(screen.queryByText("Textura e Qualidade de Pele")).not.toBeInTheDocument();
    expect(screen.queryByText("Pontos de Atenção")).not.toBeInTheDocument();
  });
});

// P0: sem anamnese registrada (nem pelo paciente, nem em nome dele), o
// profissional não pode nem ver a revisão de sugestões, muito menos avançar
// para o planejamento — a tela de bloqueio abaixo substitui todo o conteúdo
// normal do Estágio 1 e oferece as duas saídas já existentes no produto.
describe("SessaoEstagio1 — bloqueio por ausência total de anamnese", () => {
  const linksInsertSpy = vi.fn();
  const anamnesisUpsertSpy = vi.fn();

  beforeEach(async () => {
    await i18n.changeLanguage("pt");
    useAuthMock.mockReturnValue({ user: { id: "pro-1" }, loading: false });
    navigateMock.mockReset();
    fromMock.mockReset();
    sessionsUpdateSpy.mockReset();
    linksInsertSpy.mockReset();
    anamnesisUpsertSpy.mockReset();
    vi.spyOn(window, "open").mockImplementation(() => null);
  });

  /** Builder stateful para `anamnesis`: começa sem linha (paciente nunca
   * respondeu) e passa a "existir" assim que `upsert` é chamado — simula o
   * preenchimento em nome do paciente pela própria AnamnesisSheet. */
  function createStatefulAnamnesisBuilder(initialRow: { risk_flags?: unknown } | null = null) {
    const state: { row: { risk_flags?: unknown } | null } = { row: initialRow };
    return {
      builder: {
        select: () => ({
          eq: () => ({
            maybeSingle: () => Promise.resolve({ data: state.row, error: null }),
          }),
        }),
        upsert: (payload: { risk_flags?: unknown }) => {
          anamnesisUpsertSpy(payload);
          state.row = { risk_flags: payload.risk_flags ?? {} };
          return Promise.resolve({ error: null });
        },
      },
      state,
    };
  }

  function createAnamnesisLinksBuilder(token: string) {
    return {
      insert: (payload: unknown) => {
        linksInsertSpy(payload);
        return {
          select: () => ({
            single: () => Promise.resolve({ data: { token }, error: null }),
          }),
        };
      },
    };
  }

  const renderGatePage = () =>
    render(
      <QueryClientProvider client={new QueryClient()}>
        <MemoryRouter initialEntries={["/sessoes/s1/estagio-1"]}>
          <Routes>
            <Route path="/sessoes/:id/estagio-1" element={<SessaoEstagio1 />} />
          </Routes>
        </MemoryRouter>
      </QueryClientProvider>
    );

  it("shows the blocking screen instead of the suggestions review, with both existing resolution paths, when the patient has no anamnesis at all", async () => {
    const { builder } = createStatefulAnamnesisBuilder(null);
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") return builder;
      return createQueryBuilder();
    });

    renderGatePage();

    expect(await screen.findByText("Anamnese necessária")).toBeInTheDocument();
    // O gate substitui TODO o conteúdo normal — nada da revisão de
    // sugestões (nem o botão de avançar) fica acessível por trás dele.
    expect(screen.queryByText("Lábio Superior")).not.toBeInTheDocument();
    expect(screen.queryByText(/sugest(ão|ões) de ajuste/)).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Planejar|Aceite ao menos/ })).not.toBeInTheDocument();

    // As duas saídas de produto já existentes, oferecidas ali mesmo.
    expect(screen.getByRole("button", { name: "Preencher em nome do paciente" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar anamnese" })).toBeInTheDocument();
  });

  it("does NOT gate a patient who already has an anamnesis from a previous session — anamnesis is per-patient, not per-session", async () => {
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      // Linha existente, sem nenhuma flag de risco ativa — mesmo assim já
      // conta como "anamnese registrada" e libera o fluxo normalmente.
      if (table === "anamnesis") return createQueryBuilder(undefined, { data: { risk_flags: {} } });
      return createQueryBuilder();
    });

    renderGatePage();

    expect(await screen.findByText("2 sugestões de ajuste")).toBeInTheDocument();
    expect(screen.queryByText("Anamnese necessária")).not.toBeInTheDocument();
  });

  it("lets the professional fill the anamnesis on behalf of the patient right from the gate, which then unblocks the normal Stage 1 flow", async () => {
    const { builder } = createStatefulAnamnesisBuilder(null);
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") return builder;
      return createQueryBuilder();
    });

    renderGatePage();
    await screen.findByText("Anamnese necessária");

    fireEvent.click(screen.getByRole("button", { name: "Preencher em nome do paciente" }));
    const saveBtn = await screen.findByRole("button", { name: "Salvar anamnese" });
    fireEvent.click(saveBtn);

    await waitFor(() => expect(anamnesisUpsertSpy).toHaveBeenCalledTimes(1));
    expect(anamnesisUpsertSpy.mock.calls[0][0]).toMatchObject({
      patient_id: "pat-1",
      filled_by: "professional",
    });

    // Preenchida em nome do paciente: o gate cai e a revisão normal aparece.
    expect(await screen.findByText("2 sugestões de ajuste")).toBeInTheDocument();
    expect(screen.queryByText("Anamnese necessária")).not.toBeInTheDocument();
  });

  it("lets the professional (re)send the anamnesis link from the gate, without unblocking the flow by itself", async () => {
    const { builder } = createStatefulAnamnesisBuilder(null);
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") return builder;
      if (table === "anamnesis_links") return createAnamnesisLinksBuilder("tok-gate-1");
      return createQueryBuilder();
    });

    renderGatePage();
    await screen.findByText("Anamnese necessária");

    fireEvent.click(screen.getByRole("button", { name: "Enviar anamnese" }));

    await waitFor(() => expect(linksInsertSpy).toHaveBeenCalledTimes(1));
    expect(linksInsertSpy.mock.calls[0][0]).toMatchObject({ patient_id: "pat-1", professional_id: "pro-1" });
    await waitFor(() => expect(window.open).toHaveBeenCalledTimes(1));

    expect(await screen.findByText(/Link enviado!/)).toBeInTheDocument();
    // Só enviar o link não preenche a anamnese — o gate continua ativo até o
    // paciente efetivamente responder (ou "Verificar novamente" confirmar).
    expect(screen.queryByText("2 sugestões de ajuste")).not.toBeInTheDocument();
  });

  it("'check again' re-queries the anamnesis and unblocks once the patient has answered the link elsewhere", async () => {
    const { builder, state } = createStatefulAnamnesisBuilder(null);
    fromMock.mockImplementation((table: string) => {
      if (table === "sessions") return createSessionsBuilder();
      if (table === "patients") {
        return createQueryBuilder({ data: { name: "Maria Silva" } }, { data: { name: "Maria Silva" } });
      }
      if (table === "anamnesis") return builder;
      return createQueryBuilder();
    });

    renderGatePage();
    await screen.findByText("Anamnese necessária");

    // Paciente respondeu o link enquanto o profissional esperava aqui —
    // simulado alterando o estado do mock diretamente (fora da UI).
    state.row = { risk_flags: { diabetes: true } };

    fireEvent.click(screen.getByRole("button", { name: "Já preencheu? Verificar novamente" }));

    expect(await screen.findByText("2 sugestões de ajuste")).toBeInTheDocument();
    expect(screen.queryByText("Anamnese necessária")).not.toBeInTheDocument();
    // A anamnese recém-confirmada já reflete o risco na revisão normal.
    expect(screen.getByText("Pontos de atenção da anamnese")).toBeInTheDocument();
  });
});
