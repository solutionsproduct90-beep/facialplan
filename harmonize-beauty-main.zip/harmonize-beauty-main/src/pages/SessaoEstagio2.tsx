import React, { useState, useEffect, useRef, useCallback, useMemo, useId } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import TopBar from '@/components/harmonize/TopBar';
import StageDots from '@/components/harmonize/StageDots';
import HarmonizeBadge from '@/components/harmonize/Badge';
import GradientButton from '@/components/harmonize/GradientButton';
import BottomSheet from '@/components/harmonize/BottomSheet';
import SheetSelect from '@/components/harmonize/SheetSelect';
import ProcedureConsentModal from '@/components/harmonize/ProcedureConsentModal';
import { Plus, Minus, Trash2, Pencil, AlertTriangle, X, Info, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { buildLastToxinDatesByRegion, TOXIN_HISTORY_EXCLUDED_STATUS } from '@/lib/toxinHistory';
import { isPatientConsentRefusal, readEdgeFunctionError } from '@/lib/edgeFunctionError';
import type { ApplicationPoint, Insumo, Substance, ApplicationTechnique, ApplicationDepth, ApplicationDevice, JustificationParts, TechniqueLinePattern, TechniqueLine } from '@/types/harmonize';
import {
  SUBSTANCE_LABEL,
  SUBSTANCE_DEFAULT_UNIT,
  SUBSTANCE_COLOR,
  SUBSTANCE_DEFAULT_TECHNIQUE,
  SUBSTANCE_DEFAULT_DEPTH,
  SUBSTANCE_DEFAULT_DEVICE,
  APPLICATION_TECHNIQUES,
  APPLICATION_DEPTHS,
  APPLICATION_DEVICES,
  DOSE_ALERT_THRESHOLD,
  sumDoseBySubstance,
  isDoseOverThreshold,
  TOXIN_MIN_REINJECTION_INTERVAL_DAYS,
  daysSince,
  TECHNIQUE_LINE_PATTERNS,
} from '@/types/harmonize';
import {
  mapManualPointJustificationStatsRow,
  buildManualPointJustificationDraft,
} from '@/lib/manualPointJustification';
import {
  mapComplementaryProcedureInsightRow,
  complementaryProcedureInsightText,
} from '@/lib/complementaryProcedureInsight';
import { FACE_REGION_KEYS, landmarkPositionForRegion, regionLabel, regionFallbackPosition, isVascularRiskApplication, regionPolygonForRegion } from '@/lib/faceRegions';
import type { FaceRegionKey } from '@/lib/faceRegions';
import { buildTechniqueLine } from '@/lib/faceGeometry';
import { computeBudget, normalizeInsumos, suggestInsumo, formatCurrency, type CurrencyCode } from '@/lib/budget';
import type { IntensityLevel } from '@/lib/procedureCatalog';
import { INTENSITY_LEVELS, proceduresForSubstance, getProcedure, procedureNameKey, suggestedDoseForLevel } from '@/lib/procedureCatalog';
import { summarizeApplicationPoints, buildProcedureConsentText } from '@/lib/procedureConsent';
import { buildDoseThresholdRequest } from '@/lib/adversarialRiskCheck';
import type { NamedProtocol, DoseRange } from '@/lib/namedProtocols';
import {
  NAMED_PROTOCOLS,
  getNamedProtocol,
  protocolToApplicationPoints,
  projectedDoseRangeBySubstance,
  protocolNameKey,
  protocolDescriptionKey,
  protocolVarianceNoteKey,
  protocolDisplayContraindications,
} from '@/lib/namedProtocols';
import { loadFaceLandmarker, loadFaceMeshConnections } from '@/lib/faceLandmarker';
import type { FaceMeshConnections } from '@/lib/faceLandmarker';
import { groupApplicationPoints, groupKeyOf, supportsMultiPoint, addPointToGroup, removePointFromGroup } from '@/lib/applicationPoints';
import type { Json } from '@/integrations/supabase/types';
import { Link } from 'react-router-dom';
import { useOfflineSessionDraft } from '@/hooks/useOfflineSessionDraft';
import type { SessionDraftData } from '@/types/offlineDraft';
import PendingSyncIndicator from '@/components/harmonize/PendingSyncIndicator';

const SUBSTANCES: Substance[] = ['acido_hialuronico', 'toxina_botulinica', 'bioestimulador'];

// Alerta educativo de zona de risco vascular: só faz sentido para
// preenchedor (ácido hialurônico) — toxina botulínica e bioestimuladores
// não têm o mesmo risco de oclusão vascular imediata por injeção. Regra
// extraída para `isVascularRiskApplication` em `src/lib/faceRegions.ts`
// (lista não validada clinicamente — ponto de partida para revisão médica)
// pra ser a única fonte, reaproveitada também pelo aviso de sinais de
// emergência do checklist de pós-procedimento (src/lib/postProcedureChecklist.ts).
const isVascularRiskPoint = (region: string, substance: Substance) =>
  isVascularRiskApplication(region, substance);

const hexToRgba = (hex: string, alpha: number) => {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

const newPointId = () =>
  (typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `manual-${Date.now()}`);

// Landmark detectado mais próximo de uma posição normalizada — usado ao
// arrastar um ponto que tem uma linha de técnica (TechniqueLine), pra
// recalcular a linha a partir do landmark mais próximo da NOVA posição em
// vez de manter o índice antigo (que descreveria outro lugar da foto depois
// do arrasto). Busca linear em até 478 pontos — barata o bastante para
// rodar só no fim do arrasto (pointer-up), não a cada pointer-move.
const nearestLandmarkIndex = (
  pos: { x: number; y: number },
  landmarks: { x: number; y: number }[] | null
): number | undefined => {
  if (!landmarks || landmarks.length === 0) return undefined;
  let bestIdx: number | undefined;
  let bestDistSq = Infinity;
  for (let i = 0; i < landmarks.length; i++) {
    const lm = landmarks[i];
    if (!lm) continue;
    const distSq = (lm.x - pos.x) ** 2 + (lm.y - pos.y) ** 2;
    if (distSq < bestDistSq) {
      bestDistSq = distSq;
      bestIdx = i;
    }
  }
  return bestIdx;
};

// Camadas de contorno oficial do MediaPipe desenhadas como malha de fundo
// (efeito "scanner real") — a face oval + as feições internas mais
// relevantes clinicamente (lábios, olhos, sobrancelhas). Deliberadamente SEM
// FACE_LANDMARKS_TESSELATION (a malha completa de ~468 triângulos): poluiria
// demais um overlay clínico, onde o que importa é o contorno das feições, não
// a densidade da malha 3D.
const MESH_CONTOUR_GROUPS: (keyof FaceMeshConnections)[] = ['faceOval', 'lips', 'leftEye', 'rightEye', 'leftEyebrow', 'rightEyebrow'];

const SessaoEstagio2: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useTranslation();

  const [patientId, setPatientId] = useState<string | null>(null);
  const [patientName, setPatientName] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [imgAspect, setImgAspect] = useState(3 / 4);
  const [points, setPoints] = useState<ApplicationPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [landmarks, setLandmarks] = useState<{ x: number; y: number }[] | null>(null);
  const [detectionStatus, setDetectionStatus] = useState<'idle' | 'running' | 'done' | 'unavailable'>('idle');
  // Conjuntos de conexões do contorno oficial do MediaPipe (ver
  // MESH_CONTOUR_GROUPS acima) — carregados junto com a detecção de
  // landmarks, só para desenhar a malha de fundo discreta sobre a foto.
  // Independente de `detectionStatus`: se a detecção falhar não há
  // `landmarks` para desenhar a malha de qualquer forma (ver JSX abaixo), mas
  // manter os dois estados separados evita acoplar a malha à UI de status.
  const [meshConnections, setMeshConnections] = useState<FaceMeshConnections | null>(null);

  const [insumos, setInsumos] = useState<Insumo[] | null>(null);
  const [laborFeePerSession, setLaborFeePerSession] = useState<number | null>(null);
  const [currency, setCurrency] = useState<CurrencyCode>('BRL');

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [addSheetOpen, setAddSheetOpen] = useState(false);
  const [draftRegion, setDraftRegion] = useState<string>(FACE_REGION_KEYS[0]);
  const [draftSubstance, setDraftSubstance] = useState<Substance>('acido_hialuronico');
  const [draftInsumoId, setDraftInsumoId] = useState<string | undefined>(undefined);
  // Procedimento nomeado do catálogo (backlog #47, ver src/lib/procedureCatalog.ts)
  // opcionalmente vinculado a este ponto — ao escolher um, RegionSubstanceQuantityFields
  // pré-preenche região/dose sugeridas, mas nunca trava a edição livre depois.
  const [draftProcedureId, setDraftProcedureId] = useState<string | undefined>(undefined);
  const [draftQty, setDraftQty] = useState(1);
  const [draftTechnique, setDraftTechnique] = useState<ApplicationTechnique>(SUBSTANCE_DEFAULT_TECHNIQUE.acido_hialuronico);
  const [draftDepth, setDraftDepth] = useState<ApplicationDepth>(SUBSTANCE_DEFAULT_DEPTH.acido_hialuronico);
  const [draftDevice, setDraftDevice] = useState<ApplicationDevice>(SUBSTANCE_DEFAULT_DEVICE.acido_hialuronico);
  // Padrão VISUAL de aplicação (leque/reticulado/linear/punctura seriada ou
  // "nenhum") — PARALELO ao `technique` clínico acima, não a mesma coisa
  // (ver comentário de TechniqueLinePattern em src/types/harmonize.ts).
  // undefined = "nenhum", mesmo comportamento de sempre (ponto sem linha).
  const [draftLinePattern, setDraftLinePattern] = useState<TechniqueLinePattern | undefined>(undefined);
  // Copiloto de Justificativa Clínica (backlog P6) — rascunho estruturado
  // oferecido só para pontos MANUAIS (todo ponto criado por este sheet é
  // manual, por definição). `addSheetKey` força um remount do copiloto (ver
  // ManualPointJustificationCopilot abaixo) a cada abertura do sheet, pra que
  // o estado interno de "última sugestão aplicada" não vaze de uma tentativa
  // de novo ponto pra outra.
  const [draftJustification, setDraftJustification] = useState<JustificationParts | undefined>(undefined);
  const [addSheetKey, setAddSheetKey] = useState(0);
  // Sessão nova para esta paciente (sem nenhuma outra sessão registrada) —
  // usado só para reforçar o texto do alerta de dose total (item 3): sem
  // sessão anterior nesta clínica não há histórico de tolerância para
  // comparar, o que torna a referência de atenção ainda mais relevante.
  const [isFirstSession, setIsFirstSession] = useState<boolean | null>(null);

  // Alerta de Intervalo Mínimo entre Aplicações (ideia do squad de Produto):
  // por região, a data ISO da sessão CONCLUÍDA mais recente desta paciente
  // (diferente da atual) que já recebeu toxina botulínica ali — usado pra
  // avisar (não bloquear) quando um novo/editado ponto de toxina cai numa
  // região reaplicada antes de TOXIN_MIN_REINJECTION_INTERVAL_DAYS. Ver
  // handleDraftSubstanceChange/RegionSubstanceQuantityFields abaixo. Vazio
  // até a query de histórico (no load() logo abaixo) terminar.
  const [lastToxinDatesByRegion, setLastToxinDatesByRegion] = useState<Record<string, string>>({});

  const [procedureConsentOpen, setProcedureConsentOpen] = useState(false);
  const [procedureConsentLoading, setProcedureConsentLoading] = useState(false);

  // Protocolos Nomeados (comitê técnico simulado, ver src/lib/namedProtocols.ts)
  // — entrada alternativa à montagem manual de pontos: escolher um protocolo
  // aplica todos os pontos dele de uma vez sobre a foto e dispara a mesma
  // simulação de IA (generate-simulation) já usada na Etapa 3, ANTES de
  // expor a dosagem exata por ponto para edição. `protocolPickerOpen` é a
  // lista dos 6 protocolos; `protocolPreview` é o protocolo em confirmação
  // (mostra aviso do comitê, contraindicações e alertas de limiar ANTES de
  // aplicar os pontos); `protocolFlow` acompanha um protocolo já confirmado
  // até a simulação ser gerada e revelada — enquanto `!revealed`, a lista de
  // pontos/dose fica oculta (ver protocolFlowPending abaixo).
  const [protocolPickerOpen, setProtocolPickerOpen] = useState(false);
  const [protocolPreview, setProtocolPreview] = useState<NamedProtocol | null>(null);
  const [protocolFlow, setProtocolFlow] = useState<{
    protocol: NamedProtocol;
    generating: boolean;
    error: boolean;
    afterUrl: string | null;
    revealed: boolean;
  } | null>(null);
  const protocolFlowPending = !!protocolFlow && !protocolFlow.revealed;
  // true para todo ponto vindo de um protocolo nomeado já revelado/editável —
  // usado para manter o aviso fixo do comitê visível enquanto a origem dos
  // pontos da sessão incluir pelo menos um protocolo, mesmo depois de
  // navegar para longe e voltar (não é um estado só do fluxo em andamento).
  const hasProtocolOriginPoints = useMemo(() => points.some((p) => !!p.protocolId), [points]);

  // Rascunho offline dos pontos de aplicação (backlog "Modo offline-first
  // (PWA) completo pra sala de procedimento") — `saveDraft` é chamado a
  // cada edição de ponto (ver `updatePoints`/`handleContainerPointerUp`
  // abaixo), gravando localmente (debounced) além do `persist` normal pro
  // Supabase. Quando `persist` falha por estar offline, este rascunho
  // sobrevive num reload/fechamento de aba e é reenviado sozinho por
  // `onSyncDraft` assim que a conexão voltar (ver useOfflineSessionDraft).
  const onSyncDraft = useCallback(async (pendingDraft: SessionDraftData): Promise<boolean> => {
    if (!id || !pendingDraft.stage2Points) return true;
    const { error } = await supabase
      .from('sessions')
      .update({ stage2_overlay: pendingDraft.stage2Points as unknown as Json })
      .eq('id', id);
    return !error;
  }, [id]);

  const {
    draft: offlineDraft,
    loaded: offlineDraftLoaded,
    hasPendingDraft,
    isSyncing: isSyncingDraft,
    saveDraft: saveOfflineDraft,
    clearDraft: clearOfflineDraft,
  } = useOfflineSessionDraft({ sessionId: id, onSync: onSyncDraft });
  const draftRestoredRef = useRef(false);

  const imgRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const positionedRef = useRef(false);
  const draggingId = useRef<string | null>(null);
  const draggedRef = useRef(false);

  useEffect(() => {
    if (!id || !user) return;
    const load = async () => {
      const { data: session } = await supabase
        .from('sessions')
        .select('patient_id, original_image_url, stage2_overlay')
        .eq('id', id)
        .single();
      if (session) {
        const overlay = (session.stage2_overlay as unknown as ApplicationPoint[] | null) ?? [];
        setPoints(overlay);
        setPatientId(session.patient_id);

        const { data: patient } = await supabase
          .from('patients')
          .select('name')
          .eq('id', session.patient_id)
          .single();
        if (patient) setPatientName(patient.name);

        const { count } = await supabase
          .from('sessions')
          .select('id', { count: 'exact', head: true })
          .eq('patient_id', session.patient_id)
          .neq('id', id);
        setIsFirstSession((count ?? 0) === 0);

        // Histórico de sessões anteriores desta paciente, pra saber por
        // região quando foi a última vez que recebeu toxina botulínica —
        // base do Alerta de Intervalo Mínimo entre Aplicações (ver
        // lastToxinDatesByRegion acima). O que conta como aplicação
        // realizada, e por que não é mais só `status = 'complete'`, está em
        // src/lib/toxinHistory.ts.
        const { data: pastSessions } = await supabase
          .from('sessions')
          .select('created_at, stage2_overlay')
          .eq('patient_id', session.patient_id)
          .neq('status', TOXIN_HISTORY_EXCLUDED_STATUS)
          .neq('id', id);
        setLastToxinDatesByRegion(buildLastToxinDatesByRegion(pastSessions));

        if (session.original_image_url) {
          const { data: signed } = await supabase.storage
            .from('patient-photos')
            .createSignedUrl(session.original_image_url, 3600);
          if (signed?.signedUrl) setPhotoUrl(signed.signedUrl);
        }
      }

      const [{ data: profile }, { data: insumosData }] = await Promise.all([
        supabase.from('profiles').select('labor_fee_per_session, currency').eq('id', user.id).single(),
        supabase
          .from('insumos')
          .select('id, substance, brand_name, cost_per_unit, price_per_unit, active')
          .eq('professional_id', user.id),
      ]);
      setLaborFeePerSession(profile?.labor_fee_per_session ?? null);
      setCurrency((profile?.currency as CurrencyCode) ?? 'BRL');
      setInsumos(normalizeInsumos(insumosData));

      setLoading(false);
    };
    load();
  }, [id, user]);

  const activeInsumos = useMemo(() => (insumos ?? []).filter((i) => i.active), [insumos]);
  const budget = useMemo(
    () => computeBudget(points, insumos, laborFeePerSession),
    [points, insumos, laborFeePerSession],
  );

  // Dose total por substância entre TODOS os pontos aceitos da sessão (item
  // 3 do backlog P0) — sem isso nada somava toxina/AH/bioestimulador entre
  // pontos, então excesso só seria percebido ponto a ponto.
  const pointGroups = useMemo(() => groupApplicationPoints(points), [points]);
  const doseTotals = useMemo(() => sumDoseBySubstance(points), [points]);
  const overThresholdSubstances = useMemo(
    () => (Object.entries(doseTotals) as [Substance, number][]).filter(([s, total]) => isDoseOverThreshold(s, total)),
    [doseTotals],
  );

  // Segunda checagem automática de IA ("advogado do diabo" — ver
  // src/lib/adversarialRiskCheck.ts): construída sempre que há alguma
  // substância acima do limiar, mas só efetivamente disparada pelo
  // AdversarialRiskCheck dentro de ProcedureConsentModal quando a sheet de
  // consentimento do procedimento está aberta (ver `active` passado lá).
  const adversarialDoseRequest = useMemo(() => {
    if (overThresholdSubstances.length === 0) return null;
    // `patientId` é obrigatório desde o gate de consentimento no servidor
    // (squad w1-3, ver supabase/functions/_shared/consentGate.ts): a edge
    // function precisa saber de quem é o caso pra checar o consentimento
    // antes de mandar as doses planejadas pra Anthropic.
    if (!patientId) return null;
    return buildDoseThresholdRequest(
      patientId,
      overThresholdSubstances,
      points,
      DOSE_ALERT_THRESHOLD,
      SUBSTANCE_DEFAULT_UNIT,
      !!isFirstSession,
    );
  }, [overThresholdSubstances, patientId, points, isFirstSession]);

  // Persiste o overlay inteiro — sessions.stage2_overlay é a fonte da
  // verdade que a Etapa 3 vai ler.
  const persist = useCallback((next: ApplicationPoint[]) => {
    if (!id) return;
    supabase.from('sessions').update({ stage2_overlay: next as unknown as Json }).eq('id', id).then(({ error }) => {
      if (error) toast.error(t('sessions.stage2.toastSaveError'));
    });
  }, [id, t]);

  const updatePoints = useCallback((updater: (prev: ApplicationPoint[]) => ApplicationPoint[]) => {
    setPoints(prev => {
      const next = updater(prev);
      persist(next);
      // Backup local (debounced) de toda edição — sobrevive a um reload
      // se `persist` acima falhar por estar offline (ver comentário de
      // onSyncDraft acima).
      saveOfflineDraft({ stage2Points: next });
      return next;
    });
  }, [persist, saveOfflineDraft]);

  // Rascunho local pendente encontrado ao montar (ex.: o profissional
  // fechou/recarregou a aba offline com edições ainda não confirmadas no
  // Supabase) prevalece sobre o overlay carregado do servidor — ele pode
  // estar mais atualizado que o último `stage2_overlay` salvo com sucesso.
  // Roda só uma vez, depois que TANTO o `load()` do Supabase quanto a
  // leitura do IndexedDB terminarem (ver `loading`/`offlineDraftLoaded`).
  useEffect(() => {
    if (draftRestoredRef.current) return;
    if (loading || !offlineDraftLoaded) return;
    draftRestoredRef.current = true;
    if (offlineDraft?.pendingSync && offlineDraft.stage2Points) {
      setPoints(offlineDraft.stage2Points);
      persist(offlineDraft.stage2Points);
    }
  }, [loading, offlineDraftLoaded, offlineDraft, persist]);

  // Detecção de landmarks: roda uma vez, sobre a foto real já renderizada.
  const handleImgLoad = () => {
    const img = imgRef.current;
    if (!img) return;
    if (img.naturalWidth && img.naturalHeight) {
      setImgAspect(img.naturalWidth / img.naturalHeight);
    }
    setDetectionStatus('running');
    // A malha de contorno (ver MESH_CONTOUR_GROUPS) é só dado estático da
    // classe FaceLandmarker — carregada em paralelo com o landmarker em si,
    // sem depender do resultado da detecção. Uma falha aqui não deve
    // impedir a detecção normal de landmarks, por isso tem seu próprio
    // .catch silencioso (sem a malha de fundo, a Etapa 2 continua 100%
    // funcional — é só um reforço visual, nunca dado clínico).
    loadFaceMeshConnections()
      .then(setMeshConnections)
      .catch(() => {});
    loadFaceLandmarker()
      .then(landmarker => {
        const result = landmarker.detect(img);
        const first = result.faceLandmarks?.[0];
        if (first && first.length > 0) {
          setLandmarks(first);
          setDetectionStatus('done');
        } else {
          setDetectionStatus('unavailable');
          toast.info(t('sessions.stage2.toastFaceNotDetected'));
        }
      })
      .catch(err => {
        console.error('FaceLandmarker error:', err);
        setDetectionStatus('unavailable');
        toast.info(t('sessions.stage2.toastFaceDetectionUnavailable'));
      });
  };

  // Aplica a posição real dos landmarks aos pontos vindos da Etapa 1 — só
  // na primeira vez (um ponto já reposicionado guarda seu landmarkIndex).
  useEffect(() => {
    if (!landmarks || positionedRef.current) return;
    positionedRef.current = true;
    setPoints(prev => {
      const next = prev.map(p => {
        if (p.source === 'ai' && p.landmarkIndex === undefined) {
          const pos = landmarkPositionForRegion(p.region, landmarks);
          if (pos) return { ...p, x: pos.x, y: pos.y, landmarkIndex: pos.landmarkIndex };
        }
        return p;
      });
      return next;
    });
  }, [landmarks]);

  const selectedPoint = points.find(p => p.id === selectedId) ?? null;

  const relativePosFromEvent = (e: { clientX: number; clientY: number }) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const x = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    const y = Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height));
    return { x, y };
  };

  const handleDotPointerDown = (pointId: string) => (e: React.PointerEvent) => {
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    draggingId.current = pointId;
    draggedRef.current = false;
  };

  const handleContainerPointerMove = (e: React.PointerEvent) => {
    if (!draggingId.current) return;
    const pos = relativePosFromEvent(e);
    if (!pos) return;
    draggedRef.current = true;
    const dragId = draggingId.current;
    setPoints(prev => prev.map(p => (p.id === dragId ? { ...p, x: pos.x, y: pos.y } : p)));
  };

  const handleContainerPointerUp = () => {
    const dragId = draggingId.current;
    draggingId.current = null;
    if (!dragId) return;
    if (draggedRef.current) {
      setPoints(prev => {
        // Ponto arrastado que tem uma linha de técnica: recalcula a linha a
        // partir da NOVA posição + o landmark detectado mais próximo dela —
        // sem isso, a linha ficaria "presa" na origem antiga depois do
        // arrasto, descolada do ponto que agora representa a punção real.
        const next = prev.map(p => {
          if (p.id !== dragId || !p.line) return p;
          const newLandmarkIndex = nearestLandmarkIndex({ x: p.x, y: p.y }, landmarks);
          const polygon = regionPolygonForRegion(p.region, landmarks ?? undefined);
          const line = buildTechniqueLine(p.line.pattern, { x: p.x, y: p.y }, newLandmarkIndex, polygon);
          return { ...p, landmarkIndex: newLandmarkIndex, line };
        });
        persist(next);
        saveOfflineDraft({ stage2Points: next });
        return next;
      });
    } else {
      // Sem movimento — foi um toque para selecionar/editar o ponto.
      setSelectedId(dragId);
    }
  };

  const handleEditSave = (patch: Partial<ApplicationPoint>) => {
    if (!selectedId) return;
    updatePoints(prev => prev.map(p => (p.id === selectedId ? { ...p, ...patch } : p)));
  };

  const handleDeleteSelected = () => {
    if (!selectedId) return;
    updatePoints(prev => prev.filter(p => p.id !== selectedId));
    setSelectedId(null);
  };

  // Item 2 do backlog P0: uma região de toxina botulínica pode se desdobrar
  // em vários pontos discretos, cada um com sua fração da dose total do
  // grupo, em vez de um único ponto carregando a dose inteira — ver
  // src/lib/applicationPoints.ts.
  const handleSplitGroup = (groupKey: string) => {
    updatePoints(prev => addPointToGroup(prev, groupKey, newPointId()));
  };

  const handleRemoveFromGroup = (groupKey: string, pointId: string) => {
    updatePoints(prev => removePointFromGroup(prev, groupKey, pointId));
  };

  const openAddSheet = () => {
    setDraftRegion(FACE_REGION_KEYS[0]);
    setDraftSubstance('acido_hialuronico');
    // Recomendador de marca por custo-benefício (P2): pré-seleciona a marca
    // de melhor margem para a substância padrão — nunca trava, o
    // profissional pode trocar livremente no seletor abaixo.
    setDraftInsumoId(suggestInsumo(activeInsumos, 'acido_hialuronico')?.id);
    setDraftProcedureId(undefined);
    setDraftQty(1);
    setDraftTechnique(SUBSTANCE_DEFAULT_TECHNIQUE.acido_hialuronico);
    setDraftDepth(SUBSTANCE_DEFAULT_DEPTH.acido_hialuronico);
    setDraftDevice(SUBSTANCE_DEFAULT_DEVICE.acido_hialuronico);
    setDraftLinePattern(undefined);
    setDraftJustification(undefined);
    setAddSheetKey(k => k + 1);
    setAddSheetOpen(true);
  };

  // Trocar a substância no formulário de novo ponto reaplica os valores
  // sensatos de técnica/profundidade/dispositivo dessa substância (item 1)
  // — sem isso, escolher "Toxina" depois de já ter ajustado esses campos
  // para AH deixaria valores incoerentes com a nova substância selecionada.
  // O procedimento nomeado escolhido também é invalidado — o catálogo é
  // filtrado por substância (ver proceduresForSubstance), então um
  // procedimento da substância anterior não faz mais sentido aqui.
  const handleDraftSubstanceChange = (s: Substance) => {
    setDraftSubstance(s);
    setDraftProcedureId(undefined);
    // A marca escolhida pertence à substância anterior — reaplica a
    // recomendação de melhor margem (ver suggestInsumo) para a nova
    // substância, do mesmo jeito que técnica/profundidade/dispositivo
    // acima. Segue livremente trocável no seletor de marca abaixo.
    setDraftInsumoId(suggestInsumo(activeInsumos, s)?.id);
    setDraftTechnique(SUBSTANCE_DEFAULT_TECHNIQUE[s]);
    setDraftDepth(SUBSTANCE_DEFAULT_DEPTH[s]);
    setDraftDevice(SUBSTANCE_DEFAULT_DEVICE[s]);
  };

  const confirmAddPoint = () => {
    const fromLandmark = landmarkPositionForRegion(draftRegion, landmarks ?? undefined);
    const fallback = regionFallbackPosition(draftRegion);
    const origin = { x: fromLandmark?.x ?? fallback.x, y: fromLandmark?.y ?? fallback.y };
    const line = draftLinePattern
      ? buildTechniqueLine(draftLinePattern, origin, fromLandmark?.landmarkIndex, regionPolygonForRegion(draftRegion, landmarks ?? undefined))
      : undefined;
    const point: ApplicationPoint = {
      id: newPointId(),
      region: draftRegion,
      label: regionLabel(draftRegion),
      substance: draftSubstance,
      quantity: draftQty,
      unit: SUBSTANCE_DEFAULT_UNIT[draftSubstance],
      x: origin.x,
      y: origin.y,
      landmarkIndex: fromLandmark?.landmarkIndex,
      source: 'manual',
      insumoId: draftInsumoId,
      technique: draftTechnique,
      depth: draftDepth,
      device: draftDevice,
      procedureId: draftProcedureId,
      line,
      // Rascunho do Copiloto de Justificativa Clínica (ver
      // ManualPointJustificationCopilot), livremente editado ou até
      // apagado pelo profissional antes de confirmar — undefined quando a
      // base não tinha amostra suficiente para esta combinação (nenhuma
      // sugestão foi oferecida) ou o profissional limpou o texto.
      justification: draftJustification,
    };
    updatePoints(prev => [...prev, point]);
    setAddSheetOpen(false);
  };

  const openProtocolPicker = () => setProtocolPickerOpen(true);

  // Abre a tela de confirmação de UM protocolo (nome, descrição, aviso do
  // comitê, contraindicações, nota de variação e alertas de limiar) — os
  // pontos do protocolo ainda NÃO são aplicados aqui; só ao confirmar (ver
  // handleConfirmProtocol abaixo), depois que o profissional já viu tudo
  // isso, inclusive quando o protocolo ultrapassa o limiar de dose por
  // desenho (ex. Facelift Líquido) ou combinado com toxina já presente
  // nesta sessão.
  const handleChooseProtocolForPreview = (protocol: NamedProtocol) => {
    setProtocolPickerOpen(false);
    setProtocolPreview(protocol);
  };

  // Confirmar um protocolo: (1) converte os ProtocolPoint em ApplicationPoint
  // de verdade e os adiciona ao stage2_overlay da sessão — mesma estrutura de
  // sempre, cada ponto normal e editável — então (2) reaproveita a mesma
  // edge function generate-simulation já usada na Etapa 3 pra gerar uma
  // simulação ANTES de mostrar a dosagem exata de cada ponto (ver
  // protocolFlowPending, que oculta a lista de pontos/dose enquanto
  // `!revealed`). Só depois que o profissional vê o resultado simulado (ou
  // decide ver os pontos mesmo sem simulação, se a geração falhar) é que a
  // lista normal da Etapa 2 (livremente editável) volta a aparecer.
  const handleConfirmProtocol = async () => {
    if (!protocolPreview || !id || !patientId) return;
    const protocol = protocolPreview;
    setProtocolPreview(null);
    const newPoints = protocolToApplicationPoints(protocol, landmarks ?? undefined, newPointId);
    updatePoints(prev => [...prev, ...newPoints]);
    setProtocolFlow({ protocol, generating: true, error: false, afterUrl: null, revealed: false });

    try {
      const { data, error } = await supabase.functions.invoke('generate-simulation', {
        body: { sessionId: id, patientId, intensity: 'natural' },
      });
      const response = data as { simulationUrl: string | null; originalUrl: string | null; error?: string } | null;
      if (error || !response || response.error) {
        // Mesmo motivo do bloco equivalente na Etapa 3
        // (src/pages/SessaoEstagio3.tsx, runSimulation): numa resposta
        // não-2xx o supabase-js devolve `{ data: null, error }` e guarda o
        // corpo em `error.context` sem nunca lê-lo. Ler `data` aqui não
        // alcança nada, porque `data` é null — e as duas recusas que mais
        // importam neste caminho chegam como não-2xx: 451 do gate de
        // consentimento do paciente (_shared/consentGate.ts) e 402 do gate
        // de assinatura (_shared/subscriptionGate.ts). Sem
        // readEdgeFunctionError, as duas viravam o mesmo toast genérico de
        // "erro ao gerar simulação", escondendo do profissional que ele
        // precisa colher o termo ou regularizar o pagamento.
        const errorBody = await readEdgeFunctionError(error, data);
        if (isPatientConsentRefusal(errorBody)) {
          throw new Error(errorBody?.error || t('namedProtocols.generationConsentErrorToast'));
        }
        throw new Error(errorBody?.error || error?.message || t('namedProtocols.generationErrorToast'));
      }
      setProtocolFlow(prev => (prev ? { ...prev, generating: false, afterUrl: response.simulationUrl } : prev));
    } catch (err: unknown) {
      // A mensagem lançada acima é a do servidor quando existe uma; o texto
      // traduzido genérico só entra quando não há nenhuma.
      toast.error(err instanceof Error && err.message ? err.message : t('namedProtocols.generationErrorToast'));
      setProtocolFlow(prev => (prev ? { ...prev, generating: false, error: true } : prev));
    }
  };

  const handleRevealProtocolPoints = () => {
    setProtocolFlow(prev => (prev ? { ...prev, revealed: true } : prev));
  };

  // A specific TCLE (Termo de Consentimento Livre e Esclarecido) is required
  // once the plan — the ApplicationPoint[] overlay (substances, quantities,
  // regions) — is defined here in Estágio 2, and before Estágio 3 generates
  // any simulation from it.
  const handleNext = () => {
    if (!id || points.length === 0) return;
    setProcedureConsentOpen(true);
  };

  const procedureConsentSummary = useMemo(() => summarizeApplicationPoints(points), [points]);

  const handleConfirmProcedureConsent = async (signerName: string) => {
    if (!id || !patientId) return;
    setProcedureConsentLoading(true);
    try {
      const { error } = await supabase.functions.invoke('record-consent', {
        body: {
          patientId,
          sessionId: id,
          consentType: 'procedimento',
          consentText: buildProcedureConsentText(procedureConsentSummary),
          consentVersion: '1.0',
          // Não há mais um único "procedimento" com nome/slug fixo (ver
          // ApplicationPoint em @/types/harmonize) — identifica o TCLE pelas
          // substâncias efetivamente presentes no plano.
          procedureId: procedureConsentSummary.substances.join(',') || 'sem_substancia',
          procedureSummary: {
            substances: procedureConsentSummary.substances,
            totalsBySubstance: procedureConsentSummary.totalsBySubstance,
            pointCount: procedureConsentSummary.pointCount,
            regionLabels: procedureConsentSummary.regionLabels,
          },
          signerName,
        },
      });
      if (error) throw error;

      await supabase.from('sessions').update({
        stage2_overlay: points as unknown as Json,
        status: 'stage3',
      }).eq('id', id);
      // Estágio 2 confirmado no Supabase — o rascunho local (se houver)
      // não tem mais função aqui, a sessão avança para a Etapa 3.
      clearOfflineDraft();
      setProcedureConsentOpen(false);
      navigate(`/sessoes/${id}/estagio-3`);
    } catch (err) {
      const message = err instanceof Error ? err.message : t('consent.procedure.toastError');
      toast.error(message);
    } finally {
      setProcedureConsentLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-h-bg">
        <TopBar title={t('sessions.stage2.title')} showBack />
        <div className="pt-[56px] p-5 flex flex-col gap-4">
          {[1, 2].map(i => <div key={i} className="bg-h-white rounded-r shadow-h-sm h-[200px] animate-pulse" />)}
        </div>
      </div>
    );
  }

  return (
    <PageTransition>
    <div className="min-h-screen bg-h-bg pb-28">
      <TopBar
        title={t('sessions.stage2.title')}
        showBack
        onBack={() => navigate(`/sessoes/${id}/estagio-1`)}
        rightAction={<HarmonizeBadge variant="grad">{t('sessions.stage2.pointsBadgeShort', { count: points.length })}</HarmonizeBadge>}
      />
      <div className="pt-[56px] max-w-[430px] md:max-w-[560px] mx-auto w-full">
        <div className="px-5 py-4 flex flex-col items-center gap-2">
          <StageDots currentStage={2} activeColor="#A855B5" />
          <PendingSyncIndicator pending={hasPendingDraft} syncing={isSyncingDraft} />
        </div>

        <div className="px-5 flex flex-col gap-4">
          {/* Photo with editable overlay */}
          <div
            ref={containerRef}
            className="relative w-full rounded-r overflow-hidden bg-h-surface-3 touch-none select-none"
            style={{ aspectRatio: imgAspect }}
            onPointerMove={handleContainerPointerMove}
            onPointerUp={handleContainerPointerUp}
          >
            {photoUrl ? (
              <img
                ref={imgRef}
                src={photoUrl}
                alt={t('sessions.stage2.photoAlt')}
                crossOrigin="anonymous"
                onLoad={handleImgLoad}
                onError={() => { setDetectionStatus('unavailable'); toast.error(t('sessions.stage2.toastPhotoLoadError')); }}
                className="w-full h-full object-cover pointer-events-none"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-b from-h-surface-3 to-h-bg flex items-center justify-center">
                <span className="text-h-text-3 text-[14px]">{t('sessions.stage2.photoPlaceholder')}</span>
              </div>
            )}

            {/* Malha de contorno + linhas de técnica — "scanner real" pedido
                pelo dono do produto (ver relatório de investigação): camada
                de SVG SOBREPOSTA aos pontos arrastáveis abaixo (não os
                substitui — eles continuam exatamente os mesmos <div>
                interativos de sempre), pointer-events-none pra nunca
                atrapalhar o arrasto. viewBox 0-100 em vez de coordenadas de
                pixel reais: mais simples de manter, sem precisar rastrear o
                tamanho do container (ResizeObserver) só para isto — o
                trade-off é uma leve distorção de ângulo/espessura de traço em
                fotos bem longe do formato quadrado, aceitável para um
                reforço visual (não é dado clínico, só a origem/pontos
                arrastáveis são). */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              {meshConnections && landmarks && (
                <g stroke="rgba(255,255,255,0.4)" strokeWidth={0.25} fill="none" data-testid="face-mesh-contours">
                  {MESH_CONTOUR_GROUPS.map(groupKey => {
                    // Defesa contra um mock de teste (ou uma versão futura da
                    // lib) que não traga alguma dessas propriedades estáticas
                    // — nunca deixa a malha quebrar o resto da Etapa 2, ela é
                    // só um reforço visual.
                    const connections = meshConnections[groupKey];
                    if (!Array.isArray(connections)) return null;
                    return (
                      <g key={groupKey}>
                        {connections.map((c, i) => {
                          const a = landmarks[c.start];
                          const b = landmarks[c.end];
                          if (!a || !b) return null;
                          return <line key={i} x1={a.x * 100} y1={a.y * 100} x2={b.x * 100} y2={b.y * 100} />;
                        })}
                      </g>
                    );
                  })}
                </g>
              )}

              {points.filter(pt => pt.line).map(pt => (
                <TechniqueLineSvg key={pt.id} pointId={pt.id} line={pt.line as TechniqueLine} color={SUBSTANCE_COLOR[pt.substance]} />
              ))}
            </svg>

            {points.map(pt => {
              const color = SUBSTANCE_COLOR[pt.substance];
              return (
                <div
                  key={pt.id}
                  onPointerDown={handleDotPointerDown(pt.id)}
                  className="absolute flex items-center justify-center cursor-grab active:cursor-grabbing"
                  style={{ top: `${pt.y * 100}%`, left: `${pt.x * 100}%`, transform: 'translate(-50%, -50%)' }}
                >
                  <div
                    className="w-[16px] h-[16px] rounded-full"
                    style={{
                      background: color,
                      boxSizing: 'border-box',
                      // Cor = substância; estilo da borda = origem do ponto
                      // (tracejado = sugestão da IA, sólido = manual).
                      border: `2px ${pt.source === 'ai' ? 'dashed' : 'solid'} rgba(255,255,255,0.9)`,
                      boxShadow: selectedId === pt.id
                        ? '0 0 0 3px rgba(255,255,255,0.9), 0 0 0 5px #1A1918'
                        : `0 0 0 4px ${hexToRgba(color, 0.25)}`,
                    }}
                  />
                </div>
              );
            })}

            <div className="absolute top-3 right-3">
              <HarmonizeBadge variant="grad">
                {detectionStatus === 'running' ? t('sessions.stage2.detectingFace') : t('sessions.stage2.pointsBadgeFull', { count: points.length })}
              </HarmonizeBadge>
            </div>
          </div>

          {/* Aviso persistente de baixa confiança na detecção (item P2 "Validação
              da IA/MediaPipe com casos adversos"): o FaceLandmarker do MediaPipe
              não expõe um score de confiança por rosto — o único sinal disponível
              é binário (achou landmarks ou não, ver handleImgLoad acima). Quando
              não achou (foto de ângulo ruim, muito escura, rosto parcialmente
              coberto etc.), já disparamos um toast, mas um toast é transitório e
              o profissional pode não vê-lo — sem um aviso que persista na tela,
              ele poderia confiar nos pontos (que ficam nas posições genéricas de
              fallback, não ajustadas ao rosto real) sem perceber que precisam de
              revisão manual. Este banner fica visível até a detecção terminar ou
              a página ser recarregada, reforçando que os pontos NÃO foram
              alinhados à foto e pedem conferência manual antes de prosseguir. */}
          {detectionStatus === 'unavailable' && (
            <div
              className="rounded-r-sm p-3 flex items-start gap-2"
              style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
            >
              <AlertTriangle size={15} style={{ color: '#D4900A', flexShrink: 0, marginTop: 1 }} />
              <p className="text-[12px] leading-snug" style={{ color: '#8A6608' }}>
                {t('sessions.stage2.detectionWarningBanner')}
              </p>
            </div>
          )}

          {/* Add point / Use a named protocol — ocultos enquanto uma
              simulação de protocolo está sendo gerada/aguardando revelação
              (ver protocolFlowPending abaixo), pra não permitir editar
              pontos manualmente por baixo do painel de simulação. */}
          {!protocolFlowPending && (
            <div className="flex gap-2">
              <button
                onClick={openAddSheet}
                className="flex-1 bg-h-white rounded-r shadow-h-sm p-3 flex items-center justify-center gap-2 min-h-[44px]"
              >
                <Plus size={16} className="text-h-g-mid" />
                <span className="text-[13px] font-bold text-h-text">{t('sessions.stage2.addPoint')}</span>
              </button>
              <button
                onClick={openProtocolPicker}
                className="flex-1 bg-h-white rounded-r shadow-h-sm p-3 flex items-center justify-center gap-2 min-h-[44px]"
              >
                <Sparkles size={16} className="text-h-g-mid" />
                <span className="text-[13px] font-bold text-h-text">{t('namedProtocols.entryButton')}</span>
              </button>
            </div>
          )}

          {/* Painel de simulação do protocolo — aparece só entre confirmar um
              protocolo e revelar seus pontos/dose (ver handleConfirmProtocol/
              handleRevealProtocolPoints). Mostra primeiro o resultado
              simulado (reaproveitando generate-simulation), a dosagem exata
              só fica visível depois que o profissional clica em "revelar". */}
          {protocolFlowPending && protocolFlow && (
            <div className="bg-h-white rounded-r shadow-h-sm p-4 flex flex-col items-center gap-3 text-center">
              <p className="text-[13px] font-bold text-h-text">
                {t(protocolNameKey(protocolFlow.protocol.id), { defaultValue: protocolFlow.protocol.name })}
              </p>
              {protocolFlow.generating ? (
                <>
                  <div
                    className="w-8 h-8 rounded-full animate-spin"
                    style={{ border: '3px solid rgba(168,85,181,0.2)', borderTopColor: '#A855B5' }}
                  />
                  <p className="text-[12px] text-h-text-3">{t('namedProtocols.generatingHint')}</p>
                </>
              ) : (
                <>
                  {protocolFlow.afterUrl && (
                    <img
                      src={protocolFlow.afterUrl}
                      alt={t('sessions.stage2.photoAlt')}
                      className="w-full rounded-r-sm object-cover"
                      style={{ aspectRatio: imgAspect }}
                    />
                  )}
                  {protocolFlow.error && (
                    <p className="text-[12px]" style={{ color: '#D4900A' }}>{t('namedProtocols.generationErrorToast')}</p>
                  )}
                  <div className="w-full">
                    <GradientButton onClick={handleRevealProtocolPoints}>
                      {protocolFlow.error ? t('namedProtocols.viewAnywayButton') : t('namedProtocols.revealButton')}
                    </GradientButton>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Aviso fixo do comitê — visível sempre que a origem de pelo menos
              um ponto da sessão for um protocolo nomeado (ver
              hasProtocolOriginPoints), inclusive depois de revelado. */}
          {!protocolFlowPending && hasProtocolOriginPoints && (
            <div
              className="rounded-r-sm p-3 flex items-start gap-2"
              style={{ background: 'rgba(124,90,194,0.08)', border: '1px solid rgba(124,90,194,0.24)' }}
            >
              <Info size={15} style={{ color: '#7C5AC2', flexShrink: 0, marginTop: 1 }} />
              <p className="text-[12px] text-h-text-2 leading-snug">{t('namedProtocols.committeeDisclaimer')}</p>
            </div>
          )}

          {/* Legend — código de cores por substância + convenção de borda por origem */}
          {!protocolFlowPending && points.length > 0 && (
            <div className="flex flex-col gap-1.5 px-1">
              <p className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">{t('sessions.stage2.legend.title')}</p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                {SUBSTANCES.map(s => (
                  <div key={s} className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: SUBSTANCE_COLOR[s] }} />
                    <span className="text-[11px] text-h-text-2 font-medium">{SUBSTANCE_LABEL[s]}</span>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-h-text-3">{t('sessions.stage2.legend.originHint')}</p>
            </div>
          )}

          {/* Points list — agrupada por região/sugestão (ver groupApplicationPoints):
              um grupo com mais de 1 ponto é uma região de toxina desdobrada em
              vários pontos discretos (item 2 do backlog P0). */}
          {!protocolFlowPending && (
          <div className="flex flex-col gap-3">
            {pointGroups.map(group => {
              const isMultiPoint = group.points.length > 1;
              const canSplit = supportsMultiPoint(group.points[0].substance);
              return (
                <div key={group.key} className="flex flex-col gap-1.5">
                  {group.points.map((pt, indexInGroup) => {
                    const color = SUBSTANCE_COLOR[pt.substance];
                    return (
                      <button
                        key={pt.id}
                        onClick={() => setSelectedId(pt.id)}
                        className="bg-h-surface rounded-r-sm p-3 flex items-center gap-3 text-left transition-all w-full"
                        style={selectedId === pt.id ? { boxShadow: '0 0 0 1.5px #A855B5' } : {}}
                      >
                        <div
                          className="w-3 h-3 rounded-full flex-shrink-0"
                          style={{
                            background: color,
                            boxSizing: 'border-box',
                            border: `1.5px ${pt.source === 'ai' ? 'dashed' : 'solid'} rgba(0,0,0,0.18)`,
                          }}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="text-[13px] font-bold text-h-text leading-tight truncate">
                              {pt.label || regionLabel(pt.region)}
                              {isMultiPoint && (
                                <span className="text-h-text-3 font-medium"> · {t('sessions.stage2.multiPoint.pointOf', { index: indexInGroup + 1, count: group.points.length })}</span>
                              )}
                            </p>
                            {isVascularRiskPoint(pt.region, pt.substance) && (
                              <span title={t('sessions.stage2.vascularRisk.alert')} className="flex-shrink-0">
                                <AlertTriangle size={13} style={{ color: '#E05050' }} aria-label={t('sessions.stage2.vascularRisk.badgeLabel')} />
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-h-text-3">
                            {SUBSTANCE_LABEL[pt.substance]} · {pt.quantity} {pt.unit}
                            {' · '}{pt.confidence !== undefined ? t('sessions.stage2.aiSuffix', { confidence: pt.confidence }) : t('sessions.stage2.manualSuffix')}
                          </p>
                          {pt.protocolId && (
                            <p className="text-[10px] font-semibold" style={{ color: '#7C5AC2' }}>
                              {t('namedProtocols.pointBadge', {
                                name: t(protocolNameKey(pt.protocolId), {
                                  defaultValue: getNamedProtocol(pt.protocolId)?.name ?? pt.protocolId,
                                }),
                              })}
                            </p>
                          )}
                        </div>
                        {canSplit && isMultiPoint && (
                          <span
                            role="button"
                            tabIndex={0}
                            onClick={(e) => { e.stopPropagation(); handleRemoveFromGroup(group.key, pt.id); }}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); handleRemoveFromGroup(group.key, pt.id); } }}
                            aria-label={t('sessions.stage2.multiPoint.removePoint')}
                            title={t('sessions.stage2.multiPoint.removePoint')}
                            className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{ background: 'rgba(224,80,80,0.08)', color: '#E05050' }}
                          >
                            <X size={13} />
                          </span>
                        )}
                        <Pencil size={14} className="text-h-text-3 flex-shrink-0" />
                      </button>
                    );
                  })}

                  {/* Desdobrar em mais um ponto — só para toxina botulínica
                      (ver supportsMultiPoint). A dose total do grupo é
                      preservada e redistribuída, não somada. */}
                  {canSplit && (
                    <button
                      type="button"
                      onClick={() => handleSplitGroup(group.key)}
                      className="flex items-center gap-1.5 self-start text-[11px] font-bold text-h-g-mid px-2 min-h-[32px]"
                    >
                      <Plus size={13} />
                      {t('sessions.stage2.multiPoint.addPoint')}
                    </button>
                  )}
                </div>
              );
            })}
            {points.length === 0 && (
              <p className="text-[12px] text-h-text-3 text-center py-4">{t('sessions.stage2.noPointsYet')}</p>
            )}
          </div>
          )}

          {/* Dose total da sessão — soma toxina/AH/bioestimulador entre TODOS
              os pontos aceitos e alerta (não bloqueante) quando alguma
              substância passa de uma referência de atenção (item 3 do
              backlog P0; ver DOSE_ALERT_THRESHOLD em src/types/harmonize.ts).
              Mesmo padrão visual do alerta de zona de risco vascular /
              disclaimer da tela de apresentação: cor âmbar, nunca bloqueia o
              botão de avançar. */}
          {!protocolFlowPending && points.length > 0 && (
            <div className="bg-h-surface rounded-r-sm p-3.5 flex flex-col gap-1.5">
              <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1">{t('sessions.stage2.doseSummary.title')}</p>
              {(Object.entries(doseTotals) as [Substance, number][]).map(([substance, total]) => {
                const over = isDoseOverThreshold(substance, total);
                return (
                  <div key={substance} className="flex items-center justify-between">
                    <span className="text-[13px] text-h-text-2">{SUBSTANCE_LABEL[substance]}</span>
                    <span className="text-[13px] font-semibold" style={{ color: over ? '#D4900A' : '#1A1918' }}>
                      {total} {SUBSTANCE_DEFAULT_UNIT[substance]}
                    </span>
                  </div>
                );
              })}

              {overThresholdSubstances.length > 0 && (
                <div
                  className="rounded-r-sm p-3 mt-1 flex items-start gap-2"
                  style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
                >
                  <Info size={15} style={{ color: '#D4900A', flexShrink: 0, marginTop: 1 }} />
                  <p className="text-[12px] leading-snug" style={{ color: '#8A6608' }}>
                    {overThresholdSubstances
                      .map(([substance, total]) => t('sessions.stage2.doseSummary.overThreshold', {
                        substance: SUBSTANCE_LABEL[substance],
                        total,
                        unit: SUBSTANCE_DEFAULT_UNIT[substance],
                        threshold: DOSE_ALERT_THRESHOLD[substance],
                      }))
                      .join(' ')}
                    {' '}{t('sessions.stage2.doseSummary.disclaimer')}
                    {isFirstSession && ` ${t('sessions.stage2.doseSummary.firstSessionNote')}`}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Budget summary — professional-only, never shown to the patient */}
          {!protocolFlowPending && points.length > 0 && (
            <div className="bg-h-surface rounded-r-sm p-3.5 flex flex-col gap-1.5">
              <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1">{t('sessions.stage2.budget.title')}</p>
              {activeInsumos.length === 0 ? (
                <Link to="/perfil" className="text-[13px] font-semibold text-h-g-start">
                  {t('sessions.stage2.budget.configurePrices')}
                </Link>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] text-h-text-2">{t('sessions.stage2.budget.cost')}</span>
                    <span className="text-[13px] font-semibold text-h-text">{formatCurrency(budget.totalCost, currency)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] text-h-text-2">{t('sessions.stage2.budget.price')}</span>
                    <span className="text-[13px] font-semibold text-h-text">{formatCurrency(budget.totalPrice, currency)}</span>
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-h-white">
                    <span className="text-[13px] font-bold text-h-text">{t('sessions.stage2.budget.margin')}</span>
                    <span className="text-[13px] font-bold text-h-text">
                      {formatCurrency(budget.margin, currency)} ({Math.round(budget.marginPct * 100)}%)
                    </span>
                  </div>
                  {budget.unpriced.length > 0 && (
                    <p className="text-[11px] text-h-text-3 mt-1">
                      {t('sessions.stage2.budget.unpriced', { count: budget.unpriced.length })}
                    </p>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom */}
      <div className="fixed bottom-0 left-0 right-0 p-5 bg-h-bg" style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
        <div className="max-w-[430px] md:max-w-[560px] mx-auto">
          <GradientButton onClick={handleNext} disabled={points.length === 0 || protocolFlowPending}>{t('sessions.stage2.generateSimulation')}</GradientButton>
        </div>
      </div>
    </div>

    {/* Edit existing point */}
    <BottomSheet open={!!selectedPoint} onClose={() => setSelectedId(null)} title={t('sessions.stage2.editPointTitle')}>
      {selectedPoint && (
        <PointForm
          key={selectedPoint.id}
          region={selectedPoint.region}
          substance={selectedPoint.substance}
          insumoId={selectedPoint.insumoId}
          procedureId={selectedPoint.procedureId}
          quantity={selectedPoint.quantity}
          technique={selectedPoint.technique ?? SUBSTANCE_DEFAULT_TECHNIQUE[selectedPoint.substance]}
          depth={selectedPoint.depth ?? SUBSTANCE_DEFAULT_DEPTH[selectedPoint.substance]}
          device={selectedPoint.device ?? SUBSTANCE_DEFAULT_DEVICE[selectedPoint.substance]}
          x={selectedPoint.x}
          y={selectedPoint.y}
          landmarkIndex={selectedPoint.landmarkIndex}
          line={selectedPoint.line}
          landmarks={landmarks}
          insumos={activeInsumos}
          lastToxinDatesByRegion={lastToxinDatesByRegion}
          onChange={handleEditSave}
          onDelete={handleDeleteSelected}
          onDone={() => setSelectedId(null)}
          // Copiloto de Justificativa Clínica: só para pontos manuais — um
          // ponto de sugestão de IA (source 'ai') já traz sua própria
          // JustificationParts (ver ANALYSIS_PROMPT/Suggestion.justification),
          // que nunca deve ser substituída por um rascunho de dado agregado.
          showJustificationCopilot={selectedPoint.source === 'manual'}
          justification={selectedPoint.justification}
        />
      )}
    </BottomSheet>

    {/* Add new point */}
    <BottomSheet open={addSheetOpen} onClose={() => setAddSheetOpen(false)} title={t('sessions.stage2.newPointTitle')}>
      <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
        <RegionSubstanceQuantityFields
          region={draftRegion} setRegion={setDraftRegion}
          substance={draftSubstance} setSubstance={handleDraftSubstanceChange}
          insumoId={draftInsumoId} setInsumoId={setDraftInsumoId}
          procedureId={draftProcedureId} setProcedureId={setDraftProcedureId}
          quantity={draftQty} setQuantity={setDraftQty}
          technique={draftTechnique} setTechnique={setDraftTechnique}
          depth={draftDepth} setDepth={setDraftDepth}
          device={draftDevice} setDevice={setDraftDevice}
          linePattern={draftLinePattern} setLinePattern={setDraftLinePattern}
          insumos={activeInsumos}
          lastToxinDatesByRegion={lastToxinDatesByRegion}
        />
        {/* Todo ponto criado por este sheet é manual por definição — o
            copiloto sempre pode se oferecer aqui (ver comentário de
            showJustificationCopilot acima, no form de edição). */}
        <ManualPointJustificationCopilot
          key={addSheetKey}
          enabled={addSheetOpen}
          region={draftRegion}
          substance={draftSubstance}
          unit={SUBSTANCE_DEFAULT_UNIT[draftSubstance]}
          justification={draftJustification}
          onChange={setDraftJustification}
        />
        <GradientButton onClick={confirmAddPoint}>{t('sessions.stage2.confirmAddPoint')}</GradientButton>
      </div>
    </BottomSheet>

    {/* Protocolos Nomeados — lista dos 6 protocolos do comitê (nome +
        descrição curta). Escolher um abre a tela de confirmação abaixo, sem
        aplicar nenhum ponto ainda. */}
    <BottomSheet open={protocolPickerOpen} onClose={() => setProtocolPickerOpen(false)} title={t('namedProtocols.sheetTitle')}>
      <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-3">
        <p className="text-[12px] text-h-text-3">{t('namedProtocols.sheetSubtitle')}</p>
        {NAMED_PROTOCOLS.map(protocol => (
          <button
            key={protocol.id}
            type="button"
            onClick={() => handleChooseProtocolForPreview(protocol)}
            className="w-full text-left bg-h-surface rounded-r-sm p-3 flex flex-col gap-1"
          >
            <p className="text-[13px] font-bold text-h-text">{t(protocolNameKey(protocol.id), { defaultValue: protocol.name })}</p>
            <p className="text-[11px] text-h-text-3">{t(protocolDescriptionKey(protocol.id), { defaultValue: protocol.description })}</p>
          </button>
        ))}
      </div>
    </BottomSheet>

    {/* Confirmação de UM protocolo — nome, descrição, aviso fixo do comitê,
        contraindicações, nota de variação e (quando aplicável) alertas de
        limiar de dose PROATIVOS, antes de qualquer ponto ser aplicado: o
        próprio protocolo pode já ultrapassar por desenho a referência de
        atenção (ex. Facelift Líquido) ou, somado a pontos já presentes
        nesta sessão, ultrapassar combinado (ex. um segundo protocolo de
        toxina — ver projectedDoseRangeBySubstance/DOSE_ALERT_THRESHOLD). */}
    <BottomSheet
      open={!!protocolPreview}
      onClose={() => setProtocolPreview(null)}
      title={protocolPreview ? t(protocolNameKey(protocolPreview.id), { defaultValue: protocolPreview.name }) : ''}
    >
      {protocolPreview && (
        <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-3">
          <p className="text-[12px] text-h-text-2">
            {t(protocolDescriptionKey(protocolPreview.id), { defaultValue: protocolPreview.description })}
          </p>

          <div
            className="rounded-r-sm p-3"
            style={{ background: 'rgba(124,90,194,0.08)', border: '1px solid rgba(124,90,194,0.24)' }}
          >
            <p className="text-[11px] text-h-text-2 leading-snug">{t('namedProtocols.committeeDisclaimer')}</p>
          </div>

          <div>
            <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1">{t('namedProtocols.contraindicationsLabel')}</p>
            <ul className="list-disc pl-4 flex flex-col gap-0.5">
              {protocolDisplayContraindications(protocolPreview.id, t).map((contraindication, i) => (
                <li key={i} className="text-[12px] text-h-text-2">{contraindication}</li>
              ))}
            </ul>
          </div>

          <p className="text-[11px] text-h-text-3 italic">
            {t(protocolVarianceNoteKey(protocolPreview.id), { defaultValue: protocolPreview.varianceNote })}
          </p>

          {(Object.entries(projectedDoseRangeBySubstance(protocolPreview, points)) as [Substance, DoseRange][]).map(
            ([substance, range]) => {
              const existingTotal = doseTotals[substance] ?? 0;
              const overThreshold = isDoseOverThreshold(substance, range.max) || isDoseOverThreshold(substance, range.min);
              if (overThreshold) {
                return (
                  <div
                    key={substance}
                    className="rounded-r-sm p-3 flex items-start gap-2"
                    style={{ background: 'rgba(212,144,10,0.08)', border: '1px solid rgba(212,144,10,0.28)' }}
                  >
                    <AlertTriangle size={15} style={{ color: '#D4900A', flexShrink: 0, marginTop: 1 }} />
                    <p className="text-[12px] leading-snug" style={{ color: '#8A6608' }}>
                      {t('namedProtocols.warnings.overThreshold', {
                        substance: SUBSTANCE_LABEL[substance],
                        min: range.min,
                        max: range.max,
                        unit: SUBSTANCE_DEFAULT_UNIT[substance],
                        threshold: DOSE_ALERT_THRESHOLD[substance],
                      })}
                    </p>
                  </div>
                );
              }
              if (existingTotal > 0) {
                return (
                  <div
                    key={substance}
                    className="rounded-r-sm p-3 flex items-start gap-2"
                    style={{ background: 'rgba(124,90,194,0.08)', border: '1px solid rgba(124,90,194,0.24)' }}
                  >
                    <Info size={15} style={{ color: '#7C5AC2', flexShrink: 0, marginTop: 1 }} />
                    <p className="text-[12px] text-h-text-2 leading-snug">
                      {t('namedProtocols.warnings.combinedInfo', {
                        substance: SUBSTANCE_LABEL[substance],
                        existingTotal,
                        min: range.min,
                        max: range.max,
                        unit: SUBSTANCE_DEFAULT_UNIT[substance],
                      })}
                    </p>
                  </div>
                );
              }
              return null;
            },
          )}

          <div className="flex gap-3">
            <button
              onClick={() => setProtocolPreview(null)}
              className="flex-1 flex items-center justify-center rounded-full py-3 min-h-[44px] bg-h-surface"
            >
              <span className="text-[13px] font-bold text-h-text-2">{t('namedProtocols.cancelButton')}</span>
            </button>
            <div className="flex-1"><GradientButton onClick={handleConfirmProtocol}>{t('namedProtocols.confirmButton')}</GradientButton></div>
          </div>
        </div>
      )}
    </BottomSheet>

    {/* Procedure-specific TCLE, required before generating the simulation */}
    <ProcedureConsentModal
      open={procedureConsentOpen}
      summary={procedureConsentSummary}
      onConfirm={handleConfirmProcedureConsent}
      onClose={() => setProcedureConsentOpen(false)}
      loading={procedureConsentLoading}
      adversarialRequest={adversarialDoseRequest}
    />
    </PageTransition>
  );
};

// Uma seta triangular simples na ponta de um segmento — desenhada
// manualmente via <polygon> em vez de um <marker>/marker-end do SVG: mais
// simples de posicionar em cada ponto do zigue-zague de fanning/reticulado
// (que têm várias "pontas", não só uma no fim da polyline inteira) sem lidar
// com as particularidades de orientação de markers entre navegadores.
const TechniqueLineArrow: React.FC<{ from: { x: number; y: number }; to: { x: number; y: number }; color: string }> = ({ from, to, color }) => {
  const angle = Math.atan2(to.y - from.y, to.x - from.x);
  const size = 1.4; // unidades do viewBox 0-100 do SVG do container da foto
  const tipX = to.x * 100;
  const tipY = to.y * 100;
  const backAngle1 = angle + Math.PI - 0.45;
  const backAngle2 = angle + Math.PI + 0.45;
  const points = [
    `${tipX},${tipY}`,
    `${tipX + size * Math.cos(backAngle1)},${tipY + size * Math.sin(backAngle1)}`,
    `${tipX + size * Math.cos(backAngle2)},${tipY + size * Math.sin(backAngle2)}`,
  ].join(' ');
  return <polygon points={points} fill={color} />;
};

// Desenha a linha de técnica de um ponto (polyline + setas nas pontas de
// trabalho, ver TechniqueLineArrow acima) — o ponto de origem em si (o
// círculo arrastável) continua sendo desenhado pelo <div> de sempre, por
// cima desta camada; aqui só o trajeto/guia geométrico.
const TechniqueLineSvg: React.FC<{ pointId: string; line: TechniqueLine; color: string }> = ({ pointId, line, color }) => {
  const pointsAttr = line.path.map(p => `${p.x * 100},${p.y * 100}`).join(' ');
  return (
    <g data-testid={`technique-line-${pointId}`}>
      <polyline
        points={pointsAttr}
        fill="none"
        stroke={color}
        strokeWidth={0.6}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={0.85}
      />
      {line.path.map((p, i) => {
        if (i === line.originIndex) return null; // origem já marcada pelo ponto arrastável
        const from = line.path[i - 1] ?? p;
        return <TechniqueLineArrow key={i} from={from} to={p} color={color} />;
      })}
    </g>
  );
};

// Formulário de edição de um ponto já existente (região + substância + marca + quantidade + técnica/profundidade/dispositivo + remover).
const PointForm: React.FC<{
  region: string;
  substance: Substance;
  insumoId?: string;
  procedureId?: string;
  quantity: number;
  technique: ApplicationTechnique;
  depth: ApplicationDepth;
  device: ApplicationDevice;
  // Posição atual do ponto + landmark associado, e a própria linha de
  // técnica já ativa (se houver) — necessários para recalcular `line`
  // quando o profissional troca o padrão visual de aplicação pelo seletor
  // abaixo (ver commitLinePattern). `landmarks` é a detecção bruta da foto
  // (para achar o polígono da região atual via regionPolygonForRegion).
  x: number;
  y: number;
  landmarkIndex?: number;
  line?: TechniqueLine;
  landmarks: { x: number; y: number }[] | null;
  insumos: Insumo[];
  lastToxinDatesByRegion: Record<string, string>;
  onChange: (patch: Partial<ApplicationPoint>) => void;
  onDelete: () => void;
  onDone: () => void;
  // Copiloto de Justificativa Clínica (backlog P6) — só oferecido quando o
  // ponto sendo editado é manual (ver comentário de uso em SessaoEstagio2.tsx).
  showJustificationCopilot?: boolean;
  justification?: JustificationParts;
}> = ({
  region, substance, insumoId, procedureId, quantity, technique, depth, device, x, y, landmarkIndex, line, landmarks,
  insumos, lastToxinDatesByRegion,
  onChange, onDelete, onDone, showJustificationCopilot = false, justification,
}) => {
  const { t } = useTranslation();
  const [localRegion, setLocalRegion] = useState(region);
  const [localSubstance, setLocalSubstance] = useState(substance);
  const [localInsumoId, setLocalInsumoId] = useState(insumoId);
  const [localProcedureId, setLocalProcedureId] = useState(procedureId);
  const [localQty, setLocalQty] = useState(quantity);
  const [localTechnique, setLocalTechnique] = useState(technique);
  const [localDepth, setLocalDepth] = useState(depth);
  const [localDevice, setLocalDevice] = useState(device);
  const [localLinePattern, setLocalLinePattern] = useState<TechniqueLinePattern | undefined>(line?.pattern);

  useEffect(() => {
    setLocalRegion(region); setLocalSubstance(substance); setLocalInsumoId(insumoId); setLocalProcedureId(procedureId); setLocalQty(quantity);
    setLocalTechnique(technique); setLocalDepth(depth); setLocalDevice(device); setLocalLinePattern(line?.pattern);
  }, [region, substance, insumoId, procedureId, quantity, technique, depth, device, line]);

  // Trocar o padrão visual de aplicação: "nenhum" remove `line`; qualquer
  // outro padrão (re)calcula a linha a partir da posição ATUAL do ponto (não
  // se move ao trocar o padrão) + seu landmark já conhecido + o polígono da
  // região atualmente selecionada no form (null se a região ainda não tem
  // `areaIndices` curado — buildTechniqueLine degrada graciosamente nesse caso).
  const commitLinePattern = (pattern: TechniqueLinePattern | undefined) => {
    setLocalLinePattern(pattern);
    if (!pattern) { onChange({ line: undefined }); return; }
    const polygon = regionPolygonForRegion(localRegion, landmarks ?? undefined);
    onChange({ line: buildTechniqueLine(pattern, { x, y }, landmarkIndex, polygon) });
  };

  // Trocar a REGIÃO de um ponto que já tem uma linha de técnica ativa: sem
  // recalcular aqui, `line` ficava presa ao polígono da região ANTERIOR (ex.
  // o alcance/direção calculados sobre a malar), só que agora rotulada e
  // exibida como se fosse da região nova (ex. mento) — incoerência visível
  // sobre a própria foto (achado ao verificar a transição
  // região-com-polígono ↔ região-sem-polígono pedida na investigação do PR
  // #11). Mesmo recálculo de `commitLinePattern` acima, só que disparado pela
  // troca de região em vez da troca de padrão; a posição do ponto (x, y) e o
  // landmark não mudam, só o polígono usado para o alcance da linha.
  const commitRegion = (r: string) => {
    setLocalRegion(r);
    const line = localLinePattern
      ? buildTechniqueLine(localLinePattern, { x, y }, landmarkIndex, regionPolygonForRegion(r, landmarks ?? undefined))
      : undefined;
    onChange({ region: r, label: regionLabel(r), line });
  };
  const commitSubstance = (s: Substance) => {
    setLocalSubstance(s);
    // A marca escolhida, o procedimento nomeado (ver src/lib/procedureCatalog.ts
    // — filtrado por substância) e a técnica/profundidade/dispositivo
    // sugeridos pertencem à substância anterior — trocar a substância
    // reaplica os valores sensatos da nova. A marca reaplicada é a
    // recomendação de melhor margem entre as marcas cadastradas dessa
    // substância (ver suggestInsumo em src/lib/budget.ts) — nunca trava,
    // o profissional pode trocar livremente no seletor abaixo.
    const suggested = suggestInsumo(insumos, s)?.id;
    setLocalInsumoId(suggested);
    setLocalProcedureId(undefined);
    setLocalTechnique(SUBSTANCE_DEFAULT_TECHNIQUE[s]);
    setLocalDepth(SUBSTANCE_DEFAULT_DEPTH[s]);
    setLocalDevice(SUBSTANCE_DEFAULT_DEVICE[s]);
    onChange({
      substance: s,
      unit: SUBSTANCE_DEFAULT_UNIT[s],
      insumoId: suggested,
      procedureId: undefined,
      technique: SUBSTANCE_DEFAULT_TECHNIQUE[s],
      depth: SUBSTANCE_DEFAULT_DEPTH[s],
      device: SUBSTANCE_DEFAULT_DEVICE[s],
    });
  };
  const commitInsumoId = (i: string | undefined) => { setLocalInsumoId(i); onChange({ insumoId: i }); };
  const commitProcedureId = (p: string | undefined) => { setLocalProcedureId(p); onChange({ procedureId: p }); };
  const commitQty = (q: number) => { setLocalQty(q); onChange({ quantity: q }); };
  const commitTechnique = (v: ApplicationTechnique) => { setLocalTechnique(v); onChange({ technique: v }); };
  const commitDepth = (v: ApplicationDepth) => { setLocalDepth(v); onChange({ depth: v }); };
  const commitDevice = (v: ApplicationDevice) => { setLocalDevice(v); onChange({ device: v }); };

  return (
    <div style={{ padding: '16px 20px 20px' }} className="flex flex-col gap-4">
      <RegionSubstanceQuantityFields
        region={localRegion} setRegion={commitRegion}
        substance={localSubstance} setSubstance={commitSubstance}
        insumoId={localInsumoId} setInsumoId={commitInsumoId}
        procedureId={localProcedureId} setProcedureId={commitProcedureId}
        quantity={localQty} setQuantity={commitQty}
        technique={localTechnique} setTechnique={commitTechnique}
        depth={localDepth} setDepth={commitDepth}
        device={localDevice} setDevice={commitDevice}
        linePattern={localLinePattern} setLinePattern={commitLinePattern}
        insumos={insumos}
        lastToxinDatesByRegion={lastToxinDatesByRegion}
      />
      {showJustificationCopilot && (
        <ManualPointJustificationCopilot
          enabled
          region={localRegion}
          substance={localSubstance}
          unit={SUBSTANCE_DEFAULT_UNIT[localSubstance]}
          justification={justification}
          onChange={(j) => onChange({ justification: j })}
        />
      )}
      <div className="flex gap-3">
        <button
          onClick={onDelete}
          className="flex-1 flex items-center justify-center gap-2 rounded-full py-3 min-h-[44px]"
          style={{ background: 'rgba(224,80,80,0.08)', color: '#E05050' }}
        >
          <Trash2 size={15} />
          <span className="text-[13px] font-bold">{t('sessions.stage2.remove')}</span>
        </button>
        <div className="flex-1"><GradientButton onClick={onDone}>{t('sessions.stage2.done')}</GradientButton></div>
      </div>
    </div>
  );
};

// Campos compartilhados entre o form de edição e o de novo ponto.
const RegionSubstanceQuantityFields: React.FC<{
  region: string; setRegion: (r: string) => void;
  substance: Substance; setSubstance: (s: Substance) => void;
  insumoId?: string; setInsumoId: (i: string | undefined) => void;
  procedureId?: string; setProcedureId: (p: string | undefined) => void;
  quantity: number; setQuantity: (q: number) => void;
  technique: ApplicationTechnique; setTechnique: (v: ApplicationTechnique) => void;
  depth: ApplicationDepth; setDepth: (v: ApplicationDepth) => void;
  device: ApplicationDevice; setDevice: (v: ApplicationDevice) => void;
  // Padrão VISUAL de aplicação (ver TechniqueLinePattern) — PARALELO a
  // `technique` acima, não o mesmo seletor: um é metadado clínico textual, o
  // outro é geometria desenhada sobre a foto (ver comentário de
  // TechniqueLinePattern em src/types/harmonize.ts). undefined = "nenhum"
  // (comportamento de sempre, ponto sem linha).
  linePattern: TechniqueLinePattern | undefined; setLinePattern: (v: TechniqueLinePattern | undefined) => void;
  insumos: Insumo[];
  // Alerta de Intervalo Mínimo entre Aplicações: por região, a data ISO da
  // última sessão concluída anterior desta paciente com toxina botulínica
  // ali aplicada — ver comentário de lastToxinDatesByRegion em
  // SessaoEstagio2.tsx e o bloco de alerta logo abaixo do de risco vascular.
  lastToxinDatesByRegion: Record<string, string>;
}> = ({
  region, setRegion, substance, setSubstance, insumoId, setInsumoId, procedureId, setProcedureId, quantity, setQuantity,
  technique, setTechnique, depth, setDepth, device, setDevice, linePattern, setLinePattern, insumos, lastToxinDatesByRegion,
}) => {
  const { t } = useTranslation();
  const step = substance === 'toxina_botulinica' ? 1 : 0.1;
  const unit = SUBSTANCE_DEFAULT_UNIT[substance];
  const insumosForSubstance = insumos.filter(i => i.substance === substance);
  // Recomendador de marca por custo-benefício (backlog P2): entre as marcas
  // cadastradas desta substância, a de melhor margem (ver suggestInsumo em
  // src/lib/budget.ts) — só usada aqui para destacar visualmente qual marca
  // é a sugestão automática; a pré-seleção em si acontece em
  // handleDraftSubstanceChange/commitSubstance/openAddSheet, ao trocar de
  // substância. O profissional pode trocar livremente no seletor abaixo.
  const suggestedInsumo = useMemo(() => suggestInsumo(insumos, substance), [insumos, substance]);
  const insumoIsSuggested = insumosForSubstance.length > 1 && !!suggestedInsumo && insumoId === suggestedInsumo.id;

  // Alerta de Intervalo Mínimo entre Aplicações: só se aplica a toxina
  // botulínica, e só quando a região atualmente selecionada já recebeu
  // toxina há menos de TOXIN_MIN_REINJECTION_INTERVAL_DAYS numa sessão
  // concluída anterior desta paciente (ver lastToxinDatesByRegion).
  const lastToxinDateForRegion = substance === 'toxina_botulinica' ? lastToxinDatesByRegion[region] : undefined;
  const daysSinceLastToxin = lastToxinDateForRegion !== undefined ? daysSince(lastToxinDateForRegion) : null;
  const showMinIntervalAlert = daysSinceLastToxin !== null && daysSinceLastToxin < TOXIN_MIN_REINJECTION_INTERVAL_DAYS;

  // Procedimentos nomeados do catálogo (backlog #47) filtrados pela
  // substância selecionada — trocar de substância acima invalida o
  // procedimento escolhido (ver commitSubstance/handleDraftSubstanceChange),
  // então esta lista sempre casa com o procedimento atualmente selecionável.
  const proceduresForCurrentSubstance = useMemo(() => proceduresForSubstance(substance), [substance]);
  const selectedProcedure = getProcedure(procedureId);
  // Nível de intensidade só existe para pré-preencher a dose sugerida — não
  // é persistido no ApplicationPoint (ver comentário de `procedureId` em
  // src/types/harmonize.ts), por isso vive só localmente aqui.
  const [intensityLevel, setIntensityLevel] = useState<IntensityLevel>('medio');

  // Selecionar um procedimento pré-preenche região (a primeira das regiões
  // do procedimento, ou a região já escolhida se ela já fizer parte da
  // lista dele) e dose (ponto médio da faixa do nível de intensidade atual)
  // — nunca trava esses campos, o profissional pode ajustar livremente
  // depois pelos próprios controles de região/quantidade abaixo.
  const handleSelectProcedure = (id: string | undefined) => {
    setProcedureId(id);
    const procedure = getProcedure(id);
    if (!procedure) return;
    const nextRegion = procedure.regions.includes(region as FaceRegionKey) ? region : procedure.regions[0];
    setRegion(nextRegion);
    setQuantity(suggestedDoseForLevel(procedure, intensityLevel));
  };

  const handleSelectIntensity = (level: IntensityLevel) => {
    setIntensityLevel(level);
    if (selectedProcedure) setQuantity(suggestedDoseForLevel(selectedProcedure, level));
  };

  return (
    <>
      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.region')}</p>
        <SheetSelect
          value={region}
          onChange={setRegion}
          title={t('sessions.stage2.region')}
          options={FACE_REGION_KEYS.map(r => ({ value: r, label: regionLabel(r) }))}
        />
      </div>

      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.substance')}</p>
        <div className="flex gap-2">
          {SUBSTANCES.map(s => (
            <button
              key={s}
              onClick={() => setSubstance(s)}
              className={`flex-1 py-2.5 rounded-r-sm text-[12px] font-bold transition-all ${
                substance === s ? 'bg-gradient-brand' : 'bg-h-surface text-h-text-3'
              }`}
              style={substance === s ? { color: '#fff' } : {}}
            >
              {SUBSTANCE_LABEL[s]}
            </button>
          ))}
        </div>
      </div>

      {/* Procedimento nomeado (backlog #47, catálogo curado — ver
          src/lib/procedureCatalog.ts) — sempre opcional: "Nenhum
          procedimento" preserva o fluxo de ponto 100% manual já existente.
          Selecionar um procedimento só pré-preenche região/dose logo abaixo
          (ver handleSelectProcedure/handleSelectIntensity); nunca trava a
          edição livre desses campos depois. */}
      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.procedure.label')}</p>
        <select
          value={procedureId ?? ''}
          onChange={e => handleSelectProcedure(e.target.value || undefined)}
          className="w-full bg-h-surface rounded-r-sm px-3 py-3 text-[14px] font-semibold text-h-text outline-none"
        >
          <option value="">{t('sessions.stage2.procedure.none')}</option>
          {proceduresForCurrentSubstance.map(p => (
            <option key={p.id} value={p.id}>
              {t(procedureNameKey(p.id), { defaultValue: p.name })}
            </option>
          ))}
        </select>
        {selectedProcedure && (
          <div className="flex flex-col gap-1.5 mt-2">
            <p className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">{t('sessions.stage2.procedure.intensityLabel')}</p>
            <div className="flex gap-2">
              {INTENSITY_LEVELS.map(level => (
                <button
                  key={level}
                  type="button"
                  onClick={() => handleSelectIntensity(level)}
                  className={`flex-1 py-2 rounded-r-sm text-[12px] font-bold transition-all ${
                    intensityLevel === level ? 'bg-gradient-brand' : 'bg-h-surface text-h-text-3'
                  }`}
                  style={intensityLevel === level ? { color: '#fff' } : {}}
                >
                  {t(`procedureCatalog.intensity.${level}`)}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-h-text-3">{t('sessions.stage2.procedure.hint')}</p>
          </div>
        )}
        {/* Sugestão Complementar de Procedimento (ciclo 14/09, squad P9-4) —
            insight passivo e discreto, nunca um modal, nunca preenche nada
            sozinho. Ver ComplementaryProcedureInsight abaixo. */}
        <ComplementaryProcedureInsight procedureId={procedureId} />
      </div>

      {/* Alerta educativo de zona de risco vascular — não bloqueia o fluxo,
          só chama atenção antes de confirmar/salvar o ponto. Ver
          isVascularRiskPoint / HIGH_VASCULAR_RISK_REGIONS. */}
      {isVascularRiskPoint(region, substance) && (
        <div
          className="rounded-r-sm p-3 flex items-start gap-2"
          style={{ background: 'rgba(224,80,80,0.08)', border: '1px solid rgba(224,80,80,0.24)' }}
        >
          <AlertTriangle size={15} style={{ color: '#E05050', flexShrink: 0, marginTop: 1 }} />
          <p className="text-[12px] text-h-text-2 leading-snug">{t('sessions.stage2.vascularRisk.alert')}</p>
        </div>
      )}

      {/* Alerta de Intervalo Mínimo entre Aplicações (ideia do squad de
          Produto): educativo e NÃO bloqueante, mesmo padrão visual do
          alerta de zona de risco vascular acima — nunca impede
          adicionar/salvar o ponto, só chama atenção antes de confirmar. Ver
          TOXIN_MIN_REINJECTION_INTERVAL_DAYS em src/types/harmonize.ts. */}
      {showMinIntervalAlert && (
        <div
          className="rounded-r-sm p-3 flex items-start gap-2"
          style={{ background: 'rgba(224,80,80,0.08)', border: '1px solid rgba(224,80,80,0.24)' }}
        >
          <AlertTriangle size={15} style={{ color: '#E05050', flexShrink: 0, marginTop: 1 }} />
          <p className="text-[12px] text-h-text-2 leading-snug">
            {t('sessions.stage2.minInterval.alert', {
              days: daysSinceLastToxin,
              threshold: TOXIN_MIN_REINJECTION_INTERVAL_DAYS,
            })}
          </p>
        </div>
      )}

      {/* Marca/insumo — só aparece quando o profissional já cadastrou pelo
          menos uma marca ativa para a substância selecionada (em Perfil). */}
      {insumosForSubstance.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 mb-1.5">
            <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide">{t('sessions.stage2.insumo')}</p>
            {insumoIsSuggested && (
              <span
                title={t('sessions.stage2.insumoSuggestedHint')}
                className="text-[9px] font-bold uppercase tracking-wide rounded-full px-1.5 py-0.5"
                style={{ background: 'rgba(124,90,194,0.12)', color: '#7C5AC2' }}
              >
                {t('sessions.stage2.insumoSuggestedBadge')}
              </span>
            )}
          </div>
          <select
            value={insumoId ?? ''}
            onChange={e => setInsumoId(e.target.value || undefined)}
            className="w-full bg-h-surface rounded-r-sm px-3 py-3 text-[14px] font-semibold text-h-text outline-none"
          >
            <option value="">{t('sessions.stage2.insumoNone')}</option>
            {insumosForSubstance.map(i => (
              <option key={i.id} value={i.id}>
                {i.brandName}
                {insumosForSubstance.length > 1 && i.id === suggestedInsumo?.id ? ` ${t('sessions.stage2.insumoSuggestedOptionSuffix')}` : ''}
              </option>
            ))}
          </select>
          {insumoIsSuggested && (
            <p className="text-[10px] text-h-text-3 mt-1">{t('sessions.stage2.insumoSuggestedHint')}</p>
          )}
        </div>
      )}

      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.quantity')}</p>
        <div className="flex items-center gap-3 bg-h-surface rounded-full px-2 py-1.5 w-fit">
          <button
            onClick={() => setQuantity(Math.max(step, Math.round((quantity - step) * 100) / 100))}
            className="w-8 h-8 rounded-full bg-h-white flex items-center justify-center shadow-h-sm"
          >
            <Minus size={14} />
          </button>
          <span className="text-[14px] font-bold text-h-text min-w-[72px] text-center">{quantity} {unit}</span>
          <button
            onClick={() => setQuantity(Math.round((quantity + step) * 100) / 100)}
            className="w-8 h-8 rounded-full bg-h-white flex items-center justify-center shadow-h-sm"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>

      {/* Técnica, profundidade e dispositivo — detalhamento clínico por
          ponto (item 1 do backlog P0). Cada campo já chega com o valor
          sensato daquela substância (ver SUBSTANCE_DEFAULT_*) e é livremente
          editável a partir daí. */}
      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.technique.label')}</p>
        <SheetSelect
          value={technique}
          onChange={(v) => setTechnique(v as ApplicationTechnique)}
          title={t('sessions.stage2.technique.label')}
          options={APPLICATION_TECHNIQUES.map(v => ({ value: v, label: t(`sessions.stage2.technique.options.${v}`) }))}
        />
      </div>

      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.depth.label')}</p>
        <SheetSelect
          value={depth}
          onChange={(v) => setDepth(v as ApplicationDepth)}
          title={t('sessions.stage2.depth.label')}
          options={APPLICATION_DEPTHS.map(v => ({ value: v, label: t(`sessions.stage2.depth.options.${v}`) }))}
        />
      </div>

      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.device.label')}</p>
        <div className="flex gap-2">
          {APPLICATION_DEVICES.map(v => (
            <button
              key={v}
              type="button"
              onClick={() => setDevice(v)}
              className={`flex-1 py-2.5 rounded-r-sm text-[12px] font-bold transition-all ${
                device === v ? 'bg-gradient-brand' : 'bg-h-surface text-h-text-3'
              }`}
              style={device === v ? { color: '#fff' } : {}}
            >
              {t(`sessions.stage2.device.options.${v}`)}
            </button>
          ))}
        </div>
      </div>

      {/* Padrão visual de aplicação (ver TechniqueLinePattern) — DELIBERADAMENTE
          um campo separado de "Técnica" acima: um é metadado clínico
          textual (usado no PDF/documentação), o outro é a geometria
          desenhada sobre a foto (linha/leque/grade/pontos-guia). "Nenhum"
          preserva o comportamento de sempre (só o ponto, sem linha) —
          totalmente opcional e retrocompatível com sessões antigas. */}
      <div>
        <p className="text-[11px] font-bold text-h-text-3 uppercase tracking-wide mb-1.5">{t('sessions.stage2.linePattern.label')}</p>
        <SheetSelect
          value={linePattern ?? 'nenhum'}
          onChange={(v) => setLinePattern(v === 'nenhum' ? undefined : (v as TechniqueLinePattern))}
          title={t('sessions.stage2.linePattern.label')}
          options={[
            { value: 'nenhum', label: t('sessions.stage2.linePattern.options.nenhum') },
            ...TECHNIQUE_LINE_PATTERNS.map(v => ({ value: v, label: t(`sessions.stage2.linePattern.options.${v}`) })),
          ]}
        />
        <p className="text-[10px] text-h-text-3 mt-1">{t('sessions.stage2.linePattern.hint')}</p>
      </div>
    </>
  );
};

/** `justification` raso comparável campo-a-campo — o suficiente aqui, os 3 campos são sempre string. */
function justificationEquals(a: JustificationParts, b: JustificationParts): boolean {
  return a.finding === b.finding && a.clinicalGoal === b.clinicalGoal && a.technicalNote === b.technicalNote;
}

/**
 * Copiloto de Justificativa Clínica (backlog P6) — busca
 * `get_manual_point_justification_stats` (RPC SECURITY DEFINER, chamável por
 * qualquer profissional autenticado, ver
 * supabase/migrations/20260911100000_add_manual_point_justification_stats_rpc.sql)
 * para a combinação substância+região atual e, quando há amostra suficiente
 * na base, pré-preenche um RASCUNHO de `JustificationParts` — sempre editável
 * a partir daqui, nunca aceito automaticamente sem a professional poder
 * mudar uma palavra sequer.
 *
 * DECISÃO DE PRIVACIDADE: toda estatística usada aqui já vem agregada/cortada
 * por amostra mínima da própria RPC (nunca em TypeScript, ver comentário de
 * arquivo em src/lib/manualPointJustification.ts); o texto gerado nunca
 * descreve o paciente atual, só o padrão observado na base inteira.
 *
 * Quando a combinação não tem amostra suficiente, a RPC devolve zero linhas
 * — este componente então renderiza `null`, sem toast de erro nem estado
 * vazio chamativo: ausência de sugestão é o comportamento NORMAL no começo
 * da vida da base, não uma falha.
 *
 * `justification`/`onChange` refletem o campo já existente em
 * `ApplicationPoint.justification` — o componente só ESCREVE nele quando o
 * valor atual está vazio ou ainda é exatamente igual à última sugestão que
 * ele mesmo aplicou (`lastAppliedRef`); um texto que o profissional já
 * editou manualmente nunca é sobrescrito por uma nova busca (ex.: trocar de
 * região/substância depois de já ter customizado o texto).
 */
const ManualPointJustificationCopilot: React.FC<{
  enabled: boolean;
  region: string;
  substance: Substance;
  unit: string;
  justification: JustificationParts | undefined;
  onChange: (justification: JustificationParts | undefined) => void;
}> = ({ enabled, region, substance, unit, justification, onChange }) => {
  const { t } = useTranslation();
  const [suggestion, setSuggestion] = useState<JustificationParts | null>(null);
  const lastAppliedRef = useRef<JustificationParts | null>(null);
  // useId() em vez de um id fixo: o Add e o Edit sheet podem coexistir na
  // árvore do DOM (BottomSheet/vaul não garante desmontar o conteúdo
  // fechado), então um id estático duplicaria entre as duas instâncias.
  const fieldIdPrefix = useId();

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    setSuggestion(null);
    (async () => {
      const { data, error } = await supabase.rpc('get_manual_point_justification_stats', {
        p_substance: substance,
        p_region: region,
      });
      // Erro de rede/RPC ou combinação sem amostra suficiente (zero linhas)
      // recebem o MESMO tratamento aqui de propósito: nenhuma sugestão,
      // nenhum alarme — ver comentário de arquivo acima.
      if (cancelled || error) return;
      const stats = mapManualPointJustificationStatsRow(data?.[0] ?? null);
      if (!stats || cancelled) return;
      setSuggestion(
        buildManualPointJustificationDraft(
          stats,
          { regionLabel: regionLabel(region), substanceLabel: SUBSTANCE_LABEL[substance], unit },
          t,
        ),
      );
    })();
    return () => { cancelled = true; };
  }, [enabled, region, substance, unit, t]);

  useEffect(() => {
    if (!suggestion) return;
    const shouldApply = !justification || justificationEquals(justification, lastAppliedRef.current ?? { finding: '', clinicalGoal: '', technicalNote: '' });
    lastAppliedRef.current = suggestion;
    if (shouldApply) onChange(suggestion);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [suggestion]);

  if (!suggestion) return null;

  const current = justification ?? suggestion;
  const commitField = (field: keyof JustificationParts, value: string) => onChange({ ...current, [field]: value });

  return (
    <div className="rounded-r-sm p-3 flex flex-col gap-2.5" style={{ background: 'rgba(124,90,194,0.06)', border: '1px solid rgba(124,90,194,0.22)' }}>
      <div className="flex items-center gap-1.5">
        <Sparkles size={14} style={{ color: '#7C5AC2', flexShrink: 0 }} />
        <p className="text-[11px] font-bold uppercase tracking-wide" style={{ color: '#7C5AC2' }}>
          {t('sessions.stage2.justificationCopilot.badge')}
        </p>
      </div>
      <p className="text-[11px] text-h-text-3 leading-snug">{t('sessions.stage2.justificationCopilot.disclaimer')}</p>

      <div className="flex flex-col gap-1">
        <label htmlFor={`${fieldIdPrefix}-finding`} className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">
          {t('sessions.stage2.justificationCopilot.findingLabel')}
        </label>
        <textarea
          id={`${fieldIdPrefix}-finding`}
          value={current.finding}
          onChange={(e) => commitField('finding', e.target.value)}
          rows={2}
          className="w-full bg-h-white rounded-r-sm px-2.5 py-2 text-[12px] text-h-text outline-none resize-none"
        />
      </div>
      <div className="flex flex-col gap-1">
        <label htmlFor={`${fieldIdPrefix}-clinical-goal`} className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">
          {t('sessions.stage2.justificationCopilot.clinicalGoalLabel')}
        </label>
        <textarea
          id={`${fieldIdPrefix}-clinical-goal`}
          value={current.clinicalGoal}
          onChange={(e) => commitField('clinicalGoal', e.target.value)}
          rows={2}
          className="w-full bg-h-white rounded-r-sm px-2.5 py-2 text-[12px] text-h-text outline-none resize-none"
        />
      </div>
      <div className="flex flex-col gap-1">
        <label htmlFor={`${fieldIdPrefix}-technical-note`} className="text-[10px] font-bold text-h-text-3 uppercase tracking-wide">
          {t('sessions.stage2.justificationCopilot.technicalNoteLabel')}
        </label>
        <textarea
          id={`${fieldIdPrefix}-technical-note`}
          value={current.technicalNote}
          onChange={(e) => commitField('technicalNote', e.target.value)}
          rows={3}
          className="w-full bg-h-white rounded-r-sm px-2.5 py-2 text-[12px] text-h-text outline-none resize-none"
        />
      </div>
    </div>
  );
};

/**
 * Sugestão Complementar de Procedimento (Produto & Features, ciclo 14/09,
 * squad P9-4) — busca `get_complementary_procedure_insight` (RPC SECURITY
 * DEFINER, chamável por qualquer profissional autenticado, ver
 * supabase/migrations/20260914100000_add_complementary_procedure_insight_rpc.sql)
 * sempre que um Procedimento nomeado do catálogo (backlog #47) está
 * selecionado no form de novo/edição de ponto, e mostra um insight PASSIVO e
 * discreto quando a base revela um padrão de coocorrência suficiente — NUNCA
 * um modal, NUNCA preenche campo nenhum sozinho, só informação pro
 * profissional decidir se oferece um combo maior. DIFERENTE do Recomendador
 * de marca por custo-benefício (otimiza margem de uma substância já
 * escolhida) e do Plano B/Combo Plans (100% manual) — ver comentário de
 * arquivo em src/lib/complementaryProcedureInsight.ts.
 *
 * Quando a combinação não tem amostra suficiente (ou a RPC falha — erro de
 * rede, sessão expirada etc.), este componente renderiza `null`: ausência de
 * insight é o estado NORMAL, nunca um erro visível pro profissional nem algo
 * que interrompa o resto do Estágio 2 — mesmo tratamento de
 * ManualPointJustificationCopilot acima para o mesmo tipo de situação.
 */
const ComplementaryProcedureInsight: React.FC<{ procedureId: string | undefined }> = ({ procedureId }) => {
  const { t } = useTranslation();
  const [complementaryId, setComplementaryId] = useState<string | null>(null);

  useEffect(() => {
    setComplementaryId(null);
    if (!procedureId) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase.rpc('get_complementary_procedure_insight', {
        p_procedure_key: procedureId,
      });
      // Erro de rede/RPC ou combinação sem amostra suficiente (zero linhas)
      // recebem o MESMO tratamento aqui de propósito: nenhum insight, nenhum
      // alarme — ver comentário de arquivo acima.
      if (cancelled || error) return;
      const key = mapComplementaryProcedureInsightRow(data?.[0] ?? null);
      if (!cancelled) setComplementaryId(key);
    })();
    return () => { cancelled = true; };
  }, [procedureId]);

  if (!procedureId || !complementaryId) return null;
  const text = complementaryProcedureInsightText(procedureId, complementaryId, t);
  if (!text) return null;

  return (
    <div
      className="rounded-r-sm p-3 mt-2 flex items-start gap-2"
      style={{ background: 'rgba(124,90,194,0.06)', border: '1px solid rgba(124,90,194,0.22)' }}
    >
      <Sparkles size={14} style={{ color: '#7C5AC2', flexShrink: 0, marginTop: 1 }} />
      <p className="text-[11px] text-h-text-2 leading-snug">{text}</p>
    </div>
  );
};

export default SessaoEstagio2;
