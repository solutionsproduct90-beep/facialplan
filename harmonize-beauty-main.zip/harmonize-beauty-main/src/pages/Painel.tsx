import React, { useMemo, useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import AppLayout from '@/components/harmonize/AppLayout';
import HCard from '@/components/harmonize/HCard';
import ProgressRing from '@/components/harmonize/ProgressRing';
import GradientButton from '@/components/harmonize/GradientButton';
import { SkeletonStats, SkeletonCard } from '@/components/harmonize/Skeletons';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { fetchAllRows } from '@/lib/fetchAllRows';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Target, Flame, Trophy, Wallet, RefreshCw, Pencil, Star, Images, ChevronRight, Gauge, Link2, BellRing, TrendingUp } from 'lucide-react';
import { normalizeInsumos, formatCurrency } from '@/lib/budget';
import {
  computeMonthlyPotential,
  computeSubscriptionRoi,
  computeGoalProgress,
  countSessionsInPeriod,
  computeActiveDayStreak,
  formatRoiMultiple,
  computeSimulationAccuracyStats,
  aggregateReturnRadarAlerts,
  getConversionBenchmarkBucket,
  type GoalPeriod,
} from '@/lib/panel';
import AgendaTab from '@/components/harmonize/panel/AgendaTab';
import AgendaOverviewWidget from '@/components/harmonize/panel/AgendaOverviewWidget';
import EstoqueTab from '@/components/harmonize/panel/EstoqueTab';
import EstoqueOverviewWidget from '@/components/harmonize/panel/EstoqueOverviewWidget';
import FaturamentoTab from '@/components/harmonize/panel/FaturamentoTab';
import FaturamentoOverviewWidget from '@/components/harmonize/panel/FaturamentoOverviewWidget';

type PanelTab = 'overview' | 'agenda' | 'stock' | 'billing';

const PANEL_TABS: PanelTab[] = ['overview', 'agenda', 'stock', 'billing'];

// Janela de busca de `sessions` pro Painel: cobre o mês corrente inteiro (pro
// potencial financeiro/meta mensal) e uma folga generosa pra sequência de
// dias ativos, sem trazer o histórico completo do profissional a cada
// carregamento da tela.
const SESSIONS_LOOKBACK_DAYS = 90;

/**
 * Painel de uso/financeiro do profissional (`/painel`) — adaptação do
 * dashboard de retenção do concorrente Face Plan™ ao NOSSO modelo de
 * assinatura binária (ativo/bloqueado, sem cota de simulações por ciclo):
 * nada de contador "simulações restantes no ciclo" aqui, só métricas que já
 * existem ou fazem sentido sem cota — sessões no período, um ROI real da
 * assinatura (orçamento do mês ÷ mensalidade) e uma sequência de dias
 * ativos. Tela própria em vez de mais uma seção em Home.tsx: Home já é
 * densa (CTA + em andamento + pacientes recentes, ver comentário lá sobre
 * as duas colunas em desktop) e este conteúdo é "dashboard", não parte do
 * fluxo de abrir uma sessão — mesmo tratamento que Sessoes/Perfil/Conta já
 * têm como telas próprias fora de Home, com entrada pela nav principal.
 *
 * Desde a v2, a tela ganhou abas além do dashboard original — "Agenda"
 * (mini sistema de agendamento, src/components/harmonize/panel/AgendaTab.tsx),
 * "Estoque" (controle de estoque dos insumos, .../EstoqueTab.tsx) e
 * "Faturamento" (receita/margem/ticket médio agregados do mês + ranking de
 * substâncias mais lucrativas, só de sessões concluídas — .../FaturamentoTab.tsx,
 * pedido do squad de Produto) — trocadas pela mesma barra de pílulas (`role="tablist"`) já usada em
 * BeforeAfterViewer.tsx, o padrão mais recente de alternância de modo do
 * app (preferido aqui ao `<Tabs>` genérico de src/components/ui/tabs.tsx,
 * que não é usado em nenhuma tela hoje). O conteúdo original (ROI/meta/
 * streak) continua sendo a aba "overview", renderizado exatamente como
 * antes — nada nele mudou além de virar condicional à aba ativa.
 *
 * A aba "overview" virou um dashboard de 2 colunas só no desktop (`wide` em
 * AppLayout.tsx, que larga o container até 1040px): a coluna principal tem
 * o conteúdo de sempre, e uma coluna lateral (`hidden md:flex`) mostra um
 * vislumbre de Agenda/Estoque/Faturamento ao mesmo tempo, sem precisar
 * trocar de aba — cada widget (AgendaOverviewWidget/EstoqueOverviewWidget/
 * FaturamentoOverviewWidget) reaproveita a MESMA queryKey da aba completa
 * correspondente, então não duplica leitura de rede. No mobile essa coluna
 * fica escondida de propósito: a barra de pílulas já dá acesso direto às 3
 * abas, então repetir os widgets ali só pesaria a rolagem — pedido
 * explícito do dono do produto pra desktop e mobile terem layouts
 * genuinamente diferentes, não o mesmo conteúdo só esticado.
 */
const Painel: React.FC = () => {
  const { user } = useAuth();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<PanelTab>('overview');

  // Oculto por padrão a cada carregamento da tela — de propósito: a tela
  // pode estar visível com o paciente por perto, e valores de orçamento/
  // mensalidade não são pra ele ver. Não persiste em localStorage nem em
  // memória entre visitas.
  const [valuesRevealed, setValuesRevealed] = useState(false);

  const [editingSubscription, setEditingSubscription] = useState(false);
  const [subscriptionDraft, setSubscriptionDraft] = useState('');
  const [savingSubscription, setSavingSubscription] = useState(false);

  const [editingGoal, setEditingGoal] = useState(false);
  const [goalTargetDraft, setGoalTargetDraft] = useState('');
  const [goalPeriodDraft, setGoalPeriodDraft] = useState<GoalPeriod>('weekly');
  const [savingGoal, setSavingGoal] = useState(false);

  const {
    data: profile,
    isLoading: loadingProfile,
    isError: profileError,
    refetch: refetchProfile,
  } = useQuery({
    queryKey: ['panel-profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('labor_fee_per_session, subscription_monthly_value, session_goal_target, session_goal_period')
        .eq('id', user!.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const {
    data: insumosData,
    isLoading: loadingInsumos,
    isError: insumosError,
    refetch: refetchInsumos,
  } = useQuery({
    queryKey: ['panel-insumos', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('insumos')
        .select('id, substance, brand_name, cost_per_unit, price_per_unit, active')
        .eq('professional_id', user!.id);
      if (error) throw error;
      return normalizeInsumos(data);
    },
    enabled: !!user,
  });

  const {
    data: sessionsData,
    isLoading: loadingSessions,
    isError: sessionsError,
    refetch: refetchSessions,
  } = useQuery({
    queryKey: ['panel-sessions', user?.id],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - SESSIONS_LOOKBACK_DAYS);
      const { data, error } = await supabase
        .from('sessions')
        .select('created_at, stage2_overlay')
        .eq('professional_id', user!.id)
        .gte('created_at', since.toISOString());
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  // Radar de Retorno agregado (ver src/lib/returnRadar.ts + card "Retornos"
  // logo abaixo) — pedido explícito do dono do produto por um alerta visível
  // ao abrir o app, além do badge discreto que já existe em Pacientes.tsx.
  // Query PRÓPRIA (não dá pra reaproveitar `sessionsData` acima): aquela vem
  // sem separação por paciente e só com os últimos 90 dias, enquanto o Radar
  // de Retorno precisa da ÚLTIMA sessão CONCLUÍDA de CADA paciente — pode ter
  // sido há muitos meses (ver janelas em SUBSTANCE_RETURN_WINDOW_MONTHS).
  // Mesmo formato de join `patients(*, sessions(...))` de Pacientes.tsx,
  // reduzido ao mínimo de colunas que `returnRadarForSessions` lê.
  const {
    data: returnRadarPatientsData,
    isLoading: loadingReturnRadarPatients,
    isError: returnRadarPatientsError,
    refetch: refetchReturnRadarPatients,
  } = useQuery({
    queryKey: ['panel-return-radar-patients', user?.id],
    queryFn: () =>
      // Paginado (src/lib/fetchAllRows.ts). Diferente das outras leituras do
      // Painel, esta não tem janela de 90 dias — é o histórico inteiro de
      // pacientes —, então é a que realmente alcança o teto de linhas por
      // resposta do PostgREST (Max Rows, 1000 por padrão, aplicado em
      // silêncio com `error: null`). Truncar aqui não deixaria o Radar de
      // Retorno incompleto: deixaria a contagem de pacientes a retornar
      // errada com aparência de certa. Mesma classe do ciclo 86.
      fetchAllRows((from, to) =>
        supabase
          .from('patients')
          .select('sessions(created_at, status, stage2_overlay)')
          .eq('professional_id', user!.id)
          .eq('is_deleted', false)
          .range(from, to),
      ),
    enabled: !!user,
  });

  // Média de NPS recente (Central de Depoimentos/NPS Pós-Procedimento) — só
  // `nps_score`, sem `comment` (não usado aqui e o RLS de patient_feedback já
  // restringe a leitura ao próprio professional_id, mas evita trazer texto
  // livre do paciente numa tela que só mostra um número). Mesma janela de 90
  // dias das demais métricas do Painel, pra não misturar critério de
  // "recente" na mesma tela.
  const {
    data: feedbackData,
    isLoading: loadingFeedback,
    isError: feedbackError,
    refetch: refetchFeedback,
  } = useQuery({
    queryKey: ['panel-feedback', user?.id],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - SESSIONS_LOOKBACK_DAYS);
      const { data, error } = await supabase
        .from('patient_feedback')
        .select('nps_score')
        .eq('professional_id', user!.id)
        .gte('created_at', since.toISOString());
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  // Índice de Precisão da Simulação (backlog P4) — autoavaliação do próprio
  // profissional (session_simulation_accuracy_ratings, ver migration
  // 20260911030000_add_session_simulation_accuracy_ratings.sql) de quão
  // perto a simulação de IA do Estágio 3 chegou do resultado real
  // (session_real_results). NÃO é um score automático de IA visual — mesmo
  // cuidado de "nenhuma pseudo-precisão inventada" do resto desta tela (ver
  // computeSimulationAccuracyStats em src/lib/panel.ts). Mesma janela de 90
  // dias das demais métricas do Painel.
  const {
    data: accuracyRatingsData,
    isLoading: loadingAccuracyRatings,
    isError: accuracyRatingsError,
    refetch: refetchAccuracyRatings,
  } = useQuery({
    queryKey: ['panel-simulation-accuracy-ratings', user?.id],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - SESSIONS_LOOKBACK_DAYS);
      const { data, error } = await supabase
        .from('session_simulation_accuracy_ratings')
        .select('rating')
        .eq('professional_id', user!.id)
        .gte('created_at', since.toISOString());
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  // Comparativo de conversão sessão→procedimento vs. pares da mesma
  // especialidade (Central de Inteligência estendida ao profissional
  // individual — ver get_professional_conversion_benchmark, migration
  // 20260914100000_...). Query PRÓPRIA e deliberadamente FORA de
  // isLoading/hasError: um erro aqui (ou a RPC devolvendo zero linhas por
  // não ter grupo de comparação com amostra mínima) nunca deve travar nem
  // mostrar um erro pro resto do Painel — o card correspondente simplesmente
  // não aparece (ver getConversionBenchmarkBucket em src/lib/panel.ts).
  const { data: conversionBenchmarkRows } = useQuery({
    queryKey: ['panel-conversion-benchmark', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc('get_professional_conversion_benchmark');
      if (error) return null;
      return data;
    },
    enabled: !!user,
  });
  const conversionBenchmarkBucket = useMemo(
    () => getConversionBenchmarkBucket(conversionBenchmarkRows),
    [conversionBenchmarkRows],
  );

  const isLoading = loadingProfile || loadingInsumos || loadingSessions || loadingReturnRadarPatients || loadingFeedback || loadingAccuracyRatings;
  const hasError = profileError || insumosError || sessionsError || returnRadarPatientsError || feedbackError || accuracyRatingsError;

  const npsAverage = useMemo(() => {
    if (!feedbackData || feedbackData.length === 0) return null;
    const sum = feedbackData.reduce((acc, row) => acc + row.nps_score, 0);
    return { average: sum / feedbackData.length, count: feedbackData.length };
  }, [feedbackData]);

  const simulationAccuracyStats = useMemo(
    () => computeSimulationAccuracyStats(accuracyRatingsData ?? []),
    [accuracyRatingsData],
  );

  const goalPeriod: GoalPeriod = (profile?.session_goal_period as GoalPeriod) ?? 'weekly';
  const goalTarget = profile?.session_goal_target ?? null;
  const subscriptionValue = profile?.subscription_monthly_value ?? null;
  const laborFeePerSession = profile?.labor_fee_per_session ?? null;

  const sessionsInPeriod = useMemo(
    () => countSessionsInPeriod(sessionsData ?? [], goalPeriod),
    [sessionsData, goalPeriod],
  );
  const goalProgress = useMemo(
    () => computeGoalProgress(sessionsInPeriod, goalTarget),
    [sessionsInPeriod, goalTarget],
  );

  const monthlyPotential = useMemo(
    () => computeMonthlyPotential(sessionsData ?? [], insumosData, laborFeePerSession),
    [sessionsData, insumosData, laborFeePerSession],
  );
  const roi = useMemo(
    () => computeSubscriptionRoi(monthlyPotential, subscriptionValue),
    [monthlyPotential, subscriptionValue],
  );

  const streak = useMemo(
    () => computeActiveDayStreak((sessionsData ?? []).map((s) => s.created_at)),
    [sessionsData],
  );

  const returnRadarAlerts = useMemo(
    () => aggregateReturnRadarAlerts(returnRadarPatientsData ?? []),
    [returnRadarPatientsData],
  );

  const handleRetry = () => {
    refetchProfile();
    refetchInsumos();
    refetchSessions();
    refetchReturnRadarPatients();
    refetchFeedback();
    refetchAccuracyRatings();
  };

  const openSubscriptionEditor = () => {
    setSubscriptionDraft(subscriptionValue != null ? String(subscriptionValue) : '');
    setEditingSubscription(true);
  };

  const handleSaveSubscription = async () => {
    if (!user) return;
    const value = Number(subscriptionDraft.replace(',', '.'));
    if (!Number.isFinite(value) || value < 0) {
      toast.error(t('panel.roi.invalidValue'));
      return;
    }
    setSavingSubscription(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ subscription_monthly_value: value })
        .eq('id', user.id);
      if (error) throw error;
      await queryClient.invalidateQueries({ queryKey: ['panel-profile', user.id] });
      setEditingSubscription(false);
      toast.success(t('panel.saved'));
    } catch (err: any) {
      toast.error(err.message || t('panel.roi.invalidValue'));
    } finally {
      setSavingSubscription(false);
    }
  };

  const openGoalEditor = () => {
    setGoalTargetDraft(goalTarget != null ? String(goalTarget) : '');
    setGoalPeriodDraft(goalPeriod);
    setEditingGoal(true);
  };

  const handleSaveGoal = async () => {
    if (!user) return;
    const target = Number(goalTargetDraft);
    if (!Number.isInteger(target) || target <= 0) {
      toast.error(t('panel.goal.invalidTarget'));
      return;
    }
    setSavingGoal(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ session_goal_target: target, session_goal_period: goalPeriodDraft })
        .eq('id', user.id);
      if (error) throw error;
      await queryClient.invalidateQueries({ queryKey: ['panel-profile', user.id] });
      setEditingGoal(false);
      toast.success(t('panel.saved'));
    } catch (err: any) {
      toast.error(err.message || t('panel.goal.invalidTarget'));
    } finally {
      setSavingGoal(false);
    }
  };

  return (
    <PageTransition>
      <AppLayout title={t('panel.title')} wide>
        <div
          role="tablist"
          aria-label={t('panel.title')}
          className="flex gap-1 bg-h-white rounded-full shadow-h-sm p-1 mb-4 overflow-x-auto"
        >
          {PANEL_TABS.map((tabKey) => (
            <button
              key={tabKey}
              role="tab"
              type="button"
              aria-selected={activeTab === tabKey}
              data-testid={`panel-tab-${tabKey}`}
              onClick={() => setActiveTab(tabKey)}
              className={`flex-1 min-w-[84px] py-2 px-2 text-[12px] font-semibold rounded-full whitespace-nowrap transition-all ${
                activeTab === tabKey ? 'bg-gradient-brand shadow-h-sm' : 'text-h-text-3'
              }`}
              style={activeTab === tabKey ? { color: '#fff' } : undefined}
            >
              {t(`panel.tabs.${tabKey}`)}
            </button>
          ))}
        </div>

        {activeTab === 'agenda' && <AgendaTab />}
        {activeTab === 'stock' && <EstoqueTab />}
        {activeTab === 'billing' && <FaturamentoTab />}

        {activeTab === 'overview' && (isLoading ? (
          <div className="flex flex-col gap-4">
            <SkeletonStats />
            <SkeletonCard lines={2} />
          </div>
        ) : hasError ? (
          <HCard className="flex flex-col items-center gap-2 text-center py-6">
            <p className="text-[13px] text-h-text-2">{t('panel.error.load')}</p>
            <button
              onClick={handleRetry}
              className="flex items-center gap-1.5 text-[12px] font-semibold press-scale"
              style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44 }}
            >
              <RefreshCw size={14} />
              {t('panel.error.retry')}
            </button>
          </HCard>
        ) : (
          // ── Dashboard de 2 colunas no desktop, 1 coluna no mobile ──
          // Mobile já tem as 3 outras abas (Agenda/Estoque/Faturamento) a um
          // toque de distância pela barra de pílulas acima — duplicar esses
          // widgets de vislumbre ali só pesaria a rolagem sem ganho real. No
          // desktop, que tem espaço de sobra (ver `wide` em AppLayout.tsx),
          // a coluna lateral mostra os 3 de uma vez, sem precisar trocar de
          // aba — pedido explícito do dono do produto de diferenciar
          // desktop/mobile em vez de só esticar o mesmo layout mobile.
          <div className="md:grid md:grid-cols-[1fr_320px] md:gap-5 md:items-start">
          <div className="flex flex-col gap-4">
            {/* ── Radar de Retorno: alerta agregado ── Card em destaque logo
                ao abrir o Painel (via proativa pedida pelo dono do produto,
                além do badge discreto que já existe em Pacientes.tsx) — só um
                resumo numérico; a lista de nomes e o botão de lembrete por
                paciente ficam em Pacientes.tsx. */}
            <HCard>
              <div className="flex items-center gap-2 mb-3">
                <BellRing size={16} style={{ color: '#A855B5' }} />
                <p className="text-[13px] font-semibold text-h-text">{t('panel.returnRadar.title')}</p>
              </div>
              {returnRadarAlerts.dueThisWeek === 0 && returnRadarAlerts.overdue === 0 ? (
                <p className="text-[13px] text-h-text-2">{t('panel.returnRadar.allCaughtUp')}</p>
              ) : (
                <div className="flex gap-3">
                  <div
                    className="flex-1 rounded-[12px] px-3 py-2.5 text-center"
                    style={{ background: 'rgba(168,85,181,0.10)' }}
                  >
                    <p className="text-[20px] font-extrabold" style={{ color: '#A855B5' }}>
                      {returnRadarAlerts.dueThisWeek}
                    </p>
                    <p className="text-[11px] text-h-text-2 mt-0.5">{t('panel.returnRadar.dueThisWeek')}</p>
                  </div>
                  <div
                    className="flex-1 rounded-[12px] px-3 py-2.5 text-center"
                    style={{ background: returnRadarAlerts.overdue > 0 ? 'rgba(224,80,80,0.10)' : 'rgba(0,0,0,0.04)' }}
                  >
                    <p
                      className="text-[20px] font-extrabold"
                      style={{ color: returnRadarAlerts.overdue > 0 ? '#E05050' : '#AAA8A5' }}
                    >
                      {returnRadarAlerts.overdue}
                    </p>
                    <p className="text-[11px] text-h-text-2 mt-0.5">{t('panel.returnRadar.overdue')}</p>
                  </div>
                </div>
              )}
            </HCard>

            {/* ── ROI da assinatura ── */}
            <HCard>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Wallet size={16} style={{ color: '#BF5F82' }} />
                  <p className="text-[13px] font-semibold text-h-text">{t('panel.roi.title')}</p>
                </div>
                <button
                  onClick={() => setValuesRevealed((v) => !v)}
                  className="flex items-center gap-1.5 press-scale"
                  style={{ color: '#BF5F82', background: 'none', border: 'none', cursor: 'pointer', minHeight: 44, fontSize: 12, fontWeight: 600 }}
                >
                  {valuesRevealed ? <EyeOff size={14} /> : <Eye size={14} />}
                  {valuesRevealed ? t('panel.roi.hide') : t('panel.roi.reveal')}
                </button>
              </div>

              {editingSubscription ? (
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    inputMode="decimal"
                    autoFocus
                    value={subscriptionDraft}
                    onChange={(e) => setSubscriptionDraft(e.target.value)}
                    placeholder="R$ 0,00"
                    aria-label={t('panel.roi.subscriptionInputLabel')}
                    className="flex-1 h-[40px] min-h-[44px] rounded-r-sm px-3 text-[13px] font-semibold text-h-text bg-h-surface outline-none focus:ring-2 focus:ring-h-g-mid/30"
                  />
                  <GradientButton
                    onClick={handleSaveSubscription}
                    disabled={savingSubscription}
                    className="!w-auto !h-auto !min-h-[44px] px-4 py-2 text-[13px]"
                  >
                    {savingSubscription ? t('panel.saving') : t('panel.roi.save')}
                  </GradientButton>
                </div>
              ) : subscriptionValue == null ? (
                <div className="flex flex-col gap-2">
                  <p className="text-[13px] text-h-text-2">{t('panel.roi.configurePrompt')}</p>
                  <button
                    onClick={openSubscriptionEditor}
                    style={{ color: '#BF5F82', background: 'none', border: 'none', fontSize: 13, fontWeight: 700, cursor: 'pointer', textAlign: 'left', minHeight: 44 }}
                  >
                    {t('panel.roi.configureCta')}
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <div className="flex items-baseline justify-between">
                    <span className="text-[12px] text-h-text-2">{t('panel.roi.potentialLabel')}</span>
                    <span className="text-[16px] font-extrabold text-h-text" style={{ letterSpacing: '-0.01em' }}>
                      {valuesRevealed ? formatCurrency(monthlyPotential) : '•••••'}
                    </span>
                  </div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-[12px] text-h-text-2">{t('panel.roi.subscriptionLabel')}</span>
                    <span className="text-[13px] font-semibold text-h-text-2">
                      {valuesRevealed ? formatCurrency(subscriptionValue) : '•••••'}
                    </span>
                  </div>

                  {roi.hasData && (
                    <div className="rounded-[12px] px-3 py-2.5 text-center" style={{ background: 'rgba(45,184,122,0.10)' }}>
                      <p className="text-[13px] font-bold" style={{ color: '#1D9A64' }}>
                        {valuesRevealed
                          ? t('panel.roi.multiple', { times: formatRoiMultiple(roi.multiple) })
                          : t('panel.roi.hiddenHint')}
                      </p>
                    </div>
                  )}

                  <button
                    onClick={openSubscriptionEditor}
                    className="flex items-center gap-1 self-start"
                    style={{ color: '#AAA8A5', background: 'none', border: 'none', fontSize: 11, fontWeight: 600, cursor: 'pointer', minHeight: 44 }}
                  >
                    <Pencil size={11} />
                    {t('panel.roi.edit')}
                  </button>
                </div>
              )}
            </HCard>

            {/* ── Meta de sessões ── */}
            <HCard>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Target size={16} style={{ color: '#7C5AC2' }} />
                  <p className="text-[13px] font-semibold text-h-text">{t('panel.goal.title')}</p>
                </div>
                {!editingGoal && (
                  <button
                    onClick={openGoalEditor}
                    className="flex items-center gap-1"
                    style={{ color: '#AAA8A5', background: 'none', border: 'none', fontSize: 11, fontWeight: 600, cursor: 'pointer', minHeight: 44 }}
                  >
                    <Pencil size={11} />
                    {goalTarget != null ? t('panel.goal.edit') : t('panel.goal.configureCta')}
                  </button>
                )}
              </div>

              {editingGoal ? (
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      step={1}
                      inputMode="numeric"
                      autoFocus
                      value={goalTargetDraft}
                      onChange={(e) => setGoalTargetDraft(e.target.value)}
                      placeholder="5"
                      aria-label={t('panel.goal.targetInputLabel')}
                      className="w-[80px] h-[40px] min-h-[44px] rounded-r-sm px-3 text-[13px] font-semibold text-h-text bg-h-surface outline-none focus:ring-2 focus:ring-h-g-mid/30"
                    />
                    <div className="flex gap-1.5 flex-1">
                      {(['weekly', 'monthly'] as const).map((p) => (
                        <button
                          key={p}
                          onClick={() => setGoalPeriodDraft(p)}
                          className="flex-1 h-[40px] min-h-[44px] rounded-r-sm text-[12px] font-semibold"
                          style={{
                            background: goalPeriodDraft === p ? 'rgba(124,90,194,0.12)' : 'rgba(0,0,0,0.04)',
                            color: goalPeriodDraft === p ? '#7C5AC2' : '#AAA8A5',
                            border: 'none',
                            cursor: 'pointer',
                          }}
                        >
                          {p === 'weekly' ? t('panel.goal.periodWeekly') : t('panel.goal.periodMonthly')}
                        </button>
                      ))}
                    </div>
                  </div>
                  <GradientButton onClick={handleSaveGoal} disabled={savingGoal}>
                    {savingGoal ? t('panel.saving') : t('panel.goal.save')}
                  </GradientButton>
                </div>
              ) : goalProgress == null ? (
                <p className="text-[13px] text-h-text-2">{t('panel.goal.configurePrompt')}</p>
              ) : (
                <div className="flex items-center gap-4">
                  <ProgressRing pct={goalProgress.pct} color={goalProgress.achieved ? '#2DB87A' : '#7C5AC2'}>
                    <span className="text-[15px] font-extrabold text-h-text">
                      {goalProgress.current}/{goalProgress.target}
                    </span>
                  </ProgressRing>
                  <div className="flex-1">
                    <p className="text-[12px] text-h-text-2 mb-1">
                      {goalPeriod === 'weekly' ? t('panel.goal.periodWeekly') : t('panel.goal.periodMonthly')}
                    </p>
                    {goalProgress.achieved ? (
                      <div className="flex items-center gap-1.5">
                        <Trophy size={14} style={{ color: '#2DB87A' }} />
                        <p className="text-[12.5px] font-bold" style={{ color: '#2DB87A' }}>
                          {t('panel.goal.achieved')}
                        </p>
                      </div>
                    ) : (
                      <p className="text-[12.5px] text-h-text-2">
                        {t('panel.goal.progress', { current: goalProgress.current, target: goalProgress.target })}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </HCard>

            {/* ── Comparativo de conversão vs. pares da mesma especialidade
                (get_professional_conversion_benchmark) ── só renderiza quando a
                RPC devolve um bucket; `null` (amostra insuficiente, sem
                especialidade cadastrada, sem sessão própria ou erro de rede)
                omite a seção inteira, sem placeholder de "sem dados" — nunca
                cita outro profissional nem mostra número exato, só o terço. */}
            {conversionBenchmarkBucket != null && (
              <HCard>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={16} style={{ color: '#1D9A64' }} />
                  <p className="text-[13px] font-semibold text-h-text">{t('panel.conversionBenchmark.title')}</p>
                </div>
                <p className="text-[13px] text-h-text-2">
                  {t(`panel.conversionBenchmark.${conversionBenchmarkBucket === 'top_third' ? 'topThird' : conversionBenchmarkBucket === 'middle_third' ? 'middleThird' : 'bottomThird'}`)}
                </p>
                <p className="text-[11px] text-h-text-3 mt-2">{t('panel.conversionBenchmark.disclaimer')}</p>
              </HCard>
            )}

            {/* ── Biblioteca de Antes/Depois para Redes Sociais (P3) ──
                Entrada pro squad de Marketing: lista só sessões concluídas de
                pacientes com consentimento de marketing explícito (ver
                src/pages/BibliotecaMarketing.tsx e o guardrail lá descrito). */}
            <HCard
              onClick={() => navigate('/painel/biblioteca-marketing')}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: 'rgba(168,85,181,0.10)' }}
                >
                  <Images size={16} style={{ color: '#A855B5' }} />
                </div>
                <div>
                  <p className="text-[13px] font-semibold text-h-text">{t('marketingLibrary.entryTitle')}</p>
                  <p className="text-[11px] text-h-text-3">{t('marketingLibrary.entrySubtitle')}</p>
                </div>
              </div>
              <ChevronRight size={16} style={{ color: '#AAA8A5' }} />
            </HCard>

            {/* ── Mini-site/Página de Captação por Profissional (P4) ──
                Entrada pro squad de Marketing/Vendas: link público /m/:slug
                com a mesma galeria de consentimento da Biblioteca acima +
                formulário de lead, e a lista de leads recebidos (ver
                src/pages/MeusLeads.tsx / src/pages/Minisite.tsx). */}
            <HCard onClick={() => navigate('/leads')} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: 'rgba(122,90,194,0.10)' }}
                >
                  <Link2 size={16} style={{ color: '#7C5AC2' }} />
                </div>
                <div>
                  <p className="text-[13px] font-semibold text-h-text">{t('leads.entryTitle')}</p>
                  <p className="text-[11px] text-h-text-3">{t('leads.entrySubtitle')}</p>
                </div>
              </div>
              <ChevronRight size={16} style={{ color: '#AAA8A5' }} />
            </HCard>

            {/* ── Sequência de dias ativos ── */}
            <HCard>
              <div className="flex items-center gap-3">
                <div
                  className="w-[44px] h-[44px] rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: streak > 0 ? 'rgba(217,119,6,0.12)' : 'rgba(0,0,0,0.04)' }}
                >
                  <Flame size={20} style={{ color: streak > 0 ? '#D97706' : '#AAA8A5' }} />
                </div>
                <div>
                  <p className="text-[18px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>
                    {t('panel.streak.days', { count: streak })}
                  </p>
                  <p className="text-[12px] text-h-text-2">
                    {streak > 0 ? t('panel.streak.messageActive') : t('panel.streak.messageStart')}
                  </p>
                </div>
              </div>
            </HCard>

            {/* ── NPS dos pacientes (Central de Depoimentos/NPS) ── */}
            <HCard>
              <div className="flex items-center gap-2 mb-3">
                <Star size={16} style={{ color: '#D4900A' }} />
                <p className="text-[13px] font-semibold text-h-text">{t('panel.nps.title')}</p>
              </div>
              {npsAverage == null ? (
                <p className="text-[13px] text-h-text-2">{t('panel.nps.empty')}</p>
              ) : (
                <div className="flex flex-col gap-1">
                  <p className="text-[20px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>
                    {t('panel.nps.average', { score: npsAverage.average.toFixed(1) })}
                  </p>
                  <p className="text-[12.5px] text-h-text-2">
                    {t('panel.nps.responseCount', { count: npsAverage.count })}
                  </p>
                </div>
              )}
            </HCard>

            {/* ── Índice de Precisão da Simulação (P4) ── */}
            <HCard>
              <div className="flex items-center gap-2 mb-3">
                <Gauge size={16} style={{ color: '#7C5AC2' }} />
                <p className="text-[13px] font-semibold text-h-text">{t('panel.simulationAccuracy.title')}</p>
              </div>
              {simulationAccuracyStats == null ? (
                <p className="text-[13px] text-h-text-2">{t('panel.simulationAccuracy.empty')}</p>
              ) : (
                <div className="flex flex-col gap-1">
                  <p className="text-[20px] font-extrabold text-h-text" style={{ letterSpacing: '-0.02em' }}>
                    {t('panel.simulationAccuracy.average', { score: simulationAccuracyStats.average.toFixed(1) })}
                  </p>
                  <p className="text-[12.5px] text-h-text-2">
                    {t('panel.simulationAccuracy.goodMatch', { pct: Math.round(simulationAccuracyStats.goodMatchPercentage) })}
                  </p>
                  <p className="text-[12.5px] text-h-text-2">
                    {t('panel.simulationAccuracy.responseCount', { count: simulationAccuracyStats.count })}
                  </p>
                  <p className="text-[11px] text-h-text-3 mt-1">{t('panel.simulationAccuracy.disclaimer')}</p>
                </div>
              )}
            </HCard>
          </div>

          {/* ── Coluna lateral: só desktop (`hidden md:flex`) ── vislumbre
              de Agenda/Estoque/Faturamento sem trocar de aba. Cada widget
              compartilha a MESMA queryKey da aba completa correspondente
              (ver comentário em cada arquivo), então não duplica leitura
              de rede — só um resumo renderizado a partir do mesmo cache. */}
          <div className="hidden md:flex md:flex-col md:gap-4">
            <AgendaOverviewWidget onOpenAgenda={() => setActiveTab('agenda')} />
            <EstoqueOverviewWidget onOpenEstoque={() => setActiveTab('stock')} />
            <FaturamentoOverviewWidget onOpenFaturamento={() => setActiveTab('billing')} />
          </div>
          </div>
        ))}
      </AppLayout>
    </PageTransition>
  );
};

export default Painel;
