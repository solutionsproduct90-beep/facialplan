import React, { useState } from 'react';
import PageTransition from '@/components/harmonize/PageTransition';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/harmonize/AppLayout';
import PatientCard from '@/components/harmonize/PatientCard';
import PullToRefresh from '@/components/harmonize/PullToRefresh';
import GradientButton from '@/components/harmonize/GradientButton';
import GhostButton from '@/components/harmonize/GhostButton';
import { SkeletonCard } from '@/components/harmonize/Skeletons';
import { Search, Plus, UserPlus, MessageCircle, Copy } from 'lucide-react';
import { differenceInDays } from 'date-fns';
import { returnRadarForSessions } from '@/lib/returnRadar';
import {
  isPatientStalled,
  buildReactivationWhatsAppLink,
  buildReturnRadarReminderWhatsAppLink,
  STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS,
  STALLED_PATIENT_THRESHOLD_OPTIONS_DAYS,
} from '@/lib/patientReactivation';
import { computePatientAbandonmentRisk, type PatientAbandonmentRiskLevel } from '@/lib/patientAbandonmentRisk';
import { fetchAllRows } from '@/lib/fetchAllRows';
import HarmonizeBadge from '@/components/harmonize/Badge';

// Badge visual do Score de Risco de Abandono (src/lib/patientAbandonmentRisk.ts)
// — reaproveita as mesmas 3 cores de prioridade já usadas em outras telas do
// app (HarmonizeBadge 'alta'/'media'/'baixa', ver AdminAuditoria.tsx/
// AdminErros.tsx) em vez de inventar uma paleta nova só para este badge.
const RISK_BADGE_VARIANT: Record<PatientAbandonmentRiskLevel, 'alta' | 'media' | 'baixa'> = {
  alto: 'alta',
  medio: 'media',
  baixo: 'baixa',
};

const Pacientes: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const [search, setSearch] = useState('');
  const [showStalledOnly, setShowStalledOnly] = useState(false);
  const [thresholdDays, setThresholdDays] = useState(STALLED_PATIENT_DEFAULT_THRESHOLD_DAYS);

  const { data: patients, isLoading } = useQuery({
    queryKey: ['patients', user?.id],
    queryFn: () =>
      // Paginado (ver src/lib/fetchAllRows.ts): o PostgREST trunca no teto de
      // linhas por resposta (Max Rows, 1000 por padrão) em silêncio, com
      // `error: null`. Um profissional com mais de 1000 pacientes veria
      // pacientes simplesmente desaparecerem da lista, da busca e do contador
      // do chip de segmentação, sem nenhum aviso.
      fetchAllRows((from, to) =>
        supabase
          .from('patients')
          .select('*, sessions(id, created_at, status, stage2_overlay)')
          .eq('professional_id', user!.id)
          .eq('is_deleted', false)
          .order('created_at', { ascending: false })
          .range(from, to),
      ),
    enabled: !!user,
  });

  // Nota de feedback/NPS mais recente por paciente (Central de Depoimentos,
  // ver src/lib/patientAbandonmentRisk.ts) — alimenta o Score de Risco de
  // Abandono abaixo. Reaproveita a mesma tabela/coluna já lida em Painel.tsx
  // (`patient_feedback.nps_score`), só que agrupada por paciente em vez de
  // uma média geral; nenhuma tabela/RPC nova precisou ser criada pra isso.
  const { data: feedbackRows } = useQuery({
    queryKey: ['patients-latest-feedback', user?.id],
    queryFn: () =>
      // Paginado, e aqui o truncamento silencioso do PostgREST não deixaria a
      // tela incompleta — deixaria o Score de Risco de Abandono ERRADO. Este
      // histórico não tem corte por data (diferente de Painel.tsx, que lê
      // `patient_feedback` só dos últimos 90 dias): passando de 1000 linhas,
      // o Supabase devolve apenas as mais novas, e um paciente cujo último
      // feedback seja mais antigo que a 1000ª linha some do Map abaixo. O
      // score então trata um promotor (nota 9-10, contribuição 0) ou um
      // detrator (nota <= 6, contribuição 2) como "sem feedback" (0.5).
      // Achado do ciclo 90 do QA Contínuo; mesma classe do ciclo 86.
      fetchAllRows((from, to) =>
        supabase
          .from('patient_feedback')
          .select('patient_id, nps_score, created_at')
          .eq('professional_id', user!.id)
          .order('created_at', { ascending: false })
          .range(from, to),
      ),
    enabled: !!user,
  });

  // `feedbackRows` já vem ordenado por `created_at` desc, então a primeira
  // ocorrência de cada `patient_id` é a mais recente — sem precisar de outro
  // sort por paciente.
  const latestNpsByPatientId = new Map<string, number>();
  for (const row of feedbackRows ?? []) {
    if (!latestNpsByPatientId.has(row.patient_id)) {
      latestNpsByPatientId.set(row.patient_id, row.nps_score);
    }
  }

  // Enriquece cada paciente com os dados da sessão mais recente, a flag de
  // "parado" (ver src/lib/patientReactivation.ts) e o Score de Risco de
  // Abandono (src/lib/patientAbandonmentRisk.ts, combina o atraso do Radar
  // de Retorno com a nota de feedback mais recente) antes de aplicar busca e
  // filtro — assim o contador do chip de segmentação reflete todos os
  // pacientes do profissional, não só os que sobrevivem à busca por nome.
  const withMeta = (patients ?? []).map((p: any) => {
    const lastSession = p.sessions?.slice().sort((a: any, b: any) =>
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    )[0];
    const returnRadar = returnRadarForSessions(p.sessions);
    return {
      ...p,
      sessionCount: p.sessions?.length ?? 0,
      lastSessionDaysAgo: lastSession ? differenceInDays(new Date(), new Date(lastSession.created_at)) : null,
      stalled: isPatientStalled(lastSession?.created_at ?? null, new Date(), thresholdDays),
      returnRadar,
      // `recentNoShowCount` fica de fora aqui de propósito: a Agenda
      // (`appointments`) ainda não distingue falta de cancelamento avisado
      // (ver comentário de arquivo em patientAbandonmentRisk.ts) — o score
      // já funciona corretamente sem esse sinal, e passa a somá-lo sozinho
      // no dia em que existir uma fonte real pra ele.
      risk: computePatientAbandonmentRisk({
        returnRadar,
        latestFeedbackNpsScore: latestNpsByPatientId.get(p.id) ?? null,
      }),
    };
  });

  const stalledCount = withMeta.filter((p) => p.stalled).length;

  const filtered = withMeta.filter((p) => {
    if (!p.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (showStalledOnly && !p.stalled) return false;
    return true;
  });

  // Prioriza a lista de pacientes parados pelo Score de Risco de Abandono
  // (maior primeiro) — só reordena quando o filtro de segmentação está
  // ativo; a lista geral de pacientes continua na ordem original (mais
  // recentes primeiro) pra não mudar um comportamento que nada tem a ver com
  // reativação. `[...filtered]` porque `.sort` muta o array in-place.
  const displayedPatients = showStalledOnly
    ? [...filtered].sort((a, b) => b.risk.score - a.risk.score)
    : filtered;

  const handleCopyAllReactivationLinks = async () => {
    const links = displayedPatients
      .filter((p) => p.stalled)
      .map((p) => buildReactivationWhatsAppLink(
        p.phone,
        t('patients.list.stalled.whatsAppMessage', { name: p.name.split(' ')[0] })
      ));
    if (links.length === 0) return;
    try {
      await navigator.clipboard.writeText(links.join('\n\n'));
      toast.success(t('patients.list.stalled.copyAllSuccess', { count: links.length }));
    } catch {
      toast.error(t('patients.list.stalled.copyAllError'));
    }
  };

    return (
    <PageTransition>
    <AppLayout
      title={t('nav.patients')}
      rightAction={
        // BUG CORRIGIDO: era um link de texto rosa (`text-h-g-start`) sem
        // fundo — a única forma de criar um paciente a partir desta tela
        // além do estado vazio, quase invisível no header. Ver mesmo
        // padrão já corrigido em HeaderSaveButton (Perfil).
        <GhostButton
          onClick={() => navigate('/pacientes/novo')}
          className="!w-auto !h-auto !min-h-[44px] px-3 py-2 text-[13px] flex items-center gap-1"
        >
          <Plus size={16} />
          <span>{t('patients.list.newButton')}</span>
        </GhostButton>
      }
    >
      <PullToRefresh onRefresh={async () => {
        await queryClient.invalidateQueries({ queryKey: ['patients'] });
      }}>
      <div className="flex flex-col gap-4">
        {/* Search */}
        <div className="relative">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-h-text-3" />
          <input
            type="text"
            placeholder={t('patients.list.searchPlaceholder')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-[44px] rounded-full bg-h-white pl-10 pr-4 text-[14px] text-h-text shadow-h-sm outline-none placeholder:text-h-text-3 focus:ring-2 focus:ring-h-g-mid/20"
          />
        </div>

        {/* Segmentação: pacientes parados (ver src/lib/patientReactivation.ts) */}
        <div className="flex flex-wrap items-center gap-2 px-1">
          <button
            type="button"
            onClick={() => setShowStalledOnly((v) => !v)}
            className="h-[34px] px-3 rounded-full text-[12px] font-bold transition-colors press-scale"
            style={showStalledOnly
              ? { background: '#BF5F82', color: '#fff' }
              : { background: '#fff', color: '#8A8783', boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}
          >
            {t('patients.list.stalled.filterLabel')}
            {stalledCount > 0 && ` · ${stalledCount}`}
          </button>
          {showStalledOnly && (
            <select
              value={thresholdDays}
              onChange={(e) => setThresholdDays(Number(e.target.value))}
              className="h-[34px] px-2 rounded-full bg-h-white text-[12px] text-h-text-2 shadow-h-sm outline-none"
              aria-label={t('patients.list.stalled.thresholdLabel')}
            >
              {STALLED_PATIENT_THRESHOLD_OPTIONS_DAYS.map((days) => (
                <option key={days} value={days}>
                  {t('patients.list.stalled.thresholdOption', { count: days })}
                </option>
              ))}
            </select>
          )}
          {showStalledOnly && displayedPatients.length > 0 && (
            <button
              type="button"
              onClick={handleCopyAllReactivationLinks}
              className="h-[34px] px-3 rounded-full text-[12px] font-bold flex items-center gap-1.5 press-scale"
              style={{ background: 'rgba(191,95,130,0.10)', color: '#BF5F82' }}
            >
              <Copy size={13} />
              {t('patients.list.stalled.copyAllButton')}
            </button>
          )}
        </div>

        {/* Count */}
        <p className="text-[13px] text-h-text-2 font-medium px-1">
          {isLoading ? t('patients.list.loading') : t('patients.list.count', { count: displayedPatients.length })}
        </p>

        {/* List */}
        {isLoading ? (
          <div className="flex flex-col gap-2">
            {[1, 2, 3].map(i => <SkeletonCard key={i} />)}
          </div>
        ) : displayedPatients.length > 0 ? (
          <div className="bg-h-white rounded-[16px] shadow-h-sm overflow-hidden">
            {displayedPatients.map((patient: any, index: number) => {
              const returnRadar = patient.returnRadar;

              return (
                <React.Fragment key={patient.id}>
                  <PatientCard
                    id={patient.id}
                    name={patient.name}
                    sessionCount={patient.sessionCount}
                    lastSessionDaysAgo={patient.lastSessionDaysAgo}
                    returnRadar={returnRadar}
                  />
                  {showStalledOnly && patient.stalled && (
                    // Ação de reativação fora do <button> do PatientCard (que
                    // ocupa a linha inteira e navega para o detalhe) — um botão
                    // dentro de outro botão seria HTML inválido e sofreria com o
                    // clique borbulhando pra navegação. O badge de Score de
                    // Risco de Abandono (src/lib/patientAbandonmentRisk.ts) vai
                    // ao lado do botão de reativação: é justamente esta lista
                    // que ele prioriza (ver `displayedPatients` acima).
                    <div className="px-4 pb-3 -mt-2 flex items-center justify-end gap-2">
                      <HarmonizeBadge variant={RISK_BADGE_VARIANT[patient.risk.level as PatientAbandonmentRiskLevel]}>
                        {t(`patients.list.stalled.risk.${patient.risk.level}`)}
                      </HarmonizeBadge>
                      <button
                        type="button"
                        onClick={() => window.open(
                          buildReactivationWhatsAppLink(
                            patient.phone,
                            t('patients.list.stalled.whatsAppMessage', { name: patient.name.split(' ')[0] })
                          ),
                          '_blank'
                        )}
                        className="h-[30px] px-3 rounded-full text-[12px] font-bold flex items-center gap-1.5 press-scale"
                        style={{ background: 'rgba(37,211,102,0.12)', color: '#1DA851' }}
                      >
                        <MessageCircle size={13} />
                        {t('patients.list.stalled.reactivateButton')}
                      </button>
                    </div>
                  )}
                  {returnRadar && (
                    // Ação rápida do Radar de Retorno (ver src/lib/returnRadar.ts)
                    // — pedido explícito do dono do produto por uma via mais
                    // proativa além do badge acima: um botão que já monta a
                    // mensagem de retorno pro paciente, com o texto/cor variando
                    // conforme `isOverdue` (mesmo par de estados do badge do
                    // PatientCard). Mesmo padrão de "botão fora do <button> do
                    // card" do bloco de reativação acima, e mesma reaproveitação
                    // do mecanismo de link `wa.me` (buildReactivationWhatsAppLink,
                    // por trás de buildReturnRadarReminderWhatsAppLink).
                    <div className="px-4 pb-3 -mt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={() => window.open(
                          buildReturnRadarReminderWhatsAppLink(patient.phone, returnRadar.isOverdue, {
                            upcoming: t('patients.list.returnRadar.whatsAppMessageUpcoming', { name: patient.name.split(' ')[0] }),
                            overdue: t('patients.list.returnRadar.whatsAppMessageOverdue', { name: patient.name.split(' ')[0] }),
                          }),
                          '_blank'
                        )}
                        className="h-[30px] px-3 rounded-full text-[12px] font-bold flex items-center gap-1.5 press-scale"
                        style={returnRadar.isOverdue
                          ? { background: 'rgba(224,80,80,0.12)', color: '#E05050' }
                          : { background: 'rgba(168,85,181,0.12)', color: '#A855B5' }}
                      >
                        <MessageCircle size={13} />
                        {t('patients.list.returnRadar.reminderButton')}
                      </button>
                    </div>
                  )}
                  {index < displayedPatients.length - 1 && (
                    <div style={{ height: 0.5, background: '#E5E3E0', marginLeft: 62 }} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center py-10 text-center gap-3">
            <UserPlus size={28} style={{ color: '#AAA8A5' }} />
            <p style={{ fontSize: 14, fontWeight: 600, color: '#AAA8A5' }}>
              {search
                ? t('patients.list.emptySearchTitle')
                : showStalledOnly
                  ? t('patients.list.stalled.empty')
                  : t('patients.list.emptyNoneTitle')}
            </p>
            <p style={{ fontSize: 12, fontWeight: 400, color: '#C5C3C0' }}>
              {search
                ? t('patients.list.emptySearchHint')
                : showStalledOnly
                  ? t('patients.list.stalled.emptyHint', { days: thresholdDays })
                  : t('patients.list.emptyNoneHint')}
            </p>
            {!search && !showStalledOnly && (
              <button
                onClick={() => navigate('/pacientes/novo')}
                style={{ marginTop: 8, padding: '10px 20px', borderRadius: 980, background: 'rgba(191,95,130,0.10)', color: '#BF5F82', fontSize: 13, fontWeight: 700, border: 'none', cursor: 'pointer' }}
              >
                + {t('patients.list.addPatient')}
              </button>
            )}
          </div>
        )}
      </div>
      </PullToRefresh>
    </AppLayout>
    </PageTransition>
  );
};

export default Pacientes;
