import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import DepoimentoPublico from './DepoimentoPublico';
import i18n from '@/i18n';

/**
 * The public page talks to the `public-patient-feedback` edge function by
 * plain `fetch` (not the authenticated `supabase` client — see the comment
 * at the top of DepoimentoPublico.tsx), same technique as
 * SessaoPresentPublico.test.tsx, so the double here is `global.fetch`.
 */
function jsonResponse(body: unknown) {
  return Promise.resolve({ ok: true, json: () => Promise.resolve(body) } as Response);
}

const VALID_TOKEN = '8ce48925-2a03-4b67-b118-e17df300570a';

const renderAt = (path: string) =>
  render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/feedback/:token" element={<DepoimentoPublico />} />
      </Routes>
    </MemoryRouter>
  );

describe('DepoimentoPublico', () => {
  beforeEach(async () => {
    await i18n.changeLanguage('pt');
    vi.stubGlobal('fetch', vi.fn());
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('shows the invalid-link state without calling the backend for a malformed token', async () => {
    renderAt('/feedback/not-a-real-token');

    expect(await screen.findByText('Link indisponível')).toBeInTheDocument();
    expect(fetch).not.toHaveBeenCalled();
  });

  it('shows the invalid-link state for a well-formed but unknown token', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: 'not_found' }));

    renderAt(`/feedback/${VALID_TOKEN}`);

    expect(await screen.findByText('Link indisponível')).toBeInTheDocument();
    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining(`token=${VALID_TOKEN}`),
      expect.any(Object)
    );
  });

  it('shows the already-answered state for a used token', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: false, reason: 'used' }));

    renderAt(`/feedback/${VALID_TOKEN}`);

    expect(await screen.findByText('Avaliação já enviada')).toBeInTheDocument();
  });

  it('shows the invalid-link state when the request itself fails', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('network down'));

    renderAt(`/feedback/${VALID_TOKEN}`);

    expect(await screen.findByText('Link indisponível')).toBeInTheDocument();
  });

  it('renders the score scale and greets the patient by first name', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(
      jsonResponse({ valid: true, patientFirstName: 'Maria', clinicName: 'Clínica Bela Face' })
    );

    renderAt(`/feedback/${VALID_TOKEN}`);

    await waitFor(() => expect(screen.getByText(/Maria/)).toBeInTheDocument());
    expect(screen.getByText('Clínica Bela Face', { exact: false })).toBeInTheDocument();
    expect(screen.getByRole('radio', { name: '0' })).toBeInTheDocument();
    expect(screen.getByRole('radio', { name: '10' })).toBeInTheDocument();
  });

  it('keeps the submit button disabled until a score is picked', async () => {
    (fetch as ReturnType<typeof vi.fn>).mockReturnValueOnce(jsonResponse({ valid: true, patientFirstName: null, clinicName: null }));

    renderAt(`/feedback/${VALID_TOKEN}`);

    const submit = await screen.findByRole('button', { name: 'Enviar avaliação' });
    expect(submit).toBeDisabled();
  });

  it('submits the chosen score and comment, then shows the success state', async () => {
    (fetch as ReturnType<typeof vi.fn>)
      .mockReturnValueOnce(jsonResponse({ valid: true, patientFirstName: 'Maria', clinicName: null }))
      .mockReturnValueOnce(jsonResponse({ success: true }));

    renderAt(`/feedback/${VALID_TOKEN}`);

    const scoreButton = await screen.findByRole('radio', { name: '9' });
    fireEvent.click(scoreButton);

    const submit = screen.getByRole('button', { name: 'Enviar avaliação' });
    expect(submit).not.toBeDisabled();
    fireEvent.click(submit);

    expect(await screen.findByText('Obrigado pela sua avaliação!')).toBeInTheDocument();

    const postCall = (fetch as ReturnType<typeof vi.fn>).mock.calls[1];
    expect(postCall[0]).toContain('public-patient-feedback');
    const body = JSON.parse(postCall[1].body as string);
    expect(body).toMatchObject({ token: VALID_TOKEN, npsScore: 9 });
  });

  it('shows a generic error when the submission itself fails', async () => {
    (fetch as ReturnType<typeof vi.fn>)
      .mockReturnValueOnce(jsonResponse({ valid: true, patientFirstName: null, clinicName: null }))
      .mockRejectedValueOnce(new Error('network down'));

    renderAt(`/feedback/${VALID_TOKEN}`);

    const scoreButton = await screen.findByRole('radio', { name: '5' });
    fireEvent.click(scoreButton);
    fireEvent.click(screen.getByRole('button', { name: 'Enviar avaliação' }));

    expect(await screen.findByText(/Não foi possível enviar/)).toBeInTheDocument();
  });
});
