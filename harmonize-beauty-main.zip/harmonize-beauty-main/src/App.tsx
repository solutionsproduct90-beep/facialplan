import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/harmonize/ProtectedRoute";
import RootRoute from "@/components/harmonize/RootRoute";
import LocalizedPage from "@/components/harmonize/LocalizedPage";
import ErrorBoundary from "@/components/harmonize/ErrorBoundary";
import OfflineBanner from "@/components/harmonize/OfflineBanner";
import FullScreenLoader from "@/components/harmonize/FullScreenLoader";

// CARREGAMENTO SOB DEMANDA DAS ROTAS
//
// Antes deste ponto todas as páginas eram importadas estaticamente, o que
// punha o app inteiro num único chunk: quem abria a landing pública baixava
// 2.960 KB (872 KB com gzip) contendo o painel administrativo, as telas de
// paciente, os gráficos do recharts e o cliente do Supabase — telas que
// aquele visitante nunca ia ver. O peso não atrasava o primeiro paint (as
// páginas institucionais são pré-renderizadas em HTML estático), mas atrasava
// a interatividade e queimava dado de quem abre no 4G da clínica.
//
// `lazy` faz o Rollup emitir um chunk por rota. Duas exceções ficam
// estáticas de propósito:
//
//   - RootRoute (e com ela LandingPage): é o primeiro paint de "/" pra quem
//     não tem sessão. Carregar sob demanda a página mais importante do funil
//     acrescentaria uma viagem de rede exatamente onde ela custa mais.
//   - NotFound: é o fallback "*", alcançável de qualquer lugar, e é pequena.
//
// Não há risco de divergência de hidratação aqui porque src/main.tsx usa
// `createRoot().render()`, não `hydrateRoot()` — o HTML pré-renderizado é
// substituído na montagem, não reaproveitado. E o pré-render (scripts/
// prerender.mjs + src/entry-server.tsx) importa as páginas do site direto,
// sem passar por este arquivo: `renderToString` não renderiza `lazy`, e é
// justamente por isso que ele nunca dependeu daqui.
const Recursos = lazy(() => import("./pages/site/Recursos"));
const Precos = lazy(() => import("./pages/site/Precos"));
const Sobre = lazy(() => import("./pages/site/Sobre"));
const Blog = lazy(() => import("./pages/site/Blog"));
const BlogPost = lazy(() => import("./pages/site/BlogPost"));
const Login = lazy(() => import("./pages/auth/Login"));
const Cadastro = lazy(() => import("./pages/auth/Cadastro"));
const ResetSenha = lazy(() => import("./pages/auth/ResetSenha"));
const ResetPassword = lazy(() => import("./pages/auth/ResetPassword"));
const Verificar = lazy(() => import("./pages/auth/Verificar"));
const Home = lazy(() => import("./pages/Home"));
const Pacientes = lazy(() => import("./pages/Pacientes"));
const NovoPaciente = lazy(() => import("./pages/NovoPaciente"));
const PacienteDetalhe = lazy(() => import("./pages/PacienteDetalhe"));
const EditarPaciente = lazy(() => import("./pages/EditarPaciente"));
const Sessoes = lazy(() => import("./pages/Sessoes"));
const Agenda = lazy(() => import("./pages/Agenda"));
const Painel = lazy(() => import("./pages/Painel"));
const BibliotecaMarketing = lazy(() => import("./pages/BibliotecaMarketing"));
const NovaSessao = lazy(() => import("./pages/NovaSessao"));
const SessaoEstagio1 = lazy(() => import("./pages/SessaoEstagio1"));
const SessaoTriagemPele = lazy(() => import("./pages/SessaoTriagemPele"));
const SessaoEstagio2 = lazy(() => import("./pages/SessaoEstagio2"));
const SessaoEstagio3 = lazy(() => import("./pages/SessaoEstagio3"));
const SessaoPresent = lazy(() => import("./pages/SessaoPresent"));
const SessaoPresentPublico = lazy(() => import("./pages/SessaoPresentPublico"));
const Perfil = lazy(() => import("./pages/Perfil"));
const PerfilAnamnese = lazy(() => import("./pages/PerfilAnamnese"));
const PerfilInsumos = lazy(() => import("./pages/PerfilInsumos"));
const PerfilPagamento = lazy(() => import("./pages/PerfilPagamento"));
const Conta = lazy(() => import("./pages/Conta"));
const Assinar = lazy(() => import("./pages/Assinar"));
const ContaBloqueada = lazy(() => import("./pages/ContaBloqueada"));
const Regularizar = lazy(() => import("./pages/Regularizar"));
const Privacidade = lazy(() => import("./pages/Privacidade"));
const Termos = lazy(() => import("./pages/Termos"));
const AnamneseCompartilhada = lazy(() => import("./pages/AnamneseCompartilhada"));
const DepoimentoPublico = lazy(() => import("./pages/DepoimentoPublico"));
const Minisite = lazy(() => import("./pages/Minisite"));
const MeusLeads = lazy(() => import("./pages/MeusLeads"));
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const AdminUsuarios = lazy(() => import("./pages/admin/AdminUsuarios"));
const AdminUsuarioDetalhe = lazy(() => import("./pages/admin/AdminUsuarioDetalhe"));
const AdminErros = lazy(() => import("./pages/admin/AdminErros"));
const AdminMetricas = lazy(() => import("./pages/admin/AdminMetricas"));
const AdminAuditoria = lazy(() => import("./pages/admin/AdminAuditoria"));
const AdminInteligencia = lazy(() => import("./pages/admin/AdminInteligencia"));
const AdminComprasPendentes = lazy(() => import("./pages/admin/AdminComprasPendentes"));

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const AppRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      {/* O Suspense fica DENTRO do AnimatePresence: a troca de rota que
          precisa baixar um chunk mostra a marca carregando no lugar da
          página, e não uma tela branca. */}
      <Suspense fallback={<FullScreenLoader />}>
        <Routes location={location} key={location.pathname}>
          {/* Public routes */}
          <Route path="/auth/login" element={<Login />} />
          <Route path="/auth/cadastro" element={<Cadastro />} />
          <Route path="/auth/reset-senha" element={<ResetSenha />} />
          <Route path="/auth/verificar" element={<Verificar />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/assinar" element={<Assinar />} />
          <Route path="/conta-bloqueada" element={<ContaBloqueada />} />
          <Route path="/regularizar" element={<Regularizar />} />
          <Route path="/privacidade" element={<Privacidade />} />
          <Route path="/termos" element={<Termos />} />
          <Route path="/anamnese/:token" element={<AnamneseCompartilhada />} />
          <Route path="/present/:token" element={<SessaoPresentPublico />} />
          <Route path="/feedback/:token" element={<DepoimentoPublico />} />
          <Route path="/m/:slug" element={<Minisite />} />
          <Route path="/recursos" element={<Recursos />} />
          <Route path="/precos" element={<Precos />} />
          <Route path="/sobre" element={<Sobre />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />

          {/* Variantes com prefixo de idioma (hoje só /es — LATAM, mercado
              prioritário) das mesmas 5 páginas acima. LocalizedPage valida o
              :lang e cai no 404 pra qualquer prefixo que não exista em
              PREFIXED_LOCALES (src/lib/siteLocale.ts). */}
          <Route path="/:lang/recursos" element={<LocalizedPage><Recursos /></LocalizedPage>} />
          <Route path="/:lang/precos" element={<LocalizedPage><Precos /></LocalizedPage>} />
          <Route path="/:lang/sobre" element={<LocalizedPage><Sobre /></LocalizedPage>} />
          <Route path="/:lang/blog" element={<LocalizedPage><Blog /></LocalizedPage>} />
          <Route path="/:lang/blog/:slug" element={<LocalizedPage><BlogPost /></LocalizedPage>} />

          {/* "/" é SEMPRE a landing institucional pública, mesmo pra quem já
              está logado (padrão de raiz de marketing separada do app — ver
              RootRoute.tsx) — quem tem sessão é redirecionado pra "/inicio". */}
          <Route path="/" element={<RootRoute />} />
          {/* Home nos idiomas prefixados ("/es", "/en"). Sem esta rota, o
              logo do header e o seletor de idioma em qualquer página /es/*
              apontavam pra "/es", que caía no 404. Rotas estáticas (como
              "/inicio") têm prioridade sobre ":lang" no react-router, e
              LocalizedPage manda qualquer segmento que não seja idioma pro
              mesmo NotFound de antes. */}
          <Route path="/:lang" element={<LocalizedPage><RootRoute /></LocalizedPage>} />

          {/* Protected routes */}
          <Route path="/inicio" element={<ProtectedRoute><Home /></ProtectedRoute>} />
          <Route path="/pacientes" element={<ProtectedRoute><Pacientes /></ProtectedRoute>} />
          <Route path="/pacientes/novo" element={<ProtectedRoute><NovoPaciente /></ProtectedRoute>} />
          <Route path="/pacientes/:id" element={<ProtectedRoute><PacienteDetalhe /></ProtectedRoute>} />
          <Route path="/pacientes/:id/editar" element={<ProtectedRoute><EditarPaciente /></ProtectedRoute>} />
          <Route path="/sessoes" element={<ProtectedRoute><Sessoes /></ProtectedRoute>} />
          <Route path="/agenda" element={<ProtectedRoute><Agenda /></ProtectedRoute>} />
          <Route path="/painel" element={<ProtectedRoute><Painel /></ProtectedRoute>} />
          <Route path="/painel/biblioteca-marketing" element={<ProtectedRoute><BibliotecaMarketing /></ProtectedRoute>} />
          <Route path="/leads" element={<ProtectedRoute><MeusLeads /></ProtectedRoute>} />
          <Route path="/sessoes/nova" element={<ProtectedRoute><NovaSessao /></ProtectedRoute>} />
          <Route path="/sessoes/:id/estagio-1" element={<ProtectedRoute><SessaoEstagio1 /></ProtectedRoute>} />
          <Route path="/sessoes/:id/triagem-pele" element={<ProtectedRoute><SessaoTriagemPele /></ProtectedRoute>} />
          <Route path="/sessoes/:id/estagio-2" element={<ProtectedRoute><SessaoEstagio2 /></ProtectedRoute>} />
          <Route path="/sessoes/:id/estagio-3" element={<ProtectedRoute><SessaoEstagio3 /></ProtectedRoute>} />
          <Route path="/sessoes/:id/present" element={<ProtectedRoute><SessaoPresent /></ProtectedRoute>} />
          <Route path="/perfil" element={<ProtectedRoute><Perfil /></ProtectedRoute>} />
          <Route path="/perfil/anamnese" element={<ProtectedRoute><PerfilAnamnese /></ProtectedRoute>} />
          <Route path="/perfil/insumos" element={<ProtectedRoute><PerfilInsumos /></ProtectedRoute>} />
          <Route path="/perfil/pagamento" element={<ProtectedRoute><PerfilPagamento /></ProtectedRoute>} />
          <Route path="/conta" element={<ProtectedRoute><Conta /></ProtectedRoute>} />
          <Route path="/admin" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/usuarios" element={<ProtectedRoute><AdminUsuarios /></ProtectedRoute>} />
          <Route path="/admin/usuarios/:id" element={<ProtectedRoute><AdminUsuarioDetalhe /></ProtectedRoute>} />
          <Route path="/admin/erros" element={<ProtectedRoute><AdminErros /></ProtectedRoute>} />
          <Route path="/admin/metricas" element={<ProtectedRoute><AdminMetricas /></ProtectedRoute>} />
          <Route path="/admin/auditoria" element={<ProtectedRoute><AdminAuditoria /></ProtectedRoute>} />
          <Route path="/admin/inteligencia" element={<ProtectedRoute><AdminInteligencia /></ProtectedRoute>} />
          <Route path="/admin/compras-pendentes" element={<ProtectedRoute><AdminComprasPendentes /></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </AnimatePresence>
  );
};

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <OfflineBanner />
        <Toaster
          position="top-center"
          toastOptions={{
            style: {
              fontFamily: "'Plus Jakarta Sans', -apple-system, sans-serif",
              fontSize: 14,
              fontWeight: 600,
              borderRadius: 12,
              background: '#1A1918',
              color: '#FFFFFF',
              border: 'none',
              boxShadow: '0 8px 32px rgba(0,0,0,0.20)',
            },
          }}
          // A TopBar fixa tem calc(56px + safe-area-inset-top) de altura em mobile; em
          // telas md: (com DesktopNav de 64px acima dela) a faixa fixa do header vai até
          // 120px (ver o mesmo cálculo em AppLayout: md:pt-[120px]). Um offset menor que
          // isso faz o toast nascer POR CIMA do header, sobrepondo botões clicáveis (ex.
          // "Salvar" em rightAction) — o toast fica com pointer-events ativo ali,
          // bloqueando o clique. Pior: se o pointerdown do usuário acontece sobre essa
          // área sobreposta mas o pointerup termina fora dela (ex. o usuário desiste do
          // clique e vai digitar em um input), o listener interno do sonner que pausa o
          // auto-dismiss durante interação (onPointerDown/onPointerUp no container do
          // toast) nunca recebe o "up" — o toast fica marcado como "interacting" pra
          // sempre e nunca mais some sozinho. Manter o offset sempre >= altura real do
          // header (em cada breakpoint) elimina os dois sintomas na raiz, sem depender de
          // duration/richColors. mobileOffset cobre <600px (só TopBar); offset cobre
          // >=600px, com folga suficiente pra também limpar a DesktopNav em telas md:.
          offset={{ top: 'calc(120px + env(safe-area-inset-top, 0px) + 12px)' }}
          mobileOffset={{ top: 'calc(56px + env(safe-area-inset-top, 0px) + 12px)' }}
        />
        <AuthProvider>
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
