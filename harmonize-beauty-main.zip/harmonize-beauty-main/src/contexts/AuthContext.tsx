import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

// Recorte de profiles usado só pra decidir acesso (ProtectedRoute). Carregado
// e cacheado aqui, num único lugar, pra quem precisar checar bloqueio/
// assinatura reusar em vez de disparar sua própria query em profiles.
export interface AccessProfile {
  is_blocked: boolean | null;
  subscription_status: string | null;
  role: string | null;
  // Timestamp de quando subscription_status entrou em 'past_due' pela
  // primeira vez desde a última vez 'active' — usado só por ProtectedRoute
  // pra calcular a carência antes do bloqueio (ver GRACE_PERIOD_DAYS lá).
  past_due_since: string | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  profile: AccessProfile | null;
  profileLoading: boolean;
  /**
   * Relê `profiles` do banco para o usuário logado, descartando o valor em
   * cache. Resolve quando o perfil novo chegou (ou a leitura falhou), então
   * dá para aguardar antes de decidir o que mostrar.
   *
   * POR QUE EXISTE: o perfil é carregado UMA vez por `user.id` (ver o efeito
   * abaixo), o que é certo para o uso normal — mas erra exatamente no momento
   * em que o profissional volta do checkout da Hotmart. Ele pagou, o webhook
   * já virou `subscription_status` para 'active' no banco, e o app continua
   * mostrando o paywall porque está lendo o perfil de antes da compra. Sem
   * uma forma de reler, a única saída é recarregar a página inteira — que é
   * o que o cliente faz depois de achar que o pagamento não funcionou.
   *
   * Devolve o perfil lido (ou null se falhou/não há usuário) para quem
   * precisa decidir na hora, sem esperar o próximo render.
   */
  refreshProfile: () => Promise<AccessProfile | null>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  loading: true,
  profile: null,
  profileLoading: true,
  refreshProfile: async () => null,
  signOut: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<AccessProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Carrega is_blocked/subscription_status uma vez por usuário logado (não a
  // cada evento de auth — a dependência é o id, não o objeto `user`, que
  // troca de referência em todo onAuthStateChange, inclusive em refresh de
  // token). ProtectedRoute consome esse valor em vez de repetir a query.
  //
  // Achado do QA Contínuo (ciclo 37, P0): `loading` PRECISA estar nas
  // dependências e ser checado ANTES de `!user` — sem isso, no efeito que
  // roda junto com a montagem (user ainda null, loading ainda true, porque o
  // outro efeito não teve chance de resolver getSession()/onAuthStateChange
  // ainda), o ramo `if (!user)` já zerava profileLoading pra false. Quando o
  // usuário real chegava um instante depois (setUser + setLoading(false) do
  // outro efeito, num único batch), o React comitava um render intermediário
  // com user já verdadeiro mas profileLoading ainda com aquele `false`
  // obsoleto — ProtectedRoute via `loading || (user && profileLoading)` como
  // falso e decidia acesso com `profile` ainda `null`, mandando até
  // profissional com assinatura ATIVA (ou admin) pro paywall só por carregar
  // uma rota protegida diretamente. Não decidir nada enquanto `loading` for
  // `true` fecha essa janela: só existem dois casos possíveis quando este
  // efeito roda com `loading = false` — sabidamente sem usuário, ou já com o
  // usuário definitivo — nunca mais o "ainda não sei" travestido de "sem
  // usuário".
  // Contador de geração: toda leitura de perfil recebe um número, e só a de
  // número mais alto pode escrever o estado. Substitui o antigo booleano
  // `cancelled` local do efeito porque agora há DUAS origens de leitura — o
  // efeito e o refreshProfile manual — e um `cancelled` por efeito não
  // ordena as duas entre si. Sem isso, um refresh disparado logo após uma
  // troca de usuário poderia gravar o perfil do usuário anterior.
  const profileRequestRef = useRef(0);

  const loadProfile = useCallback(async (userId: string): Promise<AccessProfile | null> => {
    const requestId = ++profileRequestRef.current;
    setProfileLoading(true);

    const { data, error } = await supabase
      .from('profiles')
      .select('is_blocked, subscription_status, role, past_due_since')
      .eq('id', userId)
      .single();

    // Chegou tarde: outra leitura mais recente já começou (ou já terminou).
    // Descarta em silêncio, sem tocar no estado nem no profileLoading — quem
    // veio depois é quem manda.
    if (requestId !== profileRequestRef.current) return null;

    // Falha ao carregar o perfil (rede, RLS, etc.) não deve travar o usuário
    // fora do app inteiro — trata como "sem restrição conhecida" e segue; o
    // restante do app já lida com erros de rede.
    const next = error ? null : (data as AccessProfile | null);
    setProfile(next);
    setProfileLoading(false);
    return next;
  }, []);

  const refreshProfile = useCallback(async (): Promise<AccessProfile | null> => {
    const userId = user?.id;
    if (!userId) return null;
    return await loadProfile(userId);
  }, [user?.id, loadProfile]);

  useEffect(() => {
    if (loading) {
      return;
    }

    if (!user) {
      // Também invalida qualquer leitura em voo: sem isso, uma resposta de
      // perfil pendente do usuário que acabou de sair poderia repovoar o
      // estado depois do logout.
      profileRequestRef.current += 1;
      setProfile(null);
      setProfileLoading(false);
      return;
    }

    void loadProfile(user.id);
  }, [user?.id, loading, loadProfile]);

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, profile, profileLoading, refreshProfile, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};
