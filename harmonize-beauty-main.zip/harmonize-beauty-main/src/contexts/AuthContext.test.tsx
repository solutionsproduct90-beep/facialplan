import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, act } from "@testing-library/react";
import { AuthProvider, useAuth } from "./AuthContext";

const unsubscribeMock = vi.fn();
const onAuthStateChangeMock = vi.fn();
const getSessionMock = vi.fn();
const signOutMock = vi.fn();

// profiles query chain: supabase.from('profiles').select(...).eq(...).single()
const singleMock = vi.fn();
const eqMock = vi.fn(() => ({ single: singleMock }));
const selectMock = vi.fn(() => ({ eq: eqMock }));
const fromMock = vi.fn((..._args: unknown[]) => ({ select: selectMock }));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      onAuthStateChange: (...args: unknown[]) => onAuthStateChangeMock(...args),
      getSession: (...args: unknown[]) => getSessionMock(...args),
      signOut: (...args: unknown[]) => signOutMock(...args),
    },
    from: (...args: unknown[]) => fromMock(...args),
  },
}));

const makeSession = (overrides: Partial<{ id: string }> = {}) => ({
  access_token: "token",
  user: { id: overrides.id ?? "user-1", email: "user@example.com" },
});

// Test consumer that surfaces the context values for assertions.
const Consumer: React.FC = () => {
  const { user, session, loading, profile, profileLoading, signOut } = useAuth();
  return (
    <div>
      <span data-testid="loading">{String(loading)}</span>
      <span data-testid="user-id">{user?.id ?? "none"}</span>
      <span data-testid="session">{session ? "present" : "none"}</span>
      <span data-testid="profile-loading">{String(profileLoading)}</span>
      <span data-testid="profile-blocked">{String(profile?.is_blocked ?? "none")}</span>
      <span data-testid="profile-status">{profile?.subscription_status ?? "none"}</span>
      <button onClick={() => void signOut()}>sign out</button>
    </div>
  );
};

describe("AuthContext", () => {
  let authChangeCallback: (event: string, session: unknown) => void;

  beforeEach(() => {
    vi.clearAllMocks();
    authChangeCallback = () => {};
    onAuthStateChangeMock.mockImplementation((cb: (event: string, session: unknown) => void) => {
      authChangeCallback = cb;
      return { data: { subscription: { unsubscribe: unsubscribeMock } } };
    });
    getSessionMock.mockResolvedValue({ data: { session: null } });
    // Default: a freshly created profile — not blocked, default subscription
    // status. Individual tests override this with mockResolvedValueOnce.
    singleMock.mockResolvedValue({
      data: { is_blocked: false, subscription_status: "inactive" },
      error: null,
    });
  });

  it("useAuth outside a provider falls back to the default context (not authenticated, loading)", () => {
    render(<Consumer />);
    expect(screen.getByTestId("loading").textContent).toBe("true");
    expect(screen.getByTestId("user-id").textContent).toBe("none");
  });

  it("starts in a loading state with no user or session", () => {
    // Never resolve getSession during this assertion window.
    getSessionMock.mockReturnValue(new Promise(() => {}));
    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );
    expect(screen.getByTestId("loading").textContent).toBe("true");
    expect(screen.getByTestId("user-id").textContent).toBe("none");
    expect(screen.getByTestId("session").textContent).toBe("none");
  });

  it("stops loading and exposes the session once getSession resolves", async () => {
    const session = makeSession({ id: "abc-123" });
    getSessionMock.mockResolvedValue({ data: { session } });

    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    await waitFor(() => expect(screen.getByTestId("loading").textContent).toBe("false"));
    expect(screen.getByTestId("user-id").textContent).toBe("abc-123");
    expect(screen.getByTestId("session").textContent).toBe("present");
  });

  it("has no profile and is not profileLoading when no user is signed in", async () => {
    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    await waitFor(() => expect(screen.getByTestId("loading").textContent).toBe("false"));
    expect(screen.getByTestId("profile-loading").textContent).toBe("false");
    expect(screen.getByTestId("profile-blocked").textContent).toBe("none");
    expect(fromMock).not.toHaveBeenCalled();
  });

  it("loads is_blocked/subscription_status from profiles for the signed-in user", async () => {
    singleMock.mockResolvedValue({
      data: { is_blocked: true, subscription_status: "past_due" },
      error: null,
    });
    const session = makeSession({ id: "abc-123" });
    getSessionMock.mockResolvedValue({ data: { session } });

    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    // Espera a sessão real resolver primeiro, por clareza de sequência do
    // teste (não é mais um workaround de corrida — ver ciclo 37 abaixo, a
    // corrida que motivava este comentário foi corrigida na origem).
    await waitFor(() => expect(screen.getByTestId("user-id").textContent).toBe("abc-123"));
    await waitFor(() => expect(screen.getByTestId("profile-loading").textContent).toBe("false"));
    expect(fromMock).toHaveBeenCalledWith("profiles");
    expect(eqMock).toHaveBeenCalledWith("id", "abc-123");
    expect(screen.getByTestId("profile-blocked").textContent).toBe("true");
    expect(screen.getByTestId("profile-status").textContent).toBe("past_due");
  });

  it("treats a failed profile fetch as 'no known restriction' instead of blocking the whole app", async () => {
    singleMock.mockResolvedValue({ data: null, error: { message: "network error" } });
    const session = makeSession({ id: "abc-123" });
    getSessionMock.mockResolvedValue({ data: { session } });

    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    await waitFor(() => expect(screen.getByTestId("profile-loading").textContent).toBe("false"));
    expect(screen.getByTestId("profile-blocked").textContent).toBe("none");
    expect(screen.getByTestId("profile-status").textContent).toBe("none");
  });

  it("updates user and session when the auth state changes (e.g. sign in)", async () => {
    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    await waitFor(() => expect(screen.getByTestId("loading").textContent).toBe("false"));
    expect(screen.getByTestId("user-id").textContent).toBe("none");

    const session = makeSession({ id: "new-user" });
    act(() => {
      authChangeCallback("SIGNED_IN", session);
    });

    await waitFor(() => expect(screen.getByTestId("user-id").textContent).toBe("new-user"));
    expect(screen.getByTestId("session").textContent).toBe("present");
    await waitFor(() => expect(screen.getByTestId("profile-loading").textContent).toBe("false"));
  });

  it("clears user, session and profile on sign out event", async () => {
    const session = makeSession();
    getSessionMock.mockResolvedValue({ data: { session } });

    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    await waitFor(() => expect(screen.getByTestId("user-id").textContent).toBe("user-1"));
    await waitFor(() => expect(screen.getByTestId("profile-loading").textContent).toBe("false"));

    act(() => {
      authChangeCallback("SIGNED_OUT", null);
    });

    await waitFor(() => expect(screen.getByTestId("user-id").textContent).toBe("none"));
    expect(screen.getByTestId("session").textContent).toBe("none");
    expect(screen.getByTestId("profile-blocked").textContent).toBe("none");
  });

  it("calls supabase.auth.signOut when signOut is invoked", async () => {
    signOutMock.mockResolvedValue({ error: null });
    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );
    await waitFor(() => expect(screen.getByTestId("loading").textContent).toBe("false"));

    screen.getByText("sign out").click();

    await waitFor(() => expect(signOutMock).toHaveBeenCalledTimes(1));
  });

  it("never commits a render with a signed-in user, loading=false and profileLoading=false before the profile actually resolves (ciclo 37 regression: this used to send active/admin professionals to the paywall on a direct page load)", async () => {
    // Atraso artificial em AMBAS as etapas assíncronas (resolução da sessão e
    // fetch do perfil), pra dar tempo real de um render intermediário
    // acontecer entre elas — sem isso, com tudo resolvendo síncrono/imediato
    // nos outros testes deste arquivo, o bug do ciclo 37 nunca teria uma
    // janela de render pra se manifestar mesmo sem o fix.
    const session = makeSession({ id: "abc-123" });
    getSessionMock.mockImplementation(
      () => new Promise((resolve) => setTimeout(() => resolve({ data: { session } }), 5))
    );
    singleMock.mockImplementation(
      () =>
        new Promise((resolve) =>
          setTimeout(
            () => resolve({ data: { is_blocked: false, subscription_status: "active", role: "professional" }, error: null }),
            20
          )
        )
    );

    const snapshots: Array<{ user: string; loading: boolean; profileLoading: boolean; status: string }> = [];
    const Probe: React.FC = () => {
      const { user, loading, profile, profileLoading } = useAuth();
      snapshots.push({
        user: user?.id ?? "none",
        loading,
        profileLoading,
        status: profile?.subscription_status ?? "none",
      });
      return null;
    };

    render(
      <AuthProvider>
        <Probe />
      </AuthProvider>
    );

    await waitFor(() => expect(snapshots[snapshots.length - 1].status).toBe("active"));

    // Esta é exatamente a combinação que ProtectedRoute.tsx usa pra decidir
    // se já pode avaliar as regras de acesso (`loading || (user &&
    // profileLoading)` sendo falso libera a decisão) — com usuário logado,
    // se essa combinação aparecer com profile ainda não carregado, o
    // ProtectedRoute decide acesso com `profile = null` e manda pro paywall
    // mesmo quem tem assinatura ativa.
    const unsafeRender = snapshots.find(
      (s) => s.user !== "none" && !s.loading && !s.profileLoading && s.status === "none"
    );
    expect(unsafeRender).toBeUndefined();
  });

  it("refreshProfile relê o perfil do banco e devolve o valor novo — o caso da volta do checkout da Hotmart", async () => {
    // Cenário real: o profissional abre o app sem assinatura, vai pagar na
    // Hotmart, o webhook vira subscription_status pra 'active' no banco, e ele
    // volta. Sem reler, o app segue mostrando o paywall com o perfil de antes
    // da compra — e o cliente conclui que o pagamento não funcionou.
    singleMock.mockResolvedValueOnce({
      data: { is_blocked: false, subscription_status: "inactive", role: "professional" },
      error: null,
    });
    const session = makeSession({ id: "abc-123" });
    getSessionMock.mockResolvedValue({ data: { session } });

    let refresh: (() => Promise<unknown>) | null = null;
    const Probe: React.FC = () => {
      const ctx = useAuth();
      refresh = ctx.refreshProfile;
      return <span data-testid="status">{ctx.profile?.subscription_status ?? "none"}</span>;
    };

    render(
      <AuthProvider>
        <Probe />
      </AuthProvider>
    );

    await waitFor(() => expect(screen.getByTestId("status").textContent).toBe("inactive"));

    // Agora o banco já reflete o pagamento.
    singleMock.mockResolvedValue({
      data: { is_blocked: false, subscription_status: "active", role: "professional" },
      error: null,
    });

    let devolvido: unknown;
    await act(async () => {
      devolvido = await refresh!();
    });

    await waitFor(() => expect(screen.getByTestId("status").textContent).toBe("active"));
    // Devolve o perfil lido, pra quem chamou poder decidir na hora sem
    // esperar o próximo render.
    expect(devolvido).toMatchObject({ subscription_status: "active" });
  });

  it("refreshProfile sem usuário logado devolve null e não consulta o banco", async () => {
    let refresh: (() => Promise<unknown>) | null = null;
    const Probe: React.FC = () => {
      refresh = useAuth().refreshProfile;
      return null;
    };

    render(
      <AuthProvider>
        <Probe />
      </AuthProvider>
    );

    await waitFor(() => expect(refresh).not.toBeNull());
    fromMock.mockClear();

    let devolvido: unknown = "não chamado";
    await act(async () => {
      devolvido = await refresh!();
    });

    expect(devolvido).toBeNull();
    expect(fromMock).not.toHaveBeenCalled();
  });

  it("uma leitura de perfil que chega atrasada nunca sobrescreve uma mais recente", async () => {
    // Há DUAS origens de leitura agora (o efeito de montagem e o
    // refreshProfile manual), então um booleano de cancelamento por efeito
    // não ordena as duas entre si. Aqui a primeira leitura demora 40ms e a
    // segunda 5ms: se a ordenação por geração não existisse, a resposta velha
    // chegaria por último e venceria.
    const session = makeSession({ id: "abc-123" });
    getSessionMock.mockResolvedValue({ data: { session } });

    singleMock.mockImplementationOnce(
      () =>
        new Promise((resolve) =>
          setTimeout(() => resolve({ data: { is_blocked: false, subscription_status: "inactive" }, error: null }), 40)
        )
    );
    singleMock.mockImplementationOnce(
      () =>
        new Promise((resolve) =>
          setTimeout(() => resolve({ data: { is_blocked: false, subscription_status: "active" }, error: null }), 5)
        )
    );

    let refresh: (() => Promise<unknown>) | null = null;
    const Probe: React.FC = () => {
      const ctx = useAuth();
      refresh = ctx.refreshProfile;
      return <span data-testid="status">{ctx.profile?.subscription_status ?? "none"}</span>;
    };

    render(
      <AuthProvider>
        <Probe />
      </AuthProvider>
    );

    await waitFor(() => expect(refresh).not.toBeNull());
    await act(async () => {
      void refresh!();
      await new Promise((r) => setTimeout(r, 80));
    });

    // 'active' é a leitura mais recente, mesmo tendo sido disparada depois e
    // resolvido antes da outra.
    expect(screen.getByTestId("status").textContent).toBe("active");
  });

  it("unsubscribes from the auth listener on unmount", async () => {
    const { unmount } = render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );
    await waitFor(() => expect(screen.getByTestId("loading").textContent).toBe("false"));

    unmount();
    expect(unsubscribeMock).toHaveBeenCalledTimes(1);
  });
});
