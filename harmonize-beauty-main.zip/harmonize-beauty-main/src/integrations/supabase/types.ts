export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      anamnesis: {
        Row: {
          consent_data_processing_at: string | null
          created_at: string
          discromia: string[] | null
          filled_by: string
          id: string
          main_complaint: string | null
          oiliness: string | null
          patient_id: string
          photo_url: string | null
          professional_id: string
          reviewed_at: string | null
          risk_flags: Json
          skin_texture: string | null
          skin_type: string | null
          updated_at: string
          vascularization: string[] | null
        }
        Insert: {
          consent_data_processing_at?: string | null
          created_at?: string
          discromia?: string[] | null
          filled_by: string
          id?: string
          main_complaint?: string | null
          oiliness?: string | null
          patient_id: string
          photo_url?: string | null
          professional_id: string
          reviewed_at?: string | null
          risk_flags?: Json
          skin_texture?: string | null
          skin_type?: string | null
          updated_at?: string
          vascularization?: string[] | null
        }
        Update: {
          consent_data_processing_at?: string | null
          created_at?: string
          discromia?: string[] | null
          filled_by?: string
          id?: string
          main_complaint?: string | null
          oiliness?: string | null
          patient_id?: string
          photo_url?: string | null
          professional_id?: string
          reviewed_at?: string | null
          risk_flags?: Json
          skin_texture?: string | null
          skin_type?: string | null
          updated_at?: string
          vascularization?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "anamnesis_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: true
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "anamnesis_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      anamnesis_links: {
        Row: {
          created_at: string
          expires_at: string
          patient_id: string
          professional_id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          expires_at: string
          patient_id: string
          professional_id: string
          token?: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string
          patient_id?: string
          professional_id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "anamnesis_links_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "anamnesis_links_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          actor_id: string
          created_at: string
          id: string
          patient_id: string | null
          resource_id: string
          resource_type: string
        }
        Insert: {
          action: string
          actor_id: string
          created_at?: string
          id?: string
          patient_id?: string | null
          resource_id: string
          resource_type: string
        }
        Update: {
          action?: string
          actor_id?: string
          created_at?: string
          id?: string
          patient_id?: string | null
          resource_id?: string
          resource_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "audit_log_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      anamnesis_question_settings: {
        Row: {
          created_at: string
          enabled: boolean
          id: string
          professional_id: string
          question_key: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: string
          professional_id: string
          question_key: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: string
          professional_id?: string
          question_key?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "anamnesis_question_settings_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      ops_alert_state: {
        Row: {
          alert_key: string
          alerts_sent: number
          last_run_at: string
          last_seen_at: string
        }
        Insert: {
          alert_key: string
          alerts_sent?: number
          last_run_at?: string
          last_seen_at: string
        }
        Update: {
          alert_key?: string
          alerts_sent?: number
          last_run_at?: string
          last_seen_at?: string
        }
        Relationships: []
      }
      edge_rate_limits: {
        Row: {
          bucket: string
          request_count: number
          window_started_at: string
        }
        Insert: {
          bucket: string
          request_count?: number
          window_started_at?: string
        }
        Update: {
          bucket?: string
          request_count?: number
          window_started_at?: string
        }
        Relationships: []
      }
      error_logs: {
        Row: {
          created_at: string | null
          error_type: string
          id: string
          message: string | null
          professional_id: string | null
          session_id: string | null
          stage: string | null
        }
        Insert: {
          created_at?: string | null
          error_type: string
          id?: string
          message?: string | null
          professional_id?: string | null
          session_id?: string | null
          stage?: string | null
        }
        Update: {
          created_at?: string | null
          error_type?: string
          id?: string
          message?: string | null
          professional_id?: string | null
          session_id?: string | null
          stage?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "error_logs_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "error_logs_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      consents: {
        Row: {
          consent_text: string | null
          consent_type: string
          consent_version: string | null
          created_at: string | null
          id: string
          ip_address: string | null
          patient_id: string
          procedure_id: string | null
          procedure_summary: Json | null
          professional_id: string
          session_id: string | null
          signer_name: string | null
        }
        Insert: {
          consent_text?: string | null
          consent_type?: string
          consent_version?: string | null
          created_at?: string | null
          id?: string
          ip_address?: string | null
          patient_id: string
          procedure_id?: string | null
          procedure_summary?: Json | null
          professional_id: string
          session_id?: string | null
          signer_name?: string | null
        }
        Update: {
          consent_text?: string | null
          consent_type?: string
          consent_version?: string | null
          created_at?: string | null
          id?: string
          ip_address?: string | null
          patient_id?: string
          procedure_id?: string | null
          procedure_summary?: Json | null
          professional_id?: string
          session_id?: string | null
          signer_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "consents_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "consents_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "consents_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      appointments: {
        Row: {
          created_at: string
          duration_minutes: number | null
          id: string
          note: string | null
          patient_id: string | null
          professional_id: string
          scheduled_at: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          duration_minutes?: number | null
          id?: string
          note?: string | null
          patient_id?: string | null
          professional_id: string
          scheduled_at: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          duration_minutes?: number | null
          id?: string
          note?: string | null
          patient_id?: string | null
          professional_id?: string
          scheduled_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointments_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      appointment_waitlist: {
        Row: {
          created_at: string
          desired_end_date: string
          desired_start_date: string
          id: string
          patient_id: string
          professional_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          desired_end_date: string
          desired_start_date: string
          id?: string
          patient_id: string
          professional_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          desired_end_date?: string
          desired_start_date?: string
          id?: string
          patient_id?: string
          professional_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointment_waitlist_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointment_waitlist_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      treatment_plans: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          patient_id: string
          professional_id: string
          start_date: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          patient_id: string
          professional_id: string
          start_date?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          patient_id?: string
          professional_id?: string
          start_date?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "treatment_plans_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "treatment_plans_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      treatment_plan_steps: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          offset_days: number
          plan_id: string
          professional_id: string
          session_id: string | null
          status: string
          step_order: number
          substance: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          offset_days?: number
          plan_id: string
          professional_id: string
          session_id?: string | null
          status?: string
          step_order?: number
          substance: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          offset_days?: number
          plan_id?: string
          professional_id?: string
          session_id?: string | null
          status?: string
          step_order?: number
          substance?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "treatment_plan_steps_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "treatment_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "treatment_plan_steps_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "treatment_plan_steps_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      adverse_events: {
        Row: {
          created_at: string
          description: string
          event_type: string
          id: string
          insumo_id: string | null
          occurred_at: string
          patient_id: string | null
          professional_id: string
          session_id: string | null
          severity: string
        }
        Insert: {
          created_at?: string
          description: string
          event_type: string
          id?: string
          insumo_id?: string | null
          occurred_at?: string
          patient_id?: string | null
          professional_id: string
          session_id?: string | null
          severity: string
        }
        Update: {
          created_at?: string
          description?: string
          event_type?: string
          id?: string
          insumo_id?: string | null
          occurred_at?: string
          patient_id?: string | null
          professional_id?: string
          session_id?: string | null
          severity?: string
        }
        Relationships: [
          {
            foreignKeyName: "adverse_events_insumo_id_fkey"
            columns: ["insumo_id"]
            isOneToOne: false
            referencedRelation: "insumos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "adverse_events_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "adverse_events_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "adverse_events_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      insumos: {
        Row: {
          active: boolean
          brand_name: string
          concentration: string | null
          cost_per_unit: number
          created_at: string
          expires_on: string | null
          id: string
          low_stock_threshold: number | null
          price_per_unit: number
          professional_id: string
          quantity_on_hand: number
          substance: string
          thread_length_mm: number | null
          thread_type: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          brand_name: string
          concentration?: string | null
          cost_per_unit: number
          created_at?: string
          expires_on?: string | null
          id?: string
          low_stock_threshold?: number | null
          price_per_unit: number
          professional_id: string
          quantity_on_hand?: number
          substance: string
          thread_length_mm?: number | null
          thread_type?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          brand_name?: string
          concentration?: string | null
          cost_per_unit?: number
          created_at?: string
          expires_on?: string | null
          id?: string
          low_stock_threshold?: number | null
          price_per_unit?: number
          professional_id?: string
          quantity_on_hand?: number
          substance?: string
          thread_length_mm?: number | null
          thread_type?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "insumos_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      insumo_stock_movements: {
        Row: {
          batch_id: string | null
          created_at: string
          id: string
          insumo_id: string
          note: string | null
          professional_id: string
          quantity_delta: number
          session_id: string | null
        }
        Insert: {
          batch_id?: string | null
          created_at?: string
          id?: string
          insumo_id: string
          note?: string | null
          professional_id: string
          quantity_delta: number
          session_id?: string | null
        }
        Update: {
          batch_id?: string | null
          created_at?: string
          id?: string
          insumo_id?: string
          note?: string | null
          professional_id?: string
          quantity_delta?: number
          session_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insumo_stock_movements_insumo_id_fkey"
            columns: ["insumo_id"]
            isOneToOne: false
            referencedRelation: "insumos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insumo_stock_movements_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insumo_stock_movements_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "insumo_stock_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insumo_stock_movements_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      insumo_stock_batches: {
        Row: {
          batch_number: string
          created_at: string
          expires_on: string | null
          id: string
          insumo_id: string
          professional_id: string
          quantity_received: number
          quantity_remaining: number
          received_on: string
        }
        Insert: {
          batch_number: string
          created_at?: string
          expires_on?: string | null
          id?: string
          insumo_id: string
          professional_id: string
          quantity_received: number
          quantity_remaining?: number
          received_on?: string
        }
        Update: {
          batch_number?: string
          created_at?: string
          expires_on?: string | null
          id?: string
          insumo_id?: string
          professional_id?: string
          quantity_received?: number
          quantity_remaining?: number
          received_on?: string
        }
        Relationships: [
          {
            foreignKeyName: "insumo_stock_batches_insumo_id_fkey"
            columns: ["insumo_id"]
            isOneToOne: false
            referencedRelation: "insumos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insumo_stock_batches_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      patients: {
        Row: {
          ai_improvement_consent: boolean
          ai_improvement_consent_at: string | null
          birth_date: string | null
          consent_given: boolean | null
          created_at: string | null
          deleted_at: string | null
          email: string | null
          id: string
          is_deleted: boolean | null
          last_consent_at: string | null
          marketing_consent: boolean
          name: string
          notes: string | null
          phone: string | null
          professional_id: string
          referral_code: string
          referred_by_patient_id: string | null
        }
        Insert: {
          ai_improvement_consent?: boolean
          ai_improvement_consent_at?: string | null
          birth_date?: string | null
          consent_given?: boolean | null
          created_at?: string | null
          deleted_at?: string | null
          email?: string | null
          id?: string
          is_deleted?: boolean | null
          last_consent_at?: string | null
          marketing_consent?: boolean
          name: string
          notes?: string | null
          phone?: string | null
          professional_id: string
          referral_code?: string
          referred_by_patient_id?: string | null
        }
        Update: {
          ai_improvement_consent?: boolean
          ai_improvement_consent_at?: string | null
          birth_date?: string | null
          consent_given?: boolean | null
          created_at?: string | null
          deleted_at?: string | null
          email?: string | null
          id?: string
          is_deleted?: boolean | null
          last_consent_at?: string | null
          marketing_consent?: boolean
          name?: string
          notes?: string | null
          phone?: string | null
          professional_id?: string
          referral_code?: string
          referred_by_patient_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patients_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patients_referred_by_patient_id_fkey"
            columns: ["referred_by_patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          cash_discount_pct: number | null
          clinic_name: string | null
          council_number: string | null
          council_type: string | null
          country: string | null
          created_at: string | null
          currency: string
          email: string | null
          full_name: string | null
          hotmart_subscriber_code: string | null
          id: string
          is_blocked: boolean | null
          labor_fee_per_session: number | null
          logo_url: string | null
          max_installments: number | null
          minisite_slug: string | null
          onboarding_completed_at: string | null
          past_due_since: string | null
          phone: string | null
          pre_post_care_instructions: string | null
          role: string | null
          session_goal_period: string | null
          session_goal_target: number | null
          specialty: string | null
          stripe_customer_id: string | null
          subscription_monthly_value: number | null
          subscription_provider: string | null
          subscription_status: string | null
          subscription_updated_at: string | null
        }
        Insert: {
          cash_discount_pct?: number | null
          clinic_name?: string | null
          council_number?: string | null
          council_type?: string | null
          country?: string | null
          created_at?: string | null
          currency?: string
          email?: string | null
          full_name?: string | null
          hotmart_subscriber_code?: string | null
          id: string
          is_blocked?: boolean | null
          labor_fee_per_session?: number | null
          logo_url?: string | null
          max_installments?: number | null
          minisite_slug?: string | null
          onboarding_completed_at?: string | null
          past_due_since?: string | null
          phone?: string | null
          pre_post_care_instructions?: string | null
          role?: string | null
          session_goal_period?: string | null
          session_goal_target?: number | null
          specialty?: string | null
          stripe_customer_id?: string | null
          subscription_monthly_value?: number | null
          subscription_provider?: string | null
          subscription_status?: string | null
          subscription_updated_at?: string | null
        }
        Update: {
          cash_discount_pct?: number | null
          clinic_name?: string | null
          council_number?: string | null
          council_type?: string | null
          country?: string | null
          created_at?: string | null
          currency?: string
          email?: string | null
          full_name?: string | null
          hotmart_subscriber_code?: string | null
          id?: string
          is_blocked?: boolean | null
          labor_fee_per_session?: number | null
          logo_url?: string | null
          max_installments?: number | null
          minisite_slug?: string | null
          onboarding_completed_at?: string | null
          past_due_since?: string | null
          phone?: string | null
          pre_post_care_instructions?: string | null
          role?: string | null
          session_goal_period?: string | null
          session_goal_target?: number | null
          specialty?: string | null
          stripe_customer_id?: string | null
          subscription_monthly_value?: number | null
          subscription_provider?: string | null
          subscription_status?: string | null
          subscription_updated_at?: string | null
        }
        Relationships: []
      }
      marketing_leads: {
        Row: {
          contact: string
          created_at: string
          id: string
          message: string | null
          minisite_slug: string | null
          name: string
          professional_id: string
        }
        Insert: {
          contact: string
          created_at?: string
          id?: string
          message?: string | null
          minisite_slug?: string | null
          name: string
          professional_id: string
        }
        Update: {
          contact?: string
          created_at?: string
          id?: string
          message?: string | null
          minisite_slug?: string | null
          name?: string
          professional_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "marketing_leads_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      session_present_links: {
        Row: {
          access_count: number
          created_at: string | null
          last_accessed_at: string | null
          professional_id: string
          revoked_at: string | null
          session_id: string
          token: string
        }
        Insert: {
          access_count?: number
          created_at?: string | null
          last_accessed_at?: string | null
          professional_id: string
          revoked_at?: string | null
          session_id: string
          token?: string
        }
        Update: {
          access_count?: number
          created_at?: string | null
          last_accessed_at?: string | null
          professional_id?: string
          revoked_at?: string | null
          session_id?: string
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_present_links_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_present_links_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          p256dh: string
          professional_id: string
          user_agent: string | null
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh: string
          professional_id: string
          user_agent?: string | null
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh?: string
          professional_id?: string
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "push_subscriptions_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_feedback: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          nps_score: number
          patient_id: string
          professional_id: string
          session_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          nps_score: number
          patient_id: string
          professional_id: string
          session_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          nps_score?: number
          patient_id?: string
          professional_id?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "patient_feedback_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_feedback_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_feedback_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      patient_feedback_links: {
        Row: {
          created_at: string
          professional_id: string
          session_id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          professional_id: string
          session_id: string
          token?: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          professional_id?: string
          session_id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "patient_feedback_links_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "patient_feedback_links_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      sessions: {
        Row: {
          cost_estimate: Json | null
          created_at: string | null
          id: string
          last_active_at: string | null
          oblique_left_image_url: string | null
          oblique_right_image_url: string | null
          original_image_url: string | null
          overlay_image_url: string | null
          paid_at: string | null
          patient_id: string
          payment_amount_cents: number | null
          payment_currency: string | null
          payment_status: string | null
          pdf_url: string | null
          professional_id: string
          profile_image_url: string | null
          reminder_sent_at: string | null
          return_reminder_sent_at: string | null
          selected_procedure: string | null
          simulation_intensity: string | null
          simulation_url: string | null
          stage1_analysis: Json | null
          stage2_overlay: Json | null
          status: string | null
          stripe_checkout_session_id: string | null
        }
        Insert: {
          cost_estimate?: Json | null
          created_at?: string | null
          id?: string
          last_active_at?: string | null
          oblique_left_image_url?: string | null
          oblique_right_image_url?: string | null
          original_image_url?: string | null
          overlay_image_url?: string | null
          paid_at?: string | null
          patient_id: string
          payment_amount_cents?: number | null
          payment_currency?: string | null
          payment_status?: string | null
          pdf_url?: string | null
          professional_id: string
          profile_image_url?: string | null
          reminder_sent_at?: string | null
          return_reminder_sent_at?: string | null
          selected_procedure?: string | null
          simulation_intensity?: string | null
          simulation_url?: string | null
          stage1_analysis?: Json | null
          stage2_overlay?: Json | null
          status?: string | null
          stripe_checkout_session_id?: string | null
        }
        Update: {
          cost_estimate?: Json | null
          created_at?: string | null
          id?: string
          last_active_at?: string | null
          oblique_left_image_url?: string | null
          oblique_right_image_url?: string | null
          original_image_url?: string | null
          overlay_image_url?: string | null
          paid_at?: string | null
          patient_id?: string
          payment_amount_cents?: number | null
          payment_currency?: string | null
          payment_status?: string | null
          pdf_url?: string | null
          professional_id?: string
          profile_image_url?: string | null
          reminder_sent_at?: string | null
          return_reminder_sent_at?: string | null
          selected_procedure?: string | null
          simulation_intensity?: string | null
          simulation_url?: string | null
          stage1_analysis?: Json | null
          stage2_overlay?: Json | null
          status?: string | null
          stripe_checkout_session_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sessions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sessions_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      session_real_results: {
        Row: {
          id: string
          professional_id: string
          session_id: string
          photo_url: string
          uploaded_at: string
        }
        Insert: {
          id?: string
          professional_id: string
          session_id: string
          photo_url: string
          uploaded_at?: string
        }
        Update: {
          id?: string
          professional_id?: string
          session_id?: string
          photo_url?: string
          uploaded_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_real_results_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_real_results_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      session_simulation_accuracy_ratings: {
        Row: {
          id: string
          professional_id: string
          session_id: string
          rating: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          professional_id: string
          session_id: string
          rating: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          professional_id?: string
          session_id?: string
          rating?: number
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_simulation_accuracy_ratings_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_simulation_accuracy_ratings_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      skin_screening_revisions: {
        Row: {
          asymmetry: boolean
          color_variation: boolean
          diameter_over_6mm: boolean
          has_suspicious_finding: boolean
          id: string
          irregular_borders: boolean
          lesion_location: string | null
          notes: string | null
          patient_id: string
          proceed_justification: string | null
          proceeded_despite_finding: boolean
          professional_id: string
          recent_evolution: boolean
          recorded_at: string
          referred_to_dermatology: boolean
          screening_id: string
          session_id: string
          superseded_at: string
        }
        Insert: {
          asymmetry: boolean
          color_variation: boolean
          diameter_over_6mm: boolean
          has_suspicious_finding: boolean
          id?: string
          irregular_borders: boolean
          lesion_location?: string | null
          notes?: string | null
          patient_id: string
          proceed_justification?: string | null
          proceeded_despite_finding: boolean
          professional_id: string
          recent_evolution: boolean
          recorded_at: string
          referred_to_dermatology: boolean
          screening_id: string
          session_id: string
          superseded_at?: string
        }
        Update: {
          asymmetry?: boolean
          color_variation?: boolean
          diameter_over_6mm?: boolean
          has_suspicious_finding?: boolean
          id?: string
          irregular_borders?: boolean
          lesion_location?: string | null
          notes?: string | null
          patient_id?: string
          proceed_justification?: string | null
          proceeded_despite_finding?: boolean
          professional_id?: string
          recent_evolution?: boolean
          recorded_at?: string
          referred_to_dermatology?: boolean
          screening_id?: string
          session_id?: string
          superseded_at?: string
        }
        Relationships: []
      }
      skin_screenings: {
        Row: {
          asymmetry: boolean
          color_variation: boolean
          created_at: string
          diameter_over_6mm: boolean
          has_suspicious_finding: boolean
          id: string
          irregular_borders: boolean
          lesion_location: string | null
          notes: string | null
          patient_id: string
          proceed_justification: string | null
          proceeded_despite_finding: boolean
          professional_id: string
          recent_evolution: boolean
          referred_to_dermatology: boolean
          session_id: string
          updated_at: string
        }
        Insert: {
          asymmetry?: boolean
          color_variation?: boolean
          created_at?: string
          diameter_over_6mm?: boolean
          has_suspicious_finding?: boolean
          id?: string
          irregular_borders?: boolean
          lesion_location?: string | null
          notes?: string | null
          patient_id: string
          proceed_justification?: string | null
          proceeded_despite_finding?: boolean
          professional_id: string
          recent_evolution?: boolean
          referred_to_dermatology?: boolean
          session_id: string
          updated_at?: string
        }
        Update: {
          asymmetry?: boolean
          color_variation?: boolean
          created_at?: string
          diameter_over_6mm?: boolean
          has_suspicious_finding?: boolean
          id?: string
          irregular_borders?: boolean
          lesion_location?: string | null
          notes?: string | null
          patient_id?: string
          proceed_justification?: string | null
          proceeded_despite_finding?: boolean
          professional_id?: string
          recent_evolution?: boolean
          referred_to_dermatology?: boolean
          session_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "skin_screenings_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "skin_screenings_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "skin_screenings_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_connections: {
        Row: {
          connection_status: string
          created_at: string
          id: string
          instance_name: string
          phone_number: string | null
          professional_id: string
          qr_code_base64: string | null
          updated_at: string
        }
        Insert: {
          connection_status?: string
          created_at?: string
          id?: string
          instance_name: string
          phone_number?: string | null
          professional_id: string
          qr_code_base64?: string | null
          updated_at?: string
        }
        Update: {
          connection_status?: string
          created_at?: string
          id?: string
          instance_name?: string
          phone_number?: string | null
          professional_id?: string
          qr_code_base64?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_connections_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_message_templates: {
        Row: {
          body: string
          created_at: string
          id: string
          name: string
          professional_id: string
          updated_at: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          name: string
          professional_id: string
          updated_at?: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          name?: string
          professional_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_message_templates_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          phone_number: string
          professional_id: string
          status: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          phone_number: string
          professional_id: string
          status: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          phone_number?: string
          professional_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_send_log_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      terms_acceptances: {
        Row: {
          accepted_at: string
          claim_token: string | null
          claimed_at: string | null
          id: string
          ip_address: string | null
          privacy_version: string
          source: string
          terms_version: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          accepted_at?: string
          claim_token?: string | null
          claimed_at?: string | null
          id?: string
          ip_address?: string | null
          privacy_version: string
          source?: string
          terms_version: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          accepted_at?: string
          claim_token?: string | null
          claimed_at?: string | null
          id?: string
          ip_address?: string | null
          privacy_version?: string
          source?: string
          terms_version?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      hotmart_pending_purchases: {
        Row: {
          buyer_email: string
          claim_requested_at: string | null
          claim_requested_by: string | null
          event: string
          id: string
          payload_excerpt: Json | null
          received_at: string
          resolution: string | null
          resolved_at: string | null
          resolved_profile_id: string | null
          subscriber_code: string | null
          target_status: string
          transaction_id: string | null
        }
        Insert: {
          buyer_email: string
          claim_requested_at?: string | null
          claim_requested_by?: string | null
          event: string
          id?: string
          payload_excerpt?: Json | null
          received_at?: string
          resolution?: string | null
          resolved_at?: string | null
          resolved_profile_id?: string | null
          subscriber_code?: string | null
          target_status: string
          transaction_id?: string | null
        }
        Update: {
          buyer_email?: string
          claim_requested_at?: string | null
          claim_requested_by?: string | null
          event?: string
          id?: string
          payload_excerpt?: Json | null
          received_at?: string
          resolution?: string | null
          resolved_at?: string | null
          resolved_profile_id?: string | null
          subscriber_code?: string | null
          target_status?: string
          transaction_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: { Args: { _role: string; _user_id: string }; Returns: boolean }
      consume_rate_limit: {
        Args: { _bucket: string; _max_requests: number; _window_seconds: number }
        Returns: Json
      }
      purge_expired_rate_limits: {
        Args: { _older_than_seconds?: number }
        Returns: number
      }
      log_data_access: {
        Args: { p_action: string; p_resource_id: string; p_resource_type: string }
        Returns: undefined
      }
      admin_resolve_patient_names: {
        Args: { p_patient_ids: string[] }
        Returns: { id: string; name: string }[]
      }
      consume_insumo_stock_fefo: {
        Args: { p_insumo_id: string; p_quantity: number; p_session_id?: string | null }
        Returns: undefined
      }
      get_patient_anamnesis: {
        Args: { p_patient_id: string }
        Returns: {
          consent_data_processing_at: string | null
          created_at: string
          discromia: string[] | null
          filled_by: string
          id: string
          main_complaint: string | null
          oiliness: string | null
          patient_id: string
          photo_url: string | null
          professional_id: string
          reviewed_at: string | null
          risk_flags: Json
          skin_texture: string | null
          skin_type: string | null
          updated_at: string
          vascularization: string[] | null
        }[]
      }
      admin_dose_accuracy_correlation: {
        Args: Record<PropertyKey, never>
        Returns: { substance: string; region: string; dose_bucket: string; n: number; average_rating: number }[]
      }
      admin_adverse_event_patterns: {
        Args: Record<PropertyKey, never>
        Returns: { substance: string; brand_name: string; event_type: string; n: number }[]
      }
      admin_anamnesis_flag_frequency: {
        Args: Record<PropertyKey, never>
        Returns: { flag_key: string; n: number }[]
      }
      delete_patient_permanently: {
        Args: { p_patient_id: string }
        Returns: { patient_photos_paths: string[] | null; simulation_results_paths: string[] | null }[]
      }
      get_manual_point_justification_stats: {
        Args: { p_substance: string; p_region: string }
        Returns: {
          avg_quantity: number
          quantity_sample_size: number
          avg_accuracy_rating: number | null
          accuracy_sample_size: number
          adverse_event_rate: number | null
          adverse_event_sample_size: number
        }[]
      }
      get_complementary_procedure_insight: {
        Args: { p_procedure_key: string }
        Returns: { complementary_procedure_key: string }[]
      }
      admin_get_session_compliance_context: {
        Args: { p_session_id: string }
        Returns: Json
      }
      admin_toggle_professional_block: {
        Args: { p_professional_id: string; p_blocked: boolean }
        Returns: undefined
      }
      get_professional_conversion_benchmark: {
        Args: Record<PropertyKey, never>
        Returns: { conversion_bucket: string }[]
      }
      // Retorna 'activated' | 'under_review' — string em vez de boolean de
      // propósito: a resposta é deliberadamente a mesma para "não existe
      // compra com esse e-mail" e "existe, mas não é sua" (ver o comentário
      // da função em 20260917153000_add_hotmart_pending_purchases.sql).
      request_hotmart_purchase_recovery: {
        Args: { p_purchase_email: string }
        Returns: string
      }
      admin_link_hotmart_pending_purchase: {
        Args: { p_pending_id: string; p_profile_id: string }
        Returns: undefined
      }
      admin_error_log_summary: {
        Args: { p_days?: number }
        Returns: {
          stage: string
          error_type: string
          n: number
          last_seen_at: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
