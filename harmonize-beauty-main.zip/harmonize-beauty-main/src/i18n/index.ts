import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import pt from './locales/pt.json';
import en from './locales/en.json';
import es from './locales/es.json';
import fr from './locales/fr.json';
import it from './locales/it.json';

export const SUPPORTED_LANGUAGES = ['pt', 'en', 'es', 'fr', 'it'] as const;
export type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number];

export const LANGUAGE_STORAGE_KEY = 'harmonize-language';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      pt: { translation: pt },
      en: { translation: en },
      es: { translation: es },
      fr: { translation: fr },
      it: { translation: it },
    },
    fallbackLng: 'pt',
    supportedLngs: SUPPORTED_LANGUAGES,
    // strips regional variants (e.g. browser "pt-BR" or "en-US") down to their base language
    load: 'languageOnly',
    detection: {
      // checks localStorage first (so a manual choice sticks), then the browser language.
      // Geolocation (below) is a separate, async step that only runs when
      // neither of these produced an explicit stored choice — it can't be
      // listed here because i18next-browser-languagedetector only supports
      // synchronous detectors.
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: LANGUAGE_STORAGE_KEY,
      caches: ['localStorage'],
    },
    interpolation: {
      escapeValue: false, // React already escapes values
    },
  });

// Países de língua espanhola cobertos pelo locale "es" (ver src/i18n/locales/es.json).
const SPANISH_SPEAKING_COUNTRIES = new Set([
  'ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'GT', 'CU', 'BO', 'DO',
  'HN', 'PY', 'SV', 'NI', 'CR', 'PA', 'UY', 'PR', 'GQ',
]);

// Países de língua francesa cobertos pelo locale "fr" (ver src/i18n/locales/fr.json).
// A Bélgica (BE) é deliberadamente deixada de fora: tem múltiplas línguas
// oficiais (neerlandês, francês, alemão) e o país sozinho não indica qual
// delas o visitante fala — mapeá-la para "fr" arriscaria errar para boa
// parte dos usuários belgas.
const FRENCH_SPEAKING_COUNTRIES = new Set(['FR', 'MC']);

function languageForCountry(country: string): SupportedLanguage | undefined {
  if (country === 'BR' || country === 'PT') return 'pt';
  if (SPANISH_SPEAKING_COUNTRIES.has(country)) return 'es';
  if (FRENCH_SPEAKING_COUNTRIES.has(country)) return 'fr';
  if (country === 'IT') return 'it';
  return undefined; // deixa o fallback (navigator → 'pt') decidir
}

// Geolocalização por IP: só roda quando o visitante nunca escolheu um
// idioma manualmente (nada salvo em localStorage) — uma escolha explícita
// do usuário sempre tem prioridade e nunca é sobrescrita por isso. Usa o
// endpoint serverless `/api/geo` (Vercel injeta o país via
// x-vercel-ip-country, sem custo nem API externa); fora da Vercel (dev
// local) o endpoint não existe e isso falha silenciosamente, mantendo o
// idioma detectado pelo navegador.
if (typeof window !== 'undefined' && !window.localStorage.getItem(LANGUAGE_STORAGE_KEY)) {
  fetch('/api/geo')
    .then((res) => (res.ok ? res.json() : null))
    .then((data: { country?: string | null } | null) => {
      const lang = data?.country ? languageForCountry(data.country) : undefined;
      if (lang && lang !== i18n.resolvedLanguage) {
        i18n.changeLanguage(lang);
      }
    })
    .catch(() => {
      // Sem geolocalização disponível (dev local, endpoint fora do ar) —
      // mantém o idioma já resolvido por localStorage/navigator/fallback.
    });
}

export default i18n;
