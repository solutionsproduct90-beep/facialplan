# Internacionalização (i18n)

Infraestrutura de tradução do FacialPlan, baseada em `i18next` + `react-i18next`.
Idiomas suportados hoje: `pt` (padrão/fallback), `en`, `es`, `fr`, `it`.

## Como funciona

- `index.ts` inicializa o i18next, registra os cinco dicionários (`locales/*.json`)
  como recursos e importa o plugin `i18next-browser-languagedetector`, que:
  1. Ao carregar o app, procura um idioma salvo em `localStorage`
     (chave `harmonize-language`); se não achar, usa o idioma do navegador.
  2. Sempre que `i18n.changeLanguage(lang)` é chamado (ex.: no seletor de
     idioma da tela de Perfil), o próprio i18next pede ao detector para
     gravar a escolha em `localStorage` — não é preciso persistir na mão.
  3. `fallbackLng: 'pt'` garante que qualquer chave/idioma não encontrado
     cai no português.
- `main.tsx` importa `./i18n` uma única vez (efeito colateral de inicialização),
  antes de renderizar `<App />`.

## Como usar em um componente

```tsx
import { useTranslation } from 'react-i18next';

const MeuComponente = () => {
  const { t } = useTranslation();
  return <p>{t('home.greeting.morning')}</p>;
};
```

Para trocar o idioma programaticamente (veja `src/pages/Perfil.tsx` para um
exemplo completo com `AuthSelect`):

```tsx
const { i18n } = useTranslation();
i18n.changeLanguage('en'); // 'pt' | 'en' | 'es' | 'fr' | 'it'
```

## Como adicionar uma nova chave de tradução

1. Escolha o namespace correto (veja convenção abaixo) e adicione a chave
   nos **cinco** arquivos em `locales/` (`pt.json`, `en.json`, `es.json`,
   `fr.json`, `it.json`), sempre na mesma posição/estrutura em todos — isso
   facilita ver o que falta traduzir. Se ainda não souber a tradução em
   `en`/`es`/`fr`/`it`, ao menos duplique o texto em português nesses
   arquivos (nunca deixe a chave ausente: sem ela, o app cai no texto puro
   da chave, ex. `home.foo.bar`, visível na tela).
2. No componente, troque o texto hardcoded por `t('namespace.chave')`.
3. Se o texto tiver uma variável (ex. "Olá, {{nome}}"), use interpolação:
   `t('home.hello', { nome: firstName })` e, no JSON,
   `"hello": "Olá, {{nome}}"`.
4. Rode `npx tsc --noEmit -p tsconfig.app.json` e `npm run build` para
   garantir que nada quebrou.

## Convenção de nomenclatura das chaves

Formato: `<namespace>.<tela ou área>.<elemento>[.<estado>]`, em `camelCase`,
sem acentos nem espaços. Os namespaces existentes hoje:

- `common.*` — textos reaproveitados em várias telas (ex. nomes de idiomas).
- `nav.*` — itens do menu inferior (`BottomNav`).
- `home.*` — tela Home (`src/pages/Home.tsx`), com sub-áreas como
  `home.greeting.*`, `home.newSession.*`, `home.recentPatients.*`.
- `auth.login.*` / `auth.cadastro.*` — telas de autenticação, uma sub-chave
  por tela (`src/pages/auth/Login.tsx`, `src/pages/auth/Cadastro.tsx`).
  Mensagens de erro ficam em `auth.<tela>.errors.*`.
- `profile.*` — tela de Perfil (`src/pages/Perfil.tsx`).

Ao traduzir uma nova tela, crie um namespace com o nome da tela (em minúsculo,
ex. `pacientes`, `sessoes`, `conta`) e organize as sub-chaves por seção da UI,
não por texto solto — isso evita colisão de nomes e deixa o JSON legível.
Textos de erro/validação sempre em `<namespace>.errors.<motivo>`.

**Não traduza:** nomes próprios (ex. "FacialPlan"), valores enviados/salvos no
banco de dados (ex. os `value` de especialidade em `Cadastro.tsx`, que
continuam em português por serem dados persistidos — só o `label` exibido é
traduzido).

## Como marcar um componente ainda não traduzido

O escopo desta primeira rodada cobriu apenas `Home`, `Login`, `Cadastro` e
`BottomNav` como exemplo de padrão. O restante do app ainda tem texto
hardcoded em português. Para sinalizar que um componente falta traduzir:

1. Adicione um comentário logo no topo do arquivo:
   ```tsx
   // TODO(i18n): textos hardcoded em pt-BR, ainda não migrado para react-i18next
   ```
2. Ao migrar de fato, siga o padrão dos componentes já traduzidos: importe
   `useTranslation`, extraia as strings visíveis para `locales/*.json` no
   namespace apropriado, e substitua o texto por `t('...')`.
3. Não é necessário migrar tudo de uma vez — prefira migrar tela por tela,
   completando os cinco idiomas antes de seguir para a próxima.

## Arquivos que NÃO devem ser tocados por esta frente de trabalho

`src/pages/Sessao*.tsx`, `src/pages/NovaSessao.tsx` e as edge functions em
`supabase/functions/` estão sendo reescritos por outro time em paralelo —
aguarde a estabilização deles antes de internacionalizar essas telas.
