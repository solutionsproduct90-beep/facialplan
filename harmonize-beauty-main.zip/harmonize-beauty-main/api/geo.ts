// Vercel Serverless Function — detecta o país do visitante pelo IP.
//
// A Vercel injeta automaticamente o header `x-vercel-ip-country` (código
// ISO 3166-1 alpha-2, ex: "BR", "US", "PT") em toda requisição que chega
// pela sua rede de borda — não precisa de nenhuma API externa nem chave.
// Em ambientes fora da Vercel (dev local, outro host) o header não existe;
// o cliente trata a ausência caindo de volta pro idioma do navegador.
//
// Chamado uma única vez, no boot do app, só quando o visitante ainda não
// tem um idioma salvo (ver src/i18n/index.ts) — nunca sobrepõe uma escolha
// manual anterior.
export default function handler(
  req: { headers: Record<string, string | string[] | undefined> },
  res: {
    setHeader: (name: string, value: string) => void;
    status: (code: number) => { json: (body: unknown) => void };
  },
) {
  const country = req.headers['x-vercel-ip-country'];
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    country: typeof country === 'string' ? country : null,
  });
}
