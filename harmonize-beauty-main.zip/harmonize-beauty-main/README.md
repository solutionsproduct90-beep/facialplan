# FacialPlan

Software de planejamento de harmonização facial com IA, para profissionais de
estética da América Latina.

O profissional fotografa o rosto do paciente e o app percorre três estágios:

1. **Análise** — a IA lê a foto (com os landmarks do MediaPipe) e devolve
   achados faciais, proporções e pontos de atenção, cruzados com a anamnese já
   preenchida pelo paciente.
2. **Planejamento** — o profissional monta o protocolo: procedimentos, pontos
   de aplicação, dose e técnica por ponto, com estimativa de custo calculada a
   partir dos insumos e marcas que ele mesmo cadastrou.
3. **Apresentação** — sai um PDF profissional e um PDF para o paciente, uma
   simulação do resultado e um link público que o paciente abre no celular.

Em volta disso: prontuário, agenda, consentimentos (TCLE por procedimento,
termos, LGPD), controle de estoque, radar de retorno, mini-site de captação por
profissional, depoimentos/NPS e um painel administrativo.

O acesso é por assinatura, cobrada pela Hotmart, e o app é um PWA instalável
com push e um modo offline.

## Stack

| Camada | Tecnologia |
|---|---|
| Frontend | React 18, TypeScript, Vite 5, Tailwind, shadcn/ui, react-router-dom v6 |
| Estado/dados | TanStack Query, Supabase JS |
| Backend | Supabase — Postgres com RLS, Auth, Storage e 25 edge functions em Deno |
| IA | Anthropic (análise clínica, checagem adversarial, leitura de rótulo) e Google Gemini (imagens) |
| Idiomas | react-i18next — pt (fonte), en, es, fr, it |
| Pagamento | Hotmart (assinatura do profissional) |
| E-mail / push | Resend / Web Push (VAPID, implementado sobre a Web Crypto API) |
| Hospedagem | Vercel, com pré-renderização estática das páginas públicas |
| Testes | Vitest + Testing Library (~1.600 testes) |

## Rodando localmente

Requer **Node 22**.

```bash
git clone <repo> && cd harmonize-beauty
npm ci
cp .env.example .env     # preencha; cada variável está explicada lá dentro
npm run dev              # http://localhost:8080
```

Para o app subir de verdade bastam `VITE_SUPABASE_URL` e
`VITE_SUPABASE_PUBLISHABLE_KEY` apontando para um projeto Supabase com as
migrations aplicadas (`supabase db push`). O resto das variáveis liga recursos
específicos, e a ausência de cada uma degrada de forma visível e proposital —
o `.env.example` diz exatamente o quê.

## Comandos

| Comando | O que faz |
|---|---|
| `npm run dev` | Servidor de desenvolvimento (porta 8080). |
| `npm run build` | Build de **produção**: `vite build` + pré-renderização das páginas públicas. Exige `VITE_SITE_URL`, `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY` — falha se faltar (ver `scripts/buildEnv.mjs`). |
| `npm run build:dev` | Build sem pré-renderização, sem exigir variável de SEO. |
| `npm run preview` | Serve o `dist/` já construído. |
| `npm run lint` | ESLint. |
| `npm run test` | Vitest, uma passada. |
| `npm run test:watch` | Vitest em watch. |

### Antes de commitar

O `vitest` **não faz checagem de tipo** — já houve commit com três erros de
`tsc` e a suíte toda verde. Rode os quatro, nesta ordem:

```bash
npx tsc --noEmit -p tsconfig.app.json
npm run lint
npm run test -- --run
npm run build && rm -rf dist .prerender-ssr
```

A CI (`.github/workflows/ci.yml`) roda exatamente isso a cada push.

## Estrutura

```
src/
  pages/            uma tela por rota (ver o mapa de rotas em src/App.tsx)
    admin/          painel administrativo (usuários, erros, métricas, auditoria)
    site/           páginas públicas institucionais + blog
  components/
    harmonize/      componentes do produto (ProtectedRoute, layouts, PDF, câmera…)
    site/           componentes das páginas institucionais
    ui/             shadcn/ui
  lib/              regra de negócio pura, testável sem React (orçamento, PDF,
                    agenda, métricas, análise facial, exportações)
  hooks/            hooks de React (câmera, push, ditado por voz, offline…)
  contexts/         AuthContext
  i18n/locales/     pt.json (fonte) + en, es, fr, it
  integrations/     client e tipos gerados do Supabase
  content/blog/     posts do blog em Markdown
  test/             testes de edge function e de configuração
supabase/
  migrations/       schema, uma migration por mudança — nunca edite uma aplicada
  functions/        25 edge functions em Deno (_shared/ tem os helpers comuns)
  config.toml       inclui os blocos verify_jwt (leia antes de criar função nova)
scripts/
  prerender.mjs     gera o HTML estático das páginas públicas + sitemap.xml
  buildEnv.mjs      variáveis obrigatórias do build de produção
docs/               runbook de produção, hospedagem, rotinas agendadas
api/geo.ts          função serverless da Vercel (país do visitante, para o idioma)
```

Testes ficam ao lado do código que testam (`budget.ts` → `budget.test.ts`).

## Convenções que o projeto leva a sério

- **Comentário explica o porquê**, não o quê: a decisão de produto ou de
  arquitetura por trás do trecho. Leia os arquivos vizinhos antes de escrever.
- **Nenhuma string visível hardcoded.** Texto novo entra em
  `src/i18n/locales/pt.json` e nos outros quatro idiomas.
- **O paywall vive em três camadas mantidas em sincronia manual**: RLS via
  `public.has_active_subscription()`, `supabase/functions/_shared/subscriptionGate.ts`
  e `src/components/harmonize/ProtectedRoute.tsx`. Mudou a regra de acesso,
  mude nas três.
- **`verify_jwt`**: toda edge function autenticada por outro meio que não o JWT
  do Supabase Auth precisa do bloco `[functions.<nome>] verify_jwt = false` em
  `supabase/config.toml`. Sem ele o gateway responde 401 antes de o código
  rodar — esse erro já derrubou o webhook da Hotmart.
- **Migrations são imutáveis.** Arquivo novo, `YYYYMMDDHHMMSS_descricao.sql`,
  com `COMMENT ON COLUMN` em toda coluna nova e índice em toda coluna que o app
  vai filtrar. Tabela nova nasce com RLS habilitada.
- **Mudança de comportamento vem com teste.**

## Documentação

| Documento | Assunto |
|---|---|
| [`docs/runbook-producao.md`](docs/runbook-producao.md) | **Comece por aqui para implantar.** Migrations, edge functions, os 14 secrets, webhook da Hotmart, Resend, primeira conta admin e smoke test. |
| [`docs/hospedagem.md`](docs/hospedagem.md) | O `vercel.json` explicado bloco a bloco. |
| [`docs/rotinas-agendadas.md`](docs/rotinas-agendadas.md) | O agendador via GitHub Actions e o `SCHEDULER_TOKEN`. |
| [`docs/testes-adversariais-ia.md`](docs/testes-adversariais-ia.md) | Testes adversariais dos prompts de IA. |
| [`.env.example`](.env.example) | Toda variável de build, o que quebra sem ela e onde obter o valor. |
