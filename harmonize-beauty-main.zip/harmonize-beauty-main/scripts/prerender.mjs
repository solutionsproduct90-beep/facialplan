// Pré-renderização estática das páginas públicas institucionais + blog.
//
// Por quê: este app é uma SPA Vite pura, sem SSR — o HTML servido antes do
// JS rodar é sempre o mesmo `index.html` genérico. Isso é o suficiente pra
// navegador, mas a maioria dos crawlers relevantes pro objetivo de SEO/IA
// (Googlebot renderiza JS, mas nem todo bot de IA/preview faz isso — ver
// nota em src/hooks/useDocumentMeta.ts) só lê o HTML estático inicial.
//
// Este script roda DEPOIS do `vite build` (ver package.json) e gera, pra
// cada rota pública sem dependência de sessão (recursos/preços/sobre/blog),
// um `dist/<rota>/index.html` com o conteúdo real já renderizado e
// title/description/OG corretos — sem exigir SSR em runtime, sem servidor
// Node em produção: são arquivos estáticos que o Vercel serve diretamente
// (arquivo existente tem prioridade sobre o fallback de SPA).
//
// "/" fica de fora de propósito — ver comentário em src/entry-server.tsx.
import { build as viteBuild, loadEnv } from 'vite';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertRequiredBuildEnv } from './buildEnv.mjs';

const PROJECT_ROOT = path.dirname(fileURLToPath(new URL('.', import.meta.url)));
const DIST_DIR = path.join(PROJECT_ROOT, 'dist');
const SSR_OUT_DIR = path.join(PROJECT_ROOT, '.prerender-ssr');

// `loadEnv` em vez de `process.env` direto: este script é a única parte do
// build que roda fora do pipeline do Vite, e por isso era a única que NÃO
// enxergava um .env. Quem configurasse VITE_SITE_URL no .env local (o lugar
// onde todas as outras variáveis VITE_ moram) via o sitemap ser pulado sem
// entender por quê — o valor estava lá, só não neste processo. Agora as duas
// pontas leem da mesma fonte, com a mesma precedência (.env, .env.local,
// .env.production, process.env).
const BUILD_ENV = loadEnv('production', PROJECT_ROOT, 'VITE_');
const SITE_URL = BUILD_ENV.VITE_SITE_URL?.replace(/\/$/, '');

function escapeHtmlAttr(value) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function buildStructuredData(structuredData, { route, description }) {
  if (!structuredData) return null;

  if (structuredData.type === 'organization') {
    return {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'FacialPlan',
      description,
      url: SITE_URL,
      logo: `${SITE_URL}/favicon.svg`,
    };
  }

  // article
  const article = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: structuredData.title,
    description: structuredData.description,
    datePublished: structuredData.datePublished,
    author: { '@type': 'Person', name: structuredData.author },
    publisher: { '@type': 'Organization', name: 'FacialPlan' },
  };
  if (structuredData.tags?.length) article.keywords = structuredData.tags.join(', ');
  // coverImage no front matter é sempre um caminho relativo (ver src/content/blog) — o
  // schema.org exige URL absoluta, montada com SITE_URL (garantida por
  // assertRequiredBuildEnv em main()).
  if (structuredData.image) {
    article.image = [structuredData.image.startsWith('http') ? structuredData.image : `${SITE_URL}${structuredData.image}`];
  }
  article.mainEntityOfPage = { '@type': 'WebPage', '@id': `${SITE_URL}${route}` };
  return article;
}

function injectIntoTemplate(template, { html, title, description, locale, alternates, structuredData }, route) {
  const safeTitle = escapeHtmlAttr(title);
  const safeDescription = escapeHtmlAttr(description);

  let output = template
    .replace(/<html lang="[^"]*"/, `<html lang="${locale}"`)
    .replace(/<div id="root"><\/div>/, `<div id="root">${html}</div>`)
    .replace(/<title>[^<]*<\/title>/, `<title>${safeTitle}</title>`)
    .replace(/(<meta name="description"\s+content=")[^"]*(")/, `$1${safeDescription}$2`)
    .replace(/(<meta property="og:title" content=")[^"]*(")/, `$1${safeTitle}$2`)
    .replace(/(<meta property="og:description"\s+content=")[^"]*(")/, `$1${safeDescription}$2`);

  const extraTags = [];

  // hreflang só faz sentido apontando pra uma URL absoluta (exigência do
  // próprio padrão) — daí VITE_SITE_URL ser obrigatória no build de produção
  // (scripts/buildEnv.mjs). Publicar hreflang relativo seria pior que não
  // publicar: crawlers ignoram em silêncio.
  if (alternates?.length) {
    for (const alt of alternates) {
      extraTags.push(`    <link rel="alternate" hreflang="${alt.locale}" href="${SITE_URL}${alt.href}" />`);
    }
    // pt é a língua-fonte — x-default aponta pra ela (ou pra própria
    // página, se ela já É a pt).
    const ptHref = locale === 'pt' ? route : alternates.find((a) => a.locale === 'pt')?.href;
    if (ptHref) extraTags.push(`    <link rel="alternate" hreflang="x-default" href="${SITE_URL}${ptHref}" />`);
  }

  const canonicalUrl = `${SITE_URL}${route}`;
  extraTags.push(`    <link rel="canonical" href="${canonicalUrl}" />`, `    <meta property="og:url" content="${canonicalUrl}" />`);

  const jsonLd = buildStructuredData(structuredData, { route, description });
  if (jsonLd) {
    extraTags.push(`    <script type="application/ld+json">${JSON.stringify(jsonLd)}</script>`);
  }

  if (extraTags.length) {
    output = output.replace('</head>', `${extraTags.join('\n')}\n  </head>`);
  }

  return output;
}

function buildSitemapXml(entries) {
  const urlBlocks = [
    // "/" não é pré-renderizada (conteúdo depende de sessão — ver comentário em
    // src/entry-server.tsx) mas é a home pública real, então entra no sitemap mesmo assim.
    `  <url>\n    <loc>${SITE_URL}/</loc>\n  </url>`,
  ];

  for (const entry of entries) {
    const lines = [`    <loc>${SITE_URL}${entry.route}</loc>`];
    if (entry.lastmod) lines.push(`    <lastmod>${entry.lastmod}</lastmod>`);

    const altLinks = entry.alternates.map((alt) => `    <xhtml:link rel="alternate" hreflang="${alt.locale}" href="${SITE_URL}${alt.href}" />`);
    const ptHref = entry.locale === 'pt' ? entry.route : entry.alternates.find((alt) => alt.locale === 'pt')?.href;
    if (ptHref) altLinks.push(`    <xhtml:link rel="alternate" hreflang="x-default" href="${SITE_URL}${ptHref}" />`);
    lines.push(...altLinks);

    urlBlocks.push(`  <url>\n${lines.join('\n')}\n  </url>`);
  }

  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n${urlBlocks.join('\n')}\n</urlset>\n`;
}

async function appendSitemapToRobots() {
  const roboPath = path.join(DIST_DIR, 'robots.txt');
  // public/robots.txt (copiado pro dist pelo próprio `vite build`) já define as regras de
  // bot — só adiciona a referência ao sitemap, não sobrescreve.
  const existing = await readFile(roboPath, 'utf-8').catch(() => '');
  if (existing.includes('Sitemap:')) return;
  await writeFile(roboPath, `${existing.trimEnd()}\n\nSitemap: ${SITE_URL}/sitemap.xml\n`, 'utf-8');
}

async function main() {
  // Antes de qualquer trabalho: sem VITE_SITE_URL não existe pré-renderização
  // que preste (nem sitemap, nem canonical, nem hreflang, nem og:url), e a
  // versão anterior deste script apenas IMPRIMIA um aviso e saía com código 0
  // — um deploy de produção subia sem sitemap.xml e sem robots.txt apontando
  // pra ele, com o pipeline todo verde. O `vite build` já barra isso pelo
  // plugin em vite.config.ts; a checagem se repete aqui porque este script
  // também é executável sozinho (`node scripts/prerender.mjs`).
  assertRequiredBuildEnv(BUILD_ENV);

  console.log('[prerender] building SSR bundle...');
  await viteBuild({
    root: PROJECT_ROOT,
    build: {
      ssr: 'src/entry-server.tsx',
      outDir: path.relative(PROJECT_ROOT, SSR_OUT_DIR),
      emptyOutDir: true,
      // Bundle roda em Node (nunca no navegador) — precisa de target com
      // suporte a top-level await, usado em src/entry-server.tsx pra
      // inicializar a instância de i18next dedicada ao SSR.
      target: 'node18',
    },
    logLevel: 'warn',
  });

  const entryPath = path.join(SSR_OUT_DIR, 'entry-server.js');
  const { render, listStaticRoutes } = await import(`${entryPath}?t=${Date.now()}`);

  const template = await readFile(path.join(DIST_DIR, 'index.html'), 'utf-8');
  const routes = listStaticRoutes();

  console.log(`[prerender] gerando ${routes.length} página(s) estática(s)...`);
  const sitemapEntries = [];
  for (const route of routes) {
    const result = await render(route);
    const finalHtml = injectIntoTemplate(template, result, route);

    const outDir = path.join(DIST_DIR, route);
    await mkdir(outDir, { recursive: true });
    await writeFile(path.join(outDir, 'index.html'), finalHtml, 'utf-8');
    console.log(`[prerender]   ${route} -> ${result.title}`);

    sitemapEntries.push({
      route,
      locale: result.locale,
      alternates: result.alternates,
      lastmod: result.structuredData?.type === 'article' ? result.structuredData.datePublished : undefined,
    });
  }

  await writeFile(path.join(DIST_DIR, 'sitemap.xml'), buildSitemapXml(sitemapEntries), 'utf-8');
  await appendSitemapToRobots();
  console.log('[prerender] sitemap.xml gerado e referenciado em robots.txt.');

  await rm(SSR_OUT_DIR, { recursive: true, force: true });
  console.log('[prerender] concluído.');
}

main().catch((error) => {
  console.error('[prerender] falhou:', error);
  process.exitCode = 1;
});
