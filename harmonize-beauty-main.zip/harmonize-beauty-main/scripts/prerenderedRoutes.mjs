/**
 * Rotas que existem como HTML estático em `dist/` (ver scripts/prerender.mjs)
 * e que o service worker NÃO pode responder com o app shell.
 *
 * O Workbox, no modo `generateSW`, registra uma NavigationRoute que responde
 * QUALQUER navegação com o `index.html` precacheado. Num navegador comum isso
 * é invisível (o service worker só assume depois da primeira visita, e o host
 * já entregou o HTML certo), mas num PWA instalado ele passa a ser o caminho
 * padrão: o visitante abre /precos e recebe a casca do SPA, sem o <title>,
 * o canonical, o hreflang nem o conteúdo pré-renderizado. O mesmo vale para
 * qualquer navegação vinda de um link compartilhado dentro do app instalado.
 *
 * Estes padrões entram em `workbox.navigateFallbackDenylist`, que faz a
 * NavigationRoute se recusar a atender essas URLs — a navegação segue para a
 * rede e o host entrega o arquivo pré-renderizado de verdade.
 *
 * O Workbox testa cada RegExp contra `url.pathname + url.search`, e não contra
 * o pathname puro. Por isso o fim de cada padrão aceita `?` e `#`: sem isso,
 * um link de campanha como /precos?utm_source=ig escaparia do denylist e
 * voltaria a cair no app shell — justamente o tráfego que mais precisa da
 * página certa.
 *
 * Mantido em sincronia com `listStaticRoutes()` (src/entry-server.tsx) pelo
 * teste src/test/pwaPrerenderDenylist.test.ts, que percorre a lista real de
 * rotas geradas e exige que cada uma case com algum padrão daqui.
 */
export const PRERENDERED_NAVIGATION_DENYLIST = [
  // Institucionais e blog, em pt (sem prefixo) e nos locales prefixados.
  // O sufixo `(?:\/|[?#]|$)` cobre tanto /blog quanto /blog/<slug>.
  /^\/(?:es\/|en\/)?(?:recursos|precos|sobre|blog)(?:\/|[?#]|$)/,
  // Documentos legais: só existem em pt, sem variante prefixada.
  /^\/(?:termos|privacidade)(?:\/|[?#]|$)/,
];
