// Entrada do harness de captura de telas.
//
// Renderiza UMA das três telas reais do app, escolhida por query string, com
// o idioma pedido. O Playwright (capture.mjs) abre esta página uma vez por
// combinação tela × idioma e fotografa o viewport.
//
//   ?screen=analise|simulacao|planificacao&lang=pt|es|en
//
// As telas são os componentes de produção, sem cópia nem reimplementação: o
// que muda é só de onde vêm os dados (ver mocks/supabaseClient.ts).

import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { TooltipProvider } from '@/components/ui/tooltip';
import i18n from '@/i18n';
import SessaoEstagio1 from '@/pages/SessaoEstagio1';
import SessaoEstagio2 from '@/pages/SessaoEstagio2';
import SessaoEstagio3 from '@/pages/SessaoEstagio3';
import { DEMO_SESSION_ID } from './fixtures';
import '../../src/index.css';

const params = new URLSearchParams(window.location.search);
const screen = params.get('screen');
const lang = params.get('lang') ?? 'pt';

const SCREENS: Record<string, { path: string; element: React.ReactElement }> = {
  analise: { path: '/sessoes/:id/estagio-1', element: <SessaoEstagio1 /> },
  planificacao: { path: '/sessoes/:id/estagio-2', element: <SessaoEstagio2 /> },
  simulacao: { path: '/sessoes/:id/estagio-3', element: <SessaoEstagio3 /> },
};

const ROUTE_BY_SCREEN: Record<string, string> = {
  analise: `/sessoes/${DEMO_SESSION_ID}/estagio-1`,
  planificacao: `/sessoes/${DEMO_SESSION_ID}/estagio-2`,
  simulacao: `/sessoes/${DEMO_SESSION_ID}/estagio-3`,
};

// Abrir a raiz sem query string mostra um índice em vez de escolher uma tela
// por conta própria: quem abre o harness pela primeira vez precisa ver o que
// existe, não adivinhar os parâmetros.
function Indice() {
  const telas: Array<[string, string]> = [
    ['analise', 'Análise facial (Etapa 1)'],
    ['simulacao', 'Simulação antes/depois (Etapa 3)'],
    ['planificacao', 'Pontos de aplicação (Etapa 2)'],
  ];
  const idiomas = ['pt', 'es', 'en', 'fr', 'it'];

  return (
    <div style={{ font: '16px/1.5 system-ui, sans-serif', padding: 24, maxWidth: 560, margin: '0 auto' }}>
      <h1 style={{ fontSize: 22, marginBottom: 4 }}>FacialPlan — telas para captura</h1>
      <p style={{ color: '#666', marginTop: 0 }}>
        Telas reais do app com dados de demonstração. Abra no modo dispositivo do
        DevTools (iPhone 14) e tire o print.
      </p>
      {telas.map(([id, rotulo]) => (
        <div key={id} style={{ marginBottom: 18 }}>
          <strong>{rotulo}</strong>
          <div style={{ marginTop: 6, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {idiomas.map((l) => (
              <a key={l} href={`?screen=${id}&lang=${l}`} style={{ color: '#B5179E' }}>
                {l.toUpperCase()}
              </a>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Harness() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // O idioma precisa estar trocado ANTES da tela montar, senão o primeiro
    // render sai em português e o print pode pegar esse frame.
    i18n.changeLanguage(lang).then(() => setReady(true));
  }, []);

  if (!ready) return null;
  if (!screen) return <Indice />;

  const config = SCREENS[screen];
  if (!config) {
    throw new Error(`Tela desconhecida: ${screen}. Use analise, simulacao ou planificacao.`);
  }

  return (
    <TooltipProvider>
      <MemoryRouter initialEntries={[ROUTE_BY_SCREEN[screen]]}>
        <Routes>
          <Route path={config.path} element={config.element} />
        </Routes>
      </MemoryRouter>
    </TooltipProvider>
  );
}

createRoot(document.getElementById('root')!).render(<Harness />);
