// Gera os dois retratos-placeholder usados nas capturas de tela.
//
// POR QUE UM PLACEHOLDER: as três telas capturadas mostram a foto do
// paciente. Um print de marketing com rosto real exige autorização de uso de
// imagem, que é uma decisão de quem opera a clínica — não algo que o harness
// possa presumir. Então ele desenha um retrato neutro e estilizado, bom o
// suficiente para a composição do mockup ler, e claramente não uma pessoa.
//
// PARA TROCAR PELA FOTO DEFINITIVA: substitua os dois arquivos em
// scripts/screenshots/public/assets/ mantendo os nomes, de preferência em
// 3:4 e com o rosto centralizado. "antes" e "depois" devem ser a MESMA
// pessoa, para a tela de simulação contar uma história só.
//
//   node scripts/screenshots/gerarFoto.mjs

import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, 'public', 'assets');
mkdirSync(outDir, { recursive: true });

// O desenho em si vive num script Python porque Pillow já está disponível no
// ambiente e dá controle fino de gradiente e desfoque sem nenhuma dependência
// nova no package.json.
const python = `
import math
from PIL import Image, ImageDraw, ImageFilter

W, H = 900, 1200

def portrait(path, *, cheek_lift, lip_fullness, brow_smooth):
    """Retrato estilizado em 3:4. Os 3 parametros deslocam sutilmente malar,
    labio e sobrancelha — a diferenca entre 'antes' e 'depois' vem so deles,
    imitando o tipo de mudanca que a simulacao do app produz.

    A geometria e casada com scripts/screenshots/mocks/faceLandmarker.ts: a
    testa fica VISIVEL (cabelo so ate ~y=0.24) porque os pontos de terco
    frontal e glabela sao aplicados ali."""
    img = Image.new('RGB', (W, H), (30, 25, 33))
    d = ImageDraw.Draw(img)

    # Fundo: vinheta radial quente.
    for i in range(150):
        t = i / 150
        r = int(600 * (1 - t) + 70)
        d.ellipse([W // 2 - r, int(H * 0.44) - r, W // 2 + r, int(H * 0.44) + r],
                  fill=(int(56 + 30 * t), int(47 + 25 * t), int(62 + 28 * t)))

    skin = (226, 190, 170)
    shadow = (198, 158, 140)
    light = (241, 210, 192)

    cx = W // 2
    cy = 600
    fw = 252 + cheek_lift
    fh = 352

    # Cabelo de tras: moldura que aparece dos lados e atras dos ombros.
    hair = (43, 31, 38)
    d.ellipse([cx - fw - 62, cy - fh - 92, cx + fw + 62, cy + fh + 60], fill=hair)

    # Pescoco e ombros.
    d.polygon([(cx - 150, H), (cx - 92, cy + fh - 40), (cx + 92, cy + fh - 40), (cx + 150, H)], fill=shadow)
    d.ellipse([cx - 340, cy + fh + 60, cx + 340, H + 240], fill=(50, 42, 58))

    # Ovalo do rosto.
    d.ellipse([cx - fw, cy - fh, cx + fw, cy + fh], fill=skin)

    # Testa iluminada — precisa ficar limpa para os pontos do terco superior.
    d.ellipse([cx - fw + 26, cy - fh + 4, cx + fw - 26, cy - 90], fill=light)

    # Malares.
    for sx in (-1, 1):
        mx = cx + sx * (142 + cheek_lift // 2)
        d.ellipse([mx - 96, cy - 62, mx + 96, cy + 66], fill=light)

    # Sombra sob a maca do rosto, menor quando ha mais projecao.
    depth = 30 - cheek_lift // 5
    for sx in (-1, 1):
        mx = cx + sx * 156
        d.ellipse([mx - 82, cy + 96, mx + 82, cy + 96 + depth], fill=shadow)

    # Sobrancelhas (y ~ 0.335 * H = 402). brow_smooth reduz a inclinacao.
    for sx in (-1, 1):
        bx = cx + sx * 108
        tilt = (7 - brow_smooth) * sx
        d.line([(bx - 66, 408 + tilt), (bx + 66, 400 - tilt)], fill=(78, 58, 54), width=16)

    # Olhos abertos (y ~ 0.40 * H = 480).
    for sx in (-1, 1):
        ex = cx + sx * 108
        d.ellipse([ex - 56, 452, ex + 56, 508], fill=(250, 246, 244))
        d.ellipse([ex - 22, 458, ex + 22, 502], fill=(82, 60, 50))
        d.ellipse([ex - 9, 471, ex + 9, 489], fill=(22, 16, 18))
        d.line([(ex - 58, 450), (ex + 58, 446)], fill=(60, 44, 42), width=6)

    # Nariz (ponta em y ~ 0.505 * H = 606).
    d.polygon([(cx, 505), (cx - 36, 606), (cx + 36, 606)], fill=shadow)
    d.ellipse([cx - 40, 590, cx + 40, 626], fill=skin)

    # Labios (vermelhao superior em y ~ 0.565 * H = 678).
    ly = 690
    d.polygon(
        [(cx - 90, ly), (cx - 32, ly - 18 - lip_fullness), (cx, ly - 9 - lip_fullness // 2),
         (cx + 32, ly - 18 - lip_fullness), (cx + 90, ly), (cx, ly + 13)],
        fill=(178, 106, 108),
    )
    d.polygon([(cx - 84, ly + 5), (cx, ly + 50 + lip_fullness // 2), (cx + 84, ly + 5)], fill=(160, 90, 94))

    # Cabelo da frente: SO a calota, terminando bem acima das sobrancelhas
    # (y = 288 = 0.24 * H), para nao cobrir a testa.
    d.chord([cx - fw - 30, cy - fh - 80, cx + fw + 30, cy - fh + 300], 180, 360, fill=hair)
    for sx in (-1, 1):
        hx = cx + sx * (fw + 14)
        d.ellipse([hx - 76, cy - fh + 40, hx + 76, cy + fh + 40], fill=hair)

    img = img.filter(ImageFilter.GaussianBlur(7))

    noise = Image.effect_noise((W, H), 16).convert('L').point(lambda v: 128 + (v - 128) // 7)
    img = Image.blend(img, Image.merge('RGB', (noise, noise, noise)), 0.06)

    img.save(path, 'PNG', optimize=True)

portrait('${outDir}/paciente-antes.png', cheek_lift=0, lip_fullness=0, brow_smooth=0)
portrait('${outDir}/paciente-depois.png', cheek_lift=18, lip_fullness=10, brow_smooth=5)
print('ok')
`;

execFileSync('python3', ['-c', python], { stdio: 'inherit' });
console.log(`Retratos-placeholder gerados em ${outDir}`);
