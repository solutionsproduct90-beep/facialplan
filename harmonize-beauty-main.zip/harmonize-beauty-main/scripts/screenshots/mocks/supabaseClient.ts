// Stand-in do cliente Supabase para o harness de captura de telas.
//
// O Vite do harness (vite.config.screenshots.ts) aliasa
// `@/integrations/supabase/client` para este arquivo, então as telas reais do
// app rodam sem rede, sem autenticação e sem banco — mas pelo mesmo caminho de
// código de sempre: elas continuam chamando `supabase.from(...).select(...)`,
// `supabase.storage...createSignedUrl(...)` e `supabase.rpc(...)` exatamente
// como em produção.
//
// O builder abaixo é deliberadamente burro: ignora os filtros e resolve pela
// TABELA mais o fato de `.single()`/`.maybeSingle()` ter sido chamado. Isso
// basta porque cada tela consulta cada tabela de um jeito só. Se uma tela nova
// passar a consultar a mesma tabela de duas formas diferentes, é aqui que se
// acrescenta a distinção.

import {
  DEMO_ANAMNESIS,
  DEMO_CONSENT,
  DEMO_INSUMOS,
  DEMO_PATIENT,
  DEMO_PROFILE,
  DEMO_SESSION,
  PHOTO_AFTER,
  PHOTO_BEFORE,
} from '../fixtures';

type Resolution = { data: unknown; error: null; count?: number | null };

const LIST_BY_TABLE: Record<string, unknown[]> = {
  insumos: DEMO_INSUMOS,
  // Sessões anteriores concluídas da paciente: vazio de propósito, para o
  // print não carregar avisos de histórico que dependem de outra sessão.
  sessions: [],
  consents: [],
  skin_screenings: [],
  adverse_events: [],
  treatment_plans: [],
  treatment_plan_steps: [],
  appointments: [],
  session_real_results: [],
};

const SINGLE_BY_TABLE: Record<string, unknown> = {
  sessions: DEMO_SESSION,
  patients: DEMO_PATIENT,
  profiles: DEMO_PROFILE,
  anamnesis: DEMO_ANAMNESIS,
  consents: DEMO_CONSENT,
  // Sem achado suspeito: o selo de conformidade fica verde, que é o estado
  // que o material de marketing deve mostrar.
  skin_screenings: null,
};

interface Builder extends PromiseLike<Resolution> {
  select: (...a: unknown[]) => Builder;
  insert: (...a: unknown[]) => Builder;
  update: (...a: unknown[]) => Builder;
  upsert: (...a: unknown[]) => Builder;
  delete: (...a: unknown[]) => Builder;
  eq: (...a: unknown[]) => Builder;
  neq: (...a: unknown[]) => Builder;
  gt: (...a: unknown[]) => Builder;
  gte: (...a: unknown[]) => Builder;
  lt: (...a: unknown[]) => Builder;
  lte: (...a: unknown[]) => Builder;
  in: (...a: unknown[]) => Builder;
  is: (...a: unknown[]) => Builder;
  or: (...a: unknown[]) => Builder;
  not: (...a: unknown[]) => Builder;
  order: (...a: unknown[]) => Builder;
  limit: (...a: unknown[]) => Builder;
  range: (...a: unknown[]) => Builder;
  single: () => Builder;
  maybeSingle: () => Builder;
}

function createBuilder(table: string): Builder {
  let wantsSingle = false;

  const resolve = (): Resolution => {
    if (wantsSingle) {
      const row = table in SINGLE_BY_TABLE ? SINGLE_BY_TABLE[table] : null;
      return { data: row, error: null };
    }
    const rows = LIST_BY_TABLE[table] ?? [];
    return { data: rows, error: null, count: rows.length };
  };

  const chain = (...names: string[]) =>
    Object.fromEntries(names.map(name => [name, () => builder]));

  const builder = {
    ...chain(
      'select', 'insert', 'update', 'upsert', 'delete',
      'eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'in', 'is', 'or', 'not',
      'order', 'limit', 'range',
    ),
    single: () => {
      wantsSingle = true;
      return builder;
    },
    maybeSingle: () => {
      wantsSingle = true;
      return builder;
    },
    then: (onFulfilled: (value: Resolution) => unknown, onRejected?: (reason: unknown) => unknown) =>
      Promise.resolve(resolve()).then(onFulfilled, onRejected),
  } as unknown as Builder;

  return builder;
}

/** As URLs assinadas do Storage viram os arquivos estáticos do harness. */
const SIGNED_URL_BY_PATH: Record<string, string> = {
  'demo/antes.png': PHOTO_BEFORE,
  'demo/depois.png': PHOTO_AFTER,
};

export const supabase = {
  from: (table: string) => createBuilder(table),

  rpc: async () => ({ data: [], error: null }),

  storage: {
    from: (bucket: string) => ({
      createSignedUrl: async (path: string) => {
        const signedUrl = SIGNED_URL_BY_PATH[path] ?? null;
        // `simulation-results` não guarda a foto original: devolver null aqui
        // reproduz o fallback real da Etapa 3, que tenta o outro bucket.
        if (bucket === 'simulation-results' && path !== 'demo/depois.png') {
          return { data: null, error: { message: 'not found' } };
        }
        return signedUrl
          ? { data: { signedUrl }, error: null }
          : { data: null, error: { message: 'not found' } };
      },
      createSignedUrls: async () => ({ data: [], error: null }),
      upload: async () => ({ data: { path: 'demo/upload.png' }, error: null }),
      download: async () => ({ data: null, error: { message: 'unsupported in screenshots' } }),
      remove: async () => ({ data: [], error: null }),
      getPublicUrl: (path: string) => ({ data: { publicUrl: SIGNED_URL_BY_PATH[path] ?? PHOTO_BEFORE } }),
    }),
  },

  functions: {
    invoke: async (name: string) => {
      if (name === 'generate-simulation') {
        return {
          data: { simulationUrl: PHOTO_AFTER, originalUrl: PHOTO_BEFORE, source: 'ai' },
          error: null,
        };
      }
      return { data: null, error: null };
    },
  },

  auth: {
    getSession: async () => ({ data: { session: null }, error: null }),
    getUser: async () => ({ data: { user: null }, error: null }),
    onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
    signOut: async () => ({ error: null }),
  },

  channel: () => ({
    on: () => ({ subscribe: () => ({ unsubscribe: () => {} }) }),
    subscribe: () => ({ unsubscribe: () => {} }),
  }),
  removeChannel: () => {},
};
