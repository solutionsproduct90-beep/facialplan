// Stand-in do AuthContext para o harness de captura.
//
// As três telas capturadas só consomem `user` e `profile` do contexto; elas
// não passam pelo ProtectedRoute aqui, porque o harness renderiza a página
// diretamente. O perfil devolvido é o de um profissional com assinatura
// ativa, que é o estado que o material de marketing deve mostrar.

import React from 'react';
import { DEMO_PROFILE, DEMO_USER_ID } from '../fixtures';

export interface AccessProfile {
  is_blocked: boolean | null;
  subscription_status: string | null;
  role: string | null;
  past_due_since: string | null;
}

const DEMO_USER = {
  id: DEMO_USER_ID,
  email: 'camila@studiocamilarocha.com.br',
  app_metadata: {},
  user_metadata: {},
  aud: 'authenticated',
  created_at: '2026-01-10T12:00:00.000Z',
};

const value = {
  user: DEMO_USER,
  session: { user: DEMO_USER, access_token: 'demo', token_type: 'bearer' },
  loading: false,
  profile: {
    is_blocked: DEMO_PROFILE.is_blocked,
    subscription_status: DEMO_PROFILE.subscription_status,
    role: DEMO_PROFILE.role,
    past_due_since: DEMO_PROFILE.past_due_since,
  } as AccessProfile,
  profileLoading: false,
  refreshProfile: async () => value.profile,
  signOut: async () => {},
};

export const useAuth = () => value;

export const AuthProvider = ({ children }: { children: React.ReactNode }) => <>{children}</>;
