// Stand-in de src/lib/faceLandmarker.ts para o harness de captura.
//
// O FaceLandmarker real baixa um modelo de alguns MB de um CDN e roda WASM
// sobre a foto. No harness isso seria lento, dependente de rede e
// não-determinístico entre execuções — e, pior, ao falhar faz a Etapa 2
// mostrar o aviso "não foi possível detectar todos os pontos faciais", que
// não pode aparecer num print de marketing.
//
// Em vez de desligar a detecção, este mock a faz SUCEDER com coordenadas
// fixas, medidas sobre o retrato-placeholder gerado por gerarFoto.mjs. A tela
// então segue exatamente o mesmo caminho de código de uma detecção real: ela
// reposiciona cada ponto pelo landmark da região (landmarkPositionForRegion,
// em src/lib/faceRegions.ts) e não mostra aviso nenhum.
//
// AO TROCAR A FOTO PLACEHOLDER por uma foto de verdade, ajuste as coordenadas
// abaixo para os mesmos pontos anatômicos no novo rosto — ou remova este
// alias de vite.config.screenshots.ts e deixe o MediaPipe rodar de verdade.

/** Índice do Face Mesh -> posição normalizada (0–1) no retrato-placeholder. */
const POSICOES: Record<number, { x: number; y: number }> = {
  // Terço frontal (testa) — acima das sobrancelhas, abaixo da linha do cabelo.
  10: { x: 0.5, y: 0.285 },
  108: { x: 0.42, y: 0.29 },
  337: { x: 0.58, y: 0.29 },
  // Glabela — entre as sobrancelhas.
  9: { x: 0.5, y: 0.335 },
  8: { x: 0.5, y: 0.345 },
  168: { x: 0.5, y: 0.355 },
  // Malares.
  234: { x: 0.315, y: 0.455 },
  93: { x: 0.33, y: 0.47 },
  454: { x: 0.685, y: 0.455 },
  323: { x: 0.67, y: 0.47 },
  // Dorso e ponta nasal.
  6: { x: 0.5, y: 0.42 },
  197: { x: 0.5, y: 0.44 },
  1: { x: 0.5, y: 0.505 },
  4: { x: 0.5, y: 0.515 },
  // Lábios.
  13: { x: 0.5, y: 0.565 },
  0: { x: 0.5, y: 0.555 },
  37: { x: 0.46, y: 0.56 },
  267: { x: 0.54, y: 0.56 },
  14: { x: 0.5, y: 0.6 },
  17: { x: 0.5, y: 0.615 },
  84: { x: 0.46, y: 0.605 },
  314: { x: 0.54, y: 0.605 },
  61: { x: 0.415, y: 0.58 },
  291: { x: 0.585, y: 0.58 },
  // Sulcos nasolabiais.
  206: { x: 0.425, y: 0.535 },
  187: { x: 0.4, y: 0.525 },
  426: { x: 0.575, y: 0.535 },
  411: { x: 0.6, y: 0.525 },
  // Ângulos mandibulares e mento.
  172: { x: 0.345, y: 0.63 },
  136: { x: 0.36, y: 0.645 },
  397: { x: 0.655, y: 0.63 },
  365: { x: 0.64, y: 0.645 },
  152: { x: 0.5, y: 0.69 },
  175: { x: 0.5, y: 0.675 },
  // Olheiras e têmporas.
  230: { x: 0.415, y: 0.4 },
  145: { x: 0.42, y: 0.405 },
  450: { x: 0.585, y: 0.4 },
  374: { x: 0.58, y: 0.405 },
  127: { x: 0.295, y: 0.375 },
  34: { x: 0.305, y: 0.385 },
  356: { x: 0.705, y: 0.375 },
  264: { x: 0.695, y: 0.385 },
};

// O Face Mesh tem 478 pontos; a tela só lê os índices acima, mas a lista
// precisa ter o comprimento certo para os índices baterem.
const LANDMARKS = Array.from({ length: 478 }, (_, i) => POSICOES[i] ?? { x: 0.5, y: 0.5 });

export function loadFaceLandmarker() {
  return Promise.resolve({
    detect: () => ({ faceLandmarks: [LANDMARKS] }),
  });
}

export function __resetFaceLandmarkerForTests(): void {}
