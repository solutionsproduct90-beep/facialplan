// Stand-in de src/hooks/useOfflineSessionDraft.ts para o harness de captura.
//
// O hook real lê e escreve um rascunho no IndexedDB e, enquanto houver um
// rascunho não sincronizado, a Etapa 1 mostra a faixa "Salvo neste
// dispositivo — aguardando conexão para sincronizar". Isso é comportamento
// correto do produto, mas num print de marketing vira uma mensagem de erro
// aparente. Aqui o rascunho já nasce carregado e vazio: nenhuma pendência,
// nenhuma faixa, e o restante da tela segue igual.

import type { SessionDraftData } from '../../../src/types/offlineDraft';

export function useOfflineSessionDraft() {
  return {
    draft: null as SessionDraftData | null,
    loaded: true,
    hasPendingDraft: false,
    isSyncing: false,
    saveDraft: () => {},
    clearDraft: () => {},
  };
}
