// Stand-in de @mediapipe/tasks-vision para o harness de captura.
//
// A Etapa 2 importa a biblioteca dinamicamente depois que a foto carrega, e
// ela baixa o modelo de landmarks da rede. No harness isso seria lento,
// dependente de rede e não-determinístico entre execuções. Recusando a
// inicialização, a tela cai no caminho de fallback que ela já tem
// (regionFallbackPosition, em src/lib/faceRegions.ts) e posiciona os pontos
// pelas coordenadas normalizadas da própria região — que é exatamente o que
// as fixtures já gravaram em stage2_overlay.

export const FilesetResolver = {
  forVisionTasks: async () => {
    throw new Error('landmarker desabilitado no harness de captura');
  },
};

export const FaceLandmarker = {
  createFromOptions: async () => {
    throw new Error('landmarker desabilitado no harness de captura');
  },
};
