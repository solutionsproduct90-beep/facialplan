// Captura as três telas do app usadas no material de marketing.
//
//   npm run screenshots
//
// Sobe o Vite do harness (vite.config.screenshots.ts), abre cada combinação
// tela × idioma num viewport de celular e salva o PNG em
// scripts/screenshots/out/. As telas são as de produção — o harness só troca
// a origem dos dados. Ver scripts/screenshots/README.md.

import { execFileSync, spawn } from 'node:child_process';
import { existsSync, mkdirSync, rmSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, 'out');
const PORT = 5199;
const BASE = `http://localhost:${PORT}`;

// iPhone 14 em pé. deviceScaleFactor 3 dá 1179×2556 no PNG — resolução de
// sobra para o mockup, que reduz bastante os celulares laterais.
const VIEWPORT = { width: 393, height: 852 };
const SCALE = 3;

// `scroll` desloca a tela antes do print, para quando o que conta a história
// não está no topo. Hoje as três telas abrem já no enquadramento certo, mas o
// suporte fica porque é o primeiro ajuste que se quer ao trocar a foto ou ao
// mudar a ordem dos blocos de uma tela.
const SCREENS = [
  { id: 'analise', nome: '1-analise', scroll: 0 },
  { id: 'simulacao', nome: '2-simulacao', scroll: 0 },
  { id: 'planificacao', nome: '3-planificacao', scroll: 0 },
];

const LANGS = ['pt', 'es', 'en'];

function startVite() {
  const proc = spawn(
    'npx',
    ['vite', '--config', 'vite.config.screenshots.ts', '--port', String(PORT), '--strictPort'],
    { cwd: path.resolve(here, '../..'), stdio: ['ignore', 'pipe', 'pipe'] },
  );

  return new Promise((resolve, reject) => {
    const falhou = setTimeout(() => reject(new Error('Vite não subiu em 60s')), 60_000);
    const onData = (chunk) => {
      const texto = chunk.toString();
      process.stdout.write(texto);
      if (texto.includes('ready in') || texto.includes(`localhost:${PORT}`)) {
        clearTimeout(falhou);
        resolve(proc);
      }
    };
    proc.stdout.on('data', onData);
    proc.stderr.on('data', (c) => process.stderr.write(c.toString()));
    proc.on('exit', (code) => {
      clearTimeout(falhou);
      reject(new Error(`Vite saiu com código ${code}`));
    });
  });
}

// Os retratos-placeholder não são versionados (ver .gitignore ao lado): num
// clone novo eles ainda não existem, e sem eles as três telas sairiam sem
// foto. Gerar aqui torna `npm run screenshots` auto-suficiente.
if (!existsSync(path.join(here, 'public', 'assets', 'paciente-antes.png'))) {
  console.log('Retratos-placeholder ausentes — gerando...');
  execFileSync('node', [path.join(here, 'gerarFoto.mjs')], { stdio: 'inherit' });
}

const vite = await startVite();

rmSync(outDir, { recursive: true, force: true });
mkdirSync(outDir, { recursive: true });

// O container traz o Chromium pré-instalado num caminho fixo, que pode não
// bater com a build que esta versão do Playwright procura por padrão. Apontar
// direto evita o "npx playwright install" (que o ambiente desencoraja).
const EXECUTABLE = process.env.CHROMIUM_PATH ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const browser = await chromium.launch({
  executablePath: existsSync(EXECUTABLE) ? EXECUTABLE : undefined,
  args: ['--no-sandbox', '--font-render-hinting=none'],
});
const erros = [];

try {
  for (const lang of LANGS) {
    const context = await browser.newContext({
      viewport: VIEWPORT,
      deviceScaleFactor: SCALE,
      isMobile: true,
      hasTouch: true,
      locale: lang === 'pt' ? 'pt-BR' : lang === 'es' ? 'es-ES' : 'en-US',
      colorScheme: 'light',
    });

    for (const screen of SCREENS) {
      const page = await context.newPage();
      // Um erro de console que quebre a tela não pode virar um PNG em branco
      // salvo em silêncio — a captura falha alto.
      page.on('pageerror', (err) => erros.push(`${screen.id}/${lang}: ${err.message}`));

      await page.goto(`${BASE}/?screen=${screen.id}&lang=${lang}`, { waitUntil: 'networkidle' });

      // Espera a foto do paciente estar decodificada: ela é o elemento que
      // mais atrasa e o que mais aparece no print.
      await page.waitForFunction(
        () => Array.from(document.images).every((img) => img.complete && img.naturalWidth > 0),
        null,
        { timeout: 20_000 },
      );
      // Margem para as transições de entrada (PageTransition) assentarem e
      // para o reposicionamento dos pontos pelos landmarks acontecer.
      await page.waitForTimeout(1200);

      if (screen.scroll) {
        await page.evaluate((y) => {
          const alvo = document.scrollingElement ?? document.documentElement;
          alvo.scrollTop = y;
          // O app rola num container próprio em algumas telas; se o documento
          // não rolou, rola o primeiro elemento que de fato tem overflow.
          if (alvo.scrollTop === 0) {
            const rolavel = Array.from(document.querySelectorAll('*')).find(
              (el) => el.scrollHeight > el.clientHeight + 40 && getComputedStyle(el).overflowY !== 'visible',
            );
            if (rolavel) rolavel.scrollTop = y;
          }
        }, screen.scroll);
        await page.waitForTimeout(500);
      }

      const arquivo = path.join(outDir, `facialplan-${screen.nome}-${lang}.png`);
      await page.screenshot({ path: arquivo });
      console.log(`✓ ${path.relative(process.cwd(), arquivo)}`);
      await page.close();
    }

    await context.close();
  }
} finally {
  await browser.close();
  vite.kill('SIGTERM');
}

if (erros.length) {
  console.error('\nErros de página durante a captura:');
  erros.forEach((e) => console.error(`  ${e}`));
  process.exit(1);
}

console.log(`\n${SCREENS.length * LANGS.length} capturas em ${outDir}`);
