# Capturas de tela para material de marketing

Gera prints verticais das três telas centrais do app, em PT, ES e EN, para
landing page, mockups e material de oferta.

```bash
npm run screenshots
```

Os PNGs saem em `scripts/screenshots/out/`, um por tela × idioma, a
1179×2556 (iPhone 14, `deviceScaleFactor` 3).

| Arquivo | Tela | O que mostra |
|---|---|---|
| `facialplan-1-analise-<lang>.png` | Etapa 1 | Foto do paciente, resumo e análise estrutural |
| `facialplan-2-simulacao-<lang>.png` | Etapa 3 | Antes/depois com a divisão visível |
| `facialplan-3-planificacao-<lang>.png` | Etapa 2 | Pontos de aplicação sobre o rosto, com legenda |

## Por que existe

As três telas exigem sessão autenticada, assinatura ativa, linhas em várias
tabelas e uma foto no Storage. Não dá para simplesmente abrir o app e
fotografar, e desenhar as telas à parte num editor cria um mockup que
envelhece na primeira mudança de UI.

Então o harness renderiza **os componentes de produção**
(`src/pages/SessaoEstagio1/2/3.tsx`), sem cópia nem reimplementação. O que ele
troca é só de onde vêm os dados, via aliases em `vite.config.screenshots.ts`:

| Módulo real | Stand-in | Por quê |
|---|---|---|
| `@/integrations/supabase/client` | `mocks/supabaseClient.ts` | Sessão de demonstração, sem rede nem banco |
| `@/contexts/AuthContext` | `mocks/AuthContext.tsx` | Profissional logado com assinatura ativa |
| `@/lib/faceLandmarker` | `mocks/faceLandmarker.ts` | Landmarks fixos: sem download de modelo, sem aviso de detecção falha, pontos sempre no mesmo lugar |
| `@/hooks/useOfflineSessionDraft` | `mocks/useOfflineSessionDraft.ts` | Sem rascunho local pendente, para não aparecer a faixa "aguardando conexão" |

`vite.config.ts` (o build de produção) não é tocado.

## Trocar a foto do paciente

O rosto usado é um **retrato-placeholder desenhado** por
`gerarFoto.mjs` — não é uma pessoa. Print de marketing com rosto real exige
autorização de uso de imagem, que é decisão de quem opera a clínica.

Para usar uma foto de verdade (paciente com autorização, ou modelo):

1. Substitua os dois arquivos em `scripts/screenshots/public/assets/`,
   mantendo os nomes `paciente-antes.png` e `paciente-depois.png`.
   Proporção 3:4, rosto centralizado, **mesma pessoa nos dois** — as três
   telas contam uma história só.
2. Ajuste as coordenadas de `mocks/faceLandmarker.ts` para os mesmos pontos
   anatômicos no novo rosto. Alternativa: remova esse alias de
   `vite.config.screenshots.ts` e deixe o MediaPipe detectar de verdade — aí
   os pontos se posicionam sozinhos, ao custo de depender de rede.
3. `npm run screenshots`.

## Ajustar o que aparece

- **Idiomas**: `LANGS` em `capture.mjs`. O app suporta `pt`, `en`, `es`,
  `fr`, `it`.
- **Enquadramento**: `scroll` por tela em `SCREENS`, se o bloco que interessa
  não estiver no topo.
- **Tamanho**: `VIEWPORT` e `SCALE` em `capture.mjs`.
- **Conteúdo clínico** (regiões, doses, justificativas, marcas, preços):
  `fixtures.ts`. Os formatos são os mesmos que a edge function `analyze-face`
  grava e que `sessions.stage2_overlay` guarda, então mexer ali não quebra as
  telas desde que os campos sejam preenchidos.

## Saída não versionada

`out/` e `public/assets/` estão no `.gitignore` deste diretório: os dois são
gerados, e binário que muda a cada ajuste de UI não pertence ao repositório.
`npm run screenshots` gera os retratos automaticamente se estiverem faltando.
