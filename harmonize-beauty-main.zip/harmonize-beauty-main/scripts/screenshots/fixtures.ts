// Dados de demonstração para as capturas de tela de marketing.
//
// Este arquivo NÃO faz parte do bundle do app — só do harness de captura
// (ver scripts/screenshots/README.md). Ele existe para que os prints usados
// em landing page e material de oferta venham das TELAS REAIS do produto,
// renderizadas pelo mesmo código que o profissional usa, e não de um mockup
// desenhado à parte que envelhece assim que a UI muda.
//
// Nenhum dado aqui é de paciente real: o nome é fictício e a foto é um
// retrato-placeholder gerado proceduralmente (ver gerarFoto.mjs). Trocar a
// foto por uma de paciente com autorização de imagem (ou de modelo) é
// substituir os dois arquivos em scripts/screenshots/assets/.

import type { ApplicationPoint, Stage1Analysis } from '../../src/types/harmonize';

export const DEMO_SESSION_ID = 'demo-session';
export const DEMO_PATIENT_ID = 'demo-patient';
export const DEMO_USER_ID = 'demo-professional';

export const DEMO_PATIENT_NAME = 'Marina Duarte';

/** Caminhos servidos pelo Vite a partir de scripts/screenshots/assets/. */
export const PHOTO_BEFORE = '/assets/paciente-antes.png';
export const PHOTO_AFTER = '/assets/paciente-depois.png';

// Análise da Etapa 1 no formato exato que a edge function analyze-face grava
// em sessions.stage1_analysis (ver o contrato no cabeçalho de
// supabase/functions/analyze-face/index.ts). `source: 'ai'` porque a tela
// carimba a proveniência — um print com 'mock' mostraria a faixa de
// demonstração, que não é o que a landing page deve comunicar.
export const DEMO_STAGE1_ANALYSIS: Stage1Analysis & { source: string } = {
  source: 'ai',
  suggestions: [
    {
      id: 'sug-malar-esq',
      region: 'malar_esquerda',
      label: 'Projeção malar esquerda',
      substance: 'acido_hialuronico',
      confidence: 0.86,
      quantitySuggested: 1,
      unit: 'ml',
      justification: {
        finding: 'Perda de projeção do terço médio à esquerda, com sombra infraorbital acentuada.',
        clinicalGoal: 'Devolver suporte ao compartimento malar e suavizar a transição pálpebra-bochecha.',
        technicalNote: 'Bolus supraperiosteal em ponto único, aspiração prévia, cânula 22G para a difusão lateral.',
      },
    },
    {
      id: 'sug-malar-dir',
      region: 'malar_direita',
      label: 'Projeção malar direita',
      substance: 'acido_hialuronico',
      confidence: 0.83,
      quantitySuggested: 1,
      unit: 'ml',
      justification: {
        finding: 'Assimetria de projeção em relação ao lado esquerdo, menos acentuada.',
        clinicalGoal: 'Equalizar a projeção bilateral respeitando a assimetria natural da paciente.',
        technicalNote: 'Mesma técnica do lado contralateral, com volume reduzido para não sobrecorrigir.',
      },
    },
    {
      id: 'sug-glabela',
      region: 'glabela',
      label: 'Rugas glabelares',
      substance: 'toxina_botulinica',
      confidence: 0.91,
      quantitySuggested: 20,
      unit: 'unidades',
      justification: {
        finding: 'Linhas glabelares visíveis em repouso, padrão em "V".',
        clinicalGoal: 'Reduzir a contração do complexo corrugador/prócero sem congelar a expressão.',
        technicalNote: 'Cinco pontos intramusculares, profundidade média, distribuição clássica.',
      },
    },
    {
      id: 'sug-terco-frontal',
      region: 'terco_frontal',
      label: 'Linhas frontais',
      substance: 'toxina_botulinica',
      confidence: 0.78,
      quantitySuggested: 12,
      unit: 'unidades',
      justification: {
        finding: 'Linhas horizontais dinâmicas no terço superior, sem sulco em repouso.',
        clinicalGoal: 'Suavizar a dinâmica preservando a elevação do supercílio.',
        technicalNote: 'Dose conservadora e pontos altos, para não induzir ptose de cauda.',
      },
    },
    {
      id: 'sug-labio-sup',
      region: 'labio_superior',
      label: 'Contorno do lábio superior',
      substance: 'acido_hialuronico',
      confidence: 0.74,
      quantitySuggested: 0.6,
      unit: 'ml',
      justification: {
        finding: 'Perda de definição do arco de Cupido e proporção 1:1,3 entre lábios.',
        clinicalGoal: 'Redefinir o contorno mantendo a proporção natural do terço inferior.',
        technicalNote: 'Retroinjeção linear no vermelhão, produto de baixa coesividade.',
      },
    },
  ],
  patientSummary:
    'O plano propõe devolver suporte ao terço médio e suavizar as linhas de expressão do terço superior, mantendo as características naturais do rosto.',
  facialAnalysis: {
    shape: 'Oval alongado, com boa definição do ângulo mandibular.',
    symmetry: 'Assimetria leve à direita, dentro da variação natural.',
    proportions: 'Terço médio discretamente encurtado em relação ao inferior.',
  },
  facialThirds: {
    upper: 'Linhas dinâmicas presentes, sem sulco estático.',
    middle: 'Perda de projeção malar bilateral, mais evidente à esquerda.',
    lower: 'Contorno labial com perda de definição; mento equilibrado.',
  },
  skinTexture: 'Pele normal a mista, com textura regular e sem lesões aparentes.',
  attentionPoints: [
    'Sulco nasolabial acompanha a perda de suporte malar — reavaliar após o preenchimento do terço médio.',
    'Assimetria de supercílio pré-existente deve ser apontada à paciente antes da aplicação.',
  ],
  analysisLimitations:
    'Leitura feita a partir de foto estática frontal. Não substitui exame presencial nem avaliação dinâmica.',
};

// Plano da Etapa 2 no formato ApplicationPoint[] (sessions.stage2_overlay).
// As posições x/y são as mesmas que a tela usaria como fallback quando a
// detecção de landmarks não roda — ver FACE_REGIONS em src/lib/faceRegions.ts.
export const DEMO_STAGE2_OVERLAY: ApplicationPoint[] = [
  {
    id: 'pt-malar-esq',
    region: 'malar_esquerda',
    label: 'Região Malar Esquerda',
    substance: 'acido_hialuronico',
    quantity: 1,
    unit: 'ml',
    x: 0.25,
    y: 0.46,
    confidence: 0.86,
    source: 'ai',
    insumoId: 'insumo-ah',
    technique: 'bolus',
    depth: 'supraperiosteal',
    device: 'agulha',
    justification: DEMO_STAGE1_ANALYSIS.suggestions[0].justification,
  },
  {
    id: 'pt-malar-dir',
    region: 'malar_direita',
    label: 'Região Malar Direita',
    substance: 'acido_hialuronico',
    quantity: 1,
    unit: 'ml',
    x: 0.75,
    y: 0.46,
    confidence: 0.83,
    source: 'ai',
    insumoId: 'insumo-ah',
    technique: 'bolus',
    depth: 'supraperiosteal',
    device: 'agulha',
    justification: DEMO_STAGE1_ANALYSIS.suggestions[1].justification,
  },
  {
    id: 'pt-glabela',
    region: 'glabela',
    label: 'Glabela',
    substance: 'toxina_botulinica',
    quantity: 20,
    unit: 'unidades',
    x: 0.5,
    y: 0.34,
    confidence: 0.91,
    source: 'ai',
    insumoId: 'insumo-toxina',
    technique: 'intramuscular',
    depth: 'intramuscular',
    device: 'agulha',
    justification: DEMO_STAGE1_ANALYSIS.suggestions[2].justification,
  },
  {
    id: 'pt-terco-frontal',
    region: 'terco_frontal',
    label: 'Terço Frontal',
    substance: 'toxina_botulinica',
    quantity: 12,
    unit: 'unidades',
    x: 0.5,
    y: 0.2,
    confidence: 0.78,
    source: 'ai',
    insumoId: 'insumo-toxina',
    technique: 'intramuscular',
    depth: 'intramuscular',
    device: 'agulha',
    justification: DEMO_STAGE1_ANALYSIS.suggestions[3].justification,
  },
  {
    id: 'pt-labio-sup',
    region: 'labio_superior',
    label: 'Lábio Superior',
    substance: 'acido_hialuronico',
    quantity: 0.6,
    unit: 'ml',
    x: 0.5,
    y: 0.62,
    confidence: 0.74,
    source: 'ai',
    insumoId: 'insumo-ah',
    technique: 'linear_retrograda',
    depth: 'dermico_profundo',
    device: 'agulha',
    justification: DEMO_STAGE1_ANALYSIS.suggestions[4].justification,
  },
];

/** Linhas de `insumos` como o PostgREST devolve (snake_case). */
export const DEMO_INSUMOS = [
  {
    id: 'insumo-ah',
    substance: 'acido_hialuronico',
    brand_name: 'Restylane Lyft',
    cost_per_unit: 620,
    price_per_unit: 1450,
    active: true,
  },
  {
    id: 'insumo-toxina',
    substance: 'toxina_botulinica',
    brand_name: 'Botox Allergan',
    cost_per_unit: 14,
    price_per_unit: 38,
    active: true,
  },
  {
    id: 'insumo-bio',
    substance: 'bioestimulador',
    brand_name: 'Sculptra',
    cost_per_unit: 1100,
    price_per_unit: 2400,
    active: true,
  },
];

export const DEMO_PROFILE = {
  id: DEMO_USER_ID,
  full_name: 'Dra. Camila Rocha',
  clinic_name: 'Studio Camila Rocha',
  logo_url: null,
  labor_fee_per_session: 350,
  max_installments: 12,
  cash_discount_pct: 10,
  currency: 'BRL',
  pre_post_care_instructions: null,
  role: 'professional',
  is_blocked: false,
  subscription_status: 'active',
  past_due_since: null,
};

export const DEMO_PATIENT = {
  id: DEMO_PATIENT_ID,
  name: DEMO_PATIENT_NAME,
  email: 'marina@exemplo.com',
  consent_given: true,
  last_consent_at: '2026-09-02T14:10:00.000Z',
  ai_data_consent_status: 'granted',
  marketing_consent_status: 'granted',
};

export const DEMO_SESSION = {
  id: DEMO_SESSION_ID,
  patient_id: DEMO_PATIENT_ID,
  professional_id: DEMO_USER_ID,
  status: 'stage3',
  selected_procedure: null,
  stage1_analysis: DEMO_STAGE1_ANALYSIS,
  stage2_overlay: DEMO_STAGE2_OVERLAY,
  original_image_url: 'demo/antes.png',
  simulation_url: 'demo/depois.png',
  simulation_intensity: 'natural',
  created_at: '2026-09-15T13:30:00.000Z',
  pdf_url: null,
};

export const DEMO_ANAMNESIS = {
  id: 'demo-anamnesis',
  patient_id: DEMO_PATIENT_ID,
  created_at: '2026-09-10T09:00:00.000Z',
  updated_at: '2026-09-10T09:00:00.000Z',
  anticoagulant_use: false,
  autoimmune_disease: false,
  pregnant_or_breastfeeding: false,
  metal_implant_or_pacemaker: false,
  previous_adverse_reaction: false,
  keloid_history: false,
  active_infection: false,
  chronic_conditions: null,
  medications: null,
  allergies: null,
};

export const DEMO_CONSENT = {
  created_at: '2026-09-15T13:52:00.000Z',
  consent_text: 'Termo de consentimento livre e esclarecido para o procedimento planejado.',
  ip_address: '189.45.10.22',
};
