// Contrato das variáveis de ambiente exigidas por um build de PRODUÇÃO.
//
// Por que este arquivo existe: até esta rodada, esquecer uma variável de
// build não produzia nenhum vermelho. O `vite build` substitui uma leitura de
// `import.meta.env` ausente por `undefined` e termina com sucesso; o
// `scripts/prerender.mjs` imprimia "VITE_SITE_URL não definida — pulando
// sitemap.xml/robots.txt" e saía com código 0. O resultado é o pior modo de
// falha possível para um produto tocado por um operador só: o deploy fica
// verde, o site sobe, e o estrago (nenhum sitemap, nenhuma canonical, o SEO
// pré-renderizado de 26 páginas invisível para o Google) só aparece semanas
// depois, quando alguém repara que o blog nunca foi indexado.
//
// Este módulo é a lista única dessas variáveis, consumida por dois pontos
// diferentes do mesmo build:
//   - vite.config.ts        — falha ANTES de bundlar (feedback em ~1s em vez
//                             de ~20s, e antes de emitir um dist quebrado);
//   - scripts/prerender.mjs — falha de novo, porque o script também pode ser
//                             rodado sozinho (`node scripts/prerender.mjs`).
//
// Mantido em JavaScript puro (.mjs, sem dependência nenhuma) de propósito: o
// prerender roda em Node cru, fora do pipeline do Vite, e não tem como
// importar TypeScript. A resolução do VALOR de cada variável fica com quem
// chama — os dois já importam o `loadEnv` do Vite, que é o único jeito de ler
// exatamente o que `import.meta.env` enxergaria (arquivos .env + .env.local +
// process.env, nessa precedência). Ver scripts/buildEnv.d.mts para os tipos.

/**
 * Variáveis sem as quais um build de produção não deve nascer.
 *
 * O critério para entrar aqui é estreito: a ausência tem de causar uma falha
 * SILENCIOSA em produção. Variável cuja ausência degrada de forma visível e
 * deliberada (VITE_HOTMART_CHECKOUT_URL desativa o botão de assinar e mostra
 * "em breve", VITE_CONTACT_EMAIL some o bloco de contato, VITE_VAPID_PUBLIC_KEY
 * deixa o push indisponível) NÃO entra — exigi-las impediria um deploy legítimo
 * de pré-lançamento. Essas estão documentadas como opcionais no .env.example e
 * cobradas no checklist de docs/runbook-producao.md.
 */
export const REQUIRED_BUILD_ENV = [
  {
    name: 'VITE_SITE_URL',
    purpose: 'URL pública canônica do app, sem barra no final (ex.: https://facialplan.com).',
    breaks:
      'scripts/prerender.mjs pula sitemap.xml e a linha "Sitemap:" do robots.txt, e as páginas ' +
      'pré-renderizadas saem sem <link rel="canonical">, sem hreflang e sem og:url — ou seja, ' +
      'todo o SEO institucional/blog sobe invisível para os crawlers.',
    where: 'Variável de ambiente do host (na Vercel: Settings > Environment Variables) ou .env local.',
  },
  {
    name: 'VITE_SUPABASE_URL',
    purpose: 'URL da API do projeto Supabase (https://<project-ref>.supabase.co).',
    breaks:
      'createClient() recebe undefined em src/integrations/supabase/client.ts e lança ' +
      '"supabaseUrl is required" no primeiro import — tela branca no navegador e falha na ' +
      'pré-renderização.',
    where: 'Supabase > Project Settings > API > Project URL.',
  },
  {
    name: 'VITE_SUPABASE_PUBLISHABLE_KEY',
    purpose: 'Chave publicável (anon) do projeto Supabase — é pública por definição, vai no bundle.',
    breaks:
      'Mesmo caminho do VITE_SUPABASE_URL: o client do Supabase não é construído e o app inteiro ' +
      'morre no import, incluindo as telas públicas de paciente (anamnese, apresentação, feedback).',
    where: 'Supabase > Project Settings > API > anon/public key. NUNCA a service_role.',
  },
];

/**
 * Lista as variáveis obrigatórias ausentes do `env` recebido.
 *
 * Trata string vazia como ausente de propósito: `VITE_SITE_URL=` num .env é o
 * erro de digitação mais provável, e uma string vazia produziria exatamente o
 * mesmo dano que a variável não existir (URLs montadas como "/sitemap.xml").
 */
export function findMissingBuildEnv(env) {
  return REQUIRED_BUILD_ENV.filter((entry) => String(env?.[entry.name] ?? '').trim() === '');
}

/** Monta a mensagem de erro — uma variável por bloco, dizendo o que quebra e onde obter. */
export function formatMissingBuildEnv(missing) {
  const blocks = missing.map(
    (entry) =>
      `  - ${entry.name}\n` +
      `      Para que serve: ${entry.purpose}\n` +
      `      Sem ela: ${entry.breaks}\n` +
      `      Onde definir: ${entry.where}`,
  );

  return [
    'Build de produção interrompido: variável de ambiente obrigatória ausente.',
    '',
    ...blocks,
    '',
    'Copie .env.example para .env (ou defina as variáveis no painel do host) e rode de novo.',
    'Passo a passo completo de deploy: docs/runbook-producao.md.',
    '',
    'Para um build local que não precisa disso, use `npm run build:dev` — ele não',
    'pré-renderiza nada e por isso não tem compromisso de SEO a cumprir.',
  ].join('\n');
}

/**
 * Interrompe o build quando falta variável obrigatória.
 *
 * Lança em vez de `process.exit()` para que o erro apareça pelo caminho normal
 * de erro de quem chama (o overlay/stack do Vite no config, o `.catch()` do
 * prerender) — e para que dê para testar sem derrubar o processo do vitest.
 */
export function assertRequiredBuildEnv(env) {
  const missing = findMissingBuildEnv(env);
  if (missing.length === 0) return;
  throw new Error(formatMissingBuildEnv(missing));
}
