// Tipos escritos à mão para scripts/buildEnv.mjs.
//
// O módulo precisa ser .mjs (é importado pelo scripts/prerender.mjs, que roda
// em Node cru e não passa por transpilação), mas é importado também por
// vite.config.ts e por src/test/envContract.test.ts — ambos passam pelo `tsc`.
// Sem esta declaração o `npx tsc --noEmit -p tsconfig.app.json` reclamaria de
// módulo JavaScript sem tipos (allowJs está desligado no tsconfig.app.json).

export interface RequiredBuildEnvEntry {
  /** Nome exato da variável, como aparece no .env.example. */
  name: string;
  /** Para que serve, em uma frase. */
  purpose: string;
  /** O que quebra em produção sem ela. */
  breaks: string;
  /** Onde se obtém/define o valor. */
  where: string;
}

export declare const REQUIRED_BUILD_ENV: RequiredBuildEnvEntry[];

export declare function findMissingBuildEnv(
  env: Record<string, string | undefined> | undefined,
): RequiredBuildEnvEntry[];

export declare function formatMissingBuildEnv(missing: RequiredBuildEnvEntry[]): string;

export declare function assertRequiredBuildEnv(
  env: Record<string, string | undefined> | undefined,
): void;
