// Listener de Web Push injetado no service worker gerado pelo
// vite-plugin-pwa (ver `workbox.importScripts` em vite.config.ts). Plain JS
// de propósito — roda dentro do mesmo escopo de service worker que o
// Workbox usa para o cache do app shell, sem precisar migrar para o modo
// "injectManifest" do plugin só para isso.
//
// `event.data` é o corpo binário decifrado que o navegador já entrega
// pronto (a decifragem do payload, feita pelo próprio navegador conforme
// RFC 8291/8188, acontece ANTES do service worker receber o evento — o
// backend nunca manda texto plano pela rede, ver
// supabase/functions/_shared/webPush.ts). O JSON dentro é o mesmo objeto
// `{ title, body, url? }` montado em sendWebPush().
self.addEventListener("push", (event) => {
  let payload = { title: "FacialPlan", body: "Você tem uma nova notificação." };
  try {
    if (event.data) {
      const parsed = event.data.json();
      if (parsed && typeof parsed === "object") {
        payload = {
          title: typeof parsed.title === "string" && parsed.title ? parsed.title : payload.title,
          body: typeof parsed.body === "string" && parsed.body ? parsed.body : payload.body,
          url: typeof parsed.url === "string" ? parsed.url : undefined,
        };
      }
    }
  } catch {
    // Payload em formato inesperado (não JSON) — mostra a notificação
    // genérica acima em vez de deixar o evento sem nenhuma notificação
    // (alguns navegadores penalizam/desativam push do site que recebe um
    // evento `push` sem chamar `showNotification`).
  }

  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: "/pwa-192x192.png",
      badge: "/pwa-192x192.png",
      data: { url: payload.url || "/" },
    })
  );
});

// Clique na notificação: foca uma aba já aberta do app se existir, ou abre
// uma nova na URL indicada pelo payload (ex. a ficha do paciente com
// retorno atrasado) — sem isso o clique só fecharia a notificação sem levar
// a lugar nenhum.
self.addEventListener("notificationclick", (event) => {
  const targetUrl = (event.notification.data && event.notification.data.url) || "/";
  event.notification.close();

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if ("focus" in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
