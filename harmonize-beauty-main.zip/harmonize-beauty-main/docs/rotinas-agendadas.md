# Rotinas agendadas

## O problema que isto resolve

Até esta mudança o FacialPlan **não tinha agendador nenhum**. Duas edge functions
prontas, testadas e mescladas nunca eram invocadas:

| Function | O que faz | O que acontecia sem agendador |
|---|---|---|
| `send-reengagement-reminders` | Varre sessões abandonadas e envia e-mail de reengajamento ao paciente | Nenhum e-mail saía, nunca |
| `notify-overdue-returns` | Avisa o profissional, por push, dos retornos de manutenção atrasados | Nenhum push saía, nunca |
| `alert-error-spike` | Resume `error_logs` e avisa os admins por e-mail quando algo falha | Não existia — erro em produção só aparecia para quem abrisse o painel |

Os comentários no topo das duas já registravam a pendência ("este projeto ainda
não tem nenhum agendador configurado"). São duas features entregues que em
produção não fariam absolutamente nada — e ninguém receberia erro, porque não
há erro: simplesmente nada é chamado.

## Como funciona agora

`.github/workflows/rotinas-agendadas.yml` faz um `POST` em cada function com o
header `x-scheduler-token`, em duas frequências:

| Quando | Rotinas |
|---|---|
| **De hora em hora** (`25 * * * *`) | `alert-error-spike` |
| **Diariamente às 11:00 UTC** (08:00 em Brasília) | todas as três |

A separação é deliberada. Um secret expirado ou uma API de IA fora do ar
precisa ser descoberto em uma hora, não no dia seguinte — enquanto mandar
e-mail de reengajamento 24 vezes por dia seria spam. As rotinas diárias são
puladas no disparo horário via `if: github.event.schedule != '25 * * * *'`.

### Observabilidade: por que o alerta existe

`error_logs` existe desde a primeira migration e tem tela no Admin, mas o log
é **passivo**: só mostra o que já aconteceu, para quem por acaso abrir. Em
produção, um secret expirado ou um webhook quebrado ficaria invisível até um
profissional reclamar — para um produto tocado por um operador só, é o pior
modo de falha possível: silencioso, e descoberto pelo cliente.

Três decisões dessa rotina que valem saber:

- **O e-mail nunca carrega `error_logs.message`, `professional_id` ou
  `session_id`.** `message` recebe texto de exceção da aplicação inteira e
  pode conter nome de paciente ou trecho de payload clínico; e-mail sai do
  perímetro do sistema e fica numa caixa de entrada para sempre. O alerta diz
  *o que* está falhando e *com que intensidade*; o detalhe fica no painel,
  atrás de autenticação.
- **Ocorrência esperada não alerta.** `subscription_inactive`,
  `consent_missing` e `rate_limited` são o paywall, o gate de consentimento e
  o rate limit funcionando. Alertar sobre eles produziria fadiga, e alerta que
  se aprende a ignorar é pior que alerta nenhum. Note que
  `rate_limit_not_evaluated` **alerta** — esse é o rate limit tendo deixado de
  funcionar.
- **O ponteiro de leitura fica em `ops_alert_state.last_seen_at`**, não numa
  janela relativa a `now()`. A rotina pode atrasar na fila de cron, falhar e
  ser reexecutada, ou ser disparada manualmente; em todos os casos ela olha
  exatamente o intervalo que ainda não olhou, sem pular nem duplicar.

Os destinatários são os `profiles` com `role = 'admin'` e e-mail preenchido —
sem secret novo, justamente para não existir um endereço configurado uma vez
e esquecido apontando para alguém que saiu. Sem admin com e-mail, ou sem
`RESEND_API_KEY`, a rotina registra `error_digest_no_recipient` /
`error_digest_missing_api_key`: o alerta sobre o alerta.

Também dá para disparar manualmente pela aba **Actions > Rotinas agendadas >
Run workflow** — é assim que se testa sem esperar o dia seguinte.

## Configuração (obrigatória antes do lançamento)

Sem estes passos o workflow falha alto, de propósito: um agendamento que
parece rodar e não roda é pior que um vermelho visível.

### 0. O arquivo precisa estar no branch PADRÃO

**O GitHub só agenda `cron` a partir do branch padrão do repositório.** Um
workflow que existe apenas num branch de feature nunca dispara pelo horário, e
o botão *Run workflow* (`workflow_dispatch`) também não aparece — o GitHub lê a
lista de workflows do branch padrão para montar a aba Actions.

Isto merece o primeiro lugar da lista porque é o caso extremo do princípio
acima, e o único aqui que **não** falha alto: não há job vermelho, não há log,
não há linha em `error_logs`. Simplesmente nada acontece. Dá para gerar o
token, cadastrar os dois secrets, ver o arquivo no repositório e concluir que o
agendador está de pé — sem que ele exista.

No momento em que este documento foi escrito,
`.github/workflows/rotinas-agendadas.yml` estava apenas no branch de trabalho.
Confira antes de tudo:

```bash
git fetch origin
git cat-file -e origin/<branch-padrao>:.github/workflows/rotinas-agendadas.yml \
  && echo "no branch padrão" || echo "AINDA NÃO — as rotinas não rodam"
```

Se o retorno for o segundo, o passo que falta não é de configuração: é mesclar.

### 1. Gerar o token

```bash
openssl rand -base64 48
```

### 2. Registrar o token nos dois lados

No Supabase (o mesmo projeto onde as functions estão publicadas):

```bash
supabase secrets set SCHEDULER_TOKEN='<valor gerado>'
```

No GitHub, em **Settings > Secrets and variables > Actions > New repository
secret**:

| Secret | Valor |
|---|---|
| `SCHEDULER_TOKEN` | exatamente o mesmo valor do comando acima |
| `SUPABASE_FUNCTIONS_URL` | `https://<project-ref>.supabase.co/functions/v1` |

> `<project-ref>` depende de qual projeto Supabase é o de produção — hoje há
> uma divergência aberta entre o `project_id` em `supabase/config.toml` e o
> `VITE_SUPABASE_URL` do `.env`. Resolva isso antes.

### 3. Verificar

Primeiro confirme que o workflow **aparece** na aba Actions do repositório. Se
não aparecer, volte ao passo 0 — nenhum secret resolve isso.

Depois dispare o workflow manualmente (*Run workflow*) e confira:

- o job termina verde;
- em **Admin > Log de Erros** não aparece nenhum `scheduler_auth_*`.

O disparo manual valida token, URL e as três functions de uma vez, mas **não**
prova que o agendamento por horário está ativo — só a presença no branch padrão
faz isso. Na dúvida, volte um dia depois e confira em Actions se houve execução
com o gatilho `schedule`.

Se aparecer `scheduler_auth_not_configured`, o secret existe no GitHub mas não
no Supabase. Se aparecer `scheduler_auth_mismatch`, os dois valores não são
iguais.

## Por que um token dedicado e não a service role key

As duas functions já aceitavam `Authorization: Bearer <SERVICE_ROLE_KEY>`, e
mandar isso do Actions teria sido mais curto. Teria sido também a decisão
errada.

A service role key ignora RLS por definição: ela lê e escreve qualquer linha de
qualquer profissional — todo prontuário, toda foto, todo dado de paciente do
produto. Guardá-la num secret de GitHub amplia a superfície de vazamento muito
além do agendamento: qualquer pessoa com permissão de escrita no repositório
pode abrir um PR com um workflow que imprime o secret, e um comprometimento da
conta do GitHub vira um comprometimento total do banco.

O `SCHEDULER_TOKEN` serve só para dizer "esta chamada veio do agendador".
Vazado, o estrago máximo é alguém disparar as rotinas fora de hora — e as duas
são idempotentes (`sessions.reminder_sent_at` e
`sessions.return_reminder_sent_at`), então uma segunda execução no mesmo dia
não reenvia nada.

Os três caminhos de autorização aceitos hoje por essas functions, em ordem de
privilégio:

1. `x-scheduler-token` — só dispara as rotinas. É o que o agendador usa.
2. JWT de um usuário com `profiles.role = 'admin'` — disparo manual pelo painel.
3. `Authorization: Bearer <SERVICE_ROLE_KEY>` — mantido por compatibilidade;
   não use em agendador.

## Rotação do token

Trocar o token é seguro a qualquer momento, desde que na ordem certa:

1. gere o novo valor;
2. `supabase secrets set SCHEDULER_TOKEN=<novo>`;
3. atualize o secret no GitHub.

Entre os passos 2 e 3 uma execução agendada falharia com
`scheduler_auth_mismatch`. Como a rotina é diária e idempotente, faça a troca
logo depois da execução das 11:00 UTC e não há janela real de perda.

## Quando migrar para pg_cron

O GitHub Actions foi escolhido por ficar versionado, por o projeto já usar
Actions e por não depender de habilitar extensão no painel do Supabase. Ele
tem duas limitações conhecidas:

- o GitHub não garante o minuto exato de disparo (a fila de cron atrasa em
  horários de pico) — irrelevante para uma rotina diária e idempotente;
- o segredo vive fora do banco.

`pg_cron` + `pg_net`, rodando dentro do próprio Postgres, resolve os dois e é o
caminho natural quando houver volume que exija horário previsível ou frequência
maior que diária. A troca é localizada: as functions não mudam, só quem as
chama.

## Ao adicionar uma rotina nova

1. A function aceita `x-scheduler-token` via `checkSchedulerAuth()` de
   `supabase/functions/_shared/schedulerAuth.ts`.
2. A rotina é **idempotente** — o agendador pode repetir a chamada (retry do
   curl, disparo manual, re-execução do job).
3. A resposta devolve **contadores agregados, nunca dado de paciente**: o corpo
   é impresso no log do Actions, que é legível por quem tem acesso ao repo.
4. O passo novo entra no workflow com `if: always()`, para que a falha de uma
   rotina não impeça as seguintes.
