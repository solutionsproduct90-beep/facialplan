# Plano de teste adversarial — IA de pontos faciais e simulação

## Contexto e escopo

Item de backlog: **"Validação da IA/MediaPipe com casos adversos"** (P2). O
achado original era que a detecção de landmarks faciais (`@mediapipe/tasks-vision`,
usada no Estágio 2 — editor de pontos, ver `src/lib/faceLandmarker.ts` e
`src/pages/SessaoEstagio2.tsx`) nunca foi validada com casos do mundo real que
fogem do "rosto de frente, bem iluminado, sem obstrução": peles de tons mais
escuros, ângulos ruins, óculos, maquiagem pesada.

**Este documento não é um relatório de validação** — ele foi escrito num
ambiente sem acesso a um banco de fotos de teste reais (nem de pacientes
reais nem sintéticas variadas o suficiente para cobrir os casos abaixo com
seriedade). Gerar ou obter esse banco de imagens está fora do alcance de um
agente autônomo neste ambiente. O que este documento entrega:

1. Um **roteiro estruturado de teste manual** que o QA Contínuo (papel
   autônomo recorrente) ou qualquer pessoa do time pode seguir assim que
   tiver acesso a fotos de teste reais (banco próprio, fotos de consentimento
   de pacientes de teste, ou um dataset público de rostos diversos).
2. O que muda no comportamento do app quando a IA "erra" ou "não sabe": o
   código foi revisado e reforçado (ver seção "O que já está tratado hoje")
   para que uma detecção ruim degrade graciosamente com aviso, em vez de
   travar ou de posicionar pontos errados silenciosamente.

Três superfícies de IA estão em escopo:

| Superfície | Onde roda | O que faz |
|---|---|---|
| Detecção de landmarks (MediaPipe) | Client-side, Estágio 2 (`src/lib/faceLandmarker.ts`) | Localiza ~478 pontos de referência no rosto da foto pra reposicionar os pontos de aplicação sugeridos pela IA em cima do rosto real |
| `analyze-face` (Edge Function) | Servidor, Estágio 1 | Envia a foto pra Claude (Anthropic) e recebe de volta região/substância/quantidade sugeridas |
| `generate-simulation` (Edge Function) | Servidor, Estágio 3 | Envia a foto + pontos aceitos pra Gemini (Google) e recebe uma imagem "depois" simulada |

## O que já está tratado hoje (não duplicar)

A detecção de landmarks do MediaPipe **não expõe um score de confiança por
rosto** — a API (`FaceLandmarker.detect()`) devolve ou uma lista de ~478
landmarks, ou uma lista vazia; não existe um "achei o rosto mas com pouca
certeza". Dado esse limite da lib, o tratamento possível (e já implementado)
é:

- Se **nenhum landmark for encontrado** (`result.faceLandmarks` vazio) — foto
  de ângulo muito ruim, muito escura, rosto fora do enquadramento etc. — os
  pontos de aplicação permanecem nas posições genéricas de fallback (não
  ajustadas ao rosto real, ver `regionFallbackPosition` em
  `src/lib/faceRegions.ts`) e o app:
  - mostra um **toast** imediato (`toastFaceNotDetected`);
  - mostra um **banner persistente** na tela do Estágio 2, visível até a
    página ser recarregada (`sessions.stage2.detectionWarningBanner`),
    reforçando que os pontos precisam de conferência manual antes de
    prosseguir. Esse banner foi adicionado nesta leva porque um toast sozinho
    é transitório — o profissional pode não vê-lo e confiar sem perceber que
    os pontos não foram alinhados ao rosto da foto.
- Se **o carregamento do modelo/WASM falhar** (ex.: erro de rede no CDN) —
  mesmo tratamento acima, com o toast `toastFaceDetectionUnavailable`.
- Se **a própria foto falhar ao carregar** (`<img onError>`) — toast
  `toastPhotoLoadError`, mesmo banner de aviso.
- Em nenhum desses casos o app trava: os pontos continuam arrastáveis
  manualmente, e a sessão pode prosseguir.

O que a lib **não permite** detectar sem imagens reais para calibrar: uma
detecção "encontrou landmarks, mas nas posições erradas" (ex.: por causa de
óculos escuros, maquiagem pesada ou ângulo extremo que engana o modelo sem
zerar a detecção). Não existe um sinal de baixa confiança de posição vindo da
lib para isso — só uma inspeção visual humana pega esse caso. É exatamente
para isso que este roteiro manual existe: a única forma de saber se os
pontos "encontrados" fazem sentido nesses casos é o QA olhar a foto lado a
lado com os pontos renderizados.

## Como rodar este roteiro

Pré-requisito: um pequeno banco de fotos de teste (pode ser um conjunto de
fotos próprias/de consentimento, ou rostos sintéticos gerados por IA
representando cada categoria abaixo — não usar fotos de pacientes reais sem
consentimento explícito para uso em teste).

Para cada foto de teste, percorra o fluxo real do app:

1. **Nova Sessão** → upload da foto de teste.
2. **Estágio 1** (`analyze-face`) → observe a sugestão da IA.
3. **Estágio 2** (MediaPipe + editor de pontos) → observe a detecção de
   landmarks e o posicionamento dos pontos sugeridos.
4. **Estágio 3** (`generate-simulation`) → observe a imagem simulada gerada.

Para cada caso da tabela abaixo, registre: o que aconteceu de fato, se bateu
com o comportamento esperado, e (se não bateu) abra um item de backlog
com prints antes/depois.

## Matriz de casos adversos

### 1. Pele de tons mais escuros (escala Fitzpatrick IV-VI)

| Superfície | O que testar | Comportamento esperado |
|---|---|---|
| Detecção de landmarks | Testar com pelo menos 3 fotos de tons de pele variados (claro, médio, escuro), mesmo ângulo/iluminação nas três. Comparar se os 478 pontos ficam igualmente bem alinhados nas três, especialmente contorno de lábios, sobrancelha e mandíbula (regiões de menor contraste em peles escuras com iluminação ruim). | **Deve funcionar bem** com iluminação adequada — modelos MediaPipe modernos são treinados em datasets diversos. Se a detecção degradar visivelmente (pontos deslocados) só em tons mais escuros, é um viés de dataset a documentar — comportamento esperado nesse caso: **degradar graciosamente** (banner de aviso já cobre a falha total; abrir item de backlog se a falha for silenciosa, ou seja, landmarks encontrados mas visivelmente errados). |
| `analyze-face` | Mesmas 3 fotos — comparar se a qualidade/plausibilidade das regiões e quantidades sugeridas pela Claude varia por tom de pele. | Deve sugerir regiões/quantidades clinicamente equivalentes para o mesmo rosto/expressão independente do tom de pele. Divergência sistemática = achado de viés a escalar, não um bug de UI. |
| `generate-simulation` | Mesmas 3 fotos — avaliar se a simulação gerada pela Gemini preserva o tom de pele original e não introduz artefatos (clareamento, banding, mudança de textura) mais em peles escuras. | Simulação deve preservar o tom de pele do paciente. Se houver clareamento/distorção sistemática, é falha grave (produto que "embranquece" pacientes é inaceitável) — reportar como P0, não P2. |

### 2. Ângulos de câmera ruins

Casos: **perfil quase total** (>60° de rotação), **de baixo pra cima**
(ângulo de queixo/contrapicada), **de cima pra baixo** (câmera acima da
cabeça), **foto levemente inclinada** (rosto não alinhado ao horizonte).

| Superfície | O que testar | Comportamento esperado |
|---|---|---|
| Detecção de landmarks | Uma foto por variação de ângulo listada acima. | Perfil >60°: MediaPipe frequentemente **não encontra rosto algum** — deve cair no fluxo já tratado (toast + banner persistente + fallback manual). Ângulos moderados (15-45°, baixo/cima): pode encontrar landmarks, mas deslocados nas bordas do rosto — QA deve inspecionar visualmente se os pontos parecem plausíveis; se não, é um **falso "sucesso"** (a UI não mostra aviso porque achou *algum* landmark) — comportamento esperado é o profissional notar visualmente e reposicionar manualmente, já que a UI sempre permite arrastar pontos livremente. |
| `analyze-face` | Mesmas fotos — a IA de análise deve reconhecer que o ângulo é ruim e não inventar regiões/quantidades como se fosse uma foto frontal ideal. | Ideal: a IA responder com sugestões mais conservadoras ou uma observação textual sobre o ângulo (se o prompt já pedir isso — conferir `supabase/functions/analyze-face/index.ts`). Se não houver esse tipo de ressalva hoje, é uma melhoria futura a registrar, não um bug bloqueante. |
| `generate-simulation` | Ângulos extremos tendem a gerar simulações com artefatos (rosto distorcido, feições "erradas"). | Simulação com ângulo extremo pode falhar ou ficar visivelmente ruim — **aceitável degradar** desde que não trave a Etapa 3; se a Edge Function retornar erro, o app deve mostrar mensagem de erro clara (conferir tratamento de erro na tela do Estágio 3), não uma tela em branco/travada. |

### 3. Uso de óculos (grau e escuros)

| Superfície | O que testar | Comportamento esperado |
|---|---|---|
| Detecção de landmarks | Uma foto com óculos de grau (armação fina), uma com óculos escuros (lentes escuras cobrindo os olhos). | Óculos de grau: geralmente não atrapalha muito — landmarks de olho podem ficar levemente deslocados pelo reflexo/aro. Óculos escuros: MediaPipe pode falhar em landmarks da região dos olhos especificamente (as lentes escondem a íris) — pontos de regiões próximas aos olhos (ex. "olheiras", "pé de galinha") devem ser conferidos manualmente mesmo se a detecção geral "funcionou". |
| `analyze-face` | Mesmas fotos — regiões periorbitais (olheira, pé de galinha) sugeridas devem ser plausíveis mesmo com óculos escuros cobrindo a referência visual. | Se a IA sugerir uma região periorbital com alta confiança numa foto onde os olhos estão totalmente cobertos por lente escura, isso é um sinal de alucinação — vale registrar como achado, já que o app hoje não valida a plausibilidade da sugestão contra oclusões visuais. |
| `generate-simulation` | Simulação deve manter os óculos na imagem final (não "removê-los" nem gerar olhos por baixo da lente escura, o que seria uma invenção visual). | Manter os óculos indica que o modelo respeitou a identidade/aparência real; "inventar" olhos por trás da lente é falha a reportar. |

### 4. Maquiagem pesada (contorno, cílios postiços, batom escuro, etc.)

| Superfície | O que testar | Comportamento esperado |
|---|---|---|
| Detecção de landmarks | Uma foto com maquiagem leve (baseline) e uma com maquiagem pesada (contorno marcado, lábios com batom escuro/contorno de lábio desenhado fora do formato natural, cílios postiços grandes). | Contorno de maquiagem pode confundir a detecção de bordas de lábio/maçã do rosto — comparar se os landmarks de lábio seguem o formato **real** do lábio ou o formato **desenhado** pela maquiagem (batom passado fora do contorno natural é um caso clássico de confusão). |
| `analyze-face` | Verificar se a IA sugere procedimentos "para corrigir" algo que é só maquiagem (ex.: sugerir preenchimento labial porque o batom foi passado fora do contorno, achando que é o lábio real). | A IA não deve confundir maquiagem com anatomia real de forma a gerar uma sugestão clinicamente equivocada. Se acontecer, é achado importante — sugestão de dose/local baseada em maquiagem é risco clínico, não só estético. |
| `generate-simulation` | Simulação deve simular o efeito do procedimento sobre o rosto real, não sobre a maquiagem (ex.: simular preenchimento labial não deveria só "esticar" o batom desenhado). | Resultado plausível anatomicamente. Artefatos visuais relacionados à maquiagem (brilho, textura) podem degradar; sugestão clínica construída em cima de maquiagem, não. |

### 5. Iluminação ruim (contraluz, muito escura, muito estourada/superexposta, luz colorida/ambiente)

| Superfície | O que testar | Comportamento esperado |
|---|---|---|
| Detecção de landmarks | Uma foto em contraluz (janela atrás do paciente, rosto em sombra), uma muito escura (ambiente pouco iluminado), uma estourada (flash direto/luz forte lavando os detalhes do rosto). | Contraluz/muito escura: alta chance de **nenhum landmark** ser encontrado — fluxo já tratado (toast + banner). Estourada: pode encontrar landmarks mas com posições menos precisas nas áreas de brilho especular (nariz, testa) — checar visualmente. |
| `analyze-face` | Mesmas fotos — a IA deve reconhecer regiões mesmo com iluminação ruim, ou sinalizar incerteza (se o prompt já contempla isso). | Aceitável degradar (sugestões mais genéricas) desde que o app continue funcional; falha grave seria a Edge Function travar/lançar erro não tratado — conferir tratamento de erro em `SessaoEstagio1`. |
| `generate-simulation` | Simulação com foto mal iluminada tende a ficar visualmente pior (mais artefato). | Degradação aceitável na qualidade visual; erro/timeout deve virar mensagem de erro clara pro profissional, nunca tela travada. |

## Classificação de resultado por caso

Para cada célula testada, classifique em uma das três categorias:

- ✅ **Funciona bem** — resultado plausível e clinicamente coerente, sem
  necessidade de aviso adicional.
- ⚠️ **Degrada graciosamente** — a IA erra ou não sabe, mas o app deixa isso
  claro (aviso visível, ainda que a experiência fique pior) e o profissional
  consegue prosseguir manualmente sem risco de confiar em algo errado sem
  perceber. **O que fazer:** confirmar que o aviso existe e é visível; se
  não existir, abrir item de backlog pedindo o aviso (seguindo o padrão do
  banner de detecção de landmarks descrito acima).
- ❌ **Falha (silenciosa ou bloqueante)** — a IA erra e o app não avisa (pior
  caso: gera uma sugestão clínica ou uma posição de ponto errada sem
  qualquer sinalização), ou trava/quebra a tela. **O que fazer:** tratar como
  bug — se envolver sugestão clínica equivocada sem aviso (dose, local de
  aplicação), priorizar como P0/P1 por ser risco à paciente, não só defeito
  de UX.

## Fora de escopo deste documento

- Não cobre performance/latência da detecção (tempo de carregamento do
  modelo MediaPipe) — isso é uma preocupação de UX separada.
- Não cobre testes automatizados de regressão visual (comparação pixel a
  pixel) — o roteiro acima é deliberadamente manual/qualitativo, já que a
  "correção" de um ponto de aplicação facial é uma avaliação clínica, não
  uma métrica objetiva fácil de automatizar sem um dataset anotado por
  profissionais.
- Não avalia se a Claude/Gemini API está configurada em produção — isso é
  configuração de ambiente, não comportamento de IA.
