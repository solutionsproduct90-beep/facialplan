# Hospedagem (Vercel) — `vercel.json` explicado bloco a bloco

Este documento é o comentário que o `vercel.json` não pode ter: o formato é
JSON estrito, a Vercel rejeita o deploy se houver `//` no arquivo. Toda decisão
tomada lá está justificada aqui.

**Contexto do achado.** Até esta rodada o repositório não tinha *nenhum* arquivo
de configuração de hospedagem versionado (nem `vercel.json`, nem
`netlify.toml`). Para uma SPA com 57 rotas client-side (`src/App.tsx`) isso é
bloqueador de produção em dois eixos ao mesmo tempo:

1. **Roteamento.** Sem `rewrites`, qualquer acesso *direto* a uma rota profunda
   (F5 em `/pacientes`, link de apresentação `/present/<token>` colado no
   WhatsApp, mini-site `/m/<slug>` compartilhado pelo profissional) recebe 404
   do próprio host — o `index.html` nunca chega ao navegador e o
   `react-router-dom` nunca roda.
2. **Segurança.** O app manipula foto de rosto de paciente e prontuário —
   dado pessoal sensível de saúde sob a LGPD (art. 5º, II). Sem headers de
   transporte/enquadramento/permissão, a superfície de ataque (downgrade para
   HTTP, clickjacking, vazamento de `Referer` com token na URL) fica aberta
   por omissão.

---

## 1. `rewrites` — fallback de SPA sem canibalizar a pré-renderização

```json
{ "source": "/((?!api/).*)", "destination": "/index.html" }
```

### Por que isso não destrói o SEO já construído

O `npm run build` roda `vite build` **e depois** `node scripts/prerender.mjs`,
que gera HTML real (conteúdo renderizado + `<title>`/`description`/OG/JSON-LD/
`hreflang`/`canonical` corretos) para 26 rotas públicas — institucionais e blog,
em `pt`, `es` e `en`. O resultado no `dist/` é um arquivo físico por rota:

```
dist/recursos/index.html
dist/precos/index.html
dist/sobre/index.html
dist/blog/index.html
dist/blog/<slug>/index.html
dist/es/... dist/en/...
```

A ordem de roteamento da Vercel é: `headers` → `redirects` → **sistema de
arquivos** → `rewrites` → 404. Ou seja: o rewrite só é consultado quando **não
existe arquivo** para o caminho pedido. `/blog/simulador-...` encontra
`dist/blog/simulador-.../index.html` no passo do sistema de arquivos e é servido
como HTML estático — o rewrite nunca roda. O mesmo vale para `/assets/*`,
`/favicon.svg`, `/sitemap.xml`, `/robots.txt`, `/manifest.webmanifest`,
`/sw.js`. Só rotas *sem* arquivo correspondente (`/pacientes`, `/sessoes/:id/…`,
`/present/:token`, `/m/:slug`) caem no `index.html` e viram SPA.

É exatamente a premissa que o `scripts/prerender.mjs` já documenta no cabeçalho
("arquivo existente tem prioridade sobre o fallback de SPA") — este arquivo só
torna essa premissa versionada em vez de dependente do painel da Vercel.

### Por que `(?!api/)` e não `/(.*)`

`api/geo.ts` é uma Vercel Serverless Function (lê `x-vercel-ip-country` para
sugerir idioma no primeiro boot, ver `src/i18n/index.ts`). Funções também são
resolvidas no passo de sistema de arquivos, então `/(.*)` *deveria* funcionar —
mas o modo de falha é silencioso: `/api/geo` passaria a devolver o `index.html`
e a detecção de país degradaria sem erro visível, só com um `JSON.parse` falhando
no cliente. O *negative lookahead* torna a intenção explícita e o modo de falha
barulhento (deploy quebra se a sintaxe estiver errada, em vez de um recurso
sumir em produção).

### `trailingSlash: false`

Sem essa chave a Vercel serve `/recursos` **e** `/recursos/` com 200 — duas URLs
para o mesmo conteúdo, o clássico problema de conteúdo duplicado. O
`prerender.mjs` emite `<link rel="canonical" href="${SITE_URL}${route}" />` sem
barra final; `trailingSlash: false` faz a versão com barra devolver 308 para a
canônica, alinhando host e canonical.

---

## 2. `headers` — segurança

Aplicados em `/(.*)`, isto é, em toda resposta (inclusive `/api/geo` e os HTMLs
pré-renderizados). A Vercel aplica *todas* as regras que casam, na ordem do
arquivo — por isso o bloco global só define segurança e os blocos seguintes só
definem `Cache-Control`: não há sobreposição entre eles.

| Header | Valor | Por quê |
|---|---|---|
| `Strict-Transport-Security` | `max-age=63072000; includeSubDomains` | Foto de rosto e prontuário não podem trafegar em HTTP nem por um downgrade de um único request. 2 anos é o valor recomendado pela OWASP. **Sem `preload` de propósito** — ver "Decisões do dono". |
| `X-Content-Type-Options` | `nosniff` | O Storage do Supabase serve upload de profissional; `nosniff` impede que um arquivo enviado com `Content-Type` inofensivo seja reinterpretado como script. |
| `Referrer-Policy` | `strict-origin-when-cross-origin` | Vários links públicos carregam **token na URL** (`/present/:token`, `/anamnese/:token`, `/feedback/:token`). Se o paciente clicar num link externo a partir dessas telas, o header `Referer` não pode vazar o token para terceiros — esta política envia só a origem em navegação cross-origin. |
| `X-Frame-Options` | `SAMEORIGIN` | Anti-clickjacking. O app não usa `<iframe>` em lugar nenhum, então enquadrar só na própria origem não custa nada. Duplicado em CSP como `frame-ancestors 'self'` para navegadores modernos. |
| `Cross-Origin-Opener-Policy` | `same-origin-allow-popups` | Isola o `window` do app de janelas cross-origin. A variante `-allow-popups` (e não `same-origin`) é obrigatória aqui: o app abre muitas janelas externas por `window.open` — `wa.me`, portal Hotmart, PDF em aba nova (`SessaoEstagio3.tsx`, que abre `about:blank` *antes* do `await` de propósito). `same-origin` puro romperia a referência dessas janelas. |
| `Permissions-Policy` | ver abaixo | — |

### `Permissions-Policy` — por que `microphone` NÃO está bloqueado

```
camera=(self), microphone=(self), geolocation=(), payment=(), usb=(),
serial=(), midi=(), display-capture=(), browsing-topics=()
```

- `camera=(self)` — `PerfilInsumos.tsx` usa `<input type="file"
  capture="environment">` para ler rótulo de insumo pela câmera (P8-2).
- `microphone=(self)` — **liberado de propósito, contrariando o pedido original
  da tarefa.** O app tem ditado por voz no prontuário (P4-8, ver
  `src/hooks/useVoiceDictation.ts` e `src/components/harmonize/VoiceDictationButton.tsx`),
  que usa a Web Speech API (`SpeechRecognition`/`webkitSpeechRecognition`). No
  Chrome/Edge essa API é governada pela feature `microphone` do
  Permissions-Policy: `microphone=()` mataria o ditado por voz em produção sem
  nenhuma mensagem de erro útil. Bloquear microfone e manter o recurso são
  requisitos incompatíveis; o recurso ganhou.
- `geolocation=()`, `payment=()`, `usb=()`, `serial=()`, `midi=()`,
  `display-capture=()` — nada no app usa; negar tudo reduz o estrago de um
  script de terceiro que um dia entre na página.
- `browsing-topics=()` — opt-out explícito da Topics API do Chrome. Não é
  requisito técnico, é postura de privacidade coerente com um app de dado de
  saúde.

### CSP: entregue em `Report-Only`, de propósito

O `Content-Security-Policy-Report-Only` lista as origens que o app comprovadamente
usa hoje:

| Diretiva | Origem | De onde veio |
|---|---|---|
| `script-src` | `'self'`, `'wasm-unsafe-eval'`, `https://cdn.jsdelivr.net` | O bundle é local, mas `FilesetResolver.forVisionTasks()` baixa o *loader* WASM do MediaPipe da jsDelivr (`src/lib/faceLandmarker.ts`), e o WASM precisa de `wasm-unsafe-eval`. |
| `style-src` | `'self'`, `'unsafe-inline'`, `https://fonts.googleapis.com` | Google Fonts (`index.html`) + estilos inline de Tailwind/Radix/Framer Motion, que são inevitáveis sem nonce por request (impossível em HTML estático). |
| `font-src` | `'self'`, `data:`, `https://fonts.gstatic.com` | Os `.woff2` do Plus Jakarta Sans. |
| `img-src` | `'self'`, `data:`, `blob:`, `https://*.supabase.co` | Fotos de paciente vêm de URL assinada do Storage; `blob:` é o preview local (`URL.createObjectURL` em `NovaSessao.tsx`, exports de vídeo/antes-e-depois). |
| `connect-src` | `'self'`, `https://*.supabase.co`, `wss://*.supabase.co`, `https://cdn.jsdelivr.net`, `https://storage.googleapis.com` | REST/Auth/Realtime/Edge Functions do Supabase, WASM da jsDelivr e o modelo `face_landmarker.task` do `storage.googleapis.com`. |

**Por que não está sendo imposta.** Três motivos concretos:

1. A URL do Supabase é por ambiente (`VITE_SUPABASE_URL`), então a CSP usa
   `https://*.supabase.co`. O curinga cobre projeto de produção e de preview,
   mas é mais largo do que o ideal — quem impuser deve trocar pelo host exato.
2. `style-src 'unsafe-inline'` é obrigatório hoje. Uma CSP com `unsafe-inline`
   em estilo protege menos do que aparenta; vale como rede de contenção para
   `script-src`, não como selo de conformidade.
3. O HTML pré-renderizado injeta `<script type="application/ld+json">` inline
   (`scripts/prerender.mjs`). Blocos de dado não-executável não deveriam
   disparar violação de `script-src`, mas o comportamento já divergiu entre
   navegadores. `Report-Only` é exatamente o mecanismo para descobrir isso sem
   derrubar as páginas que sustentam o SEO.

Uma CSP errada em modo imposto não degrada: ela apaga o app. Report-Only entrega
o inventário de origens (a parte difícil e a que envelhece) já pronto, e deixa a
virada para uma decisão consciente com dado de violação na mão.

**Checklist antes de impor** (auditoria de segurança pré-lançamento, 28/09/2026):

- [x] `script-src` autoriza por hash (`'sha256-…'`) o único `<script>` inline
  executável do `index.html` (captura do hash da URL para `/reset-password`,
  ver `src/lib/initialUrlHash.ts`). Sem isso, a CSP imposta bloqueia o script e
  todo link de recuperação de senha passa a ser "inválido". O teste
  `src/test/hostingConfig.test.ts` recalcula o hash e quebra se o script mudar
  sem o `vercel.json` acompanhar.
- [ ] **Não existe coleta de relatório.** A política não tem `report-uri` nem
  `report-to`, então o modo Report-Only hoje só escreve no console do
  navegador de quem abriu o DevTools — o "dado de violação na mão" descrito
  acima nunca chega a ninguém. Antes de impor, apontar `report-to`/`report-uri`
  para um coletor (serviço externo de relatórios de CSP ou um endpoint próprio,
  ex. uma Serverless Function em `api/` que só registre o relatório em log) e
  observar alguns dias de tráfego real.
- [ ] Trocar `https://*.supabase.co`/`wss://*.supabase.co` pelo host exato do
  projeto de produção.
- [ ] Validar num navegador real o fluxo do MediaPipe (loader carregado da
  jsDelivr) com a política imposta — o bundle local não usa `eval`/`new
  Function` (conferido no build), mas o loader remoto não passa pelo build.
  Alternativa que simplifica a CSP: servir os arquivos `wasm/` do
  `@mediapipe/tasks-vision` a partir do próprio domínio (hoje o app usa o JS da
  versão 1.0.1 instalada com o WASM 0.10.14 da CDN) e remover a jsDelivr de
  `script-src`/`connect-src`.

---

## 3. `headers` — cache

| Caminho | `Cache-Control` | Por quê |
|---|---|---|
| `/assets/(.*)` | `public, max-age=31536000, immutable` | Tudo em `dist/assets/` tem hash de conteúdo no nome (`index-BM3xSR3U.js`, `index-DKd6Bwam.css`, `vision_bundle-*.js`, imagens do blog). Mudou o conteúdo, muda o nome — cache eterno é seguro e é o que faz o segundo carregamento ser instantâneo. |
| `/workbox-(.*)` | `public, max-age=31536000, immutable` | O `workbox-<hash>.js` que o `vite-plugin-pwa` emite na raiz (não em `assets/`) também tem hash no nome, e é carregado por `importScripts` a partir do `sw.js`. Como o `sw.js` é revalidado sempre, um Workbox novo entra assim que o SW novo entra. |
| `/index.html` | `public, max-age=0, must-revalidate` | É o arquivo que aponta para o bundle com hash. Se ele ficar em cache, o usuário fica preso numa versão velha do app **para sempre** — o hash novo nunca é descoberto. |
| `/sw.js`, `/registerSW.js`, `/push-sw.js` | `public, max-age=0, must-revalidate` | Mesmo raciocínio, agravado: o service worker é o que decide o que fica em cache. Um `sw.js` velho em cache congela o app inteiro. Navegadores já limitam o cache de service worker a 24h por conta própria; isto elimina a janela. `push-sw.js` entra via `workbox.importScripts` (ver `vite.config.ts`) e não tem hash no nome, então precisa da mesma regra. |
| `/manifest.webmanifest` | `public, max-age=0, must-revalidate` | Sem hash no nome; mudanças de ícone/nome do PWA precisam chegar. |

Os HTMLs pré-renderizados (`/recursos`, `/blog/<slug>`, …) ficam no padrão da
Vercel para estático (`max-age=0, must-revalidate` no navegador, com cache na
borda e revalidação) — que é o comportamento certo para conteúdo editorial que
pode ser corrigido a qualquer momento. Não há regra explícita para eles de
propósito.

### Conflito com o PWA (resolvido)

O service worker gerado pelo Workbox registra
`NavigationRoute(createHandlerBoundToURL("index.html"))`, ou seja: por padrão,
**para um visitante que já instalou o SW, toda navegação é respondida com o
`index.html` do precache** — inclusive `/recursos` e `/blog/<slug>`, que têm
HTML pré-renderizado no servidor. Crawlers não executam service worker, então o
SEO nunca esteve em risco; o prejuízo era para o visitante recorrente e para o
PWA instalado, que viam a casca do SPA no lugar da página estática.

A correção é `workbox.navigateFallbackDenylist` no `vite.config.ts`, alimentado
por `scripts/prerenderedRoutes.mjs`. Os padrões de lá fazem a NavigationRoute se
recusar a atender essas URLs, e a navegação segue para a rede — onde os headers
da seção anterior entregam o arquivo pré-renderizado.

Dois detalhes que valem lembrar ao mexer nisso:

- O Workbox testa cada RegExp contra `url.pathname + url.search`, não contra o
  pathname puro. Um padrão terminado em `$` deixaria `/precos?utm_source=ig`
  escapar do denylist — justamente o tráfego de campanha.
- `src/test/pwaPrerenderDenylist.test.ts` percorre a lista real de
  `listStaticRoutes()` e exige que cada rota case com algum padrão. Rota
  institucional nova sem padrão correspondente quebra a suíte.

Para conferir no build: `grep -o 'denylist:\[.*' dist/sw.js`.

---

## 4. Verificação depois do primeiro deploy

```bash
curl -sI https://<dominio>/pacientes | head -1          # 200, não 404
curl -sI https://<dominio>/recursos | grep -i 'content-type'
curl -s  https://<dominio>/recursos | grep -c 'Recursos — FacialPlan'   # 1: veio o pré-renderizado
curl -s  https://<dominio>/api/geo                      # {"country":"BR"}, não HTML
curl -sI https://<dominio>/assets/<arquivo-com-hash>.js | grep -i cache-control
curl -sI https://<dominio>/sw.js | grep -i cache-control
```

Os invariantes desta configuração estão travados em
`src/test/hostingConfig.test.ts` — qualquer edição no `vercel.json` que
reintroduza um dos bugs acima quebra a suíte.
