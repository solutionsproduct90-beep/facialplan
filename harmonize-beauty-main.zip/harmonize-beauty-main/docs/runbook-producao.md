# Runbook de produção — do repositório ao primeiro paciente

Este documento é o passo a passo para colocar o FacialPlan no ar **do zero**,
escrito para alguém que nunca leu o código. Siga na ordem: cada etapa assume
a anterior pronta.

Até esta rodada essa informação não existia em lugar nenhum — só na cabeça de
quem escreveu o código. Um produto que só a autora consegue implantar não tem
operação, tem refém.

**Documentos irmãos, que este aqui NÃO repete:**

| Assunto | Onde está |
|---|---|
| Configuração de hospedagem (`vercel.json`): rewrites de SPA, headers de segurança, cache, CSP | [`docs/hospedagem.md`](./hospedagem.md) |
| Agendador das rotinas periódicas (GitHub Actions), `SCHEDULER_TOKEN`, rotação do token | [`docs/rotinas-agendadas.md`](./rotinas-agendadas.md) |
| Variáveis de build do frontend, uma a uma | [`.env.example`](../.env.example) na raiz |
| Testes adversariais dos prompts de IA | [`docs/testes-adversariais-ia.md`](./testes-adversariais-ia.md) |

---

## 0. Decisões que precisam de um dono antes de começar

Estes valores não estão no código porque não podem estar — dependem de escolha
de negócio. Decida antes, porque quase todo passo abaixo depende deles. Ao
longo do runbook aparecem como `<PLACEHOLDER>`.

| Placeholder | O que é | Onde vai ser usado |
|---|---|---|
| `<DOMINIO_APP>` | Domínio público do APP (login, painel, pacientes, sessões, admin), ex. `facialplan.com.br`. | Secret `PUBLIC_SITE_URL`, Resend, Supabase Auth URL Configuration, DNS |
| `<DOMINIO_INSTITUCIONAL>` | Domínio público do INSTITUCIONAL/blog (landing, recursos, preços, sobre, blog), ex. `facialplan.com` — desde a separação de domínio (ver `vercel.json`), é DIFERENTE do domínio do app. | `VITE_SITE_URL`, DNS |
| `<PROJECT_REF>` | Referência do projeto Supabase de produção (a parte de `https://<PROJECT_REF>.supabase.co`). | URL dos webhooks, deploy das functions, agendador |
| `<EMAIL_REMETENTE>` | Endereço que envia os e-mails transacionais, ex. `nao-responda@facialplan.com`. | Secret `RESEND_FROM_EMAIL` |
| `<EMAIL_CONTATO>` | Caixa de contato exibida no site institucional. Só preencha se alguém realmente lê. | `VITE_CONTACT_EMAIL` |
| `<EMAIL_ADMIN>` | E-mail da primeira conta administrativa. | Passo 8 |
| `<PRECO_ASSINATURA>` | Preço e periodicidade do produto na Hotmart. | Passo 6 |
| `<RAZAO_SOCIAL>`, `<CNPJ>`, `<ENDERECO>`, `<EMAIL_DPO>` | Dados do controlador dos dados, exigidos pela LGPD. | Termos de Uso e Política de Privacidade |

### Bloqueios ativos

Cada item abaixo impede alguma coisa de funcionar hoje. Nenhum é código: são
decisões ou passos de configuração que só o dono pode dar.

| # | Bloqueio | O que trava enquanto não resolver | Onde resolver |
|---|---|---|---|
| 1 | Um projeto Vercel por domínio ainda não decidido | Enquanto mais de um projeto estiver ligado ao mesmo repositório, um constrói a cada push e os outros ficam cancelados — todo PR fica com vermelho que não significa nada. Decida qual é produção, configure só nele e desconecte os outros. | Painel da Vercel |
| 2 | `project_id` do `config.toml` e `VITE_SUPABASE_URL` do `.env` apontam para projetos Supabase diferentes | O pior sintoma possível: o app fala com um banco e as edge functions e o agendador com outro. | Decisão + alinhar os dois |
| 3 | O workflow do agendador ainda não está no branch padrão | As três rotinas periódicas não rodam, e **sem erro nenhum** — o GitHub só agenda `cron` a partir do branch padrão. Mesclar é o passo que falta, não configurar. | Mesclar o PR (passo 5) |
| 4 | Secrets das edge functions não cadastrados | Cada função sem o seu segredo falha na primeira chamada real. A tabela do passo 3 lista todos. | `supabase secrets set` (passo 3) |
| 5 | Termos de Uso e Política de Privacidade com dados do controlador pendentes | Os dois documentos ficam públicos com `[PENDENTE — CNPJ]` visível para o paciente. Pior que não ter: expõe que ninguém revisou. | `src/content/legal/*.pt.md` |
| 6 | Nove versões de migration com mais de um arquivo | Só importa se o banco de produção for criado do zero. Ver a seção de timestamps repetidos no passo 2. | Decisão, depende do estado do banco |

**Resolvido nesta rodada, e por um caminho diferente do que este runbook
descrevia:** `VITE_SITE_URL` ausente derrubava todo deploy desde que o guard de
build entrou. Ela agora está no `.env`, que é versionado — o Vite lê esse
arquivo durante o build da Vercel, então o valor chega ao bundle sem nenhuma
configuração no painel. Cadastrar a variável em Settings > Environment
Variables continua funcionando e continua tendo precedência, mas deixou de ser
obrigatório para o deploy passar.

---

## 1. Contas e ferramentas necessárias

| Serviço | Para quê | Obrigatório? |
|---|---|---|
| [Supabase](https://supabase.com) | Banco, autenticação, storage de fotos e as 17 edge functions | Sim |
| [Vercel](https://vercel.com) | Hospedagem do frontend | Sim (ver `docs/hospedagem.md`) |
| [OpenAI](https://platform.openai.com) | Análise facial, checagem adversarial e leitura de rótulo de insumo | Sim — sem ela a IA cai no mock |
| [Google AI Studio](https://aistudio.google.com/app/apikey) | Geração da imagem de simulação e das peças de marketing | Sim — sem ela não há simulação |
| [Hotmart](https://hotmart.com) | Cobrança da assinatura do profissional | Sim, para vender |
| [Resend](https://resend.com) | E-mail transacional (paciente e alertas de admin) | Sim, para reengajamento e alertas |

Na máquina de quem vai implantar: **Node 22**, **npm**, **git** e a
[CLI do Supabase](https://supabase.com/docs/guides/local-development/cli/getting-started).

```bash
npm install -g supabase   # ou brew install supabase/tap/supabase
supabase login
supabase link --project-ref <PROJECT_REF>
```

---

## 2. Aplicar as migrations no banco

O schema inteiro vive em `supabase/migrations/` (78 arquivos, aplicados em
ordem de nome). Nunca edite um arquivo já aplicado: corrija criando uma
migration nova.

```bash
supabase db push
```

Verificação:

```bash
supabase migration list           # remoto e local devem bater
```

No painel (**Database > Tables**) confira que `profiles`, `patients`,
`sessions`, `error_logs` e `audit_log` existem e que **todas** aparecem com RLS
habilitada. Uma tabela sem RLS neste produto significa prontuário de um
profissional visível para outro.

> **Storage.** Os buckets de foto de paciente e de resultado de simulação são
> criados pelas próprias migrations
> (`20260909174233_add_error_logs_photos_bucket_hotmart.sql` e
> `20260909180500_add_simulation_results_bucket.sql`), com as policies junto.
> Não crie nada à mão no painel.

### Timestamps repetidos: verifique ANTES do primeiro `db push`

Nove versões de migration têm mais de um arquivo:

```bash
ls supabase/migrations | sed 's/_.*//' | sort | uniq -d
```

O prefixo numérico do nome é a chave de versão que o Supabase usa para saber o
que já rodou, então dois arquivos com o mesmo prefixo são ambíguos: a linha
registrada representa qual dos dois? Isso aconteceu porque várias ondas de
trabalho paralelo criaram migrations no mesmo horário redondo (`…190200`,
`…200000`, `…000000`) sem se verem.

**O que fazer depende de uma informação que só você tem: o banco de produção já
aplicou essas migrations?**

- **Se o banco já está com o schema completo** (foi construído ao longo do
  desenvolvimento, e não a partir de um `db push` do zero): não renomeie nada.
  Rode `supabase migration list` e compare com `ls supabase/migrations`. Se o
  remoto já registra tudo, o `db push` não tem o que aplicar e a ambiguidade
  não chega a ser exercitada. Deixe como está.

- **Se você vai criar um projeto Supabase novo e aplicar tudo do zero**: rode o
  `db push` num projeto descartável primeiro e confira que os 78 arquivos foram
  aplicados. Se algum ficar de fora, renomeie os duplicados para timestamps
  distintos (mantendo a ordem relativa) e repita — aqui é seguro, porque nada
  rodou ainda.

O que **não** dá para fazer é renomear com o banco de produção já populado: o
CLI passa a ver o arquivo renomeado como migration nova e tenta rodá-la de
novo, e 13 dos 25 arquivos envolvidos têm `CREATE TABLE`/`INDEX`/`POLICY` sem
`IF NOT EXISTS`, que falham na segunda execução.

`src/test/migrationVersions.test.ts` congela essa lista: os nove grupos estão
registrados como linha de base e qualquer migration nova que colida com uma
versão existente quebra a build. Corrigir aí é trivial, porque o arquivo novo
ainda não rodou em lugar nenhum.

---

## 3. Publicar as edge functions

As 17 funções em `supabase/functions/` rodam em Deno, no Supabase, e são o que
fala com IA, pagamento, e-mail e push.

```bash
supabase functions deploy
```

Para publicar uma só (depois de mexer nela):

```bash
supabase functions deploy analyze-face
```

### 3.1 `verify_jwt` — a armadilha que já derrubou o webhook da Hotmart

Toda função autenticada por outro meio que não o JWT do Supabase Auth precisa
de um bloco `[functions.<nome>] verify_jwt = false` em `supabase/config.toml`.
Sem o bloco, o valor padrão é `true` e **o gateway responde 401 antes de o
código da função rodar** — nenhum log, nenhum erro, só um webhook que
silenciosamente nunca chega. Foi exatamente o que aconteceu com o postback da
Hotmart e quase aconteceu com o agendador.

O arquivo já está correto hoje, com um comentário explicando cada caso. Se você
criar uma função nova nessa situação, o bloco é obrigatório.

### 3.2 Secrets

São **14 secrets** configurados à mão. Três variáveis que o código também lê —
`SUPABASE_URL`, `SUPABASE_ANON_KEY` e `SUPABASE_SERVICE_ROLE_KEY` — são
injetadas automaticamente pelo Supabase em toda função: **não as configure**.

```bash
supabase secrets set NOME='valor'      # uma
supabase secrets list                  # confere o que está lá
```

| Secret | Para que serve | Quem usa | Onde obter |
|---|---|---|---|
| `OPENAI_API_KEY` | Modelo que faz a análise facial (GPT-6 Sol), a segunda opinião adversarial e a leitura de rótulo de insumo (GPT-6 Luna nas duas últimas). | `analyze-face`, `adversarial-risk-check`, `read-insumo-label` | platform.openai.com > API Keys |
| `GEMINI_API_KEY` | Geração das imagens (simulação do resultado). | `generate-simulation` | aistudio.google.com/app/apikey |
| `HOTMART_HOTTOK` | Segredo que autentica o postback da Hotmart (comparado em tempo constante). | `hotmart-webhook` | Hotmart > Ferramentas > Webhook/Postback > Hottok |
| `RESEND_API_KEY` | Envio de todo e-mail transacional. | `send-patient-email`, `send-reengagement-reminders`, `alert-error-spike`, `hotmart-webhook` | resend.com > API Keys |
| `RESEND_FROM_EMAIL` | Remetente dos e-mails, no formato `FacialPlan <nao-responda@dominio>`. Sem ele o código cai no remetente de sandbox da Resend, que **só entrega para você mesmo**. | idem acima | Decisão do dono: `<EMAIL_REMETENTE>` |
| `PUBLIC_SITE_URL` | `https://<DOMINIO_APP>` — usado para montar links absolutos fora do navegador (link de apresentação no e-mail, link do painel no alerta de erro). | `send-reengagement-reminders`, `alert-error-spike` | Decisão do dono. **Não confundir com `VITE_SITE_URL`**: são domínios DIFERENTES desde a separação app/institucional — este usa `<DOMINIO_APP>`, aquele usa `<DOMINIO_INSTITUCIONAL>`. |
| `SCHEDULER_TOKEN` | Autentica o agendador (GitHub Actions) nas rotinas periódicas. | `alert-error-spike`, `notify-overdue-returns`, `send-reengagement-reminders` | `openssl rand -base64 48` — ver `docs/rotinas-agendadas.md` |
| `VAPID_PUBLIC_KEY` | Chave pública do Web Push. Precisa ser **idêntica** ao `VITE_VAPID_PUBLIC_KEY` do frontend. | `send-push-notification` | `npx web-push generate-vapid-keys` |
| `VAPID_PRIVATE_KEY` | Chave privada do mesmo par. Nunca sai do servidor. | `send-push-notification` (via `_shared/webPush.ts`) | mesmo comando acima |
| `VAPID_SUBJECT` | Contato exigido pelo RFC 8292: `mailto:<EMAIL_CONTATO>` ou `https://<DOMINIO_APP>`. Sem ele a Apple rejeita o push. | `send-push-notification` | Decisão do dono |

**Degradação quando um secret falta.** Nenhuma função quebra com exceção não
tratada: cada uma checa a própria chave e degrada de forma registrada — a IA
cai num resultado mock, o e-mail é pulado com uma linha em `error_logs`.
Isso é bom para subir por partes, mas significa que **a ausência de um secret
não aparece como erro vermelho**: confira com `supabase secrets list` e depois
com o smoke test do passo 9.

---

## 4. Publicar o frontend (Vercel)

O `vercel.json` já está versionado e explicado bloco a bloco em
[`docs/hospedagem.md`](./hospedagem.md) — leia lá o porquê de cada rewrite,
header e regra de cache. Aqui fica só a sequência operacional.

1. **Importe o repositório** em vercel.com > Add New > Project.
2. **Build settings** — os defaults do Vite servem: build `npm run build`,
   output `dist`.
3. **Environment Variables**: as três variáveis marcadas `[OBRIGATÓRIA]` em
   [`.env.example`](../.env.example) não são negociáveis — o `npm run build`
   **falha** sem elas, de propósito. Antes desse guard um deploy sem
   `VITE_SITE_URL` subia verde e sem `sitemap.xml` nenhum, com o SEO
   pré-renderizado invisível para os buscadores. As três já estão no `.env`
   versionado e o Vite as lê durante o build, então o deploy passa sem tocar no
   painel. Cadastre-as em *Production* e *Preview* apenas quando algum ambiente
   precisar de um valor diferente do que está no arquivo: a variável do painel
   tem precedência sobre o `.env`.
4. **Domínio**: aponte `<DOMINIO_APP>` E `<DOMINIO_INSTITUCIONAL>` em Settings >
   Domains e siga o DNS indicado para os dois — são domínios diferentes desde
   a separação app/institucional (ver `vercel.json`), ambos precisam estar
   configurados no mesmo projeto Vercel para os redirects entre eles funcionarem.
5. **Refaça o deploy depois de qualquer mudança de variável.** Variável `VITE_`
   é embutida no bundle em tempo de build; alterar no painel não muda nada até
   o próximo deploy.

Verificação (o `docs/hospedagem.md` tem a lista completa de `curl`):

```bash
curl -sI https://<DOMINIO_APP>/pacientes | head -1                 # 200, não 404
curl -s  https://<DOMINIO_INSTITUCIONAL>/sitemap.xml | head -3      # <urlset …>, não o index.html
curl -s  https://<DOMINIO_INSTITUCIONAL>/robots.txt | grep Sitemap  # aponta para <DOMINIO_INSTITUCIONAL>
```

Se o `sitemap.xml` devolver HTML, o arquivo não foi gerado: `VITE_SITE_URL` não
estava presente no build.

---

## 5. Agendador das rotinas periódicas

Três rotinas (alerta de erro em produção, reengajamento de sessões
abandonadas, aviso de retorno atrasado) só existem se alguém as chamar.

Passo a passo completo — geração do token, os dois secrets do GitHub, rotação e
verificação — em **[`docs/rotinas-agendadas.md`](./rotinas-agendadas.md)**. Não
pule: sem isso, três funcionalidades entregues não fazem absolutamente nada em
produção, e sem erro nenhum, porque nada é chamado.

> **Antes dos secrets: o workflow precisa estar no branch padrão.** O GitHub só
> agenda `cron` a partir dele, e não avisa quando o arquivo está só num branch
> de feature — não há job vermelho, não há log, nada acontece. Confira com
> `git cat-file -e origin/<branch-padrao>:.github/workflows/rotinas-agendadas.yml`
> e, se não existir, o passo que falta é mesclar, não configurar. Ver o passo 0
> de [`docs/rotinas-agendadas.md`](./rotinas-agendadas.md).

---

## 6. Registrar o postback da Hotmart

A Hotmart é quem libera o acesso ao app: enquanto o postback não chegar,
`profiles.subscription_status` fica `inactive` e **todo mundo que paga continua
vendo a tela de assinatura**.

1. Crie o produto e a oferta (`<PRECO_ASSINATURA>`) na Hotmart.
2. Em **Ferramentas > Webhook (Postback)**, cadastre:

   ```
   https://<PROJECT_REF>.supabase.co/functions/v1/hotmart-webhook
   ```

3. Selecione os eventos de compra e assinatura. O código trata
   `PURCHASE_APPROVED` e `PURCHASE_COMPLETE` (libera), `PURCHASE_CANCELED`,
   `PURCHASE_REFUNDED`, `PURCHASE_CHARGEBACK`, `PURCHASE_EXPIRED` e
   `SUBSCRIPTION_CANCELLATION` (bloqueia) e `PURCHASE_DELAYED` (marca
   `past_due`, com 3 dias de carência).
4. Copie o **Hottok** e registre:

   ```bash
   supabase secrets set HOTMART_HOTTOK='<hottok>'
   ```

5. Copie o link de checkout da oferta para `VITE_HOTMART_CHECKOUT_URL` e o link
   da área de assinantes para `VITE_HOTMART_MEMBER_PORTAL_URL`, no painel da
   Vercel. Sem o primeiro, o botão "Assinar" fica desabilitado com "em breve".

**Verificação:** dispare um evento de teste pela Hotmart e confira em
**Admin > Log de Erros** que não apareceu `hotmart_*`. Um 401 na Hotmart
significa `verify_jwt` (passo 3.1); um 501 significa `HOTMART_HOTTOK` ausente.

---

## 7. Verificar o domínio no Resend e criar as caixas

Sem domínio verificado, a Resend só entrega e-mail **para o dono da própria
conta** — em produção isso significa que nenhum paciente recebe nada.

1. Em resend.com > **Domains > Add Domain**, informe o domínio de
   `<EMAIL_REMETENTE>`.
2. Publique no DNS os registros que a Resend mostrar: **SPF** (TXT), **DKIM**
   (CNAME/TXT) e, recomendado, **DMARC** (TXT em `_dmarc`). Aguarde o status
   virar *Verified*.
3. Registre o remetente:

   ```bash
   supabase secrets set RESEND_FROM_EMAIL='FacialPlan <nao-responda@<DOMINIO_APP>>'
   ```

**Caixas que precisam existir de verdade** (não são só endereços no DNS):

| Caixa | Por quê |
|---|---|
| A caixa de resposta do `<EMAIL_REMETENTE>` | Mesmo um "não responda" recebe resposta de paciente. Se o endereço não existe, a resposta volta como bounce e ninguém fica sabendo. |
| `<EMAIL_CONTATO>` | Exibida em `/sobre`. Só configure `VITE_CONTACT_EMAIL` se alguém lê. |
| `<EMAIL_ADMIN>` | Recebe o alerta horário de erro em produção (`alert-error-spike` envia para **todo** `profiles` com `role = 'admin'` e e-mail preenchido). |

---

## 8. Criar a primeira conta admin

Não existe tela para promover ninguém a admin — de propósito: se existisse, o
primeiro admin precisaria de outro admin para criá-lo. A coluna
`profiles.role` nasce com `'professional'` e só muda no banco.

1. Cadastre-se normalmente pelo app em `https://<DOMINIO_APP>/auth/cadastro` com
   `<EMAIL_ADMIN>` e confirme o e-mail.
2. No painel do Supabase, em **SQL Editor**:

   ```sql
   update public.profiles
      set role = 'admin'
    where id = (select id from auth.users where email = '<EMAIL_ADMIN>');
   ```

3. Faça logout e login de novo (o papel é lido no carregamento do perfil).

O que isso habilita: as telas `/admin/*` (usuários, log de erros, métricas,
auditoria, Central de Inteligência) e, por `ProtectedRoute.tsx`, **bypass do
paywall** — é a conta que a equipe usa para testar sem pagar. É também o
endereço que recebe o alerta de erro em produção. Trate como credencial
sensível: ela vê dados agregados de todos os profissionais.

---

## 9. Smoke test manual pós-deploy

Execute **nesta ordem**, num navegador anônimo, com uma conta descartável que
não seja a de admin (o admin não passa pelo paywall e esconderia justamente o
bug mais caro). Cada passo depende do anterior.

| # | Passo | O que precisa acontecer | Se falhar, olhe |
|---|---|---|---|
| 1 | **Cadastro** — `/auth/cadastro`, aceite os termos, confirme o e-mail. | Conta criada, e-mail de confirmação chega, e o app leva a `/assinar` (e não para dentro). | Auth > URL Configuration no Supabase (o link de confirmação precisa apontar para `<DOMINIO_APP>`); tabela `terms_acceptances` tem a linha com `source = 'cadastro'`. |
| 2 | **Pagamento** — clique em "Assinar" e conclua uma compra de teste na Hotmart. | O botão leva ao checkout (não fica cinza com "em breve"). | `VITE_HOTMART_CHECKOUT_URL` no painel da Vercel + novo deploy. |
| 3 | **Ativação** — volte ao app e recarregue. | `profiles.subscription_status` virou `active` e o app entra no painel em vez de voltar para `/assinar`. | Passo 6. 401 na Hotmart = `verify_jwt`; nada chegando = URL errada; 501 = `HOTMART_HOTTOK`. |
| 4 | **Primeira sessão com IA** — crie um paciente, preencha a anamnese, inicie uma sessão e envie a foto. | A análise volta com achados reais **e** a simulação gera imagem. Se vier um texto genérico, a IA caiu no mock. | `OPENAI_API_KEY` (análise) e `GEMINI_API_KEY` (imagem); Admin > Log de Erros. |
| 5 | **PDF** — conclua o estágio 3 e gere o PDF. | O arquivo abre com foto, protocolo, custos e a trilha de auditoria clínica. | O PDF é gerado no navegador; um bloqueador de popup impede a aba nova. |
| 6 | **Link público do paciente** — gere o link de apresentação e abra **em janela anônima**, sem sessão. | A apresentação carrega para quem não está logado. | `verify_jwt` de `public-session-presentation`. |

Depois do roteiro, abra **Admin > Log de Erros**: uma linha de
`subscription_inactive`, `consent_missing` ou `rate_limited` é o sistema
funcionando (paywall, gate de consentimento, rate limit). Qualquer outra coisa
merece investigação antes de convidar o primeiro profissional de verdade.

---

## 10. Segurança: o que resolver antes de crescer

- **O arquivo `.env` está versionado no Git.** Hoje ele só contém valores
  `VITE_` (publicáveis por definição — vão para o bundle de qualquer jeito), e
  a CI depende dele para o passo de build, então remover exige trocar as duas
  coisas juntas. Ainda assim é uma armadilha: no dia em que alguém acrescentar
  ali uma chave que não é pública, ela vaza no mesmo commit. O certo é
  `git rm --cached .env`, acrescentar `.env` ao `.gitignore` e declarar
  `VITE_SUPABASE_URL`/`VITE_SUPABASE_PUBLISHABLE_KEY` como variáveis do passo de
  build em `.github/workflows/ci.yml` (que já tem um comentário apontando para
  aqui).
- **Nunca coloque `service_role`, `sk_live_…`, `OPENAI_API_KEY` ou
  `VAPID_PRIVATE_KEY` numa variável `VITE_`.** Tudo que tem esse prefixo é
  embutido no JavaScript e fica legível para qualquer visitante.
- **CSP.** O `vercel.json` entrega `Content-Security-Policy-Report-Only`. Depois
  de algumas semanas com dados de violação, avalie impor — ver o raciocínio
  completo em `docs/hospedagem.md`.

---

## 11. Quando algo quebrar

| Sintoma | Causa mais provável |
|---|---|
| `npm run build` falha dizendo "variável de ambiente obrigatória ausente" | É o comportamento novo e correto. Configure o que a mensagem pede (`scripts/buildEnv.mjs` tem a lista). |
| Tela branca em produção, console com `supabaseUrl is required` | `VITE_SUPABASE_URL`/`VITE_SUPABASE_PUBLISHABLE_KEY` não estavam no build. |
| 404 ao recarregar uma rota interna, ou num link `/present/…` | Rewrite de SPA — `docs/hospedagem.md`. |
| Webhook (Hotmart) devolve 401 | Falta o bloco `[functions.<nome>] verify_jwt = false` em `supabase/config.toml`. |
| Webhook devolve 501 | O secret correspondente não está configurado. |
| Pagou e continua vendo `/assinar` | O postback não chegou ou não foi aceito — passo 6. |
| Nenhum e-mail sai | `RESEND_API_KEY` ausente, ou domínio não verificado na Resend (passo 7). |
| Push não ativa | `VITE_VAPID_PUBLIC_KEY` e `VAPID_PUBLIC_KEY` precisam ser o mesmo valor; no iOS o app tem de estar instalado na tela de início. |
| Rotina agendada não roda | `docs/rotinas-agendadas.md`, seção de verificação. |
| IA responde algo genérico demais | Caiu no fallback mock: `OPENAI_API_KEY`/`GEMINI_API_KEY`. |
